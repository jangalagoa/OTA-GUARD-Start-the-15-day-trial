"""Masquage des secrets — utilisé par la boîte noire, le rapport et le zip.

Règle : AUCUN secret ne doit jamais quitter la machine en clair, même dans
un rapport destiné au vendeur. Trois mécanismes :
1. mask_dict()   : récursif — toute clé au nom suspect (password, token,
                   api_key, secret, auth…) a sa valeur remplacée ;
2. mask_text()   : motifs regex dans le texte libre (clés AIza…, Bearer…,
                   ?token=…, "password": "…") — mêmes motifs que
                   business/app_logger._sanitize, réimportés pour rester
                   en synchro ;
3. les fichiers de secrets (secrets.json) ne sont JAMAIS ouverts.
"""
import re

# Noms de clés dont la valeur est TOUJOURS masquée (insensible à la casse).
_KEY_HINTS = ("password", "passwd", "pass", "secret", "token", "api_key",
              "apikey", "auth", "credential", "private_key", "cm_pass",
              "cm_user")

# Valeurs qui ressemblent à une clé même sous un nom anodin.
_VALUE_PATTERNS = [
    re.compile(r"AIza[A-Za-z0-9_\-]{20,}"),
    re.compile(r"sk-(?:ant|proj)-[A-Za-z0-9_\-]{10,}"),
    re.compile(r"gsk_[A-Za-z0-9_\-]{10,}"),
]

_MASK = "***"


def _key_is_sensitive(key: str) -> bool:
    k = (key or "").lower()
    return any(h in k for h in _KEY_HINTS)


def mask_value(v):
    """Masque une valeur si elle ressemble à une clé, sinon la retourne."""
    if isinstance(v, str):
        for pat in _VALUE_PATTERNS:
            if pat.search(v):
                return _MASK
        if len(v) > 80 and re.search(r"[A-Za-z0-9_\-]{30,}", v):
            # Longue chaîne opaque ressemblant à un secret encodé.
            return _MASK
    return v


def mask_dict(obj, _depth: int = 0):
    """Copie profonde masquée d'un dict/list (l'original n'est pas touché)."""
    if _depth > 12:
        return _MASK
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _key_is_sensitive(str(k)):
                out[k] = _MASK if v not in ("", None, False, 0) else v
            else:
                out[k] = mask_dict(v, _depth + 1)
        return out
    if isinstance(obj, (list, tuple)):
        return [mask_dict(v, _depth + 1) for v in obj]
    return mask_value(obj)


def mask_text(text: str) -> str:
    """Masque les secrets dans du texte libre (lignes de journal, etc.)."""
    if not text:
        return text
    # Mêmes motifs que business/app_logger (source de vérité unique).
    try:
        from business.app_logger import _sanitize
        text = _sanitize(text)
    except Exception:
        pass
    for pat in (re.compile(r'([?&](?:key|token|auth|api_key|secret)=)[^&\s"\']+',
                           re.I),
                re.compile(r'((?:password|secret|token|api_key|auth)\s*[=:]\s*)\S+',
                           re.I)):
        text = pat.sub(r"\1" + _MASK, text)
    return text


def mask_url(url: str) -> str:
    """Garde le domaine + chemin d'une URL, masque la query string."""
    if not isinstance(url, str) or "://" not in url:
        return url
    base, sep, _query = url.partition("?")
    return base + ("?…" if sep else "")
