"""Collecte des faits — lecture seule intégrale (D91).

Lecture de TOUT ce que OTA Guard sait sur lui-même :
identité, environnement, licence, configuration (masquée), calibrations,
dernier scan, historique d'envois, échecs de push, erreurs de journaux,
vérifications saisonnières, journal juridique, bases SQLite, boîte noire.

RÈGLES :
- config.json lu DIRECTEMENT (jamais core.config.load(), qui injecte les
  secrets et peut réécrire le fichier) ;
- secrets.json : présence/taille uniquement, JAMAIS ouvert ;
- toute section défaillée est marquée "collect_error" — jamais de crash ;
- progress_cb(section_label) pour la fenêtre.
"""
import datetime
import json
import os
import re
import socket
import threading
import time
from pathlib import Path

from core.paths import DATA_DIR, INSTALL_DIR

from diagnostic import masker
from diagnostic import recorder

# D95 : garde-fous de durée — sur le PC client (≈120 000 captures,
# ota_guard.log 15 Mo), une section pouvait traîner des minutes et la
# fenêtre restait « Analyse… » à l'infini. Chaque section est désormais
# exécutée sous surveillance : au-delà de SECTION_TIMEOUT s elle est
# abandonnée (constatée « trop lente » dans le rapport) et la collecte
# CONTINUE. Les journaux ne sont lus que par leur QUEUE (derniers
# _TAIL_BYTES octets) : le diagnostic porte sur le récent, pas l'histoire.
SECTION_TIMEOUT = 30.0
_TAIL_BYTES = 2 * 1024 * 1024


def _tail_lines(fp: Path, max_bytes: int = _TAIL_BYTES) -> list:
    """Dernières lignes d'un fichier (queue des derniers max_bytes octets).
    Un diagnostic porte sur le RÉCENT : lire un journal de 15 Mo entier
    ne change rien au verdict et coûte des minutes sur un disque lent."""
    try:
        size = fp.stat().st_size
        with open(fp, "rb") as f:
            if size > max_bytes:
                f.seek(-max_bytes, os.SEEK_END)
            raw = f.read()
        text = raw.decode("utf-8", "replace")
        if size > max_bytes and "\n" in text:
            text = text.split("\n", 1)[1]   # ligne partielle du début
        return [l for l in text.splitlines() if l.strip()]
    except Exception:
        return []


def _read_json(fp: Path):
    with open(fp, encoding="utf-8") as f:
        return json.load(f)


def _file_info(fp: Path) -> dict:
    st = fp.stat()
    return {
        "size": st.st_size,
        "mtime": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(
            timespec="seconds"),
        "age_h": round((time.time() - st.st_mtime) / 3600, 1),
    }


def _collect_identity(out: dict):
    import platform
    import sys
    try:
        from version import VERSION, BUILD_DATE
        out["app_version"] = f"{VERSION} (build {BUILD_DATE})"
    except Exception:
        out["app_version"] = "inconnue"
    out["generated_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    # Nuitka standalone ne définit PAS sys.frozen : chaque module compilé
    # reçoit l'attribut __compiled__ — c'est lui le marqueur de l'exe
    # (premier rapport réel : l'exe s'annonçait « source python » à tort).
    out["mode"] = ("exe compilé" if (getattr(sys, "frozen", False)
                                     or "__compiled__" in globals())
                   else "source python")
    out["python"] = sys.version.split()[0]
    out["os"] = f"{platform.system()} {platform.release()}"
    out["machine"] = platform.node()
    out["user"] = os.environ.get("USERNAME", "?")
    out["tz"] = time.tzname[0]
    out["install_dir"] = str(INSTALL_DIR)
    out["data_dir"] = str(DATA_DIR)


def _collect_environment(out: dict):
    # Fichiers clés du dossier de données
    watched = ["config.json", "config.json.bak", "secrets.json", "scraper.db",
               "otaguard.db", "license.dat", ".tdata", "app.log", "app.log.bak",
               "ota_guard.log", "activity_log.txt", "fx_cache.json",
               "instance.lock"]
    files = {}
    for name in watched:
        fp = DATA_DIR / name
        if fp.exists():
            fi = _file_info(fp)
            fi["size_kb"] = round(fi.pop("size") / 1024, 1)
            files[name] = fi
    out["data_files"] = files
    out["secrets_present"] = (DATA_DIR / "secrets.json").exists()

    # Captures VAE : le VRAI dossier est celui que l'app utilise
    # (extranet_bridge.captures_dir — freshest entre vae embarqué et
    # standalone). data/captures n'est qu'un candidat : le premier rapport
    # réel comptait 0 captures alors que le journal en sauvegarde en
    # continu. Repli silencieux si l'import est impossible.
    caps_path = None
    try:
        from extranet_bridge import captures_dir as _cd
        caps_path = _cd({})
    except Exception:
        pass
    if caps_path is None or not Path(caps_path).exists():
        caps_path = DATA_DIR / "captures"
    out["captures_dir"] = str(caps_path)
    caps = Path(caps_path)
    if caps.exists():
        try:
            # D95 : UN SEUL passage (scandir) pour count + fraîcheur —
            # l'ancien code faisait glob + max(stat) puis re-glob,
            # 3 parcours complets (des minutes sur 120 000 fichiers).
            count, newest = 0, 0.0
            for entry in os.scandir(caps):
                if not entry.name.lower().endswith(".json"):
                    continue
                count += 1
                try:
                    m = entry.stat(follow_symlinks=False).st_mtime
                    if m > newest:
                        newest = m
                except OSError:
                    pass
            out["captures"] = {
                "count": count,
                "newest": datetime.datetime.fromtimestamp(newest).isoformat(
                    timespec="seconds") if newest else "",
                "age_h": round((time.time() - newest) / 3600, 1) if newest
                else None,
            }
        except Exception:
            out["captures"] = {"error": "lecture impossible"}
    else:
        out["captures"] = {"count": 0}

    # Port CDP 9222 du navigateur (connexion LOCALE au propre navigateur
    # de l'utilisateur — identique à l'écoute VAE, aucune requête OTA, R1).
    try:
        s = socket.create_connection(("127.0.0.1", 9222), timeout=1.0)
        s.close()
        out["cdp_9222"] = True
    except Exception:
        out["cdp_9222"] = False

    # Espace disque du dossier de données
    try:
        import shutil as _sh
        usage = _sh.disk_usage(str(DATA_DIR))
        out["disk_free_gb"] = round(usage.free / 1024 ** 3, 1)
    except Exception:
        pass

    # Boîte noire : volume
    try:
        bb = DATA_DIR / "blackbox"
        days = sorted(bb.glob("blackbox_*.jsonl")) if bb.exists() else []
        out["blackbox_days"] = [f.name for f in days[-3:]]
    except Exception:
        pass


def _collect_license(out: dict):
    try:
        from licensing.license_checker import (
            get_checker, TRIAL_ACTIVE, LICENSED, TRIAL_EXPIRED,
            LICENSE_EXPIRED, LICENSE_REVOKED, INVALID)
        names = {TRIAL_ACTIVE: "essai actif", LICENSED: "licence active",
                 TRIAL_EXPIRED: "essai expiré", LICENSE_EXPIRED: "licence expirée",
                 LICENSE_REVOKED: "licence révoquée", INVALID: "invalide"}
        checker = get_checker()
        out["status"] = names.get(checker.status, str(checker.status))
        info = checker.info or {}
        for k in ("expires", "days_left", "hw_ok"):
            if k in info:
                out[k] = info[k]
    except Exception as e:
        out["checker_error"] = str(e)[:120]
    try:
        from licensing.limits import license_limits
        max_rooms, zone = license_limits()
        out["zone"] = zone
        out["max_rooms"] = max_rooms
    except Exception:
        pass
    # Jamais le contenu de license.dat / .tdata.


def _collect_config(out: dict):
    """config.json lu DIRECTEMENT — jamais core.config.load() (injection
    de secrets + effet de bord de sauvegarde). Résultat masqué."""
    fp = DATA_DIR / "config.json"
    if not fp.exists():
        out["missing"] = True
        return
    try:
        cfg = _read_json(fp)
    except Exception as e:
        out["invalid_json"] = str(e)[:200]
        return
    out["valid_json"] = True

    ow = cfg.get("ota_watch") or {}
    otas = []
    for o in ow.get("otas") or []:
        if isinstance(o, dict) and o.get("name"):
            otas.append({"name": o.get("name"),
                         "active": bool(o.get("active")),
                         "domain": masker.mask_url(o.get("url") or "")})
    out["otas"] = otas
    out["target_prices"] = ow.get("target_prices") or {}
    out["last_results"] = ow.get("last_results") or {}
    out["last_scan_time"] = ow.get("last_scan_time") or ""
    out["auto_correct"] = cfg.get("ota_watch", {}).get("auto_correct")
    out["scan_interval_h"] = ow.get("interval_h")
    out["min_gap"] = ow.get("min_gap")
    out["room_inventory"] = cfg.get("room_inventory") or {}
    out["room_types"] = cfg.get("room_types") or []
    strat = cfg.get("strategy") or {}
    out["floors"] = strat.get("floors") or {}
    out["ceilings"] = strat.get("ceilings") or {}
    out["currency"] = cfg.get("currency_code") or cfg.get("hotel_currency")
    out["hotel"] = {"name": cfg.get("hotel_name"), "city": cfg.get("hotel_city"),
                    "country": cfg.get("hotel_country")}

    # Extranet direct : transport + CM actif (aucun secret)
    ed = cfg.get("extranet_direct") or {}
    out["transport"] = ed.get("transport") or (
        cfg.get("channel_manager", {}) or {}).get("transport", "api")
    out["cm_map"] = ed.get("cm_map") or ""
    out["extranet_browser_execution"] = ed.get("browser_execution")
    out["cm_domain"] = masker.mask_url(
        ((cfg.get("channel_manager") or {}).get("base_url")) or "")

    # Config complète masquée (pour le rapport JSON / la comparaison)
    out["_sanitized_full"] = masker.mask_dict(cfg)


def _collect_calibrations(out: dict):
    profs = []
    for fp in sorted(DATA_DIR.glob("calibration_data_*.json")):
        if fp.name.endswith("_shared.json") or ".bak" in fp.name:
            continue
        try:
            data = _read_json(fp)
        except Exception:
            out.setdefault("invalid_files", []).append(fp.name)
            continue
        for key, p in (data.get("profiles") or {}).items():
            if not isinstance(p, dict):
                continue
            profs.append({
                "file": fp.name,
                "ota": p.get("ota") or key.split("||")[-1],
                "room_aliases": p.get("room_aliases") or {},
                "calibrated_at": p.get("calibrated_at") or "",
                "last_scan": p.get("last_scan") or "",
                "prices_learned": len(p.get("prices_learned") or {}),
                "source_currency": p.get("source_currency") or "",
            })
    out["profiles"] = profs
    sh = DATA_DIR / "calibration_data_shared.json"
    if sh.exists():
        try:
            out["shared_keys"] = sorted((_read_json(sh) or {}).keys())
        except Exception:
            out["shared_error"] = "illisible"


def _collect_sends(out: dict):
    """Historique d'envois : par fichier/OTA, par chambre."""
    per_ota = {}
    for fp in sorted(DATA_DIR.glob("send_history_*.json")):
        ota = fp.stem.replace("send_history_", "")
        try:
            data = _read_json(fp)
        except Exception:
            per_ota[ota] = {"error": "illisible"}
            continue
        rooms = {}
        for room, lst in (data.get("measures") or {}).items():
            if not isinstance(lst, list):
                continue
            confirmed = [e for e in lst
                         if e.get("status") == "confirmed" and e.get("sent")
                         and e.get("observed")]
            pend = next((e for e in reversed(lst)
                         if e.get("status") == "pending"), None)
            ratios = [e["observed"] / e["sent"] for e in confirmed
                      if e.get("sent")]
            rooms[room] = {
                "total": len(lst),
                "confirmed": len(confirmed),
                "pending": bool(pend),
                "pending_checks": (pend or {}).get("checks", 0),
                "pending_since": (pend or {}).get("sent_at", ""),
                "last_sent": next((e.get("sent") for e in reversed(lst)
                                   if not e.get("simulated") and e.get("sent")),
                                  None),
                "last_observed": (confirmed[-1].get("observed")
                                  if confirmed else None),
                "last_target": next((e.get("target") for e in reversed(lst)
                                     if e.get("target")), None),
                "ratio_median": round(sorted(ratios)[len(ratios) // 2], 3)
                if ratios else None,
            }
        per_ota[ota] = rooms
    out["per_ota"] = per_ota


_PUSH_CAUSES = [
    ("preflight_failed", re.compile(r"preflight", re.I)),
    ("post_missing", re.compile(r"post_missing|aucun POST", re.I)),
    ("session expirée", re.compile(r"session.*expir|login", re.I)),
    ("refus verrou", re.compile(r"déjà en cours|already in progress|refus", re.I)),
    ("not_seen", re.compile(r"not_seen|change not seen", re.I)),
    ("échec réseau/CDP", re.compile(r"websocket|timeout|cdp|reconnect", re.I)),
]

# D92 : garde-fous min/max vus par l'app — la cause n°1 d'« imprecise prices »
# (le calcul veut envoyer X mais le plancher/plafond le ramène à Y → la cible
# n'est jamais atteinte). Extraits de app.log, la source de vérité datée.
_CLAMP_FR = re.compile(
    r"\[(\d{2}/\d{2}/\d{4})[^\]]*\] \[OTA_WATCH\] ⚠ (?:Calibration )?"
    r"([^:/]+?) / ([^:]+?) : prix calculé ([\d\s,]+?) "
    r"(sous le minimum|au-dessus du maximum) autorisé ([\d\s,]+)")
_CLAMP_EN = re.compile(
    r"\[(\d{2}/\d{2}/\d{4})[^\]]*\] \[OTA_WATCH\] ⚠ Calibration "
    r"([^:/]+?) / ([^:]+?): calculated price ₹?([\d,]+) "
    r"(below the minimum|above the maximum) ([\d,]+)")


def _collect_clamps(out: dict):
    """Dernier clamp min/max par chambre×OTA (queue de app.log + .bak).

    Clé TEXTE « OTA / chambre » — jamais un tuple : la première clé
    réelle (7 couples chez le client, 05/10 soir) a fait exploser le
    json.dumps du rapport (TypeError: keys must be str…) — sur le PC
    dev le dict était vide, d'où l'absence du crash dans les tests."""
    clamps = {}
    for name in ("app.log", "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        for line in _tail_lines(fp):
            m = _CLAMP_FR.search(line) or _CLAMP_EN.search(line)
            if not m:
                continue
            day, ota, room, calc, kind, bound = m.groups()
            fr = kind.startswith(("sous", "au-dessus"))
            clamps[f"{ota.strip()} / {room.strip()}"] = {
                "date": day,
                "ota": ota.strip(),
                "room": room.strip(),
                "calc": int(calc.replace(",", "").replace(" ", "")),
                "kind": "floor" if (kind.startswith("sous")
                                    or kind.startswith("below"))
                else "ceiling",
                "bound": int(bound.replace(",", "").replace(" ", "")),
                "fr": fr,
            }
    out["clamps"] = clamps
    out["clamp_count"] = len(clamps)


def _classify_push_line(line: str):
    for name, pat in _PUSH_CAUSES:
        if pat.search(line):
            return name
    return None


def _collect_pushes(out: dict, max_lines: int = 400):
    """Lignes d'envoi ([EXTRANET], push, correction) dans app.log —
    la source de vérité des échecs réels (D81 : lignes datées).
    D95 : lecture par la QUEUE (derniers 2 Mo) — pas le fichier entier."""
    lines_out, causes, last_by_cause = [], {}, {}
    for name in ("app.log", "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        all_lines = _tail_lines(fp)
        push_lines = [l.rstrip() for l in all_lines
                      if re.search(r"\[EXTRANET\]|push|AddBulkUpdate|"
                                   r"correction|BulkUpdate", l, re.I)]
        for l in push_lines:
            cause = _classify_push_line(l)
            if re.search(r"échec|failed|erreur|error|refus|expir", l, re.I):
                if cause:
                    causes[cause] = causes.get(cause, 0) + 1
                    last_by_cause[cause] = l[:160]
        lines_out.extend(push_lines[-max_lines:])
    out["recent_count"] = len(lines_out)
    out["recent_tail"] = lines_out[-40:]
    out["failure_causes"] = causes
    out["failure_last"] = last_by_cause
    _collect_clamps(out)


_ERR_SIG = re.compile(r"[0-9]+|\"[^\"]*\"|'[^']*'")


def _signature(line: str) -> str:
    """Normalise une ligne d'erreur pour grouper les récurrences."""
    return _ERR_SIG.sub("#", line)[:150]


def _collect_errors(out: dict, days: int = 7):
    """Exceptions/erreurs des journaux, groupées par signature.
    D95 : lecture par la QUEUE (derniers 2 Mo par fichier)."""
    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)
    groups = {}
    for name in ("ota_guard.log", "ota_guard.log.bak", "app.log",
                 "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        content = _tail_lines(fp)
        for i, l in enumerate(content):
            if not re.search(r"\b(ERROR|CRITICAL|Traceback|Exception)\b",
                             l, re.I):
                continue
            # Date de la ligne (JJ/MM/AAAA D81 ou ISO logging)
            m = re.search(r"(\d{2}/\d{2}/\d{4})|(\d{4}-\d{2}-\d{2})", l)
            if m:
                try:
                    raw = m.group(0)
                    dt = (datetime.datetime.strptime(raw, "%d/%m/%Y")
                          if "/" in raw else
                          datetime.datetime.fromisoformat(raw))
                    if dt < cutoff:
                        continue
                except ValueError:
                    pass
            sig = _signature(l)
            g = groups.setdefault(sig, {"count": 0, "last": "", "sample": ""})
            g["count"] += 1
            g["last"] = l.strip()[:160]
            if not g["sample"]:
                ctx = "".join(content[i:i + 4])[:400]
                g["sample"] = masker.mask_text(ctx)
    top = sorted(groups.items(), key=lambda kv: -kv[1]["count"])[:15]
    out["groups"] = [{"signature": k, **v} for k, v in top]
    out["total_grouped"] = len(groups)


def _collect_seasonal(out: dict):
    d = DATA_DIR / "seasonal_reports"
    if not d.exists():
        out["missing"] = True
        return
    reports = sorted(d.glob("verification_*.json"))
    out["count"] = len(reports)
    last = None
    if reports:
        try:
            env = _read_json(reports[-1])
            report = env.get("report") or ""
            last = {
                "file": reports[-1].name,
                "generated": env.get("generated", ""),
                "ok_count": report.count("✅"),
                "warn_count": report.count("⚠️"),
                "not_read": report.lower().count("non lue"),
            }
        except Exception as e:
            # D92 : citer la cause et tenter le .txt homonyme (le premier
            # rapport réel disait juste « illisible » sans explication).
            last = {"file": reports[-1].name,
                    "error": str(e)[:160]}
            txt_twin = reports[-1].with_suffix(".txt")
            try:
                if txt_twin.exists():
                    raw = txt_twin.read_text(encoding="utf-8",
                                             errors="replace")
                    last["ok_count"] = raw.count("✅")
                    last["warn_count"] = raw.count("⚠️")
                    last["not_read"] = raw.lower().count("non lue")
                    last["from_txt"] = True
            except Exception:
                pass
    out["last"] = last


def _collect_evidence(out: dict):
    from business.legal_ledger import evidence_dir
    root = evidence_dir()
    if not root.exists():
        out["missing"] = True
        return
    sessions = []
    for sd in sorted(root.glob("session-*")):
        counts, mono_ok, expected = {}, True, 0
        for fp in sorted(sd.glob("evidence-*.jsonl")):
            try:
                with open(fp, encoding="utf-8", errors="replace") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except ValueError:
                            mono_ok = False
                            continue
                        counts[rec.get("record_type", "?")] = \
                            counts.get(rec.get("record_type", "?"), 0) + 1
                        idx = rec.get("record_index")
                        if idx is not None and idx != expected:
                            mono_ok = False
                        expected = (idx if idx is not None else expected) + 1
            except Exception:
                pass
        sessions.append({"session": sd.name, "records": counts,
                         "index_monotonic": mono_ok})
    out["sessions"] = sessions[-10:]
    out["total_sessions"] = len(sessions)


def _collect_dbs(out: dict):
    import sqlite3
    for name in ("scraper.db", "otaguard.db"):
        fp = DATA_DIR / name
        entry = {}
        if not fp.exists():
            entry["missing"] = True
            out[name] = entry
            continue
        try:
            entry.update(_file_info(fp))
            entry["size_kb"] = round(entry.pop("size") / 1024, 1)
            con = sqlite3.connect(f"file:{fp}?mode=ro", uri=True)
            try:
                entry["integrity"] = (con.execute(
                    "PRAGMA integrity_check").fetchone() or ["?"])[0]
                tables = [r[0] for r in con.execute(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
                entry["tables"] = {t: con.execute(
                    f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
                    for t in tables[:12]}
            finally:
                con.close()
        except Exception as e:
            entry["error"] = str(e)[:120]
        out[name] = entry


def _collect_blackbox(out: dict):
    evts = recorder.recent_events(200)
    out["count"] = len(evts)
    out["tail"] = evts[-60:]
    crashes = [e for e in evts if e.get("kind") == "crash"]
    out["recent_crashes"] = crashes[-10:]


def _run_with_watchdog(fn, sec: dict, timeout: float = None):
    """Exécute une section dans un fil surveillé. Au-delà de
    SECTION_TIMEOUT secondes, la section est ABANDONNÉE (constatée
    « trop lente ») et la collecte continue — le rapport ne doit jamais
    rester bloqué sur « Analyse… » pendant des heures (constat
    propriétaire 05/10 : un rapport « a fait 2 h qui scan »). Le fil
    abandonné meurt en daemon, il ne fait que lire. NB : la limite est
    lue à l'EXÉCUTION (pas un défaut figé à la définition — piège qui
    rendait le timeout inconfigurable)."""
    if timeout is None:
        timeout = SECTION_TIMEOUT
    box = {"done": False}

    def _work():
        try:
            fn(sec)
        finally:
            box["done"] = True

    t = threading.Thread(target=_work, daemon=True,
                         name=f"diag-{fn.__name__}")
    t.start()
    t.join(timeout)
    return box["done"]


def collect_facts(progress_cb=None) -> dict:
    """Point d'entrée : ramène TOUS les faits. Ne lève jamais.

    D95 : chaque section est plafonnée à SECTION_TIMEOUT secondes —
    une section qui traîne (disque lent, 120 000 captures, verrou
    quelconque) est abandonnée et SIGNALÉE au lieu de geler le rapport.
    """
    facts = {"_meta": {"started": datetime.datetime.now().isoformat(
        timespec="seconds")}}
    steps = [
        ("identité", _collect_identity),
        ("environnement", _collect_environment),
        ("licence", _collect_license),
        ("configuration", _collect_config),
        ("calibrations", _collect_calibrations),
        ("envois", _collect_sends),
        ("pushes", _collect_pushes),
        ("erreurs", _collect_errors),
        ("saisons", _collect_seasonal),
        ("preuves", _collect_evidence),
        ("bases", _collect_dbs),
        ("boîte noire", _collect_blackbox),
    ]
    for label, fn in steps:
        key = label.replace(" ", "_")
        if progress_cb:
            try:
                progress_cb(label)
            except Exception:
                pass
        sec = facts.setdefault(key, {})
        finished = None
        try:
            finished = _run_with_watchdog(fn, sec)
        except Exception as e:
            facts[key] = {"collect_error": f"{type(e).__name__}: {e}"}
            continue
        if finished is False:
            facts[key] = {
                "collect_error": f"section abandonnée : trop lente "
                f"(> {SECTION_TIMEOUT:.0f} s) — disque occupé ou dossier "
                "de captures très volumineux",
            }
    facts["_meta"]["ended"] = datetime.datetime.now().isoformat(
        timespec="seconds")
    return facts
