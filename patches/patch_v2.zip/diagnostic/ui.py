"""Fenêtre du diagnostic interne (D91) — outil vendeur caché.

Lancement : main.py --diagnostic (bat dans le dossier diag/ côté source,
à côté de main.exe côté installé). Protégé par mot de passe vendeur (seul
son SHA-256 vit dans le code — jamais le mot de passe en clair).

Fenêtre autonome (thème sombre fixe, indépendante de l'app et de sa
licence) : progression de la collecte, rapport colorisé, boutons
📁 ouvrir le dossier / 📦 zip nettoyé / ⚖ comparer deux rapports.
"""
import hashlib
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

# SHA-256 du mot de passe vendeur (le mot de passe lui-même n'est JAMAIS
# stocké dans le code ni dans l'exe compilé).
_PASS_HASH = "74cf5ae15956c96fa52e9a1c985786a276cccb1cf85cf514c0c473806ebf87ce"

BG, FG = "#1e1e2e", "#cdd6f4"
ENTRY_BG, SEL_BG, ACCENT = "#313244", "#45475a", "#89b4fa"
GREEN, RED, ORANGE, YELLOW = "#a6e3a1", "#f38ba8", "#fab387", "#f9e2af"

_MAX_TRIES = 3


def _check_password(candidate: str) -> bool:
    return hashlib.sha256((candidate or "").strip().encode("utf-8")) \
        .hexdigest() == _PASS_HASH


class DiagnosticWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self._txt_path = None
        self._json_path = None
        self._facts = None
        self._findings = None
        self._report_text = ""
        self._queue = queue.Queue()
        root.title("🔎 OTA Guard — Diagnostic interne (outil vendeur)")
        root.configure(bg=BG)
        root.geometry("980x720")
        self._center(980, 720)
        try:
            from pathlib import Path
            ico = Path(__file__).resolve().parent.parent / "assets" \
                / "icon.ico"
            if ico.exists():
                root.iconbitmap(default=str(ico))
        except Exception:
            pass
        self._build_password_gate()

    def _center(self, w, h):
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")

    # ── Étape 1 : porte à mot de passe ─────────────────────────────────

    def _build_password_gate(self):
        self.gate = tk.Frame(self.root, bg=BG)
        self.gate.pack(fill="both", expand=True)
        tk.Label(self.gate, text="🔒", bg=BG, fg=ACCENT,
                 font=("Segoe UI", 34)).pack(pady=(60, 6))
        tk.Label(self.gate, text="Outil de diagnostic interne",
                 bg=BG, fg=FG, font=("Segoe UI", 13, "bold")).pack()
        tk.Label(self.gate,
                 text="Réservé au vendeur — mot de passe requis.",
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(pady=(2, 24))

        self.pw_var = tk.StringVar()
        ent = tk.Entry(self.gate, textvariable=self.pw_var, show="•",
                       bg=ENTRY_BG, fg=FG, insertbackground=FG,
                       relief="flat", justify="center",
                       font=("Segoe UI", 12), width=28,
                       highlightthickness=1,
                       highlightbackground=SEL_BG,
                       highlightcolor=ACCENT)
        ent.pack(ipady=6)
        ent.focus_set()
        ent.bind("<Return>", lambda e: self._try_password())

        self.gate_status = tk.Label(self.gate, text="", bg=BG, fg=FG,
                                    font=("Segoe UI", 9, "italic"))
        self.gate_status.pack(pady=10)
        tk.Button(self.gate, text="Déverrouiller", command=self._try_password,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=18, pady=6,
                  cursor="hand2").pack()
        self._tries = 0

    def _try_password(self):
        if _check_password(self.pw_var.get()):
            self.gate.destroy()
            self._build_main()
            self._start_analysis()
        else:
            self._tries += 1
            left = _MAX_TRIES - self._tries
            self.pw_var.set("")
            if left <= 0:
                self.root.destroy()
                return
            self.gate_status.config(
                text=f"❌ Mot de passe incorrect — {left} essai(s) restant(s)",
                fg=RED)

    # ── Étape 2 : écran principal ──────────────────────────────────────

    def _build_main(self):
        top = tk.Frame(self.root, bg=SEL_BG, pady=8, padx=12)
        top.pack(fill="x", side="top")
        tk.Label(top, text="🔎 Diagnostic interne OTA Guard",
                 bg=SEL_BG, fg=ACCENT,
                 font=("Segoe UI", 12, "bold")).pack(side="left")
        self.score_lbl = tk.Label(top, text="", bg=SEL_BG, fg=FG,
                                  font=("Segoe UI", 11, "bold"))
        self.score_lbl.pack(side="right")

        self.status_lbl = tk.Label(self.root, text="…", bg=BG, fg="#888888",
                                   font=("Segoe UI", 9))
        self.status_lbl.pack(fill="x", padx=12, pady=(8, 0))
        # Barre déterminée : l'analyse est rapide (~2 s) — une animation
        # indéterminée semblait figée dès la fin. Ici chaque section
        # collectée fait avancer le pourcentage, 0 → 100.
        self.progress = ttk.Progressbar(self.root, mode="determinate",
                                        maximum=100, length=940)
        self.progress.pack(fill="x", padx=12, pady=(2, 8))
        self.progress.configure(value=0)

        self.text = scrolledtext.ScrolledText(
            self.root, bg=ENTRY_BG, fg=FG, relief="flat",
            font=("Consolas", 9), wrap="word", state="disabled")
        self.text.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        for tag, color in (("ok", GREEN), ("warn", ORANGE), ("err", RED),
                           ("info", ACCENT), ("head", YELLOW),
                           ("dim", "#888888")):
            self.text.tag_configure(tag, foreground=color)
        self.text.tag_configure("head", font=("Consolas", 9, "bold"))

        bar = tk.Frame(self.root, bg=BG, pady=8)
        bar.pack(fill="x", side="bottom")
        for label, cmd in (
                ("📁 Ouvrir le dossier", self._open_folder),
                ("📦 Tout embarquer (.zip)", self._make_bundle),
                ("⚖ Comparer deux rapports", self._compare),
                ("✖ Fermer", self.root.destroy)):
            tk.Button(bar, text=label, command=cmd, bg=SEL_BG, fg=FG,
                      relief="flat", font=("Segoe UI", 9, "bold"),
                      padx=12, pady=5, cursor="hand2").pack(side="left",
                                                            padx=4)
        self._set_text("Analyse en cours…", [("info", )])

    # ── Thread de collecte ─────────────────────────────────────────────

    def _start_analysis(self):
        # 14 étapes : 12 sections de collecte + analyse + écriture
        self._steps_done = 0
        self._steps_total = 14
        self._t0 = time.time()
        self.progress.configure(value=0)

        def work():
            # D95 : une erreur imprévue ici tuait le fil en silence — la
            # fenêtre restait « Analyse… » à l'infini (constat
            # propriétaire : « un rapport a fait 2 h qui scan »). Toute
            # exception est désormais AFFICHÉE, jamais avalée.
            from diagnostic import collect, detective, report
            try:
                facts = collect.collect_facts(
                    progress_cb=lambda s: self._queue.put(("status", s)))
                self._queue.put(("status", "analyse causale"))
                findings = detective.analyze(facts)
                self._queue.put(("status", "écriture du rapport"))
                txt, jsn = report.save_report(facts, findings)
                self._queue.put(("done", (facts, findings, txt, jsn)))
            except Exception as e:
                import traceback
                self._queue.put(("error",
                                 f"{type(e).__name__}: {e}\n"
                                 + "".join(traceback.format_exc()[-800:])))

        threading.Thread(target=work, daemon=True,
                         name="diagnostic").start()
        self.root.after(150, self._poll)

    def _poll(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "status":
                    self._steps_done += 1
                    pct = min(99, self._steps_done * 100 // self._steps_total)
                    self.progress.configure(value=pct)
                    elapsed = int(time.time() - self._t0)
                    self.status_lbl.config(
                        text=f"Analyse ({pct} %, {elapsed} s) : "
                        f"{payload}…", fg="#888888")
                elif kind == "error":
                    self.progress.configure(value=100)
                    self.status_lbl.config(
                        text="❌ Erreur pendant l'analyse — le rapport "
                             "est incomplet", fg=RED)
                    self._set_text("❌ ERREUR PENDANT L'ANALYSE :\n\n"
                                   + str(payload))
                    return
                elif kind == "done":
                    self._on_done(*payload)
                    return
        except queue.Empty:
            pass
        self.root.after(150, self._poll)

    def _on_done(self, facts, findings, txt_path, jsn_path):
        self.progress.configure(value=100)
        from diagnostic.detective import health_score
        score, _ = health_score(findings)
        color = GREEN if score >= 85 else (ORANGE if score >= 60 else RED)
        self.score_lbl.config(text=f"Santé : {score}/100", fg=color)
        self.status_lbl.config(
            text=f"Rapport complet : {txt_path.name}", fg=color)
        self._facts, self._findings = facts, findings
        self._txt_path, self._json_path = txt_path, jsn_path
        with open(txt_path, encoding="utf-8") as f:
            self._report_text = f.read()
        self._render(self._report_text)

    # ── Rendu colorisé ─────────────────────────────────────────────────

    def _render(self, text: str):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        for line in text.splitlines():
            tag = "dim"
            if line.startswith(("✅",)):
                tag = "ok"
            elif line.startswith(("⚠️",)):
                tag = "warn"
            elif line.startswith(("❌",)):
                tag = "err"
            elif line.startswith(("ℹ️",)):
                tag = "info"
            elif line.startswith(("=", "─")) or line.isupper() or \
                    ("CONSTATS" in line or "FAITS" in line):
                tag = "head"
            self.text.insert("end", line + "\n", tag)
        self.text.configure(state="disabled")

    def _set_text(self, msg, tags=()):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("end", msg + "\n", *[t[0] for t in tags])
        self.text.configure(state="disabled")

    # ── Boutons ────────────────────────────────────────────────────────

    def _open_folder(self):
        try:
            from diagnostic.report import REPORTS_DIR
            REPORTS_DIR.mkdir(parents=True, exist_ok=True)
            import os
            os.startfile(str(REPORTS_DIR))
        except Exception as e:
            messagebox.showerror("Diagnostic", str(e), parent=self.root)

    def _make_bundle(self):
        if not self._txt_path:
            messagebox.showinfo("Diagnostic",
                                "Lancez d'abord l'analyse.", parent=self.root)
            return
        try:
            from diagnostic.bundle import make_bundle
            zp = make_bundle(self._txt_path, self._json_path, self._facts)
            if messagebox.askyesno(
                    "Diagnostic",
                    f"Zip prêt :\n{zp.name}\n\n"
                    "Ouvrir son dossier ?", parent=self.root):
                import os
                os.startfile(str(zp.parent))
        except Exception as e:
            messagebox.showerror("Diagnostic", str(e), parent=self.root)

    def _compare(self):
        try:
            a = filedialog.askopenfilename(
                title="Rapport A (ex. : PC python)",
                filetypes=[("Rapports JSON", "*.json")],
                parent=self.root)
            if not a:
                return
            b = filedialog.askopenfilename(
                title="Rapport B (ex. : PC installé)",
                filetypes=[("Rapports JSON", "*.json")],
                parent=self.root)
            if not b:
                return
            from pathlib import Path
            from diagnostic.bundle import compare_reports
            lines = compare_reports(Path(a), Path(b))
            self._render("\n".join(lines) +
                         "\n\n(Le rapport complet est réaffiché au prochain "
                         "lancement de l'analyse)")
        except Exception as e:
            messagebox.showerror("Diagnostic", str(e), parent=self.root)


def run():
    """Point d'entrée : fenêtre bloquante (main.py --diagnostic)."""
    root = tk.Tk()
    DiagnosticWindow(root)
    root.mainloop()


if __name__ == "__main__":  # permet aussi : python -m diagnostic.ui
    run()
