"""Détective (D91) — analyse causale des faits collectés.

Transforme les faits bruts (collect.py) en CONCLUSIONS traçables :
pour chaque problème détecté, une cause proposée et sa preuve (fichier,
ligne de journal, valeur exacte). C'est le cœur « pourquoi les prix ne
sont pas précis » de la demande du propriétaire.

Chaque constat (finding) :
  severity : ok | info | warn | error
  section  : regroupement pour le rapport
  title    : une ligne
  detail   : explication
  evidence : liste de preuves citées (chemins, valeurs, lignes de journal)

Le détective ne devine JAMAIS sans preuve : ce qui n'est pas démontrable
est rendu comme « non déterminable » avec la raison.
"""
from datetime import datetime

_TOL_PCT = 2.0        # tolérance par défaut (±2 %, même défaut que D74)


def _finding(severity, section, title, detail="", evidence=None):
    return {"severity": severity, "section": section, "title": title,
            "detail": detail, "evidence": evidence or []}


def _parse_iso(ts: str):
    try:
        return datetime.fromisoformat((ts or "").strip())
    except ValueError:
        return None


def _pct(a, b) -> float:
    """Écart relatif de a par rapport à b, en %."""
    if not a or not b:
        return 0.0
    return (a - b) * 100.0 / b


def _target_for(targets: dict, room: str, ota_name: str):
    """Cible pour un couple chambre×OTA — AVEC l'alias MakeMyTrip/Goibibo.

    Règle projet : les deux OTA partagent le MÊME inventaire et la cible
    vit sous la clé combinée « MakeMyTrip / Goibibo ». Le premier rapport
    réel disait « aucune cible définie » pour les 4 chambres Goibibo alors
    que les cibles existaient — cet unique résolveur répare ça (jamais
    dupliqué ailleurs dans le détective)."""
    per = targets.get(room) or {}
    if ota_name in per:
        return per[ota_name]
    low = (ota_name or "").lower()
    if "goibibo" in low or "makemytrip" in low:
        for k, v in per.items():
            lk = (k or "").lower()
            if "goibibo" in lk or "makemytrip" in lk:
                return v
    return None


def _rooms_with_target(targets: dict, ota_name: str) -> list:
    return [r for r, per in targets.items() if _target_for(targets, r, ota_name)]


def analyze_price_precision(facts: dict) -> list:
    """LE cœur : pour chaque OTA × chambre du dernier scan, verdict et cause."""
    out = []
    cfg = facts.get("configuration") or {}
    sends = (facts.get("envois") or {}).get("per_ota") or {}
    last_results = cfg.get("last_results") or {}
    targets = cfg.get("target_prices") or {}
    currency = cfg.get("currency") or ""
    min_gap = cfg.get("min_gap") or 0
    clamps = (facts.get("pushes") or {}).get("clamps") or {}

    if not last_results:
        return [_finding("warn", "prix",
                         "Aucun résultat de scan en mémoire",
                         "config.json n'a pas de ota_watch.last_results : "
                         "aucun scan n'a abouti depuis la dernière "
                         "installation/réinitialisation.",
                         ["config.json → ota_watch.last_results vide"])]

    # table ota_name → ota_id de fichier send_history
    try:
        from core.send_history import ota_id as _ota_id
    except Exception:
        def _ota_id(n):
            return (n or "").lower().replace(" ", "_")

    from datetime import date as _date
    today = _date.today()

    def _clamp_active(ota_name, room):
        """Clamp min/max vu sur ce couple, récent (≤ 2 j) → dict ou None.
        Clé TEXTE « OTA / chambre » (D96-bis : les tuples faisaient
        exploser le JSON du rapport)."""
        c = clamps.get(f"{ota_name} / {room}")
        if not c:
            return None
        try:
            d = datetime.strptime(c.get("date", ""), "%d/%m/%Y").date()
            if (today - d).days > 2:
                return None
        except ValueError:
            pass
        return c

    for ota_name, rooms in sorted(last_results.items()):
        if not isinstance(rooms, dict):
            continue
        hist = sends.get(_ota_id(ota_name)) or {}
        for room, displayed in sorted(rooms.items()):
            try:
                displayed = float(displayed)
            except (TypeError, ValueError):
                out.append(_finding("info", "prix",
                                    f"{ota_name} / {room} : prix illisible",
                                    f"Valeur brute : {displayed!r}"))
                continue
            target = _target_for(targets, room, ota_name)
            if not target:
                # La cible existe-t-elle sous un AUTRE nom de chambre
                # pour cette OTA ? Signature D86 : l'annonce expose sa
                # chambre sous un nom plus court que la config.
                other = _rooms_with_target(targets, ota_name)
                hint = ""
                if other:
                    hint = (f" ⚠ cette OTA a pourtant des cibles sous : "
                            f"{', '.join(other)} — la calibration "
                            f"range le prix sous un autre nom de "
                            f"chambre (voir section CALIBRATION).")
                out.append(_finding(
                    "info" if not other else "warn", "prix",
                    f"{ota_name} / {room} : affiché {displayed:.0f}"
                    f"{currency} — aucune cible définie",
                    "Aucun prix cible pour ce couple chambre×OTA dans "
                    "« Target prices per room » : aucun écart n'est donc "
                    "calculé, aucune correction ne sera déclenchée."
                    + hint,
                    ["config.json → ota_watch.target_prices"]))
                continue

            gap = _pct(displayed, target)
            base = (f"{ota_name} / {room} : affiché {displayed:.0f} "
                    f"vs cible {target:.0f}{currency} "
                    f"(écart {gap:+.1f} %)")
            ev = [f"config.json → ota_watch.last_results[{ota_name!r}]"
                  f"[{room!r}] = {displayed:.0f}",
                  f"config.json → target_prices[{room!r}]"
                  f" = {target:.0f}"]

            if abs(gap) <= _TOL_PCT:
                out.append(_finding("ok", "prix", base + " — DANS la tolérance"))
                continue

            # ── écart sous min_gap : AUCUN envoi n'est attendu (réglage
            # de l'utilisateur, pas un bug) — le 1er rapport criait
            # « AUCUN envoi » en erreur pour Expedia alors que l'écart
            # de 56 ₹ est volontairement sous le seuil de 100 ₹.
            if min_gap and abs(displayed - target) < min_gap:
                out.append(_finding(
                    "info", "prix", base + f" — sous le seuil min_gap "
                    f"({min_gap:.0f}{currency})",
                    f"L'écart ({abs(displayed - target):.0f}{currency}) est "
                    f"volontairement ignoré : min_gap = "
                    f"{min_gap:.0f}{currency} dans les réglages — aucune "
                    "correction ne sera déclenchée, c'est le comportement "
                    "attendu.",
                    ev + ["config.json → ota_watch.min_gap = "
                          f"{min_gap}"]))
                continue

            h = hist.get(room) or {}

            # ── CAUSE n°1 (vue sur le 1er rapport réel) : le garde-fou
            # min/max bloque le prix calculé → la cible est INATTEIGNABLE
            # tant que plancher/plafond et cible ne sont pas réconciliés.
            clamp = _clamp_active(ota_name, room)
            if clamp:
                what = ("plancher (minimum)" if clamp["kind"] == "floor"
                        else "plafond (maximum)")
                out.append(_finding(
                    "error", "prix", base + " — cible BLOQUÉE par le "
                    f"{what} autorisé",
                    f"Le logiciel a calculé qu'il faut envoyer "
                    f"{clamp['calc']:,} pour atteindre la cible, mais le "
                    f"{what} de {clamp['bound']:,} l'en empêche — le prix "
                    "est ramené au garde-fou et la cible ne sera JAMAIS "
                    "affichée. Décision à prendre : réconcilier la cible "
                    f"({target:.0f}) et le {what} ({clamp['bound']:,}) "
                    "pour cette chambre.",
                    ev + [f"app.log [{clamp['date']}] → prix calculé "
                          f"{clamp['calc']:,} "
                          f"{'sous le minimum' if clamp['kind'] == 'floor' else 'au-dessus du maximum'} "
                          f"{clamp['bound']:,} — ramené au garde-fou"]))
                continue

            # ── écart significatif : chercher la CAUSE ──────────────────
            ratio = h.get("ratio_median")
            last_sent = h.get("last_sent")
            pending_checks = h.get("pending_checks") or 0

            if h.get("pending") and pending_checks > 0:
                out.append(_finding(
                    "warn", "prix", base + " — envoi en attente de "
                    "répercussion",
                    f"Un envoi est parti ({last_sent}) mais l'OTA affiche "
                    f"toujours l'ancien prix depuis {pending_checks} scan(s). "
                    "Le Channel Manager a accepté l'envoi ; l'OTA ne l'a pas "
                    "(encore) répercuté — renvoyer n'apprendrait rien "
                    "(send_history : compteur checks).",
                    ev + [f"send_history → checks = {pending_checks}, "
                          f"depuis {h.get('pending_since')}"]))
                continue

            if ratio and last_sent:
                expected = last_sent * ratio
                dev = _pct(displayed, expected)
                if abs(dev) <= 8.0:
                    # MÊME formule que l'app (ancre fraîche D35/D38) :
                    # envoi = dernier_envoyé × cible ÷ affiché.
                    needed = int(round(last_sent * target / displayed))
                    out.append(_finding(
                        "warn", "prix", base + " — cohérent avec le ratio "
                        f"de l'OTA (×{ratio:.2f})",
                        f"L'affichage est EXACTEMENT ce que l'OTA fait "
                        f"habituellement de l'envoi : {last_sent} envoyé → "
                        f"{expected:.0f} attendu, {displayed:.0f} affiché. "
                        f"La lecture est BONNE — l'écart vient du dernier "
                        f"envoi, pas d'un bug. Pour afficher {target:.0f}, "
                        f"l'app calculerait un envoi ≈ {needed:,}.",
                        ev + [f"send_history → ratio médian affiché/envoyé "
                              f"= {ratio}", f"dernier envoi = {last_sent}"]))
                    continue
                out.append(_finding(
                    "error", "prix", base + " — INCOHÉRENT avec le ratio "
                    f"connu (×{ratio:.2f})",
                    f"Avec {last_sent} envoyé, cette OTA affiche "
                    f"habituellement {expected:.0f} — or elle affiche "
                    f"{displayed:.0f} ({dev:+.1f} % d'écart au modèle). "
                    "Suspects : promotion active non extraite, devise non "
                    "convertie, ou lecture d'une autre chambre/annonce "
                    "(voir la section calibrations).",
                    ev + [f"send_history → ratio médian = {ratio}"]))
                continue

            if last_sent:
                out.append(_finding(
                    "warn", "prix", base + " — dernier envoi jamais mesuré",
                    f"Dernier envoi : {last_sent}, mais aucune mesure "
                    "confirmée (envoyé→affiché) n'existe encore pour cette "
                    "chambre : impossible de dire si l'écart est le ratio "
                    "normal de l'OTA ou un problème. Le prochain scan qui "
                    "voit le prix bouger créera la mesure.",
                    ev + ["send_history → 0 mesure confirmée"]))
                continue

            out.append(_finding(
                "error", "prix", base + " — AUCUN envoi jamais enregistré",
                "send_history n'a trace d'aucun envoi pour ce couple "
                "chambre×OTA : l'écart ne peut pas se corriger tout seul "
                "et la boucle n'a rien à apprendre. Suspects : pushes "
                "jamais déclenchés, refus de verrou, ou chambre/OTA "
                "récemment ajoutée.",
                ev + ["send_history → rien pour cette chambre"]))
    return out


def analyze_calibrations(facts: dict) -> list:
    """Ambiguïtés de calibration — l'espèce D43/D86 détectée à l'avance."""
    out = []
    cfg = facts.get("configuration") or {}
    cal = facts.get("calibrations") or {}
    inventory = cfg.get("room_inventory") or {}
    inv_names = set(inventory.keys())
    targets = cfg.get("target_prices") or {}
    last_results = cfg.get("last_results") or {}

    if cal.get("invalid_files"):
        out.append(_finding("error", "calibration",
                            f"{len(cal['invalid_files'])} fichier(s) de "
                            "calibration illisible(s)",
                            "Un JSON corrompu = les aliases qu'il portait "
                            "sont perdus pour les scans.",
                            [f"calibration_data_{f}" for f in
                             cal["invalid_files"][:5]]))

    # Noms de chambres imbriqués (« Double Room » ⊂ « Double Room with
    # Balcony ») : le matching flou peut éclipser la cible (D86).
    names = sorted(inv_names)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if a.lower() in b.lower() or b.lower() in a.lower():
                out.append(_finding(
                    "info", "calibration",
                    f"Noms de chambres imbriqués : « {a} » / « {b} »",
                    "Le match parfait du nom court peut éclipser le nom "
                    "long au moment d'associer la cible (bug D86 du "
                    "23/09). Le code corrige par cible OTA, mais toute "
                    "nouvelle OTA doit être vérifiée."))

    # Alias pointant hors inventaire
    for p in cal.get("profiles") or []:
        for alias, room in (p.get("room_aliases") or {}).items():
            if inv_names and room not in inv_names:
                out.append(_finding(
                    "warn", "calibration",
                    f"{p.get('ota')} : l'alias mène à une chambre inconnue "
                    f"(« {room} »)",
                    "La calibration associe ce que l'OTA affiche à une "
                    "chambre qui n'existe plus dans l'inventaire — les "
                    "prix seront rangés nulle part.",
                    [f"{p.get('file')} → room_aliases[{alias!r}] = {room!r}",
                     f"inventaire = {sorted(inv_names)}"]))

    # Chambre rapportée par le scan MAIS non revendiquée par la
    # calibration de ce profil, alors que cette OTA a des cibles définies
    # (sous un autre nom) : signature exacte du bug D86 — l'annonce
    # expose sa chambre sous un nom plus court, le prix se range sous
    # « Double Room » pendant que la cible vit sous « Double Room with
    # Balcony » → correction jamais déclenchée.
    for ota_cfg, rooms in last_results.items():
        ota_key = (ota_cfg or "").lower().replace(" ", "_")
        has_targets = any(ota_cfg in (per or {})
                          for per in targets.values())
        if not has_targets:
            continue
        for p in cal.get("profiles") or []:
            if ota_key not in (p.get("ota") or "").lower():
                continue
            alias_rooms = set((p.get("room_aliases") or {}).values())
            if not alias_rooms:
                continue
            for room in rooms:
                if room not in alias_rooms:
                    out.append(_finding(
                        "warn", "calibration",
                        f"{ota_cfg} rapporte « {room} » mais sa "
                        "calibration attend d'autres chambres",
                        "Le scan range le prix de cette annonce sous une "
                        "chambre que la calibration de ce profil ne "
                        "revendique pas (l'annonce expose sa chambre sous "
                        "un nom plus court — mécanisme du bug D86 du "
                        "23/09). Le correcteur contourne par cible OTA "
                        "(fix D86 : piste prioritaire = candidat portant "
                        "une cible pour CETTE OTA), mais l'affichage "
                        "montre le prix sous l'autre nom et toute OTA "
                        "nouvelle devra être revérifiée.",
                        [f"{p.get('file')} → aliases = "
                         f"{sorted(alias_rooms)}",
                         f"last_results[{ota_cfg!r}] contient {room!r}",
                         f"cibles de cette OTA = "
                         f"{[r for r, per in targets.items() if ota_cfg in (per or {})]}"]))
    return out


def analyze_operations(facts: dict) -> list:
    """Verrous, échecs d'envoi, erreurs récurrentes, fraîcheur du scan."""
    out = []
    env = facts.get("environnement") or {}
    pushes = facts.get("pushes") or {}
    errors = facts.get("erreurs") or {}
    cfg = facts.get("configuration") or {}

    # Verrou mono-instance résiduel
    if (env.get("data_files") or {}).get("instance.lock"):
        age = env["data_files"]["instance.lock"].get("age_h")
        out.append(_finding(
            "info", "opérations",
            f"Verrou mono-instance présent ({age} h)",
            "Normal si l'app tourne ; résiduel si elle est fermée "
            "(arrêt brutal) — il est ignoré quand le PID est mort."))

    # Échecs d'envoi classés
    causes = pushes.get("failure_causes") or {}
    if causes:
        worst = max(causes.values())
        sev = "error" if worst >= 5 else "warn"
        detail = "Causes comptées dans app.log (app.log.bak inclus) :\n" + \
            "\n".join(f"  • {k} : {v}" for k, v in
                      sorted(causes.items(), key=lambda kv: -kv[1]))
        ev = [pushes.get("failure_last", {}).get(k, "")[:140]
              for k in sorted(causes, key=lambda k: -causes[k])]
        out.append(_finding(sev, "opérations",
                            f"{sum(causes.values())} ligne(s) d'échec "
                            "d'envoi dans les journaux", detail,
                            [e for e in ev if e]))

    # Erreurs récurrentes groupées
    for g in (errors.get("groups") or [])[:5]:
        if g.get("count", 0) >= 3:
            out.append(_finding(
                "warn", "opérations",
                f"Erreur récurrente ×{g['count']} : {g.get('last', '')[:90]}",
                "Signature normalisée : " + g.get("signature", ""),
                [g.get("sample", "")[:300]]))

    # Fraîcheur du scan
    st = _parse_iso(cfg.get("last_scan_time") or "")
    if st:
        age_h = (datetime.now() - st).total_seconds() / 3600
        if age_h > 48:
            out.append(_finding(
                "warn", "opérations",
                f"Dernier scan il y a {age_h:.0f} h",
                "Les prix affichés en mémoire ont plus de 2 jours : "
                "toutes les décisions prises dessus sont périmées.",
                [f"config.json → last_scan_time = {cfg.get('last_scan_time')}"]))
        else:
            out.append(_finding("ok", "opérations",
                                f"Dernier scan il y a {age_h:.1f} h"))

    # OTA surveillées
    actives = [o["name"] for o in cfg.get("otas") or [] if o.get("active")]
    if cfg and not actives:
        out.append(_finding("error", "opérations",
                            "AUCUNE OTA surveillée (toutes inactives)",
                            "Aucun scan ne rapportera de prix.",
                            ["config.json → ota_watch.otas"]))
    elif cfg:
        out.append(_finding("ok", "opérations",
                            f"{len(actives)} OTA surveillée(s) : "
                            + ", ".join(actives)))

    # Mesures bloquées (OTA ne répercute pas)
    for ota_id, rooms in ((facts.get("envois") or {}).get("per_ota")
                          or {}).items():
        for room, h in rooms.items():
            if isinstance(h, dict) and (h.get("pending_checks") or 0) >= 5:
                out.append(_finding(
                    "warn", "opérations",
                    f"{ota_id} / {room} : {h['pending_checks']} scans sans "
                    "répercution",
                    "Le CM a accepté l'envoi mais l'OTA affiche toujours "
                    "l'ancien prix — les envois sont suspendus pour cette "
                    "chambre (garde-fou send_history).",
                    [f"send_history_{ota_id}.json → checks = "
                     f"{h['pending_checks']}"]))

    # Environnement
    if env and env.get("cdp_9222") is False:
        out.append(_finding(
            "warn", "opérations",
            "Port CDP 9222 fermé — navigateur non détecté",
            "Brave n'est pas lancé avec le débogage distant (ou est "
            "fermé) : les scans et l'Extranet Direct ne peuvent pas "
            "fonctionner.",
            ["test de connexion locale 127.0.0.1:9222"]))
    if env and env.get("captures", {}).get("age_h") is not None and \
            env["captures"]["age_h"] > 48:
        out.append(_finding(
            "warn", "opérations",
            f"Captures VAE vieilles de {env['captures']['age_h']:.0f} h",
            "Le listener n'a rien capturé depuis plus de 2 jours.",
            [f"captures → {env['captures'].get('count')} fichiers, "
             f"dernier {env['captures'].get('newest')}"]))
    return out


def analyze_integrity(facts: dict) -> list:
    """Self-tests : JSON valides, bases saines, preuves, licence."""
    out = []
    cfg = facts.get("configuration") or {}
    env = facts.get("environnement") or {}
    lic = facts.get("licence") or {}
    dbs = facts.get("bases") or {}
    ev = facts.get("preuves") or {}

    if cfg.get("invalid_json"):
        out.append(_finding("error", "intégrité",
                            "config.json ILLISIBLE",
                            "L'app est repartie sur la sauvegarde .bak ou "
                            "une config vide — tous les réglages peuvent "
                            "avoir sauté.",
                            [cfg.get("invalid_json", "")]))
    elif cfg.get("valid_json"):
        out.append(_finding("ok", "intégrité", "config.json : JSON valide"))
        if not (env.get("data_files") or {}).get("config.json.bak"):
            out.append(_finding("info", "intégrité",
                                "Pas de config.json.bak",
                                "La sauvegarde n'existe pas encore (créée "
                                "au premier save après ce fichier)."))

    for name, entry in dbs.items():
        if not isinstance(entry, dict):
            continue
        if entry.get("missing"):
            out.append(_finding("info", "intégrité", f"{name} absent"))
        elif entry.get("integrity") == "ok":
            out.append(_finding("ok", "intégrité",
                                f"{name} : intégrité SQLite OK "
                                f"({entry.get('size_kb', '?')} Ko)"))
        else:
            out.append(_finding("error", "intégrité",
                                f"{name} : intégrité DÉFAILLANTE",
                                str(entry.get("integrity") or
                                    entry.get("error"))))

    if ev.get("sessions"):
        bad = [s for s in ev["sessions"] if not s.get("index_monotonic")]
        if bad:
            out.append(_finding(
                "warn", "intégrité",
                f"{len(bad)} session(s) du journal ⚖ avec index non "
                "monotone",
                "Des enregistrements manquent ou sont dupliqués dans ces "
                "sessions — valeur probatoire à vérifier.",
                [s["session"] for s in bad[:3]]))
        else:
            out.append(_finding("ok", "intégrité",
                                f"Journal ⚖ : {ev.get('total_sessions')} "
                                "session(s), index monotones"))

    status = lic.get("status") or "?"
    if "expir" in status or "invalide" in status or "révoqué" in status:
        out.append(_finding("warn", "intégrité",
                            f"Licence : {status}",
                            "L'outil de diagnostic fonctionne quand même "
                            "(outil vendeur).",
                            [f"zone={lic.get('zone')} "
                             f"max_rooms={lic.get('max_rooms')}"]))
    else:
        out.append(_finding("ok", "intégrité", f"Licence : {status}",
                            "", [f"zone={lic.get('zone')} "
                                 f"max_rooms={lic.get('max_rooms')}"]))

    bb = facts.get("boîte_noire") or {}
    if bb.get("recent_crashes"):
        out.append(_finding(
            "warn", "intégrité",
            f"{len(bb['recent_crashes'])} crash(s) récent(s) en boîte "
            "noire",
            "Exceptions non gérées attrapées par l'enregistreur de vol.",
            [(c.get("data") or {}).get("exc", "")[:200]
             for c in bb["recent_crashes"][:3]]))
    return out


def analyze(facts: dict) -> list:
    """Tous les constats, ordre du rapport."""
    out = []
    out.extend(analyze_price_precision(facts))
    out.extend(analyze_calibrations(facts))
    out.extend(analyze_operations(facts))
    out.extend(analyze_integrity(facts))
    for key, sec in facts.items():
        if key.startswith("_"):
            continue
        if isinstance(sec, dict) and sec.get("collect_error"):
            out.append(_finding("error", "collecte",
                                f"Section « {key} » non collectée",
                                sec.get("collect_error")))
    return out


def health_score(findings: list):
    """Score global 0-100 + par section. Chaque error -15, warn -5."""
    score = 100
    sections = {}
    for f in findings:
        sev = f.get("severity")
        penalty = {"error": 15, "warn": 5}.get(sev, 0)
        score -= penalty
        s = f.get("section", "?")
        sections.setdefault(s, 100)
        sections[s] -= penalty
    score = max(0, min(100, score))
    sections = {k: max(0, min(100, v)) for k, v in sections.items()}
    return score, sections
