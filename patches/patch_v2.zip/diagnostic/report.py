"""Assemblage du rapport (D91) — texte lisible + JSON structuré.

Le .txt est ce que le propriétaire lit et transmet tel quel ; le .json
sert à la comparaison de deux rapports (bundle.compare_reports).
Écrits dans data/diagnostics/rapport_<horodatage>.{txt,json}.
"""
import datetime
import json

from core.paths import DATA_DIR

from diagnostic.detective import health_score

REPORTS_DIR = DATA_DIR / "diagnostics"

_SEV_ICON = {"ok": "✅", "info": "ℹ️", "warn": "⚠️", "error": "❌"}
_SECTION_ORDER = ["prix", "calibration", "opérations", "intégrité",
                  "collecte"]


def _line(v):
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def _fmt_kb(n):
    return f"{n} Ko"


def build_text(facts: dict, findings: list) -> str:
    score, sections = health_score(findings)
    L = []
    add = L.append

    add("=" * 72)
    add("OTA GUARD — RAPPORT DE DIAGNOSTIC INTERNE")
    add("=" * 72)
    ident = facts.get("identité") or {}
    add(f"Généré le      : {ident.get('generated_at')}")
    add(f"Version        : {ident.get('app_version')}  "
        f"({ident.get('mode')})")
    add(f"Machine        : {ident.get('machine')} — "
        f"utilisateur {ident.get('user')}")
    add(f"Dossier données: {ident.get('data_dir')}")
    add(f"SCORE DE SANTÉ : {score}/100")
    add("")

    # ── Constats (le cœur) ─────────────────────────────────────────────
    add("─" * 72)
    add("1. CONSTATS (constatés par le détective, avec preuves)")
    add("─" * 72)
    by_sec = {}
    for f in findings:
        by_sec.setdefault(f.get("section", "?"), []).append(f)
    rank = {"error": 0, "warn": 1, "info": 2, "ok": 3}
    sec_num = 2
    for sec in _SECTION_ORDER + [s for s in by_sec if s not in
                                 _SECTION_ORDER]:
        items = by_sec.get(sec)
        if not items:
            continue
        add("")
        add(f"  [{sec.upper()}] — santé {sections.get(sec, 100)}/100")
        add("  " + "." * 60)
        for f in sorted(items, key=lambda x: rank.get(x.get("severity"), 9)):
            add(f"  {_SEV_ICON.get(f['severity'], '?')} {f['title']}")
            if f.get("detail"):
                for dl in f["detail"].splitlines():
                    add(f"       {dl}")
            for ev in f.get("evidence") or []:
                add(f"       ↳ preuve : {ev}")
        sec_num += 1

    # ── Faits bruts condensés ──────────────────────────────────────────
    add("")
    add("─" * 72)
    add("2. FAITS BRUTS")
    add("─" * 72)

    lic = facts.get("licence") or {}
    add("")
    add(f"  Licence : {lic.get('status', '?')} — zone "
        f"{lic.get('zone', '?')}, max_rooms {lic.get('max_rooms', '?')}")

    cfg = facts.get("configuration") or {}
    add(f"  Dernier scan : {cfg.get('last_scan_time') or 'jamais'}")
    add(f"  Transport CM : {cfg.get('transport', '?')} "
        f"(carte {cfg.get('cm_map') or 'défaut'})")
    add(f"  Domaine CM   : {cfg.get('cm_domain') or '?'}")
    add(f"  Devise       : {cfg.get('currency') or '?'}")
    add(f"  Auto-correct : {cfg.get('auto_correct')} — intervalle "
        f"{cfg.get('scan_interval_h')} h")
    add("  OTA surveillées :")
    for o in cfg.get("otas") or []:
        add(f"    [{'x' if o.get('active') else ' '}] {o.get('name')} — "
            f"{o.get('domain')}")
    add("  Cibles :")
    for room, per in (cfg.get("target_prices") or {}).items():
        for ota, price in per.items():
            disp = ((cfg.get("last_results") or {}).get(ota) or {}) \
                .get(room)
            add(f"    {room} × {ota} : cible {_line(price)}, affiché "
                f"{_line(disp)}")

    cal = facts.get("calibrations") or {}
    add("  Calibrations :")
    for p in cal.get("profiles") or []:
        add(f"    {p.get('ota')} : aliases="
            f"{json.dumps(p.get('room_aliases'), ensure_ascii=False)}, "
            f"calibrée {p.get('calibrated_at') or '?'}, "
            f"{p.get('prices_learned')} prix appris")

    sends = (facts.get("envois") or {}).get("per_ota") or {}
    add("  Historique d'envois (par chambre) :")
    for ota_id, rooms in sorted(sends.items()):
        for room, h in rooms.items():
            if not isinstance(h, dict):
                continue
            add(f"    {ota_id} × {room} : {h.get('confirmed')} mesure(s), "
                f"dernier envoi {h.get('last_sent')}, ratio "
                f"{h.get('ratio_median')}"
                + (f", EN ATTENTE ({h.get('pending_checks')} scans)"
                   if h.get("pending") else ""))

    env = facts.get("environnement") or {}
    add("  Environnement :")
    add(f"    Port CDP 9222 : "
        f"{'OUVERT (navigateur détecté)' if env.get('cdp_9222') else 'FERMÉ'}")
    caps = env.get("captures") or {}
    add(f"    Captures VAE : {caps.get('count', 0)} fichiers, fraîcheur "
        f"{caps.get('age_h', '?')} h")
    add(f"    Disque libre : {env.get('disk_free_gb', '?')} Go")
    files = env.get("data_files") or {}
    add("    Fichiers clés :")
    for n in ("config.json", "config.json.bak", "secrets.json",
              "scraper.db", "license.dat", "app.log"):
        if n in files:
            add(f"      {n} : {_fmt_kb(files[n].get('size_kb', '?'))}, "
                f"modifié il y a {files[n].get('age_h')} h")

    seas = facts.get("saisons") or {}
    if seas.get("last"):
        s = seas["last"]
        if s.get("error"):
            add(f"  Dernier rapport saisonnier : {s.get('file')} — "
                f"ILLISIBLE ({s.get('error')})"
                + (" ; stats lues via le .txt jumeau"
                   if s.get("from_txt") else ""))
        else:
            add(f"  Dernier rapport saisonnier : "
                f"{s.get('file')} "
                f"({s.get('ok_count')} ✅ / "
                f"{s.get('warn_count')} ⚠️)")

    pushes = facts.get("pushes") or {}
    if pushes.get("failure_causes"):
        add("  Échecs d'envoi comptés : "
            + json.dumps(pushes["failure_causes"], ensure_ascii=False))
    if pushes.get("clamp_count"):
        add(f"  Garde-fous min/max actifs (2 j) : "
            f"{pushes['clamp_count']} chambre×OTA clampé(s) — voir "
            "section PRIX")

    errors = facts.get("erreurs") or {}
    add(f"  Erreurs groupées (7 j) : {errors.get('total_grouped', 0)} "
        "signatures distinctes")

    # ── Fin ────────────────────────────────────────────────────────────
    add("")
    add("─" * 72)
    add("Fin du rapport — généré par l'outil de diagnostic interne OTA "
        "Guard (D91).")
    add("Aucun secret ne figure dans ce rapport (masquage automatique).")
    add("=" * 72)
    return "\n".join(L)


def build_json(facts: dict, findings: list) -> dict:
    score, sections = health_score(findings)
    return {
        "schema": "otaguard-diagnostic/1",
        "generated_at": datetime.datetime.now().isoformat(
            timespec="seconds"),
        "score": score,
        "section_scores": sections,
        "findings": findings,
        # faits sans les gros blocs de lignes de journal
        "facts_lite": _slim_facts(facts),
    }


def _slim_facts(facts: dict) -> dict:
    slim = {}
    for k, v in facts.items():
        if not isinstance(v, dict):
            continue
        v2 = {kk: vv for kk, vv in v.items()
              if kk not in ("recent_tail", "tail", "_sanitized_full")}
        slim[k] = v2
    return slim


def _jsonable(obj):
    """Blindage D96-bis : convertit tout ce que json.dumps refuse —
    clés tuple (le crash réel du client : « keys must be str, int,
    float, bool or None, not tuple »), sets, dates, objets quelconques.
    Le rapport JSON ne doit JAMAIS planter sur la forme des données."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, (str, int, float, bool)) or k is None:
                kk = k
            elif isinstance(k, tuple):
                kk = " / ".join(str(x) for x in k)
            else:
                kk = str(k)
            out[kk] = _jsonable(v)
        return out
    if isinstance(obj, (list, tuple, set)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return str(obj)


def save_report(facts: dict, findings: list):
    """Écrit rapport .txt + .json ; retourne (txt_path, json_path).
    Le .json passe par _jsonable : aucune donnée collectée ne peut plus
    casser la sérialisation (le .txt est écrit AVANT — mais un rapport
    sans .json casse la comparaison ⚖ et le score)."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    txt = REPORTS_DIR / f"rapport_{ts}.txt"
    jsn = REPORTS_DIR / f"rapport_{ts}.json"
    txt.write_text(build_text(facts, findings), encoding="utf-8")
    jsn.write_text(json.dumps(_jsonable(build_json(facts, findings)),
                              ensure_ascii=False, indent=1), encoding="utf-8")
    return txt, jsn
