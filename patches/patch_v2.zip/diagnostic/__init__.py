"""Diagnostic interne OTA Guard (D91) — outil vendeur caché.

Trois niveaux :
- recorder : boîte noire JSONL permanente (chaque événement de l'app) ;
- collect  : lecture seule de TOUS les faits sur disque ;
- detective + report : analyse causale, rapport complet, score de santé.

Règles absolues du module :
- JAMAIS de secret en clair (masker appliqué partout, secrets.json jamais
  ouvert) ;
- 100 % lecture seule sur les données (seule écriture : dossier
  data/diagnostics/ et data/blackbox/) ;
- aucune requête réseau vers une OTA (R1) — le seul test réseau est la
  connexion locale au port CDP 9222 du navigateur de l'utilisateur ;
- tout échec est toléré : l'outil ne doit jamais faire planter l'app.
"""
