"""Boîte noire OTA Guard (D91) — enregistreur de vol permanent.

PRINCIPE : « le moindre bug qui passe doit laisser une trace datée et
structurée ». Trois flux capturés, tous déjà existants — on ne touche
aucun module métier :

1. logging Python (handler racine) : tout ce que l'app écrit dans
   ota_guard.log, y compris les exceptions avec exc_info ;
2. business.app_log (callback enregistré) : le journal métier daté D81
   (scans, envois [EXTRANET], verdicts) — il n'utilise PAS le module
   logging, d'où le crochet dédié via son API register_callback ;
3. excepthooks (sys + threading) : tout crash non géré, en chaînant
   sur le hook précédent (activity_log D39 en pose un aussi).

Écriture : data/blackbox/blackbox_AAAA-MM-JJ.jsonl, un fichier par jour,
rétention KEEP_DAYS jours. Échec d'écriture = désactivation silencieuse
après 3 tentatives : la boîte noire ne doit JAMAIS faire planter l'app.

Toujours masqué (masker.mask_dict) : rien de sensible ne peut y entrer.
"""
import datetime
import json
import logging
import os
import sys
import threading
import traceback

from core.paths import DATA_DIR

BLACKBOX_DIR = DATA_DIR / "blackbox"
KEEP_DAYS = 7          # rétention des fichiers quotidiens
_MAX_DAY_BYTES = 5 * 1024 * 1024   # garde-fou anti-emballement
_FAILS_BEFORE_OFF = 3

_lock = threading.Lock()
_state = {"installed": False, "fails": 0, "off": False, "day": ""}


def _today() -> str:
    return datetime.date.today().isoformat()


def _file_for(day: str):
    return BLACKBOX_DIR / f"blackbox_{day}.jsonl"


def event(kind: str, level: str = "info", data: dict | None = None):
    """Ajoute un événement à la boîte noire. Ne lève JAMAIS."""
    if _state["off"]:
        return
    try:
        payload = {
            "ts": datetime.datetime.now().isoformat(timespec="seconds"),
            "kind": str(kind)[:80],
            "level": str(level)[:12],
            "thread": threading.current_thread().name[:40],
            "data": data or {},
        }
        from diagnostic.masker import mask_dict
        line = json.dumps(mask_dict(payload), ensure_ascii=False)
        with _lock:
            day = _today()
            fp = _file_for(day)
            if not fp.exists():
                BLACKBOX_DIR.mkdir(parents=True, exist_ok=True)
            elif fp.stat().st_size > _MAX_DAY_BYTES and level != "error":
                return  # journée saturée : seules les erreurs passent encore
            with open(fp, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            if day != _state["day"]:
                _state["day"] = day
                _purge_old()
    except Exception:
        _state["fails"] += 1
        if _state["fails"] >= _FAILS_BEFORE_OFF:
            _state["off"] = True


def _purge_old():
    """Supprime les fichiers quotidiens au-delà de KEEP_DAYS. Jamais fatal."""
    try:
        cutoff = datetime.date.today() - datetime.timedelta(days=KEEP_DAYS)
        for fp in BLACKBOX_DIR.glob("blackbox_*.jsonl"):
            try:
                day = fp.stem.replace("blackbox_", "")
                if datetime.date.fromisoformat(day) < cutoff:
                    fp.unlink(missing_ok=True)
            except ValueError:
                pass
    except Exception:
        pass


def recent_events(n: int = 300) -> list:
    """Les n derniers événements (aujourd'hui + hier), les plus récents
    en dernier. Lecture tolérante aux lignes incomplètes — et par la
    QUEUE du fichier (derniers 256 Ko, D95) : un journal de journée
    saturée (5 Mo) ne doit pas ralentir le diagnostic."""
    out = []
    for day in (_today(),
                (datetime.date.today() - datetime.timedelta(days=1)).isoformat()):
        fp = _file_for(day)
        try:
            if not fp.exists():
                continue
            with open(fp, "rb") as f:
                import os as _os
                _size = fp.stat().st_size
                _sought = _size > 262_144
                if _sought:
                    f.seek(-262_144, _os.SEEK_END)
                raw = f.read()
            text = raw.decode("utf-8", "replace")
            if _sought and "\n" in text:
                text = text.split("\n", 1)[1]   # ligne partielle du début
            elif not _sought and text.startswith("\ufeff"):
                text = text.lstrip("\ufeff")
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
        except Exception:
            pass
    return out[-n:]


# ── Installation (appelée une fois au démarrage normal de l'app) ────────────

class _BlackboxHandler(logging.Handler):
    """Relais logging → boîte noire. Aucun logging interne (récursion)."""

    def emit(self, record: logging.LogRecord):
        try:
            if record.levelno < logging.INFO:
                return
            data = {"logger": record.name, "msg": record.getMessage()}
            if record.exc_info:
                data["exc"] = "".join(
                    traceback.format_exception_only(*record.exc_info[:2])).strip()
            event("log", record.levelname.lower(), data)
        except Exception:
            pass


def _make_excepthook(previous):
    def _hook(typ, val, tb):
        try:
            event("crash", "error", {
                "exc": "".join(traceback.format_exception(typ, val, tb)
                               [-6:]).strip(),
            })
        finally:
            if previous is not None:
                try:
                    previous(typ, val, tb)
                except Exception:
                    pass
    return _hook


def _make_thread_excepthook(previous):
    def _hook(args):
        try:
            event("crash", "error", {
                "thread": getattr(args.thread, "name", "?"),
                "exc": "".join(traceback.format_exception(
                    args.exc_type, args.exc_value, args.exc_traceback)
                    [-6:]).strip(),
            })
        finally:
            if previous is not None:
                try:
                    previous(args)
                except Exception:
                    pass
    return _hook


def install():
    """Branche la boîte noire sur les trois flux. Idempotent."""
    with _lock:
        if _state["installed"]:
            return
        _state["installed"] = True

    # 1. logging Python
    try:
        h = _BlackboxHandler()
        h.setLevel(logging.INFO)
        logging.getLogger().addHandler(h)
    except Exception:
        pass

    # 2. journal métier app_log (D81) — ne passe pas par logging
    try:
        from business.app_logger import app_log, register_callback

        def _on_app_line(line: str, level: str):
            event("app_log", level if level in
                  ("warn", "error", "ok", "price", "scan", "browser",
                   "head", "info") else "info",
                  {"line": line.rstrip()})

        register_callback(_on_app_line)
        del app_log  # importé uniquement pour expliciter la dépendance
    except Exception:
        pass

    # 3. crashes non gérés (chaînés sur l'existant — activity_log D39)
    try:
        sys.excepthook = _make_excepthook(sys.excepthook)
    except Exception:
        pass
    try:
        prev = getattr(threading, "excepthook", None)
        threading.excepthook = _make_thread_excepthook(prev)
    except Exception:
        pass

    event("blackbox_start", "info", {
        "pid": os.getpid(),
        "frozen": bool(getattr(sys, "frozen", False)),
    })
