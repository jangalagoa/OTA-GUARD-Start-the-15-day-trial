"""
VAE 2 — Keep-alive (E5, plan §4.5 / D9).

Reloads the owner's EXTRANET tabs (Page.reload with ignoreCache — the
R4-compliant "Ctrl+F5" move: the BROWSER itself re-fetches, exactly like
a human refresh) at RANDOM intervals so the server-side session never
idles out — and so a background tab never stays frozen long enough for
Brave's memory saver to stop the site's own keepalive timers.

Live proof this is needed (2026-08-24): CM login ~03:00, session dead
by ~11:15 with Brave open the whole time — the CM's native
Account/KeepaliveSession (periodic JS timer) did not save it.

Rules (plan §4.5 / D9):
- one INDEPENDENT timer per tab, random 10-20 min interval
  (map-configurable: session.keepalive.interval_seconds), distinct
  initial offsets so the tabs don't reload in lockstep;
- NEVER during an edition: raise keepalive.EDITION (threading.Event)
  while the executor drives the tab — every tick skips reloading while
  it is set (the in-flight edition is never disturbed);
- reloads EXISTING tabs only — never opens, never closes anything
  (D24: tab management belongs to the owner alone).
"""

from __future__ import annotations

import asyncio
import json
import random
import threading
import urllib.request
from typing import Callable, Dict, Optional, Tuple

try:
    import websockets
except Exception:            # pragma: no cover
    websockets = None

# Shared edition flag — the bridge raises it around every coordinator
# run (executor driving a tab); the keep-alive loop checks it on every
# tick and never reloads an extranet tab while it is set.
EDITION = threading.Event()

DEFAULT_INTERVAL = (600, 1200)      # seconds, per plan D9
TICK_SECONDS = 30                   # housekeeping cadence
POSTPONE_DURING_EDITION = 60        # re-check delay when a run is active


class ExtranetKeepalive:
    """Background keep-alive for the extranet tabs of ONE browser.

    Usage (from the app / extranet_bridge):
        ka = ExtranetKeepalive.from_map(map_path) or ExtranetKeepalive()
        ka.start()          # daemon thread, its own asyncio loop
        ...
        ka.stop()
    The bridge additionally raises EDITION around coordinator runs.
    """

    def __init__(self, debug_port: int = 9222,
                 domain: Optional[str] = None,
                 interval: Tuple[int, int] = DEFAULT_INTERVAL,
                 enabled: bool = True,
                 log_sink: Optional[Callable[[str], None]] = None):
        if websockets is None:
            raise RuntimeError("websockets library required")
        self.debug_port = debug_port
        self.domain = domain or ""
        self.interval = (min(interval), max(interval))
        self.enabled = enabled
        self._log = log_sink or (lambda m: print(f"[keepalive] {m}"))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        # tab id -> next due timestamp (monotonic seconds); a tab seen
        # for the first time gets a DISTINCT random initial offset
        self._next_due: Dict[str, float] = {}

    # ── construction from a site map (session.keepalive block) ──────────
    @classmethod
    def from_map(cls, map_path, debug_port: int = 9222,
                 log_sink: Optional[Callable[[str], None]] = None
                 ) -> "ExtranetKeepalive":
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(Path(map_path).read_text(encoding="utf-8"))
        sess = (cfg.get("session") or {}).get("keepalive") or {}
        interval = sess.get("interval_seconds") or DEFAULT_INTERVAL
        return cls(debug_port=debug_port,
                   domain=cfg.get("extranet") or None,
                   interval=(int(interval[0]), int(interval[1])),
                   enabled=bool(sess.get("enabled", True)),
                   log_sink=log_sink)

    # ── lifecycle ────────────────────────────────────────────────────────
    def start(self) -> None:
        if not self.enabled:
            self._log("disabled by the site map — not started")
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="vae2-keepalive",
                                        daemon=True)
        self._thread.start()
        self._log(f"started — reload every {self.interval[0]}-"
                  f"{self.interval[1]}s (random, per tab) on "
                  f"*{self.domain}*")

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
            self._log("stopped")

    # ── internals ────────────────────────────────────────────────────────
    def _run(self) -> None:
        asyncio.run(self._loop())

    def _tabs(self) -> list:
        try:
            # D128: the CM may live on a learned address now — reload
            # its tabs wherever they are (card domain + learned hosts).
            try:
                from business import cm_sites as _cms
                domains = [d for d in _cms.all_hosts(self.domain) if d]
            except Exception:
                domains = [self.domain]
            with urllib.request.urlopen(
                    f"http://127.0.0.1:{self.debug_port}/json/list",
                    timeout=3) as r:
                return [t for t in json.loads(r.read().decode())
                        if t.get("type") == "page"
                        and any(d in (t.get("url") or "") for d in domains)]
        except Exception:
            return []

    async def _reload(self, tab: dict) -> bool:
        try:
            ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                          max_size=10 * 1024 * 1024)
        except Exception as e:
            self._log(f"connect failed {tab.get('url', '')[:50]}: {e}")
            return False
        try:
            await ws.send(json.dumps({
                "id": 1, "method": "Page.reload",
                "params": {"ignoreCache": True}}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(),
                                                         timeout=20))
                if data.get("id") == 1:
                    return True
        except Exception as e:
            self._log(f"reload failed {tab.get('url', '')[:50]}: {e}")
            return False
        finally:
            try:
                await ws.close()
            except Exception:
                pass

    async def _loop(self) -> None:
        loop = asyncio.get_event_loop()
        while not self._stop.is_set():
            now = loop.time()
            for tab in self._tabs():
                tid = tab.get("id")
                if not tid:
                    continue
                if tid not in self._next_due:
                    # distinct initial offset per tab (never in lockstep)
                    self._next_due[tid] = now + random.uniform(
                        *self.interval)
                    continue
                if now < self._next_due[tid]:
                    continue
                if EDITION.is_set():
                    # an executor run is active — never reload under it
                    self._next_due[tid] = now + POSTPONE_DURING_EDITION
                    continue
                try:  # D98 : global pause — no more reloading at all
                    from extranet_bridge import is_paused
                    if is_paused():
                        self._next_due[tid] = now + POSTPONE_DURING_EDITION
                        continue
                except Exception:
                    pass
                url = (tab.get("url") or "")[:60]
                if await self._reload(tab):
                    self._log(f"reloaded {url}")
                self._next_due[tid] = loop.time() + random.uniform(
                    *self.interval)
            # cooperative wait: threading.Event.wait() is NOT awaitable —
            # poll the flag in 1 s slices so stop() reacts immediately
            for _ in range(TICK_SECONDS):
                if self._stop.is_set():
                    break
                await asyncio.sleep(1)


if __name__ == "__main__":        # manual check: python -m vae2.keepalive
    ka = ExtranetKeepalive()
    print("10 s watch (no reload expected — intervals are minutes):")
    ka.start()
    import time
    time.sleep(10)
    ka.stop()
