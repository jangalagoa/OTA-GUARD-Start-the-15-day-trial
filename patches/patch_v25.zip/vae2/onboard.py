"""VAE 2 — New Channel Manager onboarding tool (D50).

Turns the E1->E4 integration procedure (proven on channelmanager.com.au)
into a repeatable, gated command sequence for ANY new CM extranet.

Subcommands (each one stamps `integration:` in the map — single source
of truth for progress):
  init            create the adapter map skeleton (create_map helper)
  register        add the domain to vae/config/ota_domains.yaml (backup
                  first, idempotent) so the passive listener attaches
  captures        count/list passive captures for the domain and show
                  candidate endpoints (raw material for learning)
  learn           analyze captures and write a sources PROPOSAL
                  (sandbox/onboard/<id>_proposal.yaml) — fingerprints
                  are auto-discovered (R8), the semantic naming and the
                  state_model stay human-reviewed, then merged with
                  --apply
  validate-read   run the scanner with the map over the captures;
                  PASS = ok status, rooms, OTAs, prices, zero locks
  validate-test   run a TEST-a-blanc through the executor (form filled,
                  submit NOT clicked) — browser required, explicit args
  enable-write    flip capabilities.browser_execution: true — refused
                  until validate-test succeeded
  status          print the integration checklist

Safety boundaries (unchanged):
- learn/captures/status/validate-read are pure FILE reading (R1/R3);
- browser actions only exist in validate-test (and later real sends,
  which stay in the app's own REAL confirmation gate);
- no subcommand ever sends an HTTP request (R1).

Usage:
  python -m vae2.onboard status [--map maps/example_cm.yaml]
  python -m vae2.onboard init --domain cm.example.com [--name "Example CM"]
  python -m vae2.onboard register --map maps/example_cm.yaml
  python -m vae2.onboard captures --map maps/example_cm.yaml [--captures DIR]
  python -m vae2.onboard learn --map maps/example_cm.yaml [--captures DIR] [--apply FILE]
  python -m vae2.onboard validate-read --map maps/example_cm.yaml [--captures DIR]
  python -m vae2.onboard validate-test --map maps/example_cm.yaml \
      --room "Room" --ota "OTA" --rate 1234 --date-from 2026-09-01 --date-to 2026-09-03
  python -m vae2.onboard enable-write --map maps/example_cm.yaml
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

VAE2_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = VAE2_DIR.parent
MAPS_DIR = VAE2_DIR / "maps"
DEFAULT_CAPTURES = PROJECT_ROOT / "vae" / "data" / "api_discovery"
PROPOSAL_DIR = PROJECT_ROOT / "sandbox" / "onboard"
DOMAINS_FILE = PROJECT_ROOT / "vae" / "config" / "ota_domains.yaml"


# ── helpers ─────────────────────────────────────────────────────────────────

def _stamp(map_path: Path, key: str, value: Any) -> None:
    """Record integration progress INSIDE the map (data, not code)."""
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    integ = cfg.get("integration") or {}
    integ[key] = value
    integ["updated"] = date.today().isoformat()
    cfg["integration"] = integ
    map_path.write_text(
        yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False),
        encoding="utf-8")


def _stamp_get(map_path: Path, key: str) -> Any:
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    return (cfg.get("integration") or {}).get(key)


def _domain_of(map_path: Path) -> str:
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    dom = str(cfg.get("extranet") or "").strip().lower()
    if not dom:
        raise SystemExit(f"map has no 'extranet': {map_path}")
    return dom


def _count_captures(captures_dir: Path, domain: str) -> int:
    """Fast count: filename filter only — NEVER opens files (the capture
    folder can hold >100k files; opening each meta made 'status' hang)."""
    dom_token = domain.replace(".", "_")
    if not captures_dir.exists():
        return 0
    import os
    n = 0
    with os.scandir(captures_dir) as it:
        for e in it:
            n_name = e.name
            if (not n_name.endswith("_body.json") and "log" not in n_name
                    and dom_token in n_name and n_name.endswith(".json")):
                n += 1
    return n


def _iter_captures(captures_dir: Path, domain: str):
    """Yield (meta, body_obj_or_None) for captures of this domain.
    Uses scandir + early name filter; only matching metas are opened."""
    dom_token = domain.replace(".", "_")
    if not captures_dir.exists():
        return
    import os
    for e in os.scandir(captures_dir):
        name = e.name
        if (name.endswith("_body.json") or "log" in name
                or dom_token not in name or not name.endswith(".json")):
            continue
        try:
            meta = json.loads(Path(e.path).read_text(encoding="utf-8"))
        except Exception:
            continue
        body = None
        body_p = Path(e.path).with_name(Path(e.path).stem + "_body.json")
        if body_p.exists():
            try:
                body = json.loads(body_p.read_text(encoding="utf-8"))
            except Exception:
                body = None
        yield meta, body


_DATELIKE = re.compile(r"\d{4}[.\-/]\d{2}[.\-/]\d{2}")
_CREDENTIAL = re.compile(r"password|passwd|token|secret|apikey|api_key", re.I)


def _stable_field(name: str) -> bool:
    """A field usable as a fingerprint requirement: NOT a rolling date key
    (the grid window moves daily — a date-named requirement made the
    fingerprint match only the capture day, proven 30/08) and NOT a
    credential-ish name (E1 §8.2: those are whitelisted out of everything)."""
    return not _DATELIKE.search(name or "") and not _CREDENTIAL.search(name or "")


def _root_arrays(body: Any) -> List[Dict[str, Any]]:
    """Structural inventory of a JSON body: root arrays with shapes (R8).
    Only STABLE fields are collected (see _stable_field)."""
    out = []
    if not isinstance(body, dict):
        return out
    for key, val in body.items():
        if isinstance(val, list) and val and isinstance(val[0], dict):
            fields = set()
            for rec in val[:20]:
                fields.update(k for k in rec.keys()
                              if isinstance(k, str) and _stable_field(k))
            out.append({"array": key, "records": len(val),
                        "fields": sorted(fields)})
    return out


# ── subcommands ─────────────────────────────────────────────────────────────

def cmd_init(args) -> int:
    from vae2.adapters.create_map import create_map
    domain = args.domain.strip().lower()
    ident = domain.replace(".", "_").replace("-", "_")
    out = MAPS_DIR / f"{ident}.yaml"
    if out.exists():
        raise SystemExit(f"refusing to overwrite existing map: {out}")
    create_map(domain, out, name=args.name)
    _stamp(out, "init", date.today().isoformat())
    print(f"[init] map created : {out}")
    print("  next: register the domain, open the CM extranet in Brave "
          "(so the listener captures it), then run 'captures' + 'learn'.")
    return 0


def cmd_register(args) -> None:
    map_path = Path(args.map)
    domain = _domain_of(map_path)
    if DOMAINS_FILE.exists():
        shutil.copy2(DOMAINS_FILE, DOMAINS_FILE.with_suffix(".yaml.bak"))
    lines = []
    if DOMAINS_FILE.exists():
        lines = DOMAINS_FILE.read_text(encoding="utf-8").splitlines()
    if not any(domain in ln for ln in lines):
        lines.append(f"  - {domain}")
        DOMAINS_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"[register] {domain} added to {DOMAINS_FILE.name} (backup .bak)")
    else:
        print(f"[register] {domain} already registered")
    _stamp(map_path, "domain_registered", date.today().isoformat())
    print("  note: the passive listener attaches at APP STARTUP — restart "
          "OTA Guard (or the standalone listener) after this.")


def cmd_captures(args) -> int:
    map_path = Path(args.map)
    domain = _domain_of(map_path)
    cdir = Path(args.captures) if args.captures else DEFAULT_CAPTURES
    n, endpoints = 0, defaultdict(lambda: {"count": 0, "bytes": 0})
    for meta, body in _iter_captures(cdir, domain):
        n += 1
        url = str(meta.get("url") or "")
        path = "/" + url.split("//", 1)[-1].split("/", 1)[-1] if "://" in url else url
        path = path.split("?")[0][:70]
        endpoints[path]["count"] += 1
        endpoints[path]["bytes"] += len(json.dumps(body)) if body else 0
    print(f"[captures] {n} capture(s) for {domain} in {cdir}")
    if not n:
        print("  NOTHING captured. Checklist:")
        print("   1. domain registered?  -> onboard register")
        print("   2. listener attached?  -> app restarted after register")
        print("   3. CM tab opened/refreshed in Brave?")
        return 2
    print(f"{'endpoint':<72}{'count':>7}{'json KB':>9}")
    for path, st in sorted(endpoints.items(), key=lambda kv: -kv[1]["bytes"])[:15]:
        print(f"{path:<72}{st['count']:>7}{st['bytes'] // 1024:>9}")
    return 0


def cmd_learn(args) -> int:
    map_path = Path(args.map)
    domain = _domain_of(map_path)
    cdir = Path(args.captures) if args.captures else DEFAULT_CAPTURES

    if args.apply:
        proposal = yaml.safe_load(Path(args.apply).read_text(encoding="utf-8")) or {}
        sources = proposal.get("sources") or {}
        if not sources:
            raise SystemExit("proposal has no sources")
        cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
        cfg.setdefault("sources", {}).update(sources)
        map_path.write_text(
            yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False),
            encoding="utf-8")
        _stamp(map_path, "sources_learned", date.today().isoformat())
        print(f"[learn] {len(sources)} source(s) merged into {map_path}")
        # D50 : per-source report IMMEDIATELY after the merge — an
        # auto-learned fingerprint may match nothing (fields too strict,
        # wrong candidate). The vendor then prunes the offending source.
        try:
            cdir = Path(args.captures) if getattr(args, "captures", None)                 else DEFAULT_CAPTURES
            from vae2.scanner import run_scan
            rep = run_scan(cdir, map_path)
            for name, st in (rep.sources_status or {}).items():
                found = bool(st.get("found"))
                print(f"  source '{name}' : "
                      + ("MATCH in the captures" if found
                         else "NO match — consider removing it "
                              "(or loosening required_fields)"))
        except Exception as e:
            print(f"  (per-source verification impossible: {e})")
        print("  next: rename/review them (semantic names + state_model), "
              "then 'validate-read'.")
        return 0

    # analyze: per endpoint, structural candidates (pure file reading)
    candidates: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {"count": 0, "bodies": [], "url": ""})
    for meta, body in _iter_captures(cdir, domain):
        url = str(meta.get("url") or "")
        path = "/" + url.split("//", 1)[-1].split("/", 1)[-1] if "://" in url else url
        path = path.split("?")[0]
        c = candidates[path]
        c["count"] += 1
        c["url"] = url
        if body is not None:
            c["bodies"].append(body)

    ranked = []
    for path, c in candidates.items():
        arrs: Dict[str, Dict[str, Any]] = {}
        for body in c["bodies"][:30]:
            for arr in _root_arrays(body):
                a = arrs.setdefault(arr["array"], {"records": 0, "fields": None})
                a["records"] = max(a["records"], arr["records"])
                # INTERSECTION: fields guaranteed present in EVERY
                # sample — the union produced required_fields that
                # some records lack -> fingerprint never matched.
                f = (set(a["fields"]) & set(arr["fields"])
                     if a["fields"] else set(arr["fields"]))
                a["fields"] = sorted(f)
        if arrs:
            ranked.append((sum(a["records"] for a in arrs.values()), path, c, arrs))
    ranked.sort(reverse=True, key=lambda r: r[0])

    PROPOSAL_DIR.mkdir(parents=True, exist_ok=True)
    out = PROPOSAL_DIR / f"{map_path.stem}_proposal.yaml"
    doc = {"_comment": "PROPOSAL — REQUIRED: rename the read grid source to "
                       "'otasheet_grid' and the write form source to "
                       "'bulkupdate_grid' (canonical names the scanner "
                       "extracts with), fill each state_model from the "
                       "reference map, prune non-matching candidates, then: "
                       "onboard learn --apply this_file",
           "sources": {}}
    for i, (score, path, c, arrs) in enumerate(ranked[:8], 1):
        _dateish = any(re.search(r"\d{4}\.\d{2}\.\d{2}|\d{4}-\d{2}-\d{2}",
                                 str(f)) for a in arrs.values()
                       for f in (a["fields"] or []))
        src = {"endpoint_hint": path.rsplit("/", 1)[-1][:60],
               "_evidence": {"captures": c["count"], "url": c["url"][:90]},
               "_suggest": ("likely otasheet_grid — date-like keys detected"
                            if _dateish else
                            "candidate (form/state source — check fields)"),
               "fingerprint": {"root_arrays": {
                   arr_name: {"min_records": 1,
                              "required_fields": a["fields"][:12]}
                   for arr_name, a in arrs.items()}}}
        doc["sources"][f"src_{i}"] = src
    out.write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False),
                   encoding="utf-8")
    print(f"[learn] {len(candidates)} endpoint(s) seen — top candidates "
          f"written to {out}")
    for i, (score, path, c, arrs) in enumerate(ranked[:8], 1):
        print(f"  src_{i}: {path[:60]}  (captures={c['count']}, "
              f"arrays={list(arrs)[:4]})")
    print("  review the proposal (names + state_model matter: they define "
          "what the scanner extracts), then --apply.")
    return 0


def cmd_validate_read(args) -> int:
    map_path = Path(args.map)
    domain = _domain_of(map_path)
    cdir = Path(args.captures) if args.captures else DEFAULT_CAPTURES
    from vae2.scanner import run_scan
    rep = run_scan(cdir, map_path)
    ok = (rep.status == "ok" and rep.rooms and rep.otas
          and getattr(rep, "daily_prices", None) and not rep.locks)
    print(f"[validate-read] status={rep.status} rooms={len(rep.rooms)} "
          f"otas={len(rep.otas)} prices={len(getattr(rep, 'daily_prices', []) or [])} "
          f"locks={len(rep.locks)}")
    print("  RESULT :", "PASS" if ok else "FAIL")
    if ok:
        _stamp(map_path, "validate_read_ok", date.today().isoformat())
    else:
        print("  fix the proposal/state_model (or capture a grid refresh), "
              "then re-run. A lock = fingerprint mismatch — never force it.")
    return 0 if ok else 2


def cmd_validate_test(args) -> int:
    map_path = Path(args.map)
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    if not (cfg.get("capabilities") or {}).get("browser_execution"):
        raise SystemExit(
            "refused: capabilities.browser_execution is false in this map — "
            "validate the READ path first, then enable-write. (The write "
            "path on an unproven extranet must never start by accident.)")
    from vae2.coordinator import run_task, Task
    task = Task(room_label=args.room, ota_label=args.ota,
                rate=str(args.rate), date_from=args.date_from,
                date_to=args.date_to)
    res = asyncio_run(run_task(
        task, map_path=map_path, captures_dir=Path(args.captures),
        confirmed=False))
    outcome = res.get("outcome")
    print(f"[validate-test] outcome={outcome}")
    ok = outcome in ("test_ok_no_modification", "verified")
    if ok:
        _stamp(map_path, "validate_test_ok", date.today().isoformat())
        print("  RESULT : PASS — the form workflow works on this extranet.")
        print("  next : enable-write, then use the app's own REAL gate.")
    else:
        print("  RESULT : FAIL — page left as-is (D12). Read the journal.")
    return 0 if ok else 2


def cmd_enable_write(args) -> int:
    map_path = Path(args.map)
    if not _stamp_get(map_path, "validate_test_ok"):
        raise SystemExit(
            "refused: no validate_test_ok stamp — run validate-test first. "
            "Write capability is never enabled on an unproven extranet.")
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    caps = cfg.setdefault("capabilities", {})
    caps["browser_execution"] = True
    caps["requires_explicit_confirmation"] = True
    map_path.write_text(
        yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False),
        encoding="utf-8")
    _stamp(map_path, "write_enabled", date.today().isoformat())
    print(f"[enable-write] browser_execution=true in {map_path}")
    print("  real sends still require the app's own confirmation gate.")
    return 0


def cmd_status(args) -> int:
    map_path = Path(args.map)
    cfg = yaml.safe_load(map_path.read_text(encoding="utf-8")) or {}
    dom = str(cfg.get("extranet") or "?")
    registered = False
    if DOMAINS_FILE.exists():
        registered = any(dom in ln for ln in
                         DOMAINS_FILE.read_text(encoding="utf-8").splitlines())
    cdir = Path(args.captures) if args.captures else DEFAULT_CAPTURES
    n = _count_captures(cdir, dom)
    checks = [
        ("map created", True),
        ("domain registered (listener)", registered),
        (f"captures present ({n})", n > 0),
        ("sources learned", bool(cfg.get("sources"))),
        ("read path validated", bool(_stamp_get(map_path, "validate_read_ok"))),
        ("test write validated", bool(_stamp_get(map_path, "validate_test_ok"))),
        ("write enabled", bool((cfg.get("capabilities") or {})
                               .get("browser_execution"))),
    ]
    active = ""
    try:
        from extranet_bridge import active_cm_map
        active = active_cm_map().name
    except Exception:
        pass
    print(f"CM onboarding checklist — {map_path.name} (extranet: {dom})")
    for label, okflag in checks:
        print(f"  [{'x' if okflag else ' '}] {label}")
    print(f"  active map in app: {active or '?'}"
          + ("  (this map)" if active == map_path.name else ""))
    done = all(ok for _, ok in checks)
    print("  INTEGRATION:", "COMPLETE" if done else "IN PROGRESS")
    return 0


def asyncio_run(coro):
    import asyncio
    return asyncio.run(coro)


def main(argv: List[str] = None) -> int:
    ap = argparse.ArgumentParser(prog="vae2.onboard",
                                 description="New CM onboarding (D50)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init")
    p.add_argument("--domain", required=True)
    p.add_argument("--name")
    p.set_defaults(fn=cmd_init)

    for name in ("register", "captures", "learn", "validate-read", "status"):
        p = sub.add_parser(name)
        p.add_argument("--map", required=True)
        if name in ("captures", "learn", "validate-read", "status"):
            p.add_argument("--captures", default=None)
        if name == "learn":
            p.add_argument("--apply", default=None)
        p.set_defaults(fn=globals()[f"cmd_{name.replace('-', '_')}"])

    p = sub.add_parser("validate-test")
    p.add_argument("--map", required=True)
    p.add_argument("--captures", default=None)
    p.add_argument("--room", required=True)
    p.add_argument("--ota", required=True)
    p.add_argument("--rate", type=int, required=True)
    p.add_argument("--date-from", required=True)
    p.add_argument("--date-to", required=True)
    p.set_defaults(fn=cmd_validate_test)

    p = sub.add_parser("enable-write")
    p.add_argument("--map", required=True)
    p.set_defaults(fn=cmd_enable_write)

    args = ap.parse_args(argv)
    return args.fn(args) or 0


if __name__ == "__main__":
    sys.exit(main())
