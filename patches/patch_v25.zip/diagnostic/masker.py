"""Secret masking — used by the black box, the report and the zip.

Rule: NO secret may ever leave the machine in clear text, even in a
report meant for the vendor. Three mechanisms:
1. mask_dict()   : recursive — every key with a suspicious name
                   (password, token, api_key, secret, auth…) gets its
                   value replaced;
2. mask_text()   : regex patterns in free text (AIza… keys, Bearer…,
                   ?token=…, "password": "…") — same patterns as
                   business/app_logger._sanitize, re-imported to stay
                   in sync;
3. the secret files (secrets.json) are NEVER opened.
"""
import re

# Key names whose value is ALWAYS masked (case-insensitive).
_KEY_HINTS = ("password", "passwd", "pass", "secret", "token", "api_key",
              "apikey", "auth", "credential", "private_key", "cm_pass",
              "cm_user")

# Values that look like a key even under an innocent name.
_VALUE_PATTERNS = [
    re.compile(r"AIza[A-Za-z0-9_\-]{20,}"),
    re.compile(r"sk-(?:ant|proj)-[A-Za-z0-9_\-]{10,}"),
    re.compile(r"gsk_[A-Za-z0-9_\-]{10,}"),
]

_MASK = "***"


def _key_is_sensitive(key: str) -> bool:
    k = (key or "").lower()
    return any(h in k for h in _KEY_HINTS)


def mask_value(v):
    """Masks a value if it looks like a key, otherwise returns it."""
    if isinstance(v, str):
        for pat in _VALUE_PATTERNS:
            if pat.search(v):
                return _MASK
        if len(v) > 80 and re.search(r"[A-Za-z0-9_\-]{30,}", v):
            # Long opaque string resembling an encoded secret.
            return _MASK
    return v


def mask_dict(obj, _depth: int = 0):
    """Masked deep copy of a dict/list (the original is untouched)."""
    if _depth > 12:
        return _MASK
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _key_is_sensitive(str(k)):
                out[k] = _MASK if v not in ("", None, False, 0) else v
            else:
                out[k] = mask_dict(v, _depth + 1)
        return out
    if isinstance(obj, (list, tuple)):
        return [mask_dict(v, _depth + 1) for v in obj]
    return mask_value(obj)


def mask_text(text: str) -> str:
    """Masks secrets in free text (log lines, etc.)."""
    if not text:
        return text
    # Same patterns as business/app_logger (single source of truth).
    try:
        from business.app_logger import _sanitize
        text = _sanitize(text)
    except Exception:
        pass
    for pat in (re.compile(r'([?&](?:key|token|auth|api_key|secret)=)[^&\s"\']+',
                           re.I),
                re.compile(r'((?:password|secret|token|api_key|auth)\s*[=:]\s*)\S+',
                           re.I)):
        text = pat.sub(r"\1" + _MASK, text)
    return text


def mask_url(url: str) -> str:
    """Keeps the domain + path of a URL, masks the query string."""
    if not isinstance(url, str) or "://" not in url:
        return url
    base, sep, _query = url.partition("?")
    return base + ("?…" if sep else "")
