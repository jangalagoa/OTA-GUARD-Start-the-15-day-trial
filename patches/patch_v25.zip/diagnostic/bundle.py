"""Vendor deliverable (D91) — cleaned zip + comparison of two reports.

make_bundle(): packs report.txt/.json + masked config + masked log
tails + black box tail. Everything goes through masker — the zip is
meant to leave the machine, NOTHING sensitive may enter it.

compare_reports(): diagnostic-oriented diff between the JSON report of
the python PC and the one of the installed PC (the owner's original
request).
"""
import datetime
import json
import zipfile

from core.paths import DATA_DIR

from diagnostic import masker
from diagnostic.report import REPORTS_DIR

_BUNDLE_MAX_LINES = 400


def _tail_file(fp, n=_BUNDLE_MAX_LINES):
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception:
        return ""
    return "".join(masker.mask_text(l) for l in lines[-n:])


def _full_file_masked(fp) -> str:
    """D99: the ENTIRE log, masked line by line — the zip leaves the
    machine, so every line goes through the mask (same patterns as the
    black box and the tails). A 15 MB log takes a few seconds: this is
    an explicit manual action (📦 button)."""
    out = []
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            for line in f:
                out.append(masker.mask_text(line.rstrip("\n")))
    except Exception:
        return ""
    return "\n".join(out) + ("\n" if out else "")


def make_bundle(txt_path, json_path, facts: dict):
    """Creates the zip; returns its path (in data/diagnostics/)."""
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = REPORTS_DIR / f"otaguard_bundle_{ts}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        if txt_path and txt_path.exists():
            z.write(txt_path, txt_path.name)
        if json_path and json_path.exists():
            z.write(json_path, json_path.name)

        # Full masked config (the precise diff between two machines)
        full = ((facts.get("configuration") or {}).get("_sanitized_full"))
        if full is not None:
            z.writestr("config_sanitized.json",
                       json.dumps(masker.mask_dict(full),
                                  ensure_ascii=False, indent=1))

        # Masked log tails (quick read)
        for name in ("app.log", "ota_guard.log"):
            tail = _tail_file(DATA_DIR / name)
            if tail:
                z.writestr(f"tail_{name}.txt", tail)

        # D99: COMPLETE masked logs — the external analysis (another AI,
        # the vendor) must be able to judge the whole history, not only
        # the tails. app.log + .bak, ota_guard.log + .bak, activity_log.
        for name in ("app.log", "app.log.bak", "ota_guard.log",
                     "ota_guard.log.bak", "activity_log.txt"):
            fp = DATA_DIR / name
            if fp.exists():
                full = _full_file_masked(fp)
                if full:
                    # activity_log.txt already ends with .txt — no
                    # double extension
                    arc = f"full_{name}" if name.endswith(".txt") \
                        else f"full_{name}.txt"
                    z.writestr(arc, full)

        # Black box: full days — already masked AT WRITE TIME
        # (recorder.event applies mask_dict before every line), they go
        # as-is.
        try:
            bb = DATA_DIR / "blackbox"
            for f in sorted(bb.glob("blackbox_*.jsonl")):
                z.writestr(f"blackbox/{f.name}",
                           f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass

        # Black box tail (preview, as before)
        try:
            from diagnostic import recorder
            evts = recorder.recent_events(200)
            if evts:
                z.writestr("blackbox_tail.jsonl",
                           "\n".join(json.dumps(masker.mask_dict(e),
                                                ensure_ascii=False)
                                     for e in evts))
        except Exception:
            pass
    return zip_path


def compare_reports(path_a, path_b) -> list:
    """Readable diff between two .json reports. Returns lines."""
    def load(p):
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d

    try:
        A, B = load(path_a), load(path_b)
    except Exception as e:
        return [f"❌ Unreadable: {e}"]

    L = ["⚖ COMPARISON OF TWO REPORTS",
         f"  A : {path_a.name}",
         f"  B : {path_b.name}", ""]

    def fa(d):  # facts_lite
        return d.get("facts_lite") or {}

    a, b = fa(A), fa(B)

    def row(label, va, vb):
        if va != vb:
            L.append(f"  • {label} :")
            L.append(f"      A = {_short(va)}")
            L.append(f"      B = {_short(vb)}")

    ia, ib = a.get("identity") or {}, b.get("identity") or {}
    row("version", ia.get("app_version"), ib.get("app_version"))
    row("mode (python/exe)", ia.get("mode"), ib.get("mode"))
    row("health score", A.get("score"), B.get("score"))

    ca, cb = a.get("configuration") or {}, b.get("configuration") or {}
    row("last scan", ca.get("last_scan_time"),
        cb.get("last_scan_time"))
    row("CM transport", ca.get("transport"), cb.get("transport"))
    row("CM map", ca.get("cm_map"), cb.get("cm_map"))
    row("active OTAs",
        [o["name"] for o in ca.get("otas") or [] if o.get("active")],
        [o["name"] for o in cb.get("otas") or [] if o.get("active")])
    row("targets", ca.get("target_prices"), cb.get("target_prices"))
    row("room inventory", sorted((ca.get("room_inventory") or {}).keys()),
        sorted((cb.get("room_inventory") or {}).keys()))

    la, lb = ca.get("last_results") or {}, cb.get("last_results") or {}
    if la != lb:
        L.append("  • last displayed prices:")
        for ota in sorted(set(la) | set(lb)):
            if la.get(ota) != lb.get(ota):
                L.append(f"      {ota} : A = {la.get(ota)}  |  "
                         f"B = {lb.get(ota)}")

    ka, kb = a.get("calibrations") or {}, b.get("calibrations") or {}
    row("calibrations (aliases)",
        [(p.get("ota"), p.get("room_aliases"))
         for p in ka.get("profiles") or []],
        [(p.get("ota"), p.get("room_aliases"))
         for p in kb.get("profiles") or []])

    sa, sb = a.get("shipments") or {}, b.get("shipments") or {}
    row("shipments (summary)",
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sa.get("per_ota") or {}).items()},
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sb.get("per_ota") or {}).items()})

    # Diverging findings
    def titles(d):
        return sorted(f"{f.get('severity', '?')}|{f.get('title', '')}"
                      for f in d.get("findings") or [])
    ta, tb = titles(A), titles(B)
    only_a = [t for t in ta if t not in tb]
    only_b = [t for t in tb if t not in ta]
    if only_a:
        L.append("  • findings present ONLY in A:")
        L.extend(f"      {t}" for t in only_a[:12])
    if only_b:
        L.append("  • findings present ONLY in B:")
        L.extend(f"      {t}" for t in only_b[:12])

    if len(L) == 4:
        L.append("  ✅ No difference found on the tracked points.")
    return L


def _short(v):
    s = json.dumps(v, ensure_ascii=False, default=str) \
        if not isinstance(v, str) else v
    return s if len(s) <= 220 else s[:217] + "…"
