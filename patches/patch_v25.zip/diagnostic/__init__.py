"""OTA Guard internal diagnostic (D91) — hidden vendor tool.

Three levels:
- recorder: permanent JSONL black box (every app event) ;
- collect : read-only reading of ALL facts on disk ;
- detective + report: causal analysis, full report, health score.

Absolute rules of the module:
- NEVER a secret in clear text (masker applied everywhere, secrets.json
  never opened) ;
- 100% read-only on the data (only writes: the data/diagnostics/ and
  data/blackbox/ folders) ;
- no network request to any OTA (R1) — the only network test is the
  local connection to the user's browser CDP port 9222 ;
- every failure is tolerated: the tool must never crash the app.
"""
