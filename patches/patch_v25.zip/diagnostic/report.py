"""Report assembly (D91) — readable text + structured JSON.

The .txt is what the owner reads and forwards as-is; the .json is used
to compare two reports (bundle.compare_reports). Both are written to
data/diagnostics/report_<timestamp>.{txt,json}.
"""
import datetime
import json

from core.paths import DATA_DIR

from diagnostic.detective import health_score

REPORTS_DIR = DATA_DIR / "diagnostics"

_SEV_ICON = {"ok": "✅", "info": "ℹ️", "warn": "⚠️", "error": "❌"}
_SECTION_ORDER = ["price", "calibration", "operations", "integrity",
                  "collection"]


def _line(v):
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def _fmt_kb(n):
    return f"{n} KB"


def build_text(facts: dict, findings: list) -> str:
    score, sections = health_score(findings)
    L = []
    add = L.append

    add("=" * 72)
    add("OTA GUARD — INTERNAL DIAGNOSTIC REPORT")
    add("=" * 72)
    ident = facts.get("identity") or {}
    add(f"Generated at  : {ident.get('generated_at')}")
    add(f"Version       : {ident.get('app_version')}  "
        f"({ident.get('mode')})")
    add(f"Machine       : {ident.get('machine')} — "
        f"user {ident.get('user')}")
    add(f"Data folder   : {ident.get('data_dir')}")
    add(f"HEALTH SCORE  : {score}/100")
    add("")

    # ── Findings (the core) ────────────────────────────────────────────
    add("─" * 72)
    add("1. FINDINGS (detected by the detective, with proofs)")
    add("─" * 72)
    by_sec = {}
    for f in findings:
        by_sec.setdefault(f.get("section", "?"), []).append(f)
    rank = {"error": 0, "warn": 1, "info": 2, "ok": 3}
    sec_num = 2
    for sec in _SECTION_ORDER + [s for s in by_sec if s not in
                                 _SECTION_ORDER]:
        items = by_sec.get(sec)
        if not items:
            continue
        add("")
        add(f"  [{sec.upper()}] — health {sections.get(sec, 100)}/100")
        add("  " + "." * 60)
        for f in sorted(items, key=lambda x: rank.get(x.get("severity"), 9)):
            add(f"  {_SEV_ICON.get(f['severity'], '?')} {f['title']}")
            if f.get("detail"):
                for dl in f["detail"].splitlines():
                    add(f"       {dl}")
            for ev in f.get("evidence") or []:
                add(f"       ↳ proof: {ev}")
        sec_num += 1

    # ── Condensed raw facts ────────────────────────────────────────────
    add("")
    add("─" * 72)
    add("2. RAW FACTS")
    add("─" * 72)

    lic = facts.get("license") or {}
    add("")
    add(f"  License : {lic.get('status', '?')} — zone "
        f"{lic.get('zone', '?')}, max_rooms {lic.get('max_rooms', '?')}")

    cfg = facts.get("configuration") or {}
    add(f"  Last scan : {cfg.get('last_scan_time') or 'never'}")
    add(f"  CM transport : {cfg.get('transport', '?')} "
        f"(map {cfg.get('cm_map') or 'default'})")
    add(f"  CM domain    : {cfg.get('cm_domain') or '?'}")
    add(f"  Currency     : {cfg.get('currency') or '?'}")
    add(f"  Auto-correct : {cfg.get('auto_correct')} — interval "
        f"{cfg.get('scan_interval_h')} h")
    add("  Watched OTAs:")
    for o in cfg.get("otas") or []:
        add(f"    [{'x' if o.get('active') else ' '}] {o.get('name')} — "
            f"{o.get('domain')}")
    add("  Targets:")
    for room, per in (cfg.get("target_prices") or {}).items():
        for ota, price in per.items():
            disp = ((cfg.get("last_results") or {}).get(ota) or {}) \
                .get(room)
            add(f"    {room} × {ota} : target {_line(price)}, showing "
                f"{_line(disp)}")

    cal = facts.get("calibrations") or {}
    add("  Calibrations:")
    for p in cal.get("profiles") or []:
        add(f"    {p.get('ota')} : aliases="
            f"{json.dumps(p.get('room_aliases'), ensure_ascii=False)}, "
            f"calibrated {p.get('calibrated_at') or '?'}, "
            f"{p.get('prices_learned')} prices learned")

    sends = (facts.get("shipments") or {}).get("per_ota") or {}
    add("  Send history (per room):")
    for ota_id, rooms in sorted(sends.items()):
        for room, h in rooms.items():
            if not isinstance(h, dict):
                continue
            add(f"    {ota_id} × {room} : {h.get('confirmed')} "
                f"measurement(s), last shipment {h.get('last_sent')}, "
                f"ratio "
                f"{h.get('ratio_median')}"
                + (f", PENDING ({h.get('pending_checks')} scans)"
                   if h.get("pending") else ""))

    env = facts.get("environment") or {}
    add("  Environment:")
    add(f"    CDP port 9222 : "
        f"{'OPEN (browser detected)' if env.get('cdp_9222') else 'CLOSED'}")
    caps = env.get("captures") or {}
    add(f"    VAE captures : {caps.get('count', 0)} files, freshness "
        f"{caps.get('age_h', '?')} h")
    add(f"    Free disk : {env.get('disk_free_gb', '?')} GB")
    files = env.get("data_files") or {}
    add("    Key files:")
    for n in ("config.json", "config.json.bak", "secrets.json",
              "scraper.db", "license.dat", "app.log"):
        if n in files:
            add(f"      {n} : {_fmt_kb(files[n].get('size_kb', '?'))}, "
                f"modified {files[n].get('age_h')} h ago")

    seas = facts.get("seasonal") or {}
    if seas.get("last"):
        s = seas["last"]
        if s.get("error"):
            add(f"  Last seasonal report : {s.get('file')} — "
                f"UNREADABLE ({s.get('error')})"
                + (" ; stats read via the twin .txt"
                   if s.get("from_txt") else ""))
        else:
            add(f"  Last seasonal report : "
                f"{s.get('file')} "
                f"({s.get('ok_count')} ✅ / "
                f"{s.get('warn_count')} ⚠️)")

    pushes = facts.get("pushes") or {}
    if pushes.get("failure_causes"):
        add("  Counted shipment failures : "
            + json.dumps(pushes["failure_causes"], ensure_ascii=False))
    if pushes.get("clamp_count"):
        add(f"  Active min/max guards (2 d) : "
            f"{pushes['clamp_count']} clamped room×OTA — see the "
            "PRICE section")

    errors = facts.get("errors") or {}
    add(f"  Grouped errors (7 d) : {errors.get('total_grouped', 0)} "
        "distinct signatures")

    # ── End ────────────────────────────────────────────────────────────
    add("")
    add("─" * 72)
    add("End of report — generated by the OTA Guard internal diagnostic "
        "tool (D91).")
    add("No secret appears in this report (automatic masking).")
    add("=" * 72)
    return "\n".join(L)


def build_json(facts: dict, findings: list) -> dict:
    score, sections = health_score(findings)
    return {
        "schema": "otaguard-diagnostic/1",
        "generated_at": datetime.datetime.now().isoformat(
            timespec="seconds"),
        "score": score,
        "section_scores": sections,
        "findings": findings,
        # facts without the big log-line blocks
        "facts_lite": _slim_facts(facts),
    }


def _slim_facts(facts: dict) -> dict:
    slim = {}
    for k, v in facts.items():
        if not isinstance(v, dict):
            continue
        v2 = {kk: vv for kk, vv in v.items()
              if kk not in ("recent_tail", "tail", "_sanitized_full")}
        slim[k] = v2
    return slim


def _jsonable(obj):
    """D96-bis shield: converts everything json.dumps refuses — tuple
    keys (the real client crash: "keys must be str, int, float, bool or
    None, not tuple"), sets, dates, any object. The JSON report must
    NEVER crash on the shape of the data."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, (str, int, float, bool)) or k is None:
                kk = k
            elif isinstance(k, tuple):
                kk = " / ".join(str(x) for x in k)
            else:
                kk = str(k)
            out[kk] = _jsonable(v)
        return out
    if isinstance(obj, (list, tuple, set)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return str(obj)


def save_report(facts: dict, findings: list):
    """Writes the .txt + .json report; returns (txt_path, json_path).
    The .json goes through _jsonable: no collected data can break
    serialization anymore (the .txt is written FIRST — but a report
    without a .json breaks the ⚖ comparison and the score)."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    txt = REPORTS_DIR / f"report_{ts}.txt"
    jsn = REPORTS_DIR / f"report_{ts}.json"
    txt.write_text(build_text(facts, findings), encoding="utf-8")
    jsn.write_text(json.dumps(_jsonable(build_json(facts, findings)),
                              ensure_ascii=False, indent=1), encoding="utf-8")
    return txt, jsn
