"""OTA Guard black box (D91) — permanent flight recorder.

PRINCIPLE: "the slightest bug that slips through must leave a dated,
structured trace". Three captured streams, all pre-existing — no
business module is touched:

1. Python logging (root handler): everything the app writes to
   ota_guard.log, including exceptions with exc_info;
2. business.app_log (registered callback): the dated business journal
   D81 (scans, [EXTRANET] shipments, verdicts) — it does NOT use the
   logging module, hence the dedicated hook through its
   register_callback API;
3. excepthooks (sys + threading): every unhandled crash, chained onto
   the previous hook (activity_log D39 installs one too).

Writing: data/blackbox/blackbox_YYYY-MM-DD.jsonl, one file per day,
KEEP_DAYS retention. Write failure = silent shutdown after 3 attempts:
the black box must NEVER crash the app.

Always masked (masker.mask_dict): nothing sensitive can enter it.
"""
import datetime
import json
import logging
import os
import sys
import threading
import traceback

from core.paths import DATA_DIR

BLACKBOX_DIR = DATA_DIR / "blackbox"
KEEP_DAYS = 7          # retention of the daily files
_MAX_DAY_BYTES = 5 * 1024 * 1024   # runaway guard
_FAILS_BEFORE_OFF = 3

_lock = threading.Lock()
_state = {"installed": False, "fails": 0, "off": False, "day": ""}


def _today() -> str:
    return datetime.date.today().isoformat()


def _file_for(day: str):
    return BLACKBOX_DIR / f"blackbox_{day}.jsonl"


def event(kind: str, level: str = "info", data: dict | None = None):
    """Adds an event to the black box. NEVER raises."""
    if _state["off"]:
        return
    try:
        payload = {
            "ts": datetime.datetime.now().isoformat(timespec="seconds"),
            "kind": str(kind)[:80],
            "level": str(level)[:12],
            "thread": threading.current_thread().name[:40],
            "data": data or {},
        }
        from diagnostic.masker import mask_dict
        line = json.dumps(mask_dict(payload), ensure_ascii=False)
        with _lock:
            day = _today()
            fp = _file_for(day)
            if not fp.exists():
                BLACKBOX_DIR.mkdir(parents=True, exist_ok=True)
            elif fp.stat().st_size > _MAX_DAY_BYTES and level != "error":
                return  # saturated day: only errors still get through
            with open(fp, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            if day != _state["day"]:
                _state["day"] = day
                _purge_old()
    except Exception:
        _state["fails"] += 1
        if _state["fails"] >= _FAILS_BEFORE_OFF:
            _state["off"] = True


def _purge_old():
    """Deletes the daily files beyond KEEP_DAYS. Never fatal."""
    try:
        cutoff = datetime.date.today() - datetime.timedelta(days=KEEP_DAYS)
        for fp in BLACKBOX_DIR.glob("blackbox_*.jsonl"):
            try:
                day = fp.stem.replace("blackbox_", "")
                if datetime.date.fromisoformat(day) < cutoff:
                    fp.unlink(missing_ok=True)
            except ValueError:
                pass
    except Exception:
        pass


def recent_events(n: int = 300) -> list:
    """The last n events (today + yesterday), newest last. Tolerant
    reading of incomplete lines — and through the TAIL of the file
    (last 256 KB, D95): a saturated day journal (5 MB) must not slow
    down the diagnostic."""
    out = []
    for day in (_today(),
                (datetime.date.today() - datetime.timedelta(days=1)).isoformat()):
        fp = _file_for(day)
        try:
            if not fp.exists():
                continue
            with open(fp, "rb") as f:
                import os as _os
                _size = fp.stat().st_size
                _sought = _size > 262_144
                if _sought:
                    f.seek(-262_144, _os.SEEK_END)
                raw = f.read()
            text = raw.decode("utf-8", "replace")
            if _sought and "\n" in text:
                text = text.split("\n", 1)[1]   # partial line at the start
            elif not _sought and text.startswith("\ufeff"):
                text = text.lstrip("\ufeff")
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
        except Exception:
            pass
    return out[-n:]


# ── Installation (called once at the app's normal startup) ──────────────────

class _BlackboxHandler(logging.Handler):
    """logging relay → black box. No internal logging (recursion)."""

    def emit(self, record: logging.LogRecord):
        try:
            if record.levelno < logging.INFO:
                return
            data = {"logger": record.name, "msg": record.getMessage()}
            if record.exc_info:
                data["exc"] = "".join(
                    traceback.format_exception_only(*record.exc_info[:2])).strip()
            event("log", record.levelname.lower(), data)
        except Exception:
            pass


def _make_excepthook(previous):
    def _hook(typ, val, tb):
        try:
            event("crash", "error", {
                "exc": "".join(traceback.format_exception(typ, val, tb)
                               [-6:]).strip(),
            })
        finally:
            if previous is not None:
                try:
                    previous(typ, val, tb)
                except Exception:
                    pass
    return _hook


def _make_thread_excepthook(previous):
    def _hook(args):
        try:
            event("crash", "error", {
                "thread": getattr(args.thread, "name", "?"),
                "exc": "".join(traceback.format_exception(
                    args.exc_type, args.exc_value, args.exc_traceback)
                    [-6:]).strip(),
            })
        finally:
            if previous is not None:
                try:
                    previous(args)
                except Exception:
                    pass
    return _hook


def install():
    """Wires the black box onto the three streams. Idempotent."""
    with _lock:
        if _state["installed"]:
            return
        _state["installed"] = True

    # 1. Python logging
    try:
        h = _BlackboxHandler()
        h.setLevel(logging.INFO)
        logging.getLogger().addHandler(h)
    except Exception:
        pass

    # 2. app_log business journal (D81) — does not go through logging
    try:
        from business.app_logger import app_log, register_callback

        def _on_app_line(line: str, level: str):
            event("app_log", level if level in
                  ("warn", "error", "ok", "price", "scan", "browser",
                   "head", "info") else "info",
                  {"line": line.rstrip()})

        register_callback(_on_app_line)
        del app_log  # imported only to make the dependency explicit
    except Exception:
        pass

    # 3. unhandled crashes (chained onto the existing — activity_log D39)
    try:
        sys.excepthook = _make_excepthook(sys.excepthook)
    except Exception:
        pass
    try:
        prev = getattr(threading, "excepthook", None)
        threading.excepthook = _make_thread_excepthook(prev)
    except Exception:
        pass

    event("blackbox_start", "info", {
        "pid": os.getpid(),
        "frozen": bool(getattr(sys, "frozen", False)),
    })
