"""business/seasonal_roomgrid.py — DATED reader of the Agoda room-grid (D72).

VAE1 remains the ONLY capture engine (passive, CDP — unchanged). This
module only READS files already written by VAE1 and only
retains the room-grid whose analyticsContext.checkin_date
matches EXACTLY the requested night. Never a guessed price:

  - no room-grid dated with the right day → None: the caller waits,
    falls back to the generic scan or reports (no more teaser "from"
    price read while the page had not finished loading — nights
    12/20-21 of the 09/20 report);
  - price read: rooms[].offers[0].price.final — what the OTA DISPLAYS,
    discounts included (via final.amountNumber, fallback to the formatted
    string "3,813" / "1,407");
  - currency: final.currency (symbol) → ISO, converted to the software's
    currency with the VAE converter (24 h cache) if different.
"""
import json
import re
import time
from pathlib import Path

# Symbol -> ISO (the room-grid carries the currency as a symbol)
_SYMBOL_TO_ISO = {"₹": "INR", "฿": "THB", "$": "USD", "€": "EUR",
                  "£": "GBP", "¥": "JPY"}

# injectable for tests (the real VAE converter by default)
_converter_factory = None


def _get_converter_factory():
    global _converter_factory
    if _converter_factory is None:
        from vae.src.extractors.currency_converter import CurrencyConverter
        _converter_factory = CurrencyConverter
    return _converter_factory


def host_token(url: str) -> str:
    """Hostname normalized like vae_bridge: 'www.agoda.com/…' → 'agoda_com'."""
    host = (url or "").lower().split("//")[-1].split("/")[0]
    host = host.replace(".", "_")
    if host.startswith("www_"):
        host = host[4:]
    return host


def _room_label(name) -> str:
    "'Chambre Double (Double Room)' → 'Double Room'; otherwise as-is."
    n = (name or "").strip()
    if "(" in n and n.endswith(")"):
        inner = n[n.rindex("(") + 1:-1].strip()
        if inner:
            return inner
    return n


def _amount(offer: dict):
    """Displayed final price from ONE room-grid offer (float or None)."""
    fin = ((offer.get("price") or {}) or {}).get("final") or {}
    v = fin.get("amountNumber")
    if isinstance(v, (int, float)) and v > 0:
        return float(v)
    s = str(fin.get("amount") or "")
    digits = re.sub(r"\D", "", s)
    return float(digits) if digits else None


def read_room_grid(captures_dir, night_iso: str, token: str = "agoda_com",
                   target_currency: str = "INR", not_before: float = 0.0):
    """The FRESHEST room-grid whose checkin_date == night_iso.

    not_before (epoch): ignore every file written before — during a
    verification, the capture must come from THAT night's navigation,
    never from a previous session (on 09/20, the night of 12/21
    read the stale 13,358 of the previous day that way).

    Returns (prices, meta) or (None, reason):
      prices = {room_label: price in the software's currency}
      meta   = {"file", "checkin", "currency"}
    No file modified — pure read (R1/R3: VAE1 captures, we read)."""
    d = Path(captures_dir)
    try:
        files = sorted(d.glob(f"*_{token}_body.json"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        return None, f"captures folder unreadable: {captures_dir}"
    for f in files:
        try:
            mt = f.stat().st_mtime
        except Exception:
            continue
        if not_before and mt < not_before:
            break        # sorted by descending mtime: everything else
            # is even older — no need to continue
        try:
            body = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(body, dict):
            continue
        ac = body.get("analyticsContext") or {}
        if str(ac.get("checkin_date") or "") != night_iso:
            continue                       # locked date: NOT this night
        out, cur_iso = {}, ""
        for r in (body.get("rooms") or []):
            label = _room_label(r.get("name"))
            offers = r.get("offers") or []
            if not label or not offers:
                continue
            amt = _amount(offers[0])
            if amt is None:
                continue
            sym = str((((offers[0].get("price") or {})
                        .get("final")) or {}).get("currency") or "").strip()
            cur_iso = _SYMBOL_TO_ISO.get(sym) or cur_iso
            out[label] = amt
        if not out:
            continue
        if cur_iso and target_currency and cur_iso != target_currency:
            try:
                conv = _get_converter_factory()()
                out = {k: conv.convert(v, cur_iso, target_currency)
                       for k, v in out.items()}
            except Exception as e:
                return None, f"conversion {cur_iso}→{target_currency} " \
                             f"impossible ({e})"
        # D80: every dated price read goes to the evidence journal
        # (append-only) — source file cited for traceability.
        try:
            from business import legal_ledger as _ll
            for _room, _price in out.items():
                _ll.journal_price_read(
                    token, _room, _price, currency=target_currency,
                    date=night_iso,
                    source="dated room-grid (seasonal verification)",
                    source_file=f.name)
        except Exception:
            pass
        return out, {"file": f.name, "checkin": night_iso,
                     "currency": cur_iso or "?"}
    return None, f"no room-grid dated {night_iso} (the most recent " \
                 f"one does not carry this night)"

def wait_room_grid(captures_dir, night_iso, token, target_currency,
                   timeout_s=12.0, poll_s=3.0, not_before=0.0, log=None):
    """Waits for the night's room-grid to arrive (poll), then reads it.
    Same return contract as read_room_grid (None = no dated data —
    the caller decides the fallback, never a guessed price)."""
    t0 = time.time()
    while True:
        prices, meta = read_room_grid(captures_dir, night_iso, token,
                                      target_currency,
                                      not_before=not_before)
        if prices is not None:
            return prices, meta
        if time.time() - t0 >= timeout_s:
            return None, meta
        if log:
            log(f"      room-grid of {night_iso} not landed yet — "
                f"retrying…")
        time.sleep(max(0.5, poll_s))
