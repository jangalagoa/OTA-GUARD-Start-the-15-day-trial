"""
OTA Direct Push — browser automation engine.

Principle: no official API (OTAs do not grant them to individual hotels).
Instead, a path is recorded once per OTA by the user (login URL → rates
page → price field per room → Save button), via a visible browser driven by
tabs/tab_ota_direct.py (guided assistant, the user clicks themselves
on each element — no automatic field detection).

This module only contains the non-interactive, reusable logic:
- ROOM_RECORDER_JS: captures a click (CSS selector) on the browser side,
  used both by the recording assistant (tab_ota_direct.py)
  and testable independently.
- generic_login()  : best-effort filling of a login form
  (generic username + password, no OTA known precisely).
- run_test_login() : verifies that the credentials allow logging in
  (does not guarantee reaching the rates page).
- run_push()       : replays the recorded path to push prices.

Fragiler than a real API: if the OTA changes its site, the recorded
selectors break and the user must re-run the guided recording.

Journal: as for the analysis modules (D44), the messages returned to
the screen stay neutral — the name of the automation library and the
full error traces go to app.log via `log`.
"""
import logging

log = logging.getLogger(__name__)


def _tr(txt: str, **kw) -> str:
    """Translates a message intended for the screen, then inserts the values.

    Name `_tr` on purpose: it is one of the two names that `tools/i18n_extract.py`
    recognizes (`TR_NAMES`), so every text passed here automatically enters
    `locales/_master_keys.json` and goes to translation.

    All messages returned by this module end up in the tab's journal, so under
    the user's eyes: they must follow the chosen language, like the rest of
    the interface. Until now they were returned in French whatever the
    language.

    Local import of `core.utils`: this module also runs headless, and
    loading the language catalogue is then useless (same reason as
    in `scraping/qr_pairing.py`).

    The `.format` is protected. A translation whose `{...}` placeholders were
    damaged must not fail a push that itself went well:
    in that case we fall back to the source text, whose placeholders are safe.
    """
    try:
        from core.utils import tr_
        traduit = tr_(txt)
    except Exception:
        traduit = txt
    if not kw:
        return traduit
    try:
        return traduit.format(**kw)
    except Exception:
        log.warning("[OTA Direct] Unusable translation (damaged placeholders): %r", txt)
        try:
            return txt.format(**kw)
        except Exception:
            return txt


# ── JS injected into the page: captures the CSS selector of the next click ──
# when window.__ogd_arm is true (armed just before each capture, on the
# Python side, so normal navigation clicks are never intercepted).
#
# Besides the selector, the INDEX of the clicked element among all
# those this selector designates is recorded. On OTA extranets, a rate grid
# often aligns N identical fields (same CSS class, no id): a
# `locator(sel).first` at push time would then write the price into the
# FIRST row whatever the targeted room. The index makes the replay
# exact. `n` (total number of matches) is used to warn the user
# when the selector is ambiguous.
ROOM_RECORDER_JS = r"""
(function(){
    if (window.__ogd_rec) return;
    window.__ogd_rec = true;
    window.__ogd_arm = false;
    window.__ogd_actions = [];
    function _sel(el){
        if (!el || el === document || el === window) return '';
        if (el.id) return '#' + el.id;
        var attrs = ['data-testid','data-cy','data-selenium','aria-label','name','role'];
        for (var i = 0; i < attrs.length; i++){
            var v = el.getAttribute(attrs[i]);
            if (v) return el.tagName.toLowerCase() + '[' + attrs[i] + '="' +
                          v.replace(/"/g, '\\"') + '"]';
        }
        var cls = el.className;
        if (cls && typeof cls === 'string'){
            var c = cls.trim().split(/\s+/)[0];
            if (c) return el.tagName.toLowerCase() + '.' + c;
        }
        return el.tagName.toLowerCase();
    }
    function _pos(el, sel){
        // Index of `el` among the matches of `sel`, and total.
        try {
            var all = document.querySelectorAll(sel);
            for (var i = 0; i < all.length; i++){
                if (all[i] === el) return {i: i, n: all.length};
            }
            return {i: 0, n: all.length};
        } catch (err) { return {i: 0, n: 1}; }
    }
    function _hint(el){
        // Small readable marker for the user (never used to target).
        try {
            var h = el.getAttribute('aria-label') || el.getAttribute('placeholder')
                    || el.getAttribute('name') || (el.value || '') || '';
            return String(h).trim().slice(0, 40);
        } catch (err) { return ''; }
    }
    document.addEventListener('click', function(e){
        if (!window.__ogd_arm) return;
        e.preventDefault();
        e.stopPropagation();
        var s = _sel(e.target);
        var p = _pos(e.target, s);
        window.__ogd_actions.push({s: s, i: p.i, n: p.n,
                                   t: _hint(e.target), u: location.href});
        window.__ogd_arm = false;
    }, true);
})();
"""


def locate(page, mapping):
    """Finds the element described by a recorded mapping.

    `mapping` : {"selector": str, "index": int|None, ...}
    Configurations recorded BEFORE the addition of the index have no
    "index" key — we then fall back to `.first`, i.e. exactly the
    original behavior (no existing config is broken).
    """
    loc = page.locator(mapping["selector"])
    idx = mapping.get("index")
    if isinstance(idx, int) and idx > 0:
        return loc.nth(idx)
    return loc.first


def generic_login(page, username: str, password: str) -> bool:
    """Fills and submits a generic login form.

    Best-effort: no OTA has a standard form, so we try a list of usual
    selectors. Returns False if no password field was found (nothing to
    validate) — never raises.
    """
    try:
        if username:
            for sel in (
                'input[type="email"]',
                'input[autocomplete="username"]',
                'input[name*="user" i]',
                'input[name*="login" i]',
                'input[name*="email" i]',
                'input[type="text"]',
            ):
                loc = page.locator(sel).first
                try:
                    if loc.count() and loc.is_visible():
                        loc.fill(username)
                        break
                except Exception:
                    continue
    except Exception:
        pass

    try:
        pwd = page.locator('input[type="password"]').first
        if not pwd.count():
            return False
        pwd.fill(password)
    except Exception:
        return False

    clicked = False
    try:
        for sel in (
            'button[type="submit"]',
            'input[type="submit"]',
            'button:has-text("Se connecter")',
            'button:has-text("Connexion")',
            'button:has-text("Sign in")',
            'button:has-text("Log in")',
            'button:has-text("Login")',
        ):
            loc = page.locator(sel).first
            try:
                if loc.count() and loc.is_visible():
                    loc.click()
                    clicked = True
                    break
            except Exception:
                continue
    except Exception:
        pass

    if not clicked:
        try:
            page.locator('input[type="password"]').first.press("Enter")
        except Exception:
            pass

    try:
        page.wait_for_timeout(2500)
    except Exception:
        pass
    return True


# Single message when the browser driver is missing: the screen stays neutral,
# the actually missing component is traced in app.log (convention D44).
#
# Function and not constant: a constant would be frozen in the language in
# force at the time of the module import, while the language can change
# during the session. And a literal passed to `_tr()` is seen by the
# translation extractor, which a variable would not be.
def msg_no_driver() -> str:
    return _tr("The browser component is not available on this "
               "installation. Reinstall OTA Guard or contact support.")


def _load_profile(config: dict | None, ota_id: str) -> dict:
    """Anti-detection profile for this OTA (Global + possible per-OTA
    override defined in the Anti-detection tab). Returns {} if `config` is
    not provided — behavior then identical to before (headless, no proxy)."""
    if config is None:
        return {}
    try:
        from scraping.scraping import get_profile
        return get_profile(config, ota_id)
    except Exception:
        return {}


def run_test_login(login_url: str, username: str, password: str,
                    config: dict = None, ota_id: str = ""):
    """Tests the login with the extranet credentials. Does NOT verify
    that the rates page is reached — only that the login succeeds.
    Returns (ok: bool, message: str).

    config/ota_id (optional): if provided, applies the anti-detection profile
    configured for this OTA (headless, proxy).
    """
    if not login_url:
        return False, _tr("Login URL missing")
    if not username or not password:
        return False, _tr("Username or password missing")

    try:
        from scraping.browser_driver import sync_playwright
        from scraping.chrome_manager import launch_context, apply_stealth
        from scraping.scraping import ota_launch_quirks
    except ImportError as e:
        # The name of the missing component goes to app.log, not to the screen (D44).
        log.warning("[OTA Direct] Browser driver unavailable: %s", e)
        return False, msg_no_driver()

    profile = _load_profile(config, ota_id)
    try:
        from scraping.scraping import get_proxy
        _proxy = get_proxy(profile)
    except Exception:
        _proxy = None

    _quirks = ota_launch_quirks(ota_id)
    try:
        with sync_playwright() as pw:
            ctx, _ = launch_context(pw, "calib_nav",
                                     headless=profile.get("headless", True),
                                     proxy=_proxy,
                                     extra_args=_quirks.get("extra_args"),
                                     viewport={"width": 1366, "height": 768})
            page = ctx.new_page()
            apply_stealth(page)
            try:
                page.goto(login_url,
                          wait_until=_quirks.get("goto_wait_until", "domcontentloaded"),
                          timeout=_quirks.get("goto_timeout_ms", 30000))
                generic_login(page, username, password)
                still_on_login = False
                try:
                    pwd = page.locator('input[type="password"]').first
                    still_on_login = bool(pwd.count()) and pwd.is_visible()
                except Exception:
                    pass
                url_after = page.url
            finally:
                ctx.close()
    except Exception as e:
        # The exact pattern can name the automation library: it goes
        # to app.log, not to the screen (D44).
        log.warning("[OTA Direct] Login test %s failed: %s", ota_id, e)
        return False, _tr("Login impossible. Check the login URL and "
                          "the Internet connection; the technical detail is in "
                          "the application journal.")

    if still_on_login:
        return False, _tr(
            "Login probably failed (password field still visible). "
            "Check the username/password, or log in manually to "
            "see whether there is two-factor authentication (2FA) or a CAPTCHA.")
    return True, _tr(
        "Login successful (landed on {url}). This does not guarantee "
        "being on the rates page — then use "
        "🎯 Record the path to the prices.", url=url_after)


def _save_proof(page, ota_id: str):
    """Captures the rates page screen after a push, as proof.

    The tab warns the user to "always verify that a sent price is actually
    displayed on the OTA's site": without a trace, this verification is
    impossible as soon as the push runs automatically at night. Best-effort —
    a capture failure must never fail a successful push.
    """
    try:
        from datetime import datetime
        from core.paths import DATA_DIR
        d = DATA_DIR / "ota_direct_proof"
        d.mkdir(parents=True, exist_ok=True)
        # One capture per push (not per day): it is the precise push we
        # want to be able to verify. An hourly auto-push therefore produces up
        # to 24 images/day/OTA — hence the purge below.
        f = d / f"{ota_id or 'ota'}_{datetime.now():%Y-%m-%d_%H%M%S}.png"
        page.screenshot(path=str(f), full_page=False)
        log.info("[OTA Direct] Proof saved: %s", f)
        _purge_proofs(d, ota_id)
        return f
    except Exception as e:
        log.warning("[OTA Direct] Proof capture impossible: %s", e)
        return None


def _purge_proofs(dossier, ota_id: str, garder: int = 30):
    """Keeps only the `garder` latest captures of this OTA.

    Without purge, the folder grows endlessly (~200 KB per capture, up to
    24 per day and per OTA in hourly auto-push). Best-effort: a failure here
    must never fail the push that just succeeded.
    """
    try:
        motif = f"{ota_id or 'ota'}_*.png"
        # The name contains a YYYY-MM-DD_HHMMSS timestamp: alphabetical
        # order is chronological order, no stat() needed.
        anciennes = sorted(dossier.glob(motif))[:-garder]
        for vieille in anciennes:
            try:
                vieille.unlink()
            except OSError:
                pass
        if anciennes:
            log.info("[OTA Direct] %d old proof(s) deleted for %s",
                     len(anciennes), ota_id or "ota")
    except Exception as e:
        log.warning("[OTA Direct] Proof purge impossible: %s", e)


def run_push(login_url: str, username: str, password: str,
             price_page_url: str, rooms: dict, save_selector: str,
             prices: dict, config: dict = None, ota_id: str = "",
             dry_run: bool = False):
    """Replays the recorded path to push `prices` (room -> amount).

    `rooms` : {internal_room: {"ota_label": str, "selector": str, "index": int}}
    config/ota_id (optional): if provided, applies the anti-detection profile
    configured for this OTA (headless, proxy).

    `dry_run=True`: full walkthrough (login, rates page, locating
    each field) WITHOUT ever writing anything or clicking Save.
    Used to verify that a recorded path still holds after a redesign
    of the OTA's site, without risking publishing a wrong rate.

    Returns (ok: bool, message: str).
    """
    if not login_url or not username or not password:
        return False, _tr("Missing credentials — complete the configuration.")
    if not price_page_url or not rooms:
        return False, _tr(
            "No recorded path for this OTA. "
            "First use 🎯 Record the path to the prices.")

    try:
        from scraping.browser_driver import sync_playwright
        from scraping.chrome_manager import launch_context, apply_stealth
        from scraping.scraping import ota_launch_quirks
    except ImportError as e:
        log.warning("[OTA Direct] Browser driver unavailable: %s", e)
        return False, msg_no_driver()

    profile = _load_profile(config, ota_id)
    try:
        from scraping.scraping import get_proxy
        _proxy = get_proxy(profile)
    except Exception:
        _proxy = None

    _quirks = ota_launch_quirks(ota_id)
    # done      : price written AND read back with the right value
    # unverified: price written but read-back impossible/different
    # failed    : field not found or refusing input
    # missing   : room without a recorded mapping
    # invalid   : price <= 0 or unreadable — never sent
    done, unverified, failed, missing, invalid = [], [], [], [], []
    proof = None
    try:
        with sync_playwright() as pw:
            ctx, _ = launch_context(pw, "calib_nav",
                                     headless=profile.get("headless", True),
                                     proxy=_proxy,
                                     extra_args=_quirks.get("extra_args"),
                                     viewport={"width": 1366, "height": 768})
            page = ctx.new_page()
            apply_stealth(page)
            try:
                page.goto(login_url,
                          wait_until=_quirks.get("goto_wait_until", "domcontentloaded"),
                          timeout=_quirks.get("goto_timeout_ms", 30000))
                generic_login(page, username, password)
                page.goto(price_page_url,
                          wait_until=_quirks.get("goto_wait_until", "domcontentloaded"),
                          timeout=_quirks.get("goto_timeout_ms", 30000))

                # Login refused (changed password, 2FA, CAPTCHA): we
                # land on a login screen, so NO price field exists.
                # Without this check, the final message accused the site
                # of having changed and asked to re-record everything — while
                # fixing the password was enough.
                try:
                    pwd = page.locator('input[type="password"]').first
                    if pwd.count() and pwd.is_visible():
                        log.warning("[OTA Direct] %s: password field visible on "
                                    "the rates page — login not completed", ota_id)
                        return False, _tr(
                            "Login refused: the rates page asks for a password "
                            "again. Check your credentials with 🔌 Test, and "
                            "log in manually once to see whether there is "
                            "two-factor authentication (2FA) or a CAPTCHA. "
                            "No price was modified.")
                except Exception:
                    pass    # best-effort heuristic: continue the push

                for room, price in prices.items():
                    mapping = rooms.get(room)
                    if not mapping or not mapping.get("selector"):
                        missing.append(room)
                        continue
                    try:
                        if price is None or int(price) <= 0:
                            invalid.append(room)
                            continue
                    except (TypeError, ValueError):
                        invalid.append(room)
                        continue
                    try:
                        loc = locate(page, mapping)
                        loc.wait_for(state="visible", timeout=8000)
                        if dry_run:
                            # Simulation: we stop at "the field exists and
                            # it is visible". Nothing is written.
                            done.append(room)
                            continue
                        attendu = str(int(price))
                        loc.fill(attendu)
                        # Read-back: some extranets refuse the input
                        # (JS-driven field, input mask, read-only field)
                        # without raising any error. Without
                        # this check, a "successful" push may have changed
                        # nothing at all.
                        try:
                            lu = (loc.input_value() or "").strip()
                        except Exception as e:
                            log.info("[OTA Direct] %s: read-back impossible (%s)",
                                     room, e)
                            lu = None
                        if lu is None:
                            unverified.append(room)
                        elif "".join(c for c in lu if c.isdigit()) == attendu:
                            done.append(room)
                        else:
                            log.warning("[OTA Direct] %s: wrote %r, read %r",
                                        room, attendu, lu)
                            unverified.append(room)
                    except Exception as e:
                        log.warning("[OTA Direct] %s: unusable field — %s",
                                    room, e)
                        failed.append(room)

                if save_selector and not dry_run:
                    try:
                        sloc = page.locator(save_selector).first
                        sloc.wait_for(state="visible", timeout=8000)
                        sloc.click()
                        try:
                            page.wait_for_timeout(2000)
                        except Exception:
                            pass
                    except Exception as e:
                        log.warning("[OTA Direct] Save button: %s", e)
                        failed.append("(Save button)")
                elif save_selector and dry_run:
                    try:
                        page.locator(save_selector).first.wait_for(
                            state="visible", timeout=8000)
                    except Exception as e:
                        log.warning("[OTA Direct] Save button: %s", e)
                        failed.append("(Save button)")

                if not dry_run and (done or unverified):
                    proof = _save_proof(page, ota_id)
            finally:
                ctx.close()
    except Exception as e:
        log.exception("[OTA Direct] Push interrupted (OTA %s)", ota_id)
        # Full pattern → app.log; neutral screen (D44). We add the only
        # useful instruction: a push interrupted midway may have
        # already written part of the prices.
        return False, _tr("Push interrupted. Check on the OTA's site whether "
                          "prices were modified; the technical detail is in "
                          "the application journal.")

    # ── Simulation: we report, we never claim to have pushed ─────────────
    if dry_run:
        if failed or missing:
            detail = []
            if failed:
                detail.append(_tr("field(s) not found: {liste}",
                                  liste=", ".join(failed)))
            if missing:
                detail.append(_tr("unmapped room(s): {liste}",
                                  liste=", ".join(missing)))
            return False, _tr("🧪 Simulation — {details}. Re-run "
                              "🎯 Record the path to the prices.",
                              details=" ; ".join(detail))
        return True, _tr("🧪 Simulation — valid path: {n} field(s) "
                         "found. No price was sent.", n=len(done))

    if failed:
        return False, _tr(
            "{n} prices sent, but field(s) not found: {liste}. "
            "The OTA's site has probably changed — re-run "
            "🎯 Record the path to the prices.",
            n=len(done), liste=", ".join(failed))
    if not done and not unverified:
        if invalid:
            return False, _tr(
                "No valid price to send — price at 0 or negative ignored "
                "for safety for: {liste}", liste=", ".join(invalid))
        return False, _tr("No mapped room could be pushed.")

    # Message assembled piece by piece: each piece is translated
    # separately, otherwise a sentence would be needed for each of the 16
    # possible combinations of these four complements.
    ok_msg = _tr("{n} prices sent", n=len(done))
    if done:
        ok_msg += ": " + ", ".join(f"{r} = {int(prices[r]):,}" for r in done)
    if unverified:
        ok_msg += _tr("  ⚠ not confirmed by read-back: {liste} — verify "
                      "on the OTA's site", liste=", ".join(unverified))
    if invalid:
        ok_msg += _tr("  ⚠ price(s) at 0 or negative ignored for safety: {liste}",
                      liste=", ".join(invalid))
    if missing:
        ok_msg += _tr("  (unmapped, ignored: {liste})",
                      liste=", ".join(missing))
    if proof:
        ok_msg += _tr("  📸 proof: {fichier}", fichier=proof.name)
    # A push for which NO price is confirmed must not display in green:
    # the user would believe their rates published while nothing changed.
    return bool(done), ok_msg
