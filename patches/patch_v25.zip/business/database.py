import sqlite3
import csv
import logging
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

_CSV_LOCK = threading.Lock()

from core.paths import DATA_DIR
DB_FILE    = DATA_DIR / "scraper.db"
SCANS_FILE = DATA_DIR / "scans.csv"

RETENTION_DAYS = 720


def get_conn():
    conn = sqlite3.connect(str(DB_FILE), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


@contextmanager
def db_conn():
    """SQLite context-manager: commit/rollback AND guaranteed close.

    `with sqlite3.connect(...)` does NOT close the connection (it only
    commits/rolls back) — hence descriptor leaks. This helper reproduces
    the commit/rollback semantics and always closes the connection in finally.
    """
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


_db_initialized = False


def init_db():
    global _db_initialized
    if _db_initialized:
        return
    DB_FILE.parent.mkdir(exist_ok=True)
    with db_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS scans (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp   TEXT NOT NULL,
                competitor  TEXT,
                source_id   TEXT,
                room_type   TEXT,
                price       REAL,
                url         TEXT,
                status      TEXT,
                message     TEXT
            );

            CREATE TABLE IF NOT EXISTS email_raw (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                stored_at           TEXT NOT NULL,
                account             TEXT,
                uid                 TEXT UNIQUE,
                from_addr           TEXT,
                subject             TEXT,
                date_str            TEXT,
                html_body           TEXT,
                text_body           TEXT,
                source_id           TEXT,
                extracted_price     TEXT,
                extracted_currency  TEXT,
                extracted_room      TEXT,
                extracted_competitor TEXT,
                scan_method         TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_email_raw_stored ON email_raw(stored_at);
            CREATE INDEX IF NOT EXISTS idx_email_raw_uid    ON email_raw(uid);

            CREATE INDEX IF NOT EXISTS idx_scans_ts          ON scans(timestamp);
            CREATE INDEX IF NOT EXISTS idx_scans_comp_ts     ON scans(competitor, timestamp);
            CREATE INDEX IF NOT EXISTS idx_scans_comp_status ON scans(competitor, status);
        """)
    # ── email_raw migrations (columns added after the fact) ──────────────────
    _email_raw_cols = [
        ("extracted_price",      "TEXT"),
        ("extracted_currency",   "TEXT"),
        ("extracted_room",       "TEXT"),
        ("extracted_competitor", "TEXT"),
        ("scan_method",          "TEXT"),
    ]
    with db_conn() as _mc:
        for _col, _typ in _email_raw_cols:
            try:
                _mc.execute(f"ALTER TABLE email_raw ADD COLUMN {_col} {_typ}")
            except Exception:
                pass  # column already present
    purge_old_records()
    _prune_to_row_limit()
    _db_initialized = True


def purge_old_records():
    cutoff = (datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
    with db_conn() as conn:
        conn.execute("DELETE FROM scans WHERE timestamp < ?", (cutoff,))


# Row caps per table — protects against unbounded growth
_ROW_LIMITS = {
    "scans": 50_000,
}


_ALLOWED_TABLES = frozenset(_ROW_LIMITS.keys())


def _safe_table(name: str) -> str:
    """S3: validates that a table name belongs to the whitelist.

    Use this everywhere a table name is interpolated into a SQL query
    (f-string, format, etc.) to prevent injection via a caller-controlled
    table name.
    Raises ValueError if `name` is not in _ALLOWED_TABLES.
    """
    if name not in _ALLOWED_TABLES:
        raise ValueError(f"Table name not allowed: '{name}'")
    return name


def _prune_to_row_limit():
    """Deletes the oldest rows if a table exceeds its cap."""
    with db_conn() as conn:
        for table, limit in _ROW_LIMITS.items():
            try:
                t = _safe_table(table)  # S3: whitelist validation before interpolation
            except ValueError:
                logging.error("DB prune: table name not allowed '%s' — skipped.", table)
                continue
            count = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            if count > limit:
                excess = count - limit
                conn.execute(
                    f"DELETE FROM {t} WHERE id IN "
                    f"(SELECT id FROM {t} ORDER BY id ASC LIMIT ?)",
                    (excess,)
                )
                logging.info("DB prune: %d rows deleted from '%s' (cap %d).",
                             excess, t, limit)


# ── Write ────────────────────────────────────────────────────────────────────

_ANOMALY_THRESHOLD_PCT = 50   # max tolerated deviation from the historical average
_ANOMALY_MIN_SAMPLES   = 3    # minimum number of historical prices to enable the check


def check_price_anomaly(competitor, room_type, new_price, n_samples=10):
    """
    Compares new_price against the last n_samples prices for (competitor, room_type).
    Returns (is_anomaly: bool, deviation_pct: float, historical_avg: float).
    Never raises — DB errors are silent here.

    Note: insert_scan() embeds the same computation inline to automatically
    mark the ANOMALY status at insertion. This function is intended for UI
    callers (display, alerts) that want to consult the anomaly score without
    triggering an insertion.
    """
    if not new_price or new_price <= 0:
        return False, 0.0, 0.0
    try:
        with db_conn() as conn:
            rows = conn.execute(
                "SELECT price FROM scans "
                "WHERE competitor=? AND room_type=? AND price>0 AND status='OK' "
                "ORDER BY timestamp DESC LIMIT ?",
                (competitor, room_type, n_samples)
            ).fetchall()
        prices = [r[0] for r in rows if r[0]]
        if len(prices) < _ANOMALY_MIN_SAMPLES:
            return False, 0.0, 0.0
        avg = sum(prices) / len(prices)
        if avg <= 0:
            return False, 0.0, 0.0
        deviation_pct = abs(new_price - avg) / avg * 100
        return deviation_pct > _ANOMALY_THRESHOLD_PCT, round(deviation_pct, 1), round(avg)
    except Exception as e:
        logging.warning("check_price_anomaly DB error (%s / %s): %s", competitor, room_type, e)
        return False, 0.0, 0.0


def insert_scan(competitor, source_id, room_type, price, url="", status="OK", message=""):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    try:
        with db_conn() as conn:
            if status == "OK" and price and price > 0:
                rows = conn.execute(
                    "SELECT price FROM scans "
                    "WHERE competitor=? AND room_type=? AND price>0 AND status='OK' "
                    "ORDER BY timestamp DESC LIMIT ?",
                    (competitor, room_type, _ANOMALY_MIN_SAMPLES)
                ).fetchall()
                prices = [r[0] for r in rows if r[0]]
                if len(prices) >= _ANOMALY_MIN_SAMPLES:
                    avg = sum(prices) / len(prices)
                    if avg > 0:
                        deviation_pct = abs(price - avg) / avg * 100
                        if deviation_pct > _ANOMALY_THRESHOLD_PCT:
                            hist_avg = round(avg)
                            logging.warning(
                                "[PRICE ANOMALY] %s / %s: new price %d INR deviates by %.1f%% "
                                "from the historical average %d INR (%d last scans).",
                                competitor, room_type, price, deviation_pct, hist_avg, _ANOMALY_MIN_SAMPLES
                            )
                            status = "ANOMALY"
                            message = (f"Deviation {deviation_pct:.1f}% vs avg {hist_avg} INR. "
                                       + message).strip()

            conn.execute(
                "INSERT INTO scans (timestamp, competitor, source_id, room_type, price, url, status, message) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (now, competitor, source_id, room_type, price, url, status, message)
            )
        return
    except Exception as e:
        logging.warning("insert_scan SQLite failed, CSV fallback: %s", e)
    # CSV fallback only if SQLite fails.
    with _CSV_LOCK:
        is_new = not SCANS_FILE.exists() or SCANS_FILE.stat().st_size == 0
        with open(SCANS_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if is_new:
                w.writerow(["timestamp", "competitor", "source_id", "room_type",
                            "price", "url", "status", "message"])
            w.writerow([now, competitor, source_id, room_type, price, url, status, message])


# ── Read ─────────────────────────────────────────────────────────────────────


def query_scans(days=90, limit=500, competitor=None, source_id=None):
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    where = ["timestamp >= ?"]
    params = [cutoff]
    if competitor:
        where.append("competitor = ?"); params.append(competitor)
    if source_id:
        where.append("source_id = ?"); params.append(source_id)
    params.append(limit)
    with db_conn() as conn:
        rows = conn.execute(
            f"SELECT * FROM scans WHERE {' AND '.join(where)} ORDER BY timestamp ASC LIMIT ?",
            params
        ).fetchall()
    return [dict(r) for r in rows]
