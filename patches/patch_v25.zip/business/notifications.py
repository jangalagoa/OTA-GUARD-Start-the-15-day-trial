import smtplib
import json
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime


def send_email(cfg, subject, body):
    server = cfg.get("server", "")
    port = int(cfg.get("port", 587))
    user = cfg.get("user", "")
    pwd = cfg.get("password", "")
    recipient = cfg.get("recipient", "")
    if not all([server, user, pwd, recipient]):
        return False, "Incomplete email configuration"
    try:
        msg = MIMEMultipart()
        msg["From"] = user
        msg["To"] = recipient
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain", "utf-8"))
        # I31: NEVER send user/password over an unencrypted connection.
        if port == 465:
            # Implicit TLS — no clear-text phase.
            with smtplib.SMTP_SSL(server, port, timeout=10) as s:
                s.login(user, pwd)
                s.sendmail(user, recipient, msg.as_string())
        else:
            with smtplib.SMTP(server, port, timeout=10) as s:
                s.ehlo()
                # Require STARTTLS and verify it succeeded (code 220)
                # BEFORE sending the credentials.
                code, _resp = s.starttls()
                if code != 220:
                    return False, f"STARTTLS refused (code {code}) — shipment cancelled"
                s.ehlo()
                s.login(user, pwd)
                s.sendmail(user, recipient, msg.as_string())
        return True, "OK"
    except Exception as e:
        return False, str(e)


def send_telegram(cfg, message):
    token = cfg.get("bot_token", "")
    chat_id = cfg.get("chat_id", "")
    if not token or not chat_id:
        return False, "Incomplete Telegram configuration"
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(url, json={"chat_id": chat_id, "text": message}, timeout=10)
        r.raise_for_status()
        return True, "OK"
    except Exception as e:
        return False, str(e)


def send_mobile_push(event, message, config=None):
    """Sends the alert to paired phones via Firebase (companion mobile app).

    Fails silently if the mobile gateway is not configured or
    if no phone is paired — never interrupts the other channels
    (convention D8, same logic as send_email/send_telegram above).

    Filter independent of the `triggers` of send_notifications: an event can
    stay active by email/Telegram while being cut off on the mobile side
    (config["mobile_notifications"] setting, Mobile App tab or the phone's
    Settings). Event absent from this setting → sent (original behavior
    kept for events not yet configured).
    """
    try:
        prefs = (config or {}).get("mobile_notifications", {})
        if event in prefs and not prefs[event]:
            return False, "Mobile notification disabled for this event"
        from business import firebase_client, mobile_gateway
        if not firebase_client.is_available():
            return False, "Firebase not connected"
        tokens = mobile_gateway.get_fcm_tokens()
        if not tokens:
            return False, "No paired phone"
        ok = firebase_client.send_push_alert(tokens, "OTA Guard", message)
        return ok, "OK" if ok else "Push shipment failure"
    except Exception as e:
        return False, str(e)


def _currency_symbol():
    """Hotel currency symbol (₹, €, $…) for the alert texts.

    LOCAL import: `core.utils` imports tkinter, while notifications
    are sent from scan threads. Any error falls back to ₹ — a
    display symbol never influences any price sent.
    """
    try:
        from core.utils import get_currency_symbol
        return get_currency_symbol() or "₹"
    except Exception:
        return "₹"


def _build_message(event, results, error=""):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    # A single call per message: the currency does not change mid-write.
    cur = _currency_symbol()

    if event == "scan_ok":
        lines = [f"✅ [{ts}] OTA scan finished"]
        for room, r in (results.items() if results else []):
            if r:
                lines.append(f"  • {room}: {cur}{int(r.get('final', 0)):,}")
        return "\n".join(lines)

    if event == "scan_error":
        return f"❌ [{ts}] OTA scan error\n{error}"

    if event == "price_applied":
        lines = [f"✅ [{ts}] Prices sent to the Channel Manager"]
        for room, r in (results.items() if results else []):
            if r:
                lines.append(f"  • {room}: {cur}{int(r.get('final', 0)):,}")
        return "\n".join(lines)

    if event == "price_gap_detected":
        # results = {room: {"detected": x, "target": y, "gap": z, "ota": name}}
        lines = [f"⚠️ [{ts}] Wrong price detected on OTA"]
        for room, r in (results.items() if results else []):
            ota     = r.get("ota", "OTA")
            det     = r.get("detected", 0)
            target  = r.get("target", 0)
            gap     = r.get("gap", 0)
            lines.append(
                f"  • {room} ({ota}): detected {cur}{int(det):,} "
                f"/ target {cur}{int(target):,} / gap {cur}{int(gap):,}")
        return "\n".join(lines)

    if event == "correction_envoyee":
        # results = {room: sent_price}
        lines = [f"🔧 [{ts}] Correction sent to the Channel Manager"]
        for room, prix in (results.items() if results else []):
            lines.append(f"  • {room}: {cur}{int(prix):,}")
        return "\n".join(lines)

    if event == "floor_violation":
        # results = {key: {"kind": "floor"|"ceiling", "room": str, "ota": str,
        #                  "scraped": price seen, "limit": bound, "needed": target price}}
        lines = [f"🛡️ [{ts}] Price outside the floor/ceiling bounds"]
        for _k, r in (results.items() if results else []):
            if not isinstance(r, dict):
                continue
            sens = "below the floor" if r.get("kind") == "floor" else "above the ceiling"
            lines.append(
                f"  • {r.get('room', '?')} ({r.get('ota', 'OTA')}): "
                f"{cur}{int(r.get('scraped', 0)):,} — {sens} "
                f"{cur}{int(r.get('limit', 0)):,}")
        lines.append("")
        lines.append("No price was sent to the Channel Manager "
                     "(alert-only mode).")
        return "\n".join(lines)

    if event == "competition_alert":
        return f"⚠️ [{ts}] Competition alert: a competitor is cheaper"

    return f"[{ts}] Event: {event}"


def send_notifications(event, results, config, error="", triggers=None):
    if triggers is None:
        triggers = config.get("automation", {}).get("triggers", {})
    if not triggers.get(event, False):
        return

    auto = config.get("automation", {})
    msg = _build_message(event, results, error)
    subj = f"Hotel Scraper — {event.replace('_', ' ').title()}"

    email_cfg = auto.get("email", {})
    if email_cfg.get("user"):
        send_email(email_cfg, subj, msg)

    tg_cfg = auto.get("telegram", {})
    if tg_cfg.get("bot_token"):
        send_telegram(tg_cfg, msg)

    send_mobile_push(event, msg, config)
