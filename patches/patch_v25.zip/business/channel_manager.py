"""
Push rates to the Channel Manager (channelmanager.com.au)
ChannelManager Australia native PMS API format
"""
import json
import logging
import time
import requests
from datetime import datetime, timedelta


def _is_test_mode(cfg):
    """C16: test_mode defaults to FALSE.

    Previously the default was True: if the `test_mode` key was missing from
    the config, NO rate/inventory/restriction was ever pushed to the
    Channel Manager — silently. Default changed to False (user confirmed)
    + visible WARNING when test mode is active.
    """
    tm = bool(cfg.get("test_mode", False))
    if tm:
        logging.warning(
            "[CM] test_mode ACTIVE — NO real shipment to the Channel Manager "
            "(rates/inventory/restrictions simulated only)."
        )
    return tm


def _hotel_code(cfg):
    return cfg.get("hotel_id", cfg.get("hotel_code", ""))


def _auth_code(cfg):
    return (cfg.get("api_token") or cfg.get("requestor_id") or "")


def weekend_rate_segments(base_price, checkin=None, nights=1,
                          enabled=True, pct=20.0, weekend_days=(4, 5)):
    """Splits [checkin, checkin+nights) into contiguous same-rate segments.

    Friday (weekday 4) and Saturday (5) → rate increased by `pct` % if `enabled`.
    Other days keep the `base_price` rate (weekday price).
    Contiguous days with the same price are merged into a single segment
    to limit the number of entries sent to the CM.

    Returns [(FromDate_iso, ToDate_iso, price_int), ...]  (ToDate exclusive).
    """
    if checkin is None:
        checkin = datetime.now().date().isoformat()
    start = datetime.fromisoformat(checkin).date()
    base = int(round(base_price))
    try:
        wknd = int(round(base * (1 + float(pct) / 100.0))) if enabled else base
    except (ValueError, TypeError):
        wknd = base
    n = max(1, int(nights))

    segs = []
    cur_from = None
    cur_price = None
    for i in range(n):
        d = start + timedelta(days=i)
        price = wknd if (enabled and d.weekday() in weekend_days) else base
        if cur_price is None:
            cur_from, cur_price = d, price
        elif price != cur_price:
            segs.append((cur_from.isoformat(), d.isoformat(), cur_price))
            cur_from, cur_price = d, price
    if cur_price is not None:
        end = start + timedelta(days=n)
        segs.append((cur_from.isoformat(), end.isoformat(), cur_price))
    return segs


def segments_skipping_locked(base_price, checkin, nights,
                             locked_dates=None, weekend_config=None):
    """Build dated price segments, **skipping locked dates** entirely.

    Locked dates produce NO segment — the CM keeps whatever price is
    already stored for those days.  Non-locked dates get the weekend
    markup applied (if ``weekend_config`` is provided), otherwise the
    base price.

    Parameters
    ----------
    base_price : float
        The normal (already discount-reversed) CM price.
    checkin : str
        ISO start date.
    nights : int
        Number of days to cover.
    locked_dates : set[str] | None
        Set of ``"YYYY-MM-DD"`` strings to skip.
    weekend_config : dict | None
        ``{"enabled": bool, "pct": float, "weekend_days": [int]}`` or None.

    Returns ``[(from_date_iso, to_date_iso, price), ...]`` with
    ToDate exclusive — same format as :func:`weekend_rate_segments`.
    """
    if checkin is None:
        checkin = datetime.now().date().isoformat()
    start = datetime.fromisoformat(checkin).date()
    base = int(round(base_price))
    n = max(1, int(nights))
    locked = locked_dates or set()

    # Weekend parameters
    wknd_enabled = bool(weekend_config and weekend_config.get("enabled"))
    try:
        wknd_pct = float(weekend_config.get("pct", 20)) if wknd_enabled else 0
    except (ValueError, TypeError):
        wknd_pct = 0.0
    wknd_days = set(weekend_config.get("weekend_days", [4, 5])) \
        if weekend_config else {4, 5}
    try:
        wknd_days = set(int(d) for d in wknd_days)
    except (ValueError, TypeError):
        wknd_days = {4, 5}
    wknd_price = int(round(base * (1 + wknd_pct / 100.0))) if wknd_enabled else base

    segs = []
    cur_from = None
    cur_price = None
    for i in range(n):
        d = start + timedelta(days=i)
        d_iso = d.isoformat()
        if d_iso in locked:
            # Close the current segment if any, then skip
            if cur_price is not None:
                segs.append((cur_from.isoformat(), d_iso, cur_price))
                cur_from, cur_price = None, None
            continue
        price = wknd_price if (wknd_enabled and d.weekday() in wknd_days) else base
        if cur_price is None:
            cur_from, cur_price = d, price
        elif price != cur_price:
            segs.append((cur_from.isoformat(), d_iso, cur_price))
            cur_from, cur_price = d, price
    if cur_price is not None:
        end = start + timedelta(days=n)
        segs.append((cur_from.isoformat(), end.isoformat(), cur_price))
    return segs


def build_rate_push_json(cfg, room_pushes, checkin=None, nights=1):
    """
    room_pushes = [{"room_code": "21704", "rate_plan_code": "3628", "price": 3500.0}, ...]
    checkin = ISO date or None (today)

    Each entry can carry its own "from_date"/"to_date" (price per date,
    e.g. weekend markup). Otherwise the global range [checkin, checkin+nights) is used.
    """
    if checkin is None:
        checkin = datetime.now().date().isoformat()
    default_checkout = (datetime.fromisoformat(checkin) + timedelta(days=nights)).date().isoformat()

    rates = []
    for rp in room_pushes:
        entry = {
            "FromDate":   rp.get("from_date") or checkin,
            "ToDate":     rp.get("to_date") or default_checkout,
            "RoomId":     str(rp["room_code"]),
            "RatePlanId": str(rp["rate_plan_code"]),
            "Rate":       str(int(rp["price"])),
        }
        ota_code = str(rp.get("ota_code", "")).strip()
        if ota_code:
            entry["OTASpecified"] = "true"
            entry["OTACode"]      = ota_code
        rates.append(entry)

    return {
        "Authentication": {
            "HotelCode": _hotel_code(cfg),
            "AuthCode":  _auth_code(cfg),
        },
        "Rates": {
            "Rate": rates
        }
    }


def build_inventory_push_json(cfg, room_pushes, checkin=None, nights=1):
    """
    room_pushes = [{"room_code": "21704", "available": 2}, ...]
    """
    if checkin is None:
        checkin = datetime.now().date().isoformat()
    checkout = (datetime.fromisoformat(checkin) + timedelta(days=nights)).date().isoformat()

    inventories = []
    for rp in room_pushes:
        inventories.append({
            "RoomId":             str(rp["room_code"]),
            "FromDate":           checkin,
            "ToDate":             checkout,
            "AvailableRoomCount": str(rp.get("available", 1)),
        })

    return {
        "Authentication": {
            "HotelCode": _hotel_code(cfg),
            "AuthCode":  _auth_code(cfg),
        },
        "Inventories": {
            "Inventory": inventories
        }
    }


def build_restriction_push_json(cfg, room_pushes, checkin=None, nights=1):
    """
    room_pushes = [{"room_code": "21704", "rate_plan_code": "3628",
                    "stop_sell": False, "min_nights": 1}, ...]
    """
    if checkin is None:
        checkin = datetime.now().date().isoformat()
    checkout = (datetime.fromisoformat(checkin) + timedelta(days=nights)).date().isoformat()

    restrictions = []
    for rp in room_pushes:
        restrictions.append({
            "RoomId":              str(rp["room_code"]),
            "RatePlanId":          str(rp["rate_plan_code"]),
            "FromDate":            checkin,
            "ToDate":              checkout,
            "StopSell":            str(rp.get("stop_sell", False)).lower(),
            "StopSellSpecified":   "true",
            "MinNights":           str(rp.get("min_nights", 1)),
            "MinNightsSpecified":  "true",
            "COA":                 str(rp.get("coa", False)).lower(),
            "COASpecified":        "true",
            "COD":                 str(rp.get("cod", False)).lower(),
            "CODSpecified":        "true",
        })

    return {
        "Authentication": {
            "HotelCode": _hotel_code(cfg),
            "AuthCode":  _auth_code(cfg),
        },
        "Restrictions": {
            "Restriction": restrictions
        }
    }


_MAX_RETRIES = 3
_RETRY_BACKOFF = [1, 2, 4]  # seconds between retries on 429


def _enforce_https(url: str, label: str = "") -> None:
    """S6: blocks the shipment if the URL is HTTP — the API token would be transmitted in clear text."""
    if url and not url.lower().startswith("https://"):
        msg = (
            f"[CM] {label or 'Endpoint'} '{url}' uses HTTP — "
            "shipment blocked to protect your API key. "
            "Configure an HTTPS URL."
        )
        logging.error(msg)
        raise ValueError(msg)


def _post(url, payload):
    """Sends a JSON POST with exponential retry on HTTP 429.
    Returns (ok, message, response_body)."""
    _enforce_https(url, "Channel Manager endpoint")
    last_err = ""
    for attempt in range(_MAX_RETRIES):
        try:
            r = requests.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=45
            )
            if r.status_code == 429:
                wait = _RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF) - 1)]
                logging.warning("Channel Manager: HTTP 429 — waiting %ds before retry (%d/%d)",
                                wait, attempt + 1, _MAX_RETRIES)
                time.sleep(wait)
                last_err = f"HTTP 429 (attempt {attempt + 1}/{_MAX_RETRIES})"
                continue
            body = r.text[:20000]
            try:
                data = r.json()
                api_resp = data.get("APIResponse")
                if isinstance(api_resp, dict) and "IsSuccess" in api_resp:
                    ok  = bool(api_resp.get("IsSuccess"))
                    msg = api_resp.get("APIResponseText", f"HTTP {r.status_code}")
                    err = api_resp.get("ErrorCode", "")
                    if err:
                        msg = f"{msg} — code {err}"
                else:
                    # 2xx response but without the expected IsSuccess field (unexpected
                    # API contract, proxy error page, etc.) — success cannot be
                    # assumed: a reported false failure is better than a false
                    # success that would hide a price never actually applied
                    # to the Channel Manager.
                    ok  = False
                    msg = f"Unexpected Channel Manager response (HTTP {r.status_code}, IsSuccess missing)"
            except Exception:
                ok  = False
                msg = f"Unreadable Channel Manager response (HTTP {r.status_code})"
            return ok, msg, body
        except Exception as e:
            last_err = str(e)
            if attempt < _MAX_RETRIES - 1:
                time.sleep(_RETRY_BACKOFF[attempt])
    return False, last_err, ""


# ── Default URLs ─────────────────────────────────────────────────────────────
BASE = "https://pmsapi.channelmanager.com.au/api/cmpms"
URL_RATE        = BASE + "/rateupdate"
URL_INVENTORY   = BASE + "/UpdateInventory"
URL_RESTRICTION = BASE + "/UpdateRestriction"
URL_ROOMINFO    = BASE + "/roominfo"
URL_OTA         = BASE + "/otaInfo"


def push_rates_to_cm(cfg, room_pushes, checkin=None, nights=1):
    """
    Sends the rates to the Channel Manager.
    Returns (ok: bool, message: str, response_body: str)
    """
    payload = build_rate_push_json(cfg, room_pushes, checkin, nights)

    if _is_test_mode(cfg):
        return True, "Test mode — no real shipment", json.dumps(payload, indent=2)

    endpoint = cfg.get("endpoint", cfg.get("rate_endpoint", URL_RATE)).strip()
    if not endpoint:
        endpoint = URL_RATE

    return _post(endpoint, payload)


def push_rates_to_cm_by_ota(cfg, room_pushes, checkin=None, nights=1,
                             delay_seconds=5, log_cb=None):
    """
    Like push_rates_to_cm, but a separate HTTP shipment per OTA (grouped by
    "ota_code" present in each room_pushes entry) instead of a single
    global shipment — with a pause between each shipment to avoid saturating
    the Channel Manager API key.

    Entries without "ota_code" (= applies to all OTAs, backward-compatible
    behavior) form their own group, sent separately.

    Returns a list of results, one per group:
    [{"ota_code": str, "ok": bool, "msg": str, "body": str, "n": int}, ...]
    """
    def _log(msg):
        if log_cb:
            log_cb(msg)

    groups = {}
    order = []
    for rp in room_pushes:
        key = str(rp.get("ota_code", "") or "").strip()
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(rp)

    results = []
    for i, key in enumerate(order):
        group = groups[key]
        label = key if key else "all OTAs"
        _log(f"[CM] Shipping {label} — {len(group)} rate(s)…")
        ok, msg, body = push_rates_to_cm(cfg, group, checkin, nights)
        _log(f"[CM] {'✅' if ok else '✗'} {label}: {msg}")
        results.append({"ota_code": key, "ok": ok, "msg": msg, "body": body, "n": len(group)})
        if i < len(order) - 1:
            time.sleep(delay_seconds)

    return results


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept on purpose; do not rely on it without rewiring and testing it first.
def push_inventory_to_cm(cfg, room_pushes, checkin=None, nights=1):
    """Sends availability to the Channel Manager."""
    payload = build_inventory_push_json(cfg, room_pushes, checkin, nights)

    if _is_test_mode(cfg):
        return True, "Test mode — no real shipment", json.dumps(payload, indent=2)

    return _post(URL_INVENTORY, payload)


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept on purpose; do not rely on it without rewiring and testing it first.
def push_restrictions_to_cm(cfg, room_pushes, checkin=None, nights=1):
    """Sends restrictions to the Channel Manager."""
    payload = build_restriction_push_json(cfg, room_pushes, checkin, nights)

    if _is_test_mode(cfg):
        return True, "Test mode — no real shipment", json.dumps(payload, indent=2)

    return _post(URL_RESTRICTION, payload)


def get_room_info(cfg):
    """Fetches the list of rooms and rate plans from ChannelManager."""
    payload = {
        "Authentication": {
            "HotelCode": _hotel_code(cfg),
            "AuthCode":  _auth_code(cfg),
        }
    }
    return _post(URL_ROOMINFO, payload)


def get_ota_info(cfg):
    """Fetches the list of connected OTAs."""
    payload = {
        "Authentication": {
            "HotelCode": _hotel_code(cfg),
            "AuthCode":  _auth_code(cfg),
        }
    }
    return _post(URL_OTA, payload)


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept on purpose; do not rely on it without rewiring and testing it first.
def push_rates_to_website(cfg, room_pushes):
    """
    Sends rates directly to the website (webhook or REST API).
    """
    if _is_test_mode(cfg):
        return True, "Test mode — no real shipment", str(room_pushes)

    url = cfg.get("url", "").strip()
    if not url:
        return False, "Website URL not configured.", ""

    token = cfg.get("api_key", "").strip()
    headers = {"Content-Type": "application/json"}
    if token:
        try:
            _enforce_https(url, "Website URL")
        except ValueError as _e:
            return False, str(_e), ""
        headers["Authorization"] = f"Bearer {token}"

    site_type = cfg.get("type", "webhook")

    if site_type == "wordpress":
        errors = []
        for rp in room_pushes:
            payload = {"meta": {f"price_{rp['room_slug']}": rp["price"]}}
            try:
                r = requests.post(
                    f"{url.rstrip('/')}/wp-json/wp/v2/posts/{rp.get('post_id','')}",
                    json=payload, headers=headers, timeout=15
                )
                if r.status_code >= 300:
                    errors.append(f"{rp['room_slug']}: HTTP {r.status_code}")
            except Exception as e:
                errors.append(f"{rp['room_slug']}: {e}")
        if errors:
            return False, " | ".join(errors), ""
        return True, f"{len(room_pushes)} room(s) updated", ""
    else:
        from datetime import datetime as _dt
        payload = {
            "timestamp": _dt.now().strftime("%Y-%m-%d %H:%M:%S"),
            "currency":  cfg.get("currency", "INR"),
            "rooms":     [{"room": rp["room_slug"], "price": rp["price"]} for rp in room_pushes]
        }
        try:
            r = requests.post(url, json=payload, headers=headers, timeout=15)
            return r.status_code < 300, f"HTTP {r.status_code}", r.text[:300]
        except Exception as e:
            return False, str(e), ""
