"""Annual price calendar — seasonal / event-based price overrides.

This module contains pure logic (no tkinter, no UI) for:
  • Resolving event dates (recurring events re-position automatically each year)
  • Looking up locked dates (protected from D+ adaptive push)
  • Looking up calendar prices for a given room + OTA

Config key: ``config["price_calendar"]``::

    {
        "events": [
            {
                "id":         "evt_a1b2",
                "name":       "Christmas",
                "start_date": "2026-12-23",
                "end_date":   "2026-12-27",
                "recurring":  True,
                "locked":     True,
                "enabled":    True,
                "rooms": {
                    "Deluxe Room": {
                        "_default":    3500,
                        "Booking.com": 3600,
                        "Agoda":       3500
                    }
                }
            }
        ]
    }
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Dict, Optional, Set, Tuple

_log = logging.getLogger(__name__)


# ── date helpers ──────────────────────────────────────────────────────

def _parse_iso(iso_str: str) -> Optional[date]:
    """Parse YYYY-MM-DD, return None on failure."""
    try:
        return datetime.fromisoformat(iso_str.strip()[:10]).date()
    except (ValueError, AttributeError, IndexError):
        return None


def resolve_event_dates(
    event: dict, ref_date: Optional[date] = None
) -> Tuple[Optional[date], Optional[date]]:
    """Return ``(start_date, end_date)`` for *event*.

    For recurring events the year is replaced with ``ref_date.year``
    (or the current year).  Year-spanning events (e.g. 30 Dec → 2 Jan)
    are handled by checking whether the end falls before the start.
    """
    ref = ref_date or date.today()
    start = _parse_iso(event.get("start_date", ""))
    end = _parse_iso(event.get("end_date", ""))
    if start is None or end is None:
        return None, None

    if event.get("recurring"):
        try:
            start = start.replace(year=ref.year)
            end = end.replace(year=ref.year)
        except ValueError:
            # Feb-29 on a non-leap year — shift to Feb-28
            start = start.replace(year=ref.year, day=28)
            end = end.replace(year=ref.year, day=28)
        # Event spanning new-year (start > end in the same year)
        if end < start:
            if ref.month >= 7:
                # We are in Jul-Dec → the event ends next year
                end = end.replace(year=ref.year + 1)
            else:
                # We are in Jan-Jun → the event started last year
                start = start.replace(year=ref.year - 1)
    elif end < start:
        # NON-recurring event whose end date is BEFORE its start — the
        # owner typed a new-year span (19/09 real case: 20/12/2026 →
        # 03/01/2026): the end obviously belongs to the NEXT year.
        # Without this the event was invisible to every check (locked
        # dates, active, upcoming) — "nothing works" for his real event.
        end = end.replace(year=end.year + 1)

    return start, end


# ── locked dates ─────────────────────────────────────────────────────

def get_locked_dates(
    config: dict, checkin_iso: str, nights: int
) -> Set[str]:
    """Return a set of ``"YYYY-MM-DD"`` strings for every date in
    ``[checkin, checkin+nights)`` that falls inside an **active AND
    locked** calendar event.

    Lock is room-agnostic: if an event is locked, *all* rooms are
    protected for its date range.
    """
    locked: Set[str] = set()
    events = config.get("price_calendar", {}).get("events", [])
    if not events:
        return locked

    start = _parse_iso(checkin_iso)
    if start is None:
        return locked
    n = max(1, int(nights))

    for event in events:
        if not isinstance(event, dict):
            continue
        if not event.get("locked") or not event.get("enabled", True):
            continue
        ev_start, ev_end = resolve_event_dates(event, start)
        if ev_start is None or ev_end is None:
            continue
        ev_end_inclusive = ev_end + timedelta(days=1)  # end date inclusive
        for i in range(n):
            d = start + timedelta(days=i)
            if ev_start <= d < ev_end_inclusive:
                locked.add(d.isoformat())

    return locked


# ── calendar prices ──────────────────────────────────────────────────

def get_calendar_prices(
    config: dict, checkin_iso: str, nights: int,
    room: str, ota_name: str
) -> Dict[str, float]:
    """Return ``{date_iso: price}`` for dates in the range where an
    active event defines a price for *room* + *ota_name*.

    Lookup order: ``rooms[room][ota_name]`` (case-insensitive) then
    ``rooms[room]["_default"]``.
    """
    result: Dict[str, float] = {}
    events = config.get("price_calendar", {}).get("events", [])
    if not events:
        return result

    start = _parse_iso(checkin_iso)
    if start is None:
        return result
    n = max(1, int(nights))
    ota_lower = (ota_name or "").strip().lower()

    for event in events:
        if not isinstance(event, dict):
            continue
        if not event.get("enabled", True):
            continue
        ev_start, ev_end = resolve_event_dates(event, start)
        if ev_start is None or ev_end is None:
            continue
        ev_end_inclusive = ev_end + timedelta(days=1)

        room_prices = event.get("rooms", {}).get(room)
        if not room_prices:
            continue

        # OTA-specific price (case-insensitive) or _default
        price = None
        for k, v in room_prices.items():
            if k.lower() == ota_lower and v:
                price = float(v)
                break
        if price is None:
            _d = room_prices.get("_default")
            if _d:
                price = float(_d)
        if price is None:
            continue

        for i in range(n):
            d = start + timedelta(days=i)
            if ev_start <= d < ev_end_inclusive:
                result[d.isoformat()] = price

    return result


# ── misc ─────────────────────────────────────────────────────────────

def has_any_event(config: dict) -> bool:
    """True if the calendar has at least one event defined."""
    events = config.get("price_calendar", {}).get("events", [])
    return bool(events)
