"""
activity_log.py — Complete traceability of the OTA Guard session.

PURPOSE
-------
A SINGLE file (activity_log.txt (software root)) that records EVERYTHING that happens
while the software is used, including what the user does NOT see:

  • User interactions (tab navigation, clicks, scan launches…)              → log_ui()
  • What the software does internally (scan, engines, CM push…)             → log_event()
  • HIDDEN FAILURES: all existing DEBUG logging (where most of the
    `except: log.debug(...)` already live), uncaught exceptions in
    threads, and Tkinter callback crashes (a click that
    "does nothing").

By reading activity_log.txt (software root), the whole session can be reconstructed
and "it worked" can be distinguished from "it failed silently".

USAGE
-----
    from business.activity_log import init_activity_log, log_ui, log_event
    init_activity_log()                      # once, at the very beginning (main.py)
    log_ui("Click", button="Start scan")     # user interaction
    log_event("SCAN", "Agoda → 3 prices", ok=True)

The module NEVER raises an exception towards the caller (traceability must
never break the application).
"""
import logging
import logging.handlers
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

from core.paths import DATA_DIR

# ── D97: bootstrap of the signed patch loader ───────────────────────────────
# main.py imports THIS module very early, BEFORE its --diagnostic branch and
# BEFORE its own apply_early (__main__ block). Without this call, the
# diagnostic mode of an old exe loaded its COMPILED diagnostic modules
# (pre-fixes): the signed patch could never act on that path.
# apply_early is idempotent, local (no network) and never fatal.
try:
    from core.patch_loader import apply_early as _patch_bootstrap
    _patch_bootstrap()
except Exception:
    pass

# Inside data/ (the only folder guaranteed writable once installed).
ACTIVITY_FILE = DATA_DIR / "activity_log.txt"

# Beyond this size at startup, the current file is archived and we start
# clean (keeps the active file readable and bounded). The archive keeps the
# previous history: activity_log_<timestamp>.txt (software root)
_MAX_SIZE_BYTES = 5 * 1024 * 1024   # 5 MB

# Dedicated logger for explicit events (UI / application events).
_act = logging.getLogger("ACTIVITY")

# Noisy third-party libraries: capped at WARNING so they do not drown the file.
_NOISY = ("matplotlib", "urllib3", "selenium", "playwright", "PIL", "asyncio",
          "fontTools", "comtypes", "websockets", "httpx", "httpcore", "PIL.PngImagePlugin")

_initialized = False
_lock = threading.Lock()


# ── Format ───────────────────────────────────────────────────────────────────

class _ActivityFormatter(logging.Formatter):
    """HH:MM:SS.mmm [LEVEL ] logger | message"""
    def format(self, record):
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        ms = int(record.msecs)
        lvl = record.levelname[:7]
        name = record.name
        # Shorten overly long logger names (scraping.scraping → s.scraping)
        if name.startswith("scraping."):
            name = name.split(".", 1)[1]
        msg = record.getMessage()
        line = f"{ts}.{ms:03d} [{lvl:<7}] {name:<22} | {msg}"
        if record.exc_info:
            line += "\n" + "".join(traceback.format_exception(*record.exc_info)).rstrip()
        return line


# ── Simple rotation at startup ───────────────────────────────────────────────

def _rotate_if_large():
    try:
        if ACTIVITY_FILE.exists() and ACTIVITY_FILE.stat().st_size > _MAX_SIZE_BYTES:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            archive = DATA_DIR / f"activity_log_{stamp}.txt"
            ACTIVITY_FILE.replace(archive)
    except Exception:
        pass


# ── Initialization ───────────────────────────────────────────────────────────

def init_activity_log() -> None:
    """Installs global traceability. Idempotent — callable multiple times."""
    global _initialized
    with _lock:
        if _initialized:
            return
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            _rotate_if_large()

            handler = logging.FileHandler(ACTIVITY_FILE, encoding="utf-8", mode="a")
            handler.setLevel(logging.DEBUG)
            handler.setFormatter(_ActivityFormatter())
            handler._is_activity_handler = True   # anti-duplicate marker

            root = logging.getLogger()
            # Avoid adding the handler twice (restart / re-import)
            if not any(getattr(h, "_is_activity_handler", False) for h in root.handlers):
                root.addHandler(handler)

            # The root level must go down to DEBUG so hidden failures
            # (log.debug) reach the activity file…
            root.setLevel(logging.DEBUG)
            # …but EXISTING handlers (console, ota_guard.log) stay at
            # INFO so they are not flooded with DEBUG.
            for h in root.handlers:
                if getattr(h, "_is_activity_handler", False):
                    continue
                if h.level < logging.INFO:
                    h.setLevel(logging.INFO)

            # Silence noisy third-party libraries.
            for name in _NOISY:
                logging.getLogger(name).setLevel(logging.WARNING)

            _install_excepthooks()

            _initialized = True
            _banner()
        except Exception:
            # Traceability must never prevent the app from starting.
            pass


def _banner():
    try:
        from version import VERSION
    except Exception:
        VERSION = "?"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bar = "=" * 78
    _act.info(bar)
    _act.info("SESSION %s  —  OTA Guard v%s", now, VERSION)
    _act.info(bar)


# ── Capture of uncaught exceptions ───────────────────────────────────────────

def _install_excepthooks():
    # 1. Uncaught exceptions of the main thread
    _prev_hook = sys.excepthook

    def _hook(exc_type, exc_value, exc_tb):
        try:
            _act.critical("UNCAUGHT EXCEPTION (main thread)",
                          exc_info=(exc_type, exc_value, exc_tb))
        except Exception:
            pass
        if _prev_hook:
            try:
                _prev_hook(exc_type, exc_value, exc_tb)
            except Exception:
                pass

    sys.excepthook = _hook

    # 2. Uncaught exceptions in threads (scans, scheduler…)
    if hasattr(threading, "excepthook"):
        _prev_thook = threading.excepthook

        def _thook(args):
            try:
                import traceback as _tb
                from business.diagnostics import record_error
                record_error(
                    f"thread:{getattr(args, 'thread', None) and args.thread.name}",
                    "".join(_tb.format_exception(
                        args.exc_type, args.exc_value,
                        args.exc_traceback))[-600:])
            except Exception:
                pass
            try:
                _act.critical("UNCAUGHT EXCEPTION (thread '%s')",
                              getattr(args, "thread", None) and args.thread.name,
                              exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
            except Exception:
                pass
            if _prev_thook:
                try:
                    _prev_thook(args)
                except Exception:
                    pass

        threading.excepthook = _thook


def install_tk_excepthook(root) -> None:
    """Captures exceptions from Tkinter callbacks (a click that 'does nothing').

    To be called from App.__init__ with the root window. Without this, Tkinter
    swallows the handler exception and just writes it to stderr → invisible.
    """
    try:
        def _report(exc, val, tb):
            try:
                # D39: feed the diagnostic ring (reported to the vendor
                # via the ops channel — no sensitive content, just the trace)
                import traceback as _tb
                from business.diagnostics import record_error
                record_error("ui", "".join(
                    _tb.format_exception(exc, val, tb))[-600:])
            except Exception:
                pass
            try:
                _act.error("EXCEPTION IN A UI CALLBACK (a click/action failed)",
                           exc_info=(exc, val, tb))
            except Exception:
                pass
        root.report_callback_exception = _report
    except Exception:
        pass


# ── Public API ───────────────────────────────────────────────────────────────

def _fmt_details(details: dict) -> str:
    if not details:
        return ""
    parts = []
    for k, v in details.items():
        if k == "ok":
            continue
        parts.append(f"{k}={v}")
    return ("  {" + ", ".join(parts) + "}") if parts else ""


def log_ui(action: str, **details) -> None:
    """User interaction (click, navigation, validated input…)."""
    try:
        _act.info("👤 %s%s", action, _fmt_details(details))
    except Exception:
        pass


def log_event(category: str, message: str, ok: bool = None, **details) -> None:
    """Internal application event.

    ok=True  → ✅ success
    ok=False → ❌ failure (often invisible to the user)
    ok=None  → neutral information
    """
    try:
        mark = "" if ok is None else ("✅ " if ok else "❌ ")
        lvl = logging.INFO if ok is not False else logging.WARNING
        _act.log(lvl, "[%s] %s%s%s", category, mark, message, _fmt_details(details))
    except Exception:
        pass


def section(title: str) -> None:
    """Visually separates a new phase (e.g. start of a full scan)."""
    try:
        _act.info("──────── %s ────────", title)
    except Exception:
        pass
