"""
Global logger — writes to data/app.log + notifies UI callbacks in real time.
Usage:
    from business.app_logger import app_log
    app_log("Price found: 4500", level="price", engine="AGODA")
"""
import re
import threading
import datetime
from pathlib import Path

# ── Sensitive data filter ────────────────────────────────────────────────────
# Masks API keys, tokens and passwords in logged messages.
_SENSITIVE_PATTERNS = [
    # Long API keys (e.g. AIzaSy..., sk-ant-..., gsk_...)
    (re.compile(r'(AIza[A-Za-z0-9_\-]{30,})', re.I),      r'AIza***'),
    (re.compile(r'(sk-ant-[A-Za-z0-9_\-]{10,})', re.I),   r'sk-ant-***'),
    (re.compile(r'(sk-proj-[A-Za-z0-9_\-]{10,})', re.I),  r'sk-proj-***'),
    (re.compile(r'(gsk_[A-Za-z0-9_\-]{10,})', re.I),      r'gsk_***'),
    (re.compile(r'(Bearer\s+)[A-Za-z0-9_\-\.]{16,}', re.I), r'\1***'),
    # Sensitive URL parameters (?key=, ?token=, ?auth=)
    (re.compile(r'([?&](key|token|auth|api_key|secret)=)[^&\s"\']{6,}', re.I),
     r'\1***'),
    # Generic patterns: "token": "xxxx", "api_key": "xxxx"
    (re.compile(r'("(?:token|api_token|api_key|password|secret|auth_?code)"'
                r'\s*:\s*")[^"]{6,}(")', re.I), r'\1***\2'),
]


def _sanitize(msg: str) -> str:
    """Masks sensitive data in a message before writing."""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        msg = pattern.sub(replacement, msg)
    return msg

from core.paths import DATA_DIR
_lock      = threading.Lock()
_callbacks = []          # list of (callable) — the UI registers here
_LOG_FILE  = DATA_DIR / "app.log"
_MAX_BYTES = 3 * 1024 * 1024   # rotation at 3 MB

# Recognized levels (match the Tk tags in the Journal)
LEVELS = {"info", "ok", "warn", "error", "browser", "price", "head", "scan"}


def app_log(msg: str, level: str = "info", engine: str = ""):
    """Records a line in the global journal.

    level  : info | ok | warn | error | browser | price | head | scan
    engine : e.g. "AGODA", "INTEL", "VISUAL", "SCAN", "CALIB"
    """
    # D81: the DATE is part of the timestamp — without it, lines from
    # different days mixed together indistinguishably in app.log (the
    # 09/20 audit chased a "second sender" that was in reality lines
    # from 08/29).
    ts  = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    tag = f"[{engine}] " if engine else ""
    line = f"[{ts}] {tag}{_sanitize(msg)}\n"

    # File write (thread-safe)
    with _lock:
        try:
            _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
            if _LOG_FILE.exists() and _LOG_FILE.stat().st_size > _MAX_BYTES:
                bak = _LOG_FILE.with_suffix(".log.bak")
                try:
                    bak.unlink(missing_ok=True)
                    _LOG_FILE.rename(bak)
                except Exception:
                    pass
            with open(_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass

    # Notify the UI callbacks
    for cb in list(_callbacks):
        try:
            cb(line, level)
        except Exception:
            pass


def register_callback(cb):
    """Registers a callback(line: str, level: str) for UI updates."""
    if cb not in _callbacks:
        _callbacks.append(cb)


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept on purpose; do not rely on it without rewiring and testing it first.
def unregister_callback(cb):
    """Removes a callback (called when the tab is destroyed)."""
    try:
        _callbacks.remove(cb)
    except ValueError:
        pass


def get_recent(n: int = 500) -> list[str]:
    """Returns the last n lines of the log file."""
    try:
        if not _LOG_FILE.exists():
            return []
        with open(_LOG_FILE, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        return lines[-n:]
    except Exception:
        return []


def clear_log():
    """Clears the log file."""
    try:
        if _LOG_FILE.exists():
            _LOG_FILE.unlink()
    except Exception:
        pass
