"""
mobile_commands.py — Listens for commands sent by the companion mobile app
(Firestore "commands" collection) and forwards them to the main Tkinter thread.

This module neither DECIDES nor EXECUTES anything itself: it receives a command,
ignores the already-processed ones, then calls a handler provided by the app ON
THE MAIN THREAD (via root.after). The actual execution (with the min/max
safeguard checks) is done by the app — the PC remains the final guardian.

⚠ The Firestore callback runs on a thread INTERNAL to the Firebase SDK, NOT
the Tkinter thread. Touching the UI directly from that thread would crash
Tkinter — hence the systematic pass through root.after(0, ...).

Fail-safe (convention D8): if firebase-admin is missing, if no service
account is configured, or if the connection fails, start_gateway() returns
False without breaking anything — the app runs normally without the mobile gateway.
"""
import logging

log = logging.getLogger(__name__)

COMMANDS_COLLECTION = "commands"

_started = False
_seen_ids = set()   # ids of already-forwarded commands (avoids ADDED/MODIFIED duplicates)


def start_gateway(app) -> bool:
    """Initializes Firebase (if a service account is configured) and starts
    listening for the phone's commands. Idempotent — a 2nd call does nothing.

    Returns True if the listener is active, False otherwise (unconfigured / failure).
    Never raises.
    """
    global _started
    if _started:
        return True

    # 1. Firebase service account (secret, DPAPI-encrypted)
    try:
        from business.secrets import load_secrets
        sa = load_secrets().get("firebase_service_account") or {}
    except Exception:
        sa = {}
    if not sa.get("project_id"):
        return False  # no service account → mobile gateway disabled

    # 2. Firebase connection (reuses the already-open one if present)
    try:
        from business import firebase_client
        if not firebase_client.is_available():
            if not firebase_client.init_firebase(sa):
                return False
    except Exception:
        log.exception("mobile_commands: Firebase init failure")
        return False

    # 3. Handler on the app side (executed on the main thread)
    handler = getattr(app, "_on_mobile_command", None)
    if not callable(handler):
        return False

    def _on_command(doc_id, data):
        # ⚠ Internal Firebase SDK thread — NEVER touch the UI here.
        try:
            if not isinstance(data, dict):
                return
            if data.get("status") != "pending":
                return
            if doc_id in _seen_ids:
                return
            _seen_ids.add(doc_id)
            # Back to the main Tkinter thread before any processing.
            app.root.after(0, lambda: handler(doc_id, data))
        except Exception:
            log.exception("mobile_commands: error dispatching a command")

    # 4. Start of the listener
    try:
        from business import firebase_client
        watch = firebase_client.listen_for_commands(COMMANDS_COLLECTION, _on_command)
        if watch is None:
            return False
        _started = True
        log.info("mobile_commands: listening for the phone's commands started")
        return True
    except Exception:
        log.exception("mobile_commands: listener startup failure")
        return False


def update_command_status(doc_id: str, status: str, detail: str = "") -> bool:
    """Updates the status of a command in Firestore (feedback towards the
    phone: "received" / "applied" / "rejected"). Fail-safe.
    """
    try:
        from business import firebase_client
        if not firebase_client.is_available():
            return False
        return firebase_client.publish_document(
            COMMANDS_COLLECTION, doc_id,
            {"status": status, "pc_detail": detail},
            merge=True,
        )
    except Exception:
        log.exception("mobile_commands: update_command_status(%s) failure", doc_id)
        return False


def stop_gateway() -> None:
    """Stops the listener and closes the Firebase connection (on app close)."""
    global _started
    try:
        # D62: the old code called a "scraping" package that no longer
        # exists in V3 — the Firebase listener was therefore NEVER stopped
        # on close. We call the real module.
        from business import firebase_client as _fc
        _fc.shutdown()
    except Exception:
        log.exception("mobile_commands: Firebase listener shutdown failed")
    _started = False
    _seen_ids.clear()
