"""
Secrets manager — reads data/secrets.json and injects the sensitive
values into the config at load time.

data/secrets.json must NEVER be shared, committed or backed up
to an unencrypted cloud space.

Encryption: on Windows the content is encrypted via DPAPI
(Windows Data Protection API, built-in ctypes — no external dependency).
The file can only be decrypted by the same Windows account on the same
machine.  On other OSes, plain JSON fallback + chmod 600.
"""
import json
import os
import sys
import logging
from pathlib import Path

from core.paths import DATA_DIR
SECRETS_FILE = DATA_DIR / "secrets.json"

# Binary prefix identifying a DPAPI-encrypted file
_DPAPI_MAGIC = b"DPAPI1:"


# ── DPAPI encryption (Windows) ────────────────────────────────────────────────

def _dpapi_available() -> bool:
    return sys.platform == "win32"


def _dpapi_encrypt(data: bytes) -> bytes:
    """Encrypt `data` with CryptProtectData (Windows DPAPI).
    Only the same Windows account can decrypt the result.
    Raises OSError if the API fails.
    """
    import ctypes
    import ctypes.wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", ctypes.wintypes.DWORD),
                    ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    buf = (ctypes.c_ubyte * len(data))(*data)
    bi  = _BLOB(len(data), buf)
    bo  = _BLOB()

    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(bi), None, None, None, None, 0, ctypes.byref(bo)
    )
    if not ok:
        raise OSError(f"CryptProtectData failed (code {ctypes.GetLastError()})")

    result = bytes(
        ctypes.cast(bo.pbData, ctypes.POINTER(ctypes.c_ubyte * bo.cbData)).contents
    )
    ctypes.windll.kernel32.LocalFree(bo.pbData)
    return result


def _dpapi_decrypt(data: bytes) -> bytes:
    """Decrypt `data` with CryptUnprotectData (Windows DPAPI).
    Raises OSError if the API fails (wrong user, corrupted file, etc.).
    """
    import ctypes
    import ctypes.wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", ctypes.wintypes.DWORD),
                    ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    buf = (ctypes.c_ubyte * len(data))(*data)
    bi  = _BLOB(len(data), buf)
    bo  = _BLOB()

    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(bi), None, None, None, None, 0, ctypes.byref(bo)
    )
    if not ok:
        raise OSError(f"CryptUnprotectData failed (code {ctypes.GetLastError()})")

    result = bytes(
        ctypes.cast(bo.pbData, ctypes.POINTER(ctypes.c_ubyte * bo.cbData)).contents
    )
    ctypes.windll.kernel32.LocalFree(bo.pbData)
    return result


def _write_secrets_encrypted(path: Path, data: dict) -> None:
    """Write `data` to `path` atomically, DPAPI-encrypted when available.

    File format:
      - Encrypted   : b"DPAPI1:" + <CryptProtectData binary blob>
      - Unencrypted : plain UTF-8 JSON (Unix fallback / DPAPI error)
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    plain = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")

    try:
        if _dpapi_available():
            content = _DPAPI_MAGIC + _dpapi_encrypt(plain)
            with open(tmp, "wb") as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
        else:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        raise


def atomic_write_json(path, data, indent=2):
    """Write `data` as JSON atomically: .tmp file + os.replace().

    Prevents corruption (config.json / secrets.json / wizard_progress.json)
    if the process is interrupted mid-write. Raises the exception on
    failure — the caller decides whether to surface it.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        raise

# ── Adding a new secret: update ONLY ──────────────────────────────────────────
# 1. _SECRETS_TEMPLATE below          (key in secrets.json)
# 2. inject_secrets()                 (re-injection at load time)
# strip_secrets() NO LONGER NEEDS CHANGES — _scrub_tree() automatically removes
# any field whose name appears in _SECRET_FIELDNAMES.
_SECRETS_TEMPLATE = {
    "dashboard_password": "",
    "email_password": "",
    "telegram_bot_token": "",
    "whatsapp_access_token": "",
    "channel_manager_api_token": "",
    # S4: IMAP/POP3 passwords — never stored in config.json
    # key = account email address, value = password / app password
    "imap_passwords": {},
    # OTA extranet passwords (OTA Direct Push tab) — never in plain text
    # in ota_direct_config.json. key = ota_id, value = extranet password.
    "ota_direct_passwords": {},
    # CAPTCHA provider keys (multi-service selector).
    # Each config["anticaptcha"]["providers"][id]["api_key"] field is named
    # "api_key": it is therefore removed from config.json by _scrub_tree and MUST
    # be re-injected by inject_secrets below — otherwise the entered key
    # disappears at every restart.
    "captcha_nopecha_key": "",
    "captcha_anticaptcha_key": "",
    "captcha_capmonster_key": "",
    "captcha_twocaptcha_key": "",
    # Legacy field (before the multi-service selector, single NopeCHA
    # key) — kept so an already-saved key is not lost;
    # inject_secrets() falls back to it when captcha_nopecha_key is empty.
    "anticaptcha_api_key": "",
    # Companion mobile app: Firebase service account (Admin SDK, PC only).
    # Like imap_passwords, NEVER injected into config.json — loaded directly
    # by scraping/firebase_client.py and the Mobile app tab via load_secrets().
    "firebase_service_account": {},
}


def load_secrets() -> dict:
    """Load secrets.json (DPAPI-encrypted or plain JSON).

    Detects the format automatically via the _DPAPI_MAGIC prefix.
    Backward compatible: reads old plain JSON files and migrates them
    to the encrypted format at the next save_secrets() call.
    Returns {} on error (invalid key, corrupted file, etc.).
    """
    if not SECRETS_FILE.exists():
        _create_empty_secrets()
        return {}
    try:
        raw = SECRETS_FILE.read_bytes()
        if raw.startswith(_DPAPI_MAGIC):
            # DPAPI-encrypted file — decrypt
            decrypted = _dpapi_decrypt(raw[len(_DPAPI_MAGIC):])
            return json.loads(decrypted.decode("utf-8"))
        else:
            # Plain JSON file (old format) — read normally
            # It will be encrypted automatically at the next save_secrets()
            return json.loads(raw.decode("utf-8"))
    except Exception as e:
        logging.warning("load_secrets: cannot read/decrypt secrets.json: %s", e)
        return {}


def _create_empty_secrets():
    """Create an empty (encrypted) secrets.json from the template."""
    try:
        _write_secrets_encrypted(SECRETS_FILE, _SECRETS_TEMPLATE)
        _restrict_secrets_permissions(SECRETS_FILE)
    except Exception:
        logging.exception("Cannot create secrets.json")


def _restrict_secrets_permissions(path):
    """S5: restrict secrets.json read access to the current user only.

    Windows: icacls /inheritance:r /grant:r USER:(R,W)
    Unix    : chmod 600
    Silent on failure (insufficient rights, etc.).
    """
    import sys, subprocess
    path = str(path)
    if sys.platform == "win32":
        try:
            username = os.environ.get("USERNAME", "")
            if username:
                subprocess.run(
                    ["icacls", path, "/inheritance:r",
                     "/grant:r", f"{username}:(R,W)"],
                    check=False, capture_output=True, timeout=5,
                )
        except Exception:
            pass
    else:
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass


def save_secrets(secrets: dict) -> None:
    """Merge `secrets` into secrets.json, encrypt with DPAPI and write atomically.

    Only non-empty keys overwrite existing values (a secret already stored
    is never erased by an empty value coming from the UI).
    The resulting file is encrypted via CryptProtectData (Windows DPAPI):
    unreadable in a text editor, decryptable only by the same Windows
    account on the same machine.
    """
    current = load_secrets()
    if not isinstance(current, dict):
        current = {}
    for k, v in (secrets or {}).items():
        if v in ("", None, [], {}):
            continue
        # S4: deep merge for imap_passwords (dict)
        if k == "imap_passwords" and isinstance(v, dict) and isinstance(current.get(k), dict):
            current[k].update(v)
        else:
            current[k] = v
    _write_secrets_encrypted(SECRETS_FILE, current)
    _restrict_secrets_permissions(SECRETS_FILE)


def inject_secrets(config: dict) -> dict:
    """
    Inject the secrets into the config (in-place).
    secrets.json values override config.json values for sensitive fields.
    Returns the enriched config.
    """
    s = load_secrets()
    if not s:
        return config

    auto = config.setdefault("automation", {})

    if s.get("dashboard_password"):
        config["dashboard_password"] = s["dashboard_password"]

    if s.get("email_password"):
        auto.setdefault("email", {})["password"] = s["email_password"]

    if s.get("telegram_bot_token"):
        auto.setdefault("telegram", {})["bot_token"] = s["telegram_bot_token"]

    if s.get("whatsapp_access_token"):
        auto.setdefault("whatsapp", {})["access_token"] = s["whatsapp_access_token"]

    if s.get("channel_manager_api_token"):
        config.setdefault("channel_manager", {})["api_token"] = s["channel_manager_api_token"]

    captcha_providers = config.setdefault("anticaptcha", {}).setdefault("providers", {})
    _CAPTCHA_INJECT = {
        "captcha_nopecha_key": "nopecha",
        "captcha_anticaptcha_key": "anticaptcha",
        "captcha_capmonster_key": "capmonster",
        "captcha_twocaptcha_key": "twocaptcha",
    }
    for sk, provider in _CAPTCHA_INJECT.items():
        if s.get(sk):
            captcha_providers.setdefault(provider, {})["api_key"] = s[sk]
    # Compat: legacy single key (before the multi-service selector) → NopeCHA.
    if not captcha_providers.get("nopecha", {}).get("api_key") and s.get("anticaptcha_api_key"):
        captcha_providers.setdefault("nopecha", {})["api_key"] = s["anticaptcha_api_key"]

    # P7: IMAP/POP3 passwords are NO LONGER injected into the config dict.
    # They are loaded directly by EmailMonitor via imap_passwords= at
    # engine construction (load_secrets() in _make_engine), which prevents
    # the passwords from travelling in the config and being exposed by deepcopy.

    return config


# Field names that must never appear in plain text in config.json.
# _scrub_tree() walks the whole tree recursively — any future field
# carrying one of these names is removed automatically, without editing
# this file. If a new secret has a different name → add it here only.
_SECRET_FIELDNAMES = frozenset({
    "api_key", "api_keys", "api_token",
    "password", "dashboard_password",
    "bot_token", "access_token",
    "AuthCode",
})


def _scrub_tree(obj: object) -> None:
    """Recursively remove any field whose name is in _SECRET_FIELDNAMES."""
    if isinstance(obj, dict):
        for key in _SECRET_FIELDNAMES:
            obj.pop(key, None)
        for v in obj.values():
            _scrub_tree(v)
    elif isinstance(obj, list):
        for item in obj:
            _scrub_tree(item)


def strip_secrets(config: dict) -> dict:
    """Return a copy of config with no sensitive field at all.

    Uses _scrub_tree (recursive scrubber by field name) — any new
    provider or path is covered automatically, without editing this code.
    Only manual addition needed for a new secret: _SECRETS_TEMPLATE
    + inject_secrets().
    """
    import copy
    c = copy.deepcopy(config)
    _scrub_tree(c)
    return c
