"""business/seasonal_nav.py — Phase 2: verification of FUTURE events (D67).

For an upcoming locked event, bring each profile's OTA tab to the event's
dates (the BROWSER loads the page — R4/R1),
let VAE1 capture the displayed prices, scan, compare against the locked
price, then BRING the tab back to its original URL.

Rules respected:
  - EXISTING tab only: never opened, never closed (owner policy);
    a profile without an open tab is reported and skipped;
  - slow navigation, ONE OTA at a time (anti-bot doctrine);
  - D52 lock: a single operation at a time ("seasonal verification");
  - NOTHING is sent to the CM — read + report; correction stays with the
    "Push the locked prices" button.
  - Airbnb excluded for now: its dates cannot be set via the URL
    (interactive calendar) — phase 3.

Date formats: ONLY the date parameters ALREADY present in the profile's
URL are rewritten, in the format THAT profile already uses —
no invented parameter.
"""

import json
import re
import threading
import time
import urllib.parse
import urllib.request
from datetime import date, timedelta

from core.utils import tr_

_NAV_WAIT_S = 18        # page load + VAE1 capture (human-like navigation)
_RESTORE_WAIT_S = 6

# families: param -> strftime of the format THE PROFILE ALREADY USES
_DATE_PARAMS = {
    "checkin":  {"agoda": "%Y-%m-%d", "goibibo": "%Y%m%d",
                 "makemytrip": "%m%d%Y"},
    "check_in": {"agoda": "%Y-%m-%d"},
    "check_out": {"agoda": "%Y-%m-%d"},
    "checkout": {"goibibo": "%Y%m%d", "makemytrip": "%m%d%Y"},
    "chkin":    {"expedia": "%Y-%m-%d"},
    "chkout":   {"expedia": "%Y-%m-%d"},
}


def _fmt_for(host: str, param: str):
    for dom, fmt in _DATE_PARAMS.get(param, {}).items():
        if dom in host:
            return fmt
    return None


def dated_url(url: str, checkin: date) -> str:
    """Profile URL with its own date parameters rewritten to the
    (start of the) event's stay. None if no known date parameter
    (family not URL-drivable)."""
    parts = urllib.parse.urlsplit(url)
    host = (parts.netloc or "").lower()
    query = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    checkout = checkin + timedelta(days=1)
    changed = False
    out = []
    for k, v in query:
        fmt = _fmt_for(host, k.lower())
        if fmt is None:
            out.append((k, v))
            continue
        d = checkout if k.lower() in ("checkout", "chkout", "check_out") \
            else checkin
        out.append((k, d.strftime(fmt)))
        changed = True
    if not changed:
        return None
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, parts.path,
         urllib.parse.urlencode(out), parts.fragment))


def _tabs(port=9222):
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/json/list", timeout=3) as r:
            return [t for t in json.loads(r.read().decode())
                    if t.get("type") == "page"]
    except Exception:
        return []


def _find_tab(url_fragment, port=9222):
    frag = (url_fragment or "").lower()
    frag = frag.split("//")[-1].split("/")[0]
    for t in _tabs(port):
        if frag and frag in (t.get("url") or "").lower():
            return t
    return None


def _navigate(tab, url, port=9222, wait_s=_NAV_WAIT_S, log=print):
    """Page.navigate on the EXISTING tab (keepalive recipe: CDP
    websocket, the browser loads by itself — R4). True if the command
    went through."""
    try:
        import websockets

        async def _go():
            ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                          max_size=10 * 1024 * 1024)
            try:
                await ws.send(json.dumps({
                    "id": 1, "method": "Page.navigate",
                    "params": {"url": url}}))
                while True:
                    data = json.loads(await asyncio_wait_for(ws))
                    if data.get("id") == 1:
                        return True
            finally:
                try:
                    await ws.close()
                except Exception:
                    pass

        import asyncio
        ok = asyncio.run(_go())
        if ok and wait_s:
            log(f"      navigation → loading ({wait_s} s, human-like)")
            time.sleep(wait_s)
        return ok
    except Exception as e:
        log(f"      navigation impossible: {e}")
        return False


def asyncio_wait_for(ws):
    import asyncio
    return asyncio.wait_for(ws.recv(), timeout=20)


def verify_future_event(app_config, event, log=print,
                        progress=None, ui=None) -> dict:
    """Verifies ONE future event on the URL-drivable OTAs.

    ui(msg, tag=None): LIVE display callback in the tab
    (night lines, verdicts ✅/⚠️, unread nights) — the owner
    must SEE what the verification reads during the ~12 min, not
    only at the end. Returns the same report format as
    seasonal_verify.build_report, limited to this event."""

    def _ui(msg, tag=None):
        if ui:
            try:
                ui(msg, tag)
            except Exception:
                pass

    from business.price_calendar import resolve_event_dates
    from business.seasonal_verify import _event_price_for, _profile_mapping
    from vae_bridge import vae_scan

    today = date.today()
    start, end = resolve_event_dates(event, today)
    if start is None:
        return {"events": [], "checked": 0, "drifts": 0,
                "ts": today.isoformat()}
    if end < start:
        end = start
    # The WHOLE period, inclusive nights — same semantics as
    # get_locked_dates ([start, end]): on 09/20 the owner
    # found that only one night was checked; each one is verified.
    nuits = [start + timedelta(days=i)
             for i in range((end - start).days + 1)]

    entries, checked, drifts, not_read = [], 0, 0, 0
    profiles = [o for o in (app_config.get("ota_watch", {}) or {})
                .get("otas") or [] if o.get("active", True)]
    log(f"📌 {event.get('name') or 'Event'} — verification of the WHOLE "
        f"period ({len(nuits)} nights, {nuits[0].isoformat()} → "
        f"{nuits[-1].isoformat()}) on the URL-drivable OTAs:")
    _ui(tr_("📌 {name} — {n} night(s) ({a} → {b})").format(
        name=event.get("name") or tr_("Event"), n=len(nuits),
        a=nuits[0].isoformat(), b=nuits[-1].isoformat()), "tit")
    _ui(tr_("Read-only — NO price is sent. Price changes are made with “📤 Push locked prices”."),
        "mut")

    for prof in profiles:
        name = (prof.get("name") or "").strip()
        if not name or name.lower().startswith("airbnb"):
            continue                    # phase 3: Airbnb without URL dates
        url = prof.get("url") or ""
        if dated_url(url, nuits[0]) is None:
            log(f"   • {name}: no URL-settable dates — skipped")
            _ui(tr_("• {name}: no URL-settable dates — skipped").format(name=name), "warn")
            continue
        tab = _find_tab(url)
        if tab is None:
            log(f"   • {name}: tab not open in Brave — skipped "
                "(the software opens no tab)")
            _ui(tr_("• {name}: tab NOT OPEN in Brave — skipped (open this OTA's tab, then retry)")
                .format(name=name), "err")
            continue
        original = tab.get("url")
        log(f"   • {name}: {len(nuits)} night(s) to check, tab "
            "brought to the event's dates")
        _ui(tr_("• {name}: checking all {n} nights, one by one (tab navigated then restored)").format(
            name=name, n=len(nuits)), "tit")
        # D72 (owner's option b): DATED room-grid reader for
        # Agoda — each locked price on ITS night, captured AFTER the
        # navigation of that night (not_before bound). Without a dated
        # room-grid: night reported NOT READ, never a price guessed via the
        # undated scan (on 09/20, the night of 12/21 read the
        # stale 13,358 of the previous night that way).
        token = None
        try:
            from business.seasonal_roomgrid import host_token as _ht
            _tok = _ht(url)
            if _tok.startswith("agoda"):
                token = _tok
        except Exception:
            token = None
        try:
            for i_nuit, nuit in enumerate(nuits):
                if progress:
                    progress(f"{name} · {nuit.isoformat()}")
                target = dated_url(url, nuit)
                t_nav = time.time()
                _ui(tr_("   Night {i}/{n} — {d}: navigating…").format(
                    i=i_nuit + 1, n=len(nuits), d=nuit.isoformat()), "mut")
                if not _navigate(tab, target, log=log):
                    log(f"      ✗ navigation impossible for the night of "
                        f"{nuit.isoformat()} — night skipped")
                    not_read += 1
                    _ui(tr_("   ⚠️ night of {d}: navigation failed — night skipped").format(d=nuit.isoformat()),
                        "err")
                    continue
                found = None
                if token:
                    try:
                        from vae import config as _vcfg
                        from business.seasonal_roomgrid import wait_room_grid
                        prices, meta = wait_room_grid(
                            _vcfg.DATA_DIR, nuit.isoformat(), token,
                            (app_config.get("hotel_currency") or "INR"),
                            timeout_s=12, poll_s=3, not_before=t_nav,
                            log=log)
                        if prices:
                            found = prices
                            log(f"      night of {nuit.isoformat()} — "
                                f"dated room-grid read ({meta.get('file')})")
                        else:
                            not_read += 1
                            log(f"      ⚠️ night of {nuit.isoformat()} NOT "
                                f"READ: {meta} — no invented "
                                "value, night absent from the report")
                            _ui(tr_("   ⚠️ night of {d} NOT READ — Agoda did not deliver the grid: no value invented").format(
                                        d=nuit.isoformat()), "err")
                            continue
                    except Exception as e:
                        not_read += 1
                        log(f"      ⚠️ room-grid reader in error ({e}) "
                            "— night not read")
                        _ui(tr_("   ⚠️ night of {d}: reader error ({e}) — night not read").format(
                                    d=nuit.isoformat(), e=e), "err")
                        continue
                else:
                    log(f"      night of {nuit.isoformat()} — reading the "
                        "displayed prices (passive scan)…")
                    # D107: STOP = STOP — the ⏹ ALSO cuts the seasonal
                    # verification: the passive scan returns its partial results.
                    from business import seasonal_loop as _sloop
                    results = vae_scan(
                        app_config, progress_cb=None,
                        cancel_cb=lambda: _sloop.STOP.is_set())
                    found = (results or {}).get(name) or {}
                ota_key, room_of = _profile_mapping(name)
                for displayed_room, price in found.items():
                    try:
                        price = float(price)
                    except (TypeError, ValueError):
                        continue
                    room = room_of(displayed_room)
                    expected = _event_price_for(event, room, ota_key)
                    if expected is None:
                        continue
                    drift = price - expected
                    from business.seasonal_verify import \
                        event_tolerance as sver_event_tolerance
                    tol, _tol_desc = sver_event_tolerance(event, expected)
                    ok = abs(drift) <= tol
                    checked += 1
                    if not ok:
                        drifts += 1
                    entries.append({"ota": name, "room": room,
                                    "date": nuit.isoformat(),
                                    "displayed": price,
                                    "expected": expected,
                                    "drift": drift, "ok": ok})
                    line = tr_("   {mark} {d} · {room}: displayed {p} vs locked {e} (drift {dr})").format(
                        mark="✅" if ok else "⚠️", d=nuit.isoformat(),
                        room=room, p=f"{price:,.0f}",
                        e=f"{expected:,.0f}", dr=f"{drift:+,.0f}")
                    log(f"      {'✅' if ok else '⚠️'} {nuit.isoformat()} "
                        f"{displayed_room}: displayed {price:,.0f} vs "
                        f"locked {expected:,.0f}")
                    _ui(line, "ok" if ok else "err")
        finally:
            if original:
                _navigate(tab, original, wait_s=_RESTORE_WAIT_S,
                          log=lambda m: None)
                log(f"      tab brought back to its original page")
                _ui(tr_("• {name}: tab restored to its original page")
                    .format(name=name), "mut")
    return {"events": [{"name": event.get("name") or "Event",
                        "dates": f"{start.isoformat()} → {end.isoformat()}",
                        "entries": entries}],
            "checked": checked, "drifts": drifts,
            "not_read_nights": not_read,
            "ts": today.isoformat()}


def run_in_thread(app_config, event, on_done, log=print, ui=None):
    """Runs the verification in a thread with the D52 lock."""
    import extranet_bridge as _xb

    def _work():
        if not _xb.operation_begin("seasonal verification"):
            log("⚠️ another operation is running — retry when it "
                "finishes")
            if ui:
                try:
                    ui(tr_("⚠️ another operation is running (scan or push) — retry when it finishes"),
                       "err")
                except Exception:
                    pass
            on_done(None)
            return
        try:
            rep = verify_future_event(app_config, event, log=log, ui=ui)
            on_done(rep)
        except Exception as e:
            log(f"✗ error: {e}")
            if ui:
                try:
                    ui(tr_("✗ error during verification: {e}")
                       .format(e=e), "err")
                except Exception:
                    pass
            on_done(None)
        finally:
            # D75: release WITH the exact operation name — an
            # argument-less operation_end() raised TypeError in this
            # finally and the D52 slot stayed reserved FOREVER
            # (finding 09/20 17:32: push refused 40 min after the end
            # of a verification, "in progress since 16:50:06").
            try:
                _xb.operation_end("seasonal verification")
            except Exception as e:
                log(f"⚠️ impossible to release the D52 slot: {e}")

    threading.Thread(target=_work, daemon=True).start()
