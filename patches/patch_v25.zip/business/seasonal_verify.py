"""business/seasonal_verify.py — Verification of seasonal rates (D67).

PRODUCT RULE (owner finding 09/03, go-ahead 09/18): a locked seasonal
rate must stay TRUE on the OTAs — so, roughly every week, we verify
that the price ACTUALLY DISPLAYED by each OTA at the event's dates
matches the locked price.

PHASE 1 (this version, 100% read, R1): for ACTIVE events
(today within their dates), the normal OTA scan already reads the
displayed prices at those dates (the tabs show the current stay).
We compare these `last_results` against the event's prices and produce a
report per OTA × room: displayed vs locked, drift, ✅/⚠️.
NOTHING is sent — any correction stays with the existing
"Push the locked prices" button (router, D57).

PHASE 2 (upcoming, on validation): FUTURE events — the browser
is brought to the event's dates (human-like navigation, anti-bot),
VAE1 reads, we compare, we correct, we re-verify.

Cadence: the report refreshes automatically if older than 7 days
(state in config["price_calendar"]["verify"]), or on click.
"""

from datetime import date, timedelta

from core.utils import tr_

_TOLERANCE_PCT = 2.0        # tolerated drift (%, of the locked price)
_TOLERANCE_MIN = 1          # and always at least ±1 unit
_STALE_DAYS = 7             # weekly cadence

_AIRBNB_PREFIX = "airbnb "


def _parse(iso):
    from business.price_calendar import _parse_iso
    return _parse_iso(iso)


def active_locked_events(config, today=None):
    """ACTIVE locked events (today within their dates)."""
    today = today or date.today()
    from business.price_calendar import resolve_event_dates
    out = []
    for ev in (config.get("price_calendar", {}).get("events") or []):
        if not isinstance(ev, dict):
            continue
        if not ev.get("enabled", True) or not ev.get("locked"):
            continue
        start, end = resolve_event_dates(ev, today)
        if start is None or end is None:
            continue
        if start <= today <= end:
            out.append((ev, start, end))
    return out


def upcoming_locked_events(config, horizon_days=30, today=None):
    """UPCOMING locked events within the horizon (phase 2)."""
    today = today or date.today()
    from business.price_calendar import resolve_event_dates
    out = []
    for ev in (config.get("price_calendar", {}).get("events") or []):
        if not isinstance(ev, dict):
            continue
        if not ev.get("enabled", True) or not ev.get("locked"):
            continue
        start, end = resolve_event_dates(ev, today)
        if start is None or end is None:
            continue
        if today < start <= today + timedelta(days=int(horizon_days)):
            out.append((ev, start, end))
    return out


def _event_price_for(event, room, ota_key):
    """Event's locked price for (room, OTA), or None.
    Same convention as price_calendar: case-insensitive OTA key,
    `_default` fallback."""
    room_prices = (event.get("rooms") or {}).get(room) or {}
    for k, v in room_prices.items():
        if k.lower() == (ota_key or "").lower() and v:
            return float(v)
    d = room_prices.get("_default")
    return float(d) if d else None


def event_tolerance(event, expected):
    """(absolute_tolerance, description) for the expected locked price.

    D74: the tolerance is SET per event — "Tolerance ({currency})"
    in the card. Defined amount → fixed tolerance in the software's
    currency (displayed prices are converted into that currency).
    Empty → historical default ±2% (minimum 1)."""
    try:
        amt = float(event.get("tolerance_amount") or 0)
    except (TypeError, ValueError):
        amt = 0.0
    if amt > 0:
        return amt, tr_("±{a:,.0f} (event setting)").format(a=amt)
    return (max(_TOLERANCE_MIN, abs(expected) * _TOLERANCE_PCT / 100.0),
            tr_("±2% (default)"))


def _profile_mapping(profile_name):
    """(event_OTA_key, displayed_label → config_room function).

    Agoda/Expedia/Goibibo/BookNow…: the key is the profile name as-is
    (MakeMyTrip → Goibibo, same inventory, house convention).
    "Airbnb <room>" profiles: the event key is `AirBnB`
    (the CM has a single AirBnB OTA) and the config room is the suffix
    of the profile name (D43 realignment: the price displayed by the
    listing belongs to ITS room)."""
    name = (profile_name or "").strip()
    low = name.lower()
    if low == "airbnb":
        # D110: unified OTA — results already live per ROOM under
        # "Airbnb" (like Expedia): the displayed label IS the room.
        return "AirBnB", (lambda displayed: displayed)
    if low.startswith(_AIRBNB_PREFIX):
        room = name[len(_AIRBNB_PREFIX):].strip()
        return "AirBnB", (lambda _displayed, _r=room: _r)
    key = "Goibibo" if low == "makemytrip" else name
    return key, (lambda displayed: displayed)


def build_report(config, last_results=None, today=None):
    """Verification report of ACTIVE events (read-only).

    Returns {"ts", "events": [...], "checked": n, "drifts": n} where
    each event carries {"name", "dates", "entries": [{ota, room,
    displayed, expected, drift, ok}]}."""
    today = today or date.today()
    last_results = last_results if last_results is not None else \
        (config.get("ota_watch", {}) or {}).get("last_results") or {}

    events_out = []
    checked = drifts = 0
    for ev, start, end in active_locked_events(config, today):
        entries = []
        for profile, rooms in (last_results or {}).items():
            ota_key, room_of = _profile_mapping(profile)
            if not isinstance(rooms, dict):
                continue
            for displayed_room, displayed in rooms.items():
                try:
                    displayed = float(displayed)
                except (TypeError, ValueError):
                    continue
                room = room_of(displayed_room)
                expected = _event_price_for(ev, room, ota_key)
                if expected is None:
                    continue          # nothing locked for this pair
                drift = displayed - expected
                tol, _tol_desc = event_tolerance(ev, expected)
                ok = abs(drift) <= tol
                checked += 1
                if not ok:
                    drifts += 1
                entries.append({
                    "ota": profile, "room": room,
                    "displayed": displayed, "expected": expected,
                    "drift": drift, "ok": ok,
                })
        events_out.append({
            "name": ev.get("name") or "Event",
            "dates": f"{start.isoformat()} → {end.isoformat()}",
            "entries": entries,
        })
    return {"events": events_out, "checked": checked, "drifts": drifts,
            "ts": today.isoformat()}


# ── state (weekly cadence) ───────────────────────────────────────────────────

def _state(config):
    return (config.get("price_calendar", {}) or {}).get("verify") or {}


def last_verify(config):
    return str(_state(config).get("last") or "")


def verify_every_days(config):
    """Auto cadence (days) = the shortest among the active locked
    events (D74: "Verify every (days)" per event,
    default 7). No locked event → default."""
    days = []
    for ev in (config.get("price_calendar", {}).get("events") or []):
        if not isinstance(ev, dict):
            continue
        if not ev.get("enabled", True) or not ev.get("locked"):
            continue
        try:
            d = int(ev.get("verify_every_days") or 0)
        except (TypeError, ValueError):
            d = 0
        days.append(d if d > 0 else _STALE_DAYS)
    return min(days) if days else _STALE_DAYS


def is_stale(config, today=None):
    last = last_verify(config)
    if not last:
        return True
    try:
        d = _parse(last)
        if d is None:
            return True
        return (today or date.today()) - d >= timedelta(
            days=verify_every_days(config))
    except Exception:
        return True


def save_report(config, report, persist=True, report_file=None):
    """Writes the report state into the config (and saves it).
    report_file: path of the full report (write_report_file) remembered
    to display it in the tab."""
    cfg_pc = config.setdefault("price_calendar", {})
    cfg_pc["verify"] = {"last": date.today().isoformat(),
                        "drifts": report.get("drifts", 0),
                        "checked": report.get("checked", 0),
                        "last_file": str(report_file or "")}
    if persist:
        try:
            from core import config as _cfg
            _cfg.save(config)
        except Exception:
            pass


# ── readable FILE report (09/20: the owner wants a trace
#    "room X has such price at such date" kept on disk) ──────────────────

def report_dir(config=None):
    """Folder of the verification reports (created if needed)."""
    from pathlib import Path
    from core.paths import DATA_DIR
    d = Path(DATA_DIR) / "seasonal_reports"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _fmt_num(v):
    try:
        return f"{float(v):,.0f}"
    except (TypeError, ValueError):
        return str(v)


def report_tagged_lines(report):
    """[(text, tag)] of the report body — UI tags ("tit", "ok",
    "err", "mut"). SINGLE formatting source: the tab's screen and
    the .txt file show exactly the same lines."""
    lines = []
    for ev in report.get("events") or []:
        entries = ev.get("entries") or []
        lines.append((f"📌 {ev.get('name')} — {ev.get('dates')} · "
                      f"{len(entries)} price(s) checked", "tit"))
        if not entries:
            lines.append(("   (no displayed price available)", "mut"))
        by_date = {}
        for e in entries:
            by_date.setdefault(e.get("date") or "", []).append(e)
        for dat, es in sorted(by_date.items()):
            if dat:
                lines.append((f"   Night of {dat}:", "mut"))
                pfx = "      "
            else:
                pfx = "   "
            for e in es:
                mark = "✅" if e.get("ok") else "⚠️"
                try:
                    drift = f"{e.get('drift', 0):+,.0f}"
                except (TypeError, ValueError):
                    drift = str(e.get("drift"))
                lines.append((
                    f"{pfx}{mark} {e.get('ota')} · {e.get('room')}: "
                    f"displayed {_fmt_num(e.get('displayed'))} / locked "
                    f"{_fmt_num(e.get('expected'))} (drift {drift})",
                    "ok" if e.get("ok") else "err"))
    n_d = int(report.get("drifts") or 0)
    n_nr = int(report.get("not_read_nights") or 0)
    if n_nr:
        lines.append((f"⚠️ {n_nr} night(s) NOT READ — no dated room-grid "
                      "received: absent from the report, nothing is "
                      "guessed", "err"))
    lines.append((f"Summary: {report.get('checked', 0)} price(s) checked, "
                  f"{n_d} drift(s) beyond the tolerance "
                  f"±{_TOLERANCE_PCT}%",
                  "warn" if n_d else "ok"))
    return lines


def load_last_report(config):
    """Last persisted full report: envelope {"generated",
    "source", "report"} or None. Looks for verify.last_file first,
    then the most recent .json in the reports folder."""
    import json as _json
    from pathlib import Path
    cands = []
    p = str(_state(config).get("last_file") or "")
    if p:
        cands.append(Path(p[:-4] + ".json") if p.endswith(".txt")
                     else Path(p))
    try:
        cands += sorted(report_dir().glob("verification_*.json"),
                        reverse=True)
    except Exception:
        pass
    for c in cands:
        try:
            data = _json.loads(Path(c).read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        if data.get("report"):                 # envelope (current format)
            return data
        if data.get("events"):                 # old bare format (D70 morning)
            return {"generated": "", "source": "", "report": data}
    return None


def write_report_file(config, report, source="manual"):
    """Writes the full report into a READABLE .txt file (+ machine .json
    copy with envelope {generated, source, report}) into
    <data>/seasonal_reports/. Returns the .txt path, or None
    if the report contains no event. The lines come from
    report_tagged_lines — the tab displays EXACTLY this file."""
    import json as _json
    from datetime import datetime as _dt
    events = report.get("events") or []
    if not events:
        return None
    cur = ""
    try:
        from core.utils import get_currency_symbol
        cur = get_currency_symbol(config).strip()
    except Exception:
        cur = str(config.get("hotel_currency", "") or "").strip()
    stamp = _dt.now().strftime("%Y-%m-%d_%H%M%S")
    gen = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")
    d = report_dir()
    lines = [
        "VERIFICATION REPORT — SEASONAL RATES",
        f"Generated on {_dt.now().strftime('%d/%m/%Y %H:%M:%S')}",
        f"Source: {source}",
    ]
    if cur:
        lines.append(f"Software currency: {cur} "
                     "(displayed prices converted automatically)")
    lines.append("")
    lines += [t for t, _ in report_tagged_lines(report)]
    txt = d / f"verification_{stamp}.txt"
    txt.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (d / f"verification_{stamp}.json").write_text(
        _json.dumps({"generated": gen, "source": str(source),
                     "report": report},
                    ensure_ascii=False, indent=2, default=str),
        encoding="utf-8")
    return str(txt)
