"""business/analysis_engine.py — D88: the analysis brain (read-only).

The product's "brain": it reads data ALREADY accumulated
(legal journal ⚖ D80, send histories send_history) and derives, per
OTA × room:

  - the time series of displayed prices (for the charts);
  - the LEARNED sent → displayed relation (ratio + dispersion → the
    "reliability"), the same one the correction uses via the
    calibration but here described and exposed;
  - ANOMALIES: recent change of the relation, sudden deviation of the
    last displayed price from what the relation predicts
    (active OTA promo, or changed behavior);
  - the summary counters (prices read, shipments sent, POST proofs).

RULES: fully read-only — no shipment, no navigation, no network
(R1/R3); it DECIDES nothing (it describes); never purged (the journals
remain the source of truth). Insufficient data → it says so, it does
not invent.
"""
import json
import statistics
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


def _ledger_dir():
    try:
        from business import legal_ledger
        return legal_ledger.evidence_dir()
    except Exception:
        return None


# D118: ONE identity per OTA in the report — the ⚖ journal filed reads
# under different keys depending on the era (displayed scan name
# "Agoda", old per-listing profile "Airbnb Double Room", seasonal
# profile key "agoda"/"airbnb_deluxe_double_room"): the report filters
# showed 12 duplicated entries and each chart displayed only a fraction
# of the data (owner finding: "nothing works"). Everything is grouped
# under the canonical name.
_CANONICAL = {
    "agoda": "Agoda",
    "airbnb": "Airbnb",
    "expedia": "Expedia",
    "goibibo": "Goibibo",
    "makemytrip": "MakeMyTrip",
    "booking": "Booking",
    "google": "Google Hotels",
    "google_hotels": "Google Hotels",
}


def canonical_ota(name: str) -> str:
    """Canonical OTA name whatever the journal label is."""
    n = str(name or "").strip().lower()
    if not n:
        return "?"
    if n in _CANONICAL:
        return _CANONICAL[n]
    for prefix, canon in _CANONICAL.items():
        if n.startswith(prefix):        # "airbnb_deluxe_double_room" → Airbnb
            return canon
    return str(name or "?")


def read_ledger_records(max_files=None):
    """All records of the ⚖ journal (all sessions included),
    sorted by reception index. Tolerant to corrupted files."""
    root = _ledger_dir()
    out = []
    if not root:
        return out
    files = sorted(root.glob("session-*/evidence-*.jsonl"))
    if max_files:
        files = files[-int(max_files):]
    for f in files:
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
        except Exception:
            continue
    out.sort(key=lambda r: (r.get("received_at") or 0,
                            r.get("record_index") or 0))
    return out


def price_series(records=None):
    """Displayed price series: {(ota, room): [(datetime, price)]}.
    Past/present nights only (dated reads of future events would
    distort the present curve)."""
    if records is None:
        records = read_ledger_records()
    out = defaultdict(list)
    now = datetime.now()
    for r in records:
        if r.get("record_type") != "price_read":
            continue
        f = r.get("fact") or {}
        try:
            price = float(f.get("price") or 0)
        except (TypeError, ValueError):
            continue
        if price <= 0:
            continue
        ts = r.get("received_at")
        if not ts:
            continue
        dt = datetime.fromtimestamp(ts)
        # exclude FUTURE nights (early event verification)
        night = str(f.get("night") or "")
        if night:
            try:
                if datetime.fromisoformat(night) > now:
                    continue
            except ValueError:
                pass
        out[(canonical_ota(f.get("ota")), str(f.get("room") or "?"))] \
            .append((dt, price))
    for k in out:
        out[k].sort()
    return dict(out)


def _history_pairs():
    """Sent → displayed measures from the per-OTA histories:
    {(displayed_ota): [(sent, observed)]} — confirmed only."""
    from core.paths import DATA_DIR
    out = defaultdict(list)
    try:
        root = Path(DATA_DIR)
        for f in root.glob("send_history_*.json"):
            data = json.loads(f.read_text(encoding="utf-8"))
            measures = data.get("measures", {}) if isinstance(data, dict) \
                else {}
            for room, entries in measures.items():
                for e in entries or []:
                    if (e or {}).get("status") != "confirmed":
                        continue
                    sent, obs = e.get("sent"), e.get("observed")
                    if not sent or not obs:
                        continue
                    ota = str(e.get("ota_name") or f.stem[13:] or "?")
                    try:
                        out[ota].append((float(sent), float(obs)))
                    except (TypeError, ValueError):
                        continue
    except Exception:
        pass
    return out


MIN_MEASURES = 3


def transfer_model():
    """Learned relation per OTA: {ota: {ratio, spread, n, verdict}}.
    ratio = displayed / sent (robust geometric average: median);
    spread = relative dispersion (small = reliable); n = confirmed
    measures. < MIN_MEASURES → verdict "not enough data yet"."""
    out = {}
    # D118: collect ALL pairs per canonical OTA BEFORE computing
    # — two files (e.g. "airbnb" + "airbnb_double_room") = a single
    # relation per real OTA.
    pairs_by = defaultdict(list)
    for ota, pairs in _history_pairs().items():
        pairs_by[canonical_ota(ota)].extend(pairs)
    for ota, pairs in pairs_by.items():
        ratios = [o / s for s, o in pairs if s]
        n = len(ratios)
        if n < MIN_MEASURES:
            out[ota] = {"n": n, "verdict": "insufficient"}
            continue
        med = statistics.median(ratios)
        spread = (max(ratios) - min(ratios)) / med if med else 0.0
        if spread > 0.25:
            verdict = "unstable"
        elif spread > 0.10:
            verdict = "learning"
        else:
            verdict = "stable"
        out[ota] = {"n": n, "ratio": round(med, 4),
                    "spread": round(spread, 4), "verdict": verdict,
                    "min_ratio": round(min(ratios), 4),
                    "max_ratio": round(max(ratios), 4)}
    return out


def anomalies(series=None, model=None):
    """Detected anomalies: {key: [messages]} — pure read.
    (1) changed relation: the last 3 measures durably deviate from the
    OTA's median; (2) last displayed price outside the predicted range
    (active promo or changed behavior)."""
    series = series if series is not None else price_series()
    model = model if model is not None else transfer_model()
    alerts = {}
    # (1) relation drift per OTA
    for ota, m in (model or {}).items():
        if m.get("verdict") != "stable" or "ratio" not in m:
            continue
        base = m["ratio"]
        recent = [o / s for s, o in _history_pairs().get(ota, [])[-3:]
                  if s]
        if len(recent) == 3 and all(abs(r / base - 1) > 0.08 for r in recent):
            alerts.setdefault(ota, []).append(
                f"changed relation: the learned ratio ({base:.2f}x) no "
                f"longer matches the last 3 measures — check "
                f"(new commission or promotion?)")
    # (2) last displayed price outside prediction
    for (ota, room), pts in (series or {}).items():
        m = model.get(ota) or {}
        if "ratio" not in m or len(pts) < 2:
            continue
        last_dt, last_price = pts[-1]
        prev = [p for _, p in pts[:-1]]
        if not prev:
            continue
        med_prev = statistics.median(prev)
        if med_prev and abs(last_price / med_prev - 1) > 0.15:
            alerts.setdefault(f"{ota} · {room}", []).append(
                f"last displayed price {last_price:,.0f} deviates from "
                f"{med_prev:,.0f} (> 15%) — active promotion or "
                f"change at the OTA")
    return alerts


def summary():
    """Top-of-page counters (all sessions of the journal)."""
    records = read_ledger_records()
    reads = sums = proofs = 0
    for r in records:
        rt = r.get("record_type")
        if rt == "price_read":
            reads += 1
        elif rt == "push_result":
            if r.get("fact", {}).get("ok"):
                sums += 1
        elif rt == "post_proof":
            proofs += 1
    return {"price_reads": reads, "push_ok": sums,
            "post_proofs": proofs,
            "first_record": _iso(records[0].get("received_at"))
            if records else "",
            "sessions": len(list(_ledger_dir().glob("session-*")))
            if _ledger_dir() else 0}


def _iso(ts):
    try:
        return datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError, OSError):
        return ""


def weekly_history(series=None, weeks=8):
    """Weekly history: [{week, ota, room, min, max, last}] for the
    tab's table — readable aggregate of the series."""
    series = series if series is not None else price_series()
    today = datetime.now().date()
    out = []
    for (ota, room), pts in sorted(series.items()):
        buckets = defaultdict(list)
        for dt, price in pts:
            wk_start = dt.date() - timedelta(days=dt.date().weekday())
            buckets[wk_start].append(price)
        for wk_start in sorted(buckets)[-weeks:]:
            vals = buckets[wk_start]
            out.append({
                "week": wk_start.strftime("%d/%m"),
                "ota": ota, "room": room,
                "min": min(vals), "max": max(vals),
                "last": vals[-1], "n": len(vals)})
    return out
