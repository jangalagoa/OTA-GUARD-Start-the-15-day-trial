"""D128 — automatic Channel Manager address tracking.

The CM provider can move its extranet to a new address at any time
(proven 14/10: app.channelmanager.com.au → update247.cloud, first
symptom: every shipment died at preflight on a login page). OTA Guard
must follow the move BY ITSELF — no manual card edit, no developer
intervention:

  * the executor notices a redirect onto an unknown host, learns it,
    retries the SAME page path on the new host once, and remembers the
    page on success;
  * the passive scan learns hosts seen serving the CM's known page
    paths (BulkUpdate / OTASheet) straight from the capture metas;
  * every consumer (tab matching, grid reading, capture purge
    protection, listener attribution) uses the learned hosts.

Store: a small dedicated JSON beside the config (data/cm_sites.json) —
atomic replace, NEVER merged into config.json, so the listener thread
can learn while the UI saves the config without any race (lesson D112).
Fail-safe: every entry point swallows IO errors — tracking must never
break a push or a scan.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

_MAX_HOSTS = 8          # a provider rebrands twice, not twenty times
# Page-path signatures of the CM extranet (the card's own pages carry
# these paths; any host serving them IS the CM, whatever its name).
_PATH_SIGNATURES = ("bulkupdate", "otasheet")


def _store_path() -> Path:
    from core.paths import DATA_DIR
    return Path(DATA_DIR) / "cm_sites.json"


def _load() -> dict:
    try:
        d = json.loads(_store_path().read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return {}


def _save(data: dict) -> None:
    try:
        p = _store_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
    except Exception:
        pass


def host_of(url: str) -> str:
    """Bare host of a URL ('' when unusable)."""
    try:
        h = (urlsplit((url or "").strip()).hostname or "").lower()
        return h
    except Exception:
        return ""


def swap_host(url: str, new_host: str) -> str:
    """Same URL (scheme/path/query/fragment) on another host."""
    try:
        parts = list(urlsplit((url or "").strip()))
        netloc = (new_host or "").strip().lower()
        if not netloc:
            return url
        if ":" in parts[1]:            # keep an explicit port if any
            port = parts[1].rsplit(":", 1)[1]
            if port.isdigit():
                netloc = f"{netloc}:{port}"
        parts[1] = netloc
        return urlunsplit(parts)
    except Exception:
        return url


def all_hosts(card_domain: str | None = None) -> list:
    """Every host the CM is known to live on: learned ones FIRST (most
    recent address wins), then the adapter card's own domain."""
    hosts = [h for h in _load().get("hosts", []) if h]
    card = (card_domain or "").strip().lower()
    if card and card not in hosts:
        hosts.append(card)
    return hosts


def learn_host(host: str, source: str = "") -> bool:
    """Records a new CM host. Returns True when it was unknown."""
    host = (host or "").strip().lower()
    if not host or "." not in host:
        return False
    data = _load()
    hosts = [h for h in data.get("hosts", []) if h]
    if host in hosts:
        return False
    hosts.insert(0, host)               # newest first
    data["hosts"] = hosts[:_MAX_HOSTS]
    data["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    if source:
        data["last_source"] = source
    _save(data)
    return True


def learn_page(kind: str, url: str) -> bool:
    """Remembers the exact working URL of a CM page ('read'/'write').
    Only meaningful on a host OTHER than the card's (the card already
    owns its own URLs)."""
    url = (url or "").strip()
    host = host_of(url)
    if not url or not host or kind not in ("read", "write"):
        return False
    data = _load()
    pages = data.setdefault("pages", {})
    if pages.get(kind) == url:
        return False
    pages[kind] = url
    if host not in [h for h in data.get("hosts", []) if h]:
        hosts = [h for h in data.get("hosts", []) if h]
        hosts.insert(0, host)
        data["hosts"] = hosts[:_MAX_HOSTS]
    data["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    _save(data)
    return True


def page_for(kind: str, card_url: str) -> str:
    """Best URL for a CM page, newest address first:
    1. the exact learned working URL (learn_page),
    2. the card's URL host-swapped onto the newest learned host,
    3. the card's URL as is."""
    data = _load()
    url = (data.get("pages", {}) or {}).get(kind) or ""
    if url.startswith("http"):
        return url
    hosts = [h for h in data.get("hosts", []) if h]
    if hosts and card_url:
        return swap_host(card_url, hosts[0])
    return card_url or ""


# Hosts a CM page should never be followed onto (third-party SSO front
# doors) — the page path would 404 there and the host would pollute the
# learned list.
_NON_CM_HOST_MARKS = ("login", "signin", "sso", "accounts.")


def learn_from_redirect(requested_url: str, final_url: str) -> str | None:
    """The CM was asked for `requested_url` and the browser ended on
    `final_url`: when the host changed (and is not an SSO front door),
    learn the new host and return the host-swapped URL to retry the
    SAME page on the new address."""
    new_host = host_of(final_url)
    old_host = host_of(requested_url)
    if not new_host or not old_host or new_host == old_host:
        return None
    if any(m in new_host for m in _NON_CM_HOST_MARKS):
        return None
    learn_host(new_host, source="redirect")
    return swap_host(requested_url, new_host)


def learn_from_capture_metas(metas, last_check: str = "") -> list:
    """Learns CM hosts straight from capture metas (dicts with 'url' or
    'tab_url'): any URL serving a known CM page path on an unknown host
    is a moved CM. `last_check` (YYYYMMDD_HHMMSS prefix) bounds the
    pass — callers remember where they stopped. Returns learned hosts."""
    known = set(all_hosts())
    learned = []
    for meta in metas:
        for u in (meta.get("url"), meta.get("tab_url")):
            host = host_of(str(u or ""))
            if not host or host in known:
                continue
            low = str(u or "").lower()
            if any(sig in low for sig in _PATH_SIGNATURES):
                if learn_host(host, source="captures"):
                    known.add(host)
                    learned.append(host)
    return learned


def learn_from_tab_paths(tabs, card_pages: dict) -> list:
    """D128-2 — learns the CM's new host from the owner's OWN open tab.

    A page tab whose URL carries one of the CARD's page PATHS (e.g.
    '/Supplier/Updates/OTASheet' or '/Supplier/Updates/BulkUpdate')
    on an unknown host IS the moved CM — nobody else serves the card's
    paths (proven 14/10: app.merusync.com/Supplier/Updates/OTASheet,
    live session, same app under a rebranded domain). `card_pages` maps
    kind → card URL ('read'/'write'). Returns the learned hosts; the
    exact page URL is pinned too (read: fragment stripped, write: hash
    route kept)."""
    from urllib.parse import urldefrag
    known = set(all_hosts())
    learned = []
    paths = {}
    for kind, url in (card_pages or {}).items():
        try:
            p = urlsplit((url or "").strip()).path.lower()
            if p and p != "/":
                paths[p] = kind
        except Exception:
            pass
    for t in tabs or []:
        url = str((t or {}).get("url") or "").strip()
        if not url.startswith("http"):
            continue
        host = host_of(url)
        if not host or host in known:
            continue
        low = url.lower()
        hit = next((p for p in paths if p and p in low), None)
        if not hit:
            continue
        kind = paths[hit]
        if kind == "read":
            learn_page("read", urldefrag(url)[0])
        else:
            learn_page("write", url)
        known.add(host)
        learned.append(host)
    return learned


def learn_from_http_probe(urls) -> list:
    """D128-2 — last-resort learning: plain HTTP GET on the card's URLs
    (no credentials sent) and read the redirect target — a provider
    that moved its domain redirects the old address to the new one
    (proven 14/10: the old domain bounced to the new portal). One hop
    (plus one re-hop on the answer). Returns the learned hosts."""
    learned = []
    known = set(all_hosts())
    for url in urls or []:
        try:
            import urllib.request as _ur
            req = _ur.Request(url, method="GET",
                              headers={"User-Agent": "OTA-Guard-D128"})
            with _ur.urlopen(req, timeout=5) as r:      # follows chains
                final = str(r.geturl() or "")
            host = host_of(final)
            if host and host not in known:
                learn_host(host, source="http-probe")
                known.add(host)
                learned.append(host)
        except Exception:
            continue
    return learned


def forget(keep_card_domain: str | None = None) -> None:
    """Wipes the learned state (test/maintenance hook)."""
    _save({"hosts": [], "pages": {}, "updated":
           time.strftime("%Y-%m-%dT%H:%M:%S"), "last_source": "reset"})


def listener_domains_hook(domains: list) -> list:
    """Merges the learned CM hosts into the listener's known-domain list
    so its tabs stay attributed to the CM (capture naming + purge)."""
    out = list(domains or [])
    for h in all_hosts():
        if h not in out:
            out.append(h)
    return out
