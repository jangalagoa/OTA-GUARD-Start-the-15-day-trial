"""
mobile_gateway.py — Translates OTA Guard's internal state (scan results,
Channel Manager push confirmations) into Firestore documents readable by
the companion mobile app.

This module performs NO scan and pushes NO price to the Channel Manager —
it transforms data already computed elsewhere (tab_blocage_ota.py,
app_core.py) into a simple format for the phone.

WIRED to the real flow (doc updated on 2026-07-31):
  - `publish_state()` is called after every scan by
    `tabs/tab_blocage_ota.py::_publish_mobile_state`;
  - `publish_push_confirmation()` after a successful CM push by
    `app_core.py::_publish_mobile_push_confirmation`;
  - `mark_rooms_corrected()` right after a successful CM push, by
    `tabs/tab_blocage_ota.py::_publish_mobile_state_correction` — updates
    the already-published state document WITHOUT waiting for the next scan
    (PC AND mobile go through the same correction function,
    `_ota_watch_correct`).
Stays fail-safe (D8): without a connected gateway, these calls return False.

Format of the published state document (collection "state", document "current"):
{
  "updated_at": "2026-07-18T14:32:00+00:00",
  "health": "green" | "red" | "unknown",
  "currency": "₹",
  "rooms": {
    "Deluxe Room": {
      "otas": {
        "Agoda":   {"target": 4500, "detected": 4500, "gap": 0,    "status": "green"},
        "Booking": {"target": 4500, "detected": 4100, "gap": -400, "status": "red"}
      }
    }
  }
}
"""
import logging
from datetime import datetime, timezone

log = logging.getLogger(__name__)

STATE_COLLECTION = "state"
STATE_DOC = "current"
PUSH_HISTORY_COLLECTION = "push_history"
DEVICES_COLLECTION = "devices"
CONFIG_COLLECTION = "config"
TARGET_PRICES_DOC = "target_prices"
NOTIFICATION_PREFS_DOC = "notification_prefs"

DEFAULT_CURRENCY_SYMBOL = "₹"


def _currency_symbol() -> str:
    """Hotel currency symbol (₹, €, $…), to publish towards the phone.

    LOCAL import, not at module head: `core.utils` imports tkinter, and
    this module is also called from scan threads and could be called
    from a headless context. The import is done at call time
    and any error falls back to ₹ — publishing a wrong symbol never
    affects a price, only its display.
    """
    try:
        from core.utils import get_currency_symbol
        symbol = get_currency_symbol()
        return symbol if symbol else DEFAULT_CURRENCY_SYMBOL
    except Exception:
        return DEFAULT_CURRENCY_SYMBOL


def build_state_snapshot(results: dict, target_prices: dict, min_gap: float) -> dict:
    """Builds the state document to publish towards Firestore.

    `results`       : {ota_name: {room_type: detected_price}} — scan output
                       (the `results` variable of tab_blocage_ota.py).
    `target_prices` : config["ota_watch"]["target_prices"]
                       = {room_type: {ota_name: target_price}}.
    `min_gap`       : config["ota_watch"]["min_gap"] — gap (hotel currency)
                       beyond which a room is considered "modified"
                       (same threshold as the OTA correction, D18/D20).

    Never raises — returns {} on inconsistent data
    (the caller decides whether to publish anyway).
    """
    rooms = {}
    any_red = False
    any_data = False

    # OTA group aliasing (Goibibo / MakeMyTrip share one CM price) and
    # exclusion of non-bookable entries — mirrors the desktop display
    # rules of tab_blocage_ota so the phone matches the PC exactly.
    _MMT_GROUP   = {"goibibo", "makemytrip"}
    _MMT_DISPLAY = "MakeMyTrip / Goibibo"
    _GENERALIST  = ("google hotel", "google travel", "trivago", "kayak",
                    "tripadvisor")
    _EXCLUDED_ROOMS = {"move room"}

    def _ota_group_key(name: str) -> str:
        n = (name or "").lower()
        if any(g in n for g in _MMT_GROUP):
            return _MMT_DISPLAY
        return name

    try:
        for ota_name, room_prices in (results or {}).items():
            if not isinstance(room_prices, dict):
                continue
            _on_lower = (ota_name or "").lower()
            if any(g in _on_lower for g in _GENERALIST):
                continue
            # Normalize the OTA name so scan keys ("Goibibo"/"MakeMyTrip")
            # resolve against the merged target key ("MakeMyTrip / Goibibo").
            _ota_key = _ota_group_key(ota_name)
            for room, detected in room_prices.items():
                if not detected:
                    continue
                if (room or "").lower().strip() in _EXCLUDED_ROOMS:
                    continue
                _room_t = target_prices.get(room, {}) or {}
                target = _room_t.get(_ota_key) or _room_t.get(ota_name)
                if target is None:
                    continue
                gap = float(target) - float(detected)
                status = "red" if abs(gap) >= min_gap else "green"
                any_data = True
                if status == "red":
                    any_red = True
                # Publish under the merged group name so Goibibo and
                # MakeMyTrip appear as a single OTA on the phone.
                _slot = rooms.setdefault(room, {"otas": {}})["otas"]
                if _ota_key != ota_name and _ota_key in _slot:
                    # Keep the more recent detection of the merged group.
                    _slot[_ota_key]["detected"] = round(float(detected))
                    _slot[_ota_key]["gap"]      = round(gap)
                    _slot[_ota_key]["status"]   = status
                else:
                    _slot[_ota_key] = {
                        "target":   round(float(target)),
                        "detected": round(float(detected)),
                        "gap":      round(gap),
                        "status":   status,
                    }
    except Exception:
        log.exception("mobile_gateway: build_state_snapshot failure")
        return {}

    return {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "health": ("red" if any_red else "green") if any_data else "unknown",
        "currency": _currency_symbol(),
        "rooms": rooms,
    }


def mark_rooms_corrected(pushed: list) -> bool:
    """Updates the already-published state document right after a successful
    correction, without waiting for the next scan (which can take several
    minutes — the phone would show the red alert while the price
    has just been corrected, whether the correction comes from the PC or the mobile).

    `pushed` : list of {"room": str, "ota_name": str, "target": float} —
    one entry per (room, OTA) actually sent to the Channel Manager.
    Sets the matching entry to detected == target, gap == 0,
    status "green" — the next scan will replace it with the value
    actually measured.

    Local merge (read then full rewrite) rather than
    `publish_document(..., merge=True)`: `health` must be recomputed over
    all rooms/OTAs, not only the ones corrected here.

    Fail-safe (D8): returns False without breaking anything if the gateway is
    not connected or if no state document exists yet (nothing to
    correct before the first scan)."""
    from business import firebase_client
    if not firebase_client.is_available():
        return False
    if not pushed:
        return False

    doc = firebase_client.get_document(STATE_COLLECTION, STATE_DOC)
    if not doc:
        return False
    rooms = doc.setdefault("rooms", {})

    changed = False
    for p in pushed:
        room   = p.get("room")
        ota    = p.get("ota_name")
        target = p.get("target")
        if not room or not ota or target is None:
            continue
        try:
            target = round(float(target))
        except (TypeError, ValueError):
            continue
        rooms.setdefault(room, {}).setdefault("otas", {})[ota] = {
            "target":   target,
            "detected": target,
            "gap":      0,
            "status":   "green",
        }
        changed = True

    if not changed:
        return False

    any_red = any(
        (o or {}).get("status") == "red"
        for r in rooms.values()
        for o in (r.get("otas") or {}).values()
    )
    doc["health"] = "red" if any_red else "green"
    doc["updated_at"] = datetime.now(timezone.utc).isoformat()

    return firebase_client.publish_document(STATE_COLLECTION, STATE_DOC, doc)


def build_push_record(room: str, target_price: float, ota_pushes: list, mode: str = "applied") -> dict:
    """Builds a CM push confirmation record for the mobile history.

    `ota_pushes` : list of {"ota_name": str, "rate_plan_code": str,
                   "price_sent": float} — one entry per rate plan pushed
                   for this room (several OTAs per room, D20).
    `mode` : "applied" or "simulation" (same values as the `mode` column
             of the `recommendations` table, docs/database_schema.md).
    """
    return {
        "timestamp":    datetime.now(timezone.utc).isoformat(),
        "room_type":    room,
        "target_price": round(float(target_price)) if target_price else None,
        "mode":         mode,
        "ota_pushes":   ota_pushes or [],
    }


def publish_state(results: dict, target_prices: dict, min_gap: float) -> bool:
    """Builds the current state snapshot and publishes it towards Firestore.

    Returns False if the Firebase gateway is not connected or if the
    publication fails — never interrupts the caller (fail-safe, D8).
    """
    from business import firebase_client
    if not firebase_client.is_available():
        return False
    snapshot = build_state_snapshot(results, target_prices, min_gap)
    if not snapshot:
        return False
    return firebase_client.publish_document(STATE_COLLECTION, STATE_DOC, snapshot)


def publish_push_confirmation(room: str, target_price: float, ota_pushes: list, mode: str = "applied") -> bool:
    """Publishes a CM push confirmation into the Firestore history.

    A new document per push (timestamp as id) — the mobile app can
    display a history without overwriting previous confirmations.
    """
    from business import firebase_client
    if not firebase_client.is_available():
        return False
    record = build_push_record(room, target_price, ota_pushes, mode)
    doc_id = record["timestamp"].replace(":", "-")
    return firebase_client.publish_document(PUSH_HISTORY_COLLECTION, doc_id, record)


def build_target_prices_snapshot(target_prices: dict) -> dict:
    """Builds the target-prices document editable from the mobile
    (Settings tab) — direct reflection of config["ota_watch"]["target_prices"],
    independent of the last scan results (unlike
    build_state_snapshot, which only includes actually
    scanned rooms/OTAs)."""
    return {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "rooms": target_prices or {},
    }


def publish_target_prices(target_prices: dict) -> bool:
    """Publishes the target-prices config towards Firestore (collection "config",
    document "target_prices") for mobile-side display/editing.

    Returns False if the gateway is not connected — never interrupts
    the caller (fail-safe, D8)."""
    from business import firebase_client
    if not firebase_client.is_available():
        return False
    snapshot = build_target_prices_snapshot(target_prices)
    return firebase_client.publish_document(CONFIG_COLLECTION, TARGET_PRICES_DOC, snapshot)


def build_notification_prefs_snapshot(prefs: dict) -> dict:
    """Builds the mobile notification preferences document editable
    from the phone (Settings tab) or from the PC (Mobile App
    tab) — direct reflection of config["mobile_notifications"]. One toggle per
    event type (price_gap_detected, correction_envoyee,
    floor_violation); absent from the document = sent by default, see
    scraping/notifications.py::send_mobile_push."""
    return {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "prefs": prefs or {},
    }


def publish_notification_prefs(prefs: dict) -> bool:
    """Publishes the mobile notification preferences towards Firestore
    (collection "config", document "notification_prefs") for
    mobile-side display/editing.

    Returns False if the gateway is not connected — never interrupts
    the caller (fail-safe, D8)."""
    from business import firebase_client
    if not firebase_client.is_available():
        return False
    snapshot = build_notification_prefs_snapshot(prefs)
    return firebase_client.publish_document(CONFIG_COLLECTION, NOTIFICATION_PREFS_DOC, snapshot)


def get_fcm_tokens() -> list:
    """Returns the FCM tokens of paired phones (collection "devices",
    written by the mobile app after registration — see push_registration.dart).

    Empty list if disconnected or no registered phone (fail-safe, D8).
    """
    from business import firebase_client
    if not firebase_client.is_available():
        return []
    docs = firebase_client.get_documents(DEVICES_COLLECTION)
    return [d["token"] for d in docs if d.get("token")]
