"""business/legal_ledger.py — legal evidence journal (D80).

Pattern: vae3/core/evidence_ledger.py from "OTA guard 3.5" (Step 9) —
append-only JSONL in a session folder, VERBATIM records
+ traceability metadata (schema_version, session_id,
record_index, received_at), rotation at 10,000 records per
file, session summary, NEVER a business conclusion, NEVER
purged (capture cleanup never touches this folder).

What is journaled in OTA Guard V3:
  - price_read  : every DISPLAYED price read on an OTA (scan, room-grid
                  dated by the seasonal verification);
  - cm_price    : price IN PLACE observed on the CM grid when it
                  grounds a correction decision;
  - push_order  : every shipment instruction entrusted to the transport (verbatim);
  - push_result : transport verdict per group (ok, sent, msg);
  - post_proof  : proof of POST AddBulkUpdate (capture file) per
                  real shipment — THE proof that the modification left
                  the browser (D32).

Writing: flush per line (crash-safe, a session can stay
open). Write failure: logged, never propagated — the business
flow continues; but NO silent swallowing: the error goes to app.log.
"""
import json
import logging
import time
import uuid
from pathlib import Path

_log = logging.getLogger(__name__)

SCHEMA_VERSION = 1
RECORDS_PER_FILE = 10_000

# injectable for tests (production: <data>/evidence)
_ROOT_OVERRIDE = None

_state = {
    "session_id": None,
    "session_dir": None,
    "file_handle": None,
    "file_index": 0,
    "records_in_file": 0,
    "record_index": 0,
    "closed": False,
    "summary": {"total_records": 0, "by_type": {}},
}


def evidence_dir() -> Path:
    """Root of the journal (created if needed)."""
    if _ROOT_OVERRIDE is not None:
        root = Path(_ROOT_OVERRIDE)
    else:
        from core.paths import DATA_DIR
        root = Path(DATA_DIR) / "evidence"
    root.mkdir(parents=True, exist_ok=True)
    return root


def start_session() -> str:
    """Opens the session folder (one per app run)."""
    if _state["session_id"] is not None:
        return _state["session_id"]
    stamp = time.strftime("%Y%m%dT%H%M%S", time.localtime())
    sid = f"session-{stamp}-{uuid.uuid4().hex[:8]}"
    _state["session_id"] = sid
    _state["session_dir"] = evidence_dir() / sid
    _state["session_dir"].mkdir(parents=True, exist_ok=False)
    _log.info("[LEDGER] evidence session opened: %s", sid)
    return sid


def record(record_type: str, fact: dict) -> bool:
    """Writes ONE record (envelope + verbatim fact). True if written.

    NEVER raises: a write failure is logged in app.log
    and the business flow continues."""
    try:
        if _state["closed"]:
            return False
        if _state["session_dir"] is None:
            start_session()
        _rotate_if_full()
        envelope = {
            "record_type": record_type,
            "schema_version": SCHEMA_VERSION,
            "session_id": _state["session_id"],
            "record_index": _state["record_index"],
            "received_at": time.time(),
            "received_at_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%S", time.localtime()),
            "fact": fact,
        }
        _state["file_handle"].write(
            json.dumps(envelope, ensure_ascii=False, default=str) + "\n")
        _state["file_handle"].flush()
        _state["record_index"] += 1
        _state["records_in_file"] += 1
        _state["summary"]["total_records"] += 1
        bt = _state["summary"]["by_type"]
        bt[record_type] = bt.get(record_type, 0) + 1
        return True
    except Exception:
        _log.exception("[LEDGER] write impossible (type=%s)",
                       record_type)
        return False


def close_session():
    """Session summary + clean close (end of app). Crash-safe if
    never called: every line is already flushed."""
    try:
        if _state["closed"] or _state["session_dir"] is None:
            return
        record("session_summary", _state["summary"])
        _state["file_handle"].close()
        _state["file_handle"] = None
        _state["closed"] = True
        _log.info("[LEDGER] session closed: %s (%s record(s))",
                  _state["session_id"],
                  _state["summary"]["total_records"])
    except Exception:
        _log.exception("[LEDGER] session close impossible")


def _rotate_if_full():
    if _state["file_handle"] is not None \
            and _state["records_in_file"] < RECORDS_PER_FILE:
        return
    if _state["file_handle"] is not None:
        _state["file_handle"].close()
        _state["file_index"] += 1
        _state["records_in_file"] = 0
    else:
        _state["file_index"] = 1
    path = _state["session_dir"] / f"evidence-{_state['file_index']:04d}.jsonl"
    _state["file_handle"] = path.open("a", encoding="utf-8")


# ── business facts (verbatim payloads) ────────────────────────────────────

def journal_price_read(ota, room, price, currency="", date=None,
                       source="", source_file=""):
    return record("price_read", {
        "ota": ota, "room": room, "price": price,
        "currency": currency, "night": date or "",
        "source": source, "source_file": source_file,
    })


def journal_cm_price(room, ota, date, price,
                     source="CM OTASheet grid", source_file=""):
    return record("cm_price", {
        "room": room, "ota": ota, "night": date, "price": price,
        "source": source, "source_file": source_file,
    })


def journal_push_order(entries, transport=""):
    """Instructions entrusted to the transport — verbatim."""
    return record("push_order", {
        "transport": transport,
        "entries": [
            {"room_code": e.get("room_code"),
             "room_label": e.get("room_label"),
             "ota_label": e.get("ota_label"),
             "ota_code": e.get("ota_code"),
             "rate_plan_code": e.get("rate_plan_code"),
             "price": e.get("price"),
             "from_date": e.get("from_date"),
             "to_date": e.get("to_date")}
            for e in (entries or [])
        ],
    })


def journal_push_result(ota_code, ok, sent, msg):
    return record("push_result", {
        "ota_code": ota_code, "ok": bool(ok),
        "sent": int(sent or 0), "msg": str(msg or "")[:600],
    })


def journal_post_proof(post_file, room=None, ota=None, rate=None,
                       from_date=None, to_date=None):
    return record("post_proof", {
        "post_capture_file": str(post_file or ""),
        "room": room or "", "ota": ota or "", "rate": rate,
        "from_date": from_date or "", "to_date": to_date or "",
        "proof": "AddBulkUpdate POST captured (passive, R1)",
    })
