"""
firebase_client.py — Firebase connection (Firestore + Cloud Messaging) for
the OTA Guard mobile gateway.

This module knows NOTHING about the business (scans, prices, rooms): it only
exposes generic operations (publish a document, listen to a collection, send
a push alert). The "OTA Guard state <-> Firestore document" translation is
done elsewhere (mobile_gateway.py, next module).

Optional dependency: firebase-admin. If missing or invalid credentials,
all functions fail silently (return False/None) — the PC app keeps working
normally without the mobile gateway (convention D8).

Expected credentials: the JSON dict of a Firebase service account key
(Firebase Console > Project settings > Service accounts > Generate new
private key). It is a SECRET — the caller is responsible for storing it
encrypted (secrets.py) and never writing it in clear text to disk.
This module never reads/writes a credentials file itself.
"""
import logging
import threading

log = logging.getLogger(__name__)

_app = None                 # dedicated firebase_admin.App instance ("ota_guard_mobile")
_firestore_client = None    # google.cloud.firestore.Client instance
_lock = threading.Lock()
_listeners = []              # active listening handles (for clean shutdown)

_APP_NAME = "ota_guard_mobile"


def is_available() -> bool:
    """True if the Firebase connection is initialized and ready to use."""
    return _firestore_client is not None


def init_firebase(service_account_info: dict) -> bool:
    """Initializes the Firebase Admin connection from a service account.

    Idempotent: a repeated call (e.g. the client switches Firebase) cleanly
    closes the old connection before opening a new one.
    Never raises — returns False if firebase-admin is missing
    or if initialization fails (invalid credentials, no network...).
    """
    global _app, _firestore_client
    with _lock:
        try:
            import firebase_admin
            from firebase_admin import credentials, firestore
        except ImportError:
            log.warning("firebase-admin missing — mobile gateway disabled (pip install firebase-admin)")
            return False

        try:
            existing = firebase_admin.get_app(_APP_NAME)
            firebase_admin.delete_app(existing)
        except ValueError:
            pass  # no app registered yet — normal on first call

        try:
            cred = credentials.Certificate(service_account_info)
            _app = firebase_admin.initialize_app(cred, name=_APP_NAME)
            _firestore_client = firestore.client(_app)
            log.info("firebase_client: connection initialized (project=%s)",
                      service_account_info.get("project_id", "?"))
            return True
        except Exception:
            log.exception("firebase_client: initialization failure")
            _app = None
            _firestore_client = None
            return False


def shutdown() -> None:
    """Stops active listeners and closes the connection (e.g. on app close)."""
    global _app, _firestore_client
    with _lock:
        for handle in _listeners:
            try:
                handle.unsubscribe()
            except Exception:
                pass
        _listeners.clear()
        if _app is not None:
            try:
                import firebase_admin
                firebase_admin.delete_app(_app)
            except Exception:
                pass
        _app = None
        _firestore_client = None


def publish_document(collection: str, document_id: str, data: dict, merge: bool = False) -> bool:
    """Writes a Firestore document. Returns False on failure/disconnected.

    merge=False (default): replaces the whole document.
    merge=True            : merges (only touches the provided fields) — useful
                            to update a status without erasing the rest.
    """
    if _firestore_client is None:
        return False
    try:
        _firestore_client.collection(collection).document(document_id).set(data, merge=merge)
        return True
    except Exception:
        log.exception("firebase_client: publish_document(%s/%s) failure", collection, document_id)
        return False


def listen_for_commands(collection: str, on_command):
    """Continuously listens for new documents of a collection (mobile commands).

    `on_command(doc_id, data)` is called by an internal Firebase SDK thread
    — NOT the main Tkinter thread. The caller must go through
    root.after(0, ...) before touching any UI.

    Returns a listening handle (keep it for shutdown()), or None if
    disconnected / failure.
    """
    if _firestore_client is None:
        return None
    try:
        def _on_snapshot(col_snapshot, changes, read_time):
            for change in changes:
                if change.type.name in ("ADDED", "MODIFIED"):
                    try:
                        on_command(change.document.id, change.document.to_dict())
                    except Exception:
                        log.exception("firebase_client: error in the on_command callback")

        watch = _firestore_client.collection(collection).on_snapshot(_on_snapshot)
        _listeners.append(watch)
        return watch
    except Exception:
        log.exception("firebase_client: listen_for_commands(%s) failure", collection)
        return None


def get_documents(collection: str) -> list:
    """Returns all documents of a collection as a list of dicts.

    Empty list if disconnected or failure (fail-safe, convention D8) — never
    an exception raised to the caller.
    """
    if _firestore_client is None:
        return []
    try:
        return [doc.to_dict() for doc in _firestore_client.collection(collection).stream()]
    except Exception:
        log.exception("firebase_client: get_documents(%s) failure", collection)
        return []


def get_document(collection: str, document_id: str) -> dict:
    """Returns a single Firestore document as a dict.

    Empty dict if disconnected, missing document, or failure (fail-safe,
    convention D8) — never an exception raised to the caller.
    """
    if _firestore_client is None:
        return {}
    try:
        snap = _firestore_client.collection(collection).document(document_id).get()
        return snap.to_dict() or {} if snap.exists else {}
    except Exception:
        log.exception("firebase_client: get_document(%s/%s) failure", collection, document_id)
        return {}


def send_push_alert(fcm_tokens: list, title: str, body: str, data: dict = None) -> bool:
    """Sends a push notification (FCM) to one or more paired phones.

    Returns False if disconnected, no token, or shipment failure. Never interrupts
    the caller (fail-safe, convention D8).
    """
    if _firestore_client is None or not fcm_tokens:
        return False
    try:
        from firebase_admin import messaging
        message = messaging.MulticastMessage(
            notification=messaging.Notification(title=title, body=body),
            data={k: str(v) for k, v in (data or {}).items()},
            tokens=fcm_tokens,
        )
        response = messaging.send_each_for_multicast(message, app=_app)
        if response.failure_count:
            log.warning("firebase_client: %d/%d push alerts failed",
                        response.failure_count, len(fcm_tokens))
        return response.success_count > 0
    except Exception:
        log.exception("firebase_client: send_push_alert failure")
        return False
