"""
qr_pairing.py — Pairing of the phone with OTA Guard via QR code.

Generates a QR code containing the Firebase client configuration (apiKey,
appId, messagingSenderId, projectId, storageBucket) so the companion mobile
app connects to the same Firestore project as the PC.

NON-sensitive data: these are the same values embedded in any Android app
(google-services.json). The service account (Admin SDK) stays encrypted on
the PC side and is never included here.

Optional dependency: qrcode (+ PIL). If missing, a text fallback
(copyable JSON) is displayed instead of the image.
"""
import json
import logging
import tkinter as tk

from core.theme import T
from core.utils import tr_

log = logging.getLogger(__name__)


def _build_payload(client_cfg: dict) -> str:
    """Compact JSON published in the QR — read by the mobile app on scan."""
    return json.dumps({
        "type":       "ota_guard_pairing",
        "version":    1,
        "apiKey":     client_cfg.get("apiKey", ""),
        "appId":      client_cfg.get("appId", ""),
        "messagingSenderId": client_cfg.get("messagingSenderId", ""),
        "projectId":  client_cfg.get("projectId", ""),
        "storageBucket": client_cfg.get("storageBucket", ""),
    }, ensure_ascii=False)


def show_pairing_popup(root: tk.Misc, client_cfg: dict):
    """Show a modal window with the pairing QR code.

    `client_cfg`: dict of the Firebase client fields (already validated by
    l'appelant — apiKey/appId/messagingSenderId/projectId obligatoires).
    """
    win = tk.Toplevel(root)
    win.title(tr_("Phone pairing"))
    win.configure(bg=T.BG)
    win.transient(root)
    win.grab_set()
    win.resizable(False, False)

    tk.Label(win, text=tr_("📱 Mobile app pairing"),
             bg=T.BG, fg=T.ACCENT,
             font=("Segoe UI", 12, "bold")).pack(padx=24, pady=(16, 4))
    tk.Label(win,
             text=tr_("Scan this QR code from the OTA Guard mobile app to connect it to this PC."),
             bg=T.BG, fg=T.FG,
             font=("Segoe UI", 9)).pack(padx=24, pady=(0, 12))

    payload = _build_payload(client_cfg)

    # Try to render a real QR image; fall back to copyable JSON text.
    try:
        import qrcode
        from PIL import Image, ImageTk
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=2,
        )
        qr.add_data(payload)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#1e1e2e", back_color="#ffffff")
        photo = ImageTk.PhotoImage(img)
        lbl = tk.Label(win, image=photo, bg=T.BG, padx=8, pady=8)
        lbl.image = photo  # keep a reference alive
        lbl.pack(padx=24, pady=(0, 12))
    except Exception:
        log.exception("qr_pairing: qrcode/PIL unavailable, text fallback")
        txt = tk.Text(win, width=52, height=8, bg=T.ENTRY_BG, fg=T.FG,
                      font=("Courier New", 8), wrap="char", relief="flat")
        txt.insert("1.0", payload)
        txt.configure(state="disabled")
        txt.pack(padx=24, pady=(0, 8))
        tk.Label(win,
                 text=tr_("QR module unavailable — copy this JSON into the mobile app (manual pairing)."),
                 bg=T.BG, fg=T.ORANGE,
                 font=("Segoe UI", 8)).pack(padx=24, pady=(0, 12))

    def _copy():
        try:
            win.clipboard_clear()
            win.clipboard_append(payload)
            _copy_btn.configure(text=tr_("✅ Copied!"))
        except Exception:
            pass

    _copy_btn = tk.Button(win, text=tr_("📋 Copy configuration"),
                          command=_copy, bg=T.ENTRY_BG, fg=T.FG,
                          activebackground=T.SEL_BG, activeforeground=T.FG,
                          relief="flat", padx=12, pady=4, cursor="hand2")
    _copy_btn.pack(pady=(0, 8))

    tk.Button(win, text=tr_("Close"), command=win.destroy,
              bg=T.SEL_BG, fg=T.FG, activebackground=T.ACCENT,
              activeforeground=T.BG, relief="flat",
              padx=16, pady=4, cursor="hand2").pack(pady=(0, 16))

    # Center on parent
    win.update_idletasks()
    try:
        px = root.winfo_rootx() + (root.winfo_width() - win.winfo_width()) // 2
        py = root.winfo_rooty() + (root.winfo_height() - win.winfo_height()) // 2
        win.geometry(f"+{max(px, 0)}+{max(py, 0)}")
    except Exception:
        pass
