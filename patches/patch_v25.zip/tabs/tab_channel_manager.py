"""
Tab: Channel Manager — OTA Guard
Sections:
  1. CM connection
  2. Test area
  3. Room mapping
  4. Automatic update per room
"""
import os
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).parent.parent

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip, zebra_stripe
from core import config as cfg
from core.base_tab import BaseTab
from core.utils import attach_sort as _attach_sort, tr_, fmt_dt, parse_dt_any
from wizard_engine import CM_TYPES_KEYS, _cm_type_display, _cm_type_from_display


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app
        tab = frame

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("🔌Channel Manager"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("📖 Wiki"), lambda: self._show_wiki("🔌 Channel Manager"),
            color="#89b4fa", width=10).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("💾 Save"), self._save_cm,
            color=T.GREEN, width=14).pack(side="right", padx=4)

        # ── Mode banner (always visible) ──────────────────────────────────
        self._cm_mode_banner = tk.Frame(tab, pady=10)
        self._cm_mode_banner.pack(fill="x")
        self._cm_mode_icon = tk.Label(self._cm_mode_banner,
                                      font=("Segoe UI", 13, "bold"))
        self._cm_mode_icon.pack()
        self._cm_mode_sub = tk.Label(self._cm_mode_banner,
                                     font=("Segoe UI", 9))
        self._cm_mode_sub.pack()

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        cm = self.app.config.get("channel_manager", {})
        self._cm_vars            = {}
        self._cm_mapping_entries = {}

        def _ef(parent, label, key, src, store, default="", show=False, width=32):
            r = tk.Frame(parent, bg=T.BG); r.pack(fill="x", pady=3)
            lbl(r, label, bold=True).pack(side="left", padx=(0, 8))
            v = tk.StringVar(value=str(src.get(key, default)))
            e = tk.Entry(r, textvariable=v, width=width,
                         bg=T.ENTRY_BG, fg=T.FG, insertbackground=T.FG,
                         relief="flat", highlightthickness=1,
                         highlightbackground=T.SEL_BG, highlightcolor=T.ACCENT,
                         font=("Segoe UI", 10))
            if show:
                e.config(show="*")
            e.pack(side="left")
            store[key] = v

        # ══ 1. CONNECTION ══════════════════════════════════════════════════
        s_cm = section(inner, tr_("🔌 Channel Manager Login"))
        s_cm.pack(fill="x", padx=10, pady=8)

        r_type = tk.Frame(s_cm, bg=T.BG); r_type.pack(fill="x", pady=3)
        lbl(r_type, tr_("Type CM"), bold=True).pack(side="left", padx=(0, 8))
        type_v = tk.StringVar(value=_cm_type_display(cm.get("type", "API custom")))
        ttk.Combobox(r_type, textvariable=type_v, width=28, state="readonly",
                     values=[_cm_type_display(k) for k in CM_TYPES_KEYS]).pack(side="left")
        self._cm_vars["type"] = type_v

        _ef(s_cm, "URL endpoint", "endpoint", cm, self._cm_vars, width=44)
        _ef(s_cm, "API Token / API Key", "api_token", cm, self._cm_vars,
            show=True, width=40)

        r_mid = tk.Frame(s_cm, bg=T.BG); r_mid.pack(fill="x", pady=3)
        lbl(r_mid, tr_("Method"), bold=True).pack(side="left", padx=(0, 4))
        meth_v = tk.StringVar(value=cm.get("method", "POST"))
        ttk.Combobox(r_mid, textvariable=meth_v, values=["POST", "PUT", "PATCH"],
                     state="readonly", width=8).pack(side="left", padx=(0, 14))
        self._cm_vars["method"] = meth_v
        lbl(r_mid, tr_("Hotel ID/Code"), bold=True).pack(side="left", padx=(0, 4))
        hid_v = tk.StringVar(value=cm.get("hotel_id", cm.get("hotel_code", "")))
        tk.Entry(r_mid, textvariable=hid_v, width=14, bg=T.ENTRY_BG, fg=T.FG,
                 relief="flat", font=("Segoe UI", 10)).pack(side="left", padx=(0, 14))
        self._cm_vars["hotel_id"] = hid_v

        r_cf = tk.Frame(s_cm, bg=T.BG); r_cf.pack(fill="x", pady=3)
        lbl(r_cf, tr_("Currency"), bold=True).pack(side="left", padx=(0, 4))
        # Read-only: derived from hotel_currency (🏨 My Hotel), the single
        # source — a free field here could drift to a different value and
        # corrupt the real shipment to the Channel Manager.
        _cm_curr_lbl = lbl(r_cf, self.app.config.get("hotel_currency", "INR"),
                            bold=True, color=T.YELLOW)
        _cm_curr_lbl.pack(side="left", padx=(0, 4))
        tooltip(_cm_curr_lbl, tr_("Defined in 🏨 My Hotel — cannot be modified here"))
        lbl(r_cf, tr_("(see 🏨 My Hotel)"), color="#888888", size=8).pack(
            side="left", padx=(0, 18))
        lbl(r_cf, tr_("Format:"), bold=True).pack(side="left", padx=(0, 8))
        fmt_v = tk.StringVar(value=cm.get("format", "json"))
        for val, txt in [("json", "JSON"), ("xml", "XML")]:
            tk.Radiobutton(r_cf, text=txt, variable=fmt_v, value=val,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                           activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=4)
        self._cm_vars["format"] = fmt_v

        # Test / real mode
        mode_f = tk.Frame(s_cm, bg=T.BG); mode_f.pack(fill="x", pady=(10, 4))
        lbl(mode_f, tr_("Shipping method:"), bold=True).pack(side="left", padx=(0, 10))
        self._cm_test_mode_var = tk.BooleanVar(value=cm.get("test_mode", True))
        tk.Radiobutton(mode_f, text=tr_("🧪 TEST MODE (no actual sending)"),
                       variable=self._cm_test_mode_var, value=True,
                       bg=T.BG, fg=T.GREEN, selectcolor=T.ENTRY_BG,
                       activebackground=T.BG, font=("Segoe UI", 10, "bold"),
                       command=self._update_cm_banner).pack(side="left", padx=6)
        tk.Radiobutton(mode_f, text=tr_("🔴 REAL MODE (prices sent to CM)"),
                       variable=self._cm_test_mode_var, value=False,
                       bg=T.BG, fg=T.RED, selectcolor=T.ENTRY_BG,
                       activebackground=T.BG, font=("Segoe UI", 10, "bold"),
                       command=self._update_cm_banner).pack(side="left", padx=6)
        self._cm_vars["test_mode"] = self._cm_test_mode_var

        # Shipping transport (E4 seam): API or Extranet Direct.
        # A single point of truth, here, next to the keys and test mode —
        # the Extranet Direct tab only DISPLAYS this state.
        transport_f = tk.Frame(s_cm, bg=T.BG); transport_f.pack(fill="x", pady=(4, 0))
        lbl(transport_f, tr_("Transportation :"), bold=True).pack(side="left", padx=(0, 10))
        _xd_on = bool((cm.get("extranet_direct") or {}).get("enabled"))
        self._cm_transport_var = tk.StringVar(
            value="extranet" if _xd_on else "api")
        tk.Radiobutton(transport_f, text=tr_("🔑 CM API (API keys)"),
                       variable=self._cm_transport_var, value="api",
                       bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                       activebackground=T.BG,
                       font=("Segoe UI", 10)).pack(side="left", padx=6)
        _xd_rb = tk.Radiobutton(
            transport_f,
            text=tr_("🌐 Extranet Direct (keyless — drives the browser)"),
            variable=self._cm_transport_var, value="extranet",
            bg=T.BG, fg=T.ACCENT, selectcolor=T.ENTRY_BG,
            activebackground=T.BG, font=("Segoe UI", 10))
        _xd_rb.pack(side="left", padx=6)
        tooltip(_xd_rb, tr_("Prices are sent using the real CM form.\nin the browser (Brave), without an API key.\nRequires CM BulkUpdate page opened in Brave."))
        self._cm_vars["_transport"] = self._cm_transport_var

        push_row = tk.Frame(s_cm, bg=T.BG); push_row.pack(fill="x", pady=(6, 0))
        tooltip(btn(push_row, tr_("📤 Push prices"), self._push_to_cm,
                    color=T.ACCENT, width=18),
                "Immediately sends the computed prices\n"
                "to the Channel Manager via the configured API.\n"
                "⚠ Real action — prices are updated live."
                ).pack(side="left")

        save_row = tk.Frame(s_cm, bg=T.BG); save_row.pack(fill="x", pady=(10, 4))
        btn(save_row, tr_("💾 Save configuration"), self._save_cm,
            color=T.GREEN, width=28).pack(side="left")
        btn(save_row, tr_("🔌 Test the connection"), self._test_cm_connection,
            color=T.YELLOW, width=20).pack(side="left", padx=(10, 0))

        # ══ 2. TEST AREA ═══════════════════════════════════════════════════
        s_test = section(inner, tr_("🧪 Channel Manager test area"))
        s_test.pack(fill="x", padx=10, pady=8)

        lbl(s_test, tr_("Test log:"), bold=True).pack(anchor="w", pady=(0, 2))
        self._cm_log = tk.Text(s_test, bg=T.ENTRY_BG, fg=T.FG,
                               font=("Consolas", 9), height=8,
                               relief="flat", state="disabled")
        self._cm_log.pack(fill="x", pady=(0, 6))

        def _log_clear():
            self._cm_log.config(state="normal")
            self._cm_log.delete("1.0", "end")
            self._cm_log.config(state="disabled")

        clr_row = tk.Frame(s_test, bg=T.BG); clr_row.pack(anchor="e", pady=(0, 4))
        btn(clr_row, tr_("🗑 Clear log"), _log_clear,
            color=T.SEL_BG, width=14).pack(side="right")

        nb_test = ttk.Notebook(s_test)
        nb_test.pack(fill="x", pady=4)

        # Tab 1 — Connection
        t_conn = tk.Frame(nb_test, bg=T.BG, padx=10, pady=8)
        nb_test.add(t_conn, text=tr_("1 — Connection"))
        lbl(t_conn, tr_("Verifies that the Channel Manager responds to the configured URL."),
            color="#888888", size=9).pack(anchor="w", pady=(0, 6))
        _ep = cm.get("endpoint", "").strip()
        tk.Label(t_conn,
                 text=tr_("Endpoint: {ep}").format(ep=_ep) if _ep else tr_("⚠ No endpoint configured"),
                 bg=T.BG, fg=T.FG if _ep else T.ORANGE,
                 font=("Consolas", 8)).pack(anchor="w", pady=(0, 6))
        conn_btns = tk.Frame(t_conn, bg=T.BG); conn_btns.pack(anchor="w")
        tooltip(btn(conn_btns, tr_("🔌 Test GET"),
                    self._test_cm_connection, color=T.YELLOW, width=14),
                "Sends a GET request to check the connection."
                ).pack(side="left", padx=(0, 6))
        tooltip(btn(conn_btns, tr_("🔌 Test empty POST"),
                    self._test_cm_post_empty, color=T.ORANGE, width=18),
                "Sends an empty POST to test authentication\n"
                "without modifying any price.").pack(side="left")

        # Tab 2 — Room test
        t_room = tk.Frame(nb_test, bg=T.BG, padx=10, pady=8)
        nb_test.add(t_room, text=tr_("2 — Room test"))
        lbl(t_room,
            "Pick a room, enter a price manually and see what would be sent.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 8))

        r1 = tk.Frame(t_room, bg=T.BG); r1.pack(fill="x", pady=3)
        lbl(r1, tr_("Bedroom :"), bold=True).pack(side="left", padx=(0, 6))
        room_types = [r if isinstance(r, str) else r.get("type", "")
                      for r in self.app.config.get("room_types", [])]
        # "Move room" = virtual CM room for tests — always present
        _TEST_ROOM = "Move room"
        if _TEST_ROOM not in room_types:
            room_types = [_TEST_ROOM] + room_types
        self._cm_test_room_var = tk.StringVar(value=_TEST_ROOM)
        self._cm_test_room_cb = ttk.Combobox(r1, textvariable=self._cm_test_room_var,
                     values=room_types, width=28,
                     state="readonly")
        self._cm_test_room_cb.pack(side="left", padx=(0, 16))
        lbl(r1, tr_("Price ₹:"), bold=True).pack(side="left", padx=(0, 4))
        self._cm_test_price_var = tk.StringVar(value="2000")
        entry(r1, textvariable=self._cm_test_price_var, width=8).pack(side="left")

        # Room Code CM row (visible only for Move room or unmapped room)
        _rc_frame = tk.Frame(t_room, bg=T.BG); _rc_frame.pack(fill="x", pady=2)
        _rc_lbl = tk.Label(_rc_frame, text=tr_("Room Code CM:"), bg=T.BG, fg=T.ACCENT,
                           font=("Segoe UI", 9, "bold"))
        _rc_lbl.pack(side="left", padx=(0, 6))
        _move_room_code = cm.get("room_mapping", {}).get(
            _TEST_ROOM, {}).get("room_code", "")
        self._cm_test_rc_var = tk.StringVar(value=_move_room_code)
        _rc_entry = tk.Entry(_rc_frame, textvariable=self._cm_test_rc_var, width=16,
                             bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                             highlightthickness=1, highlightbackground=T.ACCENT,
                             font=("Segoe UI", 9))
        _rc_entry.pack(side="left", padx=(0, 10))
        tk.Label(_rc_frame,
                 text=tr_("(used if the room does not have a mapping defined)"),
                 bg=T.BG, fg="#666666", font=("Segoe UI", 8)).pack(side="left")

        def _toggle_rc_row(*_):
            sel = self._cm_test_room_var.get()
            mapping_rc = self._collect_cm().get(
                "room_mapping", {}).get(sel, {})
            has_code = bool(mapping_rc.get("room_code", "") if isinstance(
                mapping_rc, dict) else str(mapping_rc))
            # Show the field if "Move room" or if the room has no code
            if sel == _TEST_ROOM or not has_code:
                _rc_frame.pack(fill="x", pady=2)
            else:
                _rc_frame.pack_forget()
        self._cm_test_room_var.trace_add("write", _toggle_rc_row)
        _toggle_rc_row()   # initial state

        r2 = tk.Frame(t_room, bg=T.BG); r2.pack(fill="x", pady=3)
        lbl(r2, tr_("Arrival date:"), bold=True).pack(side="left", padx=(0, 6))
        self._cm_checkin_var = tk.StringVar(
            value=datetime.now().strftime("%d/%m/%Y"))
        entry(r2, textvariable=self._cm_checkin_var,
              width=12).pack(side="left", padx=(0, 16))
        lbl(r2, tr_("Nights:"), bold=True).pack(side="left", padx=(0, 4))
        self._cm_nights_var = tk.StringVar(value="1")
        tk.Spinbox(r2, textvariable=self._cm_nights_var, from_=1, to=30,
                   width=4, bg=T.ENTRY_BG, fg=T.FG,
                   font=("Segoe UI", 10)).pack(side="left")

        r3 = tk.Frame(t_room, bg=T.BG); r3.pack(fill="x", pady=(6, 2))
        self._cm_test_send_var = tk.BooleanVar(value=False)
        btn(r3, tr_("👁 Preview only"),
            lambda: (self._cm_test_send_var.set(False), self._cm_test_room()),
            color=T.ACCENT, width=20).pack(side="left", padx=(0, 8))
        btn(r3, tr_("📤 Send to Channel Manager"),
            lambda: (self._cm_test_send_var.set(True), self._cm_test_room()),
            color=T.GREEN, width=26).pack(side="left")

        # Tab 3 — From scan
        t_scan = tk.Frame(nb_test, bg=T.BG, padx=10, pady=8)
        nb_test.add(t_scan, text=tr_("3 — From scan"))
        lbl(t_scan,
            "Checks the full pipeline: scan data → payload → CM shipment.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 6))
        _scan_date = fmt_dt(self._load_last_scan().get("scan_date", ""), with_time=False)
        _scan_ncomp = len(self._load_last_scan().get("raw_by_competitor", {}))
        tk.Label(t_scan,
                 text=(tr_("📅 Last scan: {date} — {n} competitor(s)").format(
                           date=_scan_date, n=_scan_ncomp)
                       if _scan_date else tr_("⚠ No scans available — run a scan first.")),
                 bg=T.BG, fg=T.FG if _scan_date else T.ORANGE,
                 font=("Consolas", 8)).pack(anchor="w", pady=(0, 8))
        scan_btns = tk.Frame(t_scan, bg=T.BG); scan_btns.pack(anchor="w")
        tooltip(btn(scan_btns, tr_("🔍 See full pipeline"),
                    self._cm_test_from_scan, color=T.ACCENT, width=22),
                "Shows all the pipeline steps."
                ).pack(side="left", padx=(0, 8))
        tooltip(btn(scan_btns, tr_("📤 Dry Run (simulation)"),
                    self._dry_run_cm, color=T.YELLOW, width=24),
                "Simulates the shipment without modifying anything."
                ).pack(side="left")

        # Tab 4 — Raw payload
        t_raw = tk.Frame(nb_test, bg=T.BG, padx=10, pady=8)
        nb_test.add(t_raw, text=tr_("4 — Gross payload"))
        lbl(t_raw,
            "Manually sends a raw JSON/XML payload to the endpoint.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 4))
        _ep4 = cm.get("endpoint", "").strip()
        tk.Label(t_raw,
                 text=tr_("Endpoint: {ep}").format(ep=_ep4) if _ep4 else tr_("⚠ No endpoint configured"),
                 bg=T.BG, fg=T.FG if _ep4 else T.ORANGE,
                 font=("Consolas", 8)).pack(anchor="w", pady=(0, 8))
        self._cm_raw_text = tk.Text(t_raw, bg=T.ENTRY_BG, fg=T.FG,
                                    font=("Consolas", 10), height=7,
                                    relief="flat", insertbackground=T.FG)
        self._cm_raw_text.insert("1.0",
            '{\n  "room_type": "Deluxe Room",\n'
            '  "price": 2000,\n  "currency": "INR"\n}')
        self._cm_raw_text.pack(fill="x", pady=(0, 6))
        raw_btns = tk.Frame(t_raw, bg=T.BG); raw_btns.pack(anchor="w")
        btn(raw_btns, tr_("📤 Send raw payload"),
            self._cm_send_raw, color=T.ORANGE, width=22).pack(side="left", padx=(0, 8))
        btn(raw_btns, tr_("♻ Generate from template"),
            self._cm_fill_raw_from_template, color=T.ACCENT, width=24).pack(side="left")

        # ══ 3. ROOM MAPPING ════════════════════════════════════════════════
        s_map = section(inner, tr_("🗺 Room mapping → Channel Manager"))
        s_map.pack(fill="x", padx=10, pady=6)
        lbl(s_map, tr_("Associate each room with its CM codes."),
            color=T.FG, size=9).pack(anchor="w", pady=(0, 2))
        lbl(s_map,
            "OTA discount %: discount applied by the OTA on the sent rate. "
            "OTA Guard automatically computes the right price to send to the CM.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 8))

        _fetch_row = tk.Frame(s_map, bg=T.BG); _fetch_row.pack(fill="x", pady=(0, 10))
        tooltip(
            btn(_fetch_row, tr_("📥Retrieve Rooms from CM"),
                self._fetch_cm_room_info, color="#FF7700", width=34),
            "Queries the Channel Manager API and displays\n"
            "the list of available rooms and rate plans."
        ).pack(side="left")

        cm_mapping = cm.get("room_mapping", {})
        _base = [rt if isinstance(rt, str) else rt.get("type", "")
                 for rt in self.app.config.get("room_types", [])]
        _extra = [r for r in cm_mapping if r not in _base]

        _COL_FONT = ("Segoe UI", 9)

        def _make_rp_row(table_f, rp_data, rp_vars_list):
            """Adds an OTA row to the grid table (table_f).
            row 0 = headers (already created), row 1+ = data."""
            ota_v  = tk.StringVar(value=rp_data.get("ota_name", ""))
            otac_v = tk.StringVar(value=str(rp_data.get("ota_code", "")))
            rpc_v  = tk.StringVar(value=rp_data.get("rate_plan_code", ""))
            try:
                disc_val = int(float(rp_data.get("ota_discount_pct", 0) or 0))
            except (ValueError, TypeError):
                disc_val = 0
            disc_v = tk.StringVar(value=str(disc_val))
            rp_vars = {"ota_name": ota_v, "ota_code": otac_v,
                       "rate_plan_code": rpc_v, "ota_discount_pct": disc_v}
            rp_vars_list.append(rp_vars)
            ridx = len(rp_vars_list)   # 1, 2, 3, … (row 0 = headers)

            e0 = tk.Entry(table_f, textvariable=ota_v, bg=T.ENTRY_BG,
                          fg=T.ACCENT, relief="flat",
                          font=(_COL_FONT[0], _COL_FONT[1], "bold"))
            e0.grid(row=ridx, column=0, sticky="ew", padx=(0, 2), pady=1)

            e1 = tk.Entry(table_f, textvariable=otac_v, bg=T.ENTRY_BG,
                          fg="#f08030", relief="flat", font=_COL_FONT)
            e1.grid(row=ridx, column=1, sticky="ew", padx=(0, 2), pady=1)

            e2 = tk.Entry(table_f, textvariable=rpc_v, bg=T.ENTRY_BG,
                          fg=T.FG, relief="flat", font=_COL_FONT)
            e2.grid(row=ridx, column=2, sticky="ew", padx=(0, 2), pady=1)

            disc_f = tk.Frame(table_f, bg=T.SEL_BG)
            disc_f.grid(row=ridx, column=3, sticky="ew", padx=(0, 2), pady=1)
            tk.Entry(disc_f, textvariable=disc_v, bg=T.ENTRY_BG, fg=T.GREEN,
                     relief="flat", width=5,
                     font=(_COL_FONT[0], _COL_FONT[1], "bold")).pack(side="left",
                                                                       fill="x", expand=True)
            tk.Label(disc_f, text="%", bg=T.SEL_BG, fg="#888888",
                     font=_COL_FONT).pack(side="left")

            row_ws = [e0, e1, e2, disc_f]

            def _del(_rv=rp_vars, _ws=row_ws, _lst=rp_vars_list):
                if len(_lst) > 1:
                    _lst.remove(_rv)
                    for w in _ws:
                        w.destroy()
                    _del_btn.destroy()

            _del_btn = tk.Button(table_f, text="🗑", command=_del,
                                 bg=T.SEL_BG, fg=T.RED, relief="flat",
                                 font=("Segoe UI", 9), cursor="hand2", bd=0)
            _del_btn.grid(row=ridx, column=4, pady=1, padx=(2, 0))

        self._make_rp_row_fn = _make_rp_row
        self._mapping_cards_frame = tk.Frame(s_map, bg=T.BG)
        self._mapping_cards_frame.pack(fill="x")

        for room in _base + _extra:
            if not room:
                continue
            rm = cm_mapping.get(room, {})

            # ── Per-room card ─────────────────────────────────────────────
            card = tk.Frame(self._mapping_cards_frame, bg=T.SEL_BG, padx=8, pady=6,
                            highlightthickness=1, highlightbackground=T.ACCENT)
            card.pack(fill="x", pady=3)

            # Row 1: room name + delete button
            title_row = tk.Frame(card, bg=T.SEL_BG); title_row.pack(fill="x")
            tk.Label(title_row, text=room, bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 10, "bold"),
                     anchor="w").pack(side="left", fill="x", expand=True)
            tk.Button(title_row, text="🗑", bg=T.SEL_BG, fg=T.RED,
                      relief="flat", font=("Segoe UI", 9), cursor="hand2", bd=0,
                      command=lambda r=room, c=card: self._delete_mapping_room(r, c)
                      ).pack(side="right")
            # Row 2: Room Code CM
            hrow = tk.Frame(card, bg=T.SEL_BG); hrow.pack(fill="x", pady=(2, 0))
            lbl(hrow, tr_("Room Code CM:"), bold=True, bg=T.SEL_BG).pack(side="left", padx=(0, 4))
            rc_v = tk.StringVar(
                value=rm.get("room_code", rm) if isinstance(rm, dict) else str(rm))
            tk.Entry(hrow, textvariable=rc_v, width=14, bg=T.ENTRY_BG, fg=T.FG,
                     relief="flat", highlightthickness=1,
                     highlightbackground=T.ACCENT,
                     font=("Segoe UI", 10)).pack(side="left")

            # Rate Plans table — header + data in grid (stretches full width)
            table_f = tk.Frame(card, bg=T.SEL_BG)
            table_f.pack(fill="x", pady=(4, 0))
            table_f.columnconfigure(0, weight=4)   # OTA
            table_f.columnconfigure(1, weight=3)   # CM OTA Code
            table_f.columnconfigure(2, weight=3)   # Rate Plan
            table_f.columnconfigure(3, weight=2)   # Discount %
            table_f.columnconfigure(4, weight=0, minsize=28)  # 🗑
            # Headers (row 0) — same cells as the data → perfect alignment
            for c, txt in enumerate(["OTA", "CM OTA Code", "Rate Plan", "Discount %", ""]):
                tk.Label(table_f, text=txt, bg=T.BG, fg=T.ACCENT,
                         font=(_COL_FONT[0], _COL_FONT[1], "bold"),
                         anchor="center"
                         ).grid(row=0, column=c, sticky="ew",
                                padx=(0, 2), pady=(0, 3))

            rp_vars_list = []

            # Load the rate plans from config (new or backward compatible)
            if isinstance(rm, dict):
                rate_plans_cfg = rm.get("rate_plans", [])
                if not rate_plans_cfg:
                    old_rpc  = rm.get("rate_plan_code", "")
                    old_disc = float(rm.get("ota_discount_pct", 0) or 0)
                    rate_plans_cfg = [{"rate_plan_code":   old_rpc,
                                       "ota_discount_pct": old_disc}]
            else:
                rate_plans_cfg = [{"rate_plan_code": "", "ota_discount_pct": 0}]

            for rp_data in rate_plans_cfg:
                _make_rp_row(table_f, rp_data, rp_vars_list)

            # Add Rate Plan button
            add_row = tk.Frame(card, bg=T.SEL_BG); add_row.pack(fill="x", pady=(3, 0))
            btn(add_row, tr_("+ Rate Plan"),
                lambda _c=table_f, _l=rp_vars_list: _make_rp_row(_c, {}, _l),
                color="#313244", width=14).pack(side="left")

            self._cm_mapping_entries[room] = {"room_code": rc_v,
                                              "rate_plans": rp_vars_list}


        # ── Internal compat (kept to avoid AttributeError) ───────────────
        self._update_cm_banner()

    def refresh_on_show(self):
        """Tab built once at startup — re-syncs the lists/cards depending
        on room_types (add/remove in My Hotel) every time this tab becomes
        visible again, without restart."""
        import logging
        try:
            self._refresh_mapping_cards()
        except Exception:
            logging.exception("refresh_on_show (tab_channel_manager): _refresh_mapping_cards failed")

        try:
            cb = getattr(self, "_cm_test_room_cb", None)
            if cb is not None and cb.winfo_exists():
                room_types = [r if isinstance(r, str) else r.get("type", "")
                              for r in self.app.config.get("room_types", [])]
                _TEST_ROOM = "Move room"
                if _TEST_ROOM not in room_types:
                    room_types = [_TEST_ROOM] + room_types
                cb.config(values=room_types)
                if self._cm_test_room_var.get() not in room_types:
                    self._cm_test_room_var.set(_TEST_ROOM)
        except Exception:
            logging.exception("refresh_on_show (tab_channel_manager): per-room test combobox failed")

    # ── Methods ───────────────────────────────────────────────────────────

    def _update_cm_banner(self):
        if not hasattr(self, "_cm_mode_banner"):
            return
        is_test = (self._cm_test_mode_var.get()
                   if hasattr(self, "_cm_test_mode_var")
                   else self.app.config.get("channel_manager", {}).get(
                       "test_mode", True))
        if is_test:
            self._cm_mode_banner.config(bg="#1a3a1a")
            self._cm_mode_icon.config(text=tr_("🧪 ACTIVE TEST MODE"),
                                      bg="#1a3a1a", fg="white")
            self._cm_mode_sub.config(
                text=tr_("No prices will be sent to the Channel Manager — simulation only"),
                bg="#1a3a1a", fg="#d0f0d0")
        else:
            self._cm_mode_banner.config(bg="#4a0a0a")
            self._cm_mode_icon.config(
                text=tr_("🔴 REAL ACTIVE MODE — YOUR PRICES WILL BE CHANGED"),
                bg="#4a0a0a", fg="white")
            self._cm_mode_sub.config(
                text=tr_("⚠ Each click on “Push Prices” will send the real prices to your CM"),
                bg="#4a0a0a", fg="#ffd0d0")

    def _delete_mapping_room(self, room, card):
        """Removes a room from the CM mapping and destroys its card."""
        mapping = self.app.config.get("channel_manager", {}).get("room_mapping", {})
        mapping.pop(room, None)
        cfg.save(self.app.config)
        self._cm_mapping_entries.pop(room, None)
        card.destroy()

    def _refresh_mapping_cards(self):
        """Destroys and rebuilds the 🗺 cards from the current config."""
        if not hasattr(self, "_mapping_cards_frame"):
            return
        for w in self._mapping_cards_frame.winfo_children():
            w.destroy()
        self._cm_mapping_entries.clear()

        cm = self.app.config.get("channel_manager", {})
        cm_mapping = cm.get("room_mapping", {})
        _base = [rt if isinstance(rt, str) else rt.get("type", "")
                 for rt in self.app.config.get("room_types", [])]
        _extra = [r for r in cm_mapping if r not in _base]
        _fn = getattr(self, "_make_rp_row_fn", None)
        if _fn is None:
            return

        for room in _base + _extra:
            if not room:
                continue
            rm = cm_mapping.get(room, {})
            card = tk.Frame(self._mapping_cards_frame, bg=T.SEL_BG, padx=8, pady=6,
                            highlightthickness=1, highlightbackground=T.ACCENT)
            card.pack(fill="x", pady=3)
            title_row = tk.Frame(card, bg=T.SEL_BG); title_row.pack(fill="x")
            tk.Label(title_row, text=room, bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 10, "bold"), anchor="w").pack(side="left", fill="x", expand=True)
            tk.Button(title_row, text="🗑", bg=T.SEL_BG, fg=T.RED,
                      relief="flat", font=("Segoe UI", 9), cursor="hand2", bd=0,
                      command=lambda r=room, c=card: self._delete_mapping_room(r, c)
                      ).pack(side="right")
            hrow = tk.Frame(card, bg=T.SEL_BG); hrow.pack(fill="x", pady=(2, 0))
            lbl(hrow, tr_("Room Code CM:"), bold=True, bg=T.SEL_BG).pack(side="left", padx=(0, 4))
            rc_v = tk.StringVar(
                value=rm.get("room_code", rm) if isinstance(rm, dict) else str(rm))
            tk.Entry(hrow, textvariable=rc_v, width=14, bg=T.ENTRY_BG, fg=T.FG,
                     relief="flat", highlightthickness=1, highlightbackground=T.ACCENT,
                     font=("Segoe UI", 10)).pack(side="left")
            table_f = tk.Frame(card, bg=T.SEL_BG)
            table_f.pack(fill="x", pady=(4, 0))
            table_f.columnconfigure(0, weight=4)
            table_f.columnconfigure(1, weight=3)
            table_f.columnconfigure(2, weight=3)
            table_f.columnconfigure(3, weight=2)
            table_f.columnconfigure(4, weight=0, minsize=28)
            for c, txt in enumerate(["OTA", "CM OTA Code", "Rate Plan", "Discount %", ""]):
                tk.Label(table_f, text=txt, bg=T.BG, fg=T.ACCENT,
                         font=("Segoe UI", 9, "bold"), anchor="center"
                         ).grid(row=0, column=c, sticky="ew", padx=(0, 2), pady=(0, 3))
            rp_vars_list = []
            if isinstance(rm, dict):
                rate_plans_cfg = rm.get("rate_plans", [])
                if not rate_plans_cfg:
                    rate_plans_cfg = [{"rate_plan_code": rm.get("rate_plan_code", ""),
                                       "ota_discount_pct": float(rm.get("ota_discount_pct", 0) or 0)}]
            else:
                rate_plans_cfg = [{"rate_plan_code": "", "ota_discount_pct": 0}]
            for rp_data in rate_plans_cfg:
                _fn(table_f, rp_data, rp_vars_list)
            add_row = tk.Frame(card, bg=T.SEL_BG); add_row.pack(fill="x", pady=(3, 0))
            btn(add_row, tr_("+ Rate Plan"),
                lambda _c=table_f, _l=rp_vars_list: _fn(_c, {}, _l),
                color="#313244", width=14).pack(side="left")
            self._cm_mapping_entries[room] = {"room_code": rc_v, "rate_plans": rp_vars_list}

    def _collect_cm(self):
        cm = {}
        for k, v in self._cm_vars.items():
            cm[k] = v.get()
        if "type" in cm:
            cm["type"] = _cm_type_from_display(cm["type"])
        # Transport (E4 seam): "_transport" is not a CM key per se — it
        # drives channel_manager.extranet_direct.
        # The other sub-keys (captures_dir…) are preserved.
        _tr_val = cm.pop("_transport", "api")
        _xd = dict((self.app.config.get("channel_manager", {})
                    .get("extranet_direct")) or {})
        _xd["enabled"] = (_tr_val == "extranet")
        cm["extranet_direct"] = _xd
        # Currency always taken from hotel_currency (My Hotel) — the field in
        # this tab is read-only (see _build_content), so never stored in
        # self._cm_vars; we set it explicitly to avoid losing the key when
        # _save_cm() replaces the whole channel_manager dict.
        cm["currency"] = self.app.config.get("hotel_currency", "INR")
        cm["headers"]       = '{"Content-Type": "application/json"}'
        cm["body_template"] = ""
        mapping = {}
        for room, vars_ in self._cm_mapping_entries.items():
            if isinstance(vars_, dict) and "rate_plans" in vars_:
                rc = vars_["room_code"].get().strip()
                rate_plans = []
                for rp_v in vars_.get("rate_plans", []):
                    rpc      = rp_v["rate_plan_code"].get().strip()
                    ota      = rp_v["ota_name"].get().strip() if "ota_name" in rp_v else ""
                    ota_code = rp_v["ota_code"].get().strip() if "ota_code" in rp_v else ""
                    try:
                        disc = float(
                            rp_v["ota_discount_pct"].get().replace(",", "."))
                    except (ValueError, TypeError):
                        disc = 0.0
                    if rpc:
                        rate_plans.append({
                            "ota_name":         ota,
                            "ota_code":         ota_code,
                            "rate_plan_code":   rpc,
                            "ota_discount_pct": disc,
                        })
                mapping[room] = {"room_code": rc, "rate_plans": rate_plans}
            elif isinstance(vars_, dict):
                # Backward compatibility: old structure without rate_plans
                mapping[room] = {
                    "room_code":      vars_["room_code"].get().strip(),
                    "rate_plan_code": vars_.get(
                        "rate_plan_code", tk.StringVar()).get().strip()}
            else:
                mapping[room] = getattr(vars_, "get", lambda: str(vars_))().strip()
        cm["room_mapping"] = mapping
        from core.utils import tr_ as _tr
        _trig_map = {
            "Manual — I click myself":         "manual",
            _tr("Manual — I click myself"):    "manual",
            "Once a day at a fixed time":      "daily_once",
            _tr("Once a day at a fixed time"): "daily_once",
        }
        # ota_auto_update: handled by tab_blocage_ota → do not overwrite
        # room_auto_update: kept for old-config compatibility
        cm["room_auto_update"] = cm.get("room_auto_update", {})
        return cm

    def _save_cm(self):
        self.app.config["channel_manager"] = self._collect_cm()
        cfg.save(self.app.config)
        self._update_cm_banner()
        messagebox.showinfo(tr_("Saved"),
                            tr_("Channel Manager configuration saved."),
                            parent=self.app.root)

    def _cm_log_write(self, txt):
        if not hasattr(self, "_cm_log"):
            return
        self._cm_log.config(state="normal")
        self._cm_log.insert("end", txt + "\n")
        self._cm_log.config(state="disabled")
        self._cm_log.see("end")

    def _test_cm_connection(self):
        c2       = self._collect_cm()
        endpoint = c2.get("endpoint", "").strip()
        if not endpoint:
            messagebox.showwarning(tr_("CM test"),
                "Configure the endpoint URL first.",
                parent=self.app.root)
            return

        def _task():
            import time
            from business.channel_manager import get_room_info, URL_ROOMINFO
            hotel_code = c2.get("hotel_id", "").strip()
            t0 = time.time()
            try:
                ok, msg, body = get_room_info(c2)
                ms = int((time.time() - t0) * 1000)
                import json as _json
                try:
                    data = _json.loads(body)
                    rooms = data.get("Rooms", [])
                    nb_rooms = len(rooms)
                except Exception:
                    rooms, nb_rooms = [], 0

                if ok and nb_rooms > 0:
                    verdict = f"✅ Connection OK — {nb_rooms} room(s) found"
                elif ok:
                    verdict = f"✅ Auth accepted — {msg}"
                else:
                    verdict = f"❌ {msg}"

                self.app.root.after(0, lambda: self._cm_log_write(
                    f"[CONNECTION TEST]\n"
                    f"  URL        : {URL_ROOMINFO}\n"
                    f"  HotelCode  : {hotel_code}\n"
                    f"  Duration   : {ms} ms\n"
                    f"  {verdict}\n"
                    f"  Body received: {body[:400]}\n"))
            except Exception as e:
                self.app.root.after(0, lambda e=e: self._cm_log_write(
                    f"[CONNECTION TEST] Error: {e}\n"))

        threading.Thread(target=_task, daemon=True).start()
        self._cm_log_write("[CONNECTION TEST] In progress…")

    def _test_cm_post_empty(self):
        c2       = self._collect_cm()
        endpoint = c2.get("endpoint", "").strip()
        if not endpoint:
            messagebox.showwarning(tr_("CM test"),
                "Configure the endpoint URL first.",
                parent=self.app.root)
            return

        def _task():
            import time, requests as _req
            token   = c2.get("api_token", "").strip()
            headers = {"Content-Type": "application/json"}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            t0 = time.time()
            try:
                r   = _req.post(endpoint, headers=headers, json={}, timeout=15)
                ms  = int((time.time() - t0) * 1000)
                self.app.root.after(0, lambda: self._cm_log_write(
                    f"[EMPTY POST]\n  URL    : {endpoint}\n"
                    f"  Status : HTTP {r.status_code} ({ms} ms)\n"
                    f"  Body   : {r.text[:500]}\n"))
            except Exception as e:
                self.app.root.after(0, lambda e=e: self._cm_log_write(
                    f"[EMPTY POST] Error: {e}\n"))

        threading.Thread(target=_task, daemon=True).start()
        self._cm_log_write("[EMPTY POST] Sending…")

    def _cm_test_room(self):
        c2       = self._collect_cm()
        endpoint = c2.get("endpoint", "").strip()
        room     = self._cm_test_room_var.get().strip()
        # Entry displays d/m/y; the CM API needs ISO — normalize here.
        checkin  = parse_dt_any(self._cm_checkin_var.get().strip()
                    or datetime.now().strftime("%d/%m/%Y"))
        do_send  = self._cm_test_send_var.get()
        try:
            price = float(self._cm_test_price_var.get())
        except Exception:
            messagebox.showwarning(tr_("CM test"), tr_("Invalid price."),
                                   parent=self.app.root)
            return
        try:
            nights = int(self._cm_nights_var.get())
        except Exception:
            nights = 1
        mapping = c2.get("room_mapping", {})
        # Case-insensitive lookup (config may store "move room" or "Move room")
        rm = mapping.get(room) or next(
            (v for k, v in mapping.items() if k.lower() == room.lower()), {})
        rc = rm.get("room_code", "") if isinstance(rm, dict) else str(rm)
        # rate_plan: look for "rate_plan_code" first (old format)
        # then the first element of "rate_plans" (new format)
        rp = ""
        if isinstance(rm, dict):
            rp = rm.get("rate_plan_code") or next(
                (p.get("rate_plan_code", "") for p in rm.get("rate_plans", [])), "")
        # Fallback: manually entered Room Code (Move room or unmapped)
        if not rc and hasattr(self, "_cm_test_rc_var"):
            rc = self._cm_test_rc_var.get().strip()
        if not rc:
            self._cm_log_write(
                f"[ROOM TEST] ⚠ No Room Code for \"{room}\" — "
                "enter it in the \"Room Code CM\" field above.\n")
            return

        import json as _json
        from business.channel_manager import build_rate_push_json
        payload = build_rate_push_json(c2, [
            {"room_code": rc, "rate_plan_code": rp, "price": price}],
            checkin=checkin, nights=nights)
        body_rendered = _json.dumps(payload, indent=2, ensure_ascii=False)

        lines = [
            f"[ROOM TEST] ─────────────────────────────",
            f"  Room          : {room}",
            f"  CM Code       : {rc}  |  Rate Plan : {rp}",
            f"  Entered price : ₹{price:,.0f}",
            f"  Date          : {checkin}  ({nights} night{'s' if nights > 1 else ''})",
            f"  Endpoint      : {endpoint or '(not configured)'}",
            f"  Method        : {c2.get('method', 'POST')}",
            f"  Generated body:\n{body_rendered}",
        ]
        self._cm_log_write("\n".join(lines))

        if not do_send:
            self._cm_log_write("  → Preview only ('Send' checkbox unchecked).\n")
            return
        if not endpoint:
            self._cm_log_write("  ⚠ No endpoint configured — shipment cancelled.\n")
            return

        def _task():
            import time, requests as req
            token   = c2.get("api_token", "").strip()
            headers = {"Content-Type": "application/json"}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            try:
                headers.update(_json.loads(c2.get("headers", "{}")))
            except Exception:
                pass
            t0 = time.time()
            try:
                pl = _json.loads(body_rendered)
            except Exception:
                pl = body_rendered
            try:
                method = c2.get("method", "POST").upper()
                r = getattr(req, method.lower())(
                    endpoint, headers=headers,
                    json=pl if isinstance(pl, dict) else None,
                    data=body_rendered if not isinstance(pl, dict) else None,
                    timeout=15)
                ms = int((time.time() - t0) * 1000)
                self.app.root.after(0, lambda: self._cm_log_write(
                    f"  → HTTP {r.status_code} ({ms} ms) | {r.text[:300]}\n"))
            except Exception as e:
                self.app.root.after(0, lambda e=e: self._cm_log_write(
                    f"  → Send error: {e}\n"))
        threading.Thread(target=_task, daemon=True).start()

    def _cm_test_from_scan(self):
        self._cm_log_write("[SCAN] Full pipeline — see the Journal tab for details.\n")

    def _dry_run_cm(self):
        c2 = self._collect_cm()
        import json as _json
        self._cm_log_write(
            f"[DRY RUN] CM config:\n"
            f"{_json.dumps({k: v for k, v in c2.items() if k != 'api_token'}, indent=2)}\n")

    def _cm_send_raw(self):
        c2       = self._collect_cm()
        endpoint = c2.get("endpoint", "").strip()
        raw      = self._cm_raw_text.get("1.0", "end").strip()
        if not endpoint:
            messagebox.showwarning(tr_("CM test"),
                "Configure the endpoint URL first.",
                parent=self.app.root)
            return

        def _task():
            import json as _json, requests as _req
            token   = c2.get("api_token", "").strip()
            headers = {"Content-Type": "application/json"}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            try:
                payload = _json.loads(raw)
                r = _req.post(endpoint, headers=headers,
                              json=payload, timeout=20)
                self.app.root.after(0, lambda: self._cm_log_write(
                    f"[RAW] HTTP {r.status_code} : {r.text[:400]}\n"))
            except Exception as e:
                self.app.root.after(0, lambda e=e: self._cm_log_write(
                    f"[RAW] Error: {e}\n"))

        threading.Thread(target=_task, daemon=True).start()
        self._cm_log_write("[RAW] Sending…")

    def _cm_fill_raw_from_template(self):
        c2 = self._collect_cm()
        import json as _json
        from business.channel_manager import build_rate_push_json
        rooms = self.app.config.get("room_types", [])
        if not rooms:
            self._cm_log_write("[TEMPLATE] No room configured.\n")
            return
        room    = rooms[0] if isinstance(rooms[0], str) else rooms[0].get("type", "")
        mapping = c2.get("room_mapping", {})
        rm      = mapping.get(room, {})
        rc      = rm.get("room_code", "ROOM_CODE") if isinstance(rm, dict) else "ROOM_CODE"
        rp      = rm.get("rate_plan_code", "RATE_PLAN") if isinstance(rm, dict) else "RATE_PLAN"
        payload = build_rate_push_json(c2, [
            {"room_code": rc, "rate_plan_code": rp, "price": 2000}])
        self._cm_raw_text.delete("1.0", "end")
        self._cm_raw_text.insert("1.0",
            _json.dumps(payload, indent=2, ensure_ascii=False))

    def _push_to_cm(self):
        self._do_push(
            getattr(self, "_scan_results", {}),
            self._collect_cm(),
            datetime.now().strftime("%Y-%m-%d"),
            1, self._cm_log, silent=False)

    def _fetch_cm_codes(self):
        """Redirects to the existing popup (Retrieve Rooms from CM button)."""
        self._fetch_cm_room_info()

    def _fetch_cm_room_info(self):
        """Calls the CM roominfo API, parses JSON/XML,
        shows a window to copy the codes into the mapping."""
        from business.channel_manager import get_room_info
        cm_cfg = self._collect_cm()

        if not cm_cfg.get("hotel_id") or not cm_cfg.get("api_token"):
            messagebox.showwarning(tr_("Incomplete configuration"),
                "Fill in the Hotel ID and API Token before retrieving rooms.",
                parent=self.app.root)
            return

        try:
            ok, msg, body = get_room_info(cm_cfg)
        except Exception as e:
            messagebox.showerror(tr_("CM error"), str(e), parent=self.app.root)
            return

        if not ok:
            # The request failed (network, refused credentials, timeout...):
            # `msg` holds the real reason (from _post) — display it
            # instead of falling into JSON/XML parsing of an empty body,
            # which produced a confusing message ("no element found: line 1...").
            messagebox.showerror(tr_("CM error"),
                f"The Channel Manager did not respond correctly:\n{msg}",
                parent=self.app.root)
            return

        # Parse JSON first, XML fallback — extract everything useful
        rooms = []
        try:
            import json as _json
            data = _json.loads(body)
            for r in data.get("Rooms", []):
                rname    = r.get("RoomName", "")
                rid      = str(r.get("RoomId", ""))
                count    = int(r.get("TotalRooms",    r.get("RoomCount",
                           r.get("NumberOfUnits",     r.get("Quantity", 0)))) or 0)
                max_occ  = int(r.get("MaxOccupancy",  r.get("MaxGuests", 0)) or 0)
                for rp in r.get("RoomRatePlans", [r]):
                    rooms.append({
                        "room_name":      rname,
                        "room_id":        rid,
                        "count":          count,
                        "max_occupancy":  max_occ,
                        "rate_plan_id":   str(rp.get("RatePlanId", "")),
                        "rate_plan_name": rp.get("RatePlanName", ""),
                        "meal_plan":      rp.get("MealPlan", rp.get("BoardType", "")),
                    })
        except Exception:
            try:
                import xml.etree.ElementTree as _ET
                root_xml = _ET.fromstring(body)
                for rd in root_xml.findall(".//RoomData"):
                    rname   = (rd.findtext("RoomName") or "").strip()
                    rid     = (rd.findtext("RoomId")   or "").strip()
                    count   = int(rd.findtext("TotalRooms")   or
                                  rd.findtext("NumberOfUnits") or 0)
                    max_occ = int(rd.findtext("MaxOccupancy") or 0)
                    for rp in rd.findall(".//RoomRatePlanData"):
                        rooms.append({
                            "room_name":      rname,
                            "room_id":        rid,
                            "count":          count,
                            "max_occupancy":  max_occ,
                            "rate_plan_id":   (rp.findtext("RatePlanId")   or "").strip(),
                            "rate_plan_name": (rp.findtext("RatePlanName") or "").strip(),
                            "meal_plan":      (rp.findtext("MealPlan")     or "").strip(),
                        })
            except Exception as xe:
                messagebox.showerror(tr_("Unreadable response"),
                    f"Cannot parse the CM response:\n{xe}\n\n"
                    f"Raw response:\n{body[:600]}",
                    parent=self.app.root)
                return

        if not rooms:
            messagebox.showinfo(tr_("No rooms"),
                f"The CM responded but returned no room.\n"
                f"Status: {msg}\n\nRaw response:\n{body[:400]}",
                parent=self.app.root)
            return

        # ── Also fetch the OTA codes via /otaInfo ─────────────────────────
        from business.channel_manager import get_ota_info
        ota_rows  = []   # [(room_id, rate_plan_id, ota_code, ota_name), ...]
        ota_list  = []   # [(ota_code, ota_name), ...]  global OTAs
        ota_debug = ""   # raw response for debug
        try:
            import json as _json2
            _ok2, _msg2, body2 = get_ota_info(cm_cfg)
            ota_debug = f"Status: {_msg2}\n{body2[:2000]}"
            try:
                data2 = _json2.loads(body2)
                for o in data2.get("OTAs", []):
                    ota_list.append((str(o.get("OTACode", "")),
                                     o.get("OTAName", "")))
                for orr in data2.get("OTARooms", []):
                    rid2 = str(orr.get("RoomId", ""))
                    rp2  = str(orr.get("RatePlanId", ""))
                    for o in orr.get("OTAs", []):
                        ota_rows.append((rid2, rp2,
                                         str(o.get("OTACode", "")),
                                         o.get("OTAName", "")))
            except Exception as _pe:
                ota_debug = f"Parse error: {_pe}\n{body2[:600]}"
        except Exception as _e:
            ota_debug = f"/otaInfo call error: {_e}"

        # Results window
        win = tk.Toplevel(self.app.root)
        win.title(tr_("Rooms and Rate Plans — Channel Manager"))
        win.configure(bg=T.BG)
        win.geometry("760x560")
        win.grab_set()

        lbl(win, tr_("Rooms available in your Channel Manager"),
            bold=True, size=11).pack(pady=(12, 2))
        lbl(win,
            tr_("Click on a line then “Copy to mapping” to apply the codes."),
            color="#888888", size=9).pack(pady=(0, 8))

        _cols = ("CM Room", "Room ID", "Count", "Max occ.", "Rate Plan", "Rate Plan ID", "Meals")
        _tree = ttk.Treeview(win, columns=_cols, show="headings", height=14)
        for _c, _w, _anch in zip(
                _cols,
                [170, 70, 40, 60, 170, 80, 60],
                ["w","c","c","c","w","c","c"]):
            _tree.heading(_c, text=tr_(_c))
            _tree.column(_c, width=_w, anchor=_anch)

        for _r in rooms:
            _tree.insert("", "end", values=(
                _r["room_name"],
                _r["room_id"],
                _r["count"]       if _r["count"]       else "—",
                _r["max_occupancy"] if _r["max_occupancy"] else "—",
                _r["rate_plan_name"],
                _r["rate_plan_id"],
                _r["meal_plan"]   if _r["meal_plan"]   else "—",
            ))
        zebra_stripe(_tree)

        _sb = ttk.Scrollbar(win, orient="vertical", command=_tree.yview)
        _tree.configure(yscrollcommand=_sb.set)
        _tree.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=4)
        _sb.pack(side="left", fill="y", pady=4)
        _attach_sort(_tree)

        # Right panel — target room + copy button
        _right = tk.Frame(win, bg=T.BG, padx=12)
        _right.pack(side="left", fill="y", pady=12)

        lbl(_right, tr_("Target room\n(in OTA Guard)"), bold=True).pack(anchor="w")
        _rt_list = [r if isinstance(r, str) else r.get("type", "")
                    for r in self.app.config.get("room_types", [])]
        _target_v = tk.StringVar(value=_rt_list[0] if _rt_list else "")
        _target_cb = ttk.Combobox(_right, textvariable=_target_v, values=_rt_list,
                                   state="normal", width=22)
        _target_cb.pack(anchor="w", pady=4)

        # Option: also add to room types
        _add_to_rooms_v = tk.BooleanVar(value=True)
        tk.Checkbutton(_right,
                       text=tr_("Also add in\nRoom types"),
                       variable=_add_to_rooms_v,
                       bg=T.BG, fg=T.FG, activebackground=T.BG,
                       selectcolor=T.ENTRY_BG,
                       font=("Segoe UI", 8),
                       justify="left").pack(anchor="w", pady=(2, 6))

        _status = tk.Label(_right, text="", bg=T.BG, fg=T.GREEN,
                           font=("Segoe UI", 9), wraplength=180)
        _status.pack(anchor="w", pady=4)

        def _apply():
            sel = _tree.selection()
            if not sel:
                _status.config(text=tr_("⚠ Select a line."), fg=T.ORANGE)
                return
            vals        = _tree.item(sel[0], "values")
            _cm_name    = vals[0]   # CM-side room name
            _rid        = vals[1]
            _nb         = vals[2]   # room count
            _occ        = vals[3]   # max occupancy
            _rpid       = vals[5]   # rate plan ID
            target      = _target_v.get().strip()
            # If the field is empty, use the CM name directly
            if not target:
                target = _cm_name

            # ── Add to room_types if checked ──────────────────────────────
            if _add_to_rooms_v.get():
                existing = [r if isinstance(r, str) else r.get("type", "")
                            for r in self.app.config.get("room_types", [])]
                nb_int = int(_nb) if str(_nb).isdigit() else 1
                if target not in existing:
                    self.app.config.setdefault("room_types", []).append(target)
                    self.app.config.setdefault("room_inventory", {})[target] = {
                        "count": nb_int, "floor": 0, "ceiling": 0}
                    cfg.save(self.app.config)
                    _rt_list.append(target)
                    _target_cb["values"] = _rt_list
                elif nb_int > 1:
                    self.app.config.setdefault(
                        "room_inventory", {}).setdefault(target, {})["count"] = nb_int
                    cfg.save(self.app.config)

            # ── OTA codes for this room+rate plan ─────────────────────────
            otas_for = [(oc, on) for (r2, rp2, oc, on) in ota_rows
                        if r2 == _rid and rp2 == _rpid]
            if otas_for:
                rp_list = [{"ota_name": on, "ota_code": oc,
                            "rate_plan_code": _rpid, "ota_discount_pct": 0.0}
                           for oc, on in otas_for]
            else:
                rp_list = [{"ota_name": "", "ota_code": "",
                            "rate_plan_code": _rpid, "ota_discount_pct": 0.0}]

            # ── Fill the mapping ──────────────────────────────────────────
            mapping = self.app.config.setdefault(
                "channel_manager", {}).setdefault("room_mapping", {})
            mapping[target] = {"room_code": _rid, "rate_plans": rp_list}
            cfg.save(self.app.config)
            self.app.root.after(0, self._refresh_mapping_cards)
            n_otas = len(otas_for)
            _status.config(
                text=tr_("✅ {t}\n→ Room: {r} | Map: {p}").format(t=target, r=_rid, p=_rpid)
                     + (tr_("\n→ {n} OTA(s) configured").format(n=n_otas) if n_otas else ""),
                fg=T.GREEN)

        # Import-all-at-once button
        def _apply_all():
            count = 0
            for _r in rooms:
                name = _r["room_name"].strip()
                if not name or name.lower() == "move room":
                    continue
                # Add to room_types
                existing = [r if isinstance(r, str) else r.get("type", "")
                            for r in self.app.config.get("room_types", [])]
                if name not in existing:
                    self.app.config.setdefault("room_types", []).append(name)
                    self.app.config.setdefault("room_inventory", {})[name] = {
                        "count":   _r["count"] or 1,
                        "floor":   0,
                        "ceiling": 0,
                    }
                elif _r["count"]:
                    # Update the count if already present
                    self.app.config.setdefault(
                        "room_inventory", {}).setdefault(name, {})["count"] = _r["count"]
                # Update the mapping (always — overwrites existing data)
                mapping = self.app.config.setdefault(
                    "channel_manager", {}).setdefault("room_mapping", {})
                rid  = _r["room_id"]
                rpid = _r["rate_plan_id"]
                # Look up the OTAs connected to this room+rate plan
                otas_for = [(oc, on) for (r2, rp2, oc, on) in ota_rows
                            if r2 == rid and rp2 == rpid]
                if otas_for:
                    rp_list = [{"ota_name": on, "ota_code": oc,
                                "rate_plan_code": rpid, "ota_discount_pct": 0.0}
                               for oc, on in otas_for]
                else:
                    # Preserve existing rate plans if already configured
                    existing_rp = mapping.get(name, {}).get("rate_plans", [])
                    rp_list = existing_rp if existing_rp else [
                        {"ota_name": "", "ota_code": "",
                         "rate_plan_code": rpid, "ota_discount_pct": 0.0}]
                mapping[name] = {"room_code": rid, "rate_plans": rp_list}
                count += 1
            cfg.save(self.app.config)
            self.app.root.after(0, self._refresh_mapping_cards)
            _status.config(
                text=tr_("✅ {n} imported room(s)\nwith OTA codes.").format(n=count),
                fg=T.GREEN)

        btn(_right, tr_("⬅ Copy to mapping"), _apply,
            color=T.GREEN, width=22).pack(anchor="w", pady=(0, 4))
        btn(_right, tr_("⬇ Import all in OTA Guard"), _apply_all,
            color=T.ACCENT, width=26).pack(anchor="w", pady=(0, 6))
        btn(_right, tr_("✖ Close"), win.destroy,
            color=T.SEL_BG, width=26).pack(anchor="w", pady=2)
        lbl(_right,
            tr_("\"Import all\" adds all\nthe CM rooms in one go."),
            color="#888888", size=8).pack(anchor="w", pady=(10, 0))

        # ── OTA codes section (bottom of window) ─────────────────────────
        sep = tk.Frame(win, bg=T.ACCENT, height=1)
        sep.pack(fill="x", padx=12, pady=(8, 4))
        lbl(win, tr_("📡 Connected OTAs — Codes to enter in “OTA CM Code”"),
            bold=True, size=9).pack(anchor="w", padx=12, pady=(0, 4))
        _ota_frame = tk.Frame(win, bg=T.BG)
        _ota_frame.pack(fill="x", padx=12, pady=(0, 8))
        if ota_rows:
            _oc = ("Room ID", "Rate Plan", "CM OTA Code", "OTA Name")
            _ot = ttk.Treeview(_ota_frame, columns=_oc, show="headings", height=4)
            for _c2, _w2, _a2 in zip(_oc, [80, 80, 100, 180], ["c","c","c","w"]):
                _ot.heading(_c2, text=tr_(_c2))
                _ot.column(_c2, width=_w2, anchor=_a2)
            for _orow in ota_rows:
                _ot.insert("", "end", values=_orow)
            _ot_sb = ttk.Scrollbar(_ota_frame, orient="vertical",
                                    command=_ot.yview)
            _ot.configure(yscrollcommand=_ot_sb.set)
            _ot.pack(side="left", fill="x", expand=True)
            _ot_sb.pack(side="left", fill="y")
        elif ota_list:
            _oc = ("CM OTA Code", "OTA Name")
            _ot = ttk.Treeview(_ota_frame, columns=_oc, show="headings", height=4)
            for _c2, _w2 in zip(_oc, [120, 240]):
                _ot.heading(_c2, text=tr_(_c2))
                _ot.column(_c2, width=_w2, anchor="w")
            for _orow in ota_list:
                _ot.insert("", "end", values=_orow)
            _ot.pack(fill="x", expand=True)
        else:
            # No OTA code — show raw response for debug
            lbl(_ota_frame,
                "⚠ No OTA code returned by /otaInfo — raw response:",
                color=T.ORANGE, size=9).pack(anchor="w")
            _dbg = tk.Text(_ota_frame, height=5, bg=T.ENTRY_BG, fg="#aaaaaa",
                           font=("Courier New", 8), relief="flat", wrap="word")
            _dbg.insert("1.0", ota_debug or "(empty response)")
            _dbg.config(state="disabled")
            _dbg.pack(fill="x", pady=4)
