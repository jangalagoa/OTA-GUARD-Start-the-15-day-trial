"""
Tab: Journal — OTA Guard
Displays in real time everything happening in the background:
scans, CM push, OTA Watch, calibration, errors.
"""
import tkinter as tk
from tkinter import messagebox, filedialog
from pathlib import Path

from core.theme import T
from core.widgets import btn, lbl, tooltip
from core.utils import tr_
from core.base_tab import BaseTab

BASE_DIR = Path(__file__).parent.parent


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app

        from business.app_logger import register_callback, get_recent, \
            clear_log, app_log, _LOG_FILE
        self._LOG_FILE = _LOG_FILE

        # ── Toolbar ───────────────────────────────────────────────────────
        toolbar = tk.Frame(frame, bg=T.ENTRY_BG, pady=4)
        toolbar.pack(fill="x")

        tk.Label(toolbar, text=tr_("📋 Journal"),
                 bg=T.ENTRY_BG, fg=T.ACCENT,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=12)
        btn(toolbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(0, 8))
        btn(toolbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))

        # Filters — enhanced for OTA Guard
        self._filter_var = tk.StringVar(value="All")
        filters = [
            ("All",         "All"),
            ("Errors",      "error"),
            ("Warnings",    "warn"),
            ("Prices",      "price"),
            ("Scan",        "scan"),
            ("CM Push",     "ok"),
            ("Browser",     "browser"),
        ]
        for label, val in filters:
            tk.Radiobutton(
                toolbar, text=tr_(label), variable=self._filter_var, value=val,
                bg=T.ENTRY_BG, fg=T.FG, selectcolor=T.SEL_BG,
                activebackground=T.ENTRY_BG, activeforeground=T.ACCENT,
                font=("Segoe UI", 8), relief="flat",
                command=self._apply_filter
            ).pack(side="left", padx=3)

        tk.Frame(toolbar, bg="#444466", width=1).pack(side="left", fill="y", padx=8)

        # Auto-scroll
        self._autoscroll_var = tk.BooleanVar(value=True)
        tk.Checkbutton(toolbar, text=tr_("Auto-scroll"),
                       variable=self._autoscroll_var,
                       bg=T.ENTRY_BG, fg=T.FG, selectcolor=T.SEL_BG,
                       activebackground=T.ENTRY_BG,
                       font=("Segoe UI", 8), relief="flat").pack(side="left", padx=4)

        # Buttons
        def _export():
            dest = filedialog.asksaveasfilename(
                defaultextension=".log",
                filetypes=[("Log", "*.log"), ("Text", "*.txt")],
                initialfile="ota_guard.log",
                parent=self.app.root)
            if dest:
                try:
                    import shutil
                    shutil.copy2(str(self._LOG_FILE), dest)
                except Exception as e:
                    messagebox.showerror(tr_("Export"), str(e), parent=self.app.root)

        def _clear():
            clear_log()
            self._clear_widget()
            app_log("Log cleared", level="info", engine="JOURNAL")

        btn(toolbar, tr_("💾 Export"), _export,
            color=T.SEL_BG, width=10).pack(side="right", padx=4)
        btn(toolbar, tr_("🗑 Clear"), _clear,
            color=T.SEL_BG, width=9).pack(side="right", padx=4)

        # ── Main text area ─────────────────────────────────────────────────
        txt_frame = tk.Frame(frame, bg=T.BG)
        txt_frame.pack(fill="both", expand=True, padx=6, pady=6)

        vsb = tk.Scrollbar(txt_frame, orient="vertical")
        hsb = tk.Scrollbar(txt_frame, orient="horizontal")
        self._txt = tk.Text(
            txt_frame,
            bg="#0a0a14", fg="#aaaaaa",
            font=("Courier New", 8),
            relief="flat", wrap="none",
            yscrollcommand=vsb.set,
            xscrollcommand=hsb.set,
            state="disabled",
            selectbackground=T.ACCENT, selectforeground=T.BG)
        vsb.config(command=self._txt.yview)
        hsb.config(command=self._txt.xview)
        hsb.pack(side="bottom", fill="x")
        vsb.pack(side="right",  fill="y")
        self._txt.pack(fill="both", expand=True)

        # Color tags
        self._txt.tag_configure("info",    foreground="#6a7a9a")
        self._txt.tag_configure("ok",      foreground="#a6e3a1")
        self._txt.tag_configure("warn",    foreground="#f9a825")
        self._txt.tag_configure("error",   foreground="#f38ba8")
        self._txt.tag_configure("browser", foreground="#89b4fa")
        self._txt.tag_configure("price",   foreground="#cba6f7")
        self._txt.tag_configure("head",    foreground="#cdd6f4",
                                font=("Courier New", 8, "bold"))
        self._txt.tag_configure("scan",    foreground="#94e2d5")

        # ── Load the existing history ──────────────────────────────────────
        self._lines_all = []
        for line in get_recent(800):
            self._lines_all.append((line, "info"))
        self._apply_filter()

        # ── Real-time callback ─────────────────────────────────────────────
        def _live_cb(line: str, level: str):
            self._lines_all.append((line, level))
            if len(self._lines_all) > 2000:
                self._lines_all = self._lines_all[-2000:]
            filt = getattr(self, "_filter_var", None)
            filt_val = filt.get() if filt else "All"
            if filt_val != "All" and level != filt_val:
                return
            self.app.root.after(0, lambda l=line, lv=level: self._append(l, lv))

        self._live_cb = _live_cb
        register_callback(_live_cb)

        # Welcome message
        app_log("═" * 55, level="head", engine="")
        app_log("OTA Guard started — Journal active", level="head", engine="")
        app_log("═" * 55, level="head", engine="")

    # ── Widget methods ─────────────────────────────────────────────────────

    def _append(self, line: str, level: str = "info"):
        try:
            w = self._txt
            w.config(state="normal")
            w.insert("end", line, level)
            n = int(w.index("end-1c").split(".")[0])
            if n > 3000:
                w.delete("1.0", f"{n - 3000}.0")
            if getattr(self, "_autoscroll_var", None) and \
               self._autoscroll_var.get():
                w.see("end")
            w.config(state="disabled")
        except Exception:
            pass

    def _clear_widget(self):
        try:
            self._txt.config(state="normal")
            self._txt.delete("1.0", "end")
            self._txt.config(state="disabled")
            self._lines_all.clear()
        except Exception:
            pass

    def _apply_filter(self):
        try:
            filt = self._filter_var.get()
            self._txt.config(state="normal")
            self._txt.delete("1.0", "end")
            for line, level in self._lines_all:
                if filt == "All" or level == filt:
                    self._txt.insert("end", line, level)
            self._txt.see("end")
            self._txt.config(state="disabled")
        except Exception:
            pass
