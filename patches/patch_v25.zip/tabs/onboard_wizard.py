"""D51 — Visual onboarding wizard for a NEW Channel Manager.

Guided, step-by-step integration directly from the app (Extranet Direct
tab -> "🧰 Integrate a new CM"). Each step has its own tutorial
text, action buttons and a live status; the underlying work runs the
vae2.onboard commands in a background process (never blocks the UI),
and the wizard checks the on-disk state before enabling the next step.

Safety: identical to the CLI — learn/validate-read are pure file reads;
the TEST step drives the browser in TEST mode only (submit NOT clicked),
behind an explicit parameter-confirmation dialog; enable-write is
refused by onboard itself until the test step succeeded.
"""
import json
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from core.theme import T
from core.utils import tr_

import yaml

VAE2_DIR = Path(__file__).resolve().parent.parent / "vae2"
MAPS_DIR = VAE2_DIR / "maps"
ONBOARD_MOD = "vae2.onboard"


class OnboardWizard:
    """Step-by-step new-CM integration window."""

    def __init__(self, app):
        self.app = app
        self.win = tk.Toplevel(app.root)
        self.win.title(tr_("🧰 Assistant — integrate a new Channel Manager"))
        self.win.geometry("880x680")
        self.win.configure(bg=T.BG)

        self.map_var = tk.StringVar(value="")
        self.log_q: "queue.Queue[str]" = queue.Queue()
        self._busy = False

        self._build_header()
        self._build_map_row()
        self._build_steps()
        self._build_log()
        self._poll_log()
        self._refresh_state()

    # ── UI scaffolding ──────────────────────────────────────────────────

    def _build_header(self):
        head = tk.Frame(self.win, bg=T.SEL_BG, pady=8, padx=10)
        head.pack(fill="x")
        tk.Label(head, text=tr_("🧰 Integration of a new Channel Manager"),
                 bg=T.SEL_BG, fg=T.ACCENT,
                 font=("Segoe UI", 12, "bold")).pack(side="left")
        tk.Label(head, text=tr_("Step-by-step guide — each step is checked before the next one is activated."),
                 bg=T.SEL_BG, fg="#888888",
                 font=("Segoe UI", 8)).pack(side="right")

    def _build_map_row(self):
        row = tk.Frame(self.win, bg=T.BG)
        row.pack(fill="x", padx=10, pady=(10, 0))
        tk.Label(row, text=tr_("CM map:"), bg=T.BG, fg=T.FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left")
        self.map_cb = ttk.Combobox(row, textvariable=self.map_var,
                                   state="readonly", width=38)
        self.map_cb.pack(side="left", padx=6)
        self._maps = self._list_maps()
        self.map_cb["values"] = [m.name for m in self._maps]
        if self._maps:
            self.map_cb.current(0)
        tk.Button(row, text=tr_("🔄 Refresh"), command=self._refresh_state,
                  bg=T.SEL_BG, fg=T.FG, relief="flat",
                  padx=8).pack(side="left", padx=4)

    def _build_steps(self):
        outer, inner = self._scrolled(self.win)
        outer.pack(fill="both", expand=True, padx=10, pady=6)
        self._step_frames = {}

        steps = [
            ("1", tr_("Create the new CM card"),
             tr_("Enter the CM extranet domain (e.g. cm.hotelduclient.com) and a displayed name. The wizard generates the adapter card — writing is automatically disabled."),
             self._step1_widgets),
            ("2", tr_("Declare the domain for passive listening"),
             tr_("The domain is added to the VAE1 playlist (automatic backup). After that, RESTART OTA Guard for listening to attach to it."),
             self._step2_widgets),
            ("3", tr_("Capture the customer's extranet"),
             tr_("In Brave: open the CM extranet (connected session), display the price grid AND the update form. Then click “Check Captures” — the wizard counts what was observed, without any queries."),
             self._step3_widgets),
            ("4", tr_("Learn the sources of CM"),
             tr_("The assistant analyzes the captures and suggests candidates. Designate the reading grid and the writing form. ⚠ The semantic state_model (where is the price in the cells) remains to be completed by the seller: the card is ready to be sent to him."),
             self._step4_widgets),
            ("5", tr_("Validate reading (automatic)"),
             tr_("The scanner reads the captures with the card: PASS = rooms, OTAs and prices extracted, zero structural locks."),
             self._step5_widgets),
            ("6", tr_("Blank TEST (completed form, NOTHING sent)"),
             tr_("The performer completes the real CM form before your eyes but DOES NOT VALIDATE. Enter test parameters, verify them, then launch."),
             self._step6_widgets),
            ("7", tr_("Enable write and set as active CM"),
             tr_("Refused until TEST passes. Once active, corrections will go through this CM (the old one remains available by re-selecting its card)."),
             self._step7_widgets),
        ]
        for num, title, tuto, widgets in steps:
            card = tk.LabelFrame(inner, text=f"Step {num} — {title}",
                                 bg=T.BG, fg=T.ACCENT,
                                 font=("Segoe UI", 9, "bold"))
            card.pack(fill="x", pady=4, padx=2)
            tk.Label(card, text=tuto, bg=T.BG, fg="#888888",
                     font=("Segoe UI", 8), wraplength=780,
                     justify="left").pack(
                anchor="w", padx=10, pady=(4, 2))
            body = tk.Frame(card, bg=T.BG)
            body.pack(fill="x", padx=10, pady=(0, 6))
            widgets(card, body)
            self._step_frames[num] = card

    def _step1_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Label(row, text=tr_("Domain :"), bg=T.BG, fg=T.FG,
                 font=("Segoe UI", 9)).pack(side="left")
        self.e_domain = tk.Entry(row, width=28, bg=T.ENTRY_BG, fg=T.FG,
                                 relief="flat")
        self.e_domain.pack(side="left", padx=4)
        tk.Label(row, text=tr_("Display name:"), bg=T.BG, fg=T.FG,
                 font=("Segoe UI", 9)).pack(side="left", padx=(8, 0))
        self.e_name = tk.Entry(row, width=24, bg=T.ENTRY_BG, fg=T.FG,
                               relief="flat")
        self.e_name.pack(side="left", padx=4)
        tk.Button(row, text=tr_("Create the map"), command=self._do_init,
                  bg=T.ACCENT, fg=T.BG, relief="flat",
                  font=("Segoe UI", 9, "bold"),
                  padx=10).pack(side="left", padx=6)
        self.s1 = tk.Label(body, text="", bg=T.BG, fg=T.GREEN, )
        self.s1.pack(anchor="w")

    def _step2_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Button(row, text=tr_("Declare the domain"), command=self._do_register,
                  bg=T.SEL_BG, fg=T.FG, relief="flat", padx=10).pack(side="left")
        tk.Button(row, text=tr_("Import domain in wizard"),
                  command=self._refresh_state, bg=T.SEL_BG, fg=T.FG,
                  relief="flat", padx=8).pack(side="left", padx=6)
        self.s2 = tk.Label(body, text="", bg=T.BG, fg=T.GREEN, )
        self.s2.pack(anchor="w")

    def _step3_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Button(row, text=tr_("Check captures"), command=self._do_captures,
                  bg=T.SEL_BG, fg=T.FG, relief="flat", padx=10).pack(side="left")
        self.s3 = tk.Label(body, text="", bg=T.BG, fg=T.FG, )
        self.s3.pack(anchor="w")

    def _step4_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Button(row, text=tr_("Analyze captures (learn)"),
                  command=self._do_learn, bg=T.SEL_BG, fg=T.FG,
                  relief="flat", padx=10).pack(side="left")
        tk.Button(row, text=tr_("Import a completed proposal (seller)"),
                  command=self._do_apply_file, bg=T.SEL_BG, fg=T.FG,
                  relief="flat", padx=8).pack(side="left", padx=6)
        self.sel_row = tk.Frame(body, bg=T.BG); self.sel_row.pack(fill="x")
        self.s4 = tk.Label(body, text="", bg=T.BG, fg=T.GREEN, )
        self.s4.pack(anchor="w")

    def _step5_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Button(row, text=tr_("Validate reading"), command=self._do_validate_read,
                  bg=T.SEL_BG, fg=T.FG, relief="flat", padx=10).pack(side="left")
        self.s5 = tk.Label(body, text="", bg=T.BG, fg=T.FG, )
        self.s5.pack(anchor="w")

    def _step6_widgets(self, card, body):
        grid = tk.Frame(body, bg=T.BG); grid.pack(fill="x")
        self.t_room = self._field(grid, 0, "Chambre (nom exact sur le CM) :")
        self.t_ota = self._field(grid, 1, "OTA (nom exact) :")
        self.t_rate = self._field(grid, 2, "Prix de test :")
        self.t_from = self._field(grid, 3, "Du (AAAA-MM-JJ) :")
        self.t_to = self._field(grid, 4, "Au (AAAA-MM-JJ) :")
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x", pady=(4, 0))
        tk.Button(row, text=tr_("Run the blank TEST (no sending)"),
                  command=self._do_validate_test, bg=T.ORANGE if hasattr(T, "ORANGE") else "#E3B341",
                  fg=T.BG, relief="flat", font=("Segoe UI", 9, "bold"),
                  padx=10).pack(side="left")
        self.s6 = tk.Label(body, text="", bg=T.BG, fg=T.FG, )
        self.s6.pack(anchor="w")

    def _field(self, grid, col, label_text):
        cell = tk.Frame(grid, bg=T.BG)
        cell.grid(row=0, column=col, padx=4, sticky="w")
        tk.Label(cell, text=label_text, bg=T.BG, fg="#888888",
                 font=("Segoe UI", 8)).pack(anchor="w")
        e = tk.Entry(cell, width=18, bg=T.ENTRY_BG, fg=T.FG, relief="flat")
        e.pack()
        return e

    def _step7_widgets(self, card, body):
        row = tk.Frame(body, bg=T.BG); row.pack(fill="x")
        tk.Button(row, text=tr_("Enable writing"), command=self._do_enable_write,
                  bg=T.GREEN, fg=T.BG, relief="flat",
                  font=("Segoe UI", 9, "bold"), padx=10).pack(side="left")
        tk.Button(row, text=tr_("Set as active CM"),
                  command=self._do_set_active, bg=T.SEL_BG, fg=T.FG,
                  relief="flat", padx=10).pack(side="left", padx=6)
        self.s7 = tk.Label(body, text="", bg=T.BG, fg=T.GREEN, )
        self.s7.pack(anchor="w")

    def _build_log(self):
        self.log = tk.Text(self.win, height=10, bg="#11111b", fg="#cdd6f4",
                           font=("Consolas", 8), relief="flat")
        self.log.pack(fill="x", side="bottom", padx=10, pady=(0, 10))

    def _scrolled(self, parent):
        outer = tk.Frame(parent, bg=T.BG)
        canvas = tk.Canvas(outer, bg=T.BG, highlightthickness=0)
        sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=T.BG)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        return outer, inner

    # ── helpers ─────────────────────────────────────────────────────────

    def _log_write(self, line: str):
        self.log_q.put(line + "\n")

    def _poll_log(self):
        try:
            while True:
                line = self.log_q.get_nowait()
                self.log.insert("end", line)
                self.log.see("end")
        except queue.Empty:
            pass
        self.win.after(300, self._poll_log)

    def _run_onboard(self, args, on_done=None):
        """Run `python -m vae2.onboard ...` in a background process,
        streaming output into the log pane."""
        if self._busy:
            messagebox.showinfo(tr_("Assistant"),
                                tr_("One step is already underway."),
                                parent=self.win)
            return
        self._busy = True

        def work():
            proc = subprocess.Popen(
                [sys.executable, "-m", ONBOARD_MOD] + args,
                cwd=str(VAE2_DIR.parent),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace")
            for line in proc.stdout:
                self._log_write(line.rstrip())
            proc.wait()
            self._busy = False
            if on_done:
                on_done(proc.returncode)

        threading.Thread(target=work, daemon=True).start()

    def _current_map(self) -> Path:
        name = self.map_var.get().strip()
        if not name:
            raise SystemExit
        return MAPS_DIR / name

    def _list_maps(self):
        if not MAPS_DIR.exists():
            return []
        return sorted(MAPS_DIR.glob("*.yaml"))

    def _read_yaml(self, path: Path):
        try:
            return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except Exception:
            return {}

    def _refresh_state(self):
        self._maps = self._list_maps()
        self.map_cb["values"] = [m.name for m in self._maps]
        if self._maps:
            if self.map_var.get() not in [m.name for m in self._maps]:
                self.map_cb.current(0)
        if not hasattr(self, "s1"):
            return
        mp = self._current_map_safe()
        if not mp:
            self.s1.config(text=tr_("No card selected."))
            return
        cfgd = self._read_yaml(mp)
        integ = cfgd.get("integration") or {}
        dom = str(cfgd.get("extranet") or "?")
        n_sources = len(cfgd.get("sources") or {})
        self.s1.config(text=tr_("Active card in the wizard: {f} — domain: {d}").format(f=mp.name, d=dom))
        self.s2.config(text=tr_("Registered domain: {v}").format(
            v=integ.get("domain_registered", "—")))
        self.s4.config(text=tr_("Sources learned: {n}").format(n=n_sources))
        self.s5.config(text=tr_("Last reading validation: {v}").format(
            v=integ.get("validate_read_ok", "—")))
        caps = (cfgd.get("capabilities") or {}).get("browser_execution")
        self.s7.config(text=tr_("Write enabled: {v}").format(
            v=tr_("Yes") if caps else tr_("no — will take the TEST")))

    def _current_map_safe(self):
        name = self.map_var.get().strip()
        p = MAPS_DIR / name if name else None
        return p if p and p.exists() else None

    # ── step actions ────────────────────────────────────────────────────

    def _do_init(self):
        domain = self.e_domain.get().strip()
        name = self.e_name.get().strip() or None
        if not domain or "." not in domain:
            messagebox.showwarning(tr_("Assistant"),
                                   tr_("Enter a valid domain (eg: cm.hotelduclient.com)."),
                                   parent=self.win)
            return
        args = ["init", "--domain", domain]
        if name:
            args += ["--name", name]
        self._run_onboard(args, on_done=lambda rc: self._after_init(domain, rc))

    def _after_init(self, domain, rc):
        ident = domain.strip().lower().replace(".", "_").replace("-", "_")
        created = MAPS_DIR / f"{ident}.yaml"
        if created.exists():
            self.s1.config(text=tr_("✅ Card created: {f}").format(f=created.name))
            self._refresh_state()

    def _do_register(self):
        mp = self._current_map_safe()
        if not mp:
            return
        self._run_onboard(["register", "--map", str(mp)],
                          on_done=lambda rc: self._after_register(mp, rc))

    def _after_register(self, mp, rc):
        cfgd = self._read_yaml(mp)
        dom = str(cfgd.get("extranet") or "")
        domains_f = Path(VAE2_DIR.parent / "vae" / "config" / "ota_domains.yaml")
        if domains_f.exists() and dom in domains_f.read_text(encoding="utf-8"):
            self.s2.config(text=tr_("✅ Saved domain — RESTART OTA Guard for listening to attach."))

    def _do_captures(self):
        mp = self._current_map_safe()
        if not mp:
            return
        self._run_onboard(["captures", "--map", str(mp)],
                          on_done=lambda rc: self._after_captures(mp, rc))

    def _after_captures(self, mp, rc):
        cfgd = self._read_yaml(mp)
        dom = str(cfgd.get("extranet") or "")
        if rc == 0:
            self.s3.config(text=tr_("✅ Captures exist — get to learning."))
        else:
            self.s3.config(text=tr_("No capture: check reboot, CM session and open grid in Brave."))

    def _do_learn(self):
        mp = self._current_map_safe()
        if not mp:
            return
        self._run_onboard(["learn", "--map", str(mp)],
                          on_done=lambda rc: self._after_learn(mp, rc))

    def _after_learn(self, mp, rc):
        cfgd = self._read_yaml(mp)
        dom = str(cfgd.get("extranet") or "")
        dom_token = dom.replace(".", "_")
        # reads the proposal written by learn and offers the designation
        prop_dir = Path(VAE2_DIR.parent / "sandbox" / "onboard")
        props = sorted(prop_dir.glob(f"{mp.stem}_proposal.yaml"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        for w in self.sel_row.winfo_children():
            w.destroy()
        if not props:
            self.s4.config(text=tr_("No proposals generated — check captures (step 3)."))
            return
        prop = yaml.safe_load(props[0].read_text(encoding="utf-8")) or {}
        sources = prop.get("sources") or {}
        if not sources:
            self.s4.config(text=tr_("Empty proposition."))
            return
        self._sel = {}
        tk.Label(self.sel_row, text=tr_("Nominate the candidates:"),
                 bg=T.BG, fg=T.FG, font=("Segoe UI", 8, "bold")).pack(
            anchor="w", pady=(2, 0))
        self._role = {"read": tk.StringVar(value=""),
                      "write": tk.StringVar(value="")}
        for key, src in sources.items():
            hint = str(src.get("endpoint_hint", ""))
            suggest = str(src.get("_suggest", ""))
            rowf = tk.Frame(self.sel_row, bg=T.BG)
            rowf.pack(fill="x", pady=1)
            tk.Label(rowf, text=f"{key} — {hint[:52]}", bg=T.BG, fg=T.FG,
                     font=("Consolas", 8)).pack(side="left")
            tk.Label(rowf, text=("  " + suggest if suggest else ""), bg=T.BG,
                     fg="#CBA135", font=("Segoe UI", 7)).pack(side="left")
            for role, lbltxt in (("read", tr_("reading grid")),
                                 ("write", tr_("form"))):
                rb = tk.Radiobutton(rowf, text=lbltxt, variable=self._role[role],
                                    value=key, bg=T.BG, fg=T.FG,
                                    selectcolor=T.ENTRY_BG,
                                    font=("Segoe UI", 8))
                rb.pack(side="right", padx=4)
            if "date-like" in suggest:
                self._role["read"].set(key)
        tk.Button(self.sel_row, text=tr_("Apply selection"),
                  command=self._do_apply_selection, bg=T.ACCENT, fg=T.BG,
                  relief="flat", padx=8).pack(anchor="w", pady=(4, 0))
        self.s4.config(text=tr_("Loaded proposition — designate then apply."))

    def _do_apply_selection(self):
        mp = self._current_map_safe()
        if not mp:
            return
        read_key, write_key = self._role["read"].get(), self._role["write"].get()
        if not read_key and not write_key:
            messagebox.showwarning(
                tr_("Assistant"),
                tr_("At least designate the reading grid or the form."), parent=self.win)
            return
        prop_dir = Path(VAE2_DIR.parent / "sandbox" / "onboard")
        props = sorted(prop_dir.glob(f"{mp.stem}_proposal.yaml"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        prop = yaml.safe_load(props[0].read_text(encoding="utf-8")) or {}
        sources = prop.get("sources") or {}
        cfgd = self._read_yaml(mp)
        new_sources = {}
        if read_key and read_key in sources:
            src = dict(sources[read_key])
            src.pop("_suggest", None); src.pop("_evidence", None)
            new_sources["otasheet_grid"] = src
        if write_key and write_key in sources:
            src = dict(sources[write_key])
            src.pop("_suggest", None); src.pop("_evidence", None)
            new_sources["bulkupdate_grid"] = src
        cfgd["sources"] = new_sources
        mp.write_text(yaml.safe_dump(cfgd, allow_unicode=True,
                                     sort_keys=False), encoding="utf-8")
        self._log_write(f"[apply] sources retenues : {list(new_sources)}")
        self._refresh_state()
        messagebox.showinfo(
            tr_("Assistant"),
            tr_("Updated map with chosen prints.\n\nSELLER STEP: the semantic state_model (where is the price in the cells, date format, etc.) must be completed before reading extracts the prices. Send this file to the seller:\n{f}\n\nor import a completed proposal with the left button.")
                .format(f=mp), parent=self.win)
        self._refresh_state()

    def _do_apply_file(self):
        mp = self._current_map_safe()
        if not mp:
            return
        f = filedialog.askopenfilename(
            title=tr_("Proposal completed by the seller"),
            filetypes=[("YAML", "*.yaml"), ("Tous", "*.*")])
        if not f:
            return
        self._run_onboard(["learn", "--map", str(mp), "--apply", f],
                          on_done=lambda rc: self._refresh_state())

    def _do_validate_read(self):
        mp = self._current_map_safe()
        if not mp:
            return
        self._run_onboard(["validate-read", "--map", str(mp)],
                          on_done=lambda rc: self._after_validate_read(mp, rc))

    def _after_validate_read(self, mp, rc):
        cfgd = self._read_yaml(mp)
        v = (cfgd.get("integration") or {}).get("validate_read_ok", "—")
        if rc == 0:
            self.s5.config(text=tr_("✅ PASS — proven reading ({v}).").format(v=v), fg=T.GREEN)
        else:
            self.s5.config(text=tr_("✗ FAIL — is the state_model completed? Details in the newspaper."),
                           fg="#FF7A59")

    def _do_validate_test(self):
        mp = self._current_map_safe()
        if not mp:
            return
        room, ota = self.t_room.get().strip(), self.t_ota.get().strip()
        rate = self.t_rate.get().strip()
        dfrom, dto = self.t_from.get().strip(), self.t_to.get().strip()
        if not all((room, ota, rate, dfrom, dto)):
            messagebox.showwarning(
                tr_("Assistant"),
                tr_("Enter room, OTA, price and dates (YYYY-MM-DD)."),
                parent=self.win)
            return
        if not messagebox.askyesno(
                tr_("Blank TEST confirmation"),
                tr_("The performer will complete the REAL CM form with:\n\nRoom: {r}\nOTA: {o}\nPrice: {p}\nFrom: {f} to: {t}\n\nNO validation will be clicked — nothing will be sent.\nConfirm?").format(r=room, o=ota, p=rate, f=dfrom, t=dto),
                parent=self.win):
            return
        self._run_onboard(
            ["validate-test", "--map", str(mp), "--room", room, "--ota", ota,
             "--rate", rate, "--date-from", dfrom, "--date-to", dto],
            on_done=lambda rc: self._after_validate_test(mp, rc))

    def _after_validate_test(self, mp, rc):
        cfgd = self._read_yaml(mp)
        v = (cfgd.get("integration") or {}).get("validate_test_ok", "—")
        if rc == 0:
            self.s6.config(text=tr_("✅ PASS — form flow works ({v}).").format(v=v),
                           fg=T.GREEN)
        else:
            self.s6.config(text=tr_("✗ FAIL — page left as is (D12). Read the diary below."),
                           fg="#FF7A59")

    def _do_enable_write(self):
        mp = self._current_map_safe()
        if not mp:
            return
        self._run_onboard(["enable-write", "--map", str(mp)],
                          on_done=lambda rc: self._after_enable(mp, rc))

    def _after_enable(self, mp, rc):
        if rc == 0:
            self.s7.config(text=tr_("✅ Write Enabled — set this card as active CM."), fg=T.GREEN)
            self._refresh_state()

    def _do_set_active(self):
        mp = self._current_map_safe()
        if not mp:
            return
        from core import config as cfg
        cm = self.app.config.setdefault("channel_manager", {})
        xd = cm.setdefault("extranet_direct", {})
        xd["cm_map"] = mp.name
        cfg.save(self.app.config)
        self.s7.config(text=tr_("✅ Active CM: {f} — takes effect at next startup.").format(f=mp.name), fg=T.GREEN)
        self._log_write(f"[active] cm_map = {mp.name}")


def open_wizard(app):
    """Entry point called from the Extranet Direct tab."""
    OnboardWizard(app)
