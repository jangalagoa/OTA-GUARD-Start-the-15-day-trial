"""
Tab: My Hotel — OTA Guard
Sections: General information + Room types / floor / ceiling
"""
import tkinter as tk
from tkinter import ttk, messagebox

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip
from core.utils import tr_, parse_time_flexible
from core import config as cfg
from core.base_tab import BaseTab

# Suffix marking the "breakfast included" variant of a room type.
# Stored as-is in room_types — no other tab (Calibration, OTA price
# watch) needs changing: they already read room_types as a plain list
# of names.
_BF_SUFFIX = " (Petit-déj inclus)"
_BF_LABELS = ["Sans petit-déj", "Avec petit-déj", "Les deux"]  # canonical keys (FR), never displayed as-is


def _bf_display_map():
    # Literals passed directly to tr_() — required so that
    # tools/i18n_extract.py discovers these 3 strings (tr_(variable) is invisible
    # to the AST extractor, tr_("literal") is not).
    return {
        "Sans petit-déj": tr_("Without breakfast"),
        "Avec petit-déj": tr_("With breakfast"),
        "Les deux": tr_("Both"),
    }


def _bf_display(key):
    """Text displayed in the Combobox — translated per the active language."""
    return _bf_display_map().get(key, key)


def _bf_from_display(display):
    """Finds the canonical FR key from the displayed text (translated or not)."""
    for k, v in _bf_display_map().items():
        if v == display:
            return k
    return display


_HOTEL_TYPE_KEYS = ["Guest House", "Beach Resort", "Boutique Hotel",
                    "Budget Hotel", "Luxury Hotel", "Hostel", "Villa", "Homestay"]


def _hotel_type_display_map():
    # Literals passed directly to tr_() — same reason as _bf_display_map().
    return {
        "Guest House":    tr_("Guest House"),
        "Beach Resort":   tr_("Beach Resort"),
        "Boutique Hotel": tr_("Boutique Hotel"),
        "Budget Hotel":   tr_("Budget Hotel"),
        "Luxury Hotel":   tr_("Luxury Hotel"),
        "Hostel":         tr_("Hostel"),
        "Villa":          tr_("Villa"),
        "Homestay":       tr_("Homestay"),
    }


def _hotel_type_display(key):
    """Text displayed in the Combobox — translated per the active language."""
    return _hotel_type_display_map().get(key, key)


def _hotel_type_from_display(display):
    """Finds the canonical EN key from the displayed text (translated or not)."""
    for k, v in _hotel_type_display_map().items():
        if v == display:
            return k
    return display


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("🏨 My Hotel"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("📖 Wiki"), lambda: self._show_wiki("🏨 Mon Hôtel"),
            color="#89b4fa", width=10).pack(side="right", padx=(4, 0))

        # ── Save bar ───────────────────────────────────────────────────────
        savebar = tk.Frame(frame, bg="#1e2a1e", pady=7, padx=14)
        savebar.pack(fill="x")
        self._save_status = tk.Label(
            savebar, text=tr_("⚠ Remember to save after each modification"),
            bg="#1e2a1e", fg=T.YELLOW, font=("Segoe UI", 9))
        self._save_status.pack(side="left")
        btn(savebar, tr_("💾 Save"), self._save, color=T.GREEN, width=18).pack(side="right")

        # ── Scrollable area ───────────────────────────────────────────────
        sf, inner = scrolled_frame(frame)
        sf.pack(fill="both", expand=True)
        self._inner = inner
        self._build_content()

    def _build_content(self):
        inner = self._inner

        # ══ Section 1 — General information ═══════════════════════════════
        s_info = section(inner, tr_("General information"))
        s_info.pack(fill="x", padx=10, pady=8)

        HOTEL_TYPES = [_hotel_type_display(k) for k in _HOTEL_TYPE_KEYS]
        CURRENCIES  = ["INR", "USD", "EUR", "GBP", "THB", "AED", "SGD"]

        self._info_vars = {}
        self._info_placeholders = {}   # key -> sample text (never saved)
        for key, label_txt, placeholder, width in [
            ("hotel_name",    "Hotel name",       "e.g. Jangala Resort", 36),
            ("hotel_city",    "City",             "e.g. Arpora",         20),
            ("hotel_country", "Country",          "e.g. India",          14),
        ]:
            row = tk.Frame(s_info, bg=T.BG)
            row.pack(fill="x", pady=3)
            lbl(row, label_txt, bold=True, size=9).pack(side="left")
            lbl(row, " :", bold=True, size=9).pack(side="left", padx=(0, 8))
            val = self.app.config.get(key, "")
            v   = tk.StringVar(value=str(val) if val else "")
            e   = entry(row, textvariable=v, width=width)
            e.pack(side="left")
            if placeholder and not v.get():
                ph_tr = tr_(placeholder)
                e.insert(0, ph_tr)
                e.config(fg="#666666")
                def _clear(ev, w=e, ph=ph_tr):
                    if w.get() == ph:
                        w.delete(0, "end"); w.config(fg=T.FG)
                def _restore(ev, w=e, ph=ph_tr):
                    if not w.get():
                        w.insert(0, ph); w.config(fg="#666666")
                e.bind("<FocusIn>",  _clear)
                e.bind("<FocusOut>", _restore)
                # Remembers the sample text so that _save() does NOT record
                # it as a real value if the user never touched the field
                # (the placeholder is inserted into the StringVar, so
                # v.get() returns it as-is). Without this, a first install
                # recorded "e.g. Jangala Resort" as the hotel name — the
                # data identifying the hotel in ALL scans.
                self._info_placeholders[key] = ph_tr
            self._info_vars[key] = v

        # Establishment type
        row_type = tk.Frame(s_info, bg=T.BG); row_type.pack(fill="x", pady=3)
        lbl(row_type, tr_("Type:"), bold=True, size=9).pack(side="left", padx=(0, 8))
        self._hotel_type_var = tk.StringVar(
            value=_hotel_type_display(self.app.config.get("hotel_type", _HOTEL_TYPE_KEYS[0])))
        ttk.Combobox(row_type, textvariable=self._hotel_type_var,
                     values=HOTEL_TYPES, width=22, state="readonly").pack(side="left")

        # Check-in / Check-out / Currency — same row
        # Input 24 h OR AM/PM ("2pm" -> "14:00" on field exit);
        # storage always "HH:MM" 24 h.
        row_ops = tk.Frame(s_info, bg=T.BG); row_ops.pack(fill="x", pady=3)
        lbl(row_ops, tr_("Check-in:"), bold=True, size=9).pack(side="left", padx=(0, 4))
        self._checkin_var = tk.StringVar(
            value=self.app.config.get("hotel_checkin", "14:00"))
        _cin = entry(row_ops, textvariable=self._checkin_var, width=7)
        _cin.pack(side="left", padx=(0, 16))
        _cin.bind("<FocusOut>", lambda _e: self._norm_time(self._checkin_var))
        tooltip(_cin, "24 h or AM/PM — e.g. 14:00 or 2:00 PM")

        lbl(row_ops, tr_("Check-out:"), bold=True, size=9).pack(side="left", padx=(0, 4))
        self._checkout_var = tk.StringVar(
            value=self.app.config.get("hotel_checkout", "11:00"))
        _cout = entry(row_ops, textvariable=self._checkout_var, width=7)
        _cout.pack(side="left", padx=(0, 16))
        _cout.bind("<FocusOut>", lambda _e: self._norm_time(self._checkout_var))
        tooltip(_cout, "24 h or AM/PM — e.g. 11:00 or 11 AM")

        lbl(row_ops, tr_("Currency:"), bold=True, size=9).pack(side="left", padx=(0, 4))
        _cm_currency = self.app.config.get("channel_manager", {}).get("currency", "INR")
        self._currency_var = tk.StringVar(
            value=self.app.config.get("hotel_currency", _cm_currency))
        ttk.Combobox(row_ops, textvariable=self._currency_var,
                     values=CURRENCIES, width=7, state="readonly").pack(side="left")

        # ══ Section 2 — Room types ═══════════════════════════════════════
        s_rooms = section(inner, tr_("Room Types & Floor/Ceiling Prices"))
        s_rooms.pack(fill="x", padx=10, pady=8)
        lbl(s_rooms,
            "Define your room types, their count and the OTA price limits.",
            color=T.YELLOW, size=9).pack(anchor="w", pady=(0, 6))

        # Table in a SINGLE grid: the header (row 0) shares exactly the
        # same columns as the fields (uniform) → guaranteed alignment.
        self._room_rows = []
        self._room_list_frame = tk.Frame(s_rooms, bg=T.SEL_BG)
        self._room_list_frame.pack(fill="x")
        _g = self._room_list_frame
        for c, weight, minpx in [(0, 5, 0), (1, 2, 56), (2, 2, 80),
                                 (3, 2, 80), (4, 2, 120), (5, 0, 88),
                                 (6, 0, 34)]:
            _g.grid_columnconfigure(c, weight=weight, uniform="rooms",
                                    minsize=minpx)
        for c, txt in enumerate(["Room name", "Room count",
                                 "Floor", "Ceiling", "Breakfast",
                                 "CM test", ""]):
            if txt:
                lbl(_g, txt, bold=True, size=9, bg=T.SEL_BG,
                    color=T.ACCENT, anchor="w").grid(row=0, column=c,
                                                     sticky="ew",
                                                     padx=6, pady=(2, 4))

        room_types = self.app.config.get("room_types", [])
        inventory  = self.app.config.get("room_inventory", {})
        test_only_set = set(self.app.config.get("room_types_test_only", []) or [])

        # Group the "(Breakfast included)" variants under their base room,
        # to rebuild the Without / With / Both choice.
        _states = {}   # base_name -> {"base": bool, "bf": bool}
        _order   = []
        for rt in room_types:
            rt_str = rt if isinstance(rt, str) else rt.get("type", "")
            if not rt_str:
                continue
            if rt_str.endswith(_BF_SUFFIX):
                base = rt_str[:-len(_BF_SUFFIX)]
                st = _states.setdefault(base, {"base": False, "bf": False})
                st["bf"] = True
            else:
                base = rt_str
                st = _states.setdefault(base, {"base": False, "bf": False})
                st["base"] = True
            if base not in _order:
                _order.append(base)

        for base in _order:
            st = _states[base]
            if st["base"] and st["bf"]:
                bf_label = "Les deux"
            elif st["bf"]:
                bf_label = "Avec petit-déj"
            else:
                bf_label = "Sans petit-déj"
            inv = inventory.get(base) or inventory.get(base + _BF_SUFFIX, {})
            self._add_room_row(
                base,
                str(inv.get("count", 1)),
                str(inv.get("floor", 0)),
                str(inv.get("ceiling", "")),
                bf_label,
                base in test_only_set or (base + _BF_SUFFIX) in test_only_set,
            )

        lbl(s_rooms,
            "\"Room count\" = how many rooms of this type your hotel "
            "owns (e.g. 5) — not a number.",
            color="#888888", size=8).pack(anchor="w", pady=(4, 0))

        btn_row = tk.Frame(s_rooms, bg=T.BG)
        btn_row.pack(anchor="w", pady=6)
        btn(btn_row, tr_("+ Add a room"), self._add_room_row_empty,
            color=T.GREEN, width=22).pack(side="left", padx=(0, 8))
        tooltip(
            btn(btn_row, tr_("💾 Apply"), lambda: self._save(silent=True),
                color=T.ACCENT, width=14),
            "Saves rooms and prices without closing the menu."
        ).pack(side="left", padx=(0, 8))
        tooltip(
            btn(btn_row, tr_("🔗 Room names on OTAs"),
                self._open_ota_rooms_dialog,
                color=T.ORANGE, width=26),
            "Tells the software which OTA room matches which room of your "
            "hotel (names read in the last scan)."
        ).pack(side="left")

    def _open_ota_rooms_dialog(self):
        """Open the OTA room-naming dialog (aliases stored per OTA)."""
        try:
            from tabs.dialog_ota_rooms import open_ota_rooms_dialog
            open_ota_rooms_dialog(self.app)
        except Exception:
            import traceback
            import logging
            logging.getLogger(__name__).exception(
                "dialog_ota_rooms failed:\n%s", traceback.format_exc())

    # ── Room row management ───────────────────────────────────────────────

    def _norm_time(self, var):
        # Rewrites the field in 24 h format when the input is recognizable
        # ("2pm" -> "14:00"); an unreadable input is left as-is
        # (the warning message at save time flags it).
        raw = var.get().strip()
        parsed = parse_time_flexible(raw) if raw else None
        if parsed:
            var.set(parsed)

    def _add_room_row(self, name="", count="1", floor_val="0", ceil_val="",
                       breakfast=_BF_LABELS[0], test_only=False):
        g = self._room_list_frame
        row = len(self._room_rows) + 1

        name_v  = tk.StringVar(value=name)
        count_v = tk.StringVar(value=count)
        floor_v = tk.StringVar(value=floor_val)
        ceil_v  = tk.StringVar(value=ceil_val)
        bf_v    = tk.StringVar(value=_bf_display(breakfast))
        test_only_v = tk.BooleanVar(value=test_only)

        entry(g, textvariable=name_v,  width=8).grid(
            row=row, column=0, sticky="ew", padx=2, pady=2)
        entry(g, textvariable=count_v, width=4).grid(
            row=row, column=1, sticky="ew", padx=2, pady=2)
        entry(g, textvariable=floor_v, width=8).grid(
            row=row, column=2, sticky="ew", padx=2, pady=2)
        entry(g, textvariable=ceil_v,  width=8).grid(
            row=row, column=3, sticky="ew", padx=2, pady=2)
        ttk.Combobox(g, textvariable=bf_v,
                     values=[_bf_display(k) for k in _BF_LABELS],
                     width=13, state="readonly").grid(
            row=row, column=4, sticky="ew", padx=2, pady=2)
        tooltip(
            tk.Checkbutton(g, text=tr_("CM test"), variable=test_only_v,
                           bg=T.SEL_BG, fg=T.FG, activebackground=T.SEL_BG,
                           selectcolor=T.ENTRY_BG, font=("Segoe UI", 9)),
            tr_("Test chamber for the Channel Manager — never taken into account in OTA scans (excluded from counting and price readings).")
        ).grid(row=row, column=5, padx=2, pady=2)

        row_data = (name_v, count_v, floor_v, ceil_v, bf_v, (g, row),
                    test_only_v)
        self._room_rows.append(row_data)

        def _remove(rd=row_data):
            for w in rd[5][0].grid_slaves(row=rd[5][1]):
                w.destroy()
            self._room_rows.remove(rd)

        btn(g, "✕", _remove, color=T.RED, width=2).grid(
            row=row, column=6, padx=2, pady=2)

    def _add_room_row_empty(self):
        self._add_room_row()

    # ── Save ──────────────────────────────────────────────────────────────

    def _save(self, silent=False):
        # Captured BEFORE any write — used to detect a currency change
        # below (floor/ceiling conversion + learned reset).
        _old_currency = self.app.config.get("hotel_currency", "")

        # General information — a field still showing its sample text
        # (never edited) is saved as EMPTY, not as the placeholder.
        for key, v in self._info_vars.items():
            _val = v.get().strip()
            if _val == self._info_placeholders.get(key):
                _val = ""
            self.app.config[key] = _val
        self.app.config["hotel_type"]     = _hotel_type_from_display(self._hotel_type_var.get())
        ci_raw = self._checkin_var.get().strip()
        co_raw = self._checkout_var.get().strip()
        ci = parse_time_flexible(ci_raw) if ci_raw else "14:00"
        co = parse_time_flexible(co_raw) if co_raw else "11:00"
        if not ci or not co:
            messagebox.showwarning(
                tr_("Invalid time"),
                tr_("Invalid time: \"{v}\". Accepted examples: 14:00, 14h30, 2:00 PM, 2pm.").format(v=ci_raw or co_raw))
            return
        self.app.config["hotel_checkin"] = ci
        self.app.config["hotel_checkout"] = co

        currency = self._currency_var.get().strip()
        self.app.config["hotel_currency"] = currency
        if "channel_manager" in self.app.config:
            self.app.config["channel_manager"]["currency"] = currency
        try:
            # Apply right away (symbol used e.g. in push_history) — without
            # this the app would have to be restarted to see the change,
            # lacking the "Display Currency" setting (Advanced) that used
            # to do this hot update.
            self._apply_currency(currency, None)
        except Exception:
            pass

        # Room types & inventory
        new_types = []
        new_inventory = {}
        new_test_only = []
        for name_v, count_v, floor_v, ceil_v, bf_v, _, test_only_v in self._room_rows:
            name = name_v.get().strip()
            if not name:
                continue
            try:   cnt = int(count_v.get())
            except (ValueError, TypeError): cnt = 1
            try:   flr = float(floor_v.get())
            except (ValueError, TypeError): flr = 0.0
            try:   clg = float(ceil_v.get())
            except (ValueError, TypeError): clg = 999999.0
            inv_data = {"count": cnt, "floor": flr, "ceiling": clg}
            is_test_only = test_only_v.get()

            bf_choice = _bf_from_display(bf_v.get())
            if bf_choice == "Avec petit-déj":
                variant = name + _BF_SUFFIX
                new_types.append(variant)
                new_inventory[variant] = inv_data
                if is_test_only:
                    new_test_only.append(variant)
            elif bf_choice == "Les deux":
                variant = name + _BF_SUFFIX
                new_types.append(name)
                new_inventory[name] = inv_data
                new_types.append(variant)
                new_inventory[variant] = dict(inv_data)
                if is_test_only:
                    new_test_only.append(name)
                    new_test_only.append(variant)
            else:  # "Sans petit-déj" (no breakfast)
                new_types.append(name)
                new_inventory[name] = inv_data
                if is_test_only:
                    new_test_only.append(name)

        self.app.config["room_types"]     = new_types
        self.app.config["room_inventory"] = new_inventory
        self.app.config["room_types_test_only"] = new_test_only

        # Sync floor/ceiling → strategy (read by the OTA price tab)
        strat = self.app.config.setdefault("strategy", {})
        strat["floors"]   = {n: v["floor"]   for n, v in new_inventory.items()
                             if v.get("floor")}
        strat["ceilings"] = {n: v["ceiling"] for n, v in new_inventory.items()
                             if v.get("ceiling") and v["ceiling"] != 999999.0}

        # Purge removed rooms from all derived structures
        new_set = set(new_types)
        ota_watch = self.app.config.get("ota_watch", {})
        for rt in list(ota_watch.get("target_prices", {}).keys()):
            if rt not in new_set:
                ota_watch["target_prices"].pop(rt, None)
        for ota_results in ota_watch.get("last_results", {}).values():
            for rt in list(ota_results.keys()):
                if rt not in new_set:
                    ota_results.pop(rt, None)
        # room_mapping CM deliberately not purged: it may contain rooms
        # absent from room_types (e.g. CM test rooms only).

        # Purge calibration (prices_found, prices_learned, sessions)
        try:
            from core.calib_store import load_calib_data, save_calib_data
            _cal = load_calib_data()
            for _prof in _cal.get("profiles", {}).values():
                for _key in ("prices_found", "prices_learned"):
                    for _rt in list(_prof.get(_key, {}).keys()):
                        if _rt not in new_set:
                            _prof[_key].pop(_rt, None)
                for _sess in _prof.get("sessions", []):
                    for _rt in list(_sess.get("prices", {}).keys()):
                        if _rt not in new_set:
                            _sess["prices"].pop(_rt, None)
                    _sess["n_rooms"] = len(_sess.get("prices", {}))
            save_calib_data(_cal)
        except Exception:
            pass

        # ── Conversion + reset if the currency changed ────────────────────
        # hotel_currency is the only currency that matters for floors/
        # ceilings/target prices and for prices_learned (see _run_4eng in
        # tab_blocage_ota.py). If it changes, values already recorded in
        # the old currency become wrong as-is.
        _n_reset = 0
        if _old_currency and _old_currency != currency:
            from core.utils import get_rate
            try:
                rate = get_rate(self.app.config, _old_currency, currency)
            except Exception:
                rate = 1.0

            if rate and abs(rate - 1.0) > 1e-9:
                for inv in new_inventory.values():
                    if inv.get("floor"):
                        inv["floor"] = round(inv["floor"] * rate, 2)
                    if inv.get("ceiling") and inv["ceiling"] != 999999.0:
                        inv["ceiling"] = round(inv["ceiling"] * rate, 2)
                strat["floors"]   = {n: v["floor"]   for n, v in new_inventory.items()
                                     if v.get("floor")}
                strat["ceilings"] = {n: v["ceiling"] for n, v in new_inventory.items()
                                     if v.get("ceiling") and v["ceiling"] != 999999.0}
                for rt, val in list(ota_watch.get("target_prices", {}).items()):
                    try:
                        ota_watch["target_prices"][rt] = round(val * rate, 2)
                    except (TypeError, ValueError):
                        pass

                # Reflect on the on-screen fields — otherwise a second
                # Save would re-read the old figures from the widgets and
                # overwrite the conversion just performed.
                for name_v, _, floor_v, ceil_v, _, _, _ in self._room_rows:
                    rn = name_v.get().strip()
                    inv = new_inventory.get(rn) or new_inventory.get(rn + _BF_SUFFIX)
                    if inv:
                        floor_v.set(str(inv["floor"]))
                        if inv.get("ceiling") and inv["ceiling"] != 999999.0:
                            ceil_v.set(str(inv["ceiling"]))

            # The learned history (prices_learned, prices_found) is a
            # statistical average in the old currency — not convertible
            # term by term. We clear it; calibration is redone at the
            # next scan/wizard.
            self.app.config.setdefault("ota_watch", {})["last_results"] = {}
            try:
                from core.calib_store import load_calib_data, save_calib_data
                _cal2 = load_calib_data()
                for _prof in _cal2.get("profiles", {}).values():
                    if _prof.get("prices_learned") or _prof.get("prices_found"):
                        _n_reset += 1
                    _prof["prices_learned"] = {}
                    _prof["prices_found"]   = {}
                save_calib_data(_cal2)
            except Exception:
                pass

        cfg.save(self.app.config)

        if _old_currency and _old_currency != currency:
            messagebox.showinfo(
                tr_("Changed currency"),
                tr_("Currency changed: {old} → {new}\n\n• Floors, ceilings and target prices: automatically converted at today's rate.\n• Calibration history learned: reset ({n} profile(s) concerned) — a new calibration will be necessary for these OTAs.").format(
                        old=_old_currency, new=currency, n=_n_reset),
                parent=self.app.root)

        if not silent:
            self._save_status.config(
                text=tr_("✅ Saved"), fg=T.GREEN)
            self.app.root.after(3000, lambda: self._save_status.config(
                text=tr_("⚠ Remember to save after each modification"),
                fg=T.YELLOW))
        else:
            messagebox.showinfo(tr_("Saved"), tr_("Hotel and rooms saved."),
                                parent=self.app.root)
