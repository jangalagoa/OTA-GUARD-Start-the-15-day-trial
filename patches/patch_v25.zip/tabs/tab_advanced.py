"""
Tab: Settings — OTA Guard
Sections: Theme, Language, Currency, Database, Backup, Updates.
"""
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

from core.theme import T, THEMES
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip
from core.utils import tr_
from core import config as cfg
from core.base_tab import BaseTab

BASE_DIR = Path(__file__).parent.parent
from core.paths import DATA_DIR

_NO_WIN = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
# In compiled exe, sys.executable points to main.exe (not python.exe) —
# "sys.executable -m pip ..." would start a 2nd instance of the software instead of pip.
_IS_FROZEN = getattr(sys, "frozen", False) or "__compiled__" in globals()

# All languages supported by Google Translate
_LANGUAGES = [
    ("fr", "🇫🇷  Français"),
    ("en", "🇬🇧  English"),
    ("hi", "🇮🇳  हिन्दी (Hindi)"),
    ("es", "🇪🇸  Español"),
    ("de", "🇩🇪  Deutsch"),
    ("it", "🇮🇹  Italiano"),
    ("pt", "🇵🇹  Português"),
    ("ru", "🇷🇺  Русский"),
    ("zh", "🇨🇳  中文 (Chinese)"),
    ("ja", "🇯🇵  日本語 (Japanese)"),
    ("ko", "🇰🇷  한국어 (Korean)"),
    ("ar", "🇸🇦  العربية (Arabic)"),
    ("th", "🇹🇭  ไทย (Thai)"),
    ("vi", "🇻🇳  Tiếng Việt (Vietnamese)"),
    ("id", "🇮🇩  Bahasa Indonesia"),
]


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app

        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("🔧 Settings"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("📖 Wiki"), lambda: self._show_wiki("🔧 Paramètres"),
            color="#89b4fa", width=10).pack(side="right", padx=(4, 0))

        sf, inner = scrolled_frame(frame)
        sf.pack(fill="both", expand=True)

        self._build_theme(inner)
        self._build_language(inner)
        # "💱 Display Currency" — removed, merged into hotel_currency (My Hotel)
        self._build_license(inner)
        self._build_backup(inner)
        self._build_updates(inner)

        # Background startups
        self.app.root.after(5000, self._auto_update_security)

    # ── Theme ──────────────────────────────────────────────────────────────

    def _build_theme(self, parent):
        s = section(parent, tr_("🎨Interface Theme"))
        s.pack(fill="x", padx=10, pady=(10, 6))

        current = self.app.config.get("theme", "Catppuccin Mocha")
        _SUFFIX  = "  ★ active"

        theme_values = [f"{n}{_SUFFIX}" if n == current else n for n in THEMES.keys()]
        self._theme_var = tk.StringVar(
            value=f"{current}{_SUFFIX}" if current in THEMES else list(THEMES.keys())[0])

        row = tk.Frame(s, bg=T.BG); row.pack(fill="x", pady=(4, 8))
        lbl(row, tr_("Active theme:"), bold=True).pack(side="left", padx=(0, 8))
        combo = ttk.Combobox(row, textvariable=self._theme_var,
                              values=theme_values, width=30, state="readonly")
        combo.pack(side="left", padx=(0, 10))
        self._theme_swatch = tk.Frame(
            row, width=20, height=20,
            bg=THEMES.get(current, THEMES["Catppuccin Mocha"])["ACCENT"],
            highlightthickness=1, highlightbackground=T.FG)
        self._theme_swatch.pack(side="left", padx=(0, 14))
        self._theme_swatch.pack_propagate(False)
        combo.bind("<<ComboboxSelected>>", self._on_theme_preview)
        btn(row, tr_("✔ Apply"), self._apply_theme, color=T.ACCENT, width=14).pack(side="left")

    def _on_theme_preview(self, _event=None):
        """Color preview of the selected theme (before clicking Apply).
        Cannot be displayed IN the dropdown — ttk.Combobox does not allow
        per-row custom widgets — so shown next to it."""
        name = self._theme_var.get().replace("  ★ active", "").strip()
        t = THEMES.get(name)
        if t:
            self._theme_swatch.configure(bg=t["ACCENT"])

    def _apply_theme(self):
        name = self._theme_var.get().replace("  ★ active", "").strip()
        if name not in THEMES:
            return
        self.app.config["theme"] = name
        cfg.save(self.app.config)
        T.apply(name)
        self._restart_app()

    # ── Language ───────────────────────────────────────────────────────────

    def _build_language(self, parent):
        s = section(parent, tr_("🌐Language"))
        s.pack(fill="x", padx=10, pady=(8, 6))

        current = self.app.config.get("language", "en")
        _SUFFIX  = "  ★"

        lang_values = [f"{n}{_SUFFIX}" if c == current else n for c, n in _LANGUAGES]
        _default = next((f"{n}{_SUFFIX}" for c, n in _LANGUAGES if c == current), lang_values[0])
        self._lang_var = tk.StringVar(value=_default)

        row = tk.Frame(s, bg=T.BG); row.pack(fill="x", pady=(4, 8))
        lbl(row, tr_("Active language:"), bold=True).pack(side="left", padx=(0, 8))
        ttk.Combobox(row, textvariable=self._lang_var,
                     values=lang_values, width=36, state="readonly").pack(side="left", padx=(0, 14))
        btn(row, tr_("✔ Apply"), self._apply_language, color=T.ACCENT, width=14).pack(side="left")

        lbl(s, tr_("Changing the language restarts the application."),
            color="#888888", size=7).pack(anchor="w", pady=(0, 4))

    def _apply_language(self):
        raw  = self._lang_var.get().replace("  ★", "").strip()
        code = next((c for c, n in _LANGUAGES if n.strip() == raw.strip()), None)
        if not code:
            return
        self.app.config["language"] = code
        cfg.save(self.app.config)
        self._restart_app()

    def _restart_app(self):
        """Restarts OTA Guard in the new language."""
        try:
            import sys, subprocess, os
            is_frozen = getattr(sys, "frozen", False) or "__compiled__" in globals()
            if is_frozen:
                import ctypes
                buf = ctypes.create_unicode_buffer(32768)
                ctypes.windll.kernel32.GetModuleFileNameW(None, buf, 32768)
                exe = buf.value
            else:
                exe = sys.executable
            if is_frozen:
                os.startfile(exe)
            else:
                script = str(Path(sys.argv[0]).resolve())
                subprocess.Popen([exe, script] + sys.argv[1:], cwd=str(BASE_DIR),
                                 creationflags=_NO_WIN)
            self.app.root.after(200, self.app.root.destroy)
        except Exception as e:
            messagebox.showerror(
                tr_("Reboot"),
                tr_("Unable to restart automatically: {error}\nClose and restart OTA Guard manually.").format(error=e),
                parent=self.app.root)


    # ── Backup & Restore ───────────────────────────────────────────────────

    # ── License ───────────────────────────────────────────────────────────

    def _build_license(self, parent):
        s = section(parent, tr_("🔑 License"))
        s.pack(fill="x", padx=10, pady=(8, 6))

        # Current status
        try:
            from licensing.license_checker import (
                get_checker, TRIAL_ACTIVE, LICENSED,
                TRIAL_EXPIRED, LICENSE_EXPIRED)
            checker = get_checker()
            st      = checker.status
            info    = checker.info or {}

            if st == TRIAL_ACTIVE:
                remaining = info.get("days_remaining", 0)
                txt = tr_("🆓 Free trial — {n} day(s) remaining").format(n=remaining)
                col = T.YELLOW if remaining > 3 else T.ORANGE
            elif st == LICENSED:
                exp = info.get("expires") or "perpetual"
                ltype = info.get("type", "—")
                txt = f"✅ Active license ({ltype})  —  expires: {exp}"
                col = T.GREEN
            elif st == TRIAL_EXPIRED:
                txt = tr_("⛔ Trial expired — enter your license key")
                col = T.RED
            elif st == LICENSE_EXPIRED:
                exp = info.get("expires", "?")
                txt = tr_("⛔ License expired on {d}").format(d=exp)
                col = T.RED
            else:
                txt = tr_("❓ Status unknown")
                col = "#888888"
        except Exception as e:
            txt = f"⚠ License read error: {e}"
            col = T.RED

        tk.Label(s, text=txt, bg=T.BG, fg=col,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 6))

        # Machine ID
        try:
            from licensing.hw_id import get_hw_id_display
            mid = get_hw_id_display()
        except Exception:
            mid = "—"
        id_row = tk.Frame(s, bg=T.ENTRY_BG, padx=10, pady=6)
        id_row.pack(fill="x", pady=(0, 6))
        tk.Label(id_row, text=tr_("Machine ID:"), bg=T.ENTRY_BG, fg=T.FG,
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 8))
        mid_e = tk.Entry(id_row, bg=T.BG, fg=T.ACCENT, relief="flat",
                         font=("Courier New", 10, "bold"),
                         readonlybackground=T.BG, state="readonly")
        mid_e.pack(side="left", fill="x", expand=True, padx=(0, 8))
        mid_e.config(state="normal"); mid_e.insert(0, mid); mid_e.config(state="readonly")
        def _copy_mid():
            self.app.root.clipboard_clear()
            self.app.root.clipboard_append(mid)
        tk.Button(id_row, text="📋", command=_copy_mid,
                  bg=T.SEL_BG, fg=T.FG, relief="flat",
                  font=("Segoe UI", 9), cursor="hand2",
                  padx=6, pady=0).pack(side="left")

        # Activate button
        row = tk.Frame(s, bg=T.BG); row.pack(anchor="w", pady=(0, 4))
        btn(row, tr_("🔑 Enter a license key"),
            self._show_license_dialog,
            color=T.ACCENT, width=28).pack(side="left", padx=(0, 8))

    def _show_license_dialog(self):
        """Shows the license activation window."""
        try:
            from licensing.license_checker import get_checker
            checker = get_checker()
        except Exception as e:
            messagebox.showerror(tr_("License"),
                tr_("License module unavailable: {error}").format(error=e), parent=self.app.root)
            return

        dlg = tk.Toplevel(self.app.root)
        dlg.title(tr_("🔑 Activate a license"))
        dlg.configure(bg=T.BG)
        dlg.geometry("520x340")
        dlg.transient(self.app.root)
        dlg.grab_set()

        # Center
        dlg.update_idletasks()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dlg.geometry(f"+{(sw-520)//2}+{(sh-340)//2}")

        pad = tk.Frame(dlg, bg=T.BG, padx=24, pady=20)
        pad.pack(fill="both", expand=True)

        tk.Label(pad, text=tr_("🔑 Activate a license"), bg=T.BG, fg=T.ACCENT,
                 font=("Segoe UI", 14, "bold")).pack(pady=(0, 12))

        # Machine ID reminder
        try:
            from licensing.hw_id import get_hw_id_display
            mid = get_hw_id_display()
        except Exception:
            mid = "—"
        mid_row = tk.Frame(pad, bg=T.ENTRY_BG, padx=10, pady=6)
        mid_row.pack(fill="x", pady=(0, 12))
        tk.Label(mid_row, text=tr_("Machine ID:"), bg=T.ENTRY_BG, fg=T.FG,
                 font=("Segoe UI", 9)).pack(anchor="w")
        tk.Label(mid_row, text=mid, bg=T.ENTRY_BG, fg=T.ACCENT,
                 font=("Courier New", 10, "bold")).pack(anchor="w")

        # Key field
        tk.Label(pad, text=tr_("License key:"), bg=T.BG, fg=T.FG,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        key_var = tk.StringVar()
        key_e = tk.Entry(pad, textvariable=key_var,
                         bg=T.ENTRY_BG, fg=T.FG, insertbackground=T.FG,
                         relief="flat", highlightthickness=1,
                         highlightbackground=T.SEL_BG,
                         highlightcolor=T.ACCENT,
                         font=("Courier New", 11))
        key_e.pack(fill="x", pady=(4, 4), ipady=4)
        key_e.focus_set()

        status_lbl = tk.Label(pad, text="", bg=T.BG, fg=T.YELLOW,
                              font=("Segoe UI", 9), wraplength=460,
                              justify="left")
        status_lbl.pack(fill="x", pady=(4, 12))

        def _activate():
            key = key_var.get().strip()
            if not key:
                status_lbl.config(text=tr_("⚠ Enter a key."), fg=T.ORANGE)
                return
            try:
                ok, msg = checker.activate(key)
            except Exception as e:
                status_lbl.config(text=tr_("❌ Error: {e}").format(e=e), fg=T.RED)
                return
            if ok:
                status_lbl.config(text=tr_("✅ {msg} — reboot…").format(msg=msg), fg=T.GREEN)
                self.app.root.after(1500, lambda: (
                    dlg.destroy(),
                    self._restart_app()
                ))
            else:
                status_lbl.config(text=f"❌ {msg}", fg=T.RED)

        key_e.bind("<Return>", lambda _e: _activate())

        bbar = tk.Frame(pad, bg=T.BG); bbar.pack(fill="x")
        tk.Button(bbar, text=tr_("Cancel"), command=dlg.destroy,
                  bg=T.SEL_BG, fg=T.FG, font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=6,
                  cursor="hand2").pack(side="right", padx=(8, 0))
        tk.Button(bbar, text=tr_("🔑 Activate"), command=_activate,
                  bg=T.ACCENT, fg="#1e1e2e",
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=18, pady=6,
                  cursor="hand2").pack(side="right")

    def _build_backup(self, parent):
        s = section(parent, tr_("💾 Backup & Restore"))
        s.pack(fill="x", padx=10, pady=(8, 6))
        lbl(s,
            "Exports all data (config, databases, history) into a ZIP file.\n"
            "Ideal to back up on a USB stick or transfer to another PC.",
            color="#888888", size=8).pack(anchor="w", pady=(0, 8))

        row = tk.Frame(s, bg=T.BG); row.pack(anchor="w")
        btn(row, tr_("📤 Export backup"), self._do_export_backup,
            color=T.GREEN, width=22).pack(side="left", padx=(0, 10))
        btn(row, tr_("📥 Import backup"), self._do_import_backup,
            color=T.ORANGE, width=22).pack(side="left")

        self._bk_status = tk.Label(s, text="", bg=T.BG, fg=T.GREEN,
                                   font=("Segoe UI", 9))
        self._bk_status.pack(anchor="w", pady=(4, 0))

    def _do_export_backup(self):
        import zipfile
        from datetime import datetime as _dt
        default = f"otaguard_backup_{_dt.now().strftime('%Y%m%d_%H%M')}.zip"
        dest = filedialog.asksaveasfilename(
            parent=self.app.root, title="Save backup",
            initialfile=default, defaultextension=".zip",
            filetypes=[("Archive ZIP", "*.zip"), ("All", "*.*")])
        if not dest:
            return
        _FILES = ["config.json", "last_scan.json", "scraper.db"]
        def _run():
            try:
                self.app.root.after(0, lambda: self._bk_status.config(
                    text=tr_("⏳ Export in progress…"), fg=T.YELLOW))
                from core.calib_store import load_calib_data
                load_calib_data()  # forces the migration if the old single file is still around
                with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
                    for fname in _FILES:
                        fp = DATA_DIR / fname
                        if fp.exists():
                            zf.write(fp, fname)
                    for fp in sorted(DATA_DIR.glob("calibration_data_*.json")):
                        zf.write(fp, fp.name)
                    for fp in sorted(DATA_DIR.glob("calibration_data.json.migrated_bak*")):
                        zf.write(fp, fp.name)
                size_kb = Path(dest).stat().st_size // 1024
                self.app.root.after(0, lambda: self._bk_status.config(
                    text=tr_("✅ Export OK — {kb} KB").format(kb=size_kb), fg=T.GREEN))
            except Exception as e:
                self.app.root.after(0, lambda err=str(e): self._bk_status.config(
                    text=f"❌ {err}", fg=T.RED))
        threading.Thread(target=_run, daemon=True).start()

    def _do_import_backup(self):
        import zipfile
        src = filedialog.askopenfilename(
            parent=self.app.root, title="Choose a backup",
            filetypes=[("Archive ZIP", "*.zip"), ("All", "*.*")])
        if not src:
            return
        if not messagebox.askyesno(tr_("Confirm"),
                tr_("⚠ This operation will replace your configuration.\nContinue ?"),
                parent=self.app.root):
            return
        def _run():
            try:
                self.app.root.after(0, lambda: self._bk_status.config(
                    text=tr_("⏳ Import in progress…"), fg=T.YELLOW))
                data_dir = DATA_DIR
                with zipfile.ZipFile(src, "r") as zf:
                    names = zf.namelist()
                    for name in names:
                        target = data_dir / name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(name) as sf, open(target, "wb") as df:
                            df.write(sf.read())
                # Reload config in memory to avoid overwriting on close
                import json as _json
                try:
                    cfg_path = data_dir / "config.json"
                    if cfg_path.exists():
                        with open(cfg_path, encoding="utf-8") as f:
                            new_cfg = _json.load(f)
                        self.app.config.clear()
                        self.app.config.update(new_cfg)
                        try:
                            from business.secrets import inject_secrets
                            inject_secrets(self.app.config)
                        except Exception:
                            pass
                except Exception as _e_reload:
                    # Files already restored on disk (extraction above
                    # succeeded) — only the in-memory reload failed;
                    # harmless for the restored content (the restart
                    # re-reads config.json from disk), but we log the
                    # failure so it is not invisible.
                    import logging
                    logging.exception("Import backup: in-memory config reload failed")
                    try:
                        self.app._log_journal(
                            f"⚠ Import backup: in-memory config reload failed: {_e_reload}",
                            level="warning", engine="BACKUP")
                    except Exception:
                        pass
                self.app.root.after(0, lambda n=len(names): self._bk_status.config(
                    text=tr_("✅ Import OK — {n} file(s). Reboot…").format(n=n),
                    fg=T.GREEN))
                self.app.root.after(1500, self._restart_app)
            except Exception as e:
                self.app.root.after(0, lambda err=str(e): self._bk_status.config(
                    text=f"❌ {err}", fg=T.RED))
        threading.Thread(target=_run, daemon=True).start()

    # ── Updates ────────────────────────────────────────────────────────────

    # OTA Guard critical packages — checked and updated automatically
    _CRITICAL_PKGS = [
        "playwright", "requests", "urllib3", "certifi",
    ]

    def _build_updates(self, parent):
        s = section(parent, tr_("🔄 Component updates"))
        s.pack(fill="x", padx=10, pady=(8, 10))
        lbl(s,
            "Security updates are applied automatically.\n"
            "Click 'Check' to see the available updates.",
            color="#888888", size=8).pack(anchor="w", pady=(0, 6))

        # Results area
        self._upd_frame = tk.Frame(s, bg=T.BG)
        self._upd_frame.pack(fill="x", pady=(0, 6))
        self._upd_status = tk.Label(
            self._upd_frame, text=tr_("Click Check to check for updates."),
            bg=T.BG, fg="#888888", font=("Segoe UI", 9), justify="left", anchor="w")
        self._upd_status.pack(anchor="w")

        # Buttons
        row = tk.Frame(s, bg=T.BG); row.pack(anchor="w")
        self._upd_check_btn = btn(row, tr_("🔍 Check now"),
                                  self._check_updates, color=T.ACCENT, width=22)
        self._upd_check_btn.pack(side="left", padx=(0, 8))
        self._upd_apply_btn = btn(row, tr_("⬆ Update all"),
                                  self._apply_updates, color=T.GREEN, width=20)
        self._upd_apply_btn.pack(side="left")
        self._upd_apply_btn.config(state="disabled")

        # Check for OTA Guard's own application update (.exe updater).
        # Works in both modes; the actual installation is only offered
        # in the compiled version (see _check_ota_update).
        self._ota_upd_btn = btn(row, tr_("🔄 Check Update OTA Guard"),
                                self._check_ota_update, color="#f97316", width=24)
        self._ota_upd_btn.pack(side="left", padx=(8, 0))

        if _IS_FROZEN:
            self._upd_check_btn.config(state="disabled")
            self._upd_status.config(
                text=tr_("Component updates not available in compiled version."),
                fg="#888888")

        # Storage of outdated packages
        self._outdated_pkgs = []

    def _check_ota_update(self):
        """Manually checks whether a new OTA Guard (.exe) version is
        available on GitHub.

        The network check works in both modes (source and compiled);
        however the actual installation (downloading the .exe) is only
        offered in the compiled version — in source mode we only display
        that a version is available, never launching an installer
        (same D12/D26 guards as run_update_check)."""
        self._ota_upd_btn.config(state="disabled")
        self._upd_status.config(text=tr_("⏳ OTA Guard verification…"), fg=T.YELLOW)

        def _do():
            info, err = None, None
            try:
                from updater import check_for_update
                info = check_for_update()
            except Exception as e:
                err = str(e)

            def _ui():
                self._ota_upd_btn.config(state="normal")
                if err:
                    self._upd_status.config(
                        text=tr_("❌ Verification error: {err}").format(err=err[:60]),
                        fg=T.RED)
                elif info is None:
                    from version import VERSION
                    self._upd_status.config(
                        text=tr_("✅ OTA Guard is up to date (version {v}).").format(v=VERSION),
                        fg=T.GREEN)
                elif _IS_FROZEN:
                    from updater import show_update_dialog
                    show_update_dialog(self.app.root, info)
                else:
                    self._upd_status.config(
                        text=tr_("⬆ Version {v} available (installable only on the compiled version).").format(v=info.get("version", "?")),
                        fg=T.ORANGE)

            self.app.root.after(0, _ui)

        threading.Thread(target=_do, daemon=True).start()

    def _check_updates(self):
        if _IS_FROZEN:
            self._upd_status.config(
                text=tr_("Component updates not available in compiled version."),
                fg=T.ORANGE)
            return
        self._upd_check_btn.config(state="disabled")
        self._upd_apply_btn.config(state="disabled")
        self._upd_status.config(text=tr_("⏳ Verification in progress…"), fg=T.YELLOW)

        def _do():
            import json as _json
            outdated = []
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "list",
                     "--outdated", "--format=json"],
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                    timeout=60, creationflags=_NO_WIN)
                all_outdated = _json.loads(result.stdout or "[]")
                outdated = [p for p in all_outdated
                            if p["name"].lower() in
                            [x.lower() for x in self._CRITICAL_PKGS]]
            except Exception as e:
                self.app.root.after(0, lambda err=str(e): (
                    self._upd_status.config(
                        text=tr_("❌ Verification error: {err}").format(err=err[:60]), fg=T.RED),
                    self._upd_check_btn.config(state="normal")))
                return

            self._outdated_pkgs = outdated

            def _ui():
                self._upd_check_btn.config(state="normal")
                if not outdated:
                    self._upd_status.config(
                        text=tr_("✅ All components are up to date."), fg=T.GREEN)
                    self._upd_apply_btn.config(state="disabled")
                else:
                    lines = "\n".join(
                        f"  ⬆ {p['name']}  {p['version']} → {p['latest_version']}"
                        for p in outdated)
                    self._upd_status.config(
                        text=tr_("⚠ {n} update(s) available:\n{lines}").format(
                            n=len(outdated), lines=lines),
                        fg=T.ORANGE)
                    self._upd_apply_btn.config(state="normal")

            self.app.root.after(0, _ui)

        threading.Thread(target=_do, daemon=True).start()

    def _apply_updates(self):
        if _IS_FROZEN or not self._outdated_pkgs:
            return
        self._upd_apply_btn.config(state="disabled")
        self._upd_check_btn.config(state="disabled")
        self._upd_status.config(text=tr_("⏳ Update in progress…"), fg=T.YELLOW)
        pkgs = [p["name"] for p in self._outdated_pkgs]

        def _do():
            results = []
            for pkg in pkgs:
                try:
                    r = subprocess.run(
                        [sys.executable, "-m", "pip", "install",
                         "--upgrade", pkg, "--quiet"],
                        capture_output=True, text=True, encoding="utf-8", errors="replace",
                        timeout=120, creationflags=_NO_WIN)
                    if r.returncode == 0:
                        results.append(f"✅ {pkg}")
                        import importlib.metadata as _im
                        try:
                            v = _im.version(pkg)
                            results[-1] += f" → {v}"
                        except Exception:
                            pass
                    else:
                        results.append(f"❌ {pkg} : {r.stderr[:50]}")
                except Exception as e:
                    results.append(f"❌ {pkg} : {str(e)[:50]}")

            def _ui():
                self._upd_check_btn.config(state="normal")
                self._upd_apply_btn.config(state="disabled")
                self._outdated_pkgs = []
                msg = "Update completed:\n" + "\n".join(f"  {r}" for r in results)
                self._upd_status.config(text=msg, fg=T.GREEN)
                try:
                    self._log_journal(f"[Updates] {', '.join(results)}")
                except Exception:
                    pass

            self.app.root.after(0, _ui)

        threading.Thread(target=_do, daemon=True).start()

    def _auto_update_security(self):
        """Called at startup — silently updates the critical packages."""
        if _IS_FROZEN:
            return
        def _do():
            import json as _json
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "list",
                     "--outdated", "--format=json"],
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                    timeout=60, creationflags=_NO_WIN)
                outdated = _json.loads(result.stdout or "[]")
                security_pkgs = {"certifi", "urllib3", "requests"}
                to_update = [p["name"] for p in outdated
                             if p["name"].lower() in security_pkgs]
                for pkg in to_update:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install",
                         "--upgrade", pkg, "--quiet"],
                        capture_output=True, timeout=120, creationflags=_NO_WIN)
                    try:
                        self._log_journal(f"[Security auto-update] {pkg} updated")
                    except Exception:
                        pass
            except Exception:
                pass
        threading.Thread(target=_do, daemon=True).start()

    # ── Helpers ───────────────────────────────────────────────────────────

    def _sv_set(self, var, value):
        try:
            self.app.root.after(0, lambda: var.set(value))
        except Exception:
            pass
