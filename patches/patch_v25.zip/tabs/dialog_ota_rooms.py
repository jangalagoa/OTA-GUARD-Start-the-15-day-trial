"""
Dialog: OTA room naming — map the room names each OTA displays to the
hotel's own room types.

D108 — rebuilt entirely on owner's order: ONE FILE.
Everything you set here lives in data/room_names.json; the scan reads that
file and nothing else. No more mappings scattered across calibration files
(and no generic airbnb file left from an old trial — the cause of the
mixing that came back on every scan).

The OTA-side names come from the last real scan (ota_detected_rooms.json,
written by vae_scan), so the hotelier always picks from names that
actually appeared on the sites. The OTA list itself follows the CONFIG
(the OTAs the hotelier watches, one entry per Airbnb listing) — the menu
speaks the same language as the OTA bar.
"""

import json
import re
import tkinter as tk
from tkinter import messagebox, ttk

from core.theme import T
from core.utils import tr_


# ── Data helpers ────────────────────────────────────────────────────────────

def _detected_path():
    from core.paths import DATA_DIR
    return DATA_DIR / "ota_detected_rooms.json"


def load_detected() -> dict:
    """{ota_display: {"source_id": str, "rooms": [{"name","price","our",
    "lid","rid"}]}} from the last scan. Empty dict when no scan ran yet."""
    try:
        data = json.loads(_detected_path().read_text(encoding="utf-8"))
        return data.get("otas") or {}
    except Exception:
        return {}


def _ota_sid(name: str) -> str:
    """ota_id of the single file for an OTA/profile name."""
    try:
        from core.calib_store import _normalize_ota_id, _safe_ota_id
        return _safe_ota_id(_normalize_ota_id(name))
    except Exception:
        s = re.sub(r"[^a-z0-9_-]+", "_", (name or "").lower()).strip("_")
        return s or "_other"


def load_aliases(source_id: str) -> dict:
    """{ota_displayed_name: our_room} — read from THE single file."""
    try:
        from core import room_names
        return room_names.aliases(source_id)
    except Exception:
        return {}


def save_aliases(source_id: str, aliases: dict, id_aliases: dict = None) -> bool:
    """Writes an OTA's mappings into THE single file (names +
    machine id anchors together — one file, one truth)."""
    try:
        from core import room_names
        return room_names.set_aliases(source_id, aliases, id_aliases)
    except Exception:
        return False


# ── OTA list: the config first, the scan as complement ────────────────────

def _ota_sections(config: dict, detected: dict) -> list:
    """[{key, label, sid, rows, airbnb}] — one section per watched OTA.

    D110: Airbnb = ONE section (a single OTA), one row per LISTING —
    the listing number is the identity (label "Listing …XXXX"), with
    the link to open the listing and compare with your own eyes. Other
    OTAs keep their rows = the names they display."""
    room_types = list(config.get("room_types") or [])
    sections = []
    used_lids = set()

    try:
        from core.airbnb_unify import listing_ids_of, listing_display
    except Exception:
        listing_ids_of = None

    def _row(name, price, lid="", rid="", url=""):
        return {"name": name, "price": price, "lid": str(lid or ""),
                "rid": str(rid or ""), "url": url or ""}

    last_results = ((config.get("ota_watch", {}) or {})
                    .get("last_results") or {}).get("Airbnb") or {}

    for o in (config.get("ota_watch", {}) or {}).get("otas") or []:
        name = (o.get("name") or "").strip()
        url = o.get("url") or ""
        if not name:
            continue
        if listing_ids_of is not None and (o.get("listings")
                                           or ("airbnb" in url.lower()
                                               and "/rooms/" in url)):
            # ── Unified Airbnb section: one row per listing ──
            ids_map = {}
            try:
                from core import room_names
                ids_map = room_names.id_aliases("airbnb")
            except Exception:
                pass
            rows = []
            for lid, lurl in listing_ids_of(
                    {"ota_watch": {"otas": [o]}}):
                room = ids_map.get(lid) or ""
                price = last_results.get(room) if room else None
                rows.append(_row(listing_display(lid), price,
                                 lid=lid, url=lurl))
                used_lids.add(lid)
            sections.append({"key": "Airbnb", "label": "Airbnb",
                             "sid": "airbnb", "rows": rows, "airbnb": True})
            continue
        # Regular OTA: the names detected at the last scan.
        det_rows = ((detected.get(name) or {}).get("rooms") or [])
        rows = []
        if det_rows:
            for r in det_rows:
                rows.append(_row(r.get("name") or "?", r.get("price"),
                                 lid=r.get("lid"), rid=r.get("rid")))
        else:
            rows.append(_row(name, None))
        sections.append({"key": name, "label": name,
                         "sid": _ota_sid(name), "rows": rows,
                         "airbnb": False})

    # OTAs seen by the scan but absent from the config (safety):
    have_keys = {s["key"] for s in sections}
    for dname, info in sorted(detected.items()):
        if dname == "Airbnb":
            # listings detected but absent from the config: merged into
            # the Airbnb section if it exists, otherwise a dedicated section
            extra = []
            for r in (info.get("rooms") or []):
                if str(r.get("lid") or "") in used_lids:
                    continue
                extra.append(_row(listing_display(r.get("lid") or "?"),
                                  r.get("price"), lid=r.get("lid"),
                                  url=r.get("url") or ""))
            if not extra:
                continue
            if "Airbnb" in have_keys:
                for s in sections:
                    if s["key"] == "Airbnb":
                        s["rows"].extend(extra)
                        break
            else:
                sections.append({"key": "Airbnb", "label": "Airbnb",
                                 "sid": "airbnb", "rows": extra,
                                 "airbnb": True})
            continue
        if dname in have_keys:
            continue
        rows = [_row(r.get("name") or "?", r.get("price"),
                     lid=r.get("lid"), rid=r.get("rid"))
                for r in (info.get("rooms") or [])]
        if rows:
            sections.append({"key": dname, "label": dname,
                             "sid": _ota_sid(dname), "rows": rows,
                             "airbnb": False})
    return sections


# ── Dialog ──────────────────────────────────────────────────────────────────

def open_ota_rooms_dialog(app):
    """app: the App instance (uses app.config room_types + theme root)."""
    config = app.config or {}
    room_types = list(config.get("room_types", []) or [])

    dlg = tk.Toplevel()
    dlg.title(tr_("OTA Room Matching"))
    dlg.configure(bg=T.BG)
    dlg.grab_set()
    dlg.update_idletasks()

    # D108: the single file exists before any read/write of the menu.
    try:
        from core import room_names
        room_names.ensure_ready(config)
    except Exception:
        pass

    import tkinter.font as tkfont
    _fnt = tkfont.Font(family="Segoe UI", size=9)
    _sections = _ota_sections(config, load_detected())
    _all_rooms = [r["name"] or ""
                  for s in _sections for r in s["rows"]]
    _need_w = 380 + max([_fnt.measure(r) for r in (_all_rooms or ["x"])] or [0])
    _room_w = max([_fnt.measure(r) for r in (room_types or ["x"])] or [0])
    _want_w = max(760, min(_need_w, dlg.winfo_screenwidth() - 80))
    dlg.geometry(f"{_want_w}x560+{(dlg.winfo_screenwidth()-_want_w)//2}+"
                 f"{(dlg.winfo_screenheight()-560)//2}")
    dlg.minsize(680, 440)

    tk.Label(dlg, text=tr_("🔗 OTA room matching"),
             bg=T.BG, fg=T.ACCENT, font=("Segoe UI", 14, "bold")
             ).pack(pady=(14, 2))
    tk.Label(dlg,
             text=tr_("Tell the software which OTA room matches which room of your hotel.\n"
                      "ONE file (room_names.json): what you set here is exactly what the scan reads.\n"
                      "Applies at the next scan — an unmapped room is simply skipped.\n"
                      "⚠ Never change a mapping to reorder crossed prices:\n"
                      "corrections restore the order by themselves within a few scans."),
             bg=T.BG, fg="#888888", font=("Segoe UI", 9), justify="center"
             ).pack(pady=(0, 8))

    if not _sections:
        tk.Label(dlg,
                 text=tr_("No OTA configured.\nAdd your OTAs (OTA price block tab → My OTAs), "
                          "run a scan, then come back here."),
                 bg=T.BG, fg=T.ORANGE, font=("Segoe UI", 10), justify="center"
                 ).pack(expand=True)
        tk.Button(dlg, text=tr_("Close"), command=dlg.destroy,
                  bg=T.SEL_BG, fg=T.FG, relief="flat", padx=14, pady=5
                  ).pack(pady=12)
        return dlg

    top = tk.Frame(dlg, bg=T.BG)
    top.pack(fill="x", padx=16, pady=(0, 6))
    tk.Label(top, text=tr_("OTA:"), bg=T.BG, fg=T.FG,
             font=("Segoe UI", 10, "bold")).pack(side="left")
    ota_var = tk.StringVar(value=_sections[0]["key"])
    ota_cb = ttk.Combobox(top, textvariable=ota_var,
                          values=[s["key"] for s in _sections],
                          state="readonly", width=34)
    ota_cb.pack(side="left", padx=8)

    status = tk.Label(dlg, text="", bg=T.BG, fg=T.GREEN,
                      font=("Segoe UI", 9))
    status.pack(side="bottom", pady=6)

    table_wrap = tk.Frame(dlg, bg=T.BG)
    table_wrap.pack(fill="both", expand=True, padx=16)

    def _mk_row(parent):
        row = tk.Frame(parent, bg=T.BG)
        row.pack(fill="x", pady=1)
        row.grid_columnconfigure(0, weight=1)
        row.grid_columnconfigure(1, weight=0)
        row.grid_columnconfigure(2, weight=0)
        return row

    hdr = _mk_row(table_wrap)
    hdr.configure(bg=T.SEL_BG)
    tk.Label(hdr, text=tr_("Name displayed by OTA"), bg=T.SEL_BG, fg=T.FG,
             font=("Segoe UI", 9, "bold"), anchor="w"
             ).grid(row=0, column=0, sticky="ew", padx=(8, 4), pady=2)
    tk.Label(hdr, text=tr_("Price"), bg=T.SEL_BG, fg=T.FG,
             font=("Segoe UI", 9, "bold"), anchor="e", width=8
             ).grid(row=0, column=1, sticky="e", padx=(0, 12), pady=2)
    tk.Label(hdr, text=tr_("Your room"), bg=T.SEL_BG, fg=T.FG,
             font=("Segoe UI", 9, "bold"), anchor="w", width=26
             ).grid(row=0, column=2, sticky="w", padx=(4, 8), pady=2)

    canvas = tk.Canvas(table_wrap, bg=T.BG, highlightthickness=0)
    scroll = ttk.Scrollbar(table_wrap, orient="vertical", command=canvas.yview)
    rows_frame = tk.Frame(canvas, bg=T.BG)
    rows_frame.bind("<Configure>",
                    lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    _win_id = canvas.create_window((0, 0), window=rows_frame, anchor="nw")
    canvas.configure(yscrollcommand=scroll.set)
    canvas.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")

    _name_labels = []

    def _rewrap():
        fixed_right = _room_w + 150
        wl = max(160, canvas.winfo_width() - fixed_right)
        for l in _name_labels:
            try:
                l.configure(wraplength=wl)
            except Exception:
                pass

    canvas.bind("<Configure>", lambda e: (
        canvas.itemconfigure(_win_id, width=e.width), _rewrap()))

    selections = {}   # (sid, ota_room_name) -> StringVar
    anchors = {}      # (sid, ota_room_name) -> machine id (lid/rid)

    def _section_by_key(key):
        for s in _sections:
            if s["key"] == key:
                return s
        return _sections[0]

    def _refresh(_ev=None):
        for w in rows_frame.winfo_children():
            w.destroy()
        selections.clear()
        anchors.clear()
        _name_labels.clear()
        sec = _section_by_key(ota_var.get())
        aliases = load_aliases(sec["sid"])
        if not sec["rows"]:
            tk.Label(rows_frame, text=tr_("(no rooms detected for this OTA)"),
                     bg=T.BG, fg="#888888").pack(pady=10)
            return
        for r in sec["rows"]:
            name = r.get("name") or "?"
            _lid = r.get("lid") or ""
            _rid = r.get("rid") or ""
            _url = r.get("url") or ""
            row = _mk_row(rows_frame)
            fg = T.FG if name in aliases else "#93939b"

            # ── column "what VAE reads": the label + the link to
            # open the listing and compare with your own eyes (D110) ──
            name_cell = tk.Frame(row, bg=T.BG)
            name_cell.grid(row=0, column=0, sticky="ew", padx=(8, 4), pady=1)
            fixed_right = _room_w + 150
            wl = max(160, max(canvas.winfo_width(), 400) - fixed_right)
            name_lbl = tk.Label(name_cell, text=name, bg=T.BG, fg=fg,
                                font=("Segoe UI", 9), anchor="w",
                                justify="left", wraplength=wl)
            name_lbl.pack(side="left")
            _name_labels.append(name_lbl)
            if _url:
                import webbrowser
                link = tk.Label(name_cell, text=tr_("view listing ↗"),
                                bg=T.BG, fg=T.ACCENT, cursor="hand2",
                                font=("Segoe UI", 8, "underline"))
                link.pack(side="left", padx=(8, 0))
                link.bind(
                    "<Button-1>",
                    lambda _e, u=_url: webbrowser.open(u))
            tk.Label(row, text=str(r.get("price") or "—"), bg=T.BG, fg=fg,
                     font=("Segoe UI", 9), anchor="e", width=8
                     ).grid(row=0, column=1, sticky="e", padx=(0, 12), pady=1)
            var = tk.StringVar(value=aliases.get(name, ""))
            cb = ttk.Combobox(row, textvariable=var, values=[""] + room_types,
                              state="readonly", width=26)
            cb.grid(row=0, column=2, sticky="w", padx=(4, 8), pady=1)
            selections[(sec["sid"], name)] = var
            anchors[(sec["sid"], name)] = _lid or _rid

    ota_cb.bind("<<ComboboxSelected>>", _refresh)
    _refresh()

    btns = tk.Frame(dlg, bg=T.BG)
    btns.pack(side="bottom", pady=10)

    def _save():
        sec = _section_by_key(ota_var.get())
        sid = sec["sid"]
        aliases = {}
        id_al = {}
        for (s, name), var in selections.items():
            if s != sid or not var.get().strip():
                continue
            aliases[name] = var.get().strip()
            _anchor = anchors.get((sid, name)) or ""
            if _anchor:
                id_al[_anchor] = aliases[name]
        if not aliases:
            status.config(text=tr_("❌ Nothing to save (no room selected)"),
                          fg=T.ORANGE)
            return
        # Guard against the classic trap (user report 2026-08-16): when the
        # OTA's displayed prices cross, the tempting "fix" is to swap the
        # mapping so the price order looks right again. That disconnects
        # reading from writing — the correction loop then steers the wrong
        # card and the hotelier pays for it.
        old = load_aliases(sid)
        _changed = {k for k in old if k in aliases and old[k] != aliases[k]}
        if _changed:
            _old_vals = sorted(old[k] for k in _changed)
            _new_vals = sorted(aliases[k] for k in _changed)
            if _old_vals == _new_vals:   # same rooms reassigned = swap/rotation
                _pairs = "\n".join(f"• {k[:40]} : {old[k]} → {aliases[k]}"
                                   for k in sorted(_changed))
                if not messagebox.askyesno(
                        tr_("Room exchange?"),
                        tr_("You exchange rooms between OTA names:\n{pairs}\n\nA trade is almost always an ERROR: if prices appear inverted on the OTA, the correction puts them back in order by itself in a few scans.\nONLY change the mapping if the OTA has actually renamed its rooms.\n\nConfirm anyway?").format(
                                pairs=_pairs),
                        parent=dlg):
                    status.config(text=tr_("❌ Not registered — mapping unchanged"),
                                  fg=T.ORANGE)
                    return
        if save_aliases(sid, aliases, id_al):
            status.config(text=tr_("✅ Saved to room_names.json — "
                                   "applies at the next scan"),
                          fg=T.GREEN)
            print(f"[OTA_ROOMS] Saved {sec['label']}: "
                  f"{len(aliases)} mapping(s)"
                  + (f" + {len(id_al)} ID anchor(s)" if id_al else ""),
                  flush=True)
            try:
                app._log_journal(
                    f"🔗 Mapping {sec['label']} saved: "
                    f"{len(aliases)} name(s)"
                    + (f" + {len(id_al)} ID" if id_al else ""),
                    engine="OTA_ROOMS")
            except Exception:
                pass
        else:
            status.config(text=tr_("❌ Failed to save"), fg=T.RED)
            print(f"[OTA_ROOMS] SAVE FAILED {sec['label']} (sid={sid!r})",
                  flush=True)

    tk.Button(btns, text=tr_("💾 Save"), command=_save,
              bg=T.ACCENT, fg=T.BG, font=("Segoe UI", 10, "bold"),
              relief="flat", padx=16, pady=5, cursor="hand2"
              ).pack(side="left", padx=6)
    tk.Button(btns, text=tr_("Close"), command=dlg.destroy,
              bg=T.SEL_BG, fg=T.FG, font=("Segoe UI", 10),
              relief="flat", padx=14, pady=5, cursor="hand2"
              ).pack(side="left", padx=6)

    return dlg
