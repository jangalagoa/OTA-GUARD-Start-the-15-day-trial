"""
Tab: OTA Sources — OTA Guard
Displays only OTA 1 and OTA 2 (from ota_watch).
Technical information hidden. Wizard + success test.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import logging
from datetime import datetime

from core.theme import T
from core.widgets import lbl, btn, section, scrolled_frame, tooltip, status_badge
from core.utils import tr_
from core import config as cfg
from core.base_tab import BaseTab

# Same cap as the OTA slots table of OTA Price Block —
# both menus share the same list (ota_watch.otas).
_MAX_OTAS = 10

_OTA_NAME_CHOICES = ["Booking.com", "Agoda", "MakeMyTrip", "Google Hotels", "Expedia"]

# Default profile for each OTA (hidden technical)
_OTA_DEFAULTS = {
    "booking":       {"delay_min": 3, "delay_max": 7, "headless": True,
                      "stealth": True, "risk": "medium"},
    "agoda":         {"delay_min": 4, "delay_max": 8, "headless": True,
                      "stealth": True, "risk": "high"},
    "makemytrip":    {"delay_min": 3, "delay_max": 6, "headless": True,
                      "stealth": True, "risk": "medium"},
    "google_hotels": {"delay_min": 2, "delay_max": 5, "headless": True,
                      "stealth": False, "risk": "safe"},
    "expedia":       {"delay_min": 3, "delay_max": 6, "headless": True,
                      "stealth": True, "risk": "medium"},
    "tripadvisor":   {"delay_min": 3, "delay_max": 6, "headless": True,
                      "stealth": True, "risk": "medium"},
}


def _ota_id(name: str) -> str:
    n = name.lower().replace(".", "").replace(" ", "_")
    if "booking"   in n: return "booking"
    if "agoda"     in n: return "agoda"
    if "makemytrip"in n: return "makemytrip"
    if "google"    in n: return "google_hotels"
    if "expedia"   in n: return "expedia"
    if "tripadvisor" in n: return "tripadvisor"
    return n


class Tab(BaseTab):

    def build(self, app, frame):
        self.app      = app
        self._running = False

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("📡 OTA Sources"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        tooltip(
            btn(topbar, tr_("⚡ Auto-configure everything"), self._auto_configure_all,
                color=T.ORANGE, width=22),
            "Automatically detects the optimal configuration\nfor all monitored OTAs."
        ).pack(side="right", padx=4)

        sf, inner = scrolled_frame(frame)
        sf.pack(fill="both", expand=True)

        # ── Explanation ───────────────────────────────────────────────────
        info = tk.Frame(inner, bg=T.ENTRY_BG, padx=12, pady=8)
        info.pack(fill="x", padx=10, pady=(10, 4))
        lbl(info,
            "This menu configures price detection for your OTAs.",
            color=T.FG, size=9).pack(anchor="w")
        lbl(info,
            "OTAs are defined in OTA Price Block. "
            "Click 'Auto-configure' or test manually.",
            color="#888888", size=8).pack(anchor="w", pady=(2, 0))

        # ── OTA cards ─────────────────────────────────────────────────────
        self._s_otas = section(inner, tr_("Configuration by OTA"))
        self._s_otas.pack(fill="x", padx=10, pady=(8, 4))
        add_row = tk.Frame(self._s_otas, bg=T.BG); add_row.pack(fill="x", pady=(0, 6))
        btn(add_row, tr_("+ Add an OTA"), self._add_ota_dialog,
            color=T.ACCENT, width=18).pack(side="left")
        self._cards_frame = tk.Frame(self._s_otas, bg=T.BG)
        self._cards_frame.pack(fill="x")
        self._build_cards()

        # ── Scan period selector ──────────────────────────────────────────
        date_row = tk.Frame(inner, bg=T.BG)
        date_row.pack(fill="x", padx=10, pady=(8, 2))
        lbl(date_row, tr_("📅 Period:"), size=9, color="#aaa").pack(side="left", padx=(0, 6))
        _calib_offset_default = int(
            self.app.config.get("visual_scan", {}).get("date_offset", 1))
        self._test_date_offset_v = tk.IntVar(value=_calib_offset_default)
        for _d, _t in [(1, "D+1"), (3, "D+3"), (7, "D+7"), (10, "D+10"), (15, "D+15"), (30, "D+30")]:
            tk.Radiobutton(date_row, text=_t,
                           variable=self._test_date_offset_v, value=_d,
                           bg=T.BG, fg=T.FG,
                           selectcolor=T.SEL_BG, activebackground=T.BG,
                           font=("Segoe UI", 8), cursor="hand2").pack(side="left", padx=(0, 4))

        # ── Progress ─────────────────────────────────────────────────────
        prog_row = tk.Frame(inner, bg=T.BG)
        prog_row.pack(fill="x", padx=10, pady=(2, 2))
        self._prog = ttk.Progressbar(prog_row, mode="indeterminate", length=400)
        self._prog.pack(side="left")
        self._status_var = tk.StringVar(value="")
        self._status_lbl = tk.Label(prog_row, textvariable=self._status_var,
                                    bg=T.BG, fg=T.YELLOW,
                                    font=("Segoe UI", 9, "italic"))
        self._status_lbl.pack(side="left", padx=(10, 0))

        # ── Results log ───────────────────────────────────────────────────
        s_log = section(inner, tr_("Last test results"))
        s_log.pack(fill="x", padx=10, pady=(10, 10))
        self._log = tk.Text(s_log, bg=T.ENTRY_BG, fg=T.FG,
                            font=("Consolas", 9), height=6,
                            relief="flat", state="disabled")
        self._log.pack(fill="x")
        self._log.tag_config("ok",  foreground=T.GREEN)
        self._log.tag_config("err", foreground=T.RED)
        self._log.tag_config("info", foreground="#888888")

    # ── Cards ─────────────────────────────────────────────────────────────

    def refresh_on_show(self):
        """Tab built once at startup — the cards must be re-synced with
        `ota_watch.otas` every time the tab is shown. Without this, an OTA
        added/removed/renamed in OTA Price Block or the wizard only showed
        up here after a restart (the D38 propagation only worked in the
        OTA Sources → others direction).
        Does not rebuild while a test/auto-configuration is running."""
        if getattr(self, "_running", False):
            return
        try:
            self._build_cards()
        except Exception:
            logging.exception("refresh_on_show (tab_ota_sources): OTA card rebuild failed")

    def _build_cards(self):
        for w in self._cards_frame.winfo_children():
            w.destroy()

        otas = self.app.config.get("ota_watch", {}).get("otas", [])
        if not otas:
            lbl(self._cards_frame,
                "No OTA configured in OTA Price Block.",
                color=T.ORANGE, size=9).pack(anchor="w", pady=6)
            return

        sources = {s.get("id", ""): s
                   for s in self.app.config.get("sources", [])}

        for i, ota in enumerate(otas):
            name   = ota.get("name", "").strip()
            url    = ota.get("url", "").strip()
            if not name:
                continue
            oid    = _ota_id(name)
            src    = sources.get(oid, {})
            has_css = bool(src.get("css_selector", "").strip())
            ok      = has_css

            card = tk.Frame(self._cards_frame, bg=T.ENTRY_BG, padx=12, pady=8,
                            highlightthickness=1,
                            highlightbackground=T.GREEN if ok else T.ORANGE)
            card.pack(fill="x", pady=3)

            head = tk.Frame(card, bg=T.ENTRY_BG)
            head.pack(fill="x")
            tk.Label(head, text=name, bg=T.ENTRY_BG, fg=T.FG,
                     font=("Segoe UI", 10, "bold")).pack(side="left")
            status_badge(
                head,
                tr_("✅ Configured") if ok else tr_("⚠ Not configured"),
                T.GREEN if ok else T.ORANGE, size=8,
            ).pack(side="left", padx=(8, 0))
            tk.Label(head,
                     text="" if ok else tr_("  click Auto-configure"),
                     bg=T.ENTRY_BG, fg="#888888",
                     font=("Segoe UI", 8)).pack(side="left", padx=(8, 0))

            btns = tk.Frame(card, bg=T.ENTRY_BG)
            btns.pack(anchor="w", pady=(6, 0))
            tooltip(
                btn(btns, tr_("⚡ Auto-configure"),
                    lambda n=name, u=url: self._auto_configure_one(n, u),
                    color=T.ACCENT, width=16),
                "Automatically detects the configuration for this OTA."
            ).pack(side="left", padx=(0, 6))
            tooltip(
                btn(btns, tr_("🔍 Test"),
                    lambda n=name, u=url: self._test_one(n, u),
                    color=T.SEL_BG, width=10),
                "Checks that price detection works on this OTA."
            ).pack(side="left", padx=(0, 6))
            tooltip(
                btn(btns, "✕", lambda i=i, n=name: self._remove_ota(i, n),
                    color=T.RED, width=3),
                "Removes this OTA from monitoring (OTA Price Block, "
                "My Hotel watch and Calibration update themselves)."
            ).pack(side="left")

    # ── Add / remove an OTA ───────────────────────────────────────────────
    # Writes to ota_watch.otas, the list SHARED with OTA Price Block
    # (My Hotel watch section) and Calibration — both menus rebuild
    # from this same list every time they are reopened (refresh_on_show),
    # so an add/remove here propagates to them automatically.

    def _add_ota_dialog(self):
        dlg = tk.Toplevel(self.app.root)
        dlg.title(tr_("+ Add an OTA"))
        dlg.configure(bg=T.BG)
        dlg.geometry("460x200")
        dlg.resizable(False, False)
        dlg.grab_set()

        body = tk.Frame(dlg, bg=T.BG, padx=14, pady=14)
        body.pack(fill="both", expand=True)

        lbl(body, tr_("Name:"), color=T.FG).grid(row=0, column=0, sticky="w", pady=4)
        name_v = tk.StringVar(value=_OTA_NAME_CHOICES[0])
        ttk.Combobox(body, textvariable=name_v, values=_OTA_NAME_CHOICES,
                     width=22, state="normal").grid(row=0, column=1, sticky="w", pady=4)

        lbl(body, tr_("URL of your file:"), color=T.FG).grid(row=1, column=0, sticky="w", pady=4)
        url_v = tk.StringVar(value="")
        tk.Entry(body, textvariable=url_v, width=40, bg=T.ENTRY_BG, fg=T.FG,
                 relief="flat", highlightthickness=1, highlightbackground=T.SEL_BG,
                 font=("Segoe UI", 9)).grid(row=1, column=1, sticky="w", pady=4)

        active_v = tk.BooleanVar(value=True)
        tk.Checkbutton(body, text=tr_("Active"), variable=active_v,
                       bg=T.BG, fg=T.FG, activebackground=T.BG,
                       selectcolor=T.ENTRY_BG, font=("Segoe UI", 9)).grid(
            row=2, column=1, sticky="w", pady=(4, 8))

        err_lbl = tk.Label(body, text="", bg=T.BG, fg=T.RED,
                           font=("Segoe UI", 8), wraplength=420, justify="left")
        err_lbl.grid(row=3, column=0, columnspan=2, sticky="w")

        def _save():
            name = name_v.get().strip()
            if not name:
                err_lbl.config(text=tr_("The name is required."))
                return
            otas = self.app.config.setdefault("ota_watch", {}).setdefault("otas", [])
            slot = next((o for o in otas if not (o.get("name", "") or "").strip()), None)
            if slot is None:
                if len(otas) >= _MAX_OTAS:
                    err_lbl.config(text=tr_("Maximum {n} OTA reached.").format(n=_MAX_OTAS))
                    return
                slot = {}
                otas.append(slot)
            slot["name"]   = name
            slot["url"]    = url_v.get().strip()
            slot["active"] = active_v.get()

            # Any added OTA must have a "sources" entry from creation
            # (like "Auto-configure" does) — otherwise the scan engines
            # based on "sources" silently ignore the OTA until the user
            # thinks of running auto-configuration.
            oid  = _ota_id(name)
            defs = _OTA_DEFAULTS.get(oid, _OTA_DEFAULTS["booking"])
            sources = self.app.config.setdefault("sources", [])
            existing = next((s for s in sources if s.get("id") == oid), None)
            src_entry = {
                "id":            oid,
                "name":          name,
                "url_pattern":   self._url_pattern(slot["url"]) if slot["url"] else "",
                "css_selector":  (existing or {}).get("css_selector", ""),
                "active":        active_v.get(),
                "category":      "ota",
                **defs,
            }
            if existing:
                existing.update(src_entry)
            else:
                sources.append(src_entry)

            cfg.save(self.app.config)
            # D41: immediate engine sync (see tab_blocage_ota)
            try:
                from vae_bridge import sync_config_from_otaguard
                sync_config_from_otaguard(self.app.config)
            except Exception:
                import logging
                logging.exception("D41: VAE engine re-sync (source added)")
            dlg.destroy()
            self._build_cards()

        btn_row = tk.Frame(body, bg=T.BG)
        btn_row.grid(row=4, column=0, columnspan=2, sticky="w", pady=(4, 0))
        btn(btn_row, tr_("💾 Add"), _save,
            color=T.GREEN, width=14).pack(side="left", padx=(0, 6))
        btn(btn_row, tr_("Cancel"), dlg.destroy,
            color=T.SEL_BG, width=10).pack(side="left")

    def _remove_ota(self, idx, name):
        if not messagebox.askyesno(
                tr_("Remove an OTA"),
                tr_("Remove “{name}” from monitoring?\n\nTarget prices already entered for this OTA are retained if you add it again later with the same name.")
                    .format(name=name),
                parent=self.app.root):
            return
        otas = self.app.config.get("ota_watch", {}).get("otas", [])
        if 0 <= idx < len(otas):
            otas[idx]["name"]   = ""
            otas[idx]["url"]    = ""
            otas[idx]["active"] = False
            cfg.save(self.app.config)
            # D41: immediate engine sync (see tab_blocage_ota)
            try:
                from vae_bridge import sync_config_from_otaguard
                sync_config_from_otaguard(self.app.config)
            except Exception:
                import logging
                logging.exception("D41: VAE engine re-sync (source removed)")
        self._build_cards()

    # ── Auto-configuration ────────────────────────────────────────────────

    def _auto_configure_all(self):
        otas = self.app.config.get("ota_watch", {}).get("otas", [])
        pairs = [(o.get("name","").strip(), o.get("url","").strip())
                 for o in otas
                 if o.get("name","").strip() and o.get("url","").startswith("http")]
        if not pairs:
            messagebox.showwarning(tr_("OTA Sources"),
                tr_("No OTA with valid URL in OTA Price Block."),
                parent=self.app.root)
            return
        self._run_configure(pairs)

    def _auto_configure_one(self, name, url):
        if not url.startswith("http"):
            messagebox.showwarning(tr_("OTA Sources"),
                f"Missing URL for {name}.\nConfigure it in OTA Price Block.",
                parent=self.app.root)
            return
        self._run_configure([(name, url)])

    def _run_configure(self, pairs):
        if self._running:
            return
        self._running = True
        self._prog.config(mode="indeterminate")
        self._prog.start(12)
        self._log_clear()
        snap = dict(self.app.config)

        def _thread():
            for name, url in pairs:
                self._set_status(f"⏳ Configuring {name}…")
                self._log_write(f"▶ {name}", "info")
                oid   = _ota_id(name)
                defs  = _OTA_DEFAULTS.get(oid, _OTA_DEFAULTS["booking"])
                src_entry = {
                    "id":            oid,
                    "name":          name,
                    "url_pattern":   self._url_pattern(url),
                    "css_selector":  "",
                    "active":        True,
                    "category":      "ota",
                    **defs,
                }
                def _persist(oid=oid, src_entry=src_entry):
                    # Mutate + save self.app.config marshaled onto the main
                    # thread -- otherwise risk of racing another concurrent
                    # config read/write from the UI.
                    sources = self.app.config.setdefault("sources", [])
                    existing = next((s for s in sources if s.get("id") == oid), None)
                    if existing:
                        existing.update(src_entry)
                    else:
                        sources.append(src_entry)
                    cfg.save(self.app.config)

                self.app.root.after(0, _persist)
                self._log_write(
                    f"✅ {name} — default profile applied "
                    f"(set the CSS selector manually if needed)", "ok")
                logging.info("OTA Sources auto-config %s: defaults applied", name)
            self.app.root.after(0, self._on_done)

        threading.Thread(target=_thread, daemon=True).start()

    # ── Success test ──────────────────────────────────────────────────────

    def _test_one(self, name, url):
        if not url.startswith("http"):
            messagebox.showwarning(tr_("OTA test"),
                f"Missing URL for {name}.", parent=self.app.root)
            return
        if self._running:
            return
        self._running = True
        self._prog.config(mode="indeterminate")
        self._prog.start(12)
        self._log_clear()
        snap  = dict(self.app.config)
        # Exclude rooms with no configured target price (e.g. "move room")
        _target_prices = snap.get("ota_watch", {}).get("target_prices", {})
        rooms = [rt if isinstance(rt, str) else rt.get("type", "")
                 for rt in snap.get("room_types", [])
                 if rt and (rt if isinstance(rt, str) else rt.get("type", "")) in _target_prices]
        _date_offset = self._test_date_offset_v.get()

        def _thread():
            self._set_status(f"🔍 Test {name} (D+{_date_offset})…")
            self._log_write(f"▶ Detection test — {name}  [D+{_date_offset}]", "info")
            oid = _ota_id(name)
            src = next((s for s in snap.get("sources", []) if s.get("id") == oid), {})
            has_css = bool(src.get("css_selector", "").strip())
            if has_css:
                self._log_write(f"  ✅ {name} — CSS selector configured: {src['css_selector'][:60]}", "ok")
            else:
                self._log_write(f"  ⚠ {name} — no CSS selector configured", "err")
                self._log_write("  → VAE will extract prices by visual analysis during the scan.", "info")
            self.app.root.after(0, self._on_done)

        threading.Thread(target=_thread, daemon=True).start()

    # ── Fin + helpers ─────────────────────────────────────────────────────

    def _on_done(self):
        self._running = False
        self._prog.stop()
        self._set_status("")
        self._build_cards()

    def _url_pattern(self, url):
        try:
            from urllib.parse import urlparse
            p = urlparse(url)
            return f"{p.scheme}://{p.netloc}/*"
        except Exception:
            return url

    def _set_status(self, msg, color=None):
        def _do():
            self._status_var.set(msg)
            self._status_lbl.config(fg=color or T.YELLOW)
        try:
            self.app.root.after(0, _do)
        except Exception:
            pass

    def _log_write(self, msg, tag="info"):
        def _do():
            self._log.config(state="normal")
            self._log.insert("end", msg + "\n", tag)
            self._log.config(state="disabled")
            self._log.see("end")
        try:
            self.app.root.after(0, _do)
        except Exception:
            pass

    def _log_clear(self):
        def _do():
            self._log.config(state="normal")
            self._log.delete("1.0", "end")
            self._log.config(state="disabled")
        try:
            self.app.root.after(0, _do)
        except Exception:
            pass
