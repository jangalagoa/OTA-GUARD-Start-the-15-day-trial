"""Tab: 📊 Analysis report — D88: the engine made visible.

Sections: summary, relation learned per OTA, alerts, TWO full-width
charts (fluctuations by OTA / by room) with filters (period, multi-select
OTA/rooms, chart type), weekly history. Fully read-only: the engine
(business/analysis_engine) only describes what has already been recorded.
"""
import logging
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import ttk

from core.theme import T
from core.widgets import lbl, btn, section, tooltip
from core.utils import tr_
from core.base_tab import BaseTab

_log = logging.getLogger(__name__)

_PALETTE = ["#89b4fa", "#a6e3a1", "#f9e2af", "#f38ba8", "#cba6f7",
            "#94e2d5", "#fab387", "#eba0ac", "#89dceb", "#b4befe"]

_PERIODS = [("7 d", 7), ("30 d", 30), ("90 d", 90), ("All", 0)]


class Tab(BaseTab):
    def build(self, app, frame):
        self.app = app
        self._figs = {}
        self._canvas = {}

        # ── title bar ────────────────────────────────────────────
        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x", side="top")
        lbl(topbar, tr_("📊 Analysis report"), bold=True, size=11,
            color=T.ACCENT).pack(side="left")
        lbl(topbar, tr_("Read-only — what the software has learned about your OTAs."),
            color="#888888", size=8).pack(side="left", padx=(10, 0))
        tooltip(
            btn(topbar, tr_("🔄 Analyze"), self._refresh,
                color="#cba6f7", width=12),
            tr_("Re-reads the evidence journal and recomputes the whole report.")).pack(side="right", padx=(4, 0))

        body = tk.Frame(frame, bg=T.BG)
        body.pack(fill="both", expand=True)
        self._summary_lbl = lbl(body, "", color=T.FG, size=9)
        self._summary_lbl.pack(fill="x", padx=10, pady=(8, 0))

        self._model_box = tk.Frame(body, bg=T.BG)
        self._model_box.pack(fill="x", padx=10, pady=(6, 0))
        self._alert_box = tk.Frame(body, bg=T.BG)
        self._alert_box.pack(fill="x", padx=10, pady=(6, 0))

        self._build_chart(body)

        self._hist_box = tk.Frame(body, bg=T.BG)
        self._hist_box.pack(fill="x", padx=10, pady=(8, 10))

        self._refresh()

    # ── engine ──────────────────────────────────────────────────────
    def _refresh(self):
        import business.analysis_engine as ae
        try:
            self._records = ae.read_ledger_records()
            self._series = ae.price_series(self._records)
            self._model = ae.transfer_model()
            self._alerts = ae.anomalies(self._series, self._model)
            self._summary = ae.summary()
        except Exception:
            _log.exception("analysis refresh")
            return
        s = self._summary
        self._summary_lbl.configure(text=tr_("{r} price read(s) · {p} successful push(es) · {pp} POST proof(s) · {s} evidence session(s) since {d}").format(
            r=s["price_reads"], p=s["push_ok"], pp=s["post_proofs"],
            s=s["sessions"], d=s["first_record"] or "—"))
        self._render_model()
        self._render_alerts()
        self._render_history()
        self._rebuild_filters()

    # ── learned relation ────────────────────────────────────────────
    def _render_model(self):
        for w in self._model_box.winfo_children():
            w.destroy()
        sec = section(self._model_box, tr_("🧠 What the software has learned about each OTA"))
        sec.pack(fill="x")
        if not self._model:
            lbl(sec, tr_("Not enough measures yet — the sent → displayed relation will sharpen with upcoming pushes."), color="#888888",
                size=9).pack(anchor="w", padx=8, pady=4)
            return
        VERDICT = {"stable": ("✅ reliable", T.GREEN),
                   "learning": ("🟠 learning", T.ORANGE),
                   "unstable": ("🟠 variable", T.ORANGE),
                   "insufficient": ("⚪ not enough measures yet",
                                    "#888888")}
        for ota, m in sorted(self._model.items()):
            v_txt, v_col = VERDICT.get(m.get("verdict"),
                                       ("?", T.FG))
            row = tk.Frame(sec, bg=T.BG)
            row.pack(fill="x", padx=8, pady=1)
            if "ratio" in m:
                txt = tr_("{ota}: 1 {cur} sent → ~{ratio} {cur} displayed · spread {sp}% · {n} measures · {v}").format(
                    ota=ota, cur=_currency(self.app.config),
                    ratio=f"{m['ratio']:.2f}".rstrip("0").rstrip("."),
                    sp=int(m["spread"] * 100), n=m["n"], v=v_txt)
            else:
                txt = tr_("{ota}: {n} measure(s) — {v}").format(
                    ota=ota, n=m.get("n", 0), v=v_txt)
            lbl(row, txt, color=v_col if "ratio" not in m else T.FG,
                size=9).pack(side="left")

    # ── alerts ──────────────────────────────────────────────────────
    def _render_alerts(self):
        for w in self._alert_box.winfo_children():
            w.destroy()
        if not self._alerts:
            return
        sec = section(self._alert_box, tr_("⚠️ Alerts"))
        sec.pack(fill="x")
        for key, msgs in self._alerts.items():
            for m in msgs:
                lbl(sec, f"⚠️ {key} — {m}", color=T.ORANGE,
                    size=9).pack(anchor="w", padx=8, pady=1)

    # ── charts ──────────────────────────────────────────────────────
    def _build_chart(self, parent):
        sec = section(parent, tr_("📈 Price fluctuations"))
        sec.pack(fill="both", expand=True, padx=10, pady=(8, 0))
        self._chart_sec = sec

        try:
            import matplotlib
            matplotlib.use("TkAgg")
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import \
                FigureCanvasTkAgg
            self._Figure, self._CanvasTk = Figure, FigureCanvasTkAgg
        except Exception as e:
            lbl(sec, tr_("Charts unavailable (matplotlib missing): {e}").format(e=e),
                color=T.RED, size=9).pack(anchor="w", pady=4)
            self._Figure = None
            return

        # ── filter bar ───────────────────────────────────────────
        fb = tk.Frame(sec, bg=T.BG)
        fb.pack(fill="x", padx=8, pady=(2, 4))

        lbl(fb, tr_("Period :"), color="#888888", size=8
            ).pack(side="left", padx=(0, 4))
        self._period_var = tk.StringVar(value="30 d")
        for name, _days in _PERIODS:
            tk.Radiobutton(fb, text=name, variable=self._period_var,
                           value=name, command=self._redraw,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                           activebackground=T.BG, activeforeground=T.ACCENT,
                           font=("Segoe UI", 8)).pack(side="left")
        self._d1 = tk.StringVar(value="")
        self._d2 = tk.StringVar(value="")
        tk.Label(fb, text=tr_("from"), bg=T.BG, fg="#888888",
                 font=("Segoe UI", 8)).pack(side="left", padx=(10, 2))
        tk.Entry(fb, textvariable=self._d1, width=10, bg=T.ENTRY_BG,
                 fg=T.FG, relief="flat", insertbackground=T.FG,
                 font=("Consolas", 8)).pack(side="left")
        tk.Label(fb, text=tr_("At"), bg=T.BG, fg="#888888",
                 font=("Segoe UI", 8)).pack(side="left", padx=(6, 2))
        tk.Entry(fb, textvariable=self._d2, width=10, bg=T.ENTRY_BG,
                 fg=T.FG, relief="flat", insertbackground=T.FG,
                 font=("Consolas", 8)).pack(side="left")
        tk.Label(fb, text=tr_("(DD/MM/YYYY)"), bg=T.BG, fg="#555555",
                 font=("Segoe UI", 7)).pack(side="left", padx=(4, 0))

        lbl(fb, tr_("Type:"), color="#888888", size=8
            ).pack(side="left", padx=(12, 2))
        self._ctype = tk.StringVar(value=tr_("lines"))
        ttk.Combobox(fb, textvariable=self._ctype, state="readonly",
                     values=[tr_("lines"), tr_("bars"), tr_("dots")],
                     width=8, font=("Segoe UI", 8)).pack(side="left")

        # ── OTA / room selection (checkboxes) ────────────────────
        self._ota_sel_box = tk.Frame(sec, bg=T.BG)
        self._ota_sel_box.pack(fill="x", padx=8)
        self._room_sel_box = tk.Frame(sec, bg=T.BG)
        self._room_sel_box.pack(fill="x", padx=8)
        self._ota_vars, self._room_vars = {}, {}

        # ── both figures, FULL WIDTH ─────────────────────────────
        for name, title in (("ota", tr_("By OTA — displayed price over time")),
                            ("room", tr_("By room — displayed price over time"))):
            holder = tk.Frame(sec, bg=T.BG)
            holder.pack(fill="both", expand=True, padx=4, pady=(2, 6))
            fig = self._Figure(figsize=(12, 3.4), dpi=100)
            fig.patch.set_facecolor(T.BG)
            self._figs[name] = fig
            self._CanvasTk(fig, master=holder).get_tk_widget().pack(
                fill="both", expand=True)

    def _rebuild_filters(self):
        otas = sorted({o for (o, _r) in self._series} | set(self._model))
        rooms = sorted({_r for (_o, _r) in self._series})
        for box, items, store, prefix in (
                (self._ota_sel_box, otas, self._ota_vars, "ota"),
                (self._room_sel_box, rooms, self._room_vars, "room")):
            for w in box.winfo_children():
                w.destroy()
            store.clear()
            if not items:
                lbl(box, tr_("No prices recorded yet — run a scan."), color="#888888", size=8
                    ).pack(anchor="w")
                continue
            lbl(box, (tr_("OTAs:") if prefix == "ota"
                      else tr_("Rooms:") + " "),
                color="#888888", size=8).pack(side="left")
            for it in items:
                v = tk.BooleanVar(value=True)
                store[it] = v
                cb = tk.Checkbutton(box, text=it, variable=v,
                                    command=self._redraw, bg=T.BG,
                                    fg=T.FG, selectcolor=T.ENTRY_BG,
                                    activebackground=T.BG,
                                    activeforeground=T.ACCENT,
                                    font=("Segoe UI", 8))
                cb.pack(side="left", padx=3)
        self._redraw()

    # ── drawing ─────────────────────────────────────────────────────
    def _dates(self):
        d1 = d2 = None
        for var, end in ((self._d1, False), (self._d2, True)):
            raw = (var.get() or "").strip()
            if not raw:
                continue
            try:
                dd = datetime.strptime(raw, "%d/%m/%Y")
                if end:
                    dd = dd + timedelta(days=1)
                d1, d2 = (d1, dd) if not end else (d1, dd)
                if not end:
                    d1 = dd
            except ValueError:
                pass
        p = self._period_var.get()
        days = dict(_PERIODS).get(p, 30)
        if days and d1 is None:
            d1 = datetime.now() - timedelta(days=days)
        return d1, d2

    def _redraw(self):
        if not self._Figure:
            return
        import matplotlib.dates as mdates
        d1, d2 = self._dates()
        ctype = self._ctype.get()
        for name, group_key in (("ota", 0), ("room", 1)):
            fig = self._figs[name]
            fig.clf()
            ax = fig.add_subplot(111)
            ax.set_facecolor(T.ENTRY_BG)
            wanted = {k for k, v in (self._ota_vars if group_key == 0
                                     else self._room_vars).items()
                      if v.get()}
            plotted = 0
            for (ota, room), pts in sorted(self._series.items()):
                key = ota if group_key == 0 else room
                if key not in wanted:
                    continue
                xs = [dt for dt, _p in pts
                      if (d1 is None or dt >= d1)
                      and (d2 is None or dt <= d2)]
                ys = [p for dt, p in pts
                      if (d1 is None or dt >= d1)
                      and (d2 is None or dt <= d2)]
                if not xs:
                    continue
                color = _PALETTE[plotted % len(_PALETTE)]
                label = ota if group_key == 0 else room
                if ctype == tr_("bars"):
                    ax.bar(xs, ys, width=0.35, color=color, alpha=0.8,
                           label=label)
                elif ctype == tr_("dots"):
                    ax.plot(xs, ys, "o", color=color, ms=4,
                            label=label)
                else:
                    ax.plot(xs, ys, "-", marker="o", ms=3,
                            lw=1.6, color=color, label=label)
                plotted += 1
            title = (tr_("Fluctuations by OTA") if group_key == 0
                     else tr_("Fluctuations by room"))
            ax.set_title(f"{title}  ·  {plotted} curve(s)",
                         color=T.FG, fontsize=9, loc="left")
            ax.grid(True, color="#313244", lw=0.5, alpha=0.6)
            ax.tick_params(colors="#888888", labelsize=7)
            for sp in ax.spines.values():
                sp.set_color("#313244")
            if plotted:
                ax.xaxis.set_major_locator(
                    mdates.AutoDateLocator(minticks=4, maxticks=10))
                ax.xaxis.set_major_formatter(
                    mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()))
                ax.legend(loc="upper left", fontsize=7, framealpha=0.2,
                          labelcolor=T.FG, facecolor=T.SEL_BG,
                          edgecolor="#313244")
                ax.margins(x=0.02)
            else:
                ax.text(0.5, 0.5, tr_("No data in this period — adjust the filters or run a scan"),
                        ha="center", va="center", color="#888888",
                        fontsize=9, transform=ax.transAxes)
            fig.tight_layout(pad=1.5)
        for c in self._canvas.values():
            c.draw_idle()
        # (re)connect the canvases
        self._canvas.clear()
        for holder in [w for w in self._chart_sec.winfo_children()
                       if isinstance(w, tk.Frame)]:
            pass  # canvases already alive: draw_idle is enough

    # ── weekly history ──────────────────────────────────────────────
    def _render_history(self):
        import business.analysis_engine as ae
        for w in self._hist_box.winfo_children():
            w.destroy()
        sec = section(self._hist_box,
                      tr_("🗓️ Weekly history (displayed)"))
        sec.pack(fill="x")
        rows = ae.weekly_history(self._series)
        if not rows:
            lbl(sec, tr_("No history yet."),
                color="#888888", size=8).pack(anchor="w", padx=8, pady=4)
            return
        cols = ("week", "ota", "room", "min", "last", "max")
        tree = ttk.Treeview(sec, columns=cols, show="headings", height=6)
        for c, w, title in (("week", 70, tr_("Week")),
                            ("ota", 130, "OTA"),
                            ("room", 170, tr_("Bedroom")),
                            ("min", 90, tr_("Min")),
                            ("last", 90, tr_("Last")),
                            ("max", 90, tr_("Max"))):
            tree.heading(c, text=title)
            tree.column(c, width=w, anchor="center")
        tree.pack(fill="x", padx=8, pady=(0, 4))
        cur = _currency(self.app.config)
        for r in rows:
            tree.insert("", "end", values=(
                r["week"], r["ota"], r["room"],
                f"{int(r['min']):,}", f"{int(r['last']):,}",
                f"{int(r['max']):,}"))


def _currency(config):
    try:
        from core.utils import get_currency_symbol
        return get_currency_symbol(config).strip()
    except Exception:
        return ""
