"""
Tab: Extranet Direct (VAE 2) — OTA Guard V3

Minimal entry point of the "Extranet Direct" module (plan §4.1, reduced
version pending the full É7 tab):
  1. CM status — passive reading (vae2 scanner over VAE captures)
  2. Execution of ONE correction — blank TEST, or REAL behind the
     owner's explicit validation (plan É4: manual validation
     first). One single category at a time (D8), full log,
     before/after verification by the scanner.
"""
import queue
import tkinter as tk
from datetime import date, timedelta
from tkinter import messagebox

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame
from core.base_tab import BaseTab
from core.utils import tr_

import extranet_bridge as xb
from core import config as cfg


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app
        tab = frame

        self._q = queue.Queue()          # log lines → UI thread
        self._busy = False

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("🌐 Extranet Direct (without API)"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📖 Wiki"),
            lambda: self._show_wiki('🌐 Extranet Direct (sans API)'), color="#89b4fa", width=10).pack(side="right")
        btn(topbar, tr_("🧰 Integrate a new CM"),
            lambda: self._open_onboard_wizard(), color="#89b4fa", width=20).pack(side="right", padx=(0, 6))

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        # ══ 0. Active Channel Manager (D49: ONE CM at a time) ════════════
        s0 = section(inner, tr_("0. Channel Manager active — only one at a time"))
        s0.pack(fill="x", padx=10, pady=(8, 0))
        try:
            from vae2.adapters import AdapterRegistry
            _adapters = AdapterRegistry().discover()
        except Exception:
            _adapters = {}
        _by_name = {}
        for _dom, _ad in sorted(_adapters.items()):
            _by_name[_ad.name] = _ad
        _cm_cfg = app.config.get("channel_manager", {}).get(
            "extranet_direct", {}) or {}
        _cur_file = str(_cm_cfg.get("cm_map") or "channelmanager_com_au.yaml")
        _cur = next((_a for _a in _by_name.values()
                     if _a.map_path.name == _cur_file), None)
        _names = [a.name for a in _by_name.values()] or ["—"]
        r_cm = tk.Frame(s0, bg=T.BG); r_cm.pack(fill="x", pady=3)
        lbl(r_cm, tr_("Active CM:"), bold=True, width=12).pack(side="left")
        self._cm_var = tk.StringVar(
            value=(_cur.name if _cur else (_names[0] if _names else "—")))
        tk.OptionMenu(r_cm, self._cm_var, *_names).pack(side="left", padx=(0, 8))
        btn(r_cm, tr_("💾 Apply"), self._save_active_cm,
            color=T.ACCENT, width=12).pack(side="left")
        _dom = _cur.domain if _cur else "?"
        lbl(s0, tr_("Domain: {d} — the change takes effect at the next startup (keep-alive + listen). VAE2 never works with several CMs at the same time.").format(d=_dom),
            color="#888888", size=8).pack(anchor="w", pady=(2, 0))

        # ══ 1. CM status (passive reading) ═══════════════════════════════
        # D89: fallback credentials for automatic re-login
        s0b = section(inner, tr_("🔐 Automatic re-login — fallback credentials (optional)"))
        s0b.pack(fill="x")
        lbl(s0b, tr_("Used ONLY if Brave's autofill doesn't fill the form. Stored encrypted (DPAPI, bound to this machine). Empty = current behavior (2-click autofill, else manual login)."),
            color="#888888", size=8).pack(anchor="w", pady=(0, 4))
        from business.secrets import load_secrets, save_secrets
        _sec = load_secrets()
        row_u = tk.Frame(s0b, bg=T.BG); row_u.pack(fill="x", pady=1)
        lbl(row_u, tr_("User:"), size=9).pack(side="left")
        e_u = tk.Entry(row_u, width=28, bg=T.ENTRY_BG, fg=T.FG,
                       relief="flat", insertbackground=T.FG)
        e_u.insert(0, _sec.get("cm_user", ""))
        e_u.pack(side="left", padx=8)
        row_p = tk.Frame(s0b, bg=T.BG); row_p.pack(fill="x", pady=1)
        lbl(row_p, tr_("Password:"), size=9).pack(side="left")
        e_p = tk.Entry(row_p, width=28, bg=T.ENTRY_BG, fg=T.FG,
                       relief="flat", insertbackground=T.FG, show="\u2022")
        e_p.insert(0, _sec.get("cm_pass", ""))
        e_p.pack(side="left", padx=8)

        def _save_creds():
            s = load_secrets()
            s["cm_user"] = e_u.get().strip()
            s["cm_pass"] = e_p.get()
            save_secrets(s)
            messagebox.showinfo(
                tr_("Automatic re-login"),
                tr_("Credentials saved (DPAPI-encrypted). Automatic re-login will use them only if Brave's autofill fails."),
                parent=self.app.root)

        btn(s0b, tr_("💾 Save"), _save_creds,
            color=T.GREEN, width=14).pack(anchor="w", pady=4)

        s1 = section(inner, tr_("1. Channel Manager status — passive reading"))
        s1.pack(fill="x", padx=10, pady=8)

        self._state_lbl = lbl(s1, tr_("Not loaded — click “Load Status”.\n(no request is issued: reading of browser captures)"), size=8)
        self._state_lbl.pack(anchor="w", pady=(0, 6))

        r0 = tk.Frame(s1, bg=T.BG); r0.pack(fill="x", pady=3)
        btn(r0, tr_("🔄Load state"), self._load_state,
            color=T.ACCENT, width=18).pack(side="left")

        r1 = tk.Frame(s1, bg=T.BG); r1.pack(fill="x", pady=3)
        lbl(r1, tr_("Bedroom:"), width=10).pack(side="left")
        self._room_cb = tk.StringVar()
        self._room_menu = tk.OptionMenu(r1, self._room_cb, "—")
        self._room_menu.pack(side="left", padx=(0, 12))
        lbl(r1, tr_("OTA:"), width=6).pack(side="left")
        self._ota_cb = tk.StringVar()
        self._ota_menu = tk.OptionMenu(r1, self._ota_cb, "—")
        self._ota_menu.pack(side="left")

        self._room_cb.trace_add("write", self._refresh_current)
        self._ota_cb.trace_add("write", self._refresh_current)

        r2 = tk.Frame(s1, bg=T.BG); r2.pack(fill="x", pady=3)
        lbl(r2, tr_("Price to apply:"), width=18).pack(side="left")
        self._rate_var = tk.StringVar()
        entry(r2, self._rate_var, width=10).pack(side="left", padx=(0, 12))
        lbl(r2, tr_("From (YYYY-MM-DD):"), width=16).pack(side="left")
        self._from_var = tk.StringVar(value=(date.today() + timedelta(days=4)).isoformat())
        entry(r2, self._from_var, width=12).pack(side="left", padx=(0, 8))
        lbl(r2, tr_("At :"), width=3).pack(side="left")
        self._to_var = tk.StringVar(value=(date.today() + timedelta(days=4)).isoformat())
        entry(r2, self._to_var, width=12).pack(side="left")

        self._cur_lbl = lbl(s1, "", size=8)
        self._cur_lbl.pack(anchor="w", pady=(6, 0))

        # ══ 2. Execution ══════════════════════════════════════════════════
        s2 = section(inner, tr_("2. Execution — one category at a time"))
        s2.pack(fill="x", padx=10, pady=8)
        lbl(s2, tr_("TEST fills out the CM form without ever validating.\nAPPLY is actually valid (after your confirmation)."),
            size=8).pack(anchor="w", pady=(0, 6))

        r3 = tk.Frame(s2, bg=T.BG); r3.pack(fill="x", pady=3)
        self._test_btn = btn(r3, tr_("▶ Execute TEST (blank)"), self._run_test,
                             color="#94e2d5", width=22)
        self._test_btn.pack(side="left")
        self._apply_btn = btn(r3, tr_("✅ APPLY (real)"), self._run_real,
                              color="#f97316", width=18)
        self._apply_btn.pack(side="left", padx=(8, 0))

        # E4 seam: DISPLAY of the routing (set in the Channel
        # Manager tab → Transport — single source of truth, no second checkbox here)
        r3b = tk.Frame(s2, bg=T.BG); r3b.pack(fill="x", pady=(6, 0))
        self._routing_lbl = lbl(r3b, "", size=8)
        self._routing_lbl.pack(side="left")
        self._refresh_routing_status()

        self._result_lbl = lbl(s2, "", bold=True)
        self._result_lbl.pack(anchor="w", pady=(6, 0))

        # ══ 3. Log ════════════════════════════════════════════════════════
        s3 = section(inner, tr_("3. Action log"))
        s3.pack(fill="x", padx=10, pady=8)
        self._log = tk.Text(s3, height=14, bg=T.ENTRY_BG, fg=T.FG,
                            font=("Courier New", 8), relief="flat")
        self._log.pack(fill="x", padx=4, pady=4)

        self._poll()

    # ── Routing status (E4 seam, set in the CM tab) ─────────────────────────

    def _refresh_routing_status(self):
        cm = self.app.config.get("channel_manager", {}) or {}
        on = bool((cm.get("extranet_direct") or {}).get("enabled"))
        if on:
            self._routing_lbl.configure(
                text=tr_("🟢 “OTA Price Block” shipments go via HERE (Extranet Direct)"),
                fg=T.GREEN)
        else:
            self._routing_lbl.configure(
                text=tr_("⚪ Shipments via the CM API — to route here: Channel Manager tab → Transport → 🌐 Extranet Direct"),
                fg="#888888")

    # ── State reading ─────────────────────────────────────────────────────

    def _say(self, line):
        self._q.put(str(line))

    def _poll(self):
        try:
            while True:
                line = self._q.get_nowait()
                self._log.insert("end", line + "\n")
                self._log.see("end")
        except queue.Empty:
            pass
        self.app.root.after(150, self._poll)

    def _open_onboard_wizard(self):
        """D51: step-by-step wizard for onboarding a new CM."""
        from tabs.onboard_wizard import open_wizard
        open_wizard(self.app)

    def _save_active_cm(self):
        """D49: saves the active CM (single choice) into the config."""
        try:
            _sel = (self._cm_var.get() or "").strip()
            from vae2.adapters import AdapterRegistry
            _ad = AdapterRegistry().discover()
            _match = next((a for a in _ad.values() if a.name == _sel), None)
            if _match is None:
                messagebox.showerror(
                    tr_("Active CM"),
                    tr_("Adapter not found: {n}").format(n=_sel),
                    parent=self.app.root)
                return
            cm = self.app.config.setdefault("channel_manager", {})
            xd = cm.setdefault("extranet_direct", {})
            xd["cm_map"] = _match.map_path.name
            cfg.save(self.app.config)
            self._say(f"Active CM: {_match.name} (domain {_match.domain}) — "
                      f"takes effect at the next startup")
            messagebox.showinfo(
                tr_("Active CM"),
                tr_("Channel Manager active: {n}\nDomain: {d}\n\nTakes effect the next time you start the application.")
                    .format(n=_match.name, d=_match.domain),
                parent=self.app.root)
        except Exception as e:
            messagebox.showerror(tr_("Active CM"),
                                 tr_("Error: {e}").format(e=e),
                                 parent=self.app.root)

    def _load_state(self):
        """D103 — section "1. Channel Manager status" REBUILT: the reading
        can no longer hide anything. The log shows each candidate captures
        folder (path, count, freshness) and the one being read; any scan
        error is DISPLAYED (label + log) instead of a silent
        "0 rooms"; an empty or wrong folder is visible right
        away on screen."""
        if self._busy:
            return
        self._state_lbl.configure(text=tr_("Scanning captures in progress…"))
        self._say("── Loading CM state (passive reading) ──")

        def work():
            import time as _t
            # 1. Captures folders: what exists, what is read.
            try:
                infos = xb.capture_folders_report(self.app.config)
                for info in infos:
                    if not info["exists"]:
                        self._say(f"📁 {info['label']}: ABSENT "
                                  f"({info['path']})")
                        continue
                    if info["newest"]:
                        age_h = (_t.time() - info["newest"]) / 3600.0
                        fresh = f" · newest {age_h:.1f} h ago"
                    else:
                        fresh = " · EMPTY"
                    star = " ★" if info["label"].startswith("←") else ""
                    self._say(f"📁 {info['label']}: {info['count']} "
                              f"capture(s){fresh}{star}")
            except Exception as e:
                self._say(f"⚠ folder diagnostic impossible: {e}")
            # 2. The scan itself — any exception is DISPLAYED.
            try:
                rep = xb.scan_cm(self.app.config, say=self._say)
            except Exception as e:
                self._q.put(f"✗ SCAN ERROR: {e}\n")
                self.app.root.after(0, lambda: self._state_lbl.configure(
                    text=tr_("✗ Scan error — details in the log")))
                return
            self._q.put(f"── scan: {rep.status} · captured at "
                        f"{rep.captured_at} · {len(rep.rooms)} room(s)\n")
            self.app.root.after(0, lambda: self._fill_state(rep))

        self._run_thread(work)

    def _fill_state(self, rep):
        if rep.status != "ok" or not rep.rooms:
            self._state_lbl.configure(
                text=tr_("✗ No CM grid in captures — see folders 📁 in log (folder read, number of captures, freshness)"))
            self._say("✗ No usable grid — possible causes: "
                      "wrong captures folder chosen (see 📁), CM captures "
                      "purged, or grid never loaded in Brave")
            return
        st = xb.cm_state()
        rooms = [r["label"] for r in st["rooms"]]
        otas = [o["label"] for o in st["otas"]]
        self._room_cb.set(rooms[0] if rooms else "—")
        menu = self._room_menu["menu"]; menu.delete(0, "end")
        for r in rooms: menu.add_command(label=r, command=lambda v=r: self._room_cb.set(v))
        self._ota_cb.set(otas[0] if otas else "—")
        menu = self._ota_menu["menu"]; menu.delete(0, "end")
        for o in otas: menu.add_command(label=o, command=lambda v=o: self._ota_cb.set(v))
        self._state_lbl.configure(text=(
            f"{len(rooms)} rooms · {len(otas)} OTA · currency {st['currency']} · "
            f"captured at {st['captured_at']}"))
        self._refresh_current()

    def _refresh_current(self, *_):
        st = xb.cm_state()
        if not st:
            return
        room = next((r for r in st["rooms"] if r["label"] == self._room_cb.get()), None)
        ota = next((o for o in st["otas"] if o["label"] == self._ota_cb.get()), None)
        if not room or not ota:
            return
        p = xb.daily_price(room["code"], ota["code"], self._from_var.get().strip())
        if p is not None:
            self._cur_lbl.configure(text=tr_("Current price read on the grid (the {d}): {p:g} {cur}")
                                    .format(d=self._from_var.get(), p=p,
                                            cur=st['currency'] or ''))

    # ── Execution ─────────────────────────────────────────────────────────

    def _task_dict(self):
        return {
            "room_label": self._room_cb.get(),
            "ota_label": self._ota_cb.get(),
            "rate": self._rate_var.get().strip(),
            "date_from": self._from_var.get().strip(),
            "date_to": self._to_var.get().strip(),
        }

    def _run_test(self):
        self._launch(confirmed=False)

    def _run_real(self):
        t = self._task_dict()
        ok = messagebox.askyesno(
            tr_("Confirm actual shipment"),
            tr_("REALLY change the price on the Channel Manager?\n\nRoom: {r}\nOTA: {o}\nPrice: {p}\nDates: {df} → {dt}").format(
                r=t['room_label'], o=t['ota_label'], p=t['rate'],
                df=t['date_from'], dt=t['date_to']),
            icon="warning", parent=self.app.root)
        if ok:
            self._launch(confirmed=True)

    def _launch(self, confirmed):
        if self._busy:
            messagebox.showinfo(tr_("In progress"), tr_("An execution is already in progress."),
                                parent=self.app.root)
            return
        t = self._task_dict()
        if t["room_label"] in ("—", "") or not t["rate"] \
                or not t["date_from"] or not t["date_to"]:
            messagebox.showwarning(
                tr_("Incomplete"),
                tr_("Room, OTA, price and dates are required."),
                parent=self.app.root)
            return
        self._busy = True
        self._refresh_routing_status()
        self._test_btn.configure(state="disabled")
        self._apply_btn.configure(state="disabled")
        self._result_lbl.configure(text=tr_("Running…"), fg=T.FG)
        self._say(f"── {'APPLY (real)' if confirmed else 'TEST (blank)'}: "
                  f"{t['room_label']} / {t['ota_label']} / {t['rate']} "
                  f"from {t['date_from']} to {t['date_to']} ──")

        def done(result):
            def ui():
                self._busy = False
                self._test_btn.configure(state="normal")
                self._apply_btn.configure(state="normal")
                outcome = result.get("outcome")
                if outcome == "test_ok_no_modification":
                    self._result_lbl.configure(
                        text=tr_("✔ TEST completed — no changes sent"),
                        fg=T.GREEN)
                elif outcome == "verified":
                    changes = result.get("price_changes") or []
                    self._result_lbl.configure(
                        text=tr_("✔ SENT AND CHECKED — {n} change(s) noted on the grid").format(
                            n=len(changes)), fg=T.GREEN)
                else:
                    self._result_lbl.configure(
                        text=tr_("✖ Done: {o} — page left as is").format(
                            o=outcome),
                        fg=T.RED)
            self.app.root.after(0, ui)

        xb.run_correction(t, confirmed=confirmed, say=self._say, done=done,
                          app_config=self.app.config)

    def _run_thread(self, work):
        import threading
        threading.Thread(target=work, daemon=True,
                         name="vae2-extranet-ui").start()
