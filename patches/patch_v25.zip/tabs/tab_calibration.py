"""
Tab: Calibration — OTA Guard
Step-by-step wizard to calibrate each OTA.

Steps:
  1. OTA selection
  2. URL confirmation
  3. Chrome navigation → user clicks "I'm there"
  4. Price validation + auto-detected currency
  5. Done

Learned data (one file per OTA — see core/calib_store.py):
  - good_url        : validated URL where prices are visible
  - action_sequence : recorded clicks to replay
  - source_currency : currency displayed by the OTA (auto + manual)
  - prices_learned  : min/max/avg history per room
"""
import json
import time
import threading
import logging
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

from core.theme import T
from core.widgets import lbl, btn, entry, section, tooltip
from core import config as cfg
from core.utils import tr_, scannable_room_types, fmt_dt
from core.base_tab import BaseTab
from core.calib_store import load_calib_data, save_calib_data


def _json_numbers(obj, out=None, _depth=0):
    """Recursively collects "plausible price" numbers from a network JSON.

    Used to spot, among the network responses captured during calibration,
    the one containing the displayed prices — to learn the OTA's price
    endpoint (generalization of the existing Agoda room-grid interception).
    Bounds (100 → 5,000,000) deliberately wide: the JSON may be in a currency
    other than INR; fine filtering happens afterwards by mapping.
    """
    if out is None:
        out = []
    if _depth > 8 or len(out) > 3000:
        return out
    if isinstance(obj, dict):
        for _v in obj.values():
            _json_numbers(_v, out, _depth + 1)
    elif isinstance(obj, list):
        for _v in obj:
            _json_numbers(_v, out, _depth + 1)
    elif isinstance(obj, bool):
        pass  # bool is an int in Python — exclude it explicitly
    elif isinstance(obj, (int, float)):
        try:
            _n = int(obj)
            if 100 <= _n <= 5_000_000:
                out.append(_n)
        except Exception:
            pass
    elif isinstance(obj, str):
        # Some OTAs return the price as a string: "5,000" or "5000.00".
        _s = obj.replace(",", "").strip()
        if _s and _s.replace(".", "", 1).isdigit():
            try:
                _n = int(float(_s))
                if 100 <= _n <= 5_000_000:
                    out.append(_n)
            except Exception:
                pass
    return out

_OTA_PRICE_SELECTORS = {
    "booking": [
        '[data-testid="price-and-discounted-price"]',
        '[data-testid="price-for-x-nights"]',
        '.bui-price-display__value',
        'span[aria-label*="price" i]',
        '[class*="priceBlock"]',
    ],
    "agoda": [
        '[data-element-name="final-price"]',
        '[data-selenium="room-price"]',
        '[data-element-name="room-price"]',
        '[data-element-name="display-price"]',
        '[class*="RoomCell"] [class*="price" i]',
        '[class*="roomPrice" i]',
        '[class*="PriceDisplay" i]',
        '[data-selenium="display-price"]',
        '[itemprop="price"]',
    ],
    "makemytrip": [
        '[data-cy="price"]',
        '.priceText',
        '[class*="price" i][class*="amount" i]',
    ],
    "google_hotels": [
        'span.MW1oTb', '.UGhPb .MW1oTb', 'span.UeIHqb',
        '.rPnwsd', '.JR4iLb', '[jsname="qCDwBb"]',
        'span[aria-label*="price" i]',
    ],
}


class Tab(BaseTab):

    _MANUAL_SCAN_JS = """
(function() {
    if (window.__mscan_rec) return;
    window.__mscan_rec   = true;
    window.__mscan_click = null;   // last captured click, waiting for assignment
    window.__mscan_new_profile_requested = false;
    // Block SPA navigation (React/Google Hotels)
    history.pushState    = function(){};
    history.replaceState = function(){};
    window.open          = function(){ return null; };
    window.addEventListener('beforeunload',function(e){e.preventDefault();e.returnValue='';return '';},true);
    // Block all href links on the page
    function disableLinks(){
        document.querySelectorAll('a').forEach(function(a){
            a.removeAttribute('href');
            a.style.cursor='default';
        });
    }
    disableLinks();
    new MutationObserver(disableLinks).observe(document.documentElement,{childList:true,subtree:true});
    function cssEsc(s) {
        return (window.CSS && CSS.escape) ? CSS.escape(s) : s.replace(/([^a-zA-Z0-9_-])/g,'\\\\$1');
    }
    function getCss(el) {
        if (el.id) return '#' + cssEsc(el.id);
        var s = el.tagName.toLowerCase();
        var cls = (el.className||'').trim().split(/\\s+/).filter(Boolean).slice(0,3).map(cssEsc).join('.');
        return cls ? s+'.'+cls : s;
    }
    function getDirectText(el) {
        var t = '';
        for (var i=0;i<el.childNodes.length;i++)
            if (el.childNodes[i].nodeType===3) t+=el.childNodes[i].textContent;
        return t.trim();
    }
    // Text with fallbacks for CSS/icon elements (SVG stars, nested prices…)
    function getBestText(el) {
        var t = getDirectText(el);
        if (t && t.length <= 150) return t;
        var a = el.getAttribute && (
            el.getAttribute('aria-label') ||
            el.getAttribute('data-score') ||
            el.getAttribute('data-rating') ||
            el.getAttribute('title') ||
            el.getAttribute('alt')
        );
        if (a && a.trim()) return a.trim().slice(0,80);
        return (el.textContent||'').trim().slice(0,80);
    }
    function showBadge(el,color,label) {
        el.style.outline='3px solid '+color; el.style.outlineOffset='3px';
        var rect=el.getBoundingClientRect();
        var b=document.createElement('div');
        b.textContent=label;
        b.style.cssText='position:fixed;background:'+color+';color:#fff;border-radius:12px;padding:2px 8px;font-size:12px;font-weight:bold;z-index:2147483647;pointer-events:none;top:'+Math.max(4,rect.top-26)+'px;left:'+rect.left+'px;';
        document.body.appendChild(b);
        setTimeout(function(){b.remove();el.style.outline='';},2200);
    }
    // Hover preview BEFORE the click — to see what will be captured
    var lastHov=null;
    document.addEventListener('mouseover',function(e){
        if (lastHov && lastHov!==e.target) lastHov.style.outline=lastHov.__mscanOrig||'';
        lastHov=e.target;
        lastHov.__mscanOrig=lastHov.style.outline||'';
        lastHov.style.outline='2px dashed #ff8c00';
        e.stopPropagation();
    },true);
    // Capture one click at a time: no auto-alternation — the user then
    // chooses (Python side) whether it was the NAME or the PRICE.
    function captureTarget(origEl) {
        // One click at a time: while the previous one has not been read and
        // confirmed on the OTA Guard side, later clicks are ignored (otherwise
        // they surface late and get recorded under the wrong role).
        if (window.__mscan_click) {
            if (window.__mscan_banner) window.__mscan_banner('⏳ Confirm the previous click first (choose its type or Reject) in the calibration window');
            return;
        }
        var el=origEl, text='';
        for (var d=0; d<5 && el && el.tagName!=='BODY'; el=el.parentElement, d++) {
            text=getBestText(el);
            if (text && text.length<150) break;
            text='';
        }
        if (!text) text=origEl.tagName.toLowerCase();
        // Walk up to a selector neither too specific nor too generic (2-100 matches)
        var sel=getCss(origEl), selEl=origEl;
        for (var cur=origEl, i=0; i<4 && cur && cur.tagName!=='BODY'; cur=cur.parentElement, i++) {
            try {
                var s=getCss(cur);
                var c=document.querySelectorAll(s).length;
                if (c>=2 && c<=100) { sel=s; selEl=cur; break; }
            } catch(_e) { /* invalid selector on this ancestor: keep going */ }
        }
        // ── EXACT position of the clicked element ────────────────────────
        // `sel` above is deliberately WIDE: the "2 to 100 matches" condition
        // exists to find every room of a list (Booking, Agoda…). On a page
        // showing a single offer (Airbnb), the same selector also matches the
        // neighbouring buttons: the automatic re-read then took the first one,
        // and the price read was not the clicked one. We therefore ALSO store
        // a unique path to the element, and its rank among `sel` matches.
        function uniquePath(el) {
            var parts=[];
            for (var n=el; n && n.nodeType===1 && n.tagName!=='HTML'; n=n.parentElement) {
                if (n.id) { parts.unshift('#'+cssEsc(n.id)); break; }
                var k=1;
                for (var p=n.previousElementSibling; p; p=p.previousElementSibling)
                    if (p.tagName===n.tagName) k++;
                parts.unshift(n.tagName.toLowerCase()+':nth-of-type('+k+')');
                if (n.tagName==='BODY') break;
            }
            return parts.join(' > ');
        }
        var path='', idx=-1, nmatch=0;
        try {
            path=uniquePath(selEl);
            // A path that does not designate exactly ONE element is worthless:
            // better store nothing than store an ambiguity.
            if (document.querySelectorAll(path).length!==1) path='';
        } catch(_e) { path=''; }
        try {
            var _all=document.querySelectorAll(sel);
            nmatch=_all.length;
            idx=Array.prototype.indexOf.call(_all, selEl);
        } catch(_e) { idx=-1; nmatch=0; }
        showBadge(origEl,'#e67e22','👆 '+text.slice(0,25));
        window.__mscan_click={text:text,sel:sel,path:path,idx:idx,nmatch:nmatch};
        if (window.__mscan_banner) window.__mscan_banner('Captured: "'+text.slice(0,50)+'" — choose its type in the calibration window');
    }
    // 'pointerdown' first: fires on press, before a page (seen on MakeMyTrip
    // mobile) can swallow the 'click' event with its own touch handler —
    // the hover lit up but the click never arrived. 'click' stays as a
    // fallback for classic pages; the __mscan_click guard above avoids a
    // double capture if both events fire for the same press.
    document.addEventListener('pointerdown',function(e){
        e.preventDefault();
        captureTarget(e.target);
    },true);
    document.addEventListener('click',function(e){
        e.preventDefault();
        captureTarget(e.target);
    },true);
    // Fixed banner at the top of the page — visible feedback even if the
    // calibration (Tkinter) window is hidden behind Chrome.
    var _mb=document.createElement('div'); _mb.id='__mscan_banner_el';
    Object.assign(_mb.style,{
        position:'fixed', top:'0', left:'0', right:'0',
        height:'36px', background:'#e67e22', color:'#fff',
        font:'bold 12px Arial', lineHeight:'36px',
        padding:'0 12px', zIndex:'2147483647', pointerEvents:'none'
    });
    _mb.textContent='OTA Guard — Click an element then choose its type in the calibration window';
    document.body.prepend(_mb);
    window.__mscan_banner=function(t){
        var el=document.getElementById('__mscan_banner_el');
        if (el) el.textContent='OTA Guard — '+t;
    };
    // Floating button: manual restart with a blank Chrome profile — below
    // the banner above, top-right corner, discreet and non-blocking for
    // reading the page.
    if (!document.getElementById('__mscan_np_btn')) {
        var _npBtn=document.createElement('button');
        _npBtn.id='__mscan_np_btn';
        _npBtn.type='button';
        _npBtn.textContent='🧹 New profile';
        Object.assign(_npBtn.style,{
            position:'fixed', top:'44px', right:'8px', zIndex:'2147483647',
            padding:'6px 10px', font:'12px sans-serif', background:'#fff3cd',
            color:'#664d03', border:'1px solid #ffe69c', borderRadius:'4px',
            cursor:'pointer', opacity:'0.55', boxShadow:'0 1px 3px rgba(0,0,0,.3)'
        });
        _npBtn.onmouseenter=function(){ if(!_npBtn.disabled) _npBtn.style.opacity='1'; };
        _npBtn.onmouseleave=function(){ if(!_npBtn.disabled) _npBtn.style.opacity='0.55'; };
        _npBtn.onclick=function(){
            window.__mscan_new_profile_requested=true;
            _npBtn.disabled=true;
            _npBtn.textContent='⏳ New profile…';
            _npBtn.style.opacity='1';
            _npBtn.style.cursor='default';
        };
        document.body.appendChild(_npBtn);
    }
})();
"""

    def build(self, app, frame):
        self.app = app
        self._calib_data = self._calib_load()

        # ── Wizard state ──────────────────────────────────────────────────
        self._wiz_step           = 1
        self._wiz_ota            = None    # (oid, name)
        self._wiz_url            = ""
        self._wiz_browser_ctx    = None
        self._wiz_browser_page   = None
        self._wiz_browser_closed = None    # threading.Event: set by the Chrome
                                            # thread itself after its ctx.close()
        self._wiz_actions        = []
        self._wiz_urls_visited   = []
        self._wiz_good_url       = ""
        self._wiz_last_url_with_prices = ""  # see comment at reset (line ~694)
        self._wiz_prices         = {}      # {room: INR price}
        self._wiz_detected_cur   = ""
        self._wiz_raw_prices     = []      # raw prices found
        self._wiz_nav_stop       = None
        self._wiz_validations    = {}      # {room: True/False}
        self._wiz_manual_css_sel    = ""   # CSS selector of the final price (scans)
        self._wiz_manual_attrs      = {}   # {room: {field: {"text","sel","inr"?}}}
        self._wiz_manual_field_sels = {}   # {field: most frequent CSS selector}
        self._wiz_room_aliases      = {}   # {name displayed by the OTA: our room}

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=8, padx=12)
        topbar.pack(fill="x")
        lbl(topbar, tr_("📐 Assisted calibration"), bold=True, size=12).pack(side="left")
        hotel = self.app.config.get("hotel_name", "My Hotel")
        lbl(topbar, f"  —  {hotel}", size=10, color="#888888").pack(side="left")
        btn(topbar, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))

        # ── Date selector ─────────────────────────────────────────────────
        tk.Frame(topbar, bg="#555", width=1).pack(side="left", fill="y",
                                                   padx=(16, 12), pady=2)
        lbl(topbar, "📅", size=10, color="#aaa").pack(side="left", padx=(0, 4))
        _calib_offset_default = int(
            self.app.config.get("visual_scan", {}).get("date_offset", 1))
        self._wiz_date_offset_v = tk.IntVar(value=_calib_offset_default)
        for _d, _t in [(1, "D+1"), (3, "D+3"), (7, "D+7"), (10, "D+10"), (15, "D+15"), (30, "D+30")]:
            tk.Radiobutton(topbar, text=_t,
                           variable=self._wiz_date_offset_v, value=_d,
                           bg=T.SEL_BG, fg=T.FG,
                           selectcolor=T.SEL_BG, activebackground=T.SEL_BG,
                           font=("Segoe UI", 8), cursor="hand2").pack(side="left",
                                                                      padx=(0, 4))
        tk.Frame(topbar, bg="#555", width=1).pack(side="left", fill="y",
                                                   padx=(10, 8), pady=2)
        tk.Label(topbar,
                 text=tr_("⚠ Check that at least 1 room per category is free — if full, change the period"),
                 bg=T.SEL_BG, fg=T.FG,
                 font=("Segoe UI", 7)).pack(side="left")

        # ── Log at the bottom (packed first = always at the bottom) ────────
        log_frame = tk.Frame(frame, bg=T.BG, padx=12, pady=6)
        log_frame.pack(side="bottom", fill="x")
        _hdr = tk.Frame(log_frame, bg=T.BG)
        _hdr.pack(fill="x")
        lbl(_hdr, tr_("📋 Journal"), bold=True, size=10, color="#888").pack(side="left")
        tk.Button(_hdr, text="🗑", command=self._log_clear,
                  bg=T.BG, fg="#888", font=("Segoe UI", 9),
                  relief="flat", cursor="hand2").pack(side="right")
        _log_wrap = tk.Frame(log_frame, bg="#0d0d1a")
        _log_wrap.pack(fill="both", pady=(2, 0))
        _log_sb = tk.Scrollbar(_log_wrap, orient="vertical", bg=T.BG)
        _log_sb.pack(side="right", fill="y")
        self._log_txt = tk.Text(_log_wrap, bg="#0d0d1a", fg="#aaaaaa",
                                font=("Courier New", 10), height=9,
                                relief="flat", state="disabled", wrap="word",
                                yscrollcommand=_log_sb.set)
        self._log_txt.pack(side="left", fill="both", expand=True)
        _log_sb.config(command=self._log_txt.yview)
        self._log_txt.tag_configure("ok",    foreground="#a6e3a1")
        self._log_txt.tag_configure("warn",  foreground="#f9a825")
        self._log_txt.tag_configure("err",   foreground="#f38ba8")
        self._log_txt.tag_configure("info",  foreground="#7a8ab0")
        self._log_txt.tag_configure("price", foreground="#cba6f7")

        # ── Central zone (OTA cards + wizard) ─────────────────────────────
        _mid = tk.Frame(frame, bg=T.BG)
        _mid.pack(fill="both", expand=True)

        # OTA cards (overview — hidden during the wizard).
        #
        # SCROLLABLE zone: the cards piled up in a plain frame, with no
        # scrollbar nor mouse wheel. From 8 OTAs on (Airbnb case: one listing
        # per room = one OTA each), the last cards went off-screen with no way
        # to reach them — the bottom log takes a fixed height and leaves no
        # room. Same construction as the wizard central zone below: outer
        # frame + scrollbar + Canvas + inner frame.
        #
        # ⚠ It is _cards_scroll (the OUTER frame) that _show_step shows and
        # hides, no longer _cards_outer: the latter now lives INSIDE the Canvas
        # via create_window, is no longer managed by pack() and a pack_forget()
        # on it would hide nothing.
        self._cards_scroll = tk.Frame(_mid, bg=T.BG)
        self._cards_scroll.pack(fill="both", expand=True, padx=12, pady=(6, 0))

        _cards_vscroll = tk.Scrollbar(self._cards_scroll, orient="vertical")
        _cards_vscroll.pack(side="right", fill="y")

        self._cards_canvas = tk.Canvas(
            self._cards_scroll, bg=T.BG, bd=0,
            highlightthickness=0,
            yscrollcommand=_cards_vscroll.set)
        self._cards_canvas.pack(side="left", fill="both", expand=True)
        _cards_vscroll.config(command=self._cards_canvas.yview)

        self._cards_outer = tk.Frame(self._cards_canvas, bg=T.BG)
        self._cards_outer_win = self._cards_canvas.create_window(
            (0, 0), window=self._cards_outer, anchor="nw")

        def _cards_inner_resize(e):
            # Total height of the cards → scrollbar travel.
            self._cards_canvas.configure(
                scrollregion=self._cards_canvas.bbox("all"))
        self._cards_outer.bind("<Configure>", _cards_inner_resize)

        def _cards_canvas_resize(e):
            # Without this, the inner frame keeps its natural width and the
            # cards do not stretch over the full tab width.
            self._cards_canvas.itemconfig(self._cards_outer_win, width=e.width)
        self._cards_canvas.bind("<Configure>", _cards_canvas_resize)

        def _cards_mousewheel(e):
            self._cards_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        self._cards_mousewheel = _cards_mousewheel
        self._cards_canvas.bind("<MouseWheel>", _cards_mousewheel)
        self._cards_outer.bind("<MouseWheel>", _cards_mousewheel)

        # Wizard section (hidden at start, shown during calibration)
        self._wiz_section = tk.Frame(_mid, bg=T.BG)
        # Not packed here — see _show_step(2+)

        # Wizard progress bar (4 steps: URL → Navigation → Validation → Done)
        self._wiz_steps_frame = tk.Frame(self._wiz_section, bg=T.BG, padx=16, pady=8)
        self._wiz_steps_frame.pack(fill="x")
        self._wiz_step_labels = []
        for i, txt in enumerate(["URL", "Navigation", "Validation", "Done"], 1):
            f = tk.Frame(self._wiz_steps_frame, bg=T.BG)
            f.pack(side="left", padx=4)
            circle = tk.Label(f, text=str(i),
                              bg=T.SEL_BG, fg=T.FG,
                              font=("Segoe UI", 10, "bold"),
                              width=3, height=1, relief="flat")
            circle.pack()
            txt_lbl = tk.Label(f, text=txt, bg=T.BG, fg="#888",
                               font=("Segoe UI", 8))
            txt_lbl.pack(pady=(2, 0))
            self._wiz_step_labels.append((circle, txt_lbl))
            if i < 4:
                tk.Label(self._wiz_steps_frame, text="—" * 4,
                         bg=T.BG, fg="#444").pack(side="left", padx=2)

        # Wizard central zone — scrollable
        _wiz_scroll_outer = tk.Frame(self._wiz_section, bg=T.BG)
        _wiz_scroll_outer.pack(fill="both", expand=True)

        _wiz_vscroll = tk.Scrollbar(_wiz_scroll_outer, orient="vertical")
        _wiz_vscroll.pack(side="right", fill="y")

        self._wiz_canvas = tk.Canvas(
            _wiz_scroll_outer, bg=T.BG, bd=0,
            highlightthickness=0,
            yscrollcommand=_wiz_vscroll.set)
        self._wiz_canvas.pack(side="left", fill="both", expand=True)
        _wiz_vscroll.config(command=self._wiz_canvas.yview)

        self._wiz_main = tk.Frame(self._wiz_canvas, bg=T.BG, padx=20, pady=12)
        self._wiz_main_win = self._wiz_canvas.create_window(
            (0, 0), window=self._wiz_main, anchor="nw")

        def _wiz_inner_resize(e):
            self._wiz_canvas.configure(
                scrollregion=self._wiz_canvas.bbox("all"))
        self._wiz_main.bind("<Configure>", _wiz_inner_resize)

        def _wiz_canvas_resize(e):
            self._wiz_canvas.itemconfig(self._wiz_main_win, width=e.width)
        self._wiz_canvas.bind("<Configure>", _wiz_canvas_resize)

        def _wiz_mousewheel(e):
            self._wiz_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        self._wiz_canvas.bind("<MouseWheel>", _wiz_mousewheel)
        self._wiz_main.bind("<MouseWheel>", _wiz_mousewheel)

        # ── Show the OTA overview ─────────────────────────────────────────
        self._build_ota_cards()

    def refresh_on_show(self):
        """Tab built once at startup — re-syncs the OTA cards with the config
        of 🎯 My Hotel Monitoring (OTA Price Blocking) each time this tab
        becomes visible again, without restart.
        Does not touch the wizard if a calibration is in progress (step 2-5)."""
        if getattr(self, "_wiz_step", 1) != 1:
            return
        import logging
        try:
            self._build_ota_cards()
        except Exception:
            logging.exception("refresh_on_show (tab_calibration): OTA card rebuild failed")

    # ─────────────────────────────────────────────────────────────────────
    # WIZARD - navigation between steps
    # ─────────────────────────────────────────────────────────────────────

    def _show_step(self, n: int):
        """n=1 → back to overview (OTA cards).
           n=2..5 → shows the wizard (URL / Navigation / Validation / Done)."""
        self._wiz_step = n

        if n == 1:
            # Hide wizard, show the cards again
            self._wiz_section.pack_forget()
            # OUTER frame (Canvas + scrollbar): _cards_outer is inside the
            # Canvas and is no longer managed by pack().
            self._cards_scroll.pack(fill="both", expand=True, padx=12, pady=(6, 0))
            self._build_ota_cards()
            return

        # Hide the cards, show the wizard section
        self._cards_scroll.pack_forget()
        self._wiz_section.pack(fill="both", expand=True)

        # Progress bar: n=2→bar1 (URL), 3→bar2, 4→bar3, 5→bar4
        bar_n = n - 1
        for i, (circle, txt_lbl) in enumerate(self._wiz_step_labels, 1):
            if i < bar_n:
                circle.config(bg=T.GREEN, fg="white", text="✓")
                txt_lbl.config(fg=T.GREEN)
            elif i == bar_n:
                circle.config(bg=T.ACCENT, fg="white", text=str(i))
                txt_lbl.config(fg=T.ACCENT, font=("Segoe UI", 8, "bold"))
            else:
                circle.config(bg=T.SEL_BG, fg="#888", text=str(i))
                txt_lbl.config(fg="#888", font=("Segoe UI", 8))

        # Empty the central zone + reset scroll to top
        for w in self._wiz_main.winfo_children():
            w.destroy()
        try:
            self._wiz_canvas.yview_moveto(0)
        except Exception:
            pass

        # Call the step method
        {2: self._step_2_url,
         3: self._step_3_navigate,
         4: self._step_4_validate,
         5: self._step_5_done}[n]()

        # Propagate mouse wheel to all wizard children
        self.app.root.after(50, self._wiz_bind_scroll_all)

    def _wiz_bind_scroll_all(self):
        """Binds the mouse wheel to every wizard widget (recursive)."""
        def _bind(w):
            try:
                w.bind("<MouseWheel>",
                       lambda e: self._wiz_canvas.yview_scroll(
                           int(-1 * (e.delta / 120)), "units"))
            except Exception:
                pass
            for child in w.winfo_children():
                _bind(child)
        _bind(self._wiz_main)

    # ── Permanent OTA overview ────────────────────────────────────────────

    def _build_ota_cards(self):
        """Builds/refreshes the per-OTA cards in _cards_outer."""
        for w in self._cards_outer.winfo_children():
            w.destroy()
        # "Blank browser" checkboxes: one per OTA. Kept here otherwise Tkinter
        # loses the variable (garbage-collected) and the box unchecks itself.
        self._card_wipe_vars = {}

        lbl(self._cards_outer, tr_("Calibration by OTA"),
            bold=True, size=12).pack(anchor="w", pady=(0, 6))

        otas = self._get_ota_list()
        if not otas:
            warn = tk.Frame(self._cards_outer, bg="#3a2a00", padx=16, pady=12)
            warn.pack(fill="x")
            lbl(warn, tr_("⚠ No OTA active in OTA Price Blocking."),
                color=T.YELLOW, bold=True, size=10).pack(anchor="w")
            lbl(warn,
                "Go to OTA Price Blocking → configure your OTA URLs → come back here.",
                color="#ccc", size=9).pack(anchor="w", pady=(4, 0))
            return

        for oid, name in otas:
            profile = self._get_profile(oid)
            n_prices = len(profile.get("prices_found", {}))
            n_learn  = sum(1 for p in profile.get("prices_learned", {}).values()
                           if p.get("count", 0) >= 3)
            cal_at   = profile.get("calibrated_at", "")
            has_url  = bool(profile.get("good_url"))
            cur      = profile.get("source_currency", "")

            border = T.GREEN if has_url else T.SEL_BG
            card = tk.Frame(self._cards_outer, bg=T.ENTRY_BG, padx=14, pady=10,
                            highlightthickness=1, highlightbackground=border)
            card.pack(fill="x", pady=3)

            left = tk.Frame(card, bg=T.ENTRY_BG)
            left.pack(side="left", fill="x", expand=True)

            lbl(left, name, bold=True, size=11, bg=T.ENTRY_BG).pack(anchor="w")

            if has_url:
                status = f"✅  Calibrated  —  {n_prices} room(s)  ·  {n_learn} learned"
                sc     = T.GREEN
            else:
                status = "⚠  Not calibrated yet"
                sc     = T.YELLOW
            lbl(left, status, color=sc, size=9, bg=T.ENTRY_BG).pack(anchor="w")

            info_parts = []
            if cal_at:
                info_parts.append(f"📅 {fmt_dt(cal_at)}")
            if cur:
                info_parts.append(f"💱 {cur}")
            if info_parts:
                lbl(left, "   ".join(info_parts),
                    color="#888", size=8, bg=T.ENTRY_BG).pack(anchor="w")

            # ── Browsing memory of the automatic reading ──────────────────
            # Setting specific to THIS OTA: written to its own file
            # (data\calibration_data_<ota>.json → scan_options), never into a
            # common setting. Two OTAs can thus be set differently without
            # interfering.
            _wipe_v = tk.BooleanVar(
                value=bool((profile.get("scan_options") or {})
                           .get("wipe_profile", False)))
            self._card_wipe_vars[oid] = _wipe_v
            tk.Checkbutton(
                left,
                text=tr_("🧹 Blank browser on every automatic reading"),
                variable=_wipe_v,
                command=lambda _o=oid, _v=_wipe_v: self._save_scan_wipe(_o, _v),
                bg=T.ENTRY_BG, fg=T.FG, selectcolor=T.BG,
                activebackground=T.ENTRY_BG, activeforeground=T.FG,
                font=("Segoe UI", 9)).pack(anchor="w", pady=(6, 0))
            lbl(left,
                tr_("Unchecked (recommended): the site recognizes a visitor who has already visited and requests an anti-robot test much less often. Checked: the site sees an unknown person at each reading — only useful if this OTA displays different prices to new visitors."),
                color="#888", size=8, bg=T.ENTRY_BG,
                wraplength=560, justify="left").pack(anchor="w")

            btn_txt   = "🔄 Recalibrate" if has_url else "▶ Calibrate"
            btn_color = T.ORANGE if has_url else T.ACCENT
            btn(card, btn_txt,
                lambda _o=oid, _n=name: self._start_calibration(_o, _n),
                color=btn_color, width=14).pack(side="right", padx=(12, 0))

        # Mouse wheel on the cards themselves: without this recursive walk,
        # the wheel only works above the empty Canvas background — i.e.
        # nowhere once the list is filled (same principle as
        # _wiz_bind_scroll_all for the wizard).
        self._cards_bind_scroll_all()

    def _cards_bind_scroll_all(self):
        """Binds the wheel to every OTA card and its content."""
        _wheel = getattr(self, "_cards_mousewheel", None)
        if _wheel is None:
            return

        def _bind(w):
            try:
                w.bind("<MouseWheel>", _wheel)
            except Exception:
                pass
            for child in w.winfo_children():
                _bind(child)
        _bind(self._cards_outer)

    def _start_calibration(self, oid: str, name: str):
        """Starts calibration for the OTA selected from the cards."""
        self._wiz_ota              = (oid, name)
        self._wiz_url              = self._get_ota_url(oid)
        self._wiz_actions          = []
        self._wiz_urls_visited     = []
        self._wiz_good_url         = ""
        # 2026-08-10: last URL where prices were visible DURING navigation.
        # Expedia switches to Hotel-Search when dates are touched → page.url
        # at "I'm there" click time is no longer the page with prices. We
        # memorize the URL while it contains prices, and use it as good_url
        # if page.url drifted.
        self._wiz_last_url_with_prices = ""
        self._wiz_prices           = {}
        self._wiz_raw_prices       = []
        self._wiz_validations      = {}
        self._wiz_detected_cur     = ""
        self._wiz_agoda_room_grid  = {}   # Agoda room-grid XHR captured live
        self._wiz_net_captures     = []   # [(url_path, [numbers]), …] captured network
        self._wiz_price_endpoint   = ""   # URL pattern of the learned price endpoint
        self._wiz_mode             = "desktop"   # "desktop" or "mobile"        # Manual calibration results (phase 2) — reset HERE, not only
        # written in `_apply`. Without this, calibrating an OTA without going
        # through phase 2 re-recorded the anchors of the OTA calibrated just
        # before: anchors from ANOTHER site, hence wrong. Vital for position
        # anchors, which make no sense outside their page.
        self._wiz_manual_css_sel      = ""
        self._wiz_manual_attrs        = {}
        self._wiz_manual_field_sels   = {}
        self._wiz_manual_price_anchors = {}
        self._wiz_room_aliases        = {}
        self._log(f"▶ Calibration: {name}", "info")
        self._show_step(2)

    # ── Step 2: URL ───────────────────────────────────────────────────────

    def _step_2_url(self):
        m = self._wiz_main
        oid, name = self._wiz_ota
        lbl(m, tr_("URL of your file {name}").format(name=name),
            bold=True, size=14).pack(anchor="w", pady=(0, 8))
        lbl(m, tr_("Check or modify the URL before starting navigation."),
            color="#888", size=9).pack(anchor="w", pady=(0, 16))

        self._wiz_url_var = tk.StringVar(value=self._wiz_url)
        url_frame = tk.Frame(m, bg=T.ENTRY_BG, padx=12, pady=10)
        url_frame.pack(fill="x")
        lbl(url_frame, tr_("URL:"), bold=True, size=9).pack(anchor="w", pady=(0, 4))
        tk.Entry(url_frame, textvariable=self._wiz_url_var,
                 bg=T.BG, fg=T.FG, relief="flat",
                 font=("Consolas", 9)).pack(fill="x", ipady=4)

        # ── Version to calibrate: Desktop or Mobile ───────────
        # Mobile reuses the desktop URL/currency/endpoint; mobile is only
        # (re)calibrated where it is useful (mobile actions/CSS).
        mode_frame = tk.Frame(m, bg=T.BG)
        mode_frame.pack(fill="x", pady=(12, 0))
        lbl(mode_frame, tr_("Version to calibrate:"), bold=True, size=9).pack(
            side="left", padx=(0, 10))
        self._wiz_mode_var = tk.StringVar(value=getattr(self, "_wiz_mode", "desktop"))
        for _val, _txt in (("desktop", tr_("🖥️ Desktop")),
                           ("mobile", tr_("📱Mobile"))):
            tk.Radiobutton(
                mode_frame, text=_txt, value=_val,
                variable=self._wiz_mode_var, bg=T.BG, fg=T.FG,
                selectcolor=T.ENTRY_BG, activebackground=T.BG,
                activeforeground=T.FG, font=("Segoe UI", 9)).pack(
                    side="left", padx=(0, 8))

        if not self._wiz_url:
            warn = tk.Frame(m, bg="#3a2a00", padx=12, pady=8)
            warn.pack(fill="x", pady=(12, 0))
            lbl(warn, tr_("⚠ No URL configured for {name}").format(name=name),
                color=T.YELLOW, bold=True).pack(anchor="w")
            lbl(warn,
                tr_("Go to OTA Price Block → add the URL of {name} → come back here.").format(name=name),
                color="#ccc", size=9).pack(anchor="w", pady=(2, 0))

        # Buttons
        bbar = tk.Frame(m, bg=T.BG)
        bbar.pack(fill="x", pady=(24, 0))
        btn(bbar, tr_("← Previous"), lambda: self._show_step(1),
            color=T.SEL_BG, width=14).pack(side="left")
        btn(bbar, tr_("Next →"), self._step2_next,
            color=T.ACCENT, width=18).pack(side="right")

    def _step2_next(self):
        url = self._wiz_url_var.get().strip()
        if not url or not url.startswith("http"):
            messagebox.showwarning(tr_("Calibration"),
                tr_("Invalid URL. It must start with http:// or https://"),
                parent=self.app.root)
            return
        # Remember the chosen version (desktop / mobile)
        try:
            self._wiz_mode = self._wiz_mode_var.get()
        except Exception:
            self._wiz_mode = "desktop"
        # ── Google Hotels: force .com domain + currency + language + country ──
        # D11 REGRESSION fixed on 2026-07-22 (audit G4). D11 says the fix had
        # been applied "in tab_calibration.py (3 places) and
        # scraping/scraping.py"; only the scraping.py one survived.
        # Without it, a country-domain URL (google.to, google.co.in…) is
        # calibrated WITHOUT curr/hl/gl: Google then displays prices in the
        # local currency — exactly the D5 symptom (0 room found or absurd
        # prices at calibration), while the SCAN did fix the URL. Calibration
        # and scan thus worked on two different pages.
        try:
            import re as _re_g
            if _re_g.search(r"google\.[a-z.]{2,6}/", url, _re_g.IGNORECASE) \
                    and "/travel" in url.lower():
                _hcur = self.app.config.get("hotel_currency", "INR")
                url = _re_g.sub(r"google\.[a-z.]{2,6}/", "google.com/", url,
                                flags=_re_g.IGNORECASE)
                _sep = "&" if "?" in url else "?"
                if "curr=" not in url.lower():
                    url += f"{_sep}curr={_hcur}"; _sep = "&"
                if "hl=" not in url.lower():
                    url += f"{_sep}hl=en"; _sep = "&"
                if "gl=" not in url.lower():
                    url += f"{_sep}gl=in"
        except Exception:
            logging.exception("Calibration: Google URL normalization failed")

        # Inject the dates according to the selected offset
        try:
            from core.utils import inject_scan_dates
            _offset = int(self._wiz_date_offset_v.get())
            url = inject_scan_dates(url, _offset)
            # Save the preference into config
            self.app.config.setdefault("visual_scan", {})["date_offset"] = _offset
            from core import config as _cfg_save
            _cfg_save.save(self.app.config)
        except Exception:
            pass
        self._wiz_url = url
        self._show_step(3)
        # Launch Chrome after display
        self.app.root.after(300, self._wiz_launch_chrome)

    # ── Step 3: Navigation ────────────────────────────────────────────────

    def _step_3_navigate(self):
        m = self._wiz_main
        oid, name = self._wiz_ota
        lbl(m, tr_("Navigate to the pricing page — {name}").format(name=name),
            bold=True, size=14).pack(anchor="w", pady=(0, 8))
        lbl(m, tr_("Chrome will open. Follow these steps:"),
            color="#888", size=9).pack(anchor="w", pady=(0, 16))

        # Instructions
        steps = [
            "🌐  Chrome will open with your hotel's page",
            "👀  If a popup appears → close it",
            "📅  Select dates if asked",
            "🛏️  Navigate to the room list with their prices",
            "✅  When you clearly see the prices → click \"I'm there!\"",
        ]
        for s in steps:
            frow = tk.Frame(m, bg=T.ENTRY_BG, padx=12, pady=6)
            frow.pack(fill="x", pady=2)
            lbl(frow, s, size=10).pack(anchor="w")

        # Status
        self._wiz_status_lbl = tk.Label(
            m, text=tr_("⏳ Starting Chrome…"),
            bg=T.BG, fg=T.YELLOW,
            font=("Segoe UI", 10, "italic"))
        self._wiz_status_lbl.pack(anchor="w", pady=(16, 8))

        # Big "I'm there" button
        big = tk.Frame(m, bg=T.BG)
        big.pack(fill="x", pady=(8, 0))
        self._wiz_btn_here = tk.Button(
            big, text=tr_("✅ I'm there! — Visible prices"),
            command=self._step3_here,
            bg="#40a040", fg="white",
            font=("Segoe UI", 13, "bold"),
            relief="flat", cursor="hand2",
            padx=20, pady=14, state="disabled",
            disabledforeground="#888")
        self._wiz_btn_here.pack(fill="x")

        # Secondary buttons
        bbar = tk.Frame(m, bg=T.BG)
        bbar.pack(fill="x", pady=(12, 0))
        btn(bbar, tr_("← Previous"), self._step3_back,
            color=T.SEL_BG, width=14).pack(side="left")
        btn(bbar, tr_("🧹 New profile"), self._wiz_reset_profile,
            color=T.YELLOW, width=16).pack(side="left", padx=(8, 0))
        btn(bbar, tr_("⏹ Cancel"), self._step3_cancel,
            color=T.RED, width=14).pack(side="right")
        # Anti-robot unblock — button on its OWN line: added inside "bbar",
        # it would have pushed "⏹ Cancel" (packed right) out of the window
        # on small widths.
        bbar2 = tk.Frame(m, bg=T.BG)
        bbar2.pack(fill="x", pady=(8, 0))
        btn(bbar2, tr_("🔓 Unblock the site (CAPTCHA)"), self._wiz_unlock_site,
            color=T.ORANGE, width=30).pack(side="left")
        # Last-resort fallback, on its own line for the same reason as bbar2.
        bbar3 = tk.Frame(m, bg=T.BG)
        bbar3.pack(fill="x", pady=(8, 0))
        btn(bbar3, tr_("🖥 Go through my browser"), self._wiz_real_browser,
            color=T.ACCENT, width=30).pack(side="left")
        lbl(m, tr_("ℹ The software will automatically try 3 times if the page is not displayed correctly. If it remains empty despite this, the site may have spotted this Chrome profile as a robot - click “🧹 New profile” to leave with a blank profile, like a new visitor."),
            color="#888888", size=8).pack(anchor="w", pady=(6, 0))
        lbl(m, tr_("ℹ If the site requests an anti-robot test (CAPTCHA) and the page remains blocked even after having resolved it: click “🔓 Unblock site”. A regular Chrome window will open to resolve it — that's the only way the site will accept the response. To be repeated only when the blockage returns."),
            color="#888888", size=8).pack(anchor="w", pady=(2, 0))
        lbl(m, tr_("ℹ If even “🔓 Unblock the site” is not enough: click “🖥 Go through my browser”. The page opens in YOUR usual browser, with your personal profile — the one that passes anti-robot tests. The software then simply photographs the screen and reads the prices. Please note: this image reading does not memorize any page marks, so subsequent automatic readings will not be more reliable — this is a troubleshooting, not a real calibration."),
            color="#888888", size=8).pack(anchor="w", pady=(2, 0))

    def _step3_back(self):
        self._wiz_close_browser()
        self._show_step(2)

    def _step3_cancel(self):
        self._wiz_close_browser()
        self._show_step(1)   # back to OTA cards

    def _wiz_launch_chrome(self):
        """Opens visible Chrome + recorder JS in a thread."""
        self._wiz_actions      = []
        self._wiz_urls_visited = []
        self._wiz_nav_stop     = threading.Event()
        self._wiz_browser_closed = threading.Event()
        # Distinguishes "I'm there" (wanted extraction) from a _wiz_nav_stop
        # signal for any other reason (Previous/Cancel/New profile) — without
        # this flag, those 3 buttons also triggered a price extraction on the
        # page being closed.
        self._wiz_confirmed    = False
        threading.Thread(target=self._wiz_chrome_thread, daemon=True).start()

    _RECORDER_JS = """
(function(){
    if(window.__calib_rec)return;
    window.__calib_rec=true;
    window.__calib_actions=window.__calib_actions||[];
    window.__calib_new_profile_requested=false;
    function _sel(el){
        if(!el||el===document||el===window)return'';
        if(el.id)return'#'+el.id;
        var attrs=['data-testid','data-cy','data-selenium','aria-label','name','role','type'];
        for(var i=0;i<attrs.length;i++){
            var v=el.getAttribute(attrs[i]);
            if(v)return el.tagName.toLowerCase()+'['+attrs[i]+'="'+v.replace(/"/g,'\\"')+'"]';
        }
        var cls=el.className;
        if(cls&&typeof cls==='string'){
            var c=cls.trim().split(/\\s+/)[0];
            if(c)return el.tagName.toLowerCase()+'.'+c;
        }
        return el.tagName.toLowerCase();
    }
    document.addEventListener('click',function(e){
        window.__calib_actions.push({t:'click',s:_sel(e.target),
            x:Math.round(e.clientX),y:Math.round(e.clientY),
            u:location.href,ts:Date.now()});
    },true);
    document.addEventListener('input',function(e){
        var el=e.target;
        if(el.value!==undefined)
            window.__calib_actions.push({t:'fill',s:_sel(el),v:el.value,
                u:location.href,ts:Date.now()});
    },true);
    function _mountNewProfileBtn(){
        if(document.getElementById('__calib_np_btn'))return;
        var b=document.createElement('button');
        b.id='__calib_np_btn';
        b.type='button';
        b.textContent='🧹 New profile';
        b.style.cssText='position:fixed;top:8px;right:8px;z-index:2147483647;'
            +'padding:6px 10px;font:12px sans-serif;background:#fff3cd;'
            +'color:#664d03;border:1px solid #ffe69c;border-radius:4px;'
            +'cursor:pointer;opacity:0.55;box-shadow:0 1px 3px rgba(0,0,0,.3);';
        b.onmouseenter=function(){if(!b.disabled)b.style.opacity='1';};
        b.onmouseleave=function(){if(!b.disabled)b.style.opacity='0.55';};
        b.onclick=function(){
            window.__calib_new_profile_requested=true;
            b.disabled=true;
            b.textContent='⏳ New profile…';
            b.style.opacity='1';
            b.style.cursor='default';
        };
        (document.body||document.documentElement).appendChild(b);
    }
    if(document.body)_mountNewProfileBtn();
    else document.addEventListener('DOMContentLoaded',_mountNewProfileBtn);
})();
"""

    def _wiz_chrome_thread(self):
        try:
            from scraping.browser_driver import sync_playwright
            from scraping.chrome_manager import (
                launch_context, apply_stealth, wipe_profile)
            from scraping.scraping import (
                ota_launch_quirks, calib_launch_recipes, CALIB_PAGE_MIN_CHARS)
        except ImportError as e:
            self._set_status(f"❌ Playwright not installed: {e}", T.RED)
            self._log(f"❌ {e}", "err")
            return

        _quirks = ota_launch_quirks(self._wiz_ota[0] if self._wiz_ota else None)
        _prof_id = self._calib_profile_id()

        # Profile wipe: no longer systematic, but AT THE OTA'S REQUEST.
        #
        #  • By default: the profile is NOT wiped. Each OTA now has its own
        #    (see _calib_profile_id), so no more mixing between them, and the
        #    accumulated cookies avoid presenting ourselves as an unknown
        #    visitor every time.
        #  • Exception: OTAs flagged "calib_fresh_profile" in
        #    _OTA_LAUNCH_QUIRKS (scraping.py) start from a blank profile at
        #    EVERY opening. MakeMyTrip is in that case: it flags the browsing
        #    memory as already seen and then serves an empty page (measured —
        #    see the comment in scraping.py).
        #
        # The "🧹 New profile" button remains available to wipe on demand on
        # any OTA.
        if _quirks.get("calib_fresh_profile"):
            wipe_profile(_prof_id)
            self._log("🧹 Browsing profile wiped clean "
                      "(required by this OTA)", "info")

        # Windows pythonw workaround: sys.stderr is None → Playwright passes
        # stderr=None to the Node.js subprocess → null handle → Node.js crash.
        # Fix: AllocConsole (hidden console) + open sys.stderr on CONOUT$.
        try:
            import sys as _sys_pw
            if _sys_pw.platform == "win32" and _sys_pw.stderr is None:
                import ctypes as _ct
                _k32 = _ct.windll.kernel32
                if _k32.GetConsoleWindow() == 0:
                    _k32.AllocConsole()
                    _ch = _k32.GetConsoleWindow()
                    if _ch:
                        _ct.windll.user32.ShowWindow(_ch, 0)
                try:
                    _sys_pw.stderr = open("CONOUT$", "w")
                except Exception:
                    import os as _os
                    _sys_pw.stderr = open(_os.devnull, "w")
        except Exception:
            pass

        _is_mobile_calib = getattr(self, "_wiz_mode", "desktop") == "mobile"
        try:
            with sync_playwright() as pw:
                def _open_ctx_page():
                    """Opens a new context + page + recorder + network
                    listeners. Isolated from the try/finally block below
                    (close guaranteed even if the body crashes)."""
                    if _is_mobile_calib:
                        # MOBILE calibration: true phone emulation.
                        # Three settings are needed TOGETHER — with a single one
                        # missing, the site returns its desktop version squeezed
                        # into a corner of the window (unreadable page, elements
                        # impossible to select):
                        #  • keep_user_agent: without it the launcher REMOVES the
                        #    phone identity (wanted for scans) and the site thinks
                        #    it talks to a computer;
                        #  • is_mobile / has_touch: touch screen declared — this is
                        #    what triggers the site's phone layout;
                        #  • --window-size: the Chrome window itself at phone size,
                        #    otherwise the page only occupies a quarter of the
                        #    window (390 px of page in a 1366 px window).
                        _MOB_UA_C = ("Mozilla/5.0 (Linux; Android 14; SM-S918B) "
                                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                                     "Chrome/120.0.0.0 Mobile Safari/537.36")
                        try:
                            _ctx, _ = launch_context(
                                pw, _prof_id, headless=False,
                                keep_user_agent=True,
                                extra_args=["--window-size=400,980"]
                                           + _quirks.get("extra_args", []),
                                user_agent=_MOB_UA_C,
                                viewport={"width": 390, "height": 844},
                                is_mobile=True, has_touch=True)
                        except Exception as _emob:
                            # Safety net: if one of these options is rejected (older
                            # Playwright version), fall back to the old behaviour
                            # rather than blocking calibration.
                            self._log(f"⚠ Phone emulation unavailable ({_emob}) "
                                      f"— plain display", "error")
                            _ctx, _ = launch_context(pw, _prof_id, headless=False,
                                                     extra_args=_quirks.get("extra_args"),
                                                     user_agent=_MOB_UA_C,
                                                     viewport={"width": 390, "height": 844})
                    else:
                        _ctx, _ = launch_context(pw, _prof_id, headless=False,
                                                 extra_args=_quirks.get("extra_args"),
                                                 viewport={"width": 1366, "height": 768})
                    _pg = _ctx.new_page()
                    apply_stealth(_pg)
                    _ctx.add_init_script(self._RECORDER_JS)

                    # ── Intercept Agoda room-grid XHR ────────────────────────
                    if self._wiz_ota and self._wiz_ota[0] == "agoda":
                        def _on_agoda_resp(resp):
                            try:
                                if ("room-grid" in resp.url
                                        or "BelowFoldParams/GetPricing" in resp.url):
                                    d = resp.json()
                                    if isinstance(d, dict) and d.get("rooms"):
                                        self._wiz_agoda_room_grid = d
                                        n = len(d["rooms"])
                                        self._log(
                                            f"📡 Agoda XHR captured: {n} room(s)", "price")
                            except Exception:
                                pass
                        _pg.on("response", _on_agoda_resp)

                    # ── Generic network capture (ALL OTAs) ────────────────────
                    # Additive: does not affect the Agoda interception above.
                    # We record the numbers of each JSON response; at validation
                    # step we will spot the one containing the displayed prices
                    # → we derive the price endpoint to listen to again at scan.
                    def _on_net_resp(resp):
                        try:
                            if len(self._wiz_net_captures) >= 80:
                                return
                            _ct = (resp.headers or {}).get("content-type", "")
                            if "json" not in _ct.lower():
                                return
                            _nums = _json_numbers(resp.json())
                            if _nums:
                                from urllib.parse import urlparse as _up
                                self._wiz_net_captures.append(
                                    (_up(resp.url).path, _nums))
                        except Exception:
                            pass
                    _pg.on("response", _on_net_resp)
                    return _ctx, _pg

                # Zombie Chrome: guarantee ctx.close() even if the body crashes
                # (page crash, timeout, closed window) — otherwise chrome.exe
                # stays open indefinitely in the background.
                try:
                    # ── Opening, with a recipe cascade for unknown OTAs ──────
                    #
                    # calib_launch_recipes() returns an EMPTY list as soon as the
                    # OTA is known to the code (Agoda, MakeMyTrip, Expedia,
                    # Booking, Goibibo) or a recipe has already been found for
                    # it: the loop then makes a single pass with the usual
                    # settings and behaviour is identical to before, line for
                    # line.
                    #
                    # Otherwise the recipes are tried in order, the 1st being
                    # "no setting" (= the old behaviour). The first one that
                    # fills the page is kept. No risk of repeating the old
                    # heuristic removed below: we never RELOAD a page that did
                    # display — we only relaunch when the page stayed almost
                    # empty (measured threshold, see CALIB_PAGE_MIN_CHARS), and
                    # the user has not done anything yet since "I'm there" is
                    # disabled.
                    _oid_now  = (self._wiz_ota[0] if self._wiz_ota else "") or ""
                    _recipes  = calib_launch_recipes(_oid_now)
                    _attempts = _recipes or [("", dict(_quirks))]
                    ctx = page = None
                    for _ri, (_rname, _rq) in enumerate(_attempts):
                        _quirks = dict(_rq)
                        _last = (_ri == len(_attempts) - 1)
                        if _recipes:
                            self._log(f"🔎 Attempt {_ri + 1}/{len(_attempts)} — "
                                      f"{_rname}", "info")
                            if _quirks.get("calib_fresh_profile"):
                                wipe_profile(_prof_id)
                                self._log("🧹 Browsing profile wiped clean",
                                          "info")
                        ctx, page = _open_ctx_page()
                        self._wiz_browser_ctx  = ctx
                        self._wiz_browser_page = page
                        try:
                            # 2026-08-10: if a previous calibration stored a
                            # good_url (the page where prices are visible), use
                            # it as the start URL instead of _wiz_url (the source
                            # URL, often a search). Otherwise recalibrating forced
                            # redoing everything (CAPTCHA, hotel click, dates…)
                            # because _wiz_url restarted from the search page.
                            _start_url = self._wiz_url
                            try:
                                _existing_good = (self._get_profile(_oid_now)
                                                  .get("good_url", "")) or ""
                                if _existing_good and _existing_good.startswith("http"):
                                    _start_url = _existing_good
                            except Exception:
                                pass
                            page.goto(
                                _start_url,
                                wait_until=_quirks.get("goto_wait_until",
                                                       "domcontentloaded"),
                                timeout=_quirks.get("goto_timeout_ms", 30000))
                        except Exception as _e_goto:
                            if not _recipes or _last:
                                raise
                            self._log(f"⚠ {_rname}: {_e_goto}", "err")
                            try:
                                ctx.close()
                            except Exception:
                                pass
                            continue
                        # Give the JS rendering (SPA-like site) time to run
                        # before enabling "I'm there" — `domcontentloaded`
                        # fires BEFORE React/Angular has displayed anything.
                        try:
                            page.wait_for_timeout(3000)
                        except Exception:
                            pass
                        if not _recipes:
                            break
                        try:
                            _n_chars = len(page.evaluate(
                                "() => (document.body && document.body.innerText)"
                                " || ''") or "")
                        except Exception:
                            _n_chars = 0
                        if _n_chars >= CALIB_PAGE_MIN_CHARS:
                            self._log(f"✅ Recipe retained: {_rname} "
                                      f"({_n_chars} characters read on the page)",
                                      "ok")
                            self._wiz_launch_quirks = {**_rq, "recipe": _rname}
                            self.app.root.after(
                                0, lambda o=_oid_now: self._save_launch_quirks(o))
                            break
                        if _last:
                            # No recipe filled the page: keep the last one open
                            # rather than closing everything — the user can still
                            # navigate by hand and use the "🧹 New profile"
                            # button. Nothing is saved: the search will be redone
                            # at the next attempt rather than freezing a bad
                            # setting.
                            self._log("⚠ No recipe filled the page "
                                      f"({_n_chars} characters). Navigate by "
                                      "hand, or retry with \"🧹 New profile\".",
                                      "err")
                            break
                        self._log(f"↻ Page stayed empty ({_n_chars} characters) — "
                                  "next recipe", "warn")
                        try:
                            ctx.close()
                        except Exception:
                            pass
                    try:
                        page.evaluate(self._RECORDER_JS)
                    except Exception:
                        pass

                    # No automatic retry here: the old heuristic (text length +
                    # blocking keywords) also fired on good pages (e.g. Google
                    # Hotels with prices already displayed on first load) and
                    # the forced reload then lost the correct state. The choice
                    # now belongs to the user, via the "🧹 New profile" button
                    # injected on the page itself (see _mountNewProfileBtn in
                    # _RECORDER_JS) or the equivalent panel button — both call
                    # _wiz_reset_profile (the on-page click is detected in the
                    # polling loop below).

                    def _on_nav(url):
                        if url and url not in self._wiz_urls_visited:
                            self._wiz_urls_visited.append(url)

                    page.on("framenavigated",
                            lambda f: _on_nav(f.url) if f == page.main_frame else None)
                    _on_nav(self._wiz_url)

                    # Enable the "I'm there" button only once the page is loaded
                    # (and the retry above finished) — enabling it before the
                    # goto let the user click during a silent background
                    # reload.
                    self.app.root.after(0, lambda: self._wiz_btn_here.config(state="normal"))
                    self._set_status("✅ Chrome open — navigate to the prices",
                                     T.GREEN)

                    # Loop: collect actions until stop
                    while not self._wiz_nav_stop.is_set():
                        try:
                            if page.is_closed():
                                break
                            acts = page.evaluate(
                                "()=>{var a=(window.__calib_actions||[]).slice();"
                                "window.__calib_actions=[];return a;}")
                            if acts:
                                self._wiz_actions.extend(acts)
                            if page.evaluate(
                                    "()=>{var r=!!window.__calib_new_profile_requested;"
                                    "window.__calib_new_profile_requested=false;return r;}"):
                                # "🧹 New profile" button clicked directly on
                                # the page — same action as the panel button,
                                # run on the Tk thread (Playwright sync forbids
                                # closing ctx from that thread).
                                self.app.root.after(0, self._wiz_reset_profile)
                                break
                            # 2026-08-10: memorize the URL while the page
                            # contains prices. Expedia switches to Hotel-Search
                            # when dates are touched → page.url is no longer the
                            # page with prices at "I'm there" click time.
                            # This URL will serve as fallback good_url (see
                            # below, after the loop).
                            try:
                                _cur_url = page.url
                                _got = self._wiz_extract_prices(page)
                                if _got and _cur_url:
                                    self._wiz_last_url_with_prices = _cur_url
                            except Exception:
                                pass
                        except Exception:
                            # Navigation: the JS context was destroyed (e.g. room
                            # category change) — re-inject otherwise later clicks
                            # are never recorded again.
                            try:
                                page.evaluate(self._RECORDER_JS)
                            except Exception:
                                pass
                        self._wiz_nav_stop.wait(0.5)

                    # User clicked "I'm there" → extract prices + currency BEFORE
                    # closing (self._wiz_confirmed distinguishes this case from
                    # Previous/Cancel/New profile, which set the same
                    # _wiz_nav_stop)
                    if self._wiz_confirmed and not page.is_closed():
                        try:
                            # 2026-08-10: good_url first = the last URL where
                            # prices WERE visible (memorized during the loop).
                            # Fall back to page.url only if nothing was memorized
                            # (another OTA without the Expedia bug, or the user
                            # did not touch the dates).
                            # Reason: on Expedia, clicking the date selector
                            # switches to Hotel-Search → page.url at "I'm there"
                            # click time is no longer the price page →
                            # recalibration reopened the search.
                            _prices_now = self._wiz_extract_prices(page)
                            if _prices_now:
                                # The current page still has prices: URL OK.
                                self._wiz_good_url = page.url
                            elif self._wiz_last_url_with_prices:
                                # The page drifted (Expedia→search): use the last
                                # URL where prices were visible.
                                self._wiz_good_url = self._wiz_last_url_with_prices
                                log and log.info(
                                    "[Calibration] good_url corrected: page.url "
                                    "drifted (%s…), using the last URL with "
                                    "prices (%s…)",
                                    (page.url or "")[:60],
                                    self._wiz_good_url[:60])
                            else:
                                self._wiz_good_url = page.url
                            page_text = page.evaluate("() => document.body.innerText") or ""
                            self._wiz_detected_cur = self._detect_currency_from_text(page_text)
                            if _prices_now is None:
                                self._wiz_extract_prices(page)
                            # Reading anchors deduced from the page itself
                            # (see _wiz_auto_detect_selectors) — serves as a
                            # safety net when the OTA is unknown and no anchor
                            # was designated by hand.
                            self._wiz_auto_detect_selectors(page)
                            # Anti-robot pass: at this exact instant the price
                            # page is displayed, so the session is not blocked —
                            # it is the only moment we are certain the cookies
                            # are good. Kept for the automatic price reading,
                            # which runs unattended and cannot solve a challenge
                            # (see chrome_manager.save_site_pass).
                            try:
                                from scraping.chrome_manager import save_site_pass
                                _oid_pass = (self._wiz_ota[0]
                                             if self._wiz_ota else "")
                                if save_site_pass(_oid_pass, ctx.cookies()):
                                    self._log(
                                        "🔓 Site pass saved — it will also serve "
                                        "the automatic price "
                                        "reading", "ok")
                            except Exception as _e_pass:
                                self._log(f"⚠ Site pass not saved: "
                                          f"{_e_pass}", "warn")
                        except Exception as e:
                            self._log(f"⚠ Extraction: {e}", "warn")
                finally:
                    try:
                        ctx.close()
                    except Exception:
                        pass
                    self._wiz_browser_ctx = None
                    self._wiz_browser_page = None
                    if self._wiz_browser_closed:
                        self._wiz_browser_closed.set()
        except AttributeError as e:
            if "_playwright" in str(e):
                # Node.js driver crashed (libuv assert process_title)
                # → reinstall Playwright or relaunch from a terminal
                self._set_status(
                    "❌ Playwright driver crash (Windows). "
                    "Reinstall: python -m playwright install chromium",
                    T.RED)
                self._log("❌ Playwright driver crash: " + str(e), "err")
            else:
                self._set_status(f"❌ Chrome error: {e}", T.RED)
                self._log(f"❌ {e}", "err")
            return
        except Exception as e:
            self._set_status(f"❌ Chrome error: {e}", T.RED)
            self._log(f"❌ {e}", "err")
            return

        # Move to step 4 (only if this was a real "I'm there" —
        # otherwise Previous/Cancel/New profile would jump to step 4
        # with empty data while another relaunch is running)
        if self._wiz_confirmed and self._wiz_step == 3:
            self.app.root.after(100, lambda: self._show_step(4))

    def _step3_here(self):
        """The user says the prices are visible → stop the recorder."""
        try:
            self._wiz_btn_here.config(state="disabled", text=tr_("⏳ Extraction…"))
        except Exception:
            pass
        self._set_status("⏳ Extracting prices…", T.ACCENT)
        self._wiz_confirmed = True
        if self._wiz_nav_stop:
            self._wiz_nav_stop.set()

    def _wiz_extract_prices(self, page):
        """Extracts prices in 3 levels: OTA CSS → generic CSS → full-page regex.

        The full-page fallback is ESSENTIAL: OTA CSS classes change constantly,
        so fixed selectors often fail. Without this fallback, calibration found
        no prices at all (regression vs source software).
        """
        import re as _re
        from scraping.scraping import _MULTI_CURRENCY_RE, money_groups
        # Number displayed in a price cell, thousands separators already
        # removed by the caller: "18", "1234", "1234.50". No minimum digit
        # count — OTAs displaying in dollars/euros often show two-digit
        # amounts ("$ 18"). Validity is checked after conversion, by the
        # price range, not by the number length.
        _NUM_RE = r'\d+(?:\.\d+)?'
        try:
            from core.utils import get_inr_rates
            rates = get_inr_rates(self.app.config)
        except Exception:
            from scraping.scraping import _RATES_TO_INR as rates

        oid = self._wiz_ota[0]
        src_cur = self._wiz_detected_cur or \
                  self._get_profile(oid).get("source_currency") or \
                  self.app.config.get("hotel_currency", "INR")
        src_rate = rates.get(src_cur.upper(), rates.get(src_cur, 1.0)) or 1.0

        prices_raw = []
        seen = set()

        def _push(v_inr):
            try:
                v_inr = int(round(v_inr))
            except (ValueError, TypeError):
                return
            if 300 <= v_inr <= 500_000 and v_inr not in seen:
                seen.add(v_inr)
                prices_raw.append(v_inr)

        # Promo/discount banners ("Get $5 Off!", "Deal Applied…") — sometimes
        # match the generic price/rate/amount CSS selectors, or linger in the
        # full page text (level 3), while they are not room prices (seen on
        # MakeMyTrip: the "price" CSS classes no longer relate to the real
        # displayed price — only these promo banners still match).
        _PROMO_RE = _re.compile(r'\b(off|deal|discount|save|coupon|promo)\b',
                                 _re.IGNORECASE)

        def _convert_in_order(txt):
            """Prices WITH currency symbol, text order preserved, converted to INR.
            Returns True if at least one price found. (order = key to correct mapping)"""
            hit = False
            for m in _MULTI_CURRENCY_RE.finditer(txt):
                # Local context around the match (not the whole txt: on the
                # full-page fallback, level 3, a single "Off" elsewhere on the
                # page must not invalidate the real prices found further on).
                ctx = txt[max(0, m.start() - 30): m.end() + 20]
                if _PROMO_RE.search(ctx):
                    continue
                # money_groups: the four possible spellings of an amount
                # (₹5,000 / INR 5,000 / 5,000 INR / 5,000 ₹) are read at the
                # same place — see scraping.py. Listing the groups here too
                # meant forgetting the day a new spelling is added.
                amount, sym = money_groups(m)
                if amount is None:
                    continue
                sym = (sym or src_cur).strip()
                rate = rates.get(sym.upper(), rates.get(sym, 1)) or 1
                _push(amount * rate)
                hit = True
            return hit

        def _extract_el(txt):
            """For a price CSS CELL: currency OR, failing that, raw numbers.
            The raw-number fallback is safe here because the cell IS a price."""
            if not txt or _PROMO_RE.search(txt):
                return
            if _convert_in_order(txt):
                return
            collapsed = _re.sub(r'[\s,]+', '', txt)
            for m in _re.finditer(r'\d{3,6}', collapsed):
                _push(int(m.group()) * src_rate)

        # ── Level 0: Agoda room-grid XHR (most reliable) ─────────────────
        if oid == "agoda":
            rg = getattr(self, "_wiz_agoda_room_grid", {})
            if rg.get("rooms"):
                rg_prices = []
                for _rm in rg["rooms"]:
                    _offers = _rm.get("offers", [])
                    if not _offers:
                        continue
                    _pobj = _offers[0].get("price", {}).get("final", {})
                    _amt  = _pobj.get("amountNumber") or _pobj.get("amount")
                    _cur  = _pobj.get("currency", "USD")
                    try:
                        _amt = float(_amt)
                    except (TypeError, ValueError):
                        continue
                    _rate = rates.get(_cur.upper(), rates.get(_cur, 1.0)) or 1.0
                    _inr  = int(round(_amt * _rate))
                    if 300 <= _inr <= 500_000:
                        rg_prices.append(_inr)
                if rg_prices:
                    rg_prices.sort()
                    prices_raw.extend(rg_prices)
                    self._log(
                        f"📡 {len(prices_raw)} prices via Agoda room-grid XHR", "price")

        # ── Level 0.3: EXACT POSITION OF THE BUTTON CLICKED IN PHASE 2 ──────
        # Added 2026-07-31. The memorized selector (`manual_css_selector`) is
        # deliberately wide: it must find every room of a list, so it purposely
        # matches several elements (see _MANUAL_SCAN_JS, "2 to 100 matches"
        # condition). On a page showing a single offer — Airbnb — the same
        # selector also catches the neighbouring buttons, and the re-read took
        # the first one (scraping.py, `inBlock[0]`). Seen on the 4 Airbnb
        # listings: the clicked button gave ~1,500 ₹, the re-read one ~4,500 ₹,
        # at every calibration, with no message reporting it.
        # Here the element is re-read at ITS position, memorized at click time.
        # Absent from profiles calibrated before that date → nothing changes
        # for them until they redo a manual calibration.
        if not prices_raw:
            _prof_03 = self._get_profile(oid) or {}
            if getattr(self, "_wiz_mode", "desktop") == "mobile":
                _anch_03 = (_prof_03.get("mobile", {}) or {}).get(
                    "manual_price_anchors", {}) or {}
            else:
                _anch_03 = _prof_03.get("manual_price_anchors", {}) or {}
            _known_03 = set(scannable_room_types(self.app.config))
            if _anch_03:
                # The amount is read with THE SAME RULE as phase 2
                # (`_prices_in` → `_text_to_inr_prices`). A phase-1-specific rule
                # could read something else than what the operator validated on
                # screen on the same button — an invisible gap, impossible to
                # explain. One read, one value.
                from scraping.scraping import _text_to_inr_prices as _t2p_03
                _hotel_cur_03  = self.app.config.get("hotel_currency", "INR")
                _hotel_rate_03 = rates.get(_hotel_cur_03.upper(),
                                           rates.get(_hotel_cur_03, 1.0)) or 1.0
                _got_03, _miss_03 = {}, []
                for _room_03, _a_03 in _anch_03.items():
                    # A room removed from the configuration must not reappear
                    # in the prices through the sole grace of an old anchor.
                    if not isinstance(_a_03, dict) or _room_03 not in _known_03:
                        continue
                    _el_03 = None
                    if _a_03.get("path"):
                        try:
                            _el_03 = page.query_selector(_a_03["path"])
                        except Exception:
                            _el_03 = None
                    if _el_03 is None:
                        # Stale path (the page changed structure): fall back to
                        # the wide selector BUT keeping the rank of the clicked
                        # element, instead of taking the 1st.
                        _idx_03 = _a_03.get("idx", -1)
                        if _a_03.get("sel") and isinstance(_idx_03, int) \
                                and _idx_03 >= 0:
                            try:
                                _els_03 = page.query_selector_all(_a_03["sel"])
                                if _idx_03 < len(_els_03):
                                    _el_03 = _els_03[_idx_03]
                            except Exception:
                                _el_03 = None
                    _txt_03 = ""
                    if _el_03 is not None:
                        try:
                            _txt_03 = (_el_03.inner_text() or "").strip()
                        except Exception:
                            _txt_03 = ""
                    _v_03 = None
                    if _txt_03:
                        _found_03 = _t2p_03(_txt_03, config=self.app.config,
                                            fallback_currency=src_cur)
                        if _found_03:
                            # `_text_to_inr_prices` returns INR; bring it back to
                            # the hotel currency (identity if INR).
                            _v_03 = int(round(_found_03[0] / _hotel_rate_03))
                    if _v_03 is None:
                        _miss_03.append(_room_03)
                    else:
                        _got_03[_room_03] = _v_03
                if _got_03:
                    self._wiz_prices     = _got_03
                    self._wiz_raw_prices = list(_got_03.values())
                    self._log(
                        f"📍 {len(_got_03)} prices re-read at the exact "
                        f"position clicked in manual calibration ({src_cur}→{_hotel_cur_03})",
                        "price")
                    for _r_03 in _miss_03:
                        self._log(f"⚠ \"{_r_03}\": position anchor "
                                  "not found — recalibrate this room "
                                  "by hand", "err")
                    return
                if _miss_03:
                    self._log(
                        f"⚠ {len(_miss_03)} position anchor(s) not found "
                        "— the page changed structure, usual reading",
                        "err")

        # ── Level 0.4: NAME AND PRICE READ IN THE SAME OFFER CARD ──────────
        # Added 2026-07-31, taking priority over level 0.5.
        # Level 0.5 (below) assigns prices to rooms by ASCENDING PRICE ORDER —
        # the lowest price to the usually cheapest room, etc. That is a wrong
        # assumption as soon as a promotion swaps two rooms, and it is one
        # cause of prices landing on the wrong room.
        # Here each room name is read with the price of ITS card, then linked
        # to our rooms through the memorized mappings (`room_aliases`) and,
        # failing that, the distinctive words of the name. A line that cannot
        # be linked reliably is left aside instead of being guessed.
        if not prices_raw:
            try:
                from scraping.scraping import pair_rooms_and_prices
                from core.room_match import match_rooms
                _prof_04  = self._get_profile(oid) or {}
                _price_04 = _prof_04.get("manual_css_selector", "")
                _room_04  = (_prof_04.get("manual_field_selectors", {}) or {}).get("room", "")
                if _price_04 and _room_04:
                    _hotel_cur_04  = self.app.config.get("hotel_currency", "INR")
                    _hotel_rate_04 = rates.get(_hotel_cur_04.upper(),
                                               rates.get(_hotel_cur_04, 1.0)) or 1.0
                    _conv_04 = src_rate / _hotel_rate_04
                    _names_04, _vals_04 = [], []
                    _blocks_04 = pair_rooms_and_prices(page, _room_04, _price_04)
                    _unreadable_04 = []      # (name, price text) unreadable
                    for _bk in _blocks_04:
                        if _bk.get("ambiguous") or not _bk.get("found"):
                            continue
                        _pv = None
                        # `_NUM_RE` accepts amounts of ONE OR TWO digits.
                        # The old rule required 3 digits minimum: inherited from
                        # the era when everything was read in rupees (an INR price
                        # always has 3 digits). MakeMyTrip displays "$ 18": the 4
                        # prices were thus rejected and calibration silently fell
                        # back to reading the raw page text, which ranks prices
                        # by order of appearance → price on the wrong room (seen
                        # on 2026-07-31). Filtering is still ensured AFTER
                        # conversion by the 300 → 10,000,000 range.
                        for _mm in _re.finditer(
                                _NUM_RE, _re.sub(r'[\s,]+', '', _bk.get("price") or "")):
                            _cand = int(round(float(_mm.group()) * _conv_04))
                            if 300 <= _cand <= 10_000_000:
                                _pv = _cand
                                break
                        if _pv is None:
                            _unreadable_04.append(
                                ((_bk.get("room") or "?")[:40], (_bk.get("price") or "")[:30]))
                            continue
                        _names_04.append((_bk.get("room") or "").strip())
                        _vals_04.append(_pv)
                    # Diagnostics: without these lines, a failure here was totally
                    # mute in the log — impossible to know whether the per-card
                    # reading had failed or simply had not run.
                    if _unreadable_04:
                        for _rn_04, _pt_04 in _unreadable_04[:4]:
                            self._log(
                                f"⚠ \"{_rn_04}\": unreadable price \"{_pt_04}\" "
                                f"(out of range after conversion {src_cur}→{_hotel_cur_04})",
                                "err")
                    if not _blocks_04:
                        self._log(
                            "⚠ No room card found with the memorized "
                            "anchors (the page may have changed structure)", "err")
                    # Several prices in the same card: `pair_rooms_and_prices`
                    # keeps the first one (scraping.py, `inBlock[0]`). That is an
                    # assumption — it is stated on screen rather than silently
                    # endured, because it is exactly what made Airbnb read
                    # ~4,500 ₹ instead of ~1,500 ₹.
                    _multi_04 = sum(1 for _bk in _blocks_04
                                    if (_bk.get("nprices") or 0) > 1)
                    if _multi_04:
                        self._log(
                            f"⚠ {_multi_04} card(s) contain several prices — "
                            "the first one was kept; if the price is wrong, "
                            "redo a manual calibration to memorize the right "
                            "button", "err")
                    if _names_04:
                        from core import room_names as _rn04
                        _map_04, _refus_04 = match_rooms(
                            _names_04, scannable_room_types(self.app.config),
                            aliases=_rn04.aliases(oid))
                        if _map_04:
                            self._wiz_prices = {_our: _vals_04[_i]
                                                for _i, _our in _map_04.items()}
                            self._wiz_raw_prices = list(_vals_04)
                            self._log(
                                f"📡 {len(self._wiz_prices)} prices read in each "
                                f"room's card ({src_cur}→{_hotel_cur_04})",
                                "price")
                            for _i, _why in _refus_04.items():
                                self._log(
                                    f"⚠ \"{_names_04[_i][:40]}\" ({_vals_04[_i]}) "
                                    f"not linked to any of your rooms — {_why}",
                                    "err")
                            return
            except Exception as _e04:
                self._log(f"⚠ Per-card reading unavailable: {_e04}", "err")

        # ── Level 0.5: CSS selector captured during a manual calibration ──
        # Scans the CURRENT prices on the page, converts src_cur → hotel_currency,
        # dedupes the noise, then maps to rooms (prices_found as reference).
        if not prices_raw:
            _prof_05      = self._get_profile(oid)
            _prices_found = _prof_05.get("prices_found", {})
            _manual_sel   = _prof_05.get("manual_css_selector", "")
            if _manual_sel:
                try:
                    # Rate src_cur → hotel_currency (e.g. LAK→LAK=1.0, LAK→INR=0.0044)
                    _hotel_cur  = self.app.config.get("hotel_currency", "INR")
                    _hotel_rate = rates.get(_hotel_cur.upper(),
                                            rates.get(_hotel_cur, 1.0)) or 1.0
                    _conv_05    = src_rate / _hotel_rate  # src → hotel

                    elems = page.query_selector_all(_manual_sel)
                    _vals_05 = []
                    for el in elems[:20]:
                        _txt_05 = (el.inner_text() or "").strip()
                        if not _txt_05:
                            continue
                        # Raw number extraction, src→hotel conversion.
                        # Same fix as level 0.4: no more 3-digit minimum,
                        # otherwise "$ 18" is ignored (MakeMyTrip).
                        _col_05 = _re.sub(r'[\s,]+', '', _txt_05)
                        for _mm in _re.finditer(_NUM_RE, _col_05):
                            v_hotel = int(round(float(_mm.group()) * _conv_05))
                            if 300 <= v_hotel <= 10_000_000:
                                _vals_05.append(v_hotel)
                    if elems and not _vals_05:
                        self._log(
                            f"⚠ {len(elems)} price cell(s) found but no usable "
                            f"amount (e.g. '{(elems[0].inner_text() or '')[:20]}') "
                            f"— conversion {src_cur}→{_hotel_cur}", "err")
                    if _vals_05:
                        # Dedupe: drop values less than 5% apart
                        # (removes noise e.g. 1617 and 1619 → keeps 1617)
                        _vals_05.sort()
                        _deduped = [_vals_05[0]]
                        for _cv in _vals_05[1:]:
                            if _cv / _deduped[-1] > 1.05:
                                _deduped.append(_cv)
                        if _prices_found:
                            # Use the room order of prices_found
                            _n = len(_prices_found)
                            _rooms_sorted = sorted(_prices_found.keys(),
                                                   key=lambda r: _prices_found[r])
                            _selected = _deduped[:_n]
                            if len(_selected) == _n:
                                self._wiz_prices     = {
                                    _rooms_sorted[i]: _selected[i]
                                    for i in range(_n)
                                }
                                self._wiz_raw_prices = _selected
                                self._log(
                                    f"⚠ {_n} prices sorted by PRICE ORDER "
                                    f"({src_cur}→{_hotel_cur}) — no readable room "
                                    "name, check the mappings",
                                    "price")
                                return
                            elif _selected:
                                # Fewer rooms found than expected: keep the valid
                                # prices rather than throwing them away (otherwise
                                # the level-1+ fallback would start from zero).
                                for _dv in _selected:
                                    if _dv not in seen:
                                        seen.add(_dv)
                                        prices_raw.append(_dv)
                                self._log(
                                    f"⚠ {len(_selected)}/{_n} prices found via manual CSS "
                                    f"({src_cur}→{_hotel_cur}) — kept, partial mapping",
                                    "price")
                        else:
                            for _dv in _deduped:
                                if _dv not in seen:
                                    seen.add(_dv)
                                    prices_raw.append(_dv)
                        if prices_raw:
                            self._log(
                                f"📡 {len(prices_raw)} prices via manual CSS  "
                                f"{_manual_sel[:40]}",
                                "price")
                except Exception:
                    pass

        # ── Level 1: OTA-specific CSS selectors ──────────────────────────
        if not prices_raw:
            sel_hit = None
            for sel in _OTA_PRICE_SELECTORS.get(oid, []):
                try:
                    elems = page.query_selector_all(sel)
                    before = len(prices_raw)
                    for el in elems[:20]:
                        _extract_el((el.inner_text() or "").strip())
                    if len(prices_raw) > before:
                        sel_hit = sel
                        break
                except Exception:
                    continue
            if sel_hit:
                self._log(f"📡 {len(prices_raw)} prices via OTA CSS  {sel_hit[:40]}", "price")

        # ── Level 2: generic CSS selectors (price/rate/amount) ────────────
        if not prices_raw:
            for sel in ('[class*="price" i]', '[aria-label*="price" i]',
                        '[data-testid*="price" i]', '[class*="rate" i]',
                        '[class*="amount" i]'):
                try:
                    for el in page.query_selector_all(sel)[:30]:
                        _extract_el((el.inner_text() or "").strip())
                    if prices_raw:
                        self._log(f"📡 {len(prices_raw)} prices via generic CSS  {sel}",
                                  "price")
                        break
                except Exception:
                    continue

        # ── Level 3: full-text fallback — CURRENCY SYMBOL REQUIRED ────────
        # (otherwise "320 reviews", "4 guests"… would be taken for prices)
        if not prices_raw:
            self._log("Fallback: analyzing the full page text…", "info")
            try:
                page_text = page.evaluate("() => document.body.innerText") or ""
                _convert_in_order(page_text)
                if prices_raw:
                    self._log(
                        f"📡 Fallback: {len(prices_raw)} prices over {len(page_text)} characters",
                        "price")
                else:
                    self._log(
                        f"⚠ Fallback: 0 prices over {len(page_text)} characters "
                        "(anti-bot page or wrong URL?)", "err")
            except Exception as e:
                self._log(f"❌ Regex fallback: {e}", "err")

        # ── Map to scannable room_types (excluding "CM test" rooms) ───────
        room_types = scannable_room_types(self.app.config)
        # No sorting: the config order does not necessarily match a real
        # ascending price order (seen on this hotel: Deluxe cheaper than
        # Double on several OTAs). We keep discovery order (appearance on
        # the page) — a weaker assumption than sorting by value, but it no
        # longer reorders prices arbitrarily.
        self._wiz_prices = {}
        for i, room in enumerate(room_types):
            if i < len(prices_raw):
                self._wiz_prices[room] = prices_raw[i]
        self._wiz_raw_prices = prices_raw
        if self._wiz_prices:
            # Assignment by POSITION: the weakest assumption of all
            # (no room name could be read). Stated explicitly so the operator
            # checks on screen instead of validating blindly.
            self._log(
                f"⚠ {len(self._wiz_prices)} prices assigned by ORDER OF APPEARANCE "
                "on the page — check each room before validating "
                "(a manual calibration learns the real names)", "err")

    def _wiz_close_browser(self):
        # NEVER call ctx.close() here: the Playwright context was created in
        # _wiz_chrome_thread (separate thread) — Playwright sync forbids
        # closing from another thread (greenlet.error:
        # "Cannot switch to a different thread"), which crashed the
        # wizard on the "New profile" click. We only signal the stop; the
        # Chrome thread closes its own ctx (same thread, see the finally of
        # _wiz_chrome_thread) then sets _wiz_browser_closed — we just wait
        # for that, with a bounded delay to never block the UI indefinitely
        # if the thread already died without setting the event.
        if self._wiz_nav_stop:
            self._wiz_nav_stop.set()
        if self._wiz_browser_ctx is not None and self._wiz_browser_closed:
            self._wiz_browser_closed.wait(2.0)

    def _wiz_reset_profile(self):
        """Closes Chrome, wipes the persistent calibration profile (cookies,
        history) and restarts navigation with a blank profile.

        The current OTA's profile is reused from one calibration to the next
        (accumulated cookies to stay fast) — repeated use on the same site can
        end up flagged as automated traffic (the site then serves a fake page
        instead of the real content, e.g. an empty "200 OK").
        A fresh profile restarts from zero, like a new visitor.

        Only the current OTA's profile is wiped: other OTAs keep theirs
        (see _calib_profile_id)."""
        self._wiz_close_browser()
        self._set_status(tr_("🧹 Resetting Chrome Profile…"), T.YELLOW)
        _prof_id = self._calib_profile_id()

        def _do_wipe():
            try:
                from scraping.chrome_manager import wipe_profile
                wipe_profile(_prof_id)
                self._log("🧹 Calibration Chrome profile reset", "info")
            except Exception as e:
                self._log(f"⚠ Profile reset: {e}", "warn")
            self._wiz_launch_chrome()
        # Give the closed Chrome process time to release the profile files
        # before trying to delete them (Windows locking).
        self.app.root.after(400, _do_wipe)

    def _wiz_unlock_site(self):
        """Opens an ORDINARY Chrome on the current OTA's profile to solve an
        anti-robot challenge (CAPTCHA) there, then restarts calibration.

        Why this detour — measured on 2026-08-02 on Expedia and MakeMyTrip:
        the site presents the challenge to a visitor it does not recognize,
        but REFUSES to validate it as soon as it detects a driven browser.
        Solved in the calibration window, the challenge never unlocks the
        page — the site keeps treating the session as a robot. Solved in an
        ordinary Chrome opened on the SAME profile folder, it is accepted and
        the pass is stored there; calibration, which reuses that folder, then
        opens normally (verified: no more CAPTCHA).

        The pass eventually expires on the site side: this button renews it
        at any time, without touching the code or recompiling.

        This is also why the calibration profile is never wiped automatically
        anymore (see _OTA_LAUNCH_QUIRKS in scraping.py): wiping it means
        throwing the pass away.
        """
        from tkinter import messagebox
        # The driven Chrome must give up the profile folder: two browsers on
        # the same --user-data-dir conflict (SingletonLock) and the second
        # one closes immediately.
        self._wiz_close_browser()
        _prof_id = self._calib_profile_id()
        _url     = self._wiz_url

        def _go():
            try:
                from scraping.chrome_manager import open_manual_chrome
                proc = open_manual_chrome(
                    _prof_id, _url, extra_args=["--window-size=1366,768"])
            except Exception as e:
                proc = None
                self._log(f"⚠ Unblock: {e}", "err")
            if proc is None:
                self._set_status(
                    tr_("❌ Chrome not found — impossible to unblock"), T.RED)
                self._log("❌ Unblock: no browser found on this "
                          "machine", "err")
                self.app.root.after(600, self._wiz_launch_chrome)
                return
            self._log("🔓 Ordinary Chrome opened on calibration profile "
                      f"'{_prof_id}' — solve the challenge then come back here",
                      "info")
            self._set_status(tr_("🔓 Solve the test in the Chrome window…"),
                             T.YELLOW)
            # Deliberately modal window: it serves as "click when done".
            # Waiting for the Chrome process to end would not be reliable
            # (Chrome may hand back to the launcher while staying open).
            messagebox.showinfo(
                tr_("Unblock the site"),
                tr_("A regular Chrome window has just opened on the page.\n\n1. Solve the anti-robot test (CAPTCHA)\n2. Wait for the hotel page to actually display, with prices\n3. Come back here and click OK\n\nChrome will be closed and the calibration will restart with the pass obtained."),
                parent=self.app.root)
            try:
                proc.terminate()
            except Exception:
                pass
            self._log("🔓 Unblock finished — reopening calibration", "ok")
            # Let Chrome release the profile files (Windows locking) before
            # Playwright reopens the same folder.
            self.app.root.after(1200, self._wiz_launch_chrome)

        # Same delay as "🧹 New profile", for the same reason.
        self.app.root.after(400, _go)

    # ── Fallback: the machine's real browser ──────────────────────────────
    # NOTE: the screenshot_fallback module (OCR / screenshot) has been
    # removed.  This function now shows an error if called.  The UI button
    # is kept for compatibility; the flow is disabled until a possible
    # redesign.

    def _wiz_real_browser(self):
        """Opens the page in the machine's personal browser, then reads the
        prices on screen once the user has passed the block."""
        self.app.root.after(
            0, lambda: self._wiz_real_browser_fail(
                ImportError("screenshot_fallback module removed")))
        return

    def _wiz_real_browser_fail(self, err):
        self._set_status(tr_("❌ “Real browser” mode unavailable"), T.RED)
        self._log(f"❌ Real browser: {err}", "err")

    def _wiz_real_browser_read(self, hwnd):
        """Stub — screenshot_fallback module removed."""
        self.app.root.after(
            0, lambda: self._wiz_real_browser_fail(
                ImportError("screenshot_fallback module removed")))

    # ── Step 4: Validation ────────────────────────────────────────────────

    def _step_4_validate(self):
        m = self._wiz_main
        oid, name = self._wiz_ota
        lbl(m, tr_("Checks detected prices"), bold=True, size=14
            ).pack(anchor="w", pady=(0, 8))
        lbl(m, tr_("The software extracted these prices on the {name} page:").format(name=name),
            color="#888", size=9).pack(anchor="w", pady=(0, 12))

        # Detected currency
        cur_frame = tk.Frame(m, bg=T.ENTRY_BG, padx=12, pady=8)
        cur_frame.pack(fill="x", pady=(0, 12))
        lbl(cur_frame, tr_("💱 Currency detected on the page:"),
            bold=True, size=9).pack(side="left", padx=(0, 8))
        self._wiz_cur_var = tk.StringVar(
            value=self._wiz_detected_cur or
                  self.app.config.get("hotel_currency", "INR"))
        _CUR = ["INR", "LAK", "EUR", "USD", "THB", "GBP", "JPY", "KRW",
                "CNY", "VND", "MMK", "PHP", "AED", "SGD", "AUD", "MYR",
                "IDR", "NPR", "BDT", "LKR", "HKD", "CAD", "CHF"]
        ttk.Combobox(cur_frame, textvariable=self._wiz_cur_var,
                     values=_CUR, width=8, state="normal"
                     ).pack(side="left")
        if self._wiz_detected_cur:
            lbl(cur_frame, tr_("  ✓ auto-detected"),
                color=T.GREEN, size=8).pack(side="left", padx=8)
        else:
            lbl(cur_frame, tr_("  (no symbols found — type currency)"),
                color="#888", size=8).pack(side="left", padx=8)
        btn(cur_frame, tr_("✅ Save →"), self._step4_save,
            color=T.GREEN, width=18).pack(side="right", padx=(4, 0))
        btn(cur_frame, tr_("🖱 Manual Calibrate"), self._manual_calibrate_launch,
            color="#5865F2", width=18).pack(side="right", padx=(4, 8))

        # Prices
        if not self._wiz_prices:
            warn = tk.Frame(m, bg="#3a1010", padx=12, pady=10)
            warn.pack(fill="x", pady=(0, 12))
            lbl(warn, tr_("⚠ No prices detected on the page"),
                color=T.RED, bold=True).pack(anchor="w")
            lbl(warn,
                "The scan found no prices with the known selectors.\n"
                "Either the page was not displaying prices, or the OTA uses\n"
                "unknown CSS selectors. The calibration will still be saved\n"
                "(URL + recorded clicks) to help future scans.",
                color="#ccc", size=9).pack(anchor="w", pady=(4, 0))
        else:
            lbl(m, tr_("Price per room (click to correct)"),
                bold=True, size=10).pack(anchor="w", pady=(0, 4))
            for room, price in self._wiz_prices.items():
                row = tk.Frame(m, bg=T.ENTRY_BG, padx=12, pady=10)
                row.pack(fill="x", pady=2)
                self._wiz_validations.setdefault(room, True)
                ok     = self._wiz_validations[room]
                bg_col = "#1a2a1a" if ok else "#2a1a1a"
                row.config(bg=bg_col)

                check = "✓" if ok else "✗"
                col   = T.GREEN if ok else T.RED

                # ── Left: checkmark + room name ──────────────────────────
                left = tk.Frame(row, bg=bg_col)
                left.pack(side="left", fill="y")
                tk.Label(left, text=check, bg=bg_col, fg=col,
                         font=("Segoe UI", 12, "bold"), width=2,
                         ).pack(side="left")
                lbl(left, room, bg=bg_col,
                    color="#b8c4d8", size=9,
                    ).pack(side="left", padx=(6, 0))

                # ── Center: price (large, clearly visible) ───────────────
                lbl(row,
                    f"₹ {price:,}".replace(",", " "),
                    bg=bg_col, color=T.ACCENT, bold=True, size=14,
                    ).pack(expand=True)

                def _toggle(_e=None, _r=room):
                    self._wiz_validations[_r] = not self._wiz_validations.get(_r, True)
                    self._show_step(4)
                row.bind("<Button-1>", _toggle)
                for child in left.winfo_children():
                    try: child.bind("<Button-1>", _toggle)
                    except Exception: pass

        # Buttons
        bbar = tk.Frame(m, bg=T.BG)
        bbar.pack(fill="x", pady=(16, 0))
        btn(bbar, tr_("← Previous"), self._step4_back,
            color=T.SEL_BG, width=14).pack(side="left")
        btn(bbar, tr_("⏹ Cancel"), self._step4_cancel,
            color=T.RED, width=14).pack(side="right")

    def _step4_back(self):
        self._wiz_prices.clear()
        self._wiz_validations.clear()
        self._show_step(3)
        self.app.root.after(300, self._wiz_launch_chrome)

    def _step4_cancel(self):
        self._wiz_close_browser()
        self._show_step(1)   # back to OTA cards

    # ── Reading anchors deduced from the page ────────────────────────────
    # Looks, on the page the user just validated, for the common "shape" of
    # the cells containing a price, then that of the headings placed right
    # above (the room name). These two shapes are what the automatic reading
    # reuses afterwards to find the prices.
    #
    # Knows NO particular site: that is what lets an OTA added tomorrow have
    # anchors without anyone entering them. Does not replace manual
    # designation (the "🖱 Manual Calibrate" button), which stays more
    # reliable and always keeps priority.
    _AUTO_SEL_JS = r"""
() => {
  try {
    var CUR = /(?:[₹$€£₭]|\bRs\.?|\b(?:INR|USD|EUR|GBP|LAK|THB|AED|SGD|NPR)\b)\s*[\d][\d,.\s]{0,12}\d|[\d][\d,.\s]{0,12}\d\s*\b(?:INR|USD|EUR|GBP|LAK|THB|AED|SGD|NPR)\b/;
    function sig(el) {
      if (!el || !el.tagName) return '';
      var tag = el.tagName.toLowerCase();
      var cls = (typeof el.className === 'string') ? el.className.trim() : '';
      var parts = cls ? cls.split(/\s+/).filter(function (c) {
        return c && c.length <= 40 && /^[A-Za-z_-][\w-]*$/.test(c);
      }).slice(0, 4) : [];
      return parts.length ? tag + '.' + parts.join('.') : '';
    }
    function usable(sel) {
      if (!sel) return false;
      try { return document.querySelectorAll(sel).length > 0; } catch (e) { return false; }
    }
    var priceCount = {}, priceEls = [];
    var all = document.body ? document.body.querySelectorAll('*') : [];
    var lim = Math.min(all.length, 6000);
    for (var i = 0; i < lim; i++) {
      var el = all[i];
      if (el.children.length) continue;              // terminal cells
      var t = (el.innerText || '').trim();
      if (!t || t.length > 40 || !CUR.test(t)) continue;
      var s = sig(el);
      if (!s) continue;
      priceCount[s] = (priceCount[s] || 0) + 1;
      priceEls.push(el);
    }
    var best = '', bestN = 0, k;
    for (k in priceCount) { if (priceCount[k] > bestN) { best = k; bestN = priceCount[k]; } }

    var nameCount = {};
    var SELN = 'h1,h2,h3,h4,h5,h6,[class*="name"],[class*="Name"],'
             + '[class*="title"],[class*="Title"]';
    for (var p = 0; p < priceEls.length && p < 60; p++) {
      var node = priceEls[p], found = null;
      for (var up = 0; up < 6 && node && !found; up++) {
        node = node.parentElement;
        if (!node) break;
        var cands = node.querySelectorAll(SELN);
        for (var j = 0; j < cands.length; j++) {
          var tt = (cands[j].innerText || '').trim();
          if (tt.length < 3 || tt.length > 90 || CUR.test(tt)) continue;
          found = cands[j]; break;
        }
      }
      if (found) {
        var sn = sig(found);
        if (sn) nameCount[sn] = (nameCount[sn] || 0) + 1;
      }
    }
    var bestName = '', bestNameN = 0;
    for (k in nameCount) { if (nameCount[k] > bestNameN) { bestName = k; bestNameN = nameCount[k]; } }

    return {price: usable(best) ? best : '', price_n: bestN,
            room: usable(bestName) ? bestName : '', room_n: bestNameN};
  } catch (e) { return {error: String(e)}; }
}
"""

    def _wiz_auto_detect_selectors(self, page):
        """Deduces from the page where the prices and room names are.

        Result stored in self._wiz_auto_sels; it is only saved at save time,
        and only if the OTA has NO anchor designated by hand (see
        _step4_save).
        """
        self._wiz_auto_sels = {}
        try:
            res = page.evaluate(self._AUTO_SEL_JS) or {}
        except Exception as e:
            self._log(f"⚠ Automatic anchor detection: {e}", "warn")
            return
        if res.get("error"):
            self._log(f"⚠ Automatic anchor detection: {res['error']}",
                      "warn")
            return
        price_sel = (res.get("price") or "").strip()
        room_sel  = (res.get("room") or "").strip()
        try:
            n_price = int(res.get("price_n") or 0)
        except (TypeError, ValueError):
            n_price = 0
        # At least two cells: a single one is almost always an isolated
        # element (banner, total, crossed-out price) and not the rate column.
        if not price_sel or n_price < 2:
            self._log("🔍 Automatic detection: no reliable price anchor "
                      "on this page.", "info")
            return
        self._wiz_auto_sels = {"price": price_sel, "room": room_sel}
        _msg = (f"🔍 Anchors deduced from the page — price: {price_sel} "
                f"({n_price} cells)")
        if room_sel:
            _msg += f" · room: {room_sel}"
        self._log(_msg, "ok")

    def _identify_price_endpoint(self, valid_prices, src_cur="INR"):
        """Spots, among the captured network responses, the one containing the
        validated prices → returns a URL pattern (the path) to listen to again
        at scan.

        '' if no reliable match (the OTA does not expose its prices in readable
        JSON, e.g. Google batchexecute) → at scan we simply fall back to the
        usual engines, nothing is broken.
        """
        if not valid_prices or not getattr(self, "_wiz_net_captures", None):
            return ""
        try:
            from core.utils import get_inr_rates
            _rates = get_inr_rates(self.app.config)
        except Exception:
            try:
                from scraping.scraping import _RATES_TO_INR as _rates
            except Exception:
                _rates = {}
        _rate = _rates.get((src_cur or "INR").upper(), 1.0) or 1.0

        # Target prices: in INR AND in raw source currency (the JSON is often
        # in the OTA's currency, not INR).
        _targets = set()
        for _p in valid_prices.values():
            try:
                _p = int(_p)
            except Exception:
                continue
            _targets.add(_p)
            if _rate and abs(_rate - 1.0) > 0.01:
                _targets.add(int(round(_p / _rate)))
        if not _targets:
            return ""

        _best_path, _best_hits = "", 0
        for _path, _nums in self._wiz_net_captures:
            _numset = set(_nums)
            _hits = 0
            for _t in _targets:
                if _t in _numset or any(abs(_t - _n) <= max(2, _t * 0.01)
                                        for _n in _nums):
                    _hits += 1
            if _hits > _best_hits:
                _best_hits, _best_path = _hits, _path
        # Require at least 2 prices found (or all of them if fewer) to prevent
        # a single number from sneaking a wrong endpoint through. Also require
        # a specific enough path (≥ 5 chars) to never keep a too-generic
        # pattern (e.g. "/") that would match every URL.
        _need = min(2, len(_targets))
        if _best_hits >= _need and len(_best_path) >= 5:
            return _best_path
        return ""

    def _step4_save(self):
        oid, name = self._wiz_ota
        cur = (self._wiz_cur_var.get().strip().upper() or "INR")
        profile = self._get_profile(oid) or {}
        _is_mobile = getattr(self, "_wiz_mode", "desktop") == "mobile"
        # Keep only the validated prices
        valid_prices = {r: p for r, p in self._wiz_prices.items()
                        if self._wiz_validations.get(r, True)}
        # Learn the network price endpoint (Agoda generalization → all OTAs)
        _price_endpoint = self._identify_price_endpoint(valid_prices, src_cur=cur)
        if _price_endpoint:
            self._log(f"📡 Price endpoint learned: {_price_endpoint}", "ok")

        # ── Plausibility check (usual room order) ────────────────────────────
        # Computed BEFORE `_update_prices_learned`, otherwise suspicious prices
        # would enter the very history used as reference.
        # Does not prevent saving: a genuine repricing by the hotelier would
        # produce exactly the same signal.
        try:
            from core.room_match import plausibility_warnings as _plaus
            _plaus_warns = _plaus(valid_prices, profile.get("prices_learned", {}))
        except Exception:
            _plaus_warns = []

        if _is_mobile:
            # ── MOBILE sub-profile ────────────────────────────
            # Does NOT overwrite desktop: only what differs on mobile is stored
            # (actions/CSS/good_url/endpoint). Base URL, currency and price
            # history stay shared with desktop.
            _mob = dict(profile.get("mobile", {}) or {})
            _mob.update({
                "good_url":        self._wiz_good_url,
                "action_sequence": list(self._wiz_actions),
                "prices_found":    valid_prices,
                "price_endpoint":  _price_endpoint or _mob.get("price_endpoint", ""),
                "calibrated_at":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            if getattr(self, "_wiz_manual_css_sel", ""):
                _mob["manual_css_selector"] = self._wiz_manual_css_sel
            # Attributes captured in manual calibration (crossed-out price,
            # discount, rate type…) — stored per room + most frequent selector
            # per field.
            if getattr(self, "_wiz_manual_attrs", None):
                _mob["manual_attrs"] = self._wiz_manual_attrs
            if getattr(self, "_wiz_manual_field_sels", None):
                _mob["manual_field_selectors"] = self._wiz_manual_field_sels
            # Position anchors: STORED SEPARATELY from desktop. A position read
            # on the mobile page does not designate the same element on the
            # desktop page — mixing them would re-read the wrong button.
            if getattr(self, "_wiz_manual_price_anchors", None):
                _mob["manual_price_anchors"] = self._wiz_manual_price_anchors
            profile["mobile"] = _mob
            profile.setdefault("source_currency", cur)  # shared currency
        else:
            profile.update({
                "ota":             oid,
                "source_currency": cur,
                "good_url":        self._wiz_good_url,
                "nav_path":        list(self._wiz_urls_visited),
                "action_sequence": list(self._wiz_actions),
                "prices_found":    valid_prices,
                # Never overwrite an already-learned endpoint if this session
                # did not recapture one (e.g. prices loaded without a new
                # network call).
                "price_endpoint":  _price_endpoint or profile.get("price_endpoint", ""),
                "calibrated_at":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            # Learn the prices into the history (desktop only, so as not to
            # pollute the learned range with possible mobile rates).
            self._update_prices_learned(profile, valid_prices)
            if getattr(self, "_wiz_manual_css_sel", ""):
                profile["manual_css_selector"] = self._wiz_manual_css_sel
            # Attributes captured in manual calibration (crossed-out price,
            # discount, rate type…) — stored per room + most frequent selector
            # per field.
            if getattr(self, "_wiz_manual_attrs", None):
                profile["manual_attrs"] = self._wiz_manual_attrs
            if getattr(self, "_wiz_manual_field_sels", None):
                profile["manual_field_selectors"] = self._wiz_manual_field_sels
            # Exact position of the clicked price button for each room.
            # Replaced as a block (not merged): a position anchor is only valid
            # for the page structure as it was at click time — keeping old ones
            # alongside would re-read old positions that became wrong.
            if getattr(self, "_wiz_manual_price_anchors", None):
                profile["manual_price_anchors"] = self._wiz_manual_price_anchors
                self._log(
                    f"📍 {len(self._wiz_manual_price_anchors)} position "
                    "anchor(s) memorized — the price will be re-read on the "
                    "exact button you clicked", "ok")

            # Safety net for an OTA whose anchors nobody designated by hand:
            # we save the ones deduced from the page. Without this, a
            # user-added OTA started with a profile without any anchor, and
            # the automatic reading had nothing to read. Never over a manual
            # anchor, nor over an anchor already memorized in a previous
            # calibration.
            _auto = getattr(self, "_wiz_auto_sels", None) or {}
            if _auto.get("price") and not profile.get("manual_css_selector"):
                profile["manual_css_selector"] = _auto["price"]
                _fs = dict(profile.get("manual_field_selectors", {}) or {})
                _fs.setdefault("price", _auto["price"])
                if _auto.get("room"):
                    _fs.setdefault("room", _auto["room"])
                profile["manual_field_selectors"]  = _fs
                profile["auto_detected_selectors"] = True
                self._log("🔍 Page-deduced anchors saved "
                          "(no manual anchor for this OTA) — manual "
                          "calibration stays more reliable if prices are wrong.",
                          "ok")

        # Mappings "name displayed by the OTA → our room". Merged per D108:
        # the name mappings live in THE single file (room_names.json) — merged
        # with the already-known ones (never replaced as a block): an OTA that
        # displays sometimes "Deluxe Double Room" sometimes "Chambre Double
        # Deluxe" ends up with both labels recognized. The calibration profile
        # no longer carries them.
        if getattr(self, "_wiz_room_aliases", None):
            from core.room_match import learn_aliases as _learn_aliases
            from core import room_names as _rn
            _merged = _learn_aliases(
                _rn.aliases(oid),
                list(self._wiz_room_aliases.items()))
            _rn.set_aliases(oid, _merged)
            self._log(f"🔗 {len(_merged)} room name "
                      "mapping(s) memorized (room_names.json)", "ok")

        for _w in _plaus_warns:
            self._log(f"⚠ {_w}", "err")

        if not self._set_profile(oid, profile):
            self._log(f"❌ {name} — calibration save failed (see log)",
                      "error")
            messagebox.showerror(
                tr_("Calibration"),
                tr_("Saving the calibration failed.\nPrices were NOT saved — try again."),
                parent=self.app.root)
            return
        self._log(f"✅ {name} calibrated ({'mobile' if _is_mobile else 'desktop'}): "
                  f"{len(valid_prices)} prices, currency {cur}", "ok")
        self._show_step(5)

    def _manual_calibrate_launch(self):
        """Opens Chrome with injected JS — the user clicks an element, THEN
        explicitly states (button) whether it was the NAME or the PRICE. No
        automatic alternation: each click is confirmed/rejected before being
        recorded."""
        import threading
        import queue
        from scraping.scraping import _text_to_inr_prices
        oid, name = self._wiz_ota
        profile = self._get_profile(oid) or {}
        src_cur = (getattr(self, "_wiz_detected_cur", None) or
                   profile.get("source_currency") or
                   self.app.config.get("hotel_currency", "INR"))
        # Exchange rates + `re`, used by _prices_in (digits-only fallback).
        # Declared HERE, before any inner function using them: otherwise they
        # are only bound further down in the body and any reorganization of
        # the file would break the fallback with no visible error.
        import re as _re
        try:
            from core.utils import get_inr_rates as _gir
            _mrates = _gir(self.app.config)
        except Exception:
            from scraping.scraping import _RATES_TO_INR as _mrates
        start_url = profile.get("good_url", "")
        # MOBILE calibration: reuse the mobile-specific address if it has
        # already been validated (e.g. MakeMyTrip, where mobile and desktop do
        # not display prices on the same page) — otherwise keep the desktop
        # address as starting point, as on first launch.
        if getattr(self, "_wiz_mode", "desktop") == "mobile":
            _mob_good_url = (profile.get("mobile", {}) or {}).get("good_url", "")
            if _mob_good_url:
                start_url = _mob_good_url
        if start_url:
            try:
                from core.utils import inject_scan_dates
                start_url = inject_scan_dates(start_url, int(self._wiz_date_offset_v.get()))
            except Exception:
                pass

        dlg = tk.Toplevel(self.app.root)
        dlg.title(f"🖱 {tr_('Manual Calibrate')} — {name}")
        dlg.configure(bg=T.BG)
        # 760x600 (instead of 600x520): the table now has 5 columns
        # (170+170+90+210+36 = 676 px) + scrollbar + margins = ~724 px,
        # and the "Mapping" row added under the table costs ~50 px of
        # height. At 600x520 the "Our room" column and the bottom of the
        # window would have been truncated.
        dlg.geometry("760x600")
        dlg.resizable(True, True)

        lbl(dlg, tr_("Manual Calibrate — {n}").format(n=name), bold=True, size=12).pack(
            anchor="w", padx=16, pady=(12, 2))
        lbl(dlg,
            "Chrome will open. Click an element, then indicate its type below\n"
            "(room name, final price, crossed-out price, % discount, rate type, taxes\n"
            "included, occupancy, loyalty discount). Only click what exists on the page.",
            color="#888", size=8).pack(anchor="w", padx=16, pady=(0, 4))

        status_var = tk.StringVar(value="⏳ Starting Chrome…")
        tk.Label(dlg, textvariable=status_var, bg=T.BG, fg=T.YELLOW,
                 font=("Segoe UI", 9, "italic")).pack(anchor="w", padx=16, pady=(4, 0))

        # ── Confirmation zone of the last captured click ────────────────
        cf = tk.Frame(dlg, bg=T.ENTRY_BG, padx=10, pady=8)
        cf.pack(fill="x", padx=16, pady=(8, 4))
        preview_var = tk.StringVar(value=tr_("(no click waiting)"))
        tk.Label(cf, textvariable=preview_var, bg=T.ENTRY_BG, fg="#ddd",
                 font=("Segoe UI", 9), anchor="w", justify="left", wraplength=540
                 ).pack(anchor="w")
        # ── The 8 capturable element types ──────────────────────────────────
        # Each element is OPTIONAL: the operator only clicks what actually
        # exists on THIS OTA's page. The captured CSS selector is specific to
        # the calibrated OTA — the same element (e.g. "crossed-out price") may
        # carry a different designation / HTML class from one OTA to another:
        # we learn the clicked element, not its class name.
        # Colors chosen to stay visually distinct from each other — NOT for
        # their contrast with the text. The automatic text color choice
        # (_btn_fg) gave very dark gray text (T.BG, not pure black) on most of
        # them: real contrast ~2.5-3.5 (below the 4.5 readable minimum),
        # hence the reported "unreadable" rendering. Text forced below by
        # computing real contrast (pure black ~8-12 on these medium-light
        # colors; pure white only on the darker purple, where black would be
        # unreadable instead). Dark purple (instead of "#8e44ad") to further
        # strengthen that contrast with white.
        _FIELDS = [
            ("room",      tr_("🏷 Room name"), "#2980b9", "black"),
            ("price",     tr_("💰 Final price"),     "#27ae60", "black"),
            ("strike",    tr_("🏷️ Price crossed out"),     "#e67e22", "black"),
            ("discount",  tr_("🏷% off"),     "#c0392b", "black"),
            ("rate_type", tr_("📋 Rate type"),   "#4b0082", "white"),
            ("tax_incl",  tr_("🧾 Taxes included"),  "#16a085", "black"),
            ("occupancy", tr_("👥 Occupation"),      "#34495e", "black"),
            ("loyalty",   tr_("⭐ Loyalty discount"), "#b8860b", "black"),
        ]
        _FIELD_LABEL = {
            "room": "room name", "price": "final price", "strike": "crossed-out price",
            "discount": "% discount", "rate_type": "rate type",
            "tax_incl": "taxes-included price", "occupancy": "occupancy",
            "loyalty": "loyalty discount",
        }
        _PRICE_FIELDS = {"price", "strike", "tax_incl"}  # must contain a readable price

        cbf = tk.Frame(cf, bg=T.ENTRY_BG); cbf.pack(anchor="w", pady=(6, 0))
        field_btns = {}
        _brow1 = tk.Frame(cbf, bg=T.ENTRY_BG); _brow1.pack(anchor="w")
        _brow2 = tk.Frame(cbf, bg=T.ENTRY_BG); _brow2.pack(anchor="w", pady=(4, 0))
        for _idx, (_fk, _flabel, _fcol, _ffg) in enumerate(_FIELDS):
            _b = btn(_brow1 if _idx < 4 else _brow2, _flabel,
                     (lambda k=_fk: _assign(k)), color=_fcol, width=15,
                     fg=_ffg)
            _b.pack(side="left", padx=(0, 6))
            field_btns[_fk] = _b
        _brow3 = tk.Frame(cbf, bg=T.ENTRY_BG); _brow3.pack(anchor="w", pady=(4, 0))
        reject_btn = btn(_brow3, tr_("❌ Reject"), lambda: _reject(),
                         color="#555", width=12)
        reject_btn.pack(side="left")
        _all_click_btns = list(field_btns.values()) + [reject_btn]
        for b in _all_click_btns:
            b.config(state="disabled")

        lbl(dlg, tr_("Pairs captured:"), bold=True, size=9).pack(
            anchor="w", padx=16, pady=(6, 0))

        # bf is packed BEFORE tf (and with side="bottom") so its height is
        # reserved first — otherwise tf (fill="both", expand=True) absorbs
        # all the remaining vertical space of the window and crushes bf to
        # a near-zero height ("Apply" button invisible).
        bf = tk.Frame(dlg, bg=T.BG); bf.pack(side="bottom", fill="x", padx=16, pady=(0, 12))
        undo_btn = btn(bf, tr_("↩ Clear last"), lambda: _undo(), color="#555", width=16)
        undo_btn.pack(side="left", padx=(0, 8)); undo_btn.config(state="disabled")
        done_btn = btn(bf, tr_("✅ Apply to calibration"), lambda: _apply(),
                       color=T.GREEN, width=26)
        done_btn.pack(side="left"); done_btn.config(state="disabled")
        cancel_btn = btn(bf, tr_("❌ Cancel"), lambda: _on_close(), color="#c0392b", width=14)
        cancel_btn.pack(side="right")

        # ── Mapping "name displayed by the OTA → our room" ──────────────────
        # Added 2026-07-31. The clicked name is the one the OTA displays; it
        # was until now used directly as the price key, so Agoda in French
        # created a 5th, 6th, 7th, 8th room ("Chambre Double avec Balcon
        # (Double Room with Balcony)") next to our 4 real rooms, each with its
        # own price history.
        # This panel proposes an automatic mapping (distinctive words, see
        # core.room_match) and lets it be corrected with one click. It is
        # memorized in the calibration (`room_aliases`): later readings have
        # nothing left to guess for those names.
        # Packed BEFORE `tf`: `tf` takes all the remaining space (fill both +
        # expand), so anything packed after it would be invisible.
        _our_rooms = list(scannable_room_types(self.app.config))
        manual_map = {}          # {normalized OTA name: our room ("" = ignore)}
        _IGNORE_LBL = tr_("— ignore this line —")

        mf = tk.Frame(dlg, bg=T.BG); mf.pack(side="bottom", fill="x", padx=16, pady=(0, 6))
        lbl(mf, tr_("Correspondence of the selected line:"), size=8,
            color="#888").pack(anchor="w")
        _mrow = tk.Frame(mf, bg=T.BG); _mrow.pack(anchor="w", pady=(2, 0))
        map_var = tk.StringVar(value="")
        map_cb = ttk.Combobox(_mrow, textvariable=map_var, state="readonly",
                              width=34, values=[_IGNORE_LBL] + _our_rooms)
        map_cb.pack(side="left")

        tf = tk.Frame(dlg, bg=T.BG); tf.pack(fill="both", expand=True, padx=16, pady=(2, 4))
        tree = ttk.Treeview(tf, columns=("chambre", "notre", "prix", "details", "st"),
                             show="headings", height=8)
        tree.heading("chambre", text=tr_("Name on OTA")); tree.column("chambre", width=170, anchor="w")
        tree.heading("notre",   text=tr_("Our room")); tree.column("notre",   width=170, anchor="w")
        tree.heading("prix",    text=tr_("INR Price"));      tree.column("prix",    width=90,  anchor="center")
        tree.heading("details", text=tr_("Details captured")); tree.column("details", width=210, anchor="w")
        tree.heading("st",      text="");                   tree.column("st",      width=36,  anchor="center")
        sb = ttk.Scrollbar(tf, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        tree.tag_configure("ok",      foreground=T.GREEN)
        tree.tag_configure("pending", foreground=T.YELLOW)

        stop_ev  = threading.Event()
        cmd_q    = queue.Queue()
        records  = []       # [{"room","sel_room","price"(int|None),"price_sel","attrs":{key:{"text","sel","inr"?}}}]
        pending  = [None]   # {"text": ...}: first room still without a final price
        sels     = []       # [{"type": <field key>, "text":, "sel":}] — full click history
        page_ref = [None]

        def _prices_in(txt):
            """Prices read in the text of an element hand-DESIGNATED as a price.

            Single rule, shared by click validation and table rebuilding.
            The two used to be done separately: a text accepted by one could
            be rejected by the other, and the line stayed stuck on
            "⏳ price…" with no message explaining why.

            Two levels:
              1. normal reading (amount + recognized currency);
              2. failing that, digits alone, in the OTA's currency. Safe here
                 — unlike an automatic page reading — since the operator
                 clicked THIS element and answered "price": there is nothing
                 to guess. Two digits minimum, so as not to take
                 "2 travellers" for a rate.
            """
            found = _text_to_inr_prices(txt, config=self.app.config,
                                        fallback_currency=src_cur)
            if found:
                return found
            try:
                from scraping.scraping import money_amount
                _rate = _mrates.get(src_cur.upper(),
                                    _mrates.get(src_cur, 1.0)) or 1.0
            except Exception:
                return []
            out = []
            for _m in _re.finditer(r'\d{1,3}(?:[,    ]\d{3})+|\d{2,}',
                                   txt or ""):
                _v = money_amount(_m.group())
                if _v is None:
                    continue
                _inr = int(round(_v * _rate))
                if 300 <= _inr <= 500_000 and _inr not in out:
                    out.append(_inr)
            return sorted(out)

        def _rebuild():
            # Groups the clicks by room: a "room" click opens a new record;
            # any attribute click (final price, crossed-out, discount, rate
            # type, taxes, occupancy, loyalty) attaches to the most recently
            # opened room. Prices respect the currency displayed by the OTA
            # (source_currency) instead of treating the numbers as INR.
            records.clear(); pending[0] = None
            cur_rec = None
            for s in sels:
                ftype = s["type"]
                if ftype == "room":
                    cur_rec = {"room": s["text"], "sel_room": s.get("sel", ""),
                               "price": None, "price_sel": "", "attrs": {},
                               "price_anchor": {}, "our": ""}
                    records.append(cur_rec)
                    continue
                if cur_rec is None:
                    continue  # attribute without room: ignored (already blocked upstream)
                if ftype == "price":
                    found = _prices_in(s["text"])
                    if found:
                        cur_rec["price"]      = found[0]
                        cur_rec["price_sel"]  = s.get("sel", "")
                        # Exact position of the clicked button: it is what will
                        # be re-read in phase 1, not "an element resembling it"
                        # (see _wiz_extract_prices, level 0.3).
                        cur_rec["price_anchor"] = {
                            "path":   s.get("path", ""),
                            "idx":    s.get("idx", -1),
                            "sel":    s.get("sel", ""),
                            "nmatch": s.get("nmatch", 0)}
                elif ftype in ("strike", "tax_incl"):
                    found = _prices_in(s["text"])
                    cur_rec["attrs"][ftype] = {
                        "text": s["text"], "sel": s.get("sel", ""),
                        "inr":  (found[0] if found else None)}
                else:
                    cur_rec["attrs"][ftype] = {"text": s["text"],
                                               "sel": s.get("sel", "")}
            # First room still without a final price → "⏳ price…" hint
            for r in records:
                if r["price"] is None:
                    pending[0] = {"text": r["room"]}
                    break
            _remap()

        def _remap():
            """Proposes an "OTA name → our room" mapping for each line. The
            choices made by hand by the operator (`manual_map`) take priority
            and are never rewritten; the rest is assigned globally, safest
            pair first, and left EMPTY when two of our rooms compete for the
            same name."""
            from core.room_match import match_rooms, normalize_room_name
            from core import room_names as _rn2690
            _prof_al = _rn2690.aliases(oid)   # D108: single file
            for r in records:
                r["our"] = manual_map.get(normalize_room_name(r["room"]), None)
            _taken = {r["our"] for r in records if r["our"]}
            _free_rooms = [x for x in _our_rooms if x not in _taken]
            _idx_free = [i for i, r in enumerate(records) if r["our"] is None]
            if _idx_free and _free_rooms:
                _auto, _ = match_rooms([records[i]["room"] for i in _idx_free],
                                       _free_rooms, aliases=_prof_al)
                for _pos, _our in _auto.items():
                    records[_idx_free[_pos]]["our"] = _our
            for r in records:
                if not r["our"]:
                    r["our"] = ""

        def _attrs_summary(attrs):
            """Compact summary of the captured attributes for the "Details" column."""
            parts = []
            if "strike" in attrs:
                _inr = attrs["strike"].get("inr")
                parts.append(f"crossed ₹{_inr:,}" if _inr
                             else "crossed " + attrs["strike"]["text"][:10])
            if "discount" in attrs:
                parts.append(attrs["discount"]["text"][:10])
            if "rate_type" in attrs:
                parts.append(attrs["rate_type"]["text"][:16])
            if "tax_incl" in attrs:
                _inr = attrs["tax_incl"].get("inr")
                parts.append(f"taxes ₹{_inr:,}" if _inr else "taxes incl.")
            if "occupancy" in attrs:
                parts.append(attrs["occupancy"]["text"][:12])
            if "loyalty" in attrs:
                parts.append(attrs["loyalty"]["text"][:14])
            return "  ·  ".join(parts)

        def _refresh():
            tree.delete(*tree.get_children())
            n_complete = 0
            n_unmapped = 0
            for _i, r in enumerate(records):
                _det = _attrs_summary(r["attrs"])
                _our = r.get("our") or "❓ to specify"
                if not r.get("our"):
                    n_unmapped += 1
                if r["price"] is not None:
                    n_complete += 1
                    tree.insert("", "end", iid=str(_i),
                                values=(r["room"], _our, f"₹{r['price']:,}", _det, "✅"),
                                tags=("ok" if r.get("our") else "pending",))
                else:
                    tree.insert("", "end", iid=str(_i),
                                values=(r["room"], _our, "⏳ price…", _det, "⏳"),
                                tags=("pending",))
            done_btn.config(state="normal" if n_complete else "disabled")
            undo_btn.config(state="normal" if sels else "disabled")
            if n_unmapped and records:
                status_var.set(
                    f"❓ {n_unmapped} line(s) without mapping — select it "
                    "then choose our room below")
            elif n_complete:
                status_var.set(
                    f"✅ {n_complete} room(s) ready — continue or click Apply")
            elif pending[0]:
                status_var.set(
                    f"🟦 \"{pending[0]['text']}\" — now click its final price")
            else:
                status_var.set(
                    "Click an element in Chrome, then choose its type")

        def _selected_record():
            sel = tree.selection()
            if not sel:
                return None, None
            try:
                return int(sel[0]), records[int(sel[0])]
            except (ValueError, IndexError):
                return None, None

        def _on_tree_select(_e=None):
            _i, r = _selected_record()
            map_var.set((r.get("our") or "") if r else "")

        def _on_map_choice(_e=None):
            """Manual correction of the selected line's mapping."""
            from core.room_match import normalize_room_name
            _i, r = _selected_record()
            if r is None:
                return
            choice = map_var.get()
            key = normalize_room_name(r["room"])
            if choice and choice != _IGNORE_LBL:
                # One of our rooms can only be matched to a single line:
                # free the line that held it to avoid two prices on the same
                # room (the last one would silently overwrite the first).
                for _k, _v in list(manual_map.items()):
                    if _v == choice and _k != key:
                        manual_map.pop(_k, None)
                manual_map[key] = choice
            else:
                manual_map[key] = ""
            _remap(); _refresh()
            try:
                tree.selection_set(str(_i)); tree.see(str(_i))
            except Exception:
                pass

        tree.bind("<<TreeviewSelect>>", _on_tree_select)
        map_cb.bind("<<ComboboxSelected>>", _on_map_choice)

        def _set_waiting():
            preview_var.set(tr_("(no click waiting)"))
            for b in _all_click_btns:
                b.config(state="disabled")

        def _on_captured(text):
            preview_var.set(tr_("👆 Captured: “{t}”\nChoose what it was:").format(t=text[:60]))
            for b in _all_click_btns:
                b.config(state="normal")

        # A text made only of digits/currency cannot be a room name — it is
        # the "price recorded instead of the name" symptom.
        import re as _re
        _price_like_re = _re.compile(
            r"^[\s₹₨₭$€£]*(?:INR|USD|EUR|GBP|AED|Rs\.?)?\s*[\d][\d\s.,]*$", _re.I)

        def _is_price_like(text):
            return bool(_price_like_re.match((text or "").strip()))

        def _on_bad_assign(msg, text):
            # Refused assignment: keep the click pending and hand control back
            # to the user to choose again (Name / Price / Reject).
            preview_var.set(msg + "\n" + tr_("👆 Captured: “{t}”\nChoose what it was:").format(t=text[:60]))
            for b in _all_click_btns:
                b.config(state="normal")

        def _assign(field):
            cmd_q.put(f"assign:{field}")
            _set_waiting()

        def _reject():
            cmd_q.put("reject")
            _set_waiting()

        def _undo():
            cmd_q.put("undo")

        def _apply():
            complete = [r for r in records if r["price"] is not None]
            if not complete:
                return
            # A line without a mapping is NOT recorded: its price would
            # otherwise populate a pseudo-room carrying the OTA's label
            # (that is how Agoda ended up with 8 rooms instead of 4).
            _sans_map = [r["room"] for r in complete if not r.get("our")]
            complete = [r for r in complete if r.get("our")]
            if not complete:
                messagebox.showwarning(
                    tr_("Calibration"),
                    tr_("No lines are connected to any of your rooms.\nSelect each line and choose the corresponding room before applying."),
                    parent=dlg)
                return
            if _sans_map:
                if not messagebox.askyesno(
                        tr_("Calibration"),
                        tr_("{n} unmatched line(s) will be ignored:\n{lst}\n\nContinue?").format(
                            n=len(_sans_map),
                            lst="\n".join("• " + x[:60] for x in _sans_map[:6])),
                        parent=dlg):
                    return
            stop_ev.set()
            from collections import Counter as _Ctr
            from core.room_match import learn_aliases as _learn_aliases
            manual_attrs = {}     # {room: {field: {"text","sel","inr"?}}}
            field_sels   = {}     # {field: [selectors]} → keep the most frequent
            price_sels   = []     # selectors of the FINAL prices (unchanged)
            room_sels    = []     # selectors of the room NAMES
            price_anchors = {}    # {our room: exact position of the clicked button}
            # Mappings validated on screen → memorized in THE single
            # file (D108): base = what already lives there.
            from core import room_names as _rn2871
            self._wiz_room_aliases = _learn_aliases(
                _rn2871.aliases(oid),
                [(r["room"], r["our"]) for r in complete])
            for r in complete:
                # Key = OUR room name (not the OTA's label): prices, the
                # learned history and later readings all speak the same
                # vocabulary.
                room = r["our"]
                self._wiz_prices[room]      = r["price"]
                self._wiz_validations[room] = True
                if r.get("price_sel"):
                    price_sels.append(r["price_sel"])
                if r.get("sel_room"):
                    room_sels.append(r["sel_room"])
                # Position anchor: kept ONLY if it is better than the selector
                # alone, i.e. if there is a unique path or a known rank.
                # Otherwise nothing is stored, and the usual reading
                # (levels 0.4/0.5) takes over exactly as before.
                _anc = r.get("price_anchor") or {}
                if _anc.get("path") or (_anc.get("idx", -1) >= 0 and _anc.get("sel")):
                    price_anchors[room] = {
                        "path":   _anc.get("path", ""),
                        "idx":    _anc.get("idx", -1),
                        "sel":    _anc.get("sel", ""),
                        "nmatch": _anc.get("nmatch", 0)}
                if r["attrs"]:
                    manual_attrs[room] = dict(r["attrs"])
                    for _fk, _d in r["attrs"].items():
                        if _d.get("sel"):
                            field_sels.setdefault(_fk, []).append(_d["sel"])
            # Most frequent FINAL PRICE CSS selector — UNCHANGED: it is the
            # one the scans already use ("manual_css_selector", Level 0.5).
            if price_sels:
                self._wiz_manual_css_sel = _Ctr(price_sels).most_common(1)[0][0]
            self._wiz_manual_price_anchors = price_anchors
            # New: attributes captured per room + most frequent selector per
            # field (strike, discount, taxes…), stored for future use by the engine.
            self._wiz_manual_attrs      = manual_attrs
            self._wiz_manual_field_sels = {
                _fk: _Ctr(_sl).most_common(1)[0][0]
                for _fk, _sl in field_sels.items() if _sl}
            # The FINAL PRICE and the ROOM NAME have their own slot in each
            # record — they do not go through `attrs`, so they NEVER arrived
            # here. Yet the card reader requires `price` (otherwise it returns
            # an empty card and the adaptive formula does not kick in) and uses
            # `room` to delimit the offer card. Added so future calibrations
            # are usable as-is.
            if price_sels:
                self._wiz_manual_field_sels["price"] = \
                    _Ctr(price_sels).most_common(1)[0][0]
            if room_sels:
                self._wiz_manual_field_sels["room"] = \
                    _Ctr(room_sels).most_common(1)[0][0]
            dlg.destroy()
            self._show_step(4)

        def _on_close():
            stop_ev.set(); dlg.destroy()
        dlg.protocol("WM_DELETE_WINDOW", _on_close)

        def _chrome_thread():
            try:
                from scraping.browser_driver import sync_playwright
                from scraping.chrome_manager import (
                    launch_context, apply_stealth, wipe_profile)
                from scraping.scraping import ota_launch_quirks
                import sys as _sp
                if _sp.platform == "win32" and _sp.stderr is None:
                    import ctypes as _ct
                    _k32 = _ct.windll.kernel32
                    if _k32.GetConsoleWindow() == 0:
                        _k32.AllocConsole()
                        _ch = _k32.GetConsoleWindow()
                        if _ch:
                            _ct.windll.user32.ShowWindow(_ch, 0)
                    try:
                        _sp.stderr = open("CONOUT$", "w")
                    except Exception:
                        import os as _os
                        _sp.stderr = open(_os.devnull, "w")

                _quirks = ota_launch_quirks(self._wiz_ota[0] if self._wiz_ota else None)
                # Same profile as phase 1: specific to this OTA.
                _prof_id = self._calib_profile_id()
                # Same rule as in phase 1: OTAs flagged
                # "calib_fresh_profile" start from a blank profile at
                # EVERY Chrome opening, this one included (otherwise
                # phase 2 would reopen the profile that phase 1 just
                # got the site to flag).
                if _quirks.get("calib_fresh_profile"):
                    wipe_profile(_prof_id)
                    self._log("🧹 Browsing profile wiped clean "
                              "(required by this OTA)", "info")
                with sync_playwright() as pw:
                    def _open_ctx_page2():
                        """Opens a new context + page. Isolated so it can be
                        relaunched identically on an empty/blocked page
                        (retry after goto, below)."""
                        # This Chrome (element selection) is a SEPARATE launch
                        # from the phase 1 one (navigation) earlier in the
                        # file — it needs the same mobile settings, otherwise
                        # it always starts in desktop format even if phase 1
                        # was in phone format.
                        if getattr(self, "_wiz_mode", "desktop") == "mobile":
                            _MOB_UA_C2 = ("Mozilla/5.0 (Linux; Android 14; SM-S918B) "
                                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                                          "Chrome/120.0.0.0 Mobile Safari/537.36")
                            try:
                                _ctx, _ = launch_context(
                                    pw, _prof_id, headless=False,
                                    keep_user_agent=True,
                                    extra_args=["--window-size=400,980"]
                                               + _quirks.get("extra_args", []),
                                    user_agent=_MOB_UA_C2,
                                    viewport={"width": 390, "height": 844},
                                    is_mobile=True, has_touch=True)
                            except Exception as _emob2:
                                self._log(f"⚠ Phone emulation unavailable ({_emob2}) "
                                          f"— plain display", "error")
                                _ctx, _ = launch_context(pw, _prof_id, headless=False,
                                                         extra_args=_quirks.get("extra_args"),
                                                         user_agent=_MOB_UA_C2,
                                                         viewport={"width": 390, "height": 844})
                        else:
                            _ctx, _ = launch_context(pw, _prof_id, headless=False,
                                                     extra_args=_quirks.get("extra_args"),
                                                     viewport={"width": 1366, "height": 768})
                        _pg = _ctx.new_page()
                        apply_stealth(_pg)
                        return _ctx, _pg

                    # Zombie Chrome: guarantee ctx.close() even if the body
                    # crashes — otherwise chrome.exe stays open in the background.
                    try:
                        ctx, page = _open_ctx_page2()
                        page_ref[0] = page

                        def _inject_js():
                            for _ in range(3):
                                try:
                                    page.evaluate(self._MANUAL_SCAN_JS)
                                    return True
                                except Exception:
                                    stop_ev.wait(0.3)
                            return False

                        def _set_banner(t):
                            try:
                                page.evaluate(
                                    "(t) => { window.__mscan_banner && "
                                    "window.__mscan_banner(t); }", t)
                            except Exception:
                                pass

                        def _drop_stale_click():
                            # Drop any click memorized on the page side while
                            # waiting for confirmation — otherwise it would
                            # surface later and be recorded under the wrong
                            # role (ghost click).
                            try:
                                page.evaluate("window.__mscan_click = null")
                            except Exception:
                                pass

                        dlg.after(0, lambda: status_var.set(
                            "⏳ Chrome open — loading the page…" if start_url else
                            "✅ Chrome open — navigate to the price page then click"))
                        if start_url:
                            try:
                                page.goto(start_url,
                                          wait_until=_quirks.get("goto_wait_until", "domcontentloaded"),
                                          timeout=_quirks.get("goto_timeout_ms", 30000))
                            except Exception as _e_goto:
                                _msg_goto = str(_e_goto).splitlines()[0]
                                dlg.after(0, lambda m=_msg_goto: status_var.set(
                                    f"⚠ Page not loaded ({m}) — navigate manually to the price page"))
                            _inject_js()
                            # Give the JS rendering (SPA) time to run before
                            # judging the page empty — see the equivalent
                            # phase 1 comment.
                            try:
                                page.wait_for_timeout(3000)
                            except Exception:
                                pass

                            # No automatic retry here (same choice as the
                            # phase 1 navigation): the old heuristic also
                            # fired on good pages and the forced reload lost
                            # the correct state. The "🧹 New profile" button
                            # injected on the page (see _MANUAL_SCAN_JS) lets
                            # the user judge and relaunch if needed — detected
                            # in the capture loop below.
                            dlg.after(0, lambda: status_var.set(
                                "✅ Page loaded — click an element then choose its type"))

                        awaiting = [False]   # a click was captured, waiting for assign/reject
                        pending_click = None
                        while not stop_ev.is_set():
                            try:
                                if page.is_closed():
                                    break

                                try:
                                    _np_req = page.evaluate(
                                        "()=>{var r=!!window.__mscan_new_profile_requested;"
                                        "window.__mscan_new_profile_requested=false;return r;}")
                                except Exception:
                                    _np_req = False
                                if _np_req:
                                    # "🧹 New profile" button clicked on the
                                    # page — same mechanism as the old
                                    # automatic retry, but triggered by the
                                    # user instead of a heuristic.
                                    awaiting[0] = False
                                    pending_click = None
                                    dlg.after(0, _set_waiting)
                                    dlg.after(0, lambda: status_var.set(
                                        "🧹 New profile requested — relaunching…"))
                                    try:
                                        ctx.close()
                                    except Exception:
                                        pass
                                    try:
                                        wipe_profile(_prof_id)
                                    except Exception:
                                        pass
                                    ctx, page = _open_ctx_page2()
                                    page_ref[0] = page
                                    if start_url:
                                        try:
                                            page.goto(start_url,
                                                     wait_until=_quirks.get("goto_wait_until", "domcontentloaded"),
                                                     timeout=_quirks.get("goto_timeout_ms", 30000))
                                            _inject_js()
                                            page.wait_for_timeout(3000)
                                            dlg.after(0, lambda: status_var.set(
                                                "✅ Page loaded — click an element then choose its type"))
                                        except Exception:
                                            pass
                                    else:
                                        _inject_js()
                                        dlg.after(0, lambda: status_var.set(
                                            "✅ Fresh profile — navigate to the price page then click"))
                                    continue

                                if not awaiting[0]:
                                    try:
                                        data = page.evaluate(
                                            "() => { var v = window.__mscan_click; "
                                            "window.__mscan_click = null; return v; }")
                                    except Exception:
                                        # Navigation/reload: the JS context was
                                        # destroyed, it must be re-injected
                                        # otherwise nothing is captured anymore.
                                        _inject_js()
                                        data = None
                                    if data:
                                        awaiting[0] = True
                                        pending_click = data
                                        dlg.after(0, lambda t=data["text"]: _on_captured(t))

                                try:
                                    cmd = cmd_q.get_nowait()
                                except queue.Empty:
                                    cmd = None

                                if cmd == "undo":
                                    if sels:
                                        sels.pop()
                                        _rebuild()
                                        dlg.after(0, _refresh)
                                elif cmd == "reject":
                                    awaiting[0] = False
                                    pending_click = None
                                    _drop_stale_click()
                                    _set_banner("Click an element, then choose its type")
                                elif cmd and cmd.startswith("assign:"):
                                    field = cmd[7:]
                                    _txt  = pending_click["text"] if pending_click else ""
                                    _has_room = any(x["type"] == "room" for x in sels)
                                    if not pending_click:
                                        # Lost click (page reloaded in the
                                        # meantime): record nothing rather
                                        # than a stale element.
                                        awaiting[0] = False
                                        _drop_stale_click()
                                        _set_banner("Click lost — click the element again")
                                    elif field == "room" and _is_price_like(_txt):
                                        # Refusal: a price cannot be a room name.
                                        dlg.after(0, lambda t=_txt: _on_bad_assign(
                                            tr_("⚠ This text looks like a PRICE, not a room name."), t))
                                    elif field != "room" and not _has_room:
                                        # An attribute (price, strike, discount…)
                                        # must attach to a room: a room name must
                                        # be clicked first.
                                        dlg.after(0, lambda t=_txt: _on_bad_assign(
                                            tr_("⚠ First click a ROOM NAME, then its attributes."), t))
                                    elif field in _PRICE_FIELDS and not _prices_in(_txt):
                                        # Refusal: no readable price (final /
                                        # strike / taxes) — otherwise the element
                                        # would silently vanish in _rebuild().
                                        dlg.after(0, lambda t=_txt: _on_bad_assign(
                                            tr_("⚠ No prices readable in this text."), t))
                                    elif field == "discount" and not any(c.isdigit() for c in _txt):
                                        # Refusal: a discount must contain a number (e.g. "-20%").
                                        dlg.after(0, lambda t=_txt: _on_bad_assign(
                                            tr_("⚠ No percentage readable in this text."), t))
                                    else:
                                        txt = _txt
                                        sels.append({
                                            "type": field, "text": txt,
                                            "sel":  pending_click["sel"],
                                            # Exact click position (see
                                            # _MANUAL_SCAN_JS) — `.get`
                                            # because a click captured before
                                            # JS re-injection may lack them.
                                            "path":   pending_click.get("path", ""),
                                            "idx":    pending_click.get("idx", -1),
                                            "nmatch": pending_click.get("nmatch", 0)})
                                        awaiting[0] = False
                                        pending_click = None
                                        _drop_stale_click()
                                        _rebuild()
                                        dlg.after(0, _refresh)
                                        _set_banner(f"\"{txt[:40]}\" recorded as "
                                                    f"{_FIELD_LABEL.get(field, field)} — click the next element")
                            except Exception:
                                pass
                            stop_ev.wait(0.3)
                    finally:
                        try:
                            ctx.close()
                        except Exception:
                            pass
                        page_ref[0] = None
            except Exception as _e:
                _msg = str(_e)
                dlg.after(0, lambda m=_msg: status_var.set(f"❌ Error: {m}"))

        threading.Thread(target=_chrome_thread, daemon=True).start()

    # ── Step 5: Done ──────────────────────────────────────────────────────

    def _step_5_done(self):
        m = self._wiz_main
        oid, name = self._wiz_ota
        profile  = self._get_profile(oid)
        n_prices = len(profile.get("prices_found", {}))
        n_learn  = sum(1 for p in profile.get("prices_learned", {}).values()
                       if p.get("count", 0) >= 3)
        n_clicks = len(profile.get("action_sequence", []))
        cur      = profile.get("source_currency", "INR")

        # Success title
        title = tk.Frame(m, bg=T.BG)
        title.pack(fill="x", pady=(0, 20))
        lbl(title, "✅", bg=T.BG, size=32).pack(side="left", padx=(0, 12))
        txt = tk.Frame(title, bg=T.BG)
        txt.pack(side="left")
        lbl(txt, tr_("{name} calibrated!").format(name=name), bold=True, size=16).pack(anchor="w")
        lbl(txt, tr_("Your OTA Price Block scans will now be more accurate."),
            color="#888", size=9).pack(anchor="w")

        # Summary
        summary = tk.Frame(m, bg=T.ENTRY_BG, padx=20, pady=14)
        summary.pack(fill="x")
        for icon, label, val in [
                ("📊", "Rooms detected", f"{n_prices}"),
                ("🧠", "Rooms learned (≥3 scans)", f"{n_learn}"),
                ("💱", "Currency displayed by this OTA", cur),
                ("🖱️", "Clicks recorded (popups + nav)", f"{n_clicks}"),
                ("🌐", "Validated URL", profile.get("good_url", "—")[:60] + "…"
                  if len(profile.get("good_url", "")) > 60 else profile.get("good_url", "—")),
        ]:
            r = tk.Frame(summary, bg=T.ENTRY_BG); r.pack(fill="x", pady=3)
            lbl(r, icon, bg=T.ENTRY_BG, size=11).pack(side="left", padx=(0, 8))
            lbl(r, label + " :", bg=T.ENTRY_BG, size=10).pack(side="left")
            lbl(r, val, bg=T.ENTRY_BG, color=T.ACCENT, bold=True, size=10
                ).pack(side="right")

        # Tip
        tip = tk.Frame(m, bg="#1a2a1a", padx=14, pady=10)
        tip.pack(fill="x", pady=(20, 0))
        lbl(tip, tr_("💡 Tip"),
            bg="#1a2a1a", color=T.GREEN, bold=True, size=9).pack(anchor="w")
        lbl(tip, tr_("The more you scan (OTA price lock → Scan), the more the calibration becomes refined: the reference price range is automatically specified with each successful scan.")
                 ,
            bg="#1a2a1a", color="#ccc", size=9, wraplength=600
            ).pack(anchor="w", pady=(2, 0))

        # Boutons
        bbar = tk.Frame(m, bg=T.BG)
        bbar.pack(fill="x", pady=(24, 0))
        btn(bbar, tr_("🔄 Calibrate another OTA"), self._step5_another,
            color=T.ACCENT, width=24).pack(side="left")
        btn(bbar, tr_("✓ Finish"), self._step5_finish,
            color=T.GREEN, width=14).pack(side="right")

    def _step5_another(self):
        # Reset state + back to the overview (refreshed cards)
        self._wiz_ota          = None
        self._wiz_url          = ""
        self._wiz_actions      = []
        self._wiz_urls_visited = []
        self._wiz_good_url     = ""
        self._wiz_last_url_with_prices = ""
        self._wiz_prices       = {}
        self._wiz_raw_prices   = []
        self._wiz_validations  = {}
        self._wiz_detected_cur = ""
        # Reset the manual calibration data so it does not leak onto the
        # next OTA if the latter is not manually recalibrated.
        self._wiz_manual_css_sel    = ""
        self._wiz_manual_attrs      = {}
        self._wiz_manual_field_sels = {}
        self._wiz_room_aliases      = {}
        # Launch recipe + automatically detected anchors: specific to the OTA
        # just calibrated, never carried over to the next one.
        self._wiz_launch_quirks     = {}
        self._wiz_auto_sels         = {}
        self._calib_data       = self._calib_load()   # reload fresh data
        self._show_step(1)

    def _step5_finish(self):
        self._step5_another()

    # ─────────────────────────────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────────────────────────────

    def _set_status(self, text: str, color: str):
        try:
            self.app.root.after(0, lambda: self._wiz_status_lbl.config(
                text=text, fg=color))
        except Exception:
            pass

    def _log(self, text: str, tag: str = "info"):
        def _do():
            try:
                w = self._log_txt
                w.config(state="normal")
                ts = datetime.now().strftime("%H:%M:%S")
                w.insert("end", f"[{ts}] {text}\n", tag)
                w.see("end")
                w.config(state="disabled")
            except Exception:
                pass
        self.app.root.after(0, _do)

    def _log_clear(self):
        try:
            self._log_txt.config(state="normal")
            self._log_txt.delete("1.0", "end")
            self._log_txt.config(state="disabled")
        except Exception:
            pass

    # ── OTA list ──────────────────────────────────────────────────────────

    def _get_ota_list(self) -> list:
        """[(ota_id, ota_name), ...] from ota_watch."""
        result = []
        ota_watch = self.app.config.get("ota_watch", {})
        for ota in ota_watch.get("otas", []):
            if not ota.get("active") or not ota.get("url", "").startswith("http"):
                continue
            name = ota.get("name", "OTA")
            result.append((self._name_to_id(name), name))
        ref = ota_watch.get("reference", {})
        if ref.get("active") and ref.get("url", "").startswith("http"):
            name = ref.get("name", "Reference")
            result.append((self._name_to_id(name), name))
        return result

    def _calib_profile_id(self) -> str:
        """Chrome profile folder used by the calibration, PER OTA.

        Before, all OTAs shared the "calib_nav" folder: the state left by
        one OTA's calibration was what the next one found, and a wipe done
        for one restarted from zero for all. Each OTA now has its own, like
        the automatic reading which already uses "scraping_<ota_id>".

        Agoda deliberately keeps the historical "calib_nav" folder:
        unchanged behavior, on explicit request.
        """
        oid = (self._wiz_ota[0] if getattr(self, "_wiz_ota", None) else "") or ""
        if not oid or oid == "agoda":
            return "calib_nav"
        # An unknown OTA id comes from a name typed by the user: reduce it
        # to characters valid for a Windows folder name.
        safe = "".join(c if (c.isalnum() or c in "_-") else "_" for c in oid.lower())
        return f"calib_nav_{safe}" if safe.strip("_") else "calib_nav"

    def _name_to_id(self, name: str) -> str:
        n = name.lower()
        if "agoda" in n:      return "agoda"
        if "booking" in n:    return "booking"
        if "makemytrip" in n: return "makemytrip"
        if "google" in n:     return "google_hotels"
        return n.replace(" ", "_")

    def _get_ota_url(self, ota_id: str) -> str:
        ota_watch = self.app.config.get("ota_watch", {})
        target = None
        for o, n in self._get_ota_list():
            if o == ota_id:
                target = n
                break
        for ota in ota_watch.get("otas", []):
            if ota.get("name") == target or self._name_to_id(ota.get("name", "")) == ota_id:
                return ota.get("url", "")
        ref = ota_watch.get("reference", {})
        if self._name_to_id(ref.get("name", "")) == ota_id:
            return ref.get("url", "")
        return ""

    # ── Calibration data ──────────────────────────────────────────────────

    def _calib_load(self) -> dict:
        try:
            return load_calib_data()
        except Exception:
            pass
        return {"profiles": {}, "scan_results": {}}

    def _calib_save(self) -> bool:
        ok = save_calib_data(self._calib_data)
        if not ok:
            try:
                self.app._log_journal(
                    "❌ Calibration save failed",
                    level="error", engine="CALIBRATION")
            except Exception:
                pass
        return ok

    def _profile_key(self, ota_id: str) -> str:
        return f"{self.app.config.get('hotel_name', 'hotel')}||{ota_id}"

    def _get_profile(self, ota_id: str) -> dict:
        # Compatibility: tries the new key then the old one (OTA name only)
        profiles = self._calib_data.setdefault("profiles", {})
        new_key = self._profile_key(ota_id)
        if new_key in profiles:
            return profiles[new_key]
        # Lookup by name (old format)
        for k, v in profiles.items():
            if v.get("ota") == ota_id:
                return v
        # Lookup by direct key (e.g. "Agoda")
        for o, n in self._get_ota_list():
            if o == ota_id and n in profiles:
                return profiles[n]
        return {}

    def _set_profile(self, ota_id: str, profile: dict) -> bool:
        self._calib_data.setdefault("profiles", {})[
            self._profile_key(ota_id)] = profile
        self._cleanup_orphan_profiles(ota_id)
        return self._calib_save()

    def _save_launch_quirks(self, ota_id: str) -> None:
        """Records the launch recipe found for this OTA.

        Written right away (not at the end of the wizard): it is a finding
        about the browser, independent of whether the user goes through the
        whole calibration. It is stored in the OTA's file, next to the rest,
        and later read back by ota_launch_quirks() — so it applies to the
        price reading as well as to the next calibration.

        Called from the Tk thread (via after): `self._calib_data` is the same
        dictionary as the one used by _step4_save, so there are no two
        concurrent writes that could overwrite each other.
        """
        _q = getattr(self, "_wiz_launch_quirks", None)
        if not ota_id or not _q:
            return
        try:
            prof = self._get_profile(ota_id) or {}
            if prof.get("launch_quirks") == _q:
                return
            prof["launch_quirks"] = dict(_q)
            if not self._set_profile(ota_id, prof):
                self._log("❌ Launch recipe not saved "
                          "(see log)", "err")
                return
            from scraping.scraping import invalidate_saved_launch_quirks
            invalidate_saved_launch_quirks()
            self._log(f"💾 Launch recipe memorized for this OTA: "
                      f"{_q.get('recipe', '')}", "ok")
        except Exception as e:
            self._log(f"⚠ Launch recipe not saved: {e}", "err")

    def _save_scan_wipe(self, ota_id: str, var) -> None:
        """Records the "blank browser on every automatic reading" choice for
        ONE OTA.

        Written to this OTA's file (data\\calibration_data_<ota>.json,
        "scan_options" key), next to the rest of its calibration — never into
        a setting common to all OTAs. Later read back by
        scraping.scan_wipe_profile() during the automatic reading.
        """
        _on = bool(var.get())
        try:
            prof  = self._get_profile(ota_id) or {}
            _opts = dict(prof.get("scan_options") or {})
            if _opts.get("wipe_profile") == _on:
                return
            _opts["wipe_profile"] = _on
            prof["scan_options"]  = _opts
            if not self._set_profile(ota_id, prof):
                self._log("❌ Setting not saved (see log)", "err")
                var.set(not _on)     # the checkbox must not display a false state
                return
            self._log(
                f"💾 {ota_id}: "
                + ("blank browser on every automatic reading"
                   if _on else
                   "browsing memory kept between readings"),
                "ok")
        except Exception as e:
            self._log(f"⚠ Setting not saved: {e}", "err")
            try:
                var.set(not _on)
            except Exception:
                pass

    def _cleanup_orphan_profiles(self, ota_id: str):
        """Deletes old-format key entries (OTA name alone, or matching 'ota'
        field) that became orphans now that the profile exists under the
        current key (hotel_name||ota_id). Nothing is deleted until the new
        key exists — the old entry then remains the only valid source (see
        _get_profile)."""
        profiles = self._calib_data.get("profiles", {})
        new_key = self._profile_key(ota_id)
        if new_key not in profiles:
            return
        name = next((n for o, n in self._get_ota_list() if o == ota_id), None)
        stale_keys = [k for k, v in profiles.items()
                      if k != new_key and (v.get("ota") == ota_id or k == name)]
        for k in stale_keys:
            del profiles[k]
            self._log(f"🧹 Old calibration entry deleted: {k}", "info")

    def _update_prices_learned(self, profile: dict, prices_found: dict):
        learned = profile.setdefault("prices_learned", {})
        for room, price in prices_found.items():
            if not price:
                continue
            e = learned.setdefault(room, {
                "avg": price, "min": price, "max": price,
                "count": 0, "history": []})
            e["history"].append(price)
            if len(e["history"]) > 30:
                e["history"] = e["history"][-30:]
            e["count"] = len(e["history"])
            e["avg"]   = int(sum(e["history"]) / e["count"])
            e["min"]   = min(e["history"])
            e["max"]   = max(e["history"])
        profile.setdefault("sessions", []).append({
            "ts":      datetime.now().strftime("%Y-%m-%d %H:%M"),
            "type":    "wizard",
            "prices":  prices_found,
            "n_rooms": len(prices_found),
        })
        if len(profile["sessions"]) > 20:
            profile["sessions"] = profile["sessions"][-20:]

    # ── Currency detection ────────────────────────────────────────────────

    _SYM_TO_CUR = [
        ("₹",  "INR"), ("₨",  "INR"), ("₭",  "LAK"), ("฿",  "THB"),
        ("€",  "EUR"), ("£",  "GBP"), ("₱",  "PHP"), ("₩",  "KRW"),
        ("₫",  "VND"), ("¥",  "JPY"), ("Rp", "IDR"), ("RM", "MYR"),
        ("Rs", "INR"), ("$",  "USD"),
    ]
    _WORD_CUR = ("INR", "LAK", "EUR", "USD", "THB", "GBP", "JPY",
                 "KRW", "CNY", "VND", "PHP", "AED", "SGD", "AUD",
                 "CAD", "HKD", "MYR", "IDR", "NPR", "BDT", "LKR",
                 "PKR", "MMK", "KHR", "CHF", "TWD")

    def _detect_currency_from_text(self, text: str) -> str:
        import re as _re
        if not text:
            return ""
        counts = {}
        for sym, cur in self._SYM_TO_CUR:
            n = text.count(sym)
            if n > 0:
                counts[cur] = counts.get(cur, 0) + n
        for cur in self._WORD_CUR:
            matches = _re.findall(rf'\b{cur}\b', text)
            if matches:
                counts[cur] = counts.get(cur, 0) + len(matches)
        if not counts:
            return ""
        return max(counts, key=counts.get)
