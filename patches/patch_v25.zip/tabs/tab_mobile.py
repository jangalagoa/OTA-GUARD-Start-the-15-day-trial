"""
Tab: Mobile app — OTA Guard
Sections:
  1. Firebase connection (PC) — service account (secret, DPAPI-encrypted)
  2. Client config (for the pairing QR) — non-sensitive
  3. Pairing a phone — QR generation
"""
import json
import tkinter as tk
from tkinter import messagebox, filedialog

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame
from core import config as cfg
from core.base_tab import BaseTab
from core.utils import tr_


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app
        tab = frame

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("📱 Mobile app"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📖 Wiki"),
            lambda: self._show_wiki('📱 App mobile'), color="#89b4fa", width=10).pack(side="right")
        btn(topbar, tr_("❓ Configuration help"), self._open_firebase_guide,
            color="#f97316", width=20).pack(side="right", padx=4)
        btn(topbar, tr_("💾 Save"), self._save,
            color=T.GREEN, width=14).pack(side="right", padx=4)

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        mg = self.app.config.get("mobile_gateway", {})
        client = mg.get("firebase_client_config", {})
        self._client_vars = {}
        mn = self.app.config.get("mobile_notifications", {})
        self._notif_vars = {}

        # ══ 1. Firebase service account (secret) ═════════════════════════
        s1 = section(inner, tr_("🔑 Firebase connection (PC)"))
        s1.pack(fill="x", padx=10, pady=8)
        lbl(s1, tr_("Service account file (Admin SDK), downloaded from Firebase Console → Project Settings → Service Accounts.\nThis file is stored encrypted (DPAPI), never in the clear."),
            size=8).pack(anchor="w", pady=(0, 6))

        self._sa_status = lbl(s1, "", bold=True)
        self._sa_status.pack(anchor="w", pady=(0, 6))

        r_sa = tk.Frame(s1, bg=T.BG); r_sa.pack(fill="x", pady=3)
        btn(r_sa, tr_("📂 Load JSON file"), self._load_service_account,
            color=T.ACCENT, width=22).pack(side="left")
        btn(r_sa, tr_("🔌 Test the connection"), self._test_connection,
            color="#94e2d5", width=18).pack(side="left", padx=(6, 0))

        # ══ 2. Client config (for the QR) ═════════════════════════════════
        s2 = section(inner, tr_("📋 Client config (for pairing QR)"))
        s2.pack(fill="x", padx=10, pady=8)
        lbl(s2, tr_("Copy from Firebase Console → Project Settings → Your Apps → SDK Config. Non-sensitive (can be put in a QR)."),
            size=8).pack(anchor="w", pady=(0, 6))

        r_gs = tk.Frame(s2, bg=T.BG); r_gs.pack(fill="x", pady=(0, 6))
        btn(r_gs, tr_("📂 Import google-services.json"), self._load_google_services,
            color=T.ACCENT, width=28).pack(side="left")
        lbl(r_gs, tr_("← fills the 5 boxes automatically"),
            size=8).pack(side="left", padx=(8, 0))

        def _cf(parent, label, key, width=40):
            r = tk.Frame(parent, bg=T.BG); r.pack(fill="x", pady=3)
            lbl(r, label, bold=True, size=9).pack(side="left", padx=(0, 8))
            v = tk.StringVar(value=str(client.get(key, "")))
            entry(r, textvariable=v, width=width).pack(side="left")
            self._client_vars[key] = v

        _cf(s2, "apiKey", "apiKey")
        _cf(s2, "appId", "appId")
        _cf(s2, "messagingSenderId", "messagingSenderId")
        _cf(s2, "projectId", "projectId")
        _cf(s2, "storageBucket " + tr_("(optional)"), "storageBucket")

        # ══ 3. Pairing ═════════════════════════════════════════════════════
        s3 = section(inner, tr_("📲 Pair a phone"))
        s3.pack(fill="x", padx=10, pady=8)
        lbl(s3, tr_("Generates a QR to scan from the OTA Guard mobile app to connect this phone to this Firebase."),
            size=8).pack(anchor="w", pady=(0, 6))
        btn(s3, tr_("📷 Show QR"), self._show_qr,
            color=T.ACCENT, width=18).pack(anchor="w")

        # ══ 4. Mobile notifications ═══════════════════════════════════════
        s4 = section(inner, tr_("🔔 Mobile notifications"))
        s4.pack(fill="x", padx=10, pady=8)
        lbl(s4, tr_("Uncheck alerts to no longer receive on the phone.\nEmail and Telegram (if configured) are not affected — setting specific to the mobile channel."),
            size=8).pack(anchor="w", pady=(0, 6))

        def _nf(parent, label, key):
            r = tk.Frame(parent, bg=T.BG); r.pack(fill="x", pady=2)
            v = tk.BooleanVar(value=bool(mn.get(key, True)))
            tk.Checkbutton(r, text=label, variable=v, bg=T.BG, fg=T.FG,
                           activebackground=T.BG, selectcolor=T.ENTRY_BG,
                           font=("Segoe UI", 9)).pack(side="left")
            self._notif_vars[key] = v

        _nf(s4, tr_("⚠️ Price gap detected on an OTA"), "price_gap_detected")
        _nf(s4, tr_("🔧 Correction sent to Channel Manager"), "correction_envoyee")
        _nf(s4, tr_("🛡️ Floor/ceiling exceedance"), "floor_violation")

        self._refresh_sa_status()

    # ── Service account ────────────────────────────────────────────────────

    def _refresh_sa_status(self):
        try:
            from business.secrets import load_secrets
            sa = load_secrets().get("firebase_service_account") or {}
        except Exception:
            sa = {}
        if sa.get("project_id"):
            self._sa_status.configure(
                text=tr_("✅ Loaded service account — project: {p}").format(p=sa["project_id"]),
                fg=T.GREEN)
        else:
            self._sa_status.configure(
                text=tr_("❌ No service accounts configured"), fg=T.RED)

    # ── Firebase JSON file imports ────────────────────────────────────────
    #
    # Firebase provides TWO different .json files for the same project:
    #   • the service account (Admin SDK)   → secret, encrypted, section 1
    #   • google-services.json (Android app) → holds the 5 QR values
    # They are very easy to confuse (same extension, same console). Both
    # buttons therefore accept both files: the CONTENT decides the
    # handling, not the clicked button. Picking the wrong button no
    # longer produces an error message.

    @staticmethod
    def _is_service_account(data: dict) -> bool:
        return data.get("type") == "service_account" and "project_id" in data

    @staticmethod
    def _is_google_services(data: dict) -> bool:
        return isinstance(data.get("project_info"), dict) and "client" in data

    def _pick_json(self, title):
        path = filedialog.askopenfilename(
            parent=self.app.root, title=title, filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            messagebox.showerror(tr_("Error"), str(e), parent=self.app.root)
            return
        if not isinstance(data, dict):
            data = {}
        if self._is_service_account(data):
            self._apply_service_account(data)
        elif self._is_google_services(data):
            self._apply_google_services(data)
        else:
            messagebox.showerror(
                tr_("Unrecognized file"),
                tr_("This file is neither a Firebase service account (Project Settings → Service Accounts), nor a google-services.json (Project Settings → Your Apps)."),
                parent=self.app.root)

    def _load_service_account(self):
        self._pick_json(tr_("Choose the service account JSON file"))

    def _load_google_services(self):
        self._pick_json(tr_("Choose the google-services.json file"))

    def _apply_service_account(self, data):
        try:
            from business.secrets import save_secrets
            save_secrets({"firebase_service_account": data})
        except Exception as e:
            messagebox.showerror(tr_("Error"), str(e), parent=self.app.root)
            return
        self._refresh_sa_status()
        messagebox.showinfo(tr_("Registered"),
                             tr_("Registered (encrypted) service account."),
                             parent=self.app.root)

    @staticmethod
    def _extract_client_config(data: dict) -> dict:
        """google-services.json → the 5 values expected by the QR.

        The file may describe several applications of the same project; the
        OTA Guard mobile app is an Android app, so the first Android app is
        preferred — a Web app's appId would not work on the phone.
        """
        info = data.get("project_info") or {}
        clients = [c for c in (data.get("client") or []) if isinstance(c, dict)]
        chosen = {}
        for c in clients:
            app_id = str((c.get("client_info") or {}).get("mobilesdk_app_id", ""))
            if ":android:" in app_id:
                chosen = c
                break
        if not chosen and clients:
            chosen = clients[0]
        keys = [k for k in (chosen.get("api_key") or []) if isinstance(k, dict)]
        return {
            "apiKey":            str(keys[0].get("current_key", "")) if keys else "",
            "appId":             str((chosen.get("client_info") or {}).get("mobilesdk_app_id", "")),
            "messagingSenderId": str(info.get("project_number", "")),
            "projectId":         str(info.get("project_id", "")),
            "storageBucket":     str(info.get("storage_bucket", "")),
        }

    def _apply_google_services(self, data):
        vals = self._extract_client_config(data)
        manquants = [k for k in ("apiKey", "appId", "messagingSenderId", "projectId")
                     if not vals.get(k)]
        if manquants:
            messagebox.showerror(
                tr_("Incomplete file"),
                tr_("These values are missing from the file: {v}\nCheck that it is indeed the google-services.json of the Android application.").format(v=", ".join(manquants)),
                parent=self.app.root)
            return
        for k, v in vals.items():
            if v and k in self._client_vars:
                self._client_vars[k].set(v)
        self._save(silencieux=True)
        messagebox.showinfo(
            tr_("Imported"),
            tr_("Client config filled from google-services.json and saved — project: {p}").format(p=vals["projectId"]),
            parent=self.app.root)

    def _test_connection(self):
        try:
            from business.secrets import load_secrets
            sa = load_secrets().get("firebase_service_account") or {}
        except Exception:
            sa = {}
        if not sa.get("project_id"):
            messagebox.showwarning(
                tr_("Not configured"),
                tr_("First loads a service account file."),
                parent=self.app.root)
            return
        try:
            from business import firebase_client
            if not firebase_client.is_available():
                messagebox.showerror(
                    tr_("Missing module"),
                    tr_("The firebase-admin module is not installed."),
                    parent=self.app.root)
                return
            ok = firebase_client.init_firebase(sa)
        except Exception as e:
            messagebox.showerror(tr_("Error"), str(e), parent=self.app.root)
            return
        if ok:
            messagebox.showinfo(tr_("Connected"),
                                 tr_("Firebase connection established successfully."),
                                 parent=self.app.root)
        else:
            messagebox.showerror(
                tr_("Failure"),
                tr_("Unable to connect to Firebase — check file."),
                parent=self.app.root)

    # ── Config client / sauvegarde ────────────────────────────────────────

    def _save(self, silencieux: bool = False):
        """silencieux: saves without a confirmation window — used by the
        google-services.json import, which already shows its own message."""
        mg = self.app.config.setdefault("mobile_gateway", {})
        mg["firebase_client_config"] = {
            k: v.get().strip() for k, v in self._client_vars.items()
        }
        notif_prefs = {k: v.get() for k, v in self._notif_vars.items()}
        self.app.config.setdefault("mobile_notifications", {}).update(notif_prefs)
        cfg.save(self.app.config)
        self._publish_notification_prefs(notif_prefs)
        if silencieux:
            return
        messagebox.showinfo(tr_("Saved"),
                             tr_("Saved mobile app configuration."),
                             parent=self.app.root)

    @staticmethod
    def _publish_notification_prefs(prefs):
        """Re-publishes notification preferences to Firestore, fire-and-
        forget, fail-safe — same pattern as app_core.py::_publish_mobile_target_prices.
        Without a connected gateway, the local save still applies."""
        import threading

        def _worker():
            try:
                from business.mobile_gateway import publish_notification_prefs
                publish_notification_prefs(prefs)
            except Exception:
                pass

        threading.Thread(target=_worker, daemon=True).start()

    # ── Pairing ────────────────────────────────────────────────────────────

    def _show_qr(self):
        mg = self.app.config.get("mobile_gateway", {})
        client_cfg = {k: v for k, v in mg.get("firebase_client_config", {}).items() if v}
        required = ("apiKey", "appId", "messagingSenderId", "projectId")
        if not all(client_cfg.get(k) for k in required):
            messagebox.showwarning(
                tr_("Incomplete configuration"),
                tr_("First fill in and save apiKey, appId, messagingSenderId and projectId before generating the QR."),
                parent=self.app.root)
            return
        try:
            from business.qr_pairing import show_pairing_popup
            show_pairing_popup(self.app.root, client_cfg)
        except Exception as e:
            messagebox.showerror(tr_("Error"), str(e), parent=self.app.root)

    # ── Help / Documentation ───────────────────────────────────────────────

    def _open_firebase_guide(self):
        import subprocess
        import os
        from pathlib import Path
        from core.paths import INSTALL_DIR
        import lang

        lang_code = getattr(lang, "_lang_code", "en").lower()

        # D48: the guide exists as PDF (docs/ of the builds) AND as HTML
        # (owner addition 30/08, docs/ or root). We try the UI language
        # first, the other language as fallback, PDF before HTML.
        _langs = ["fr", "en"] if lang_code == "fr" else ["en", "fr"]
        _exts = [".pdf", ".html"]
        _dirs = [INSTALL_DIR / "docs", INSTALL_DIR]
        pdf_file = None
        for _lg in _langs:
            for _ext in _exts:
                for _d in _dirs:
                    _cand = _d / f"OTAGuard_Firebase_Setup_{_lg.upper()}{_ext}"
                    if _cand.exists():
                        pdf_file = _cand
                        break
                if pdf_file:
                    break
            if pdf_file:
                break

        if not pdf_file.exists():
            messagebox.showerror(
                tr_("File not found"),
                tr_("Firebase guide is not available."),
                parent=self.app.root)
            return

        try:
            if os.name == "nt":
                os.startfile(str(pdf_file))
            elif os.name == "posix":
                subprocess.Popen(["open", str(pdf_file)])
            else:
                subprocess.Popen(["xdg-open", str(pdf_file)])
        except Exception as e:
            messagebox.showerror(tr_("Error"),
                                 tr_("Unable to open PDF file: {e}").format(e=str(e)),
                                 parent=self.app.root)
