"""
"About" screen — OTA Guard.

Software identity card: name, version, copyright, license status,
machine ID and support contact. Gathers in a single place the information
useful for diagnostics ("which version?", "license active?", "which ID?").

Usage:
    from about import show_about
    show_about(self.root, self._lic_checker)
"""
import tkinter as tk

from version import (VERSION, BUILD_DATE, PRODUCT_NAME, COMPANY, COPYRIGHT,
                     COMPANY_ADDRESS, COMPANY_CIN, COMPANY_GST)

try:
    from core.utils import tr_ as _tr
except Exception:
    def _tr(s): return s

# Support contact (same as the license screen)
_SUPPORT_EMAIL    = "otaguard@proton.me"
_SUPPORT_WHATSAPP = "+91 9307380525 (message only)"


def show_about(parent, lic_checker=None):
    """Show the "About" window. `lic_checker` optional (license status)."""
    BG       = "#1e1e2e"
    FG       = "#cdd6f4"
    ENTRY_BG = "#313244"
    SEL_BG   = "#45475a"
    ACCENT   = "#89b4fa"
    GREEN    = "#a6e3a1"
    MUTED    = "#888888"

    try:
        from business.activity_log import log_ui
        log_ui("Opening About")
    except Exception:
        pass

    dlg = tk.Toplevel(parent)
    dlg.title(_tr("About") + " — OTA Guard")
    dlg.configure(bg=BG)
    # Fixed height abandoned: the "Price accuracy" note was
    # extended (2026-08-01) and may exceed 680px depending on the display
    # language (some translations are longer than others). Vertically
    # resizable so the content stays accessible even if the height estimate
    # below is a bit short on a small screen.
    dlg.resizable(False, True)

    # Center — height capped to the available screen (avoids a title off
    # screen on a short display, e.g. 768px high).
    dlg.update_idletasks()
    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg_h = min(840, sh - 80)
    dlg.geometry(f"520x{dlg_h}+{(sw-520)//2}+{(sh-dlg_h)//2}")

    pad = tk.Frame(dlg, bg=BG, padx=30, pady=24)
    pad.pack(fill="both", expand=True)

    # ── Header ────────────────────────────────────────────────────────────
    tk.Label(pad, text="🛡️ " + PRODUCT_NAME, bg=BG, fg=ACCENT,
             font=("Segoe UI", 18, "bold")).pack()
    tk.Label(pad, text=f"{_tr('Version')} {VERSION}  •  {_tr('Build')} {BUILD_DATE}",
             bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(pady=(2, 0))
    subtitle_lbl = tk.Label(pad, text=_tr("Hotel revenue management — OTA price monitoring"),
             bg=BG, fg=FG, font=("Segoe UI", 8), wraplength=440)
    subtitle_lbl.pack(pady=(6, 0))

    def _sep():
        tk.Frame(pad, bg=SEL_BG, height=1).pack(fill="x", pady=14)

    _sep()

    # ── Info block (key: value) ───────────────────────────────────────────
    info = tk.Frame(pad, bg=BG)
    info.pack(fill="x")

    def _row(label, value, value_fg=FG):
        r = tk.Frame(info, bg=BG)
        r.pack(fill="x", pady=2)
        label_lbl = tk.Label(r, text=label, bg=BG, fg=MUTED, font=("Segoe UI", 9),
                              width=14, anchor="w")
        label_lbl.pack(side="left")
        value_lbl = tk.Label(r, text=value, bg=BG, fg=value_fg, font=("Segoe UI", 9, "bold"),
                              anchor="w", justify="left", wraplength=260)
        value_lbl.pack(side="left", fill="x")
        return label_lbl, value_lbl

    # License status
    def _compute_lic_txt():
        txt, col = "—", FG
        if lic_checker is not None:
            try:
                from licensing.license_checker import (TRIAL_ACTIVE, LICENSED,
                                                       TRIAL_EXPIRED, LICENSE_EXPIRED)
                st = lic_checker.status
                dr = lic_checker.days_remaining()
                if st == TRIAL_ACTIVE:
                    txt = _tr("Free trial — {n} day(s) remaining").format(n=dr)
                    col = "#fab387"
                elif st == LICENSED:
                    txt = _tr("License active") if dr > 99000 else _tr("License — {n} day(s)").format(n=dr)
                    col = GREEN
                elif st == TRIAL_EXPIRED:
                    txt, col = _tr("Trial expired"), "#f38ba8"
                elif st == LICENSE_EXPIRED:
                    txt, col = _tr("License expired"), "#f38ba8"
                else:
                    txt = str(st)
            except Exception:
                pass
        return txt, col

    lic_txt, lic_col = _compute_lic_txt()
    machine_id = "—"
    try:
        from licensing.hw_id import get_hw_id_display
        machine_id = get_hw_id_display()
    except Exception:
        pass

    lic_label_lbl, lic_value_lbl = _row(_tr("License:"), lic_txt, lic_col)
    machineid_label_lbl, _ = _row(_tr("Machine ID:"), machine_id, ACCENT)

    _sep()

    # ── Company (legal identity) ──────────────────────────────────────────
    company_hdr_lbl = tk.Label(pad, text=_tr("🏢  Company"), bg=BG, fg=ACCENT,
                                font=("Segoe UI", 9, "bold"))
    company_hdr_lbl.pack(anchor="w")
    tk.Label(pad, text=COMPANY, bg=BG, fg=FG,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(2, 0))
    tk.Label(pad, text=COMPANY_ADDRESS, bg=BG, fg=FG,
             font=("Segoe UI", 9), wraplength=440,
             justify="left").pack(anchor="w", pady=(1, 4))

    legal_info = tk.Frame(pad, bg=BG)
    legal_info.pack(anchor="w", fill="x")
    tk.Label(legal_info, text=_tr("CIN:"), bg=BG, fg=MUTED,
             font=("Segoe UI", 8), width=8, anchor="w").grid(row=0, column=0, sticky="w")
    tk.Label(legal_info, text=COMPANY_CIN, bg=BG, fg=FG,
             font=("Consolas", 9)).grid(row=0, column=1, sticky="w")
    tk.Label(legal_info, text=_tr("GSTIN:"), bg=BG, fg=MUTED,
             font=("Segoe UI", 8), width=8, anchor="w").grid(row=1, column=0, sticky="w")
    tk.Label(legal_info, text=COMPANY_GST, bg=BG, fg=FG,
             font=("Consolas", 9)).grid(row=1, column=1, sticky="w")

    _sep()

    # ── Contact ───────────────────────────────────────────────────────────
    support_hdr_lbl = tk.Label(pad, text=_tr("📞  Support"), bg=BG, fg=ACCENT,
                                font=("Segoe UI", 9, "bold"))
    support_hdr_lbl.pack(anchor="w")
    tk.Label(pad, text=f"📧  {_SUPPORT_EMAIL}", bg=BG, fg=FG,
             font=("Segoe UI", 9)).pack(anchor="w", pady=(4, 0))
    tk.Label(pad, text=f"💬  {_SUPPORT_WHATSAPP}", bg=BG, fg=FG,
             font=("Segoe UI", 9)).pack(anchor="w", pady=(1, 0))

    _sep()

    # ── Copyright ─────────────────────────────────────────────────────────
    tk.Label(pad, text=COPYRIGHT, bg=BG, fg=MUTED,
             font=("Segoe UI", 8), wraplength=380, justify="center").pack()
    tk.Label(pad,
             text=_tr("© Proprietary software under license. Any unauthorized copy, "
                  "distribution or resale is strictly prohibited."),
             bg=BG, fg=MUTED, font=("Segoe UI", 7),
             wraplength=380, justify="center").pack(pady=(2, 0))

    _sep()

    # ── Price accuracy note ───────────────────────────────────────────────
    # Disclaimer about OTA price accuracy. Explicitly covers price/device/
    # location variability, the lack of control by OTA Guard over the OTA
    # pricing engine and the third-party Channel Manager, and the referral
    # to EULA/TOS — protection in case of a customer complaint about a
    # price gap that is not a software bug.
    _PRICE_NOTE_FR = (
        "Prices displayed by OTAs (Booking, Agoda, Airbnb, Expedia…) are "
        "generated by algorithms that vary them depending on the device, "
        "location/IP address, cookies, browsing history, currency and "
        "visitor profile. Two people may therefore see a different price "
        "at the same instant for the same room, without it being an "
        "error.\n\n"
        "OTA Guard does not read a single absolute price: its visual "
        "engine (VAE) extracts the prices displayed on the listing at "
        "each scan, from a given device and connection point. This may "
        "slightly vary the detected price from one scan to another, for "
        "the same reasons as above.\n\n"
        "A slight gap between the price sent to the Channel Manager and "
        "the price finally displayed on the OTA is therefore normal and "
        "independent of the software. OTA Guard has no control over the "
        "pricing engine specific to each OTA, nor over the operation of "
        "the third-party Channel Manager used to transmit prices — these "
        "are third-party systems, managed outside the software.\n\n"
        "OTA Guard is a decision-support and monitoring tool: it remains "
        "the hotel's responsibility to occasionally check the rates "
        "displayed directly on the OTA platforms. See the EULA / TOS "
        "below for the full disclaimer clause.")
    price_hdr_lbl = tk.Label(pad,
             text=_tr("ℹ️  Price accuracy"),
             bg=BG, fg=MUTED, font=("Segoe UI", 8, "bold"))
    price_hdr_lbl.pack(anchor="w")
    price_body_lbl = tk.Label(pad,
             text=_tr(_PRICE_NOTE_FR),
             bg=BG, fg=MUTED, font=("Segoe UI", 7),
             wraplength=440, justify="left")
    price_body_lbl.pack(anchor="w", pady=(2, 0))

    # ── Boutons ───────────────────────────────────────────────────────────
    btn_row = tk.Frame(pad, bg=BG)
    btn_row.pack(pady=(16, 0))

    def _copy_id():
        try:
            dlg.clipboard_clear()
            dlg.clipboard_append(machine_id)
        except Exception:
            pass

    copy_btn = tk.Button(btn_row, text=_tr("📋 Copy machine ID"), command=_copy_id,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=10, pady=4, cursor="hand2")
    copy_btn.pack(side="left", padx=(0, 8))

    def _show_eula():
        try:
            from legal.legal_screens import show_eula
            show_eula(dlg)
        except Exception:
            pass

    def _show_privacy():
        try:
            from legal.legal_screens import show_privacy
            show_privacy(dlg)
        except Exception:
            pass

    def _show_tos():
        try:
            from legal.legal_screens import show_terms_of_sale
            show_terms_of_sale(dlg)
        except Exception:
            pass

    def _show_credits():
        try:
            from legal.legal_screens import show_credits
            show_credits(dlg)
        except Exception:
            pass

    tk.Button(btn_row, text=_tr("📜 EULA"), command=_show_eula,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=10, pady=4, cursor="hand2").pack(side="left", padx=(0, 6))
    sales_btn = tk.Button(btn_row, text=_tr("💼 Sales"), command=_show_tos,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=10, pady=4, cursor="hand2")
    sales_btn.pack(side="left", padx=(0, 6))
    privacy_btn = tk.Button(btn_row, text=_tr("🔒 Privacy"), command=_show_privacy,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=10, pady=4, cursor="hand2")
    privacy_btn.pack(side="left", padx=(0, 6))
    credits_btn = tk.Button(btn_row, text=_tr("🎁 Credits"), command=_show_credits,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=10, pady=4, cursor="hand2")
    credits_btn.pack(side="left", padx=(0, 6))
    close_btn = tk.Button(btn_row, text=_tr("Close"), command=dlg.destroy,
              bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
              relief="flat", padx=16, pady=4, cursor="hand2")
    close_btn.pack(side="left")

    dlg.bind("<Escape>", lambda e: dlg.destroy())
