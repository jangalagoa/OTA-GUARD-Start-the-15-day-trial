"""
Main window — OTA Guard.
"""
import logging
import os
import sys
import threading
import tkinter as tk
from tkinter import ttk

from core.theme import T
from core import config as cfg
from core.widgets import btn, tooltip
from core.utils import tr_
from app_core import AppCore
from wizard_engine import MasterWizard
from licensing.license_checker import get_checker, TRIAL_ACTIVE, LICENSED

_log = logging.getLogger(__name__)


class App(AppCore):

    def __init__(self, root: tk.Tk):
        self.root   = root
        # Traceability: catch exceptions from UI callbacks (a click that
        # "does nothing" now leaves a trace in activity_log.txt (software root)).
        try:
            from business.activity_log import install_tk_excepthook, log_ui
            install_tk_excepthook(root)
            log_ui("Application opened")
        except Exception:
            import logging
            logging.exception("install_tk_excepthook failed — UI safety net disabled")
        self._install_wheel_routing()
        self.config = cfg.load()

        try:
            from lang import load_language
            load_language(self.config.get("language", "en"))
        except Exception:
            pass
        T.apply(self.config.get("theme", "Catppuccin Mocha"))
        try:
            # hotel_currency (My Hotel) is the single source of the currency —
            # the old separate "Display Currency" setting (Advanced) was removed.
            self._apply_currency(self.config.get("hotel_currency", "INR"), None)
        except Exception:
            pass

        # ── Global state ───────────────────────────────────────────────────
        self._any_scan_running       = False
        self._ota_watch_scanning     = False
        self._advanced_tab_init_done = False
        self._tab_text_cache         = None
        self._periodic_alive         = True
        self._all_alerts             = []
        self._alerts_data            = []
        self._journal_entries        = []
        self._journal_lock           = threading.Lock()
        self._cf_process             = None
        self._ota_watch_scan_fn      = None

        try:
            self._scan_results = self._load_last_scan()
        except Exception:
            self._scan_results = {}

        self._setup_styles()

        # ── Window ────────────────────────────────────────────────────────
        # D113: the patch level is VISIBLE IN THE TITLE — the
        # owner sees at all times WHAT IS RUNNING (end of "I don't
        # know when the fixes are applied": the title IS the proof).
        _ptitle = tr_("🛡️OTA Guard")
        try:
            from core import patch_loader as _pl
            _lvl = _pl.current_version()
            if _lvl:
                _ptitle += f"  —  patch v{_lvl}"
        except Exception:
            pass
        self.root.title(_ptitle)
        self.root.configure(bg=T.BG)
        self.root.geometry("1200x780")
        self.root.state("zoomed")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        # Window icon (Windows taskbar)
        try:
            from pathlib import Path as _P
            _ico = _P(__file__).parent / "assets" / "icon.ico"
            if _ico.exists():
                self.root.iconbitmap(default=str(_ico))
        except Exception:
            pass

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(root, bg=T.SEL_BG, pady=5, padx=10)
        topbar.pack(fill="x", side="top")

        tk.Label(topbar, text="🛡️ OTA Guard",
                 bg=T.SEL_BG, fg=T.ACCENT,
                 font=("Segoe UI", 11, "bold")).pack(side="left")

        tooltip(
            btn(topbar, tr_("⏻ Exit"), self._on_close, color=T.RED, width=10),
            tr_("Close the application.")
        ).pack(side="right", padx=(4, 8))

        tooltip(
            btn(topbar, "🧭 " + tr_("Assistant"), self._open_wizard,
                color=T.ACCENT, width=14),
            tr_("Guided setup wizard.")
        ).pack(side="right", padx=(4, 0))

        tooltip(
            btn(topbar, "ℹ️ " + tr_("About"), self._open_about,
                color=T.SEL_BG, width=11),
            tr_("Version, license, machine ID and support contact.")
        ).pack(side="right", padx=(4, 0))

        # ── License banner ──────────────────────────────────────────────
        self._lic_checker = get_checker()
        lic_status = self._lic_checker.status
        if lic_status == TRIAL_ACTIVE:
            dr = self._lic_checker.days_remaining()
            col = T.FG if dr > 5 else "#fab387" if dr > 2 else "#f38ba8"
            self._trial_lbl = tk.Label(
                topbar,
                text=tr_("Free trial") + f" — {dr} " + tr_("day(s) remaining"),
                bg=T.SEL_BG, fg=col, font=("Segoe UI", 8, "bold"))
            self._trial_lbl.pack(side="right", padx=(8, 0))
        elif lic_status == LICENSED:
            dr = self._lic_checker.days_remaining()
            txt = tr_("Active license") if dr > 99000 else tr_("License") + f" — {dr} " + tr_("days left")
            tk.Label(topbar, text=f"✅ {txt}",
                     bg=T.SEL_BG, fg="#a6e3a1",
                     font=("Segoe UI", 8, "bold")).pack(side="right", padx=(8, 0))

        # ── Tab buttons bar (below topbar, full width) ─────────────────
        tab_bar = tk.Frame(root, bg=T.SEL_BG, pady=4, padx=10)
        tab_bar.pack(fill="x", side="top")

        self._tab_buttons = {}

        tab_labels = [
            "🚫 " + tr_("OTA price block"),
            "🌐 " + tr_("Extranet Direct"),
            "🏨 " + tr_("My Hotel"),
            "🔌 " + tr_("Channel Manager"),
            "📅 " + tr_("Seasonal rates"),
            "📊 " + tr_("Analysis report"),
            "🔧 " + tr_("Settings"),
            "📱 " + tr_("Mobile app"),
        ]

        # Left spacer (fills extra horizontal space → centers the buttons)
        tk.Frame(tab_bar, bg=T.SEL_BG).pack(side="left", expand=True, fill="x")

        for _lbl in tab_labels:
            b = tk.Button(
                tab_bar, text=_lbl,
                bg=T.ENTRY_BG, fg=T.FG,
                font=("Segoe UI", 9),
                relief="flat", padx=14, pady=4, cursor="hand2",
                activebackground=T.SEL_BG, activeforeground=T.FG, bd=0,
            )
            b.pack(side="left", padx=3)
            self._tab_buttons[_lbl] = b

        # Right spacer (mirrors left spacer to truly center)
        tk.Frame(tab_bar, bg=T.SEL_BG).pack(side="left", expand=True, fill="x")

        # ── Main container ───────────────────────────────────────────
        self._main_container = tk.Frame(root, bg=T.BG)
        self._main_container.pack(fill="both", expand=True, padx=8, pady=(4, 8))

        # Notebook without visible tabs
        self.nb = ttk.Notebook(self._main_container, style="NoTab.TNotebook")
        self.nb.pack(fill="both", expand=True)

        self._build_tabs()
        self._bind_tab_buttons()

        # ── Bottom status bar (version + copyright) ──────────────────
        try:
            from version import VERSION, COPYRIGHT
            footer = tk.Frame(root, bg=T.SEL_BG, pady=3, padx=10)
            footer.pack(fill="x", side="bottom")
            tk.Label(footer,
                     text=f"OTA Guard v{VERSION}",
                     bg=T.SEL_BG, fg="#888",
                     font=("Segoe UI", 8)).pack(side="left")
            tk.Label(footer, text=COPYRIGHT,
                     bg=T.SEL_BG, fg="#888",
                     font=("Segoe UI", 8)).pack(side="right")
        except Exception:
            pass

        # ── Delayed startups ───────────────────────────────────────────
        self.root.after(500,  self._bind_context_menu_all)
        self.root.after(800,  lambda: self._lic_checker.start_runtime_checks(self.root))
        self.root.after(1500, self._auto_launch_wizard)
        self.root.after(5000, self._ota_watch_auto_loop_delayed_start)
        self.root.after(3000, self._start_mobile_gateway)

    def _install_wheel_routing(self):
        """Mouse wheel = widget under the CURSOR, not under the focus.

        On Windows, the wheel event is delivered to the widget holding focus.
        During a scan, UI refreshes (Scan button
        disabled, tab section rebuilt, table refilled) move
        that focus: the wheel then does nothing, until the
        user clicks a scrollbar (which gives focus back to the
        table). We route each wheel event to the first scrollable widget
        located under the pointer — scrolling stays alive whatever
        the background does.

        Details: ``add='+'`` so other wheel bindings are not clobbered;
        we do NOT act when the hovered widget already holds the focus (its
        native binding handles it — otherwise the wheel would scroll twice
        as fast)."""
        root = self.root

        def _scrollable_under(x, y):
            w = root.winfo_containing(x, y)
            while w is not None and w is not root:
                if w.winfo_class() in ("Treeview", "Text", "Canvas", "Listbox"):
                    return w
                w = w.master
            return None

        def _on_wheel(event):
            target = _scrollable_under(event.x_root, event.y_root)
            if target is None or target is root.focus_get():
                return
            try:
                target.yview_scroll(-1 * int(event.delta / 120), "units")
            except tk.TclError:
                pass

        root.bind_all("<MouseWheel>", _on_wheel, add="+")

    def _start_mobile_gateway(self):
        """Starts listening for phone orders (mobile gateway).
        Fail-safe: does nothing if no Firebase service account is
        configured (see the Mobile app tab)."""
        try:
            from business.mobile_commands import start_gateway
            start_gateway(self)
        except Exception:
            pass
        # D39: vendor ops channel (remote status/logs/config, signed) —
        # reuses the Firebase connection already initialized above.
        try:
            from business.vendor_ops import start as _vstart
            _vstart(self)
        except Exception:
            pass

    # ── Styles ttk ────────────────────────────────────────────────────────

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook",     background=T.BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=T.SEL_BG, foreground=T.FG,
                        padding=[12, 6], font=("Segoe UI", 9, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", T.ACCENT)],
                  foreground=[("selected", T.BG)])
        style.layout("NoTab.TNotebook", [("Notebook.client", {"sticky": "nswe"})])
        style.configure("NoTab.TNotebook", background=T.BG, borderwidth=0,
                        tabmargins=[0, 0, 0, 0])
        style.layout("NoTab.TNotebook.Tab", [])
        style.configure("NoTab.TNotebook.Tab", padding=[0, 0, 0, 0])
        style.configure("Treeview",
                        background=T.ENTRY_BG, foreground=T.FG,
                        rowheight=24, fieldbackground=T.ENTRY_BG, borderwidth=0)
        style.configure("Treeview.Heading",
                        background=T.SEL_BG, foreground=T.ACCENT,
                        font=("Segoe UI", 9, "bold"))
        style.map("Treeview",
                  background=[("selected", T.ACCENT)],
                  foreground=[("selected", T.BG)])
        style.configure("TScrollbar",
                        background=T.SEL_BG, troughcolor=T.BG, arrowcolor=T.FG)
        style.configure("Horizontal.TProgressbar",
                        background=T.ACCENT, troughcolor=T.ENTRY_BG)

    # ── Tab loading ──────────────────────────────────────────

    def _build_tabs(self):
        tab_defs = [
            ("🚫 " + tr_("OTA price block"), "tabs.tab_blocage_ota"),
            ("🌐 " + tr_("Extranet Direct"), "tabs.tab_extranet_direct"),
            ("🏨 " + tr_("My Hotel"),        "tabs.tab_hotel"),
            ("🔌 " + tr_("Channel Manager"),  "tabs.tab_channel_manager"),
            ("📅 " + tr_("Seasonal rates"), "tabs.tab_price_calendar"),
            ("📊 " + tr_("Analysis report"), "tabs.tab_analysis"),
            ("🔧 " + tr_("Settings"),       "tabs.tab_advanced"),
            ("📱 " + tr_("Mobile app"),       "tabs.tab_mobile"),
        ]

        self._tab_instances = {}
        for label, module_path in tab_defs:
            frame = tk.Frame(self.nb, bg=T.BG)
            self.nb.add(frame, text=label)
            try:
                import importlib
                mod = importlib.import_module(module_path)
                tab_inst = mod.Tab()
                tab_inst.build(self, frame)
                self._tab_instances[frame] = tab_inst
            except Exception:
                import traceback
                try:
                    from business.activity_log import log_event
                    log_event("UI", f"Tab build failed '{label}'",
                              ok=False, module=module_path)
                    import logging as _lg
                    _lg.getLogger("ACTIVITY").error(
                        "Tab '%s' traceback:\n%s", label, traceback.format_exc())
                except Exception:
                    pass
                tk.Label(frame,
                         text=tr_("Tab under construction.\n\n{tb}").format(tb=traceback.format_exc()),
                         bg=T.BG, fg=T.RED,
                         font=("Courier New", 8),
                         justify="left").pack(padx=10, pady=10)

    # ── Tab button bindings ──────────────────────────────────────────────

    def _bind_tab_buttons(self):
        """Wire tab buttons to notebook tabs and highlight the active one."""
        all_tab_ids = list(self.nb.tabs())
        button_labels = list(self._tab_buttons.keys())
        # Primary: match by label text.  Fallback: match by index.
        for idx, tid in enumerate(all_tab_ids):
            label = self.nb.tab(tid, "text")
            btn_w = self._tab_buttons.get(label)
            if not btn_w and idx < len(button_labels):
                btn_w = self._tab_buttons.get(button_labels[idx])
            if btn_w:
                btn_w.configure(command=lambda _tid=tid: self.nb.select(_tid))

        self._tab_highlight(self.nb.select() if self.nb.tabs() else "")
        self.nb.bind("<<NotebookTabChanged>>", self._on_nb_tab_changed)

    def _tab_highlight(self, tab_id):
        active_label = self.nb.tab(tab_id, "text") if tab_id else ""
        for label, btn_w in self._tab_buttons.items():
            try:
                if label == active_label:
                    btn_w.configure(bg=T.ACCENT, fg=T.BG,
                                    font=("Segoe UI", 9, "bold"))
                else:
                    btn_w.configure(bg=T.ENTRY_BG, fg=T.FG,
                                    font=("Segoe UI", 9))
            except Exception:
                pass

    def _on_nb_tab_changed(self, _event):
        sel = self.nb.select()
        self._tab_highlight(sel)
        try:
            from business.activity_log import log_ui
            log_ui("Tab navigation", onglet=self.nb.tab(sel, "text"))
        except Exception:
            pass
        # Displayed tab (frame) built only ONCE at startup —
        # some lists (room types...) must be re-synchronized
        # with self.config on every show, otherwise OTA Guard
        # must be restarted to see an addition made in another tab (e.g. My Hotel).
        try:
            frame_widget = self.nb.nametowidget(sel)
            tab_inst = self._tab_instances.get(frame_widget)
            refresh = getattr(tab_inst, "refresh_on_show", None) if tab_inst else None
            if callable(refresh):
                refresh()
        except Exception:
            import logging
            logging.exception("refresh_on_show failed for the selected tab")

    def _go_to_tab(self, text_fragment: str):
        text_lower = text_fragment.lower()
        tabs  = self.nb.tabs()
        cache = getattr(self, "_tab_text_cache", None)
        if cache is None or tuple(cache.values()) != tuple(tabs):
            cache = {self.nb.tab(t, "text").lower(): t for t in tabs}
            self._tab_text_cache = cache
        for tab_text, tab_id in cache.items():
            if text_lower in tab_text:
                self.nb.select(tab_id)
                self._tab_highlight(tab_id)
                return

    # ── Wizard ────────────────────────────────────────────────────────────

    def _open_wizard(self):
        MasterWizard(self.root, self.config, cfg.save)

    def _open_about(self):
        from about import show_about
        show_about(self.root, getattr(self, "_lic_checker", None))

    def _auto_launch_wizard(self):
        from wizard_engine import _load_progress
        progress = _load_progress()
        wiz_data = progress.get("master_wizard", {})
        if wiz_data.get("_finished"):
            return
        if not self.config.get("hotel_name"):
            self._open_wizard()

    # ── Fermeture ─────────────────────────────────────────────────────────

    def _on_close(self):
        try:
            from business.activity_log import log_ui
            log_ui("Application closed")
        except Exception:
            pass
        # D80: session summary of the evidence ledger (every line
        # is already flushed — this adds the final recap).
        try:
            from business import legal_ledger
            legal_ledger.close_session()
        except Exception:
            pass
        try:
            cfg.save(self.config)
        except Exception:
            pass
        # D33: FULL shutdown. On 27/08, Exit closed the window but
        # the process survived (non-daemon threads) and its push kept running
        # for 85 minutes in parallel with the relaunched instance — two executors
        # in the same CM form. From now on: (1) stop signal to the
        # send queues, (2) wait for worker threads, (3) real
        # death of the process (os._exit — sys.exit waited for non-daemon
        # threads and left the app running without a window).
        try:
            from extranet_bridge import request_shutdown
            request_shutdown()
        except Exception:
            pass
        try:
            self.join_workers(timeout=8.0)
        except Exception:
            pass
        try:
            from business.mobile_commands import stop_gateway
            stop_gateway()
        except Exception:
            pass
        try:
            from business.vendor_ops import stop as _vstop
            _vstop()
        except Exception:
            pass
        try:
            from core.single_instance import release_lock
            release_lock()
        except Exception:
            pass

        self.root.destroy()
        os._exit(0)
