"""
AppCore — business methods required by OTA Guard.
All methods called by the tabs via BaseTab.__getattr__ live here.
"""
import json
import logging
import threading
import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from pathlib import Path

from core import config as cfg
from core.utils import tr_
from core.utils import set_currency
from core.utils import get_currency_symbol

from core.paths import DATA_DIR, INSTALL_DIR
LAST_SCAN_FILE = DATA_DIR / "last_scan.json"


class AppCore:

    # ── Thread-safe UI call ───────────────────────────────────────────────

    def _ui_call(self, fn):
        try:
            self.root.after(0, fn)
        except (RuntimeError, tk.TclError):
            pass

    # ── Currency ───────────────────────────────────────────────────────────

    def _apply_currency(self, code: str, rate=None):
        try:
            set_currency(code, float(rate) if rate else 1.0)
        except Exception:
            pass

    # ── Last scan ─────────────────────────────────────────────────────

    def _load_last_scan(self):
        try:
            if LAST_SCAN_FILE.exists():
                with open(LAST_SCAN_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save_last_scan(self, results):
        try:
            with open(LAST_SCAN_FILE, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False)
        except Exception:
            logging.exception("_save_last_scan failed")

    # ── Database ───────────────────────────────────────────────────

    def _ensure_db_init(self):
        if getattr(self, "_db_init_done", False):
            return
        try:
            from business.database import init_db
            init_db()
        except Exception:
            logging.exception("init_db failed")
        self._db_init_done = True

    # ── Alerts ───────────────────────────────────────────────────────────

    def _push_alert(self, motor: str, alert_type: str, message: str,
                    priority: str = "info", data: dict = None):
        entry = {
            "motor":    motor,
            "type":     alert_type,
            "message":  message,
            "priority": priority,
            "data":     data or {},
            "date":     datetime.now().strftime("%H:%M:%S"),
        }
        def _apply():
            self._all_alerts.append(entry)
            if len(self._all_alerts) > 500:
                self._all_alerts = self._all_alerts[-500:]
            try:
                self._log_journal(f"[{motor}] {message}")
            except Exception:
                pass
        try:
            self.root.after(0, _apply)
        except (RuntimeError, tk.TclError):
            pass

    # ── Journal ───────────────────────────────────────────────────────────

    def _log_journal(self, message: str, level: str = "info", engine: str = ""):
        try:
            with self._journal_lock:
                self._journal_entries.append(
                    f"{datetime.now().strftime('%H:%M:%S')}  {message}"
                )
                if len(self._journal_entries) > 2000:
                    self._journal_entries = self._journal_entries[-2000:]
        except Exception:
            pass
        try:
            from business.app_logger import app_log
            app_log(message, level=level, engine=engine)
        except Exception:
            pass

    # ── Worker threads (D33: Exit stops them and waits for them) ────────

    def _spawn(self, target):
        """Starts a daemon worker thread AND registers it. Before D33,
        Exit closed the window but non-daemon threads (firebase,
        listener) kept the process alive: a push kept running for
        85 minutes behind a closed window (27/08 16:04→17:29)."""
        import threading as _th
        t = _th.Thread(target=target, daemon=True)
        try:
            self._workers.append(t)
        except AttributeError:
            self._workers = [t]
        t.start()
        return t

    def join_workers(self, timeout: float = 8.0):
        """Waits for worker threads to finish (total budget `timeout`).
        Called by Exit after request_shutdown(): queues stop before
        their next task and are given time to cleanly finish the
        one in progress."""
        import time as _time
        _end = _time.time() + timeout
        for t in getattr(self, "_workers", []):
            try:
                if t.is_alive():
                    t.join(timeout=max(0.1, _end - _time.time()))
            except RuntimeError:
                pass

    # ── Push Channel Manager ──────────────────────────────────────────────

    def _do_push(self, valid_results, cm, checkin, nights, log_widget=None,
                 silent=False, on_done=None, source="Manual", weekend_markup=None,
                 ota_filter=None):
        try:
            from licensing.license_checker import _ck
            if not _ck():
                if on_done:
                    on_done(False, "")
                return
        except Exception:
            pass
        # E4 seam (Extranet Direct): the router picks the transport —
        # classic CM API, or driving the real form when
        # channel_manager.extranet_direct.enabled. Identical contract.
        from extranet_bridge import push_rates as _push_transport
        import extranet_bridge as _xb_ops

        # D52: a single operation — immediate refusal if a scan/push is running
        if _xb_ops.operation_current():
            _msg52 = ("Impossible: a {k} is already running (since {s}) — "
                      "one operation at a time, wait for it to finish.").format(
                k=_xb_ops.operation_current(), s=_xb_ops.operation_since())
            if not silent:
                messagebox.showwarning(tr_("Push CM"), _msg52, parent=self.root)
            if on_done:
                on_done(False, _msg52)
            return

        def _progress52(done, total, label):
            """Extranet queue progress -> UI bar (thread-safe)."""
            try:
                self.root.after(0, lambda: self._push_progress(done, total,
                                                               label))
            except Exception:
                pass

        _endpoint = (cm.get("endpoint") or cm.get("api_url") or "").strip()
        if not _endpoint:
            if not silent:
                messagebox.showwarning(
                    tr_("Push CM"),
                    tr_("Channel Manager not configured: endpoint URL is empty.\nEnter it in Configuration → Channel Manager."),
                    parent=self.root)
            if on_done:
                on_done(False, "CM endpoint empty")
            return

        if not valid_results:
            if not silent:
                messagebox.showwarning(
                    tr_("Push CM"),
                    tr_("No scan results available.\nFirst run a scan from the OTA Price Blocking tab,\nor use push per room in Configuration → Channel Manager."),
                    parent=self.root)
            if on_done:
                on_done(False, "No scan results")
            return

        mapping         = cm.get("room_mapping", {})
        strat_floors    = self.config.get("strategy", {}).get("floors", {})
        strat_ceilings  = self.config.get("strategy", {}).get("ceilings", {})
        room_pushes     = []
        skipped         = []
        skipped_ceiling = []
        filtered_out = 0        # rate plans dropped by ota_filter (error message)
        per_ota_summary = {}    # ota_code/name → {"name": ota_name, "rooms": {room: price}}

        # Application duration (days) — comes from the "for: N day(s)" setting
        # of OTA Price Blocking via the `nights` parameter (caller defaults: 90 or 1).
        try:
            _total_days = max(1, min(365, int(nights)))
        except (ValueError, TypeError):
            _total_days = 90
        # Weekend mode: the duration is split into batches of 15 days max — same
        # CM request size as before, but the requested duration is honored
        # (the old code froze 2 batches of 15 days whatever `nights` was).
        _lots = []                # [(checkin_iso, nb_days)]
        _cursor = datetime.fromisoformat(checkin).date()
        _left = _total_days
        while _left > 0:
            _span = min(15, _left)
            _lots.append((_cursor.isoformat(), _span))
            _cursor += timedelta(days=_span)
            _left -= _span
        lot_pushes = [[] for _ in _lots]

        # Locked dates from annual price calendar — D+ push skips these
        # entirely so that locked seasonal prices (Christmas, events…) are
        # never overwritten by adaptive corrections.
        try:
            from business.price_calendar import get_locked_dates
            _locked_dates = get_locked_dates(self.config, checkin, _total_days)
        except Exception:
            _locked_dates = set()

        for room, r in valid_results.items():
            m = mapping.get(room, {})
            room_code = (m.get("room_code", "").strip()
                         if isinstance(m, dict) else str(m).strip())
            if not room_code:
                skipped.append(room)
                continue

            # Target price = what the guest should see on the OTA after discount
            target_price = float(r["final"])
            if target_price <= 0:
                # Safety: never send a zero or negative price to the CM.
                skipped.append(room)
                continue

            # Per-OTA correction for THIS room (OTA Price Blocking may compute a
            # different target per OTA — e.g. Agoda 1600 / MakeMyTrip 2000).
            # Key = lowercased OTA name. Absent/empty for callers that send a
            # single price per room (Manual, Mobile…) → unchanged behavior,
            # `target_price` remains used for all rate plans.
            _per_ota = (r.get("per_ota") or {}) if isinstance(r, dict) else {}

            # Floor/ceiling guardrail — protects ALL push sources
            # (Manual, OTA Blocking, OTA Calibration, Mobile), not just the
            # mobile one (which already had _mobile_guardrail_check). Same
            # convention as the rest of the code: floor = raise to it, ceiling = reject.
            _floor = strat_floors.get(room)
            _ceil  = strat_ceilings.get(room)
            if _floor and target_price < float(_floor):
                target_price = float(_floor)
            if _ceil and target_price > float(_ceil):
                skipped_ceiling.append(room)
                continue

            # ── Rate plans: multi-OTA or backward compatibility ──────────────
            if isinstance(m, dict) and m.get("rate_plans"):
                rate_plans_list = m["rate_plans"]
            else:
                # Legacy single-line config
                _rpc  = (m.get("rate_plan_code", "").strip()
                         if isinstance(m, dict) else "") or "1"
                _disc = float(m.get("ota_discount_pct", 0) or 0) \
                        if isinstance(m, dict) else 0.0
                rate_plans_list = [{"rate_plan_code":   _rpc,
                                    "ota_discount_pct": _disc}]

            for rp_entry in rate_plans_list:
                # OTA filter: accepts a single name or a set/list of names.
                # Two rules, decided after the G1 audit (finding G1-2):
                #   1. EMPTY `ota_name` = "applies to all OTAs". The field
                #      is documented as purely informative (D20) and has
                #      no input validation: an empty field, or a legacy
                #      config with a single `rate_plan_code` (D20 backward
                #      compat, which carries no `ota_name`), silently
                #      dropped the ENTIRE push.
                #   2. Case- and whitespace-insensitive comparison
                #      ("agoda" ≡ "Agoda").
                _ota_n = (rp_entry.get("ota_name", "") or "").strip().lower()
                # Goibibo and MakeMyTrip are the same OTA inventory under two
                # different names (same Channel Manager channel) — the price
                # computed for MakeMyTrip must be used for the Goibibo rate
                # plan. The CM code sent remains Goibibo's
                # (_ota_code, read separately below): only the price changes.
                if _ota_n == "goibibo":
                    _ota_n = "makemytrip"
                # CM code of this OTA — propagated up to the sent packet so
                # push_rates_to_cm_by_ota() can group and space shipments
                # per OTA instead of mixing everything in a single "all OTA" packet.
                _ota_code = (rp_entry.get("ota_code", "") or "").strip()
                if ota_filter:
                    if _ota_n:
                        if isinstance(ota_filter, (set, list, frozenset)):
                            _wanted = {str(x).strip().lower() for x in ota_filter}
                            if _ota_n not in _wanted:
                                filtered_out += 1
                                continue
                        elif _ota_n != str(ota_filter).strip().lower():
                            filtered_out += 1
                            continue

                # REAL price for THIS rate plan: its own OTA's correction if
                # OTA Price Blocking computed one, otherwise the room's generic
                # price. A per-OTA correction exists for this room but does NOT
                # cover this specific OTA → send nothing for this rate plan
                # rather than apply a price computed for another OTA.
                if _per_ota and _ota_n:
                    # D125: case-insensitive match — the correction keys
                    # carry the names displayed by the scan ("Goibibo",
                    # "MakeMyTrip") while the rate plan is compared
                    # lowercased.
                    # D127: the goibibo≡makemytrip alias must apply to
                    # BOTH sides of this lookup. The plan side renames
                    # goibibo→makemytrip (one inventory), but the price
                    # index kept a bare "goibibo" key: a room whose only
                    # correction was Goibibo's left EVERY rate plan
                    # keyless → "No Rate Plan matches the monitored OTAs
                    # (8 removed)" → push refused (14/10 ~02:15, Double
                    # Room — its MakeMyTrip correction was suspended by
                    # the unchanged-price guard, leaving Goibibo alone).
                    # Now the plan takes the sibling's price when its own
                    # OTA has no correction this round.
                    _po_ix = {str(k).strip().lower(): v
                              for k, v in _per_ota.items()}
                    _rp_val = _po_ix.get(_ota_n)
                    if _rp_val is None and _ota_n == "makemytrip":
                        _rp_val = _po_ix.get("goibibo")
                    if _rp_val is None:
                        filtered_out += 1
                        continue
                    _rp_price = float(_rp_val)
                    if _floor and _rp_price < float(_floor):
                        _rp_price = float(_floor)
                    if _ceil and _rp_price > float(_ceil):
                        if room not in skipped_ceiling:
                            skipped_ceiling.append(room)
                        continue
                else:
                    _rp_price = target_price

                rp_code = (rp_entry.get("rate_plan_code", "") or "1").strip()
                try:
                    disc_pct = float(rp_entry.get("ota_discount_pct", 0) or 0)
                except (ValueError, TypeError):
                    disc_pct = 0.0

                # Compute the price to send to the CM so the OTA displays _rp_price
                # push_price = target / (1 − discount/100)
                # E.g.: target=2000, Agoda discount=20% → push=2500
                #       (Agoda displays 2500×0.80=2000 ✓)
                if 0 < disc_pct < 100:
                    push_price = _rp_price / (1.0 - disc_pct / 100.0)
                else:
                    push_price = _rp_price
                push_price = round(push_price)

                # Per-OTA trace for the CM history (one line per OTA at
                # display) — reference price per room, before any
                # weekend segmentation.
                _ota_disp = (rp_entry.get("ota_name", "") or "").strip() or (_ota_code or "?")
                _ota_key  = _ota_code or _ota_disp
                per_ota_summary.setdefault(_ota_key, {"name": _ota_disp, "rooms": {}})
                per_ota_summary[_ota_key]["rooms"][room] = push_price

                # Date segmentation: skips dates locked by the seasonal
                # calendar and applies the weekend markup to unlocked dates.
                # If neither lock nor weekend
                # → classic flat shipment (one price for the whole period).
                _wknd_active = weekend_markup and weekend_markup.get("enabled")
                if _locked_dates or _wknd_active:
                    from business.channel_manager import segments_skipping_locked
                    _wknd_cfg = None
                    if _wknd_active:
                        _wknd_cfg = {
                            "enabled": True,
                            "pct":     float(weekend_markup.get("pct", 20)),
                            "weekend_days": weekend_markup.get("days", [4, 5]),
                        }
                    for _li, (_lstart, _lspan) in enumerate(_lots):
                        for _fd, _td, _pr in segments_skipping_locked(
                                push_price, _lstart, _lspan,
                                _locked_dates, _wknd_cfg):
                            lot_pushes[_li].append({
                                "room_code":      room_code,
                                "rate_plan_code": rp_code,
                                "price":          _pr,
                                "from_date":      _fd,
                                "to_date":        _td,
                                "ota_code":       _ota_code,
                            })
                else:
                    room_pushes.append({
                        "room_code":      room_code,
                        "rate_plan_code": rp_code,
                        "price":          push_price,
                        "ota_code":       _ota_code,
                    })

        if not room_pushes and not any(lot_pushes):
            # Precise message: the "missing CM code" case and the "no Rate
            # Plan matches the monitored OTAs" case have different causes and
            # solutions. The old single message always blamed the
            # CM code, even when it was correctly configured.
            if filtered_out:
                _why_ui = tr_("No Rate Plan corresponds to the OTAs monitored.\n{n} line(s) removed: the “OTA” field in the Rate Plan does not correspond to any active OTA in OTA Price Blocking.\nCorrect the name in Configuration → Channel Manager, or leave this field empty to apply the price to all OTAs.").format(n=filtered_out)
                _why_cb = f"No Rate Plan matches the monitored OTAs ({filtered_out} removed)"
            else:
                _why_ui = tr_("No rooms have a CM code configured.\nConfigure the mapping in Configuration → Channel Manager.")
                _why_cb = "No room_code configured"
            if not silent:
                messagebox.showwarning(tr_("Push CM"), _why_ui, parent=self.root)
            if on_done:
                on_done(False, _why_cb)
            return

        def _fmt_results(_results):
            _ok  = all(r["ok"] for r in _results) if _results else False
            _msg = " | ".join(
                f"{'✅' if r['ok'] else '✗'} {r['ota_code'] or 'all OTAs'} : {r['msg']}"
                for r in _results
            )
            return _ok, _msg

        def _sent_total(_results):
            """D42: number of shipments that REALLY went out in these results.
            Extranet transport: "sent" field (verified + POST proof).
            API path (no field): if the group is ok, everything
            went out (n); otherwise nothing is counted — the API provides no
            intermediate detail."""
            _t = 0
            for r in (_results or []):
                if "sent" in r:
                    _t += int(r.get("sent") or 0)
                elif r.get("ok"):
                    _t += int(r.get("n") or 0)
            return _t

        def _task():
            try:
                if any(lot_pushes):
                    # Weekend mode: one shipment per 15-day batch, in order;
                    # and for each batch, a separate shipment per OTA (with a
                    # 5s pause between each) rather than one grouped shipment.
                    # D39 (28/08, owner's order): a partially failed batch no
                    # longer abandons the following batches — the old
                    # `break` threw away up to 45 days of the "for 60 days"
                    # setting because ONE segment missed its POST ("it never
                    # sends everything"). Batches continue; fallen segments
                    # are retried at the next scan cycle by the 24/7 loop.
                    # Only a TOTAL failure (CM session expired, CM state
                    # unavailable) stops the chain: nothing would get through
                    # afterwards, no point in hammering.
                    _lot_oks, _lot_msgs = [], []
                    _sent = 0
                    _sent_items = []
                    for _li, _lp in enumerate(lot_pushes):
                        if not _lp:
                            continue
                        _lstart, _lspan = _lots[_li]
                        _results = _push_transport(
                            cm, _lp, _lstart, _lspan, log_cb=self._log_journal,
                            progress_cb=_progress52)
                        _lok, _lmsg = _fmt_results(_results)
                        if not _lok:
                            _lmsg = f"Lot {_li + 1}/{len(_lots)} : {_lmsg}"
                        _lot_oks.append(_lok)
                        _lot_msgs.append(_lmsg)
                        _sent += _sent_total(_results)
                        for _r in _results:
                            _sent_items.extend(_r.get("sent_items") or [])
                        if "CM session expired" in _lmsg or \
                           "CM state unavailable" in _lmsg:
                            break
                            break
                    ok = all(_lot_oks) if _lot_oks else False
                    msg = " | ".join(_lot_msgs)
                else:
                    _results = _push_transport(
                        cm, room_pushes, checkin, _total_days,
                        log_cb=self._log_journal, progress_cb=_progress52)
                    ok, msg = _fmt_results(_results)
                    _sent = _sent_total(_results)
                    _sent_items = []
                    for _r in _results:
                        _sent_items.extend(_r.get("sent_items") or [])
                body = ""
            except Exception as e:
                ok, msg, body = False, str(e), ""
                _sent = 0

            def _ui():
                if not silent:
                    if ok:
                        messagebox.showinfo(tr_("✅ Push CM"),
                                            f"Prices sent successfully.\n{msg}",
                                            parent=self.root)
                    else:
                        messagebox.showerror(tr_("✗ Push CM failed"), msg,
                                             parent=self.root)
                try:
                    if on_done:
                        _cb = msg
                        if skipped:
                            _cb += f" | ⚠ Skipped (missing mapping): {', '.join(skipped)}"
                        if skipped_ceiling:
                            _cb += f" | ⚠ Skipped (above configured ceiling): {', '.join(skipped_ceiling)}"
                        # D105-2: the segments that really went out reach the
                        # callback when it accepts 3 args — the caller can
                        # record measurements even on group failure.
                        import inspect as _inspect
                        if len(_inspect.signature(on_done).parameters) >= 3:
                            on_done(ok, _cb, _sent_items)
                        else:
                            on_done(ok, _cb)
                except Exception:
                    pass
                try:
                    self._cm_record_push(
                        {r: v.get("final", 0) for r, v in valid_results.items()},
                        source, ok, msg, per_ota=per_ota_summary,
                        sent_count=_sent)
                except Exception:
                    pass
                # Mobile gateway: confirm the push to the companion app
                # (only if the CM push really succeeded).
                try:
                    if ok:
                        self._publish_mobile_push_confirmation(valid_results)
                except Exception:
                    pass

            self._ui_call(_ui)

        self._spawn(_task)

    def _mobile_guardrail_check(self, room, ota):
        """FINAL GUARDRAIL — called before any push triggered by the mobile.

        Checks that the target price of (room, OTA) respects the configured
        floor/ceiling bounds (strategy.floors / strategy.ceilings).
        The engine already applies the floor (max(target, floor)), but NOT
        the ceiling: this check closes that gap for mobile orders.

        Returns (True, "") if the order may pass, (False, reason) otherwise.
        Conservative: on missing data or doubt, we REJECT
        rather than push an unverified price."""
        try:
            ota_cfg       = self.config.get("ota_watch", {})
            target_prices = ota_cfg.get("target_prices", {})
            _room_t = target_prices.get(room, {}) or {}
            # OTA group aliasing: after the desktop merge, the target is
            # stored under "MakeMyTrip / Goibibo" — resolve a bare
            # "Goibibo"/"MakeMyTrip" from the phone against that key.
            _n = (ota or "").lower()
            target = _room_t.get(ota)
            if not target and any(g in _n for g in ("goibibo", "makemytrip")):
                target = (_room_t.get("MakeMyTrip / Goibibo")
                          or _room_t.get("MakeMyTrip")
                          or _room_t.get("Goibibo"))
            if not target:
                return False, f"No target price configured for {room} / {ota}"
            target = float(target)

            strat   = self.config.get("strategy", {})
            floor   = (strat.get("floors", {}) or {}).get(room)
            ceiling = (strat.get("ceilings", {}) or {}).get(room)

            # Effective price the engine will send = max(target, floor).
            effective = target
            if floor:
                effective = max(effective, float(floor))
            # The ceiling must be enforced on this effective price.
            if ceiling and effective > float(ceiling):
                return (False,
                        f"Price {int(effective)} above the ceiling "
                        f"{int(float(ceiling))} for {room}")
            return True, ""
        except Exception:
            return False, "Guardrail check failed"

    def _mobile_guardrail_check_new_target(self, room, new_target):
        """GUARDRAIL — called before saving a NEW target price proposed
        by the mobile (`update_target_price` action).

        Unlike `_mobile_guardrail_check` (which revalidates a target price
        already in config before a push), this one validates the PROPOSED
        VALUE itself against the floor/ceiling bounds, before any disk write.
        Conservative: rejects on missing data or doubt."""
        try:
            new_target = float(new_target)
        except (TypeError, ValueError):
            return False, "Invalid target price"
        if new_target <= 0:
            return False, "Target price must be positive"

        strat   = self.config.get("strategy", {})
        floor   = (strat.get("floors", {}) or {}).get(room)
        ceiling = (strat.get("ceilings", {}) or {}).get(room)
        if floor and new_target < float(floor):
            return (False,
                    f"Price {int(new_target)} below the floor "
                    f"{int(float(floor))} for {room}")
        if ceiling and new_target > float(ceiling):
            return (False,
                    f"Price {int(new_target)} above the ceiling "
                    f"{int(float(ceiling))} for {room}")
        return True, ""

    def _publish_mobile_target_prices(self):
        """Republishes the target price config to Firebase after a successful
        mobile order, so the phone sees the change without waiting for
        the next scan. Fire-and-forget, fail-safe (D8 convention)."""
        target_prices = self.config.get("ota_watch", {}).get("target_prices", {})

        def _worker():
            try:
                from business.mobile_gateway import publish_target_prices
                publish_target_prices(target_prices)
            except Exception:
                pass

        self._spawn(_worker)

    def _on_mobile_command(self, doc_id, data):
        """Receives and EXECUTES an order from the phone — Tkinter main thread
        (marshalled by scraping/mobile_commands.py via root.after).

        The PC is the FINAL GUARDRAIL: before any Channel Manager push, we
        re-validate the floor/ceiling price guardrails, even for an order
        coming from the mobile. An order that would violate these bounds is
        REJECTED, never pushed. Execution itself goes through the already
        validated correction engine (_ota_watch_correct) — no price logic
        rewritten here."""
        def _log(msg, action, room, ota, ok=True):
            try:
                from business.activity_log import log_event
                log_event("MOBILE", msg, ok=ok,
                          action=action, room=room, ota=ota, doc_id=doc_id)
            except Exception:
                pass

        def _status(st, detail=""):
            try:
                from business.mobile_commands import update_command_status
                update_command_status(doc_id, st, detail)
            except Exception:
                pass

        try:
            action = (data or {}).get("action", "?")
            room   = str((data or {}).get("room", "")).strip()
            ota    = str((data or {}).get("ota", "")).strip()

            # 1. Known, well-formed action?
            if action not in ("correct_price", "update_target_price", "update_notification_prefs"):
                _log(f"Order ignored — unknown action: {action}", action, room, ota, ok=False)
                _status("rejected", f"Unknown action: {action}")
                return

            # update_notification_prefs carries no room/OTA — handled
            # before the room/ota check below, which only applies
            # to orders tied to a specific room.
            if action == "update_notification_prefs":
                self._on_mobile_update_notification_prefs(data, _log, _status)
                return

            if not room or not ota:
                _log("Order rejected — missing room or OTA", action, room, ota, ok=False)
                _status("rejected", "Missing room or OTA")
                return

            if action == "update_target_price":
                self._on_mobile_update_target_price(data, room, ota, _log, _status)
                return

            # 2. FINAL GUARDRAIL: re-validate min/max BEFORE any push.
            okg, reason = self._mobile_guardrail_check(room, ota)
            if not okg:
                _log(f"Order REJECTED by the price guardrail: {reason}", action, room, ota, ok=False)
                _status("rejected", reason)
                return

            # 3. Execution via the validated correction engine (same internal
            #    guardrails: floors, min_gap, price<=0 refusal in _do_push).
            #    silent=True: confirmation already happened on the phone.
            correct_fn = getattr(self, "_ota_watch_correct_fn", None)
            if not callable(correct_fn):
                _log("Order not executed — correction engine unavailable",
                     action, room, ota, ok=False)
                _status("rejected", "Correction engine unavailable")
                return

            _log("Order accepted — correction started via the validated engine",
                 action, room, ota, ok=True)
            _status("accepted", "Correction sent to the engine (guardrails OK)")
            try:
                correct_fn(room=room, ota_name=ota, silent=True)
            except Exception:
                import logging
                logging.exception("_on_mobile_command: _ota_watch_correct failed")
        except Exception:
            import logging
            logging.exception("_on_mobile_command: processing failed")

    def _on_mobile_update_target_price(self, data, room, ota, _log, _status):
        """Handles the `update_target_price` action: the mobile proposes a new
        target price for (room, OTA). Revalidated against floors/ceilings
        (`_mobile_guardrail_check_new_target`) then written to the on-disk
        config via `core.config.save` — same mechanism as editing from
        the OTA Price Blocking tab (tabs/tab_blocage_ota.py)."""
        action = "update_target_price"
        new_target = (data or {}).get("new_target")

        okg, reason = self._mobile_guardrail_check_new_target(room, new_target)
        if not okg:
            _log(f"New target price REJECTED by the guardrail: {reason}", action, room, ota, ok=False)
            _status("rejected", reason)
            return

        try:
            ota_cfg = self.config.setdefault("ota_watch", {})
            target_prices = ota_cfg.setdefault("target_prices", {})
            # Normalize Goibibo / MakeMyTrip orders onto the merged key so
            # the phone never creates a stale standalone entry.
            _n = (ota or "").lower()
            _write_key = ota
            if any(g in _n for g in ("goibibo", "makemytrip")):
                _write_key = "MakeMyTrip / Goibibo"
            target_prices.setdefault(room, {})[_write_key] = float(new_target)
            from core import config as cfg
            cfg.save(self.config)
        except Exception:
            import logging
            logging.exception("_on_mobile_update_target_price: failed to save")
            _log("Failed to save the new target price", action, room, ota, ok=False)
            _status("rejected", "Save failed on the PC side")
            return

        # The symbol follows the currency configured by the hotel: this text goes
        # as-is to the phone (`pc_detail`), and a hard-coded "₹" would
        # show rupees to a hotel working in euros.
        from core.utils import get_currency_symbol
        _sym = get_currency_symbol()
        _log(f"Target price updated from the mobile → {_sym}{int(float(new_target))}",
             action, room, ota, ok=True)
        _status("accepted", f"Target price saved: {_sym}{int(float(new_target))}")
        self._publish_mobile_target_prices()

    _MOBILE_NOTIFICATION_KEYS = ("price_gap_detected", "correction_envoyee", "floor_violation")

    def _on_mobile_update_notification_prefs(self, data, _log, _status):
        """Handles the `update_notification_prefs` action: the phone (or the
        PC) proposes a new state for the mobile notification toggles.
        Shared global setting — written to config["mobile_notifications"]
        (read by scraping/notifications.py::send_mobile_push) then republished
        to Firestore so every paired phone sees the
        change without waiting for the next scan."""
        action = "update_notification_prefs"
        prefs = (data or {}).get("prefs")
        if not isinstance(prefs, dict) or not prefs:
            _log("Order rejected — invalid preferences", action, "", "", ok=False)
            _status("rejected", "Invalid preferences")
            return

        cleaned = {k: bool(prefs[k]) for k in self._MOBILE_NOTIFICATION_KEYS if k in prefs}
        if not cleaned:
            _log("Order rejected — no recognized preference", action, "", "", ok=False)
            _status("rejected", "No recognized preference")
            return

        try:
            mn = self.config.setdefault("mobile_notifications", {})
            mn.update(cleaned)
            from core import config as cfg
            cfg.save(self.config)
        except Exception:
            import logging
            logging.exception("_on_mobile_update_notification_prefs: failed to save")
            _log("Failed to save preferences", action, "", "", ok=False)
            _status("rejected", "Save failed on the PC side")
            return

        _log("Notification preferences updated from the mobile", action, "", "", ok=True)
        _status("accepted", "Preferences saved")
        self._publish_mobile_notification_prefs()

    def _publish_mobile_notification_prefs(self):
        """Republishes the mobile notification preferences to Firebase,
        fire-and-forget, fail-safe (D8 convention) — same pattern as
        `_publish_mobile_target_prices`."""
        prefs = self.config.get("mobile_notifications", {})

        def _worker():
            try:
                from business.mobile_gateway import publish_notification_prefs
                publish_notification_prefs(prefs)
            except Exception:
                pass

        self._spawn(_worker)

    def _publish_mobile_push_confirmation(self, valid_results):
        """Publishes a push confirmation to Firebase (companion mobile app).

        One record per room in the push_history collection. Fail-safe
        (D8 convention): if the mobile gateway is not connected,
        publish_push_confirmation() returns False without breaking anything.
        The network send runs in a daemon thread so the UI is never blocked.

        Note: ota_pushes is left empty here (per-rate-plan detail not
        rebuilt at this stage) — the confirmation carries room + target price
        + timestamp, enough for the current mobile app."""
        rooms = {}
        try:
            for room, r in (valid_results or {}).items():
                if isinstance(r, dict) and r.get("final"):
                    rooms[room] = float(r["final"])
        except Exception:
            return
        if not rooms:
            return

        def _worker():
            try:
                from business.mobile_gateway import publish_push_confirmation
                for room, price in rooms.items():
                    publish_push_confirmation(room, price, [], mode="applied")
            except Exception:
                pass

        self._spawn(_worker)

    def _push_progress(self, done, total, label):
        """D52: progress bar of CM shipments (Blocking tab)."""
        # D111: the ⏹ button is ALWAYS active (no more 0<done<total window
        # — a click during preparation or the 1st segment used to stay dead).
        try:
            tb = getattr(self, "_push_prog", None)
            tl = getattr(self, "_push_prog_lbl", None)
            if tb is not None and tb.winfo_exists():
                tb["maximum"] = max(1, int(total))
                tb["value"] = int(done)
            if tl is not None and tl.winfo_exists():
                if done >= total and total > 0:
                    tl.config(text=tr_("✅ Completed shipments ({n}).").format(n=total))
                else:
                    tl.config(text=tr_("🛠 Correction in progress: {d}/{t} — {l}")
                              .format(d=done, t=total, l=label[:60]))
        except Exception:
            pass

    def _cm_record_push(self, rooms_prices, source, ok, msg, per_ota=None,
                        sent_count=None):
        """Records the result of a push into push_history.

        If `per_ota` carries a per-OTA detail (OTA Price Blocking, which may
        compute a different target per OTA), a SEPARATE entry is created
        per OTA — each with the OTA's name and the prices specifically
        sent to it. Otherwise (Manual, Mobile… one price per
        room), we fall back to the legacy single entry grouping all
        rooms — unchanged behavior.

        D42: `sent_count` = number of shipments that REALLY went out (extranet
        transport: verified + POST proof; API: n if group ok). The
        panel uses it for the PARTIAL state (green if all ok, orange if
        at least one shipment went out despite failures, red otherwise). The msg
        is no longer truncated — shipment details (D40) must remain
        fully readable.
        """
        try:
            ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            sym = get_currency_symbol()

            entries = []
            if per_ota:
                for _data in per_ota.values():
                    _rooms = _data.get("rooms") or {}
                    if not _rooms:
                        continue
                    # D77: verdict SPECIFIC to each OTA when the transport
                    # carries it (one failing OTA no longer paints the others
                    # ❌ — finding from the seasonal push of 20/09 18:57:
                    # Agoda ✅ but global ❌ everywhere).
                    _g_ok = _data.get("ok")
                    _g_sent = _data.get("sent")
                    entries.append({
                        "ts":     ts,
                        "rooms":  ", ".join(str(r) for r in _rooms),
                        "prices": " / ".join(f"{sym}{int(float(p)):,}" for p in _rooms.values()),
                        # Room and its price kept TOGETHER — the display
                        # shows "Room: ₹price" instead of two parallel lists
                        # the reader has to line up by hand.
                        "pairs":  [f"{r}: {sym}{int(float(p)):,}"
                                   for r, p in _rooms.items()],
                        "source": source,
                        "ota":    _data.get("name", ""),
                        "ok":     bool(_g_ok) if _g_ok is not None else bool(ok),
                        "sent":   int(_g_sent) if _g_sent is not None else (int(sent_count) if sent_count is not None else None),
                        "msg":    str(msg or ""),  # D42: no more truncation
                    })
            if not entries:
                entries = [{
                    "ts":     ts,
                    "rooms":  ", ".join(str(r) for r in rooms_prices) if rooms_prices else "—",
                    "prices": " / ".join(f"{sym}{int(float(p)):,}" for p in rooms_prices.values()) if rooms_prices else "—",
                    "pairs":  [f"{r}: {sym}{int(float(p)):,}"
                               for r, p in (rooms_prices or {}).items()],
                    "source": source,
                    "ota":    "",
                    "ok":     bool(ok),
                    "sent":   int(sent_count) if sent_count is not None else None,
                    "msg":    str(msg or ""),  # D42: no more truncation
                }]

            cm   = self.config.setdefault("channel_manager", {})
            hist = cm.setdefault("push_history", [])
            for entry in reversed(entries):
                hist.insert(0, entry)
            if len(hist) > 50:
                cm["push_history"] = hist[:50]
            cfg.save(self.config)
            for entry in entries:
                _label = f"{entry['source']} → {entry['ota']}" if entry.get("ota") else entry['source']
                self._log_journal(
                    f"CM push {'✅' if entry['ok'] else '❌'} [{_label}] "
                    f"{entry['rooms']} → {entry['prices']}")
            fn = getattr(self, "_cm_refresh_history_fn", None)
            if fn:
                self.root.after(0, fn)
        except Exception:
            pass

    # ── Wiki ─────────────────────────────────────────────────────────────

    def _show_wiki(self, topic_key):
        from wizard_engine import show_wiki
        show_wiki(self.root, topic_key)

    def _send_bug_report(self):
        import os, sys, platform, urllib.parse, webbrowser, subprocess
        from datetime import datetime
        from core.paths import DATA_DIR
        from core.utils import tr_
        try:
            from version import VERSION, BUILD_DATE
        except Exception:
            VERSION, BUILD_DATE = "?", "?"

        log_path = DATA_DIR / "app.log"

        lines = [
            "=== OTA Guard — Bug report ===",
            f"Version  : {VERSION}  (build {BUILD_DATE})",
            f"OS       : {platform.system()} {platform.release()} — {platform.version()}",
            f"Date     : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            "",
            "⚠ The folder containing app.log has just opened, with the "
            "file selected: drag it into this email before sending "
            "(email services do not allow attaching a file automatically).",
            "",
            "=== Activity log (last 50 lines, quick overview) ===",
        ]
        try:
            with open(log_path, encoding="utf-8", errors="replace") as f:
                log_lines = f.readlines()
            lines += [l.rstrip() for l in log_lines[-50:]]
        except Exception as e:
            lines.append(f"[Log unavailable: {e}]")

        lines += [
            "",
            "=== Problem description ===",
            "(Describe here what happened, the steps to reproduce, etc.)",
        ]

        body = "\n".join(lines)
        subject = f"Bug Report — OTA Guard {VERSION}"
        mailto = (
            "mailto:otaguard@proton.me"
            f"?subject={urllib.parse.quote(subject)}"
            f"&body={urllib.parse.quote(body)}"
        )

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(body)
            self.root.update()
        except Exception:
            pass

        from tkinter import messagebox
        messagebox.showinfo(
            tr_("Bug report"),
            tr_("The report has been copied to the clipboard.\n\nIf your email does not open automatically in the next step: open your usual mailbox (Gmail, Outlook, etc.) and paste the report (Ctrl+V) in a new email to otaguard@proton.me."),
            parent=self.root)

        webbrowser.open(mailto)

        # Explorer opened with a slight delay (not at the same time as mailto)
        # to avoid interrupting the Windows mail choice if no
        # default mail client is configured. Used to drag and drop the
        # full log file into the email (mailto cannot attach files).
        def _open_explorer():
            try:
                if log_path.exists():
                    subprocess.Popen(f'explorer /select,"{log_path}"')
            except Exception:
                pass
        self.root.after(2000, _open_explorer)

    def _remote_support_exe_path(self):
        return str(INSTALL_DIR / "AnyDesk.exe")

    def _open_remote_support(self):
        import os
        import subprocess
        from tkinter import messagebox
        from core.utils import tr_

        exe = self._remote_support_exe_path()
        if os.path.exists(exe):
            try:
                subprocess.Popen([exe])
            except Exception as e:
                messagebox.showerror(tr_("Remote support"),
                                      tr_("Unable to launch support tool:") + f"\n{e}",
                                      parent=self.root)
            return

        if messagebox.askyesno(
            tr_("Remote support"),
            tr_("The remote support tool is not yet installed on this workstation.") + "\n\n" +
            tr_("Download the portable version (no installation required), place the AnyDesk.exe file in:") + f"\n{INSTALL_DIR}\n\n" +
            tr_("Open download page now?"),
            parent=self.root,
        ):
            import webbrowser
            webbrowser.open("https://anydesk.com/en/downloads/windows")

    # ── UI preferences (light persistence) ──────────────────────────────

    def _ui_pref(self, key: str, default):
        return self.config.get("_ui_prefs", {}).get(key, default)

    def _ui_pref_save(self, key: str, value):
        prefs = self.config.setdefault("_ui_prefs", {})
        prefs[key] = value

    # ── OTA Watch auto loop ─────────────────────────────────────────────

    def _ota_watch_interval_ms(self) -> int:
        """Delay before the next automatic scan, in milliseconds.

        The user-set interval (interval_h / interval_m) is
        honored ON AVERAGE, no longer to the second: a random
        variation of ±8% is added. A scan firing every 4 h 00 min
        00 s exactly, day after day from the same Internet address,
        is a metronome — the simplest pattern for an OTA to spot.
        With the variation, two consecutive visits never land at the same
        time of day. The original 5-minute floor is kept.
        """
        try:
            cfg  = self.config.get("ota_watch", {})
            h    = int(cfg.get("interval_h", 4))
            m    = int(cfg.get("interval_m", 0))
            secs = h * 3600 + m * 60
            ms   = max(secs * 1000, 300_000) if secs > 0 else 14_400_000
        except Exception:
            ms = 14_400_000
        try:
            # Random jitter (±8%) so scan intervals are not perfectly
            # regular — harder for OTA anti-bot systems to fingerprint.
            import random as _rnd
            _jitter = _rnd.uniform(0.92, 1.08)
            return max(int(ms * _jitter), 300_000)
        except Exception:
            return ms

    def _ota_watch_auto_loop_delayed_start(self):
        """Waits for the configured interval before the 1st automatic scan."""
        self.root.after(self._ota_watch_interval_ms(), self._ota_watch_auto_loop)

    def _ota_watch_auto_loop(self):
        """Periodic loop — automatic scan on the configured interval."""
        try:
            # D98: global pause — the scheduler triggers NOTHING
            # (it reschedules itself and will resume on unpause).
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._ota_watch_auto_id = self.root.after(
                    self._ota_watch_interval_ms(), self._ota_watch_auto_loop)
                return
        except Exception:
            pass
        try:
            from licensing.license_checker import _ck
            if not _ck():
                # Reschedule without doing anything
                self._ota_watch_auto_id = self.root.after(14_400_000, self._ota_watch_auto_loop)
                return
        except Exception:
            pass
        try:
            cfg  = self.config.get("ota_watch", {})
            if cfg.get("auto_correct"):
                otas = [o for o in cfg.get("otas", [])
                        if o.get("active") and o.get("url", "").startswith("http")]
                busy = (getattr(self, "_ota_watch_scanning", False) or
                        getattr(self, "_any_scan_running", False))
                scan_fn = getattr(self, "_ota_watch_scan_fn", None)
                if otas and not busy and scan_fn:
                    try:
                        scan_fn(_skip_save=True)
                    except Exception as e:
                        import logging
                        logging.exception("OTA Watch — automatic scan failed")
                        self._log_journal(f"❌ OTA Watch — automatic scan failed: {e}", level="error", engine="OTA_WATCH")
        except Exception:
            pass
        # Reschedule (slightly variable interval — see _ota_watch_interval_ms)
        self._ota_watch_auto_id = self.root.after(
            self._ota_watch_interval_ms(), self._ota_watch_auto_loop)

    # ── Universal copy/paste ─────────────────────────────────────────────
    #
    # Mechanism (reworked after the G1 audit, finding G1-5): bindings are set
    # ONCE on the widget *class* (bind_class), not widget by widget.
    # They therefore apply to every widget of that class, including those
    # created later (tables rebuilt after a scan, cards, secondary
    # windows) — no need to re-walk the whole Tkinter tree every
    # 3 seconds. The menu itself is built at right-click time and
    # destroyed on the next click: at most ONE live menu at a time.
    #
    # Old behavior: one tk.Menu created per widget encountered, never
    # destroyed, plus a full re-scan every 3 s. Measured during
    # the audit: 20 fields destroyed/recreated 5 times → 20, 40, 60, 80, 100 menus
    # permanently accumulated.

    _CTX_INPUT_CLASSES = ("Entry", "Text", "TEntry", "Spinbox", "TSpinbox", "TCombobox")
    _CTX_READ_CLASSES  = ("Label", "TLabel")
    _CTX_TREE_CLASSES  = ("Treeview",)

    def _ctx_copy(self, text):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(str(text))
        except Exception:
            pass

    def _ctx_select_all(self, w):
        try:
            cls = w.winfo_class()
            if cls in ("Entry", "TEntry", "Spinbox", "TSpinbox", "TCombobox"):
                w.select_range(0, "end")
                w.icursor("end")
            elif cls == "Text":
                w.tag_add("sel", "1.0", "end")
        except Exception:
            pass

    def _ctx_tree_rows(self, tree, iids):
        return "\n".join(
            "\t".join(str(v) for v in tree.item(i, "values")) for i in iids
        )

    def _ctx_close(self):
        """Destroys the previous context menu — guarantees no more than
        one ever lives in memory."""
        m = getattr(self, "_ctx_menu", None)
        if m is not None:
            try:
                m.destroy()
            except Exception:
                pass
            self._ctx_menu = None

    def _ctx_popup(self, event, kind):
        """Builds the menu fitting the clicked widget, shows it, and releases
        the previous one. Labels are re-translated at every open: a
        language change is thus taken into account without restart."""
        w = event.widget
        try:
            self._ctx_close()
            m = tk.Menu(self.root, tearoff=0)
            self._ctx_menu = m

            if kind == "input":
                m.add_command(label=tr_("Copy"),
                              command=lambda: w.event_generate("<<Copy>>"))
                m.add_command(label=tr_("Cut"),
                              command=lambda: w.event_generate("<<Cut>>"))
                m.add_command(label=tr_("Paste"),
                              command=lambda: w.event_generate("<<Paste>>"))
                m.add_separator()
                m.add_command(label=tr_("Select all"),
                              command=lambda: self._ctx_select_all(w))
            elif kind == "label":
                m.add_command(label=tr_("Copy"),
                              command=lambda: self._ctx_copy(w.cget("text")))
            else:  # table
                m.add_command(label=tr_("Copy selected line(s)"),
                              command=lambda: self._ctx_copy(
                                  self._ctx_tree_rows(w, w.selection())))
                m.add_command(label=tr_("Copy entire table"),
                              command=lambda: self._ctx_copy(
                                  "\t".join(str(w.heading(c, "text")) for c in w["columns"])
                                  + "\n" + self._ctx_tree_rows(w, w.get_children(""))))
                m.add_separator()
                m.add_command(label=tr_("Select all"),
                              command=lambda: w.selection_set(w.get_children("")))

            m.tk_popup(event.x_root, event.y_root)
        except Exception:
            logging.exception("_ctx_popup: failed to open the context menu")
        finally:
            try:
                if getattr(self, "_ctx_menu", None) is not None:
                    self._ctx_menu.grab_release()
            except Exception:
                pass

    def _bind_context_menu_all(self, widget=None):
        """Installs the copy/paste context menu for the WHOLE application.

        Covers Entry, Text, Combobox, Spinbox, Label and Treeview — including
        widgets created after this call, since the bindings are set on the
        class and not on each widget. Idempotent: later calls (or a
        call with a specific widget, kept for compatibility) do
        nothing more.
        """
        if getattr(self, "_ctx_class_bindings_done", False):
            return
        root = getattr(self, "root", None)
        if root is None:
            return
        self._ctx_class_bindings_done = True
        self._ctx_menu = None

        # add="+": never replaces Tk's native bindings for these
        # classes (editing, keyboard navigation, column sorting…).
        try:
            for _cls in self._CTX_INPUT_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "input"), add="+")
                root.bind_class(_cls, "<Control-a>",
                                lambda e: (self._ctx_select_all(e.widget), "break")[1], add="+")
                root.bind_class(_cls, "<Control-A>",
                                lambda e: (self._ctx_select_all(e.widget), "break")[1], add="+")
            for _cls in self._CTX_READ_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "label"), add="+")
            for _cls in self._CTX_TREE_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "tree"), add="+")
                root.bind_class(_cls, "<Control-c>",
                                lambda e: (self._ctx_copy(
                                    self._ctx_tree_rows(e.widget, e.widget.selection())),
                                    "break")[1], add="+")
                root.bind_class(_cls, "<Control-a>",
                                lambda e: (e.widget.selection_set(
                                    e.widget.get_children("")), "break")[1], add="+")
        except Exception:
            logging.exception("_bind_context_menu_all: class binding installation failed")
