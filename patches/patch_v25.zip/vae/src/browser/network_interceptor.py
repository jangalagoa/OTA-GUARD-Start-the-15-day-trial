"""
Module d'interception reseau passive pour OTA Guard VAE.
Architecture evenementielle correcte :
1. requestWillBeSent -> Requete envoyee
2. responseReceived -> Headers recus
3. loadingFinished -> Body pret (on peut le recuperer)
4. loadingFailed -> Erreur (on ignore)

100% indetectable par les anti-bots.
"""

import asyncio
import json
import base64
import random
import threading
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime
import websockets


# ── Edition guard (fix 2026-08-27) ──────────────────────────────────────
# While the VAE 2 executor drives a tab (typing prices in the CM form),
# NO listener reload may fire under it: a Page.reload landing mid-type
# leaves the Angular page half-rendered and the typed rate comes back
# doubled/scrambled (proven 2026-08-26 evening: '2888' read back as
# '22,888,888'). The bridge already raises vae2.keepalive.EDITION around
# every coordinator run; the keepalive respects it, but the listener's
# initial refresh and auto-refresh did NOT. reload_tab() is the single
# choke point for both — it now refuses to fire while an edition is
# active. The import is guarded: vae2 lives in the app, not in the
# standalone engine, and the local event keeps the API usable anyway.
_LOCAL_EDITION = threading.Event()


def set_reload_block() -> None:
    _LOCAL_EDITION.set()


def clear_reload_block() -> None:
    _LOCAL_EDITION.clear()


def reload_blocked() -> bool:
    if _LOCAL_EDITION.is_set():
        return True
    try:
        from vae2.keepalive import EDITION          # same process (app)
        return EDITION.is_set()
    except Exception:
        return False


class NetworkInterceptor:
    """
    Intercepteur reseau passif via CDP avec gestion correcte du cycle de vie.
    """

    def __init__(self, debug_port: int = 9222):
        self.debug_port = debug_port
        self.active_connections = {}
        self.captured_requests = []
        self.pending_responses = {}  # request_id -> response_info
        self._request_doc_urls = {}  # request_id -> page URL at request time
        # D33: request_id -> (method, postData) seen at emission time. The
        # final capture is assembled on the RESPONSE side (loadingFinished) which
        # knows neither the method nor the payload: without this memory, the
        # fichiers sortaient avec method="" et sans post_data — impossible
        # of proving what had been sent (AddBulkUpdate POST).
        self._request_meta = {}
        self._awaiting_bodies = {}   # command_id -> (tab_id, request_id, captured, attempts)
        self.on_request_captured = None
        self.on_response_received = None
        self._message_id_counter = 1000
        self._refreshing = False
        self._refresh_tasks = []
        self._stats = {
            'requests': 0,
            'responses': 0,
            'bodies_retrieved': 0,
            'bodies_failed': 0
        }
        
    async def connect_to_tab(self, tab_ws_url: str, tab_id: str) -> bool:
        """Se connecte a un onglet specifique via WebSocket."""
        try:
            ws = await asyncio.wait_for(
                websockets.connect(tab_ws_url, max_size=10*1024*1024),
                timeout=5.0
            )
            self.active_connections[tab_id] = ws
            print(f"Connecte a l'onglet {tab_id[:8]}...", flush=True)
            return True
        except Exception as e:
            print(f"Erreur de connexion a l'onglet {tab_id}: {e}", flush=True)
            return False

    async def enable_network_listening(self, tab_id: str):
        """Active l'ecoute reseau sur un onglet."""
        if tab_id not in self.active_connections:
            return

        ws = self.active_connections[tab_id]

        await ws.send(json.dumps({
            "id": 1,
            "method": "Network.enable",
            "params": {}
        }))

        # Cache disabled at the debugger level: responses always come from
        # the network with retrievable bodies. Invisible to the page (a
        # debugger-only setting), it only prevents Chrome from silently
        # serving cached API responses the listener could never see.
        self._message_id_counter += 1
        await ws.send(json.dumps({
            "id": self._message_id_counter,
            "method": "Network.setCacheDisabled",
            "params": {"cacheDisabled": True}
        }))

        # Wait for the Network.enable response with a timeout.
        # The browser may send events before the response, so we loop
        # until we find the message with id:1 or timeout (2s per attempt).
        try:
            for _ in range(10):
                response = await asyncio.wait_for(ws.recv(), timeout=2.0)
                data = json.loads(response)
                if data.get("id") == 1 and "result" in data:
                    print(f"Ecoute reseau activee sur {tab_id[:8]}...", flush=True)
                    return
                # Event received before response: process it, keep waiting
                if "method" in data:
                    await self._process_message(tab_id, response)
        except asyncio.TimeoutError:
            # Timeout: assume enabled anyway and move on
            print(f"Ecoute reseau activee sur {tab_id[:8]}... (timeout)", flush=True)

    async def _process_message(self, tab_id: str, message: str):
        """Traite un message recu via WebSocket."""
        try:
            data = json.loads(message)

            if "id" in data:
                if data["id"] < 1000:
                    return
                # Command answer (id >= 1000): usually a getResponseBody
                # result. Non-body commands (Network.enable acks) simply
                # find no entry and are ignored.
                await self._deliver_body_response(data)
                return

            method = data.get("method", "")
            params = data.get("params", {})
            
            # Etape 1 : Requete envoyee
            if method == "Network.requestWillBeSent":
                self._stats['requests'] += 1
                request = params.get("request", {})
                url = request.get("url", "")
                
                if self._is_interesting_request(url):
                    captured = {
                        "timestamp": datetime.now().isoformat(),
                        "tab_id": tab_id,
                        "requestId": params.get("requestId", ""),
                        "url": url,
                        "method": request.get("method", ""),
                        # D33 : payload du POST, fourni par CDP dans
                        # requestWillBeSent (lecture passive, R1). Sans
                        # impossible to prove WHAT had been sent —
                        # on 08/27, the whole diagnosis of the fake "sent"
                        # had to be rebuilt without the payload. The field
                        # post_data had been lost during a sync of the
                        # moteur (la preuve E1 du 22/08 l'avait).
                        "postData": request.get("postData", ""),
                        "headers": request.get("headers", {}),
                        # Page URL AT REQUEST TIME. CDP provides it per
                        # request; the analyzer's tab context is only set
                        # at startup / new-tab detection and goes stale the
                        # moment a tab navigates (Airbnb listing A opened
                        # in a tab that was showing listing B → captures
                        # tagged with the wrong /rooms/<id> forever).
                        "documentURL": params.get("documentURL", ""),
                    }
                    self.captured_requests.append(captured)
                    # Remember the page URL at request time so the final
                    # response capture can be attributed to the right page
                    # even if the tab context is stale (tab navigation).
                    doc_url = params.get("documentURL", "")
                    if doc_url:
                        self._request_doc_urls[params.get("requestId", "")] = doc_url
                    # D33: remember method + payload for the merge at
                    # loadingFinished (the response does not carry them).
                    self._request_meta[params.get("requestId", "")] = (
                        request.get("method", ""),
                        request.get("postData", ""),
                    )

                    if self.on_request_captured:
                        await self.on_request_captured(captured)
            
            # Etape 2 : Headers recus (on stocke pour plus tard)
            elif method == "Network.responseReceived":
                self._stats['responses'] += 1
                response = params.get("response", {})
                request_id = params.get("requestId", "")
                mime_type = response.get("mimeType", "")

                if self._is_interesting_response(mime_type):
                    # Stocker en attente de loadingFinished
                    self.pending_responses[request_id] = {
                        "timestamp": datetime.now().isoformat(),
                        "tab_id": tab_id,
                        "requestId": request_id,
                        "url": response.get("url", ""),
                        "status": response.get("status", 0),
                        "mimeType": mime_type,
                        "headers": response.get("headers", {})
                    }

            # Etape 3 : Body pret (on peut le recuperer)
            elif method == "Network.loadingFinished":
                request_id = params.get("requestId", "")

                if request_id in self.pending_responses:
                    captured = self.pending_responses.pop(request_id)
                    # Attach the page URL captured at REQUEST time: the
                    # authoritative page attribution for this response.
                    doc_url = self._request_doc_urls.pop(request_id, "")
                    if doc_url:
                        captured["documentURL"] = doc_url
                    # D33: attach the method + payload seen at emission —
                    # the response does not carry them, and without them the proof
                    # d'envoi (POST AddBulkUpdate) est inexploitable.
                    _method, _pdata = self._request_meta.pop(request_id,
                                                             ("", ""))
                    captured["method"] = captured.get("method") or _method
                    captured["postData"] = _pdata

                    # Fire-and-forget: send the command now, deliver the
                    # body when the id-tagged answer returns through this
                    # same loop. NEVER await a body fetch inline: its recv
                    # loop swallows every CDP event arriving meanwhile —
                    # the historical cause of large OTA responses (Expedia
                    # propertyOffers, 240 KB+) being silently lost during
                    # page-load bursts.
                    await self._send_body_fetch(tab_id, request_id, captured)
            
            # Etape 4 : Erreur (on ignore)
            elif method == "Network.loadingFailed":
                request_id = params.get("requestId", "")
                if request_id in self.pending_responses:
                    del self.pending_responses[request_id]
                self._request_doc_urls.pop(request_id, None)
                self._request_meta.pop(request_id, None)
        
        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"Erreur de traitement: {e}")

    def _is_interesting_request(self, url: str) -> bool:
        """Determine si une requete est interessante."""
        url_lower = url.lower()
        
        exclude_patterns = [
            '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico',
            '.css', '.woff', '.woff2', '.ttf', '.eot',
            'google-analytics.com', 'facebook.com', 'doubleclick.net'
        ]
        
        for pattern in exclude_patterns:
            if pattern in url_lower:
                return False
        
        return True

    def _is_interesting_response(self, mime_type: str) -> bool:
        """Determine si une reponse est interessante.
        Permissive: many OTA APIs (GraphQL, REST) return text/plain or even
        empty MIME types with JSON content — missing them loses pricing data."""
        mime_lower = mime_type.lower()
        if not mime_lower:
            return True  # no MIME = assume interesting, let body decide
        return ('json' in mime_lower
                or 'javascript' in mime_lower
                or 'text' in mime_lower
                or 'xml' in mime_lower)

    async def _send_body_fetch(self, tab_id: str, request_id: str,
                               captured: Dict[str, Any], attempts: int = 0) -> None:
        """Send Network.getResponseBody and register the awaited answer.

        Non-blocking on purpose: the answer comes back as an id-tagged
        message handled by _deliver_body_response in the main loop."""
        ws = self.active_connections.get(tab_id)
        if ws is None:
            self._stats['bodies_failed'] += 1
            return
        self._message_id_counter += 1
        command_id = self._message_id_counter
        self._awaiting_bodies[command_id] = (tab_id, request_id, captured, attempts)
        try:
            await ws.send(json.dumps({
                "id": command_id,
                "method": "Network.getResponseBody",
                "params": {"requestId": request_id}
            }))
        except Exception:
            self._awaiting_bodies.pop(command_id, None)
            self._stats['bodies_failed'] += 1

    async def _deliver_body_response(self, data: dict) -> None:
        """Match an id-tagged getResponseBody answer to its captured response."""
        entry = self._awaiting_bodies.pop(data.get("id"), None)
        if entry is None:
            return  # ack of Network.enable or similar — not ours

        tab_id, request_id, captured, attempts = entry

        if "result" in data:
            body = data["result"].get("body", "")
            if data["result"].get("base64Encoded"):
                body = base64.b64decode(body).decode('utf-8', errors='ignore')

            # Chrome can answer getResponseBody with a SUCCESS and an empty
            # body while the payload is still being flushed (Expedia graphql
            # served through its service worker is the proven case: empty at
            # loadingFinished, fully available a few seconds later). Re-ask
            # later instead of recording a useless empty capture.
            if not body and attempts < 2:
                asyncio.create_task(self._delayed_body_refetch(
                    tab_id, request_id, captured, attempts))
                return

            captured['body'] = body

            if body:
                self._stats['bodies_retrieved'] += 1
            else:
                self._stats['bodies_failed'] += 1
                print(f"[BODY] echec final (vide) apres {attempts + 1} essais: "
                      f"{captured.get('url', '')[:90]}", flush=True)

            if self.on_response_received:
                await self.on_response_received(captured)

        elif "error" in data:
            err_msg = str(data["error"].get("message", ""))
            # -32000 "No resource with given identifier": Chrome does not
            # (yet) have the body for this requestId. Proven on the big
            # Expedia price graphql (~73 KB): the error arrives at
            # loadingFinished time while the payload becomes readable a few
            # seconds later. An IMMEDIATE retry fails identically — only the
            # delayed re-ask recovers it.
            if attempts < 2:
                asyncio.create_task(self._delayed_body_refetch(
                    tab_id, request_id, captured, attempts))
            else:
                self._stats['bodies_failed'] += 1
                print(f"[BODY] echec final ({err_msg[:50]}) apres "
                      f"{attempts + 1} essais: {captured.get('url', '')[:90]}",
                      flush=True)

    async def _delayed_body_refetch(self, tab_id: str, request_id: str,
                                    captured: Dict[str, Any], attempts: int):
        """Re-ask for a body that Chrome returned empty moments earlier."""
        # 3 s then 12 s: long enough for the flush to complete, short enough
        # to stay well inside Chrome's response buffer window.
        await asyncio.sleep(3.0 if attempts == 0 else 12.0)
        if tab_id in self.active_connections:
            await self._send_body_fetch(tab_id, request_id, captured,
                                        attempts + 1)

    async def get_response_body(self, tab_id: str, request_id: str) -> Optional[str]:
        """
        Recupere le contenu d'une reponse.
        Appele uniquement apres loadingFinished.
        Retry up to 3 times: Chrome evicts response bodies from its buffer
        quickly, so a single attempt often misses large API responses.
        """
        if tab_id not in self.active_connections:
            return None

        ws = self.active_connections[tab_id]

        for attempt in range(3):
            self._message_id_counter += 1
            command_id = self._message_id_counter

            try:
                await ws.send(json.dumps({
                    "id": command_id,
                    "method": "Network.getResponseBody",
                    "params": {"requestId": request_id}
                }))

                # Give Chrome enough time for large JSON responses (Agoda
                # room-grid, MMT search-hotels, etc. are 100K+ and need
                # more than the original 2 s on slower connections).
                timeout = 5.0
                start_time = asyncio.get_event_loop().time()

                while asyncio.get_event_loop().time() - start_time < timeout:
                    try:
                        message = await asyncio.wait_for(ws.recv(), timeout=0.5)
                        data = json.loads(message)

                        if data.get("id") == command_id:
                            if "result" in data:
                                body = data["result"].get("body", "")
                                base64_encoded = data["result"].get("base64Encoded", False)

                                if base64_encoded:
                                    return base64.b64decode(body).decode('utf-8', errors='ignore')
                                else:
                                    return body
                            elif "error" in data:
                                # Error codes:
                                #  -32000 "No resource with given identifier"
                                #    → body already evicted from Chrome buffer.
                                #    Retry: the buffer may still be available.
                                err_msg = str(data["error"].get("message", ""))
                                if "No resource" in err_msg and attempt < 2:
                                    await asyncio.sleep(0.3)
                                    break  # retry outer loop
                                return None
                            else:
                                return None

                        # Autre evenement, on le traite
                        if "method" in data:
                            await self._process_message(tab_id, message)

                    except asyncio.TimeoutError:
                        continue

            except Exception:
                if attempt < 2:
                    await asyncio.sleep(0.3)
                    continue
                return None

        return None

    async def listen_to_tab(self, tab_id: str):
        """Ecoute les messages d'un onglet en continu."""
        if tab_id not in self.active_connections:
            return

        ws = self.active_connections[tab_id]

        try:
            async for message in ws:
                await self._process_message(tab_id, message)
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            print(f"Erreur d'ecoute sur {tab_id}: {e}")
        finally:
            # The connection is gone (Brave's memory saver discards
            # background tabs, killing their debugger sockets). Remove the
            # entry so the tab-monitor can RECONNECT it later — a stale
            # dead socket here meant the tab silently stopped producing
            # captures forever, and every scan kept reading the last old
            # capture as if it were fresh (Goibibo case, 2026-08-16).
            if self.active_connections.get(tab_id) is ws:
                del self.active_connections[tab_id]
                print(f"Onglet {tab_id[:8]} deconnecte — reconnexion "
                      f"possible par le moniteur", flush=True)

    async def start_listening(self, tabs: List[Dict[str, Any]]):
        """Demarre l'ecoute passive sur plusieurs onglets."""
        tasks = []
        
        for tab in tabs:
            tab_id = tab.get("id", "")
            ws_url = tab.get("webSocketDebuggerUrl", "")
            
            if not ws_url:
                continue
            
            if await self.connect_to_tab(ws_url, tab_id):
                await self.enable_network_listening(tab_id)
                task = asyncio.create_task(self.listen_to_tab(tab_id))
                tasks.append(task)
        
        return tasks

    async def stop_listening(self):
        """Arrete l'ecoute sur tous les onglets."""
        await self.stop_auto_refresh()

        for tab_id, ws in self.active_connections.items():
            try:
                await ws.close()
            except Exception:
                pass

        self.active_connections.clear()

    # ------------------------------------------------------------------
    # Auto-refresh (F5 indetectable via CDP Page.reload)
    # ------------------------------------------------------------------

    async def reload_tab(self, tab_id: str) -> bool:
        """
        Reload a tab via CDP Page.reload (hard reload).
        From the server's perspective this is identical to Ctrl+F5:
        same headers, same cookies, same fingerprint, navigator.webdriver=false.
        ignoreCache is REQUIRED for freshness: several OTA PWAs (Expedia
        proven) serve their price graphql from a service-worker cache on
        a plain F5, so the page can look fresh while the response body never
        transits the network again — the passive listener would keep reading
        day-old captures.
        """
        if reload_blocked():
            # An executor run is active — NEVER reload under it (fix
            # 2026-08-27); the caller's own cadence will retry later.
            print("[REFRESH] skipped — executor edition in progress",
                  flush=True)
            return False
        if tab_id not in self.active_connections:
            return False

        ws = self.active_connections[tab_id]
        self._message_id_counter += 1
        cmd_id = self._message_id_counter

        try:
            await ws.send(json.dumps({
                "id": cmd_id,
                "method": "Page.reload",
                "params": {"ignoreCache": True}
            }))
            return True
        except Exception as e:
            print(f"[REFRESH] Erreur reload {tab_id[:8]}: {e}", flush=True)
            return False

    async def _tab_is_visible(self, tab_id: str) -> bool:
        """True if the tab is the one currently on screen.

        Read-only check (document.visibilityState) done on a SEPARATE
        short-lived websocket so the tab's main listener is never touched.
        A reload fired while the tab is hidden is a bot signature: humans
        only press F5 on the tab they are looking at."""
        try:
            import urllib.request
            tabs = json.load(urllib.request.urlopen(
                f"http://localhost:{self.debug_port}/json", timeout=5))
            ws_url = next((t.get("webSocketDebuggerUrl", "") for t in tabs
                           if t.get("id") == tab_id), "")
            if not ws_url:
                return False
            async with websockets.connect(ws_url,
                                          max_size=1024 * 1024) as ws:
                await ws.send(json.dumps({
                    "id": 1, "method": "Runtime.evaluate",
                    "params": {"expression": "document.visibilityState",
                               "returnByValue": True}
                }))
                while True:
                    data = json.loads(await asyncio.wait_for(ws.recv(),
                                                             timeout=5.0))
                    if data.get("id") == 1:
                        return (data.get("result", {})
                                   .get("result", {})
                                   .get("value") == "visible")
        except Exception:
            return False

    async def _auto_refresh_loop(self, tab_id: str, tab_label: str,
                                  min_delay: float, max_delay: float):
        """
        Background loop that refreshes a single tab at randomized intervals.

        Anti-bot hardening (each element mimics a human pressing F5):
          * independent random interval per tab (no cross-tab correlation),
          * interval drawn uniformly in [min_delay, max_delay] — 1-2 h,
          * reload ONLY while the tab is visible on screen: a background
            reload at 3 a.m. is a machine signature no human produces,
          * a short human pause (2-9 s) between the tab becoming visible
            and the reload — nobody hits F5 in the same millisecond.
        """
        # Stagger initial delay so all tabs don't refresh simultaneously
        initial = random.uniform(min_delay, max_delay)
        await asyncio.sleep(initial)

        while self._refreshing:
            # Wait quietly until the user actually looks at this tab
            while self._refreshing and not await self._tab_is_visible(tab_id):
                await asyncio.sleep(random.uniform(180, 480))

            if not self._refreshing:
                break

            # Human pause after the tab comes on screen
            await asyncio.sleep(random.uniform(2, 9))

            if reload_blocked():
                # Executor edition in progress — postpone WITHOUT
                # consuming the refresh slot (fix 2026-08-27).
                await asyncio.sleep(60)
                continue

            success = await self.reload_tab(tab_id)
            status = "OK" if success else "ECHEC"
            ts = datetime.now().strftime('%H:%M:%S')
            print(f"[REFRESH {ts}] {tab_label:35s} {status}", flush=True)

            # Randomized delay between refreshes
            delay = random.uniform(min_delay, max_delay)
            await asyncio.sleep(delay)

    def start_auto_refresh(self, tabs: List[Dict[str, Any]],
                           min_delay: float = 45.0, max_delay: float = 90.0):
        """
        Start auto-refresh for all connected tabs.
        Each tab refreshes at its own randomized interval.
        The reload is done via CDP Page.reload which is identical to F5
        and therefore undetectable by anti-bot systems.
        """
        self._refreshing = True
        self._refresh_tasks = []

        for tab in tabs:
            tab_id = tab.get("id", "")
            if tab_id not in self.active_connections:
                continue

            label = tab.get("ota_domain", tab.get("title", tab_id[:8]))
            task = asyncio.create_task(
                self._auto_refresh_loop(tab_id, label, min_delay, max_delay)
            )
            self._refresh_tasks.append(task)

        print(f"\n[AUTO-REFRESH] {len(self._refresh_tasks)} onglet(s) - "
              f"intervalles {min_delay:.0f}-{max_delay:.0f}s aleatoires\n", flush=True)

    async def stop_auto_refresh(self):
        """Stop all auto-refresh background tasks."""
        self._refreshing = False
        for task in self._refresh_tasks:
            task.cancel()
        self._refresh_tasks = []

    def get_stats(self) -> Dict[str, int]:
        """Retourne les statistiques."""
        return self._stats.copy()

    def get_captured_requests(self) -> List[Dict[str, Any]]:
        """Retourne la liste des requetes capturees."""
        return self.captured_requests.copy()

    def clear_captured_requests(self):
        """Vide la liste des requetes capturees."""
        self.captured_requests.clear()


async def main():
    """Fonction de test."""
    from vae.src.browser.browser_manager import BrowserManager
    
    print("=" * 60)
    print("TEST DU NETWORK INTERCEPTOR")
    print("=" * 60)
    
    manager = BrowserManager()
    
    try:
        await manager.connect()
        await asyncio.sleep(2)
        
        ota_tabs = await manager.get_ota_tabs()
        
        if not ota_tabs:
            print("Aucun onglet OTA detecte")
            return
        
        print(f"\n{len(ota_tabs)} onglet(s) OTA detecte(s)")
        
        interceptor = NetworkInterceptor(manager.debug_port)
        
        async def on_capture(captured):
            print(f"🔍 Requete: {captured.get('url', '')[:80]}...")
        
        interceptor.on_request_captured = on_capture
        
        tasks = await interceptor.start_listening(ota_tabs)
        
        print("\n" + "=" * 60)
        print("ECOUTE ACTIVE - Ctrl+C pour arreter")
        print("=" * 60 + "\n")
        
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            print("\n\nArret...")
        
        await interceptor.stop_listening()
        
        stats = interceptor.get_stats()
        print(f"\n📊 Statistiques :")
        print(f"   Requetes: {stats['requests']}")
        print(f"   Reponses: {stats['responses']}")
        print(f"   Bodies OK: {stats['bodies_retrieved']}")
        print(f"   Bodies echoues: {stats['bodies_failed']}")
        
    except Exception as e:
        print(f"Erreur: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await manager.close()


if __name__ == "__main__":
    asyncio.run(main())