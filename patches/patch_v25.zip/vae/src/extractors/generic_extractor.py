"""
Extracteur generique dynamique pour OTA Guard VAE.
Lit les fichiers YAML de mapping dans config/ota_mappings/
pour extraire les donnees de n'importe quelle OTA sans modifier le code.
"""

import json
import re
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field

from vae.config import get_mappings_dir, get_data_dir, get_target_currency, HOTEL_CONFIG_FILE
from vae.src.extractors.currency_converter import CurrencyConverter


@dataclass
class Price:
    """Room pricing breakdown. Original currency + normalized to target."""
    base_price: float = 0.0
    discount: float = 0.0
    price_after_discount: float = 0.0
    taxes: float = 0.0
    total_amount: float = 0.0
    currency: str = ""
    per_night: bool = True
    # Normalized fields (in target currency, e.g., EUR)
    base_price_normalized: float = 0.0
    discount_normalized: float = 0.0
    price_after_discount_normalized: float = 0.0
    taxes_normalized: float = 0.0
    total_amount_normalized: float = 0.0
    target_currency: str = ""

    @property
    def has_data(self) -> bool:
        """True if at least one price field is non-zero."""
        return any([
            self.base_price, self.discount, self.price_after_discount,
            self.taxes, self.total_amount
        ])

    def normalize(self, converter, target_currency: str):
        """Convert all price fields to the target currency."""
        self.target_currency = target_currency
        cur = self.currency
        if not cur or cur == target_currency:
            # Same currency: copy values
            self.base_price_normalized = self.base_price
            self.discount_normalized = self.discount
            self.price_after_discount_normalized = self.price_after_discount
            self.taxes_normalized = self.taxes
            self.total_amount_normalized = self.total_amount
        else:
            self.base_price_normalized = converter.convert(self.base_price, cur, target_currency)
            self.discount_normalized = converter.convert(self.discount, cur, target_currency)
            self.price_after_discount_normalized = converter.convert(self.price_after_discount, cur, target_currency)
            self.taxes_normalized = converter.convert(self.taxes, cur, target_currency)
            self.total_amount_normalized = converter.convert(self.total_amount, cur, target_currency)


@dataclass
class Room:
    id: str = ""
    name: str = ""
    size: str = ""
    view: str = ""
    beds: List[Dict] = field(default_factory=list)
    max_guests: int = 0
    max_adults: int = 0
    max_children: int = 0
    bed_count: int = 0
    bedroom_count: int = 0
    price: Optional[Price] = None


@dataclass
class Review:
    author: str = ""
    rating: float = 0.0
    title: str = ""
    text: str = ""
    date: str = ""
    travel_type: str = ""


@dataclass
class NearbyPlace:
    name: str = ""
    distance: str = ""
    category: str = ""
    tag_line: str = ""


@dataclass
class PopularAmenity:
    name: str = ""
    sub_text: str = ""


@dataclass
class HotelData:
    ota: str = ""
    ota_id: str = ""
    internal_id: str = ""
    name: str = ""
    address_line1: str = ""
    address_line2: str = ""
    description: str = ""
    short_description: str = ""
    star_rating: float = 0.0
    property_type: str = ""
    checkin_time: str = ""
    checkout_time: str = ""
    latitude: float = 0.0
    longitude: float = 0.0
    pin_code: str = ""
    primary_area: str = ""
    cumulative_rating: float = 0.0
    review_count: int = 0
    rating_text: str = ""
    rooms: List[Room] = field(default_factory=list)
    reviews: List[Review] = field(default_factory=list)
    amenities: Dict[str, List[str]] = field(default_factory=dict)
    popular_amenities: List[PopularAmenity] = field(default_factory=list)
    nearby_places: Dict[str, List[NearbyPlace]] = field(default_factory=dict)

    @property
    def full_address(self) -> str:
        """Retourne l'adresse complete formatee."""
        parts = [self.address_line1, self.address_line2]
        return ", ".join(p for p in parts if p).strip(", ")


class GenericExtractor:
    """
    Extracteur generique qui lit les mappings YAML dynamiquement.
    """

    def __init__(self, mappings_dir: str = "", data_dir: str = "",
                 target_currency: str = ""):
        self.mappings_dir = Path(mappings_dir) if mappings_dir else get_mappings_dir()
        self.data_dir = Path(data_dir) if data_dir else get_data_dir()
        self.target_currency = target_currency or get_target_currency()
        self.mappings = {}
        self._currency_converter = None
        self.hotel_name = self._load_hotel_name()
        self._load_all_mappings()

    def _load_hotel_name(self) -> str:
        """Load the configured hotel name for filtering aggregate OTA responses."""
        try:
            with open(HOTEL_CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            return str(cfg.get("hotel", {}).get("name", "") or "").strip()
        except Exception:
            return ""

    def _load_all_mappings(self):
        """Charge tous les fichiers YAML de mapping du dossier."""
        if not self.mappings_dir.exists():
            print(f"Dossier de mappings introuvable : {self.mappings_dir}")
            return

        yaml_files = list(self.mappings_dir.glob("*.yaml")) + list(self.mappings_dir.glob("*.yml"))

        if not yaml_files:
            print("Aucun fichier de mapping trouve")
            return

        for yaml_file in yaml_files:
            try:
                with open(yaml_file, 'r', encoding='utf-8') as f:
                    mapping = yaml.safe_load(f)

                if mapping and 'ota_name' in mapping:
                    self.mappings[mapping['ota_name']] = mapping
                    print(f"Mapping charge : {mapping['ota_name']}")
                else:
                    print(f"Fichier YAML invalide : {yaml_file.name}")

            except Exception as e:
                print(f"Erreur chargement {yaml_file.name} : {e}")

    # ISO 4217 declarations + common currency symbols (generic — any OTA)
    _CURRENCY_DECL_RE = re.compile(
        r'"(?:currency(?:Code)?|cur)"\s*:\s*"([A-Z]{3}|[฿$€£¥₹])"')
    _SYMBOL_TO_ISO = {"฿": "THB", "$": "USD", "€": "EUR", "£": "GBP",
                      "¥": "JPY", "₹": "INR"}

    @classmethod
    def _detect_payload_currency(cls, data: Any) -> str:
        """Detect the page currency from the payload itself (generic).

        Votes over every `currency`/`currencyCode` declaration in the
        serialized body — ISO codes count as-is, symbols map to ISO.
        Returns the winning ISO code, or "" when nothing is declared.
        Incident fixed (19/09): an Agoda payload in THB extracted with
        an empty currency, so THB numbers were copied to the target
        currency unconverted."""
        try:
            text = data if isinstance(data, str) else json.dumps(data)
            votes: Dict[str, int] = {}
            for raw in cls._CURRENCY_DECL_RE.findall(text):
                code = cls._SYMBOL_TO_ISO.get(raw, raw)
                if len(code) == 3 and code.isalpha() and code.isupper():
                    votes[code] = votes.get(code, 0) + 1
            if not votes:
                return ""
            return max(votes.items(), key=lambda kv: kv[1])[0]
        except Exception:
            return ""

    def get_json_path(self, data: Any, path: str) -> Any:
        """
        Navigate nested JSON using dot-notation paths.
        When a non-digit key is encountered on a list, auto-navigates
        to the first element (list[0]). This handles auto-generated
        paths that traverse arrays without explicit indices.
        """
        if not path or not data:
            return None

        keys = path.split('.')
        current = data

        for key in keys:
            if current is None:
                return None
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list):
                if key.isdigit():
                    idx = int(key)
                    current = current[idx] if idx < len(current) else None
                elif current and isinstance(current[0], dict):
                    # Non-digit key on a list: auto-navigate to first element
                    current = current[0].get(key)
                else:
                    return None
            else:
                return None

        return current

    def _find_latest_file(self, file_pattern: str) -> Optional[Path]:
        """Trouve le fichier JSON le plus recent correspondant au pattern."""
        files = list(self.data_dir.glob(file_pattern))
        if not files:
            return None
        return max(files, key=lambda p: p.stat().st_mtime)

    def _get_detect_path(self, full_path: str) -> str:
        """
        Detection path used to find which file contains a given data section.
        Uses the FULL field path (not the parent) so that files with a partial
        structure (e.g. search-rooms having hotelDetails but without 'name')
        are not falsely matched.
        """
        return full_path or ""

    def _find_data_for_section(self, file_pattern: str, detect_path: str,
                               file_cache: Dict[str, dict]) -> Optional[dict]:
        """
        Find the JSON data containing a given path.
        Scans files from newest to oldest, caches loaded files.
        Modern OTAs split data across multiple API calls (details, pricing,
        reviews), so each section must find its own correct file.
        """
        if not detect_path:
            # Fallback: return the newest file
            fp = self._find_latest_file(file_pattern)
            if not fp:
                return None
            return self._load_cached(fp, file_cache)

        files = sorted(self.data_dir.glob(file_pattern),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        for fp in files:
            d = self._load_cached(fp, file_cache)
            if d is None:
                continue
            if self.get_json_path(d, detect_path) is not None:
                return d
        return None

    def _load_cached(self, filepath: Path, cache: Dict[str, dict]) -> Optional[dict]:
        """Load a JSON file with caching to avoid re-reading."""
        key = str(filepath)
        if key in cache:
            return cache[key]
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                raw = f.read()

            # Google Travel/Hotels batchexecute responses can start either
            # with the classic )]}' prefix or directly with [["wrb.fr", ...]].
            # They are not ordinary JSON objects containing the hotel prices;
            # parse them into a small synthetic structure first.
            stripped = raw.lstrip()
            if stripped.startswith(")]}'") or '"wrb.fr"' in stripped[:200]:
                d = self._parse_google_batchexecute(raw, self.hotel_name)
            else:
                d = json.loads(raw)

            # Unwrap GraphQL responses: [{data: ..., extensions: ...}] -> {data: ...}
            if isinstance(d, list) and d and isinstance(d[0], dict):
                d = d[0]
            cache[key] = d
            return d
        except Exception:
            cache[key] = None
            return None

    def _parse_google_batchexecute(self, raw: str, hotel_name: str = "") -> dict:
        """Parse Google Travel/Hotels batchexecute into synthetic hotel offers."""
        import re

        text = raw.lstrip()
        if text.startswith(")]}'"):
            text = text[4:].lstrip()

        price_pattern = re.compile(
            r'\\"([A-Z]{3})[\s\u00a0]+([0-9][0-9,.]*)\\",null,([0-9]+(?:\.[0-9]+)?)'
        )
        name_pattern = re.compile(r'\\"/g/[^"]+\\",\\"([^"]+)\\"')

        hotels = []
        seen = set()

        for match in price_pattern.finditer(text):
            currency = match.group(1)
            raw_price = float(match.group(3))
            if raw_price <= 0 or raw_price > 50000000:
                continue

            context = text[max(0, match.start() - 5000):match.start()]
            names = name_pattern.findall(context)
            detected_name = names[-1].strip() if names else ""
            # Google response contains many unrelated hotel/teaser prices.
            # If the configured hotel is known, keep only offers belonging to it.
            if hotel_name and detected_name:
                if hotel_name.lower() not in detected_name.lower() and detected_name.lower() not in hotel_name.lower():
                    continue
            elif hotel_name and not detected_name:
                continue

            offer_name = detected_name or hotel_name or "Google Hotels"

            key = (offer_name.lower(), currency, round(raw_price, 2))
            if key in seen:
                continue
            seen.add(key)

            hotels.append({
                "name": offer_name,
                "displayPrice": raw_price,
                "currency": currency,
            })

        return {"google_hotels": hotels} if hotels else {}

    def extract_ota(self, ota_name: str) -> Optional[HotelData]:
        """Extrait les donnees d'une OTA specifique."""
        if ota_name not in self.mappings:
            print(f"Aucun mapping trouve pour l'OTA : {ota_name}")
            return None

        mapping = self.mappings[ota_name]
        file_pattern = mapping.get('file_pattern', f"*{ota_name}*body.json")
        file_cache = {}

        # Verify at least one matching file exists
        all_files = list(self.data_dir.glob(file_pattern))
        if not all_files:
            print(f"Aucun fichier JSON trouve pour {ota_name}")
            return None

        hotel = HotelData()
        hotel.ota = ota_name

        # Extraire les infos de base
        hotel_fields = mapping.get('hotel_fields', {})
        if hotel_fields:
            detect = self._get_detect_path(list(hotel_fields.values())[0])
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                for field_name, json_path in hotel_fields.items():
                    value = self.get_json_path(data, json_path)
                    if value is not None:
                        setattr(hotel, field_name, value)

        # Extraire la note globale
        rating_config = mapping.get('rating', {})
        if rating_config:
            detect = self._get_detect_path(list(rating_config.values())[0])
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                for field_name, json_path in rating_config.items():
                    value = self.get_json_path(data, json_path)
                    if value is not None:
                        if field_name == 'cumulative':
                            hotel.cumulative_rating = float(value)
                        elif field_name == 'count':
                            hotel.review_count = int(value)
                        elif field_name == 'rating_text':
                            hotel.rating_text = str(value)
                        else:
                            setattr(hotel, field_name, value)

        # Extraire les chambres
        rooms_config = mapping.get('rooms', {})
        if rooms_config:
            detect = rooms_config.get('path', '')
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                hotel.rooms = self._extract_rooms(data, rooms_config)

        # Extraire les avis
        reviews_config = mapping.get('reviews', {})
        if reviews_config:
            detect = reviews_config.get('path', '')
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                hotel.reviews = self._extract_reviews(data, reviews_config)

        # Extraire les equipements
        amenities_config = mapping.get('amenities', {})
        if amenities_config:
            detect = amenities_config.get('path', '')
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                hotel.amenities = self._extract_amenities(data, amenities_config)

        # Extraire les equipements populaires
        popular_config = mapping.get('popular_amenities', {})
        if popular_config:
            detect = popular_config.get('path', '')
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                hotel.popular_amenities = self._extract_popular_amenities(data, popular_config)

        # Extraire les lieux a proximite
        nearby_config = mapping.get('nearby_places', {})
        if nearby_config:
            detect = nearby_config.get('path', '')
            data = self._find_data_for_section(file_pattern, detect, file_cache)
            if data:
                hotel.nearby_places = self._extract_nearby_places(data, nearby_config)

        # Extraire les prix (peuvent venir d'un fichier different)
        prices_config = mapping.get('prices', {})
        if prices_config:
            self._extract_prices(hotel, file_pattern, file_cache, prices_config)

        # Normalize all prices to the target currency
        if self.target_currency and hotel.rooms:
            if self._currency_converter is None:
                self._currency_converter = CurrencyConverter()
            for room in hotel.rooms:
                if room.price and room.price.has_data:
                    room.price.normalize(self._currency_converter, self.target_currency)

        return hotel

    def _extract_rooms(self, data: Any, config: Dict) -> List[Room]:
        """Extrait les chambres selon le mapping."""
        rooms_path = config.get('path', '')
        rooms_type = config.get('type', 'dict')
        fields_map = config.get('fields', {})

        rooms_data = self.get_json_path(data, rooms_path)

        if not rooms_data:
            return []

        rooms = []

        if rooms_type == 'dict':
            for room_id, room_info in rooms_data.items():
                if not isinstance(room_info, dict):
                    continue
                room = Room(id=str(room_id))
                for field_name, json_key in fields_map.items():
                    if field_name == 'id':
                        continue
                    value = room_info.get(json_key)
                    if value is not None:
                        setattr(room, field_name, value)
                rooms.append(room)

        elif rooms_type == 'list':
            for room_info in rooms_data:
                if not isinstance(room_info, dict):
                    continue
                room = Room()
                for field_name, json_key in fields_map.items():
                    value = room_info.get(json_key)
                    if value is not None:
                        setattr(room, field_name, value)
                rooms.append(room)

        return rooms

    def _extract_reviews(self, data: Any, config: Dict) -> List[Review]:
        """Extrait les avis selon le mapping."""
        reviews_path = config.get('path', '')
        fields_map = config.get('fields', {})

        reviews_data = self.get_json_path(data, reviews_path)

        if not reviews_data or not isinstance(reviews_data, list):
            return []

        reviews = []
        for rev_info in reviews_data:
            if not isinstance(rev_info, dict):
                continue
            review = Review()
            for field_name, json_key in fields_map.items():
                value = rev_info.get(json_key)
                if value is not None:
                    setattr(review, field_name, value)
            reviews.append(review)

        return reviews

    def _extract_amenities(self, data: Any, config: Dict) -> Dict[str, List[str]]:
        """Extrait les equipements selon le mapping."""
        amenities_path = config.get('path', '')
        data_key = config.get('data_key', 'data')
        label_key = config.get('label_key', 'label')

        amenities_data = self.get_json_path(data, amenities_path)

        if not amenities_data or not isinstance(amenities_data, list):
            return {}

        amenities = {}
        for category in amenities_data:
            if isinstance(category, dict):
                label = category.get(label_key, 'Autres')
                items = category.get(data_key, [])
                if isinstance(items, list):
                    amenities[label] = items

        return amenities

    def _extract_popular_amenities(self, data: Any, config: Dict) -> List[PopularAmenity]:
        """Extrait les equipements populaires."""
        popular_path = config.get('path', '')
        fields_map = config.get('fields', {})

        popular_data = self.get_json_path(data, popular_path)

        if not popular_data or not isinstance(popular_data, list):
            return []

        amenities = []
        for item in popular_data:
            if isinstance(item, dict):
                amenity = PopularAmenity()
                for field_name, json_key in fields_map.items():
                    value = item.get(json_key)
                    if value is not None:
                        setattr(amenity, field_name, value)
                amenities.append(amenity)

        return amenities

    def _extract_nearby_places(self, data: Any, config: Dict) -> Dict[str, List[NearbyPlace]]:
        """Extrait les lieux a proximite."""
        nearby_path = config.get('path', '')
        data_key = config.get('data_key', 'category_data')
        label_key = config.get('label_key', 'category_type')
        item_fields = config.get('item_fields', {})

        nearby_data = self.get_json_path(data, nearby_path)

        if not nearby_data or not isinstance(nearby_data, list):
            return {}

        nearby_places = {}
        for category in nearby_data:
            if isinstance(category, dict):
                label = category.get(label_key, 'Autres')
                items = category.get(data_key, [])

                if isinstance(items, list):
                    places = []
                    for item in items:
                        if isinstance(item, dict):
                            place = NearbyPlace()
                            for field_name, json_key in item_fields.items():
                                value = item.get(json_key)
                                if value is not None:
                                    setattr(place, field_name, str(value))
                            places.append(place)
                    nearby_places[label] = places

        return nearby_places

    def _extract_prices(self, hotel: HotelData, file_pattern: str,
                       file_cache: Dict[str, dict], config: Dict) -> None:
        """
        Extract pricing data and attach Price objects to rooms.
        Supports two modes:
          - details_array: prices are in a list of {key, amount, label} items
          - direct: prices are in direct fields on each room item
        Prices may come from a different file than room details.
        """
        rooms_path = config.get('rooms_path', '')
        room_name_key = config.get('room_name_key', 'roomName')
        room_code_key = config.get('room_code_key', '')
        currency_path = config.get('currency_path', '')
        mode = config.get('mode', 'details_array')

        # Find the file containing pricing data.
        # Try each file that has the rooms_path, until one yields actual prices.
        # Different API endpoints may share the same path but contain different
        # data (e.g., Airbnb StaysPdpSections vs StaysPdpBookIt).
        # NEWEST FIRST: OTA prices move during the day — an old large capture
        # must never shadow a fresher one just because it is bigger.
        all_files = sorted(self.data_dir.glob(file_pattern),
                           key=lambda p: p.stat().st_mtime, reverse=True)
        pricing_data = None
        rooms_data = None

        for fp in all_files:
            d = self._load_cached(fp, file_cache)
            if d is None:
                continue
            candidate_rooms = self.get_json_path(d, rooms_path)
            if not candidate_rooms or not isinstance(candidate_rooms, list):
                continue
            # Verify first item actually has pricing data
            if candidate_rooms and isinstance(candidate_rooms[0], dict):
                test_price = None
                if mode == 'details_array':
                    test_price = self._build_price_from_details(
                        candidate_rooms[0], config, '')
                else:
                    test_price = self._build_price_direct(
                        candidate_rooms[0], config, '')
                if test_price and test_price.has_data:
                    pricing_data = d
                    rooms_data = candidate_rooms
                    break

        if not pricing_data:
            print(f"  [PRIX] Aucun fichier avec des prix exploitables trouve")
            return

        # Get currency: search the pricing file first, then fall back to any file
        currency = ""
        if currency_path:
            currency = str(self.get_json_path(pricing_data, currency_path) or "")
            if not currency:
                for fp in all_files:
                    d = self._load_cached(fp, file_cache)
                    if d is None:
                        continue
                    val = self.get_json_path(d, currency_path)
                    if val:
                        currency = str(val)
                        break

        # AUTOMATIC PAYLOAD-CURRENCY DETECTION (19/09, incident Agoda/THB) :
        # quand le mapping ne fournit pas de currency_path (ou qu'il ne
        # resolves nothing), the PAGE currency is read from the payload
        # itself — any Agoda/OTA payload displaying prices declares its
        # devise ("currencyCode":"THB", ou symbole "currency":"฿").
        # Without this detection, normalize() copied THB numbers as-is
        # into the target currency (false report). Generic: no
        # per-OTA rule — we vote on the ISO/symbol declarations of the
        # fichier qui porte les prix.
        if not currency:
            currency = self._detect_payload_currency(pricing_data)

        # Build lookup tables for matching prices to existing rooms
        room_by_name = {}
        room_by_code = {}
        for room in hotel.rooms:
            if room.name:
                room_by_name[room.name.lower().strip()] = room
            if room.id:
                room_by_code[str(room.id)] = room

        matched_count = 0
        for room_item in rooms_data:
            if not isinstance(room_item, dict):
                continue

            # Build the Price object
            if mode == 'details_array':
                price = self._build_price_from_details(room_item, config, currency)
            else:
                price = self._build_price_direct(room_item, config, currency)

            if not price or not price.has_data:
                continue

            # Find room name and code for matching.
            # get_json_path, not dict.get: mapping keys may be nested dotted
            # paths (Expedia 'header.text') — a plain .get() leaves the room
            # unnamed and the price falls into the hotel-level fallback.
            room_name = str(self.get_json_path(room_item, room_name_key) or "") if room_name_key else ""
            room_code = str(self.get_json_path(room_item, room_code_key) or "") if room_code_key else ""

            # Match to existing room
            matched_room = None
            if room_code and room_code in room_by_code:
                matched_room = room_by_code[room_code]
            elif room_name and room_name.lower().strip() in room_by_name:
                matched_room = room_by_name[room_name.lower().strip()]

            if matched_room:
                matched_room.price = price
                matched_count += 1
            else:
                # No match: create a minimal room with just the price
                new_room = Room(name=room_name, id=room_code, price=price)
                hotel.rooms.append(new_room)
                matched_count += 1

        print(f"  [PRIX] {matched_count} chambre(s) avec prix")

    def _build_price_from_details(self, room_item: dict, config: Dict, currency: str) -> Optional[Price]:
        """
        Build Price from a 'details' array structure.
        Path config:
          - price_plan_path: path to the priceMap dict (first plan is used)
          - details_key: key within each plan containing the details array
          - key_mapping: maps detail keys (BASE_FARE, etc.) to Price fields
        """
        price_plan_path = config.get('price_plan_path', '')
        details_key = config.get('details_key', 'details')
        key_mapping = config.get('key_mapping', {})

        if not price_plan_path:
            return None

        price_map = self.get_json_path(room_item, price_plan_path)
        if not price_map or not isinstance(price_map, dict):
            # price_plan_path might point directly to a list
            if isinstance(price_map, list):
                details_list = price_map
            else:
                return None
        else:
            # Plan selection: when the tariff object names a DEFAULT plan
            # (defaultPriceKey), that plan is the one the site displays on
            # the room card. Taking values()[0] instead picks an arbitrary
            # promo plan (Goibibo: GORBLFEST is first in the map, but the
            # card shows the default GOSMARTDEAL price).
            plan = None
            if price_plan_path.endswith('.priceMap'):
                parent = self.get_json_path(
                    room_item, price_plan_path[:-len('.priceMap')])
                if isinstance(parent, list) and parent and isinstance(parent[0], dict):
                    parent = parent[0]
                if isinstance(parent, dict):
                    default_key = parent.get('defaultPriceKey')
                    if default_key and default_key in price_map:
                        plan = price_map[default_key]
            if plan is None and price_map:
                plan = list(price_map.values())[0]
            if not isinstance(plan, dict):
                return None
            details_list = plan.get(details_key, [])

        if not isinstance(details_list, list):
            return None

        price = Price(currency=currency)
        for item in details_list:
            if not isinstance(item, dict):
                continue
            item_key = item.get('key', '')
            amount = item.get('amount', 0)
            if item_key in key_mapping:
                field_name = key_mapping[item_key]
                try:
                    setattr(price, field_name, float(amount))
                except (ValueError, TypeError):
                    pass

        return price

    def _parse_price_string(self, value: str) -> Optional[float]:
        """
        Extract a numeric value from a formatted price string.
        Handles: "27 €", "1,234.56", "1.234,56", "₹2,700", "$1,299"
        """
        import re
        # Remove currency symbols and whitespace
        cleaned = re.sub(r'[€$£¥₹₩₺\s]', '', str(value))
        if not cleaned:
            return None

        # Handle European format: "1.234,56" -> "1234.56"
        if ',' in cleaned and '.' in cleaned:
            cleaned = cleaned.replace('.', '').replace(',', '.')
        elif ',' in cleaned:
            parts = cleaned.split(',')
            if len(parts) == 2 and len(parts[1]) <= 2:
                cleaned = cleaned.replace(',', '.')
            else:
                cleaned = cleaned.replace(',', '')

        try:
            return float(cleaned)
        except ValueError:
            return None

    def _build_price_direct(self, room_item: dict, config: Dict, currency: str) -> Optional[Price]:
        """
        Build Price from direct fields on the room item.
        Config 'fields' maps Price field names to JSON paths (dot-notation)
        relative to the room item. Uses get_json_path for nested paths.
        Handles numeric values, dicts with numeric sub-values, and
        formatted price strings like "27 €".
        """
        fields_map = config.get('fields', {})
        if not fields_map:
            return None

        price = Price(currency=currency)
        for field_name, json_path in fields_map.items():
            value = self.get_json_path(room_item, json_path)
            if value is None:
                continue

            if isinstance(value, (int, float)):
                try:
                    setattr(price, field_name, float(value))
                except (ValueError, TypeError):
                    pass
            elif isinstance(value, str):
                parsed = self._parse_price_string(value)
                if parsed is not None:
                    setattr(price, field_name, parsed)
                # Always try to extract currency from the string
                if not price.currency:
                    for sym, cur in [('€', 'EUR'), ('$', 'USD'), ('£', 'GBP'),
                                     ('₹', 'INR'), ('¥', 'JPY'), ('₩', 'KRW')]:
                        if sym in value:
                            price.currency = cur
                            break
        return price

    def print_summary(self, hotel: HotelData):
        """Affiche un resume propre des donnees extraites."""
        print(f"\n{'='*70}")
        print(f"🏨 {hotel.name} (OTA: {hotel.ota} | ID: {hotel.ota_id})")
        print(f"{'='*70}")
        print(f"📍 Adresse     : {hotel.full_address}")
        print(f"📍 Code postal : {hotel.pin_code} | Zone : {hotel.primary_area}")
        print(f"🗺️ Coordonnees : {hotel.latitude}, {hotel.longitude}")
        print(f"⭐ Note        : {hotel.star_rating} etoiles ({hotel.rating_text})")
        print(f"🏷️ Type        : {hotel.property_type}")
        print(f"⏰ Check-in    : {hotel.checkin_time} | Check-out : {hotel.checkout_time}")
        print(f"💬 Avis        : {hotel.cumulative_rating}/5 ({hotel.review_count} avis)")

        print(f"\n📝 Description :")
        desc = hotel.description or hotel.short_description
        if desc:
            print(f"   {desc[:200]}...")

        print(f"\n🛏️ CHAMBRES ({len(hotel.rooms)} types) :")
        for i, room in enumerate(hotel.rooms, 1):
            beds_str = ", ".join([f"{b.get('count', 0)}x {b.get('type', '?')}" for b in room.beds]) if room.beds else "N/A"
            print(f"   {i}. {room.name}")
            print(f"      Taille: {room.size} | Vue: {room.view}")
            print(f"      Lits: {beds_str} | Max: {room.max_guests} pers. ({room.max_adults} adultes + {room.max_children} enfants)")
            if room.price and room.price.has_data:
                p = room.price
                cur = p.currency or "?"
                parts = []
                if p.base_price:
                    parts.append(f"Base: {p.base_price} {cur}")
                if p.discount:
                    parts.append(f"Remise: -{p.discount} {cur}")
                if p.price_after_discount:
                    parts.append(f"Apres remise: {p.price_after_discount} {cur}")
                if p.taxes:
                    parts.append(f"Taxes: +{p.taxes} {cur}")
                if p.total_amount:
                    parts.append(f"TOTAL: {p.total_amount} {cur}")
                nightly = "/nuit" if p.per_night else ""
                print(f"      💰 {nightly} " + " | ".join(parts))

        print(f"\n💬 DERNIERS AVIS ({len(hotel.reviews)}) :")
        for rev in hotel.reviews[:3]:
            title = rev.title or "(sans titre)"
            print(f"   [{rev.rating}/5] {title} par {rev.author} ({rev.date[:10]})")
            print(f"      \"{rev.text[:100]}...\"")

        print(f"\n✨ EQUIPEMENTS ({len(hotel.amenities)} categories) :")
        for category, items in list(hotel.amenities.items())[:6]:
            print(f"   • {category} : {', '.join(items[:4])}...")

        if hotel.popular_amenities:
            print(f"\n⭐ EQUIPEMENTS POPULAIRES :")
            for amenity in hotel.popular_amenities[:5]:
                sub = f" {amenity.sub_text}" if amenity.sub_text else ""
                print(f"   • {amenity.name}{sub}")

        if hotel.nearby_places:
            print(f"\n📍 LIEUX A PROXIMITE :")
            for category, places in list(hotel.nearby_places.items())[:3]:
                print(f"   {category} :")
                for place in places[:3]:
                    print(f"      - {place.name} ({place.distance} km) : {place.tag_line}")

        print(f"{'='*70}")


def main():
    print("=" * 70)
    print("EXTRACTEUR GENERIQUE DYNAMIQUE - OTA GUARD VAE")
    print("=" * 70)

    extractor = GenericExtractor()

    if not extractor.mappings:
        print("Aucun mapping charge. Ajoutez des fichiers YAML dans config/ota_mappings/")
        return

    print(f"\n{len(extractor.mappings)} OTA(s) configuree(s) : {', '.join(extractor.mappings.keys())}")

    for ota_name in extractor.mappings.keys():
        print(f"\n{'='*60}")
        print(f"Extraction : {ota_name}")
        print(f"{'='*60}")
        hotel = extractor.extract_ota(ota_name)
        if hotel:
            extractor.print_summary(hotel)
        else:
            print(f"Echec de l'extraction pour {ota_name}")

    print(f"\nExtraction terminee")


if __name__ == "__main__":
    main()
