"""Patch: install _pick_date v4 (month subview) into vae2/executor.py."""
import ast
from pathlib import Path

p = Path(__file__).parent / "vae2" / "executor.py"
src = p.read_text(encoding="utf-8")

start = src.index("    async def _pick_date")
end = src.index("\n    # ── main workflow", start)

NEW = '''    _MONTHS_SHORT = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5,
                     "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10,
                     "nov": 11, "dec": 12}

    async def _pick_date(self, css: str, iso: str, what: str) -> None:
        """Set a readOnly date field the human way, POSITION-INDEPENDENT:
        - deterministic placement via scrollIntoView(center) + picker-rect
          adjustment so the whole picker clears the navbar;
        - month selection through the picker SUBVIEW (header click -> 12
          month cells at the BOTTOM of the picker, always visible) — the
          header arrows sit at the clipped top and were the endless
          source of failures;
        - day cell click; strict read-back (D12). Trusted CDP input only,
          scrolls are layout-only."""
        y, m, d = (int(x) for x in iso.split("-"))
        current = await self.read_field(css) or ""
        expected = self._format_date_like(current, iso)

        # 1. deterministic placement: input at viewport center
        await self.js(
            f"var e=document.querySelector({json.dumps(css)});"
            "if(e)e.scrollIntoView({block:'center'});")
        await self._sleep(0.5, 0.9)

        # 2. open the picker: click the input; icon as fallback
        await self.key_event("keyDown", key="Escape", vk=27)
        await self.key_event("keyUp", key="Escape", vk=27)
        inp_expr = (
            f"(function(){{var inp=document.querySelector({json.dumps(css)});"
            f"if(!inp)return null;var r=inp.getBoundingClientRect();"
            f"return JSON.stringify({{x:r.x+r.width/2,y:r.y+r.height/2,"
            f"inV:r.top>=140&&r.bottom<=window.innerHeight-20}});}})()")
        b = await self._scroll_expr_until_visible(inp_expr, f"{what} input")
        await self._click_xy(b["x"], b["y"], f"{what} input (open picker)")
        await self._sleep(0.8, 1.4)

        picker_js = ("(function(){var picks=document.querySelectorAll('.datepicker');"
                     "for(var i=0;i<picks.length;i++){var p=picks[i];"
                     "var st=getComputedStyle(p);"
                     "if(st.display==='none'||st.visibility==='hidden')continue;"
                     "var r0=p.getBoundingClientRect();if(r0.width<100)continue;"
                     "var DAYS=p.querySelector('.datepicker-days');"
                     "if(!DAYS||DAYS.offsetWidth===0)continue;"
                     "return JSON.stringify({top:Math.round(r0.top),"
                     "bottom:Math.round(r0.bottom)});}"
                     "return null;})()")
        pk = await self.js(picker_js)
        if not pk:
            icon_expr = (
                f"(function(){{var inp=document.querySelector({json.dumps(css)});"
                f"if(!inp)return null;var btn=inp.parentElement.querySelector("
                f"'.input-group-btn');if(!btn)return null;"
                f"var r=btn.getBoundingClientRect();"
                f"return JSON.stringify({{x:r.x+r.width/2,y:r.y+r.height/2,"
                f"inV:r.top>=140&&r.bottom<=window.innerHeight-20}});}})()")
            b = await self._scroll_expr_until_visible(icon_expr,
                                                      f"{what} calendar icon")
            await self._click_xy(b["x"], b["y"], f"{what} calendar icon")
            await self._sleep(0.8, 1.4)
            pk = await self.js(picker_js)
        if not pk:
            raise ExecutorError(f"{what}: datepicker popup did not open")
        pk = json.loads(pk)

        # 3. if the picker top is under the navbar, scroll the page UP
        #    (picker is document-positioned, it moves with the content)
        if pk["top"] < 150:
            dy = pk["top"] - 170
            await self.js(f"window.scrollBy(0, {dy})")
            await self._sleep(0.5, 0.9)
            pk2raw = await self.js(picker_js)
            pk2 = json.loads(pk2raw) if pk2raw else None
            if pk2 is None or pk2["top"] < 150:
                raise ExecutorError(
                    f"{what}: picker top stuck ({pk2}) — cannot clear navbar")
            pk = pk2

        header_js = ("(function(){var picks=document.querySelectorAll('.datepicker');"
                     "for(var i=0;i<picks.length;i++){var p=picks[i];"
                     "var st=getComputedStyle(p);if(st.display==='none')continue;"
                     "var DAYS=p.querySelector('.datepicker-days');"
                     "if(!DAYS||DAYS.offsetWidth===0)continue;"
                     "var sw=p.querySelector('.datepicker-days .datepicker-switch');"
                     "return sw?sw.textContent.trim():null;}"
                     "return null;})()")
        info = await self.js(header_js)
        if not info:
            raise ExecutorError(f"{what}: picker header unreadable")
        shown = self._parse_switch(info)
        if shown is None:
            raise ExecutorError(f"{what}: cannot parse header '{info}'")
        self.log("datepicker", f"{what} shows '{info}'")

        if shown != (y, m):
            # 4a. open the month subview (click the days-header switch)
            switch_click = (
                "(function(){var picks=document.querySelectorAll('.datepicker');"
                "for(var i=0;i<picks.length;i++){var p=picks[i];"
                "var st=getComputedStyle(p);if(st.display==='none')continue;"
                "var DAYS=p.querySelector('.datepicker-days');"
                "if(!DAYS||DAYS.offsetWidth===0)continue;"
                "var sw=p.querySelector('.datepicker-days .datepicker-switch');"
                "if(!sw)return null;var r=sw.getBoundingClientRect();"
                "return JSON.stringify({x:Math.round(r.x+r.width/2),"
                "y:Math.round(r.y+r.height/2),"
                "inV:r.top>=140&&r.bottom<=window.innerHeight-20});}"
                "return null;})()")
            sb = json.loads(await self.js(switch_click) or "null")
            if not sb or not sb.get("inV"):
                raise ExecutorError(f"{what}: month switch not clickable")
            await self._click_xy(sb["x"], sb["y"], f"{what} open months")
            await self._sleep(0.6, 1.0)

            # 4b. year arrows in the months view (its OWN header, mid-picker)
            for _ in range(30):
                yh = await self.js(
                    "(function(){var picks=document.querySelectorAll("
                    "'.datepicker');"
                    "for(var i=0;i<picks.length;i++){var p=picks[i];"
                    "var st=getComputedStyle(p);if(st.display==='none')continue;"
                    "var MV=p.querySelector('.datepicker-months');"
                    "if(!MV||MV.offsetWidth===0)continue;"
                    "var sw=MV.querySelector('.datepicker-switch');"
                    "return sw?sw.textContent.trim():null;}"
                    "return null;})()")
                yshown = int(yh.strip()) if yh and yh.strip().isdigit() else None
                if yshown == y:
                    break
                nav = "prev" if (yshown or shown[0]) > y else "next"
                ya = await self.js(
                    "(function(){var picks=document.querySelectorAll("
                    "'.datepicker');"
                    "for(var i=0;i<picks.length;i++){var p=picks[i];"
                    "var st=getComputedStyle(p);if(st.display==='none')continue;"
                    "var MV=p.querySelector('.datepicker-months');"
                    "if(!MV||MV.offsetWidth===0)continue;"
                    "var el=MV.querySelector('.%s');if(!el)return null;"
                    "var r=el.getBoundingClientRect();"
                    "return JSON.stringify({x:Math.round(r.x+r.width/2),"
                    "y:Math.round(r.y+r.height/2),"
                    "inV:r.top>=140&&r.bottom<=window.innerHeight-20});}"
                    "return null;})()" % nav)
                ra = json.loads(ya) if ya else None
                if not ra or not ra.get("inV"):
                    raise ExecutorError(
                        f"{what}: year '{nav}' arrow not visible")
                await self._click_xy(ra["x"], ra["y"], f"{what} year {nav}")
                await self._sleep(0.6, 1.0)

            # 4c. click the month cell (bottom of the picker — safe zone)
            mshort = next(k for k, v in self._MONTHS_SHORT.items() if v == m)
            mc = await self.js(
                "(function(){var picks=document.querySelectorAll("
                "'.datepicker');"
                "for(var i=0;i<picks.length;i++){var p=picks[i];"
                "var st=getComputedStyle(p);if(st.display==='none')continue;"
                "var MV=p.querySelector('.datepicker-months');"
                "if(!MV||MV.offsetWidth===0)continue;"
                "var cells=MV.querySelectorAll('span.month, td.month');"
                "for(var j=0;j<cells.length;j++){var c=cells[j];"
                "var t=(c.textContent||'').trim().slice(0,3).toLowerCase();"
                "if(t==='" + mshort + "'){var r=c.getBoundingClientRect();"
                "return JSON.stringify({x:Math.round(r.x+r.width/2),"
                "y:Math.round(r.y+r.height/2),"
                "inV:r.top>=140&&r.bottom<=window.innerHeight-20});}}"
                "return null;}"
                "return null;})()")
            cellm = json.loads(mc) if mc else None
            if not cellm or not cellm.get("inV"):
                raise ExecutorError(
                    f"{what}: month cell '{mshort}' not visible")
            await self._click_xy(cellm["x"], cellm["y"],
                                 f"{what} month {mshort}")
            await self._sleep(0.7, 1.2)
            info = await self.js(header_js)
            if self._parse_switch(info or "") != (y, m):
                raise ExecutorError(
                    f"{what}: month nav ended on '{info}' (want {y}-{m:02d})")
            self.log("datepicker", f"{what} reached {y}-{m:02d} via subview")

        # 5. click the day cell
        day_expr = (
            "(function(){var picks=document.querySelectorAll('.datepicker');"
            "for(var i=0;i<picks.length;i++){var p=picks[i];"
            "var st=getComputedStyle(p);if(st.display==='none')continue;"
            "var DAYS=p.querySelector('.datepicker-days');"
            "if(!DAYS||DAYS.offsetWidth===0)continue;"
            "var tds=DAYS.querySelectorAll('tbody td.day');"
            "for(var j=0;j<tds.length;j++){var td=tds[j];"
            "if(td.classList.contains('old')||td.classList.contains('new'))continue;"
            "if(td.textContent.trim()==='" + str(d) + "'){"
            "var r=td.getBoundingClientRect();"
            "return JSON.stringify({x:Math.round(r.x+r.width/2),"
            "y:Math.round(r.y+r.height/2),"
            "inV:r.top>=150&&r.bottom<=window.innerHeight-20});}}"
            "return null;}"
            "return null;})()")
        cellraw = await self.js(day_expr)
        cell = json.loads(cellraw) if cellraw else None
        if cell is None:
            raise ExecutorError(f"{what}: day {d} cell not found")
        if not cell.get("inV"):
            raise ExecutorError(f"{what}: day {d} cell clipped")
        await self._click_xy(cell["x"], cell["y"], f"{what} day {d} cell")
        await self._sleep(0.8, 1.5)

        back = await self.read_field(css) or ""
        if back != expected:
            raise ExecutorError(
                f"{what}: read-back '{back}' != expected '{expected}' (D12 stop)")
        self.log("set_date", f"{what} -> {expected} (month subview)")
'''

src = src[:start] + NEW + src[end:]
p.write_text(src, encoding="utf-8")
ast.parse(src)
print("_pick_date v4 installed (subview), syntax OK")
