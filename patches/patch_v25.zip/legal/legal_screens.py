"""
Legal screens: EULA acceptance at first launch,
"Terms of use" and "Credits" windows accessible from About.
"""
import tkinter as tk
from pathlib import Path

LEGAL_DIR = Path(__file__).parent
EULA_FILE    = LEGAL_DIR / "eula.txt"
CREDITS_FILE = LEGAL_DIR / "credits.txt"
PRIVACY_FILE = LEGAL_DIR / "privacy.txt"
TOS_FILE     = LEGAL_DIR / "terms_of_sale.txt"

try:
    from core.utils import tr_ as _tr
except Exception:
    def _tr(s): return s


def _load_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return f"⚠ Impossible de charger : {path.name}"


def show_eula(parent, *, mode: str = "view") -> bool:
    """Affiche l'EULA.

    mode = "view"   : simple lecture (bouton Fermer)
    mode = "accept": acceptance required (Accept / Refuse buttons).
                     Returns True if accepted, False otherwise.
    """
    BG, FG, ACCENT, GREEN, RED, MUTED = (
        "#1e1e2e", "#cdd6f4", "#89b4fa", "#a6e3a1", "#f38ba8", "#888888")
    SEL_BG, ENTRY_BG = "#45475a", "#313244"

    accepted = {"value": False}
    dlg = tk.Toplevel(parent) if parent else tk.Tk()
    dlg.title(_tr("Conditions d'utilisation") + " — OTA Guard")
    dlg.configure(bg=BG)
    dlg.geometry("720x600")
    try:
        if parent:
            dlg.transient(parent)
            dlg.grab_set()
    except Exception:
        pass

    # Centrer
    dlg.update_idletasks()
    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"720x600+{(sw-720)//2}+{(sh-600)//2}")

    pad = tk.Frame(dlg, bg=BG, padx=20, pady=16)
    pad.pack(fill="both", expand=True)

    tk.Label(pad, text="📜  " + _tr("Conditions d'utilisation"),
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")
             ).pack(anchor="w", pady=(0, 8))

    if mode == "accept":
        tk.Label(pad, text=_tr("Veuillez lire et accepter ces conditions pour utiliser OTA Guard."),
                 bg=BG, fg=MUTED, font=("Segoe UI", 9),
                 wraplength=680, justify="left").pack(anchor="w", pady=(0, 8))

    # Zone texte scrollable
    txt_frame = tk.Frame(pad, bg=BG)
    txt_frame.pack(fill="both", expand=True)
    vsb = tk.Scrollbar(txt_frame, orient="vertical")
    vsb.pack(side="right", fill="y")
    txt = tk.Text(txt_frame, bg=ENTRY_BG, fg=FG,
                  font=("Consolas", 9), wrap="word",
                  relief="flat", padx=12, pady=10,
                  yscrollcommand=vsb.set)
    txt.pack(side="left", fill="both", expand=True)
    vsb.configure(command=txt.yview)
    # EULA not translated: the French version is the legal reference.
    # A non-French-speaking client can request an official translation from support.
    txt.insert("1.0", _load_text(EULA_FILE))
    txt.configure(state="disabled")

    # Boutons selon le mode
    bbar = tk.Frame(pad, bg=BG)
    bbar.pack(fill="x", pady=(12, 0))

    if mode == "accept":
        def _accept():
            accepted["value"] = True
            dlg.destroy()
        def _refuse():
            accepted["value"] = False
            dlg.destroy()
        tk.Button(bbar, text="❌  " + _tr("Je refuse"),
                  command=_refuse,
                  bg=SEL_BG, fg=FG, font=("Segoe UI", 9),
                  relief="flat", padx=16, pady=8,
                  cursor="hand2").pack(side="left")
        tk.Button(bbar, text="✅  " + _tr("J'accepte"),
                  command=_accept,
                  bg=GREEN, fg=BG, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=20, pady=8,
                  cursor="hand2").pack(side="right")
    else:
        tk.Button(bbar, text=_tr("Fermer"), command=dlg.destroy,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=20, pady=6,
                  cursor="hand2").pack(side="right")

    dlg.bind("<Escape>", lambda e: dlg.destroy())

    # Bloquant si acceptation requise
    if mode == "accept":
        if not parent:
            dlg.mainloop()
        else:
            dlg.wait_window()
        return accepted["value"]
    return True


def show_privacy(parent):
    """Show the privacy policy (GDPR)."""
    BG, FG, ACCENT, MUTED = ("#1e1e2e", "#cdd6f4", "#89b4fa", "#888888")
    ENTRY_BG = "#313244"

    dlg = tk.Toplevel(parent)
    dlg.title(_tr("Privacy policy") + " — OTA Guard")
    dlg.configure(bg=BG)
    dlg.geometry("720x600")
    try:
        dlg.transient(parent)
        dlg.grab_set()
    except Exception:
        pass

    dlg.update_idletasks()
    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"720x600+{(sw-720)//2}+{(sh-600)//2}")

    pad = tk.Frame(dlg, bg=BG, padx=20, pady=16)
    pad.pack(fill="both", expand=True)

    tk.Label(pad, text="🔒  " + _tr("Privacy policy"),
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")
             ).pack(anchor="w", pady=(0, 12))

    txt_frame = tk.Frame(pad, bg=BG)
    txt_frame.pack(fill="both", expand=True)
    vsb = tk.Scrollbar(txt_frame, orient="vertical")
    vsb.pack(side="right", fill="y")
    txt = tk.Text(txt_frame, bg=ENTRY_BG, fg=FG,
                  font=("Consolas", 9), wrap="word",
                  relief="flat", padx=12, pady=10,
                  yscrollcommand=vsb.set)
    txt.pack(side="left", fill="both", expand=True)
    vsb.configure(command=txt.yview)
    # Body not translated: the English version is the GDPR legal reference.
    txt.insert("1.0", _load_text(PRIVACY_FILE))
    txt.configure(state="disabled")

    bbar = tk.Frame(pad, bg=BG)
    bbar.pack(fill="x", pady=(12, 0))
    tk.Button(bbar, text=_tr("Fermer"), command=dlg.destroy,
              bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
              relief="flat", padx=20, pady=6,
              cursor="hand2").pack(side="right")

    dlg.bind("<Escape>", lambda e: dlg.destroy())


def show_terms_of_sale(parent):
    """Show the Terms of Sale."""
    BG, FG, ACCENT, MUTED = ("#1e1e2e", "#cdd6f4", "#89b4fa", "#888888")
    ENTRY_BG = "#313244"

    dlg = tk.Toplevel(parent)
    dlg.title(_tr("Conditions de vente") + " — OTA Guard")
    dlg.configure(bg=BG)
    dlg.geometry("720x600")
    try:
        dlg.transient(parent)
        dlg.grab_set()
    except Exception:
        pass

    dlg.update_idletasks()
    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"720x600+{(sw-720)//2}+{(sh-600)//2}")

    pad = tk.Frame(dlg, bg=BG, padx=20, pady=16)
    pad.pack(fill="both", expand=True)

    tk.Label(pad, text="💼  " + _tr("Conditions de vente"),
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")
             ).pack(anchor="w", pady=(0, 12))

    txt_frame = tk.Frame(pad, bg=BG)
    txt_frame.pack(fill="both", expand=True)
    vsb = tk.Scrollbar(txt_frame, orient="vertical")
    vsb.pack(side="right", fill="y")
    txt = tk.Text(txt_frame, bg=ENTRY_BG, fg=FG,
                  font=("Consolas", 9), wrap="word",
                  relief="flat", padx=12, pady=10,
                  yscrollcommand=vsb.set)
    txt.pack(side="left", fill="both", expand=True)
    vsb.configure(command=txt.yview)
    # Body not translated: the English version is the legal reference.
    txt.insert("1.0", _load_text(TOS_FILE))
    txt.configure(state="disabled")

    bbar = tk.Frame(pad, bg=BG)
    bbar.pack(fill="x", pady=(12, 0))
    tk.Button(bbar, text=_tr("Fermer"), command=dlg.destroy,
              bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
              relief="flat", padx=20, pady=6,
              cursor="hand2").pack(side="right")

    dlg.bind("<Escape>", lambda e: dlg.destroy())


def show_credits(parent):
    """Show the list of open source libraries in use."""
    BG, FG, ACCENT, MUTED = ("#1e1e2e", "#cdd6f4", "#89b4fa", "#888888")
    SEL_BG, ENTRY_BG = "#45475a", "#313244"

    dlg = tk.Toplevel(parent)
    dlg.title(_tr("Credits") + " — OTA Guard")
    dlg.configure(bg=BG)
    dlg.geometry("620x520")
    try:
        dlg.transient(parent)
        dlg.grab_set()
    except Exception:
        pass

    dlg.update_idletasks()
    sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
    dlg.geometry(f"620x520+{(sw-620)//2}+{(sh-520)//2}")

    pad = tk.Frame(dlg, bg=BG, padx=20, pady=16)
    pad.pack(fill="both", expand=True)

    tk.Label(pad, text="🎁  " + _tr("Open source credits"),
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")
             ).pack(anchor="w", pady=(0, 12))

    txt_frame = tk.Frame(pad, bg=BG)
    txt_frame.pack(fill="both", expand=True)
    vsb = tk.Scrollbar(txt_frame, orient="vertical")
    vsb.pack(side="right", fill="y")
    txt = tk.Text(txt_frame, bg=ENTRY_BG, fg=FG,
                  font=("Consolas", 9), wrap="word",
                  relief="flat", padx=12, pady=10,
                  yscrollcommand=vsb.set)
    txt.pack(side="left", fill="both", expand=True)
    vsb.configure(command=txt.yview)
    # Credits not translated: license and project names are standard English.
    txt.insert("1.0", _load_text(CREDITS_FILE))
    txt.configure(state="disabled")

    bbar = tk.Frame(pad, bg=BG)
    bbar.pack(fill="x", pady=(12, 0))
    tk.Button(bbar, text=_tr("Fermer"), command=dlg.destroy,
              bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
              relief="flat", padx=20, pady=6,
              cursor="hand2").pack(side="right")

    dlg.bind("<Escape>", lambda e: dlg.destroy())


def ensure_eula_accepted(parent, config: dict, save_fn) -> bool:
    """Show the EULA if not accepted yet. Returns True when OK to continue.

    Call at first launch, before the trial starts.
    Stores into config['eula'] = {accepted: True, version: "1.0", date: "..."}..
    """
    eula_cfg = config.get("eula", {})
    EULA_VERSION = "1.0"
    if eula_cfg.get("accepted") and eula_cfg.get("version") == EULA_VERSION:
        return True

    accepted = show_eula(parent, mode="accept")
    if not accepted:
        return False

    from datetime import datetime
    config["eula"] = {
        "accepted": True,
        "version":  EULA_VERSION,
        "date":     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    try:
        save_fn(config)
    except Exception:
        pass
    return True
