"""
License verification engine — OTA Guard.

Features:
  • Automatic trial period (15 days, no key required)
  • Activation by Ed25519 signed key bound to the machine
  • Runtime verification (every 30 min)
  • Trial storage in encrypted file + Windows registry (backup)

Dependency: `cryptography` (Ed25519 asymmetric, D24 2026-07-08).

Architecture (D24):
  - The Ed25519 PRIVATE key (signing_private.pem) signs keys on the vendor side.
  - The Ed25519 PUBLIC key (signing_public.pem, embedded) verifies on the client side.
  - The old symmetric HMAC mechanism (_k.py XOR + master.key) was broken:
    its verifier secret == signer secret and it leaked client-side, which
    allowed forging valid keys. Ed25519 makes forging impossible without
    the private key, absent from the client build.
"""
import base64
import json
import logging
import os
import struct
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from licensing.hw_id import (get_hw_fingerprint, get_hw_fingerprints,
                             get_hw_id, get_hw_id_display)
from licensing.keys import _embedded_public_pem, verify_key

from core.paths import DATA_DIR
from core.utils import tr_
LICENSE_FILE = DATA_DIR / "license.dat"
TRIAL_FILE   = DATA_DIR / ".tdata"
LAST_ONLINE_FILE = DATA_DIR / ".lastonline"

TRIAL_DAYS       = 15
_EPOCH           = datetime(2025, 1, 1)
_RUNTIME_INTERVAL = 1800          # 30 min
_REG_PATH        = r"Software\OTGConfig"
_REG_KEY         = "ct"
# Registry backup of the ACTIVATED license key. license.dat lives inside the
# data folder: if that folder is renamed/reinstalled/lost (fresh-install bug
# seen 2026-08-17), the paid license vanished with it while the registry kept
# the trial date → licensed client stuck on the license screen. The registry
# copy survives folder loss and restores license.dat on next startup.
_REG_LIC_KEY     = "lk"

# ── Trial anti-reset + license revocation (D45) ──────────────────────────
# (this block carried "D25": a number already taken in docs/decisions.md by
#  the phantom pricing.py module — collision fixed on 2026-08-08.)
# License service, SEPARATE from the sale form script:
#   - trial_check : remembers/recovers the first date ever seen for this
#     machine (survives uninstall + registry deletion + reinstall).
#   - lic_status  : "revoked" if the vendor tool re-issued a key for another
#     machine of the same client (see OTAKeyGen.py, Reissue tab).
#
# ⚠ EMPTY URL = FEATURE DISABLED, and that is intentional.
# The code to deploy lives in « OTA GUARD\Code_LICENCES_A_COPIER_DANS_
# APPS_SCRIPT.txt » ; until it is published there is no URL to write here.
# A fake URL would be worse than nothing: every call would fail,
# and after _GRACE_DAYS the grace period below would declare
# the license of ALL paying clients "revoked". Empty, the software
# behaves exactly as before this feature was added: no network call,
# no blocking, simply no revocation.
#
# After deployment: paste the /exec URL here (it ends with « /exec »),
# and the same one in « licensing ota guard\keygen.py ».
LICENSE_API_URL = ""

# Number of days without a server response before considering a license
# revoked. Raised from 3 to 30 on 2026-08-08: at 3 days, a Google Apps
# Script outage over a long weekend, an exceeded quota or a failed
# deployment locked out ALL paying clients, with nothing they could do
# about it. 30 days leaves ample time to repair, and still blocks
# whoever cuts server access to escape revocation.
_GRACE_DAYS     = 30

# ── License types ────────────────────────────────────────────────────────
TYPE_TRIAL    = 0x01
TYPE_STANDARD = 0x02
TYPE_PREMIUM  = 0x03
_TYPE_NAMES   = {TYPE_TRIAL: "trial", TYPE_STANDARD: "standard", TYPE_PREMIUM: "premium"}

# ── Statuses ─────────────────────────────────────────────────────────────
TRIAL_ACTIVE     = "trial_active"
TRIAL_EXPIRED    = "trial_expired"
LICENSED         = "licensed"
LICENSE_EXPIRED  = "license_expired"
LICENSE_REVOKED  = "license_revoked"
INVALID          = "invalid"


# ═════════════════════════════════════════════════════════════════════════
# Embedded verification PUBLIC key (D24)
# ═════════════════════════════════════════════════════════════════════════
# This is a PUBLIC key: disclosing it is risk-free. That is the whole
# difference with the old symmetric HMAC: verifying an Ed25519 signature
# does not allow producing one.
_PUBLIC_PEM = _embedded_public_pem()


# ═════════════════════════════════════════════════════════════════════════
# Simple XOR to encrypt LOCAL files (hardware-bound)
# ═════════════════════════════════════════════════════════════════════════
# Note: this local encryption is mere obfuscation (it protects the
# license.dat / .tdata file against immediate reading on the machine).
# The real security is carried by the Ed25519 signature of the key itself:
# the key can only be produced by the vendor (private key), and it is
# bound to the hardware via the signed hw_hash field.

def _derive_local_key(salt: str = "OTG_local") -> bytes:
    import hashlib
    return hashlib.sha256(get_hw_fingerprint() + salt.encode()).digest()


def _derive_local_keys(salt: str = "OTG_local") -> list:
    """One decryption key per acceptable fingerprint (primary first).

    Essential: `license.dat` and `.tdata` are encrypted WITH the fingerprint.
    If it varies (disk order, WMI read failure), the file becomes unreadable
    before the `hw` field is even checked — the license used to be lost
    outright.
    """
    import hashlib
    return [hashlib.sha256(fp + salt.encode()).digest()
            for fp in get_hw_fingerprints()]


def _hw_ids12() -> set:
    """Acceptable values of the `hw` field stored in the local files."""
    return {fp.hex()[:12] for fp in get_hw_fingerprints()}


def _hw_hashes() -> set:
    """Acceptable values of the signed `hw_hash` field in the license key."""
    return {fp[:6] for fp in get_hw_fingerprints()}


def _xor(data: bytes, key: bytes) -> bytes:
    return bytes(d ^ key[i % len(key)] for i, d in enumerate(data))


# ═════════════════════════════════════════════════════════════════════════
# Windows registry — install-date backup
# ═════════════════════════════════════════════════════════════════════════

def _reg_write(value: str, name: str = _REG_KEY):
    try:
        import winreg
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, _REG_PATH)
        enc = base64.b64encode(value.encode()).decode()
        winreg.SetValueEx(k, name, 0, winreg.REG_SZ, enc)
        winreg.CloseKey(k)
    except Exception:
        pass


def _reg_read(name: str = _REG_KEY) -> str | None:
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH)
        val, _ = winreg.QueryValueEx(k, name)
        winreg.CloseKey(k)
        return base64.b64decode(val.encode()).decode()
    except Exception:
        return None


# ═════════════════════════════════════════════════════════════════════════
# Atomic write (.tmp file + os.replace) — avoids a truncated/corrupted
# trial/license file if the write is interrupted midway (crash, power cut,
# antivirus lock). Same principle as scraping/secrets.py::atomic_write_json,
# adapted to the XOR binary here.
# ═════════════════════════════════════════════════════════════════════════

def _atomic_write_bytes(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        raise


# ═════════════════════════════════════════════════════════════════════════
# Trial date storage
# ═════════════════════════════════════════════════════════════════════════

def _save_trial_date(iso_date: str):
    key = _derive_local_key("trial_store")
    payload = json.dumps({"d": iso_date, "h": get_hw_id()[:12]}).encode()
    _atomic_write_bytes(TRIAL_FILE, _xor(payload, key))
    _reg_write(iso_date)


def _load_trial_date() -> str | None:
    """Recovers the oldest installation date."""
    dates = []

    # Source 1: encrypted file — tried with each acceptable fingerprint
    if TRIAL_FILE.exists():
        try:
            blob = TRIAL_FILE.read_bytes()
            ids  = _hw_ids12()
            for key in _derive_local_keys("trial_store"):
                try:
                    obj = json.loads(_xor(blob, key).decode())
                except Exception:
                    continue
                if obj.get("h") in ids:
                    dates.append(obj["d"])
                    break
        except Exception:
            pass

    # Source 2: Windows registry
    reg_val = _reg_read()
    if reg_val:
        dates.append(reg_val)

    # Source 3: config.json creation date
    cfg_file = DATA_DIR / "config.json"
    if cfg_file.exists():
        try:
            ct = os.path.getctime(cfg_file)
            dates.append(datetime.fromtimestamp(ct).strftime("%Y-%m-%d"))
        except Exception:
            pass

    if not dates:
        return None

    # Returns the oldest date (anti-reset)
    dates.sort()
    return dates[0]


# ═════════════════════════════════════════════════════════════════════════
# Online verification (D45) — trial anti-reset + revocation
# ═════════════════════════════════════════════════════════════════════════
# Best-effort: any network error returns None, never an exception that
# would propagate and block check(). The server (Apps Script) is the source
# of truth that survives a local uninstall/reinstall.

def _service_licence_configure() -> bool:
    """Does the license service have an address? If not, it is not called.

    Single decision point for the three functions below: without this
    guard, an empty URL would still go into requests.get(), which
    would raise MissingSchema — caught, therefore invisible, but paid
    on every check, and above all counted as "server unreachable" by
    the grace period.
    """
    return LICENSE_API_URL.startswith("http")


def _online_trial_check(machine: str) -> str | None:
    """Asks the server for the first known trial date for this machine.

    Returns that date even if the 3 local sources were wiped
    (uninstall + registry deletion) — else None when unreachable,
    in which case the trial starts normally locally (no offline blocking
    on this precise point, only the usual counter applies).
    """
    if not _service_licence_configure():
        return None
    try:
        import requests
        r = requests.get(LICENSE_API_URL, params={"action": "trial_check", "machine": machine}, timeout=8)
        return r.json().get("first_seen") or None
    except Exception:
        return None


def _online_lic_status(machine: str) -> str | None:
    """License status on the server side: "active" / "revoked" / "unknown".

    None when the server is unreachable (handled by the grace period).
    """
    if not _service_licence_configure():
        return None
    try:
        import requests
        r = requests.get(LICENSE_API_URL, params={"action": "lic_status", "machine": machine}, timeout=8)
        statut = r.json().get("status")
    except Exception:
        return None
    # The health service answers {"status": "ok"} when it recognized no
    # action: that is a server that is alive, not a verdict on this machine.
    # Confusing it with a license status would make "ok" indistinguishable
    # from "active" — no consequence today, but wrong, and wrong forever
    # if an extra status is ever added.
    return statut if statut in ("active", "revoked", "unknown") else None


def _mark_online_ok():
    _atomic_write_bytes(LAST_ONLINE_FILE, datetime.now().strftime("%Y-%m-%d %H:%M").encode())


def _days_since_last_online() -> int:
    """Days elapsed since the last successful online verification.

    0 if not verified yet (no immediate blocking on the very first
    offline launch of a freshly activated license).
    """
    if not LAST_ONLINE_FILE.exists():
        _mark_online_ok()
        return 0
    try:
        last = datetime.strptime(LAST_ONLINE_FILE.read_bytes().decode(), "%Y-%m-%d %H:%M")
        return (datetime.now() - last).days
    except Exception:
        return 0


def _is_revoked(machine: str) -> bool:
    """True only if the server explicitly confirms the revocation.

    Status recomputed on every call (no persistent flag): as soon as the
    connection comes back and a check succeeds, the license becomes
    valid again automatically with no user action.

    Unconfigured service (empty LICENSE_API_URL) → NEVER revoked. The
    grace period must only apply to a service that exists and cannot
    be reached. Without this guard, enabling the feature would amount
    to blocking all paying clients three days later.
    """
    if not _service_licence_configure():
        return False
    status = _online_lic_status(machine)
    if status is not None:
        _mark_online_ok()
        return status == "revoked"
    return _days_since_last_online() > _GRACE_DAYS


# ═════════════════════════════════════════════════════════════════════════
# License key decoding / verification (format v2 — Ed25519)
# ═════════════════════════════════════════════════════════════════════════
#
# Binary format v2 (76 bytes):
#   [0]      Version   (0x02)
#   [1]      Type      (0x01=trial 0x02=standard 0x03=premium)
#   [2-3]    Days      (uint16 BE, 0x0000 = perpetual)
#   [4-5]    Created   (days since 2025-01-01, uint16 BE)
#   [6-11]   Machine   (first 6 bytes of the fingerprint)
#   [12-75]  Signature Ed25519(bytes[0:12]) — 64 bytes
#
# Displayed as Base32: OTAG-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX
#                      (16 groups of 5 = 80 Base32 chars for 76 bytes, padding excluded)
#
# The old format v1 (25 bytes, truncated HMAC-SHA256) is REFUSED: its
# symmetric secret having leaked, no v1 key can be considered safe anymore.

def _key_text_to_bytes(text: str) -> bytes | None:
    """Parse a text key → 76 bytes (format v2)."""
    cleaned = text.strip().upper().replace("OTAG-", "").replace("-", "").replace(" ", "")
    # Add Base32 padding
    pad = (8 - len(cleaned) % 8) % 8
    cleaned += "=" * pad
    try:
        raw = base64.b32decode(cleaned)
        # v2 = 76 bytes, v3 (D79) = 79 bytes (+ zone + max_rooms)
        return raw if len(raw) in (76, 79) else None
    except Exception:
        return None


def _bytes_to_key_text(raw: bytes) -> str:
    """76 bytes → formatted key OTAG-XXXXX-..."""
    b32 = base64.b32encode(raw).decode().rstrip("=")
    groups = [b32[i:i + 5] for i in range(0, len(b32), 5)]
    return "OTAG-" + "-".join(groups)


def _verify_key_bytes(raw: bytes, public_pem: bytes) -> dict | None:
    """Verifies the Ed25519 signature and returns the decoded data.

    Accepted formats (D79):
      v2 (76 bytes): version/type/days/created/hw — already issued
        licenses → WORLD zone + unlimited rooms (grandfathering,
        nothing breaks for current clients) ;
      v3 (79 bytes): + zone(1B: 0=WORLD, 1..6=A..F) + max_rooms
        (2B BE, 0=unlimited) — D79 pricing grid.

    Returns None on unknown size/version or invalid signature."""
    if len(raw) not in (76, 79):
        return None
    payload    = raw[:len(raw) - 64]
    signature  = raw[len(raw) - 64:]
    if payload[0] not in (0x02, 0x03):  # accepted versions
        return None
    if not verify_key(public_pem, payload, signature):
        return None
    lic_type  = raw[1]
    days      = struct.unpack(">H", raw[2:4])[0]
    created_d = struct.unpack(">H", raw[4:6])[0]
    hw_hash   = raw[6:12]
    created   = _EPOCH + timedelta(days=created_d)
    perpetual = (days == 0)
    expires   = None if perpetual else created + timedelta(days=days)
    zone, max_rooms = "WORLD", 0
    if len(raw) == 79:
        _ZONE_NAMES = {0: "WORLD", 1: "A", 2: "B", 3: "C", 4: "D",
                       5: "E", 6: "F"}
        zone      = _ZONE_NAMES.get(raw[12], "WORLD")
        max_rooms = struct.unpack(">H", raw[13:15])[0]
    return {
        "version":   payload[0],
        "type":      _TYPE_NAMES.get(lic_type, "unknown"),
        "type_code": lic_type,
        "days":      days,
        "perpetual": perpetual,
        "created":   created.strftime("%Y-%m-%d"),
        "expires":   expires.strftime("%Y-%m-%d") if expires else None,
        "hw_hash":   hw_hash,
        "zone":      zone,
        "max_rooms": max_rooms,
    }


# ═════════════════════════════════════════════════════════════════════════
# Activated license storage
# ═════════════════════════════════════════════════════════════════════════

def _save_license(key_text: str, info: dict):
    payload = json.dumps({
        "key":       key_text,
        "type":      info["type"],
        "created":   info["created"],
        "expires":   info["expires"],
        "perpetual": info["perpetual"],
        "activated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "hw":        get_hw_id()[:12],
        "zone":      info.get("zone", "WORLD"),          # D79
        "max_rooms": info.get("max_rooms", 0),           # 0 = unlimited
    }).encode()
    key = _derive_local_key("license_store")
    _atomic_write_bytes(LICENSE_FILE, _xor(payload, key))
    # Registry backup: survives data-folder loss (see _REG_LIC_KEY note).
    _reg_write(key_text, name=_REG_LIC_KEY)


def _restore_license_from_registry() -> dict | None:
    """Rebuild license.dat from its registry backup when the file is gone.

    The backed-up key goes through the exact same validation as a manual
    entry (Ed25519 signature + machine binding + expiration), so the backup
    grants no extra rights — it only re-creates what activation produced.
    Returns the restored license dict, or None if no valid backup exists.
    """
    key_text = _reg_read(_REG_LIC_KEY)
    if not key_text:
        return None
    raw = _key_text_to_bytes(key_text)
    if raw is None:
        return None
    info = _verify_key_bytes(raw, _PUBLIC_PEM)
    if info is None or info["hw_hash"] not in _hw_hashes():
        return None
    if not info["perpetual"]:
        try:
            if datetime.now() >= datetime.strptime(info["expires"], "%Y-%m-%d"):
                return None
        except Exception:
            return None
    _save_license(key_text, info)
    logging.info("[Licence] license.dat missing — license restored "
                 "from the registry backup.")
    try:
        blob = LICENSE_FILE.read_bytes()
    except Exception:
        return None
    for key in _derive_local_keys("license_store"):
        try:
            obj = json.loads(_xor(blob, key).decode())
        except Exception:
            continue
        if obj.get("hw") in _hw_ids12():
            return obj
    return None


def _load_license() -> dict | None:
    """Re-reads the installed license.

    Tries each acceptable fingerprint: a hardware reading variation
    (disk order, WMI failure) used to make the file unreadable and drop
    the application back to the trial period WITHOUT SAYING ANYTHING —
    then, once the trial ended, ask again for the already-entered key.

    If license.dat vanished with the data folder (fresh-install bug
    2026-08-17), tries restoring from the registry backup.
    """
    if not LICENSE_FILE.exists():
        return _restore_license_from_registry()
    try:
        blob = LICENSE_FILE.read_bytes()
    except Exception:
        return None
    ids = _hw_ids12()
    for rank, key in enumerate(_derive_local_keys("license_store")):
        try:
            obj = json.loads(_xor(blob, key).decode())
        except Exception:
            continue
        if obj.get("hw") in ids:
            if rank:
                logging.info("[Licence] Secondary hardware fingerprint #%d "
                             "used (unstable hardware reading).", rank)
            # Self-heal: machines activated BEFORE this registry backup
            # existed have no "lk" entry yet — write it now so every licensed
            # machine is covered without asking clients to re-enter keys.
            key_text = obj.get("key")
            if key_text and _reg_read(_REG_LIC_KEY) != key_text:
                _reg_write(key_text, name=_REG_LIC_KEY)
            return obj
    return None


# ═════════════════════════════════════════════════════════════════════════
# LicenseChecker — main class
# ═════════════════════════════════════════════════════════════════════════

class LicenseChecker:

    def __init__(self):
        self._status       = None
        self._info         = {}
        self._public_pem   = _PUBLIC_PEM
        self._runtime_ok   = True
        self._timer        = None
        self._checked_once = False

    # ── Main verification ────────────────────────────────────────────────

    def check(self) -> str:
        """Returns the current license status.

        Online revocation (D45) is only queried from the 2nd call
        onward — the very first check() happens at startup on the main
        thread (even before the window is shown): adding a blocking
        network call there would slow every launch whenever a licensed
        client has no internet. The background thread (30 min) takes
        over without blocking the UI.
        """
        check_online = self._checked_once
        self._checked_once = True

        # 1. Activated license?
        saved = _load_license()
        if saved and saved.get("key"):
            raw = _key_text_to_bytes(saved["key"])
            if raw:
                info = _verify_key_bytes(raw, self._public_pem)
                if info:
                    # Machine check — any acceptable fingerprint works
                    # (the disk order returned by Windows varies from
                    # boot to boot; comparing against the only primary
                    # fingerprint rejected the client's license).
                    if info["hw_hash"] in _hw_hashes():
                        # Expiration check
                        if info["perpetual"] or datetime.now() < datetime.strptime(info["expires"], "%Y-%m-%d"):
                            if check_online and _is_revoked(get_hw_id_display()):
                                self._status = LICENSE_REVOKED
                                self._info   = info
                                return LICENSE_REVOKED
                            self._status = LICENSED
                            self._info   = info
                            return LICENSED
                        else:
                            self._status = LICENSE_EXPIRED
                            self._info   = info
                            return LICENSE_EXPIRED

        # 2. Trial period
        install_date = _load_trial_date()
        if install_date is None:
            # First launch (or the 3 local sources wiped) — ask the server
            # whether it already knows this machine (anti-reset D45) before
            # starting a new trial.
            install_date = _online_trial_check(get_hw_id_display()) or datetime.now().strftime("%Y-%m-%d")
            _save_trial_date(install_date)

        try:
            inst = datetime.strptime(install_date, "%Y-%m-%d")
            days_used = (datetime.now() - inst).days
        except Exception:
            days_used = 999

        if days_used <= TRIAL_DAYS:
            self._status = TRIAL_ACTIVE
            self._info   = {"days_remaining": TRIAL_DAYS - days_used,
                            "days_used": days_used,
                            "install_date": install_date}
            return TRIAL_ACTIVE

        self._status = TRIAL_EXPIRED
        self._info   = {"days_used": days_used, "install_date": install_date}
        return TRIAL_EXPIRED

    # ── Activation ───────────────────────────────────────────────────────

    def activate(self, key_text: str) -> tuple[bool, str]:
        """Activates a key. Returns (success, message)."""
        raw = _key_text_to_bytes(key_text)
        if raw is None:
            return False, tr_("Invalid key format.")
        info = _verify_key_bytes(raw, self._public_pem)
        if info is None:
            return False, tr_("Invalid license key.")
        # Machine check — same tolerance as the startup check:
        # a key issued for this machine must remain activatable whatever
        # the disk enumeration order at entry time.
        if info["hw_hash"] not in _hw_hashes():
            return False, tr_("This key is linked to another computer.")
        # Expiration check
        if not info["perpetual"]:
            exp = datetime.strptime(info["expires"], "%Y-%m-%d")
            if datetime.now() >= exp:
                return False, tr_("This key expired on {date}.").format(date=info["expires"])
        # Save
        _save_license(key_text, info)
        self._status = LICENSED
        self._info   = info
        return True, tr_("License activated successfully.")

    # ── Accessors ────────────────────────────────────────────────────────

    @property
    def status(self) -> str:
        if self._status is None:
            self.check()
        return self._status

    @property
    def info(self) -> dict:
        return dict(self._info)

    def days_remaining(self) -> int:
        if self._status == TRIAL_ACTIVE:
            return self._info.get("days_remaining", 0)
        if self._status == LICENSED:
            if self._info.get("perpetual"):
                return 99999
            try:
                exp = datetime.strptime(self._info["expires"], "%Y-%m-%d")
                return max(0, (exp - datetime.now()).days)
            except Exception:
                return 0
        return 0

    def is_active(self) -> bool:
        return self.status in (TRIAL_ACTIVE, LICENSED)

    # ── Runtime re-verification (every 30 min) ──────────────────────────

    def start_runtime_checks(self, root_tk=None):
        """Starts the periodic silent re-verification."""
        self._root = root_tk

        def _loop():
            while True:
                time.sleep(_RUNTIME_INTERVAL)
                try:
                    st = self.check()
                    self._runtime_ok = st in (TRIAL_ACTIVE, LICENSED)
                except Exception:
                    self._runtime_ok = False

        t = threading.Thread(target=_loop, daemon=True)
        t.start()

    @property
    def runtime_ok(self) -> bool:
        return self._runtime_ok


# ═════════════════════════════════════════════════════════════════════════
# Singleton + quick check for checks scattered across the code
# ═════════════════════════════════════════════════════════════════════════

_instance: LicenseChecker | None = None


def get_checker() -> LicenseChecker:
    global _instance
    if _instance is None:
        _instance = LicenseChecker()
        _instance.check()
    return _instance


def _ck() -> bool:
    """Quick silent check — True if license/trial OK."""
    try:
        return get_checker().runtime_ok
    except Exception:
        # Fail-closed (explicit choice): any verification error
        # blocks rather than letting through — anti-piracy protection
        # takes priority over tolerance for technical failures.
        logging.exception("_ck(): license verification failed — access blocked for safety")
        return False


def _ck_or_degrade(result_if_blocked=None):
    """Returns result_if_blocked if the license is invalid, else None."""
    if not _ck():
        return result_if_blocked
    return None
