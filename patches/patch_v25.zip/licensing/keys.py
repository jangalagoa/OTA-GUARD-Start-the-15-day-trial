"""
Ed25519 cryptographic utilities for the OTA Guard license system.

Asymmetric architecture (D24, 2026-07-08):
  - The PRIVATE key (signing_private.pem) signs license keys on the vendor side.
    It must NEVER be distributed, committed nor embedded in the client build.
  - The PUBLIC key (signing_public.pem) verifies signatures on the client side.
    It alone is embedded in the shipped application.

Consequence: even if an attacker fully extracts the .exe (Nuitka bytecode,
constants), they only get the public key — forging a valid license key
without the private key (which stays with the vendor) is impossible.

Replaces the old symmetric HMAC mechanism (_k.py XOR + master.key) whose
verifier secret == signer secret, and therefore leaked client-side.

Dependency: `cryptography` (C extension, industry standard).
"""
import hashlib
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

# ── Embedded public key ──────────────────────────────────────────────────────
# Source of truth: the signing_public.pem file next to this module
# (present in dev). For the client build (Nuitka onefile), the same value is
# hard-coded below as a fallback — a build without a data file works too.
# It is a PUBLIC key: disclosing it is risk-free.
_EMBEDDED_PUBLIC_KEY_FALLBACK = b"""\
-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAk8FOZAsLimAwL/jaHrQe06w40KrHF/QoEJTCiUy9KbM=
-----END PUBLIC KEY-----
"""


def _embedded_public_pem() -> bytes:
    """Returns the embedded client-side verification public key as PEM.

    Reads the signing_public.pem file when it exists (dev / build with data),
    else uses the hard-coded constant (build without a data file).

    D24 guard: in the compiled build (Nuitka: sys.frozen OR the
    __compiled__ module present), if signing_private.pem is found next to
    this module, the build is corrupted (vendor file inside the client
    deliverable). An explicit RuntimeError is raised rather than starting
    silently with a compromised private key in the package. In dev
    (sources), the private file is legitimately present → no blocking.
    """
    here = Path(__file__).parent

    # ── Guard: private key forbidden on the client side (build only) ─────
    import sys as _sys
    _is_compiled = getattr(_sys, "frozen", False) or "__compiled__" in globals()
    private_file = here / "signing_private.pem"
    if _is_compiled and private_file.exists():
        raise RuntimeError(
            "SECURITY (D24): signing_private.pem found next to the client build "
            "— this file must NEVER be distributed. The build is corrupted; "
            "rebuild without the vendor keygen folder."
        )
    pem_file = here / "signing_public.pem"
    if pem_file.exists():
        try:
            data = pem_file.read_bytes()
            if b"BEGIN PUBLIC KEY" in data:
                return data
        except Exception:
            pass
    return _EMBEDDED_PUBLIC_KEY_FALLBACK


# ── Key generation / loading ────────────────────────────────────────────────

def generate_keypair() -> tuple[bytes, bytes]:
    """Generates an Ed25519 pair.

    Returns (private_pem_bytes, public_pem_bytes) in PEM format.
    Used only by `keygen.py --init` on the vendor side.
    """
    priv = Ed25519PrivateKey.generate()
    private_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def load_private_key(private_pem: bytes) -> Ed25519PrivateKey:
    """Loads an Ed25519 private key from its PEM."""
    key = serialization.load_pem_private_key(private_pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("The private key is not an Ed25519 key.")
    return key


def load_public_key(public_pem: bytes) -> Ed25519PublicKey:
    """Loads an Ed25519 public key from its PEM."""
    key = serialization.load_pem_public_key(public_pem)
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("The public key is not an Ed25519 key.")
    return key


# ── Signature / verification ────────────────────────────────────────────────

def sign_key(private_pem: bytes, payload: bytes) -> bytes:
    """Signs `payload` (bytes) with the private key. Returns the signature (64 bytes)."""
    return load_private_key(private_pem).sign(payload)


def verify_key(public_pem: bytes, payload: bytes, signature: bytes) -> bool:
    """Verifies the Ed25519 signature. Returns True if valid, False otherwise.

    No exception ever propagates: InvalidSignature is caught → False.
    (Avoids a parsing error being confused with a license failure in the
    calling code, which must stay simply fail-closed.)
    """
    try:
        load_public_key(public_pem).verify(signature, payload)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


# ── Public key fingerprint ──────────────────────────────────────────────────

def pubkey_fingerprint(public_pem: bytes) -> str:
    """Short fingerprint (8 hex) of the public key, for display/diagnosis.

    Lets the "About" screen identify which verification key is
    embedded — useful to confirm a build embeds the right key.
    """
    return hashlib.sha256(public_pem).hexdigest()[:8].upper()
