#!/usr/bin/env python3
"""
OTA Guard license key generator (Ed25519 asymmetric, D24).

⚠️  VENDOR TOOL — TO BE USED ONLY ON THE BUILD/SALES MACHINE.
    signing_private.pem must NEVER be committed nor distributed.

Usage (CLI):

  # 1. Initialization (once, when installing the license system)
  #    Generates the Ed25519 pair. The private key signs keys, the public key
  #    is embedded on the client side.
  python licensing/keygen.py --init

  # 2. Generate a client key (standard type, 365 days)
  python licensing/keygen.py --generate --machine OTG-XXXX-XXXX-XXXX --type standard --days 365

  # 3. Generate a perpetual key (premium)
  python licensing/keygen.py --generate --machine OTG-XXXX-XXXX-XXXX --type premium --perpetual

  # 4. Minimal GUI
  python licensing/keygen.py --gui

The machine ID (OTG-XXXX-XXXX-XXXX) is provided by the client (shown in
the license screen and in the app's "About").
"""
import argparse
import base64
import json
import struct
import sys
from datetime import datetime
from pathlib import Path

from licensing.keys import (
    generate_keypair,
    load_private_key,
    sign_key,
    pubkey_fingerprint,
)

HERE = Path(__file__).parent
PRIVATE_KEY_FILE = HERE / "signing_private.pem"
PUBLIC_KEY_FILE  = HERE / "signing_public.pem"
LEGACY_FILES     = [
    HERE / "master.key",
    HERE / "_k.py",
]
HISTORY_FILE     = HERE / "keygen_history.json"

_EPOCH = datetime(2025, 1, 1)

# License type → byte (must stay in sync with license_checker.py)
TYPE_MAP = {
    "trial":    0x01,
    "standard": 0x02,
    "premium":  0x03,
}

KEY_VERSION = 0x03  # v3 = v2 + zone + max_rooms (D79)  # Format v2 = Ed25519 (v1 = HMAC, refused)


# ═════════════════════════════════════════════════════════════════════════
# --init: key pair generation
# ═════════════════════════════════════════════════════════════════════════

def init_keys(force: bool = False) -> None:
    """Generates the Ed25519 pair and writes it to disk.

    - signing_private.pem  (keep secret, vendor side only)
    - signing_public.pem   (embed in the client build)

    Deletes the obsolete HMAC-mechanism artifacts (master.key, _k.py)
    if they exist, since they carry the old compromised secret.
    """
    if PRIVATE_KEY_FILE.exists() and not force:
        print(f"⚠  {PRIVATE_KEY_FILE.name} already exists.")
        print("   To regenerate it (and invalidate ALL keys already issued),")
        print("   use --init --force.")
        sys.exit(1)

    private_pem, public_pem = generate_keypair()
    PRIVATE_KEY_FILE.write_bytes(private_pem)
    PUBLIC_KEY_FILE.write_bytes(public_pem)
    # Restricted permissions on the private key (best-effort)
    try:
        import os as _os
        _os.chmod(PRIVATE_KEY_FILE, 0o600)
    except Exception:
        pass

    # Cleanup of obsolete HMAC artifacts
    for f in LEGACY_FILES:
        if f.exists():
            try:
                f.unlink()
                print(f"🧹 Deleted (obsolete): {f.name}")
            except Exception as e:
                print(f"⚠  Could not delete {f.name}: {e}")

    fp = pubkey_fingerprint(public_pem)
    print("=" * 60)
    print("✅ Ed25519 pair generated")
    print("=" * 60)
    print(f"  Private key (SECRET) : {PRIVATE_KEY_FILE}")
    print(f"  Public key           : {PUBLIC_KEY_FILE}")
    print(f"  Pub. fingerprint     : {fp}")
    print()
    print("  ⚠  signing_private.pem must NEVER be:")
    print("     - committed to Git")
    print("     - copied into dist/main.dist/")
    print("     - sent to a client")
    print()
    print("  The client build must embed ONLY signing_public.pem.")
    print("=" * 60)


# ═════════════════════════════════════════════════════════════════════════
# --generate: client key issuance
# ═════════════════════════════════════════════════════════════════════════

def _load_private_pem() -> bytes:
    if not PRIVATE_KEY_FILE.exists():
        print(f"❌ {PRIVATE_KEY_FILE.name} not found.")
        print("   Run first: python licensing/keygen.py --init")
        sys.exit(1)
    return PRIVATE_KEY_FILE.read_bytes()


def _machine_display_to_bytes(machine_id: str) -> bytes:
    """Converts the displayed machine ID (OTG-XXXX-XXXX-XXXX) into the 6 hw_hash bytes.

    The machine ID displayed client-side is the Base32 of the first 8 bytes of
    the hardware fingerprint (see hw_id.py::get_hw_id_display). Its first
    6 bytes are decoded, matching the signed hw_hash field in the key.
    """
    cleaned = machine_id.strip().upper().replace("OTG-", "").replace("-", "").replace(" ", "")
    pad = (8 - len(cleaned) % 8) % 8
    cleaned += "=" * pad
    try:
        raw = base64.b32decode(cleaned)
    except Exception:
        print(f"❌ Invalid machine ID: {machine_id!r}")
        print("   Expected format: OTAG-XXXX-XXXX-XXXX (provided by the client)")
        sys.exit(1)
    if len(raw) < 6:
        print(f"❌ Machine ID too short after decoding ({len(raw)} bytes).")
        sys.exit(1)
    return raw[:6]


def _bytes_to_key_text(raw: bytes) -> str:
    b32 = base64.b32encode(raw).decode().rstrip("=")
    groups = [b32[i:i + 5] for i in range(0, len(b32), 5)]
    return "OTAG-" + "-".join(groups)


def generate_key(machine_id: str, lic_type: str, days: int,
                 perpetual: bool = False, note: str = "",
                 zone: str = "WORLD", max_rooms: int = 0) -> str:
    """Generates an Ed25519-signed license key.

    Returns the key in text format OTAG-XXXXX-...
    """
    private_pem = _load_private_pem()
    load_private_key(private_pem)  # validates the PEM format (raises if corrupted)

    type_byte = TYPE_MAP.get(lic_type.lower(), 0x02)  # default standard
    days_val  = 0 if perpetual else int(days)
    if not perpetual and (days_val <= 0 or days_val > 65535):
        print(f"❌ Invalid --days: {days} (1-65535, or --perpetual)")
        sys.exit(1)

    created_d = (datetime.now() - _EPOCH).days
    if created_d < 0 or created_d > 65535:
        print(f"❌ Internal date out of range (created_d={created_d}).")
        sys.exit(1)

    hw_bytes  = _machine_display_to_bytes(machine_id)
    # Payload v3: version(1)+type(1)+days(2)+created(2)+hw(6)
    # + zone(1)+max_rooms(2) = 15 bytes (D79 — pricing grid)
    ZONE_CODES = {"WORLD": 0, "A": 1, "B": 2, "C": 3, "D": 4,
                  "E": 5, "F": 6}
    zone_byte = ZONE_CODES.get((zone or "WORLD").upper(), 0)
    rooms_val = max(0, int(max_rooms or 0))
    payload = (struct.pack(">BBHH", 0x03, type_byte, days_val, created_d)
               + hw_bytes + bytes([zone_byte])
               + struct.pack(">H", rooms_val))
    if len(payload) != 15:
        print(f"❌ Internal error: payload is {len(payload)} bytes (expected 15).")
        sys.exit(1)

    signature = sign_key(private_pem, payload)
    raw = payload + signature  # 15 + 64 = 79 bytes
    key_text = _bytes_to_key_text(raw)

    _save_history(key_text, lic_type, days_val, perpetual, machine_id, note)
    return key_text


def _save_history(key_text: str, lic_type: str, days: int, perpetual: bool,
                  machine_id: str, note: str) -> None:
    """Archives the issued key into keygen_history.json (vendor audit)."""
    try:
        history = []
        if HISTORY_FILE.exists():
            history = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if not isinstance(history, list):
                history = []
        history.append({
            "key":       key_text,
            "type":      lic_type,
            "days":      days,
            "perpetual": perpetual,
            "machine":   machine_id,
            "note":      note,
            "created":   datetime.now().strftime("%Y-%m-%d %H:%M"),
        })
        HISTORY_FILE.write_text(
            json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"⚠  Could not archive into the history: {e}")


# ═════════════════════════════════════════════════════════════════════════
# --gui: minimal graphical interface
# ═════════════════════════════════════════════════════════════════════════

def run_gui() -> None:
    import tkinter as tk
    from tkinter import ttk

    BG, FG = "#1e1e2e", "#cdd6f4"
    ENTRY_BG, SEL_BG = "#313244", "#45475a"
    ACCENT, GREEN = "#89b4fa", "#a6e3a1"

    root = tk.Tk()
    root.title("🔑 OTA Guard — KeyGen (vendor)")
    root.configure(bg=BG)
    root.geometry("620x420")
    root.resizable(False, False)

    pad = tk.Frame(root, bg=BG, padx=24, pady=16)
    pad.pack(fill="both", expand=True)

    tk.Label(pad, text="🔑 License key generator",
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")).pack(pady=(0, 10))

    # Embedded public key fingerprint (info)
    try:
        pub = PUBLIC_KEY_FILE.read_bytes()
        fp = pubkey_fingerprint(pub)
        tk.Label(pad, text=f"Embedded public key: {fp}",
                 bg=BG, fg="#888888", font=("Courier New", 9)).pack(anchor="w", pady=(0, 8))
    except Exception:
        pass

    def _field(label, default=""):
        tk.Label(pad, text=label, bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6, 2))
        e = tk.Entry(pad, bg=ENTRY_BG, fg=FG, insertbackground=FG,
                     relief="flat", highlightthickness=1,
                     highlightbackground=SEL_BG, highlightcolor=ACCENT,
                     font=("Courier New", 10))
        e.pack(fill="x", ipady=3)
        if default:
            e.insert(0, default)
        return e

    mid_e = _field("Client machine ID (OTG-XXXX-XXXX-XXXX):")

    # Type
    tk.Label(pad, text="License type:", bg=BG, fg=FG,
             font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6, 2))
    type_var = tk.StringVar(value="standard")
    type_row = tk.Frame(pad, bg=BG); type_row.pack(fill="x")
    for t, lbl in [("standard", "Standard"), ("premium", "Premium"), ("trial", "Trial")]:
        tk.Radiobutton(type_row, text=lbl, variable=type_var, value=t,
                       bg=BG, fg=FG, selectcolor=ENTRY_BG,
                       activebackground=BG, activeforeground=FG,
                       font=("Segoe UI", 9)).pack(side="left", padx=(0, 12))

    # Perpetual / days
    perp_var = tk.BooleanVar(value=False)
    def _toggle_perp():
        days_e.configure(state=tk.DISABLED if perp_var.get() else tk.NORMAL)
    tk.Checkbutton(pad, text="Perpetual (no expiration)",
                   variable=perp_var, command=_toggle_perp,
                   bg=BG, fg=FG, selectcolor=ENTRY_BG,
                   activebackground=BG, activeforeground=FG,
                   font=("Segoe UI", 9)).pack(anchor="w", pady=(6, 2))
    days_e = _field("Duration (days):", default="365")
    days_e.configure(state=tk.DISABLED)

    note_e = _field("Note (optional):")

    status_lbl = tk.Label(pad, text="", bg=BG, fg=ACCENT,
                          font=("Segoe UI", 9), wraplength=560, justify="left")
    status_lbl.pack(fill="x", pady=(8, 4))

    key_out_var = tk.StringVar()
    key_out = tk.Entry(pad, textvariable=key_out_var, bg=ENTRY_BG, fg=GREEN,
                       font=("Courier New", 10, "bold"), relief="flat",
                       state="readonly", readonlybackground=ENTRY_BG)
    key_out.pack(fill="x", ipady=3)

    def _gen():
        mid = mid_e.get().strip()
        if not mid:
            status_lbl.config(text="⚠ Enter the client machine ID.", fg="#fab387")
            return
        try:
            key = generate_key(
                machine_id=mid,
                lic_type=type_var.get(),
                days=int(days_e.get() or 365),
                perpetual=perp_var.get(),
                note=note_e.get().strip(),
            )
        except SystemExit:
            return
        except Exception as e:
            status_lbl.config(text=f"❌ Error: {e}", fg="#f38ba8")
            return
        key_out_var.set(key)
        status_lbl.config(text="✅ Key generated and archived.", fg=GREEN)

    def _copy():
        if not key_out_var.get():
            return
        root.clipboard_clear()
        root.clipboard_append(key_out_var.get())
        status_lbl.config(text="📋 Key copied to the clipboard.", fg=GREEN)

    btns = tk.Frame(pad, bg=BG); btns.pack(fill="x", pady=(10, 0))
    tk.Button(btns, text="🔑 Generate", command=_gen,
              bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
              relief="flat", padx=16, pady=6, cursor="hand2").pack(side="left")
    tk.Button(btns, text="📋 Copy", command=_copy,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 9),
              relief="flat", padx=14, pady=6, cursor="hand2").pack(side="left", padx=(8, 0))

    root.mainloop()


# ═════════════════════════════════════════════════════════════════════════
# CLI
# ═════════════════════════════════════════════════════════════════════════

def main():
    p = argparse.ArgumentParser(
        description="OTA Guard license key generator (Ed25519).")
    p.add_argument("--init", action="store_true",
                   help="Generates the Ed25519 pair (once).")
    p.add_argument("--force", action="store_true",
                   help="With --init: regenerates (invalidates all issued keys).")
    p.add_argument("--generate", action="store_true",
                   help="Generates a client key.")
    p.add_argument("--machine", metavar="ID",
                   help="Client machine ID (OTG-XXXX-XXXX-XXXX).")
    p.add_argument("--type", choices=list(TYPE_MAP.keys()), default="standard",
                   help="License type (default: standard).")
    p.add_argument("--days", type=int, default=365,
                   help="Duration in days (default: 365). Ignored if --perpetual.")
    p.add_argument("--perpetual", action="store_true",
                   help="Perpetual license (no expiration).")
    p.add_argument("--note", default="",
                   help="Internal note archived in the history.")
    p.add_argument("--gui", action="store_true",
                   help="Launches the graphical interface.")
    args = p.parse_args()

    if args.gui:
        run_gui()
        return

    if args.init:
        init_keys(force=args.force)
        return

    if args.generate:
        if not args.machine:
            p.error("--machine is required with --generate")
        key = generate_key(
            machine_id=args.machine,
            lic_type=args.type,
            days=args.days,
            perpetual=args.perpetual,
            note=args.note,
        )
        print()
        print("✅ License key generated:")
        print()
        print("  " + key)
        print()
        print(f"  Type: {args.type} | "
              f"{'Perpetual' if args.perpetual else str(args.days) + ' days'}")
        return

    p.print_help()


if __name__ == "__main__":
    main()
