"""
Hardware fingerprint — unique identifier of the machine.
Used to bind a license to a single PC.

Robustness (2026-07-25) — fix for "license lost on its own"
──────────────────────────────────────────────────────────────────
The fingerprint was recomputed on every call from 3 WMI reads, and the
slightest variation in a single one of those reads changed the hash ENTIRELY,
thus silently invalidating the already-installed license (back to the free
trial without any message; at the end of the trial, the key was asked again).
Two real causes, both observed:

  • `wmic diskdrive get SerialNumber` returns ONE LINE PER DISK and only
    the first one was kept. Windows does not guarantee the enumeration
    order from one boot to the next: on a 2-disk machine, the fingerprint
    therefore changed at every restart.
  • A failed read (timeout, wmic absent on 24H2, busy machine at launch)
    returned "" and the part was SILENTLY ignored by the join's `if p` —
    which also changes the hash.

Three protections, cumulative:

  1. In-process memoization: a single WMI read per launch instead of one
     per call (`check()` triggered 6). Faster, and the hit window of a
     timeout is reduced accordingly.
  2. Local cache of already-read values (`.hwparts`): a failed read
     reuses the last known value — but ONLY if the successful reads
     agree with the cache (otherwise it is another machine and the cache
     is ignored then replaced).
  3. List of CANDIDATES (`get_hw_fingerprints`): all plausible fingerprints
     for this machine (each disk, unreadable disk, one part missing). A
     license is accepted if it matches any of them.

The "primary" fingerprint (`get_hw_fingerprint`, first of the list) is
still computed exactly as before — same part order, same separator:
already-issued keys remain valid and the displayed machine ID does not change.
"""
import base64
import hashlib
import json
import os
import platform
import subprocess
import threading

# Cache file of the already-read identifiers (simple obfuscation: it
# contains no secret, only serial numbers already readable by
# any system tool on this machine).
_PARTS_NAME = ".hwparts"
_OBFUS     = b"OTG_hwparts_v1"

_lock = threading.Lock()
_memo = None          # (parts: dict, fingerprints: list[bytes])


def _wmic_vals(cls, prop) -> list[str]:
    """Reads a WMI property → ALL values (one per line).

    Returns [] when the read fails — the caller must distinguish this case
    from a genuinely empty value, or the fingerprint would change.
    Tries wmic first, then PowerShell Get-CimInstance (fallback on Windows 11
    24H2+ where wmic was removed).
    """
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0

    # Attempt 1: wmic (Windows 10 / Windows 11 before 24H2)
    try:
        r = subprocess.run(
            ["wmic", cls, "get", prop],
            capture_output=True, text=True, timeout=8,
            startupinfo=si,
        )
        lines = [
            l.strip()
            for l in r.stdout.strip().splitlines()
            if l.strip() and l.strip().lower() != prop.lower()
        ]
        if lines:
            return lines
    except Exception:
        pass

    # Attempt 2: PowerShell Get-CimInstance (Windows 11 24H2+ without wmic)
    _CIM_MAP = {
        "cpu":       "Win32_Processor",
        "baseboard": "Win32_BaseBoard",
        "diskdrive": "Win32_DiskDrive",
    }
    cim_cls = _CIM_MAP.get(cls.lower(), cls)
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             f"(Get-CimInstance {cim_cls}).{prop}"],
            capture_output=True, text=True, timeout=10,
            startupinfo=si,
        )
        return [l.strip() for l in r.stdout.strip().splitlines() if l.strip()]
    except Exception:
        return []


def _wmic_val(cls, prop) -> str:
    """Compat: first value only ("" when the read fails)."""
    vals = _wmic_vals(cls, prop)
    return vals[0] if vals else ""


# ═════════════════════════════════════════════════════════════════════════
# Local cache of the read identifiers
# ═════════════════════════════════════════════════════════════════════════

def _parts_path():
    try:
        from core.paths import DATA_DIR
        return DATA_DIR / _PARTS_NAME
    except Exception:
        return None


def _obf(data: bytes) -> bytes:
    return bytes(b ^ _OBFUSC[i % len(_OBFUSC)] for i, b in enumerate(data))


def _load_parts_cache() -> dict:
    p = _parts_path()
    try:
        if p and p.exists():
            obj = json.loads(_obf(p.read_bytes()).decode())
            if isinstance(obj, dict):
                return {
                    "cpu":   str(obj.get("cpu", "") or ""),
                    "mb":    str(obj.get("mb", "") or ""),
                    "pc":    str(obj.get("pc", "") or ""),
                    "disks": [str(d) for d in (obj.get("disks") or []) if d],
                }
    except Exception:
        pass
    return {}


def _save_parts_cache(parts: dict):
    p = _parts_path()
    if not p:
        return
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        with open(tmp, "wb") as f:
            f.write(_obf(json.dumps(parts).encode()))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)
    except Exception:
        pass


def _same_machine(live: dict, cached: dict) -> bool:
    """Does the cache really describe THIS machine?

    Two conditions: no contradiction on what could be read, and at
    least one positive match. The match must be about hardware
    (processor, motherboard, disk) and not the PC name alone,
    which renames in two clicks.

    Accepted exception: when NO hardware read succeeds (broken WMI,
    wmic removed and PowerShell blocked), the cache is accepted on the
    sole PC-name match. That is a deliberate trade-off — exploiting it
    would require copying `.hwparts` AND `license.dat`, renaming the PC
    identically AND neutralizing WMI, whereas without this tolerance a
    legitimate client whose WMI breaks finds themselves locked out.
    """
    if not cached:
        return False
    for k in ("cpu", "mb", "pc"):
        if live.get(k) and cached.get(k) and live[k] != cached[k]:
            return False
    live_d, cach_d = live.get("disks") or [], cached.get("disks") or []
    if live_d and cach_d and not (set(live_d) & set(cach_d)):
        return False

    hw_match = any(live.get(k) and cached.get(k) and live[k] == cached[k]
                   for k in ("cpu", "mb")) or bool(set(live_d) & set(cach_d))
    if hw_match:
        return True
    no_hw_read = not (live.get("cpu") or live.get("mb") or live_d)
    return no_hw_read and bool(live.get("pc")) and live["pc"] == cached.get("pc")


# ═════════════════════════════════════════════════════════════════════════
# Fingerprints
# ═════════════════════════════════════════════════════════════════════════

def _fp(cpu: str, mb: str, disk: str, pc: str) -> tuple:
    """(source text, fingerprint) — original order and separator, NOT to be
    modified: any change would invalidate already-issued keys."""
    raw = "|".join(p for p in (cpu, mb, disk, pc) if p)
    return raw, hashlib.sha256(raw.encode()).digest()


def _candidates(parts: dict) -> list:
    """All plausible fingerprints, primary one first.

    • one candidate per disk (the WMI enumeration order is not guaranteed) ;
    • one "unreadable disk" candidate ;
    • the degraded variants without processor / without motherboard, for
      licenses activated while a read was failing.
    """
    cpu = parts.get("cpu", "")
    mb  = parts.get("mb", "")
    pc  = parts.get("pc", "")
    disks = list(parts.get("disks") or [])

    disk_variants = disks + [""]
    combos = [(cpu, mb, d, pc) for d in disk_variants]
    for d in disk_variants:
        combos.append(("", mb, d, pc))
        combos.append((cpu, "", d, pc))

    out, seen = [], set()
    for c in combos:
        raw, digest = _fp(*c)
        if not raw or raw in seen:
            continue
        seen.add(raw)
        out.append(digest)
    if not out:                       # no data at all (non-Windows): original behavior
        out.append(hashlib.sha256(b"").digest())
    return out


def _read_live() -> dict:
    out = {"cpu": "", "mb": "", "disks": [], "pc": ""}
    if platform.system() == "Windows":
        out["cpu"]   = _wmic_val("cpu", "ProcessorId")
        out["mb"]    = _wmic_val("baseboard", "SerialNumber")
        out["disks"] = _wmic_vals("diskdrive", "SerialNumber")
        out["pc"]    = os.environ.get("COMPUTERNAME", "")
    return out


def _resolve():
    """Single hardware read per process → (parts, candidates)."""
    global _memo
    with _lock:
        if _memo is not None:
            return _memo

        live   = _read_live()
        cached = _load_parts_cache()
        parts  = dict(live)

        if _same_machine(live, cached):
            for k in ("cpu", "mb", "pc"):
                if not parts.get(k) and cached.get(k):
                    parts[k] = cached[k]
            # Already-known disks come first: the primary fingerprint
            # (hence the displayed machine ID) stops depending on the
            # Windows enumeration order.
            known = [d for d in cached.get("disks", []) if d]
            parts["disks"] = known + [d for d in (live.get("disks") or [])
                                      if d not in known]

        if (parts.get("cpu") or parts.get("mb") or parts.get("disks")) \
                and parts != cached:
            _save_parts_cache(parts)

        _memo = (parts, _candidates(parts))
        return _memo


def get_hw_fingerprints() -> list:
    """All acceptable fingerprints for this machine (32 bytes each).

    To be used to VERIFY a license. The first one is the primary
    fingerprint, the one used to create a new key.
    """
    return list(_resolve()[1])


def get_hw_fingerprint() -> bytes:
    """SHA-256 of the hardware identifiers → 32 bytes (primary fingerprint)."""
    return _resolve()[1][0]


def get_hw_ids() -> list:
    """Acceptable 24-char hex machine IDs (primary first)."""
    return [fp.hex()[:24] for fp in get_hw_fingerprints()]


def get_hw_id() -> str:
    """24-char hex machine ID."""
    return get_hw_fingerprint().hex()[:24]


def get_hw_id_display() -> str:
    """Readable machine ID: OTG-XXXX-XXXX-XXXX (for client display)."""
    b32 = base64.b32encode(get_hw_fingerprint()[:8]).decode().rstrip("=")
    return f"OTG-{b32[:4]}-{b32[4:8]}-{b32[8:12]}"
