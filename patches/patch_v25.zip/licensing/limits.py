"""licensing/limits.py — enforcement of the pricing grid (D79).

The signed license now carries zone (A..F / WORLD) and max_rooms
(small=19, medium=50, 0=unlimited for large on quotation). This module:

  1. ZONE — verifies that a workstation is inside its license zone, WITHOUT
     any server (D45): Windows time zone (mandatory) + Windows country
     (registry Geo, precise country by country) + hotel currency
     (warning only).
  2. ROOMS — counts rooms: the Channel Manager grid as soon as a read
     exists (the list of rooms actually distributed — impossible to lie
     to one's own OTAs), otherwise the hotel sheet declaration
     (room_inventory, D64) as a fallback.
     Above the signed limit → scans and shipments refused.

Grandfathering: v2 licenses without zone/limit → WORLD + unlimited ;
trial period → no limit. Honesty: the offline check stops license
sharing across zones and the hotelier inflating their declaration;
the determined cracker belongs to online licensing (ruled out D45 —
the signed zone is ready if that changes).
"""
from datetime import datetime

# Countries per zone (2-letter ISO codes — pricing grid D79)
ZONE_COUNTRIES = {
    "A": {"IN", "BD", "LK", "NP", "PK"},                    # South Asia
    "B": {"TH", "VN", "ID", "PH", "MY"},                    # South-East Asia
    "C": {"AE", "QA", "SA", "BH", "KW"},                    # Middle East
    "D": {"KE", "NG", "ZA", "MA", "EG", "TZ"},              # Africa
    "E": {"PL", "RO", "HR", "BR", "MX", "AR"},              # Eastern Europe / Lat Am
    "F": {"FR", "DE", "ES", "IT", "GB", "PT", "NL"},        # Western Europe
}

# Allowed time zones per zone, in HOURS (UTC) — winter/summer covered by
# the range. Zones A/B well separated from the rest; E/F share +1/+2
# → tie-broken by the Windows country (Geo), present on every Windows 10.
ZONE_OFFSETS = {
    "A": {5.0, 5.5, 5.75, 6.0},        # PK, IN/LK, NP, BD
    "B": {7.0, 8.0},                   # TH/VN/ID, MY/PH
    "C": {3.0, 4.0},                   # SA/KW/BH/QA, AE
    "D": {1.0, 2.0, 3.0},              # MA/NG, ZA, KE/EG/TZ
    "E": {-6.0, -3.0, 1.0, 2.0},       # MX, BR/AR, PL/RO/HR + DST
    "F": {0.0, 1.0, 2.0},              # GB, FR/DE/ES/IT/PT/NL + DST
}

ZONE_NAMES_FR = {
    "A": "South Asia", "B": "South-East Asia", "C": "Middle East",
    "D": "Africa", "E": "Eastern Europe / Latin America",
    "F": "Western Europe", "WORLD": "all zones",
}

# Typical currencies per zone (warning ONLY — never blocking)
ZONE_CURRENCIES = {
    "A": {"INR"}, "B": {"THB", "VND", "IDR", "PHP", "MYR"},
    "C": {"AED", "QAR", "SAR", "BHD", "KWD"},
    "D": {"KES", "NGN", "ZAR", "MAD", "EGP", "TZS"},
    "E": {"PLN", "RON", "HRK", "BRL", "MXN", "ARS"},
    "F": {"EUR", "GBP"},
}


# ── current license (verified by the checker) ──────────────────────────────

def license_limits() -> tuple[int, str]:
    """(max_rooms, zone) of the ACTIVATED license. Trial / unverified →
    (0, "WORLD") = no limit: the zone is checked at startup."""
    try:
        from licensing.license_checker import get_checker, LICENSED
        ck = get_checker()
        if ck and getattr(ck, "status", None) == LICENSED and ck.info:
            return (int(ck.info.get("max_rooms") or 0),
                    str(ck.info.get("zone") or "WORLD").upper())
    except Exception:
        pass
    return 0, "WORLD"


# ── local workstation signals (injectable for tests) ───────────────────────

def _windows_country_code() -> str:
    """Windows country (2-letter ISO) via registry Geo — local, no
    network. '' when absent (Geo zone then ignored)."""
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Control Panel\International\Geo") as k:
            val, _ = winreg.QueryValueEx(k, "Name")
            return str(val or "").strip().upper()
    except Exception:
        return ""


def _utc_offset_hours() -> float:
    """Current time offset of the workstation, in hours (5.5 = UTC+5:30)."""
    off = datetime.now().astimezone().utcoffset()
    if off is None:
        return 99.0
    return off.total_seconds() / 3600.0


def zone_of_country(code: str) -> str:
    c = (code or "").strip().upper()
    for zone, countries in ZONE_COUNTRIES.items():
        if c in countries:
            return zone
    return ""


# ── zone check (startup) ───────────────────────────────────────────────────

def check_zone(license_zone: str, country=None, offset_hours=None) \
        -> tuple[bool, str]:
    """(ok, message). WORLD → always ok. Otherwise:
    - workstation time zone outside the zone → REFUSAL (reliable, hard
      to keep fake for long: Windows re-synchronizes the clock) ;
    - Windows country known AND in ANOTHER zone → REFUSAL (distinguishes
      E/F and C/D which the time zone alone cannot separate) ;
    - unknown country + good time zone → ok (Geo absent) ;
    - inconsistent hotel currency → handled separately (warning)."""
    lz = (license_zone or "WORLD").upper()
    if lz == "WORLD" or lz not in ZONE_OFFSETS:
        return True, ""
    if country is None:
        country = _windows_country_code()
    if offset_hours is None:
        offset_hours = _utc_offset_hours()
    off = round(float(offset_hours), 3)
    if off not in ZONE_OFFSETS[lz]:
        found = zone_of_country("")  # noqa: F841 — readability
        return False, (
            f"License valid for zone {lz} "
            f"({ZONE_NAMES_FR.get(lz, lz)}). This workstation is set to a "
            f"time zone outside that zone (UTC{'+' if off >= 0 else ''}"
            f"{off:g}). Contact your reseller for a license of the "
            f"correct zone.")
    geo_zone = zone_of_country(country)
    if geo_zone and geo_zone != lz:
        return False, (
            f"License valid for zone {lz} "
            f"({ZONE_NAMES_FR.get(lz, lz)}). This workstation is configured "
            f"for a country of zone {geo_zone} "
            f"({ZONE_NAMES_FR.get(geo_zone, geo_zone)}). Contact your "
            f"reseller for a license of the correct zone.")
    return True, ""


def currency_warning(license_zone: str, hotel_currency: str) -> str:
    """Warning (never blocking) if the hotel currency is not typical of
    the license zone."""
    lz = (license_zone or "WORLD").upper()
    cur = (hotel_currency or "").strip().upper()
    if lz == "WORLD" or not cur:
        return ""
    typical = ZONE_CURRENCIES.get(lz)
    if typical and cur not in typical:
        return (f"Configured currency ({cur}) atypical for the license "
                f"zone ({lz}) — check the configuration.")
    return ""


# ── room counting (scan + push) ────────────────────────────────────────────

def cm_room_count() -> int:
    """Rooms listed on the CM grid, WITHOUT triggering a scan:
    counted only when a read already exists in this session."""
    try:
        import extranet_bridge as _eb
        last = getattr(_eb, "_last_scan", None)
        if not last:
            return 0
        return len([r for r in (last.get("rooms") or [])
                    if r.get("room_id") is not None])
    except Exception:
        return 0


def declared_room_count(app_config: dict) -> int:
    """Sum of the declared "room counts" (hotel sheet, D64)."""
    inv = (app_config or {}).get("room_inventory") or {}
    total = 0
    for room, data in inv.items():
        if isinstance(data, dict):
            try:
                total += max(0, int(data.get("count") or 0))
            except (TypeError, ValueError):
                total += 1
        else:
            total += 1
    return total


def counted_rooms(app_config: dict) -> tuple[int, str]:
    """(count, source) — the CM grid wins as soon as it exists (the
    distribution truth), otherwise the declaration as a fallback."""
    cm = cm_room_count()
    if cm > 0:
        return cm, "Channel Manager grid"
    return declared_room_count(app_config), "hotel sheet declaration"


def operation_allowed(app_config: dict) -> tuple[bool, str]:
    """(ok, reason) — called before price scans and CM shipments.
    Unlimited license or trial → always ok."""
    max_rooms, _zone = license_limits()
    if max_rooms <= 0:
        return True, ""
    n, source = counted_rooms(app_config)
    if n <= max_rooms:
        return True, ""
    return False, (
        f"License limited to {max_rooms} rooms — this hotel declares "
        f"{n} ({source}). Upgrade to the higher license to continue "
        f"(scans and shipments blocked).")
