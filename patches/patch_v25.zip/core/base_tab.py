"""
Base class for all tabs.
Automatically redirects calls to unknown methods to self.app
(compatibility with the original code that calls self.method_of_another_tab).
"""


class BaseTab:
    """
    All tabs inherit from this class.
    If a method is not defined in the tab, it is looked up on self.app.
    This allows porting the original code without modifying cross-calls.
    """

    def __getattr__(self, name):
        # Avoid infinite recursion on 'app'
        if name == "app":
            raise AttributeError(name)
        app = object.__getattribute__(self, "__dict__").get("app")
        if app is not None and hasattr(app, name):
            return getattr(app, name)
        raise AttributeError(
            f"'{type(self).__name__}' has no attribute '{name}' "
            f"(neither in the tab nor in app)"
        )
