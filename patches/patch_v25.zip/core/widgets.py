"""
Reusable UI widgets.
All tabs import these helpers to keep a consistent style.

Automatic translation: every text going through lbl/btn/section is
automatically translated via tr_() when the active language is not 'fr'.
"""
import tkinter as tk
from tkinter import ttk
from core.theme import T


def _xlate(text):
    """Translate text via tr_() if possible, fallback = original text."""
    if not text or not isinstance(text, str):
        return text
    try:
        from core.utils import tr_
        return tr_(text)
    except Exception:
        return text


def _lum(hex_color: str) -> float:
    """Perceived luminance (0–1) of a hex color."""
    try:
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255
    except Exception:
        return 0.0


def _cr(l1: float, l2: float) -> float:
    """WCAG contrast ratio between two luminances."""
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def _btn_fg(bg: str) -> str:
    """Returns T.FG or T.BG: whichever gives the best contrast on bg.
    Works for all themes, including Light Pro."""
    bg_l  = _lum(bg)
    cr_fg  = _cr(bg_l, _lum(T.FG))
    cr_tbg = _cr(bg_l, _lum(T.BG))
    return T.FG if cr_fg >= cr_tbg else T.BG


def _parent_bg(parent) -> str:
    """Gets the background color of the parent widget (fallback T.BG)."""
    try:
        return parent.cget("bg")
    except Exception:
        return T.BG


def lbl(parent, text, bold=False, color=None, size=10, **kwargs):
    """Simple label — text automatically translated according to the language.
    bg automatically inherits from the parent when not specified."""
    fg = color or T.FG
    font = ("Segoe UI", size, "bold") if bold else ("Segoe UI", size)
    bg = kwargs.pop("bg", _parent_bg(parent))
    return tk.Label(parent, text=_xlate(text), bg=bg, fg=fg, font=font, **kwargs)


class _SelectableLabel(tk.Entry):
    """One-line label whose text stays selectable/copyable (unlike
    tk.Label). Based on tk.Entry in state="readonly" — click-drag selection
    and copy (Ctrl+C) work natively in this state, without allowing
    editing. Exposes a compatible API (text=, .configure(text=...), .cget("text"))
    to remain a transparent replacement for tk.Label."""

    def __init__(self, parent, text="", anchor=None, justify=None, **kwargs):
        self._var = tk.StringVar(value=text)
        just = {"w": "left", "center": "center", "e": "right"}.get(anchor or justify, "left")
        bg = kwargs.pop("bg", None)
        fg = kwargs.pop("fg", None)
        kwargs.pop("relief", None)
        super().__init__(
            parent, textvariable=self._var, state="readonly",
            readonlybackground=bg, bg=bg, fg=fg, justify=just,
            relief="flat", bd=0, highlightthickness=0, **kwargs,
        )

    def configure(self, cnf=None, **kwargs):
        if cnf:
            kwargs.update(cnf)
        if "text" in kwargs:
            self._var.set(kwargs.pop("text"))
        if "bg" in kwargs:
            kwargs["readonlybackground"] = kwargs["bg"]
        if kwargs:
            super().configure(**kwargs)

    config = configure

    def cget(self, key):
        if key == "text":
            return self._var.get()
        return super().cget(key)


class _SelectableTextLabel(tk.Text):
    """Multi-line label (wraplength) selectable/copyable — replaces tk.Label
    when automatic line wrapping is needed. Based on tk.Text in
    state="disabled": selection/copy remain possible in this state (only
    editing is blocked), and the height is recomputed automatically after
    display to fit the number of lines actually shown."""

    def __init__(self, parent, text="", wraplength=300, font=None,
                 bg=None, fg=None, anchor=None, justify=None, **kwargs):
        import tkinter.font as tkfont
        try:
            f = tkfont.Font(font=font) if font else tkfont.nametofont("TkDefaultFont")
            avg_w = max(f.measure("n"), 1)
        except Exception:
            avg_w = 7
        chars = max(10, int(wraplength / avg_w))
        kwargs.pop("relief", None)
        super().__init__(
            parent, wrap="word", width=chars, height=1, font=font,
            bg=bg, fg=fg, relief="flat", bd=0, highlightthickness=0,
            padx=0, pady=0, cursor="xterm", takefocus=0, **kwargs,
        )
        just = {"w": "left", "center": "center", "e": "right"}.get(anchor or justify, "left")
        self.tag_configure("_body", justify=just)
        self._set_text(text)

    def _set_text(self, text):
        self.configure_raw(state="normal")
        self.delete("1.0", "end")
        self.insert("1.0", text, "_body")
        self.configure_raw(state="disabled")
        self.after_idle(self._autosize)

    def configure_raw(self, **kwargs):
        tk.Text.configure(self, **kwargs)

    def _autosize(self):
        try:
            self.configure_raw(state="normal")
            counted = self.count("1.0", "end-1c", "displaylines")
            n = counted[0] if counted else 1
            self.configure_raw(height=max(1, n), state="disabled")
        except Exception:
            pass

    def configure(self, cnf=None, **kwargs):
        if cnf:
            kwargs.update(cnf)
        if "text" in kwargs:
            self._set_text(kwargs.pop("text"))
        if kwargs:
            self.configure_raw(**kwargs)

    config = configure

    def cget(self, key):
        if key == "text":
            return self.get("1.0", "end-1c")
        return super().cget(key)


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept voluntarily; do not rely on it without rewiring and testing it first.
def slbl(parent, text, bold=False, color=None, size=10, **kwargs):
    """Selectable/copyable variant of lbl() — same signature, same style,
    but makes the text selectable via _SelectableLabel/_SelectableTextLabel
    instead of tk.Label (which does not allow selection in pure Tkinter).
    Automatically switches to the multi-line variant when wraplength is provided."""
    fg = color or T.FG
    font = ("Segoe UI", size, "bold") if bold else ("Segoe UI", size)
    bg = kwargs.pop("bg", _parent_bg(parent))
    txt = _xlate(text)
    if "wraplength" in kwargs:
        wraplength = kwargs.pop("wraplength")
        anchor = kwargs.pop("anchor", None)
        justify = kwargs.pop("justify", None)
        return _SelectableTextLabel(
            parent, text=txt, wraplength=wraplength, font=font,
            bg=bg, fg=fg, anchor=anchor, justify=justify, **kwargs,
        )
    return _SelectableLabel(parent, text=txt, font=font, bg=bg, fg=fg, **kwargs)


def btn(parent, text, cmd, color=None, width=14, fg=None):
    """Styled button — text contrasted automatically against the button color.
    Accent border visible on hover (highlightbackground/highlightthickness,
    the only "hover" effect possible in pure Tkinter, without gradient or shadow).
    Every click is traced in activity_log.txt (root of the software) (100% traceability).

    fg: explicitly forces the text color instead of the automatic choice
    _btn_fg(bg). Use only when that automatic choice gives a poorly readable
    result on a specific color (e.g. several mid-luminance colors of the same
    palette) — changes NOTHING for existing calls that do not pass it."""
    bg = color or T.ACCENT
    fg = fg or _btn_fg(bg)

    def _traced_cmd(text=text, cmd=cmd):
        try:
            from business.activity_log import log_ui
            log_ui("Button click", texte=text)
        except Exception:
            pass
        if cmd:
            return cmd()

    b = tk.Button(
        parent, text=_xlate(text), command=_traced_cmd,
        bg=bg, fg=fg, activebackground=T.SEL_BG, activeforeground=T.FG,
        relief="flat", cursor="hand2", font=("Segoe UI", 9, "bold"),
        width=width, pady=4,
        highlightthickness=2, highlightbackground=bg, highlightcolor=T.FG,
    )
    b.bind("<Enter>", lambda e: b.configure(highlightbackground=T.FG))
    b.bind("<Leave>", lambda e: b.configure(highlightbackground=bg))
    return b


def entry(parent, textvariable=None, width=30, show=None):
    """Input field."""
    return tk.Entry(
        parent, textvariable=textvariable,
        bg=T.ENTRY_BG, fg=T.FG, insertbackground=T.FG,
        relief="flat", font=("Segoe UI", 9),
        width=width, show=show,
    )


def section(parent, title):
    """Section with title and separator — title translated automatically."""
    frame = tk.Frame(parent, bg=T.BG)
    tk.Label(
        frame, text=_xlate(title),
        bg=T.BG, fg=T.ACCENT,
        font=("Segoe UI", 10, "bold"),
    ).pack(anchor="w", pady=(8, 2))
    tk.Frame(frame, bg=T.SEL_BG, height=1).pack(fill="x")
    return frame


def scrolled_frame(parent):
    """Frame with vertical scrollbar. Wheel active only on hover."""
    outer = tk.Frame(parent, bg=T.BG)
    canvas = tk.Canvas(outer, bg=T.BG, highlightthickness=0)
    vsb = tk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vsb.set)
    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    inner = tk.Frame(canvas, bg=T.BG)
    win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

    def _on_configure(e):
        canvas.configure(scrollregion=canvas.bbox("all"))
        canvas.itemconfig(win_id, width=canvas.winfo_width())

    inner.bind("<Configure>", _on_configure)
    canvas.bind("<Configure>", _on_configure)

    # Wheel bound to the sub-tree only (no global bind_all)
    _wheel_bound = []

    def _scroll(e):
        canvas.yview_scroll(-1 * (e.delta // 120), "units")

    def _scroll_break(e):
        # ttk.Combobox and tk.Spinbox NATIVELY change their value on wheel
        # scroll under Windows. When the user scrolls the page while hovering
        # one of these fields, its value changes by itself (e.g. an empty
        # dropdown becomes "Booking.com"). We force the page to scroll instead
        # and block (return "break") this accidental value change.
        canvas.yview_scroll(-1 * (e.delta // 120), "units")
        return "break"

    _VALUE_WHEEL_WIDGETS = ("TCombobox", "Spinbox", "TSpinbox")

    def _bind(_e=None):
        if _wheel_bound:
            return
        def _rec(w):
            try:
                handler = _scroll_break if w.winfo_class() in _VALUE_WHEEL_WIDGETS else _scroll
                w.bind("<MouseWheel>", handler)
                _wheel_bound.append(w)
            except tk.TclError:
                return
            for ch in w.winfo_children():
                _rec(ch)
        _rec(canvas)
        _rec(inner)

    def _unbind(_e=None):
        for w in _wheel_bound:
            try:
                w.unbind("<MouseWheel>")
            except tk.TclError:
                pass
        _wheel_bound.clear()

    canvas.bind("<Enter>", _bind)
    canvas.bind("<Leave>", _unbind)

    return outer, inner


def status_badge(parent, text, color, size=8):
    """Status badge: Label with flat colored background + automatically contrasted text.
    Reserved for tk.Frame layouts (cards, headers) — a ttk.Treeview or a
    tk.Text cannot embed a widget per cell/row without fragile hacking
    (.place() overlay that breaks on scroll/resize)."""
    fg = _btn_fg(color)
    return tk.Label(
        parent, text=_xlate(text), bg=color, fg=fg,
        font=("Segoe UI", size, "bold"), padx=8, pady=2,
    )


def zebra_stripe(tree):
    """Alternating stripe (even/odd rows) on an already-filled ttk.Treeview.
    Only affects the background — does not conflict with the text-color tags
    (foreground) already set on the rows (e.g. OK/error status).
    Call once the rows are in their final display order."""
    tree.tag_configure("_zebra_even", background=T.BG)
    tree.tag_configure("_zebra_odd", background=T.SEL_BG)
    for i, iid in enumerate(tree.get_children("")):
        cur_tags = tuple(t for t in tree.item(iid, "tags") if not t.startswith("_zebra_"))
        tree.item(iid, tags=cur_tags + (("_zebra_odd",) if i % 2 else ("_zebra_even",)))


def tooltip(widget, text):
    """Hover tooltip."""
    tip = [None]

    def show(e):
        x = widget.winfo_rootx() + 20
        y = widget.winfo_rooty() + widget.winfo_height() + 4
        tip[0] = tk.Toplevel(widget)
        tip[0].wm_overrideredirect(True)
        tip[0].wm_geometry(f"+{x}+{y}")
        tk.Label(
            tip[0], text=_xlate(text),
            bg="#2a2a3e", fg="#e8e8f0",
            font=("Segoe UI", 8),
            relief="flat", padx=6, pady=3,
        ).pack()

    def hide(e):
        if tip[0]:
            tip[0].destroy()
            tip[0] = None

    # add="+" MANDATORY: without it, these two bindings REPLACE the ones
    # already set on the widget. Yet btn() already binds <Enter>/<Leave> for
    # its accent border on hover — and the common usage is tooltip(btn(...)),
    # so the border was lost on practically every button of the application.
    widget.bind("<Enter>", show, add="+")
    widget.bind("<Leave>", hide, add="+")
    return widget  # allows chaining tooltip(btn(...)).pack(...)
