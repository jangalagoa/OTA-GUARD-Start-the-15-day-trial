"""
core/i18n_overrides.py — Manual per-language corrections.

Some French source words are ambiguous out of context and the automatic
translation engine (Google Translate, used offline by tools/i18n_batch_translate.py)
sometimes mistranslates them (e.g. "Journal" = activity log HERE, but Google
often picks "Newspaper"). These corrections are applied first, before the
generated catalog, so we never depend on an already-frozen batch.
"""

_OVERRIDES = {
    "en": {
        "Journal": "Log",
        "📋 Journal": "📋 Log",
    },
}


def get_overrides(lang_code: str) -> dict:
    """Return the manual correction table for a language (empty if none)."""
    return _OVERRIDES.get((lang_code or "").strip().lower(), {})
