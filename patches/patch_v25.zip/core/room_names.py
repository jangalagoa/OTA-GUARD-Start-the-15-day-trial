# -*- coding: utf-8 -*-
"""D108 — THE single room-mapping file.

One single file — ``data/room_names.json`` — says which hotel room matches
each name displayed by each OTA (and each machine identifier: Airbnb
listing id, Agoda typeId, Goibibo roomCode…).
The "OTA room mapping" menu is the ONLY writer, the scan the ONLY
decision-making reader. Nobody else sorts rooms.

Why this module exists: before D108, the mappings lived in the calibration
files (one per OTA) PLUS a generic airbnb file left over from an old August
trial. The scan read the generic one FIRST — crossed since the beginning —
while the owner's corrections went into the per-listing files: the mixture
came back at every scan (11/10 finding: "when you come back everything is
mixed again").
D108 (owner's order): one single file, readable, edited by the menu.

Schema ::
    {"schema": 1, "otas": {"agoda": {"names": {displayed_name: room},
                                     "ids":   {machine_id:  room}}}}

The migration (``ensure_ready``) is UNIQUE: it imports the old mappings from
the calibration files once, then the file lives its own life. The calibration
files keep their learned prices/sessions — they no longer decide room names.
"""
import json
import logging
import threading

from core.paths import DATA_DIR

_LOCK = threading.RLock()
_FILE_NAME = "room_names.json"


def _path():
    return DATA_DIR / _FILE_NAME


def _normalize(ota_id: str) -> str:
    try:
        from core.calib_store import _normalize_ota_id, _safe_ota_id
        return _safe_ota_id(_normalize_ota_id(ota_id))
    except Exception:
        import re
        s = re.sub(r"[^a-z0-9_-]+", "_", (ota_id or "").lower()).strip("_")
        return s or "_other"


def load() -> dict:
    """Full content (dict {ota_id: {names, ids}}). Never raises."""
    try:
        data = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("otas"), dict):
            return data
    except FileNotFoundError:
        pass
    except Exception:
        logging.exception("room_names: read impossible")
    return {"schema": 1, "otas": {}}


def save(data: dict) -> bool:
    """Atomic write — a crash never leaves a half-written file."""
    try:
        from business.secrets import atomic_write_json
        atomic_write_json(_path(), data, indent=1)
        return True
    except Exception:
        logging.exception("room_names: write impossible")
        return False


# ── Read ───────────────────────────────────────────────────────────────────

def aliases(ota_id: str) -> dict:
    """{name displayed by the OTA: our room} remembered for this OTA."""
    with _LOCK:
        return dict(((load().get("otas") or {})
                     .get(_normalize(ota_id)) or {}).get("names") or {})


def id_aliases(ota_id: str) -> dict:
    """{machine id: our room} — the anchor that survives renames."""
    with _LOCK:
        return dict(((load().get("otas") or {})
                     .get(_normalize(ota_id)) or {}).get("ids") or {})


# ── Write (the menu and anchor learning) ──────────────────────────────────

def set_aliases(ota_id: str, names: dict, ids: dict = None) -> bool:
    """Replaces ALL mappings of one OTA. One single file."""
    if not ota_id:
        return False
    with _LOCK:
        data = load()
        entry = {"names": {str(k): v for k, v in (names or {}).items() if k and v}}
        if ids is not None:
            entry["ids"] = {str(k): v for k, v in ids.items() if k and v}
        else:
            entry["ids"] = ((data.get("otas") or {})
                            .get(_normalize(ota_id)) or {}).get("ids") or {}
        data.setdefault("otas", {})[_normalize(ota_id)] = entry
        return save(data)


def learn_id_alias(ota_id: str, machine_id: str, our_room: str) -> bool:
    """Remembers ONE anchor {machine id: room} — completed, never replaced
    in bulk. Called by the scan when the attribution succeeded through a safe
    path: the id becomes the durable anchor that survives a rename."""
    if not (ota_id and machine_id and our_room):
        return False
    with _LOCK:
        data = load()
        ota = data.setdefault("otas", {}).setdefault(_normalize(ota_id),
                                                     {"names": {}, "ids": {}})
        ota.setdefault("ids", {})[str(machine_id)] = our_room
        return save(data)


# ── One-time migration from the old system ────────────────────────────────

def ensure_ready(config: dict = None) -> dict:
    """Creates/completes the single file.

    Two parts:
      — the UNIQUE import of the old calibration files (marked
        "migrated": never replayed, calibrations no longer decide
        room names);
      — the seeding of Airbnb listings from the config DECLARATION
        ("Airbnb <room>" + listing id in the URL), replayed on every
        call: a listing added to the config gets its entry by itself —
        without ever stomping a menu edit (only ABSENT keys are seeded).
    """
    with _LOCK:
        data = load()
        room_types = list((config or {}).get("room_types") or [])
        otas = data.setdefault("otas", {})

        # 1. UNIQUE import of calibrations (excluding the crossed generic airbnb)
        if not data.get("migrated"):
            try:
                from core.calib_store import load_calib_data
                for key, prof in ((load_calib_data().get("profiles")) or {}).items():
                    sid = str(key).split("||")[-1]
                    if not sid or sid == "airbnb" or sid == "shared":
                        continue    # crossed leftover / shared: never imported
                    names = {str(k): v for k, v in
                             (prof.get("room_aliases") or {}).items() if k and v}
                    ids = {str(k): v for k, v in
                           (prof.get("room_id_aliases") or {}).items() if k and v}
                    if names or ids:
                        e = otas.setdefault(sid, {"names": {}, "ids": {}})
                        e["names"].update(names)
                        e["ids"].update(ids)
            except Exception:
                logging.exception("room_names: calibration import")
            data["migrated"] = True

        # 2. Idempotent seeding of Airbnb listings (declaration):
        #    replayed on every call — a listing added to the config gets
        #    its entry by itself — but never STOMPS a menu edit (only
        #    ABSENT keys are seeded).
        import re as _re
        for o in ((config or {}).get("ota_watch", {}) or {}).get("otas") or []:
            url = (o.get("url") or "")
            name = (o.get("name") or "").strip()
            m = _re.search(r"/rooms/(\d+)", url)
            if not (m and "airbnb" in url.lower() and name):
                continue
            declared = (name[len("Airbnb"):].strip()
                        if name.lower().startswith("airbnb") else name)
            if not declared or (room_types and declared not in room_types):
                continue     # unreadable: to be mapped in the menu
            sid = _normalize(name)
            entry = otas.setdefault(sid, {"names": {}, "ids": {}})
            entry["names"].setdefault(name, declared)
            entry["ids"].setdefault(m.group(1), declared)

        save(data)
        return data
