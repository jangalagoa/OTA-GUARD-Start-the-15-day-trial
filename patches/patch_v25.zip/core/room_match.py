# -*- coding: utf-8 -*-
"""
Matching "room name displayed by the OTA" ↔ "hotel room".

Why this module (created on 2026-07-31)
---------------------------------------
Surveyed prices kept landing on the wrong room. Three causes measured on the
real data of the Jangala hotel:

1. Names were compared WHOLE-PHRASE by `difflib.SequenceMatcher`, with an
   acceptance threshold of 0.45. But the hotel's 4 rooms differ by only one
   word, which gave:
       "Double Room with Balcony" vs "Deluxe Double Room with Balcony" = 0.87
       "Double Room"              vs "Deluxe Double Room"             = 0.76
       "Double Room"              vs "Move room"                      = 0.70
   … i.e. three pairs well above the threshold: the software accepted wrong
   matches instead of refusing them.

2. Attribution was FIRST-COME-FIRST-SERVED: the first room read took the best
   still-free name, the following ones shared the leftovers. A single early
   error shifted everything after it.

3. Nothing remembered the name used by the OTA. Proof in the Agoda
   calibration: 8 rooms recorded for 4 real ones, because Agoda displayed
   « Chambre Double avec Balcon (Double Room with Balcony) » once and
   « Double Room with Balcony » another time.

What this module does
---------------------
* `room_tokens`      : reduces a name to its DISTINCTIVE words (removes
                       "room", "chambre", "breakfast included", "free
                       cancellation"…, and translates common FR/ES/DE/IT
                       terms to English) → « Chambre Double avec Balcon » and
                       "Double Room with Balcony" become identical.
* `name_score`       : 0→1 similarity computed on those distinctive words.
* `match_rooms`      : GLOBAL attribution, safest pair first, and explicit
                       REFUSAL when two rooms contend for the same name
                       within less than `margin` (a hole is better than a
                       price on the wrong room).
* `apply_aliases`/`learn_aliases` : "OTA name → our room" dictionary
                       memorized per OTA in the calibration profile
                       (key `room_aliases`). Once filled in, there is nothing
                       left to guess: it is a lookup.
* `plausibility_warnings` : compares the survey to the learned price history
                       and flags a probable swap between two rooms.

No dependency outside the standard library: this module is imported both by
the survey engine (scraping) and by the UI (Calibration menu).
"""

import difflib
import re
import unicodedata

# Acceptance threshold for an automatic match. Deliberately far higher than
# the old 0.45: below it, we prefer to attribute nothing.
DEFAULT_THRESHOLD = 0.55
# Minimal gap required between the best candidate and the next one. Below it,
# the match is judged AMBIGUOUS and refused (cf. "Deluxe Double Room" vs
# "Double Room", too similar to be separated without risk).
DEFAULT_MARGIN = 0.12


# ── Words that do not distinguish one room from another ──────────────────────
# Removed before comparison. Multilingual: OTAs often display the name
# translated into the visitor's language (observed on Agoda). Words below
# mirror what OTA pages actually display — kept verbatim.
_NOISE = {
    # generic
    "room", "rooms", "chambre", "chambres", "habitacion", "habitacion",
    "zimmer", "camera", "quarto", "kamar", "kamer", "rum",
    # articles / liaisons
    "the", "a", "an", "le", "la", "les", "un", "une", "des", "du", "de", "d",
    "el", "los", "las", "il", "der", "die", "das", "with", "avec", "and", "et",
    "y", "e", "und", "con", "sans", "without", "or", "ou", "in", "at", "por",
    "for", "pour", "per", "van",
    # conditions tarifaires
    "breakfast", "petit", "dejeuner", "déjeuner", "desayuno", "fruhstuck",
    "included", "inclus", "incluse", "incluses", "inclusive", "incl",
    "free", "gratuit", "gratuite", "gratis", "offert", "offerte",
    "cancellation", "annulation", "cancelacion", "refundable", "remboursable",
    "non", "no", "pay", "payer", "later", "now", "book", "reserver",
    "deal", "offer", "offre", "promo", "promotion", "special", "save",
    "rate", "tarif", "price", "prix", "night", "nights", "nuit", "nuits",
    "tax", "taxes", "fees", "total", "from", "des",
    # occupation (l'occupation n'identifie pas le TYPE de chambre)
    "guest", "guests", "adult", "adults", "personne", "personnes", "pax",
    "occupancy", "sleeps", "max", "maximum",
    # bedding / amenities too widespread to discriminate
    "bed", "beds", "lit", "lits", "size", "type", "only", "new",
    "wifi", "tv", "smoking", "nonsmoking",
    # divers
    "sqm", "sq", "ft", "m2",
}

# ── Equivalent terms brought back to a single form ───────────────────────────
# Goal: « Chambre Double Deluxe avec Balcon » (Agoda in French) and
# "Deluxe Double Room with Balcony" (our name) yield the same words.
# OTA page words — kept verbatim, multilingual.
_SYNONYMS = {
    # categories
    "delux": "deluxe", "luxe": "deluxe", "lujo": "deluxe", "luxus": "deluxe",
    "luxury": "deluxe", "deluxe": "deluxe",
    "superieur": "superior", "supérieur": "superior", "superieure": "superior",
    "superior": "superior", "superiore": "superior",
    "standart": "standard", "estandar": "standard", "standaard": "standard",
    "classique": "standard", "classic": "standard", "standard": "standard",
    "basic": "standard", "basique": "standard",
    "economique": "economy", "economy": "economy", "budget": "economy",
    "executif": "executive", "executive": "executive", "ejecutiva": "executive",
    "premium": "premium", "prestige": "premium",
    "suite": "suite", "junior": "junior",
    "familiale": "family", "familial": "family", "familiar": "family",
    "famille": "family", "family": "family",
    "appartement": "apartment", "apartamento": "apartment",
    "apartment": "apartment", "studio": "studio",
    "villa": "villa", "bungalow": "bungalow", "cottage": "cottage",
    "dortoir": "dorm", "dormitory": "dorm", "dorm": "dorm",
    # occupation → type
    "simple": "single", "individuelle": "single", "individual": "single",
    "single": "single",
    "doble": "double", "doppel": "double", "doppia": "double",
    "duplo": "double", "double": "double",
    "jumeaux": "twin", "twin": "twin", "gemelas": "twin",
    "triple": "triple", "quadruple": "quad", "quad": "quad",
    # views and distinctive amenities
    "balcon": "balcony", "balkon": "balcony", "balcone": "balcony",
    "balcony": "balcony", "terrasse": "terrace", "terrace": "terrace",
    "vue": "view", "vista": "view", "view": "view", "blick": "view",
    "mer": "sea", "mar": "sea", "ocean": "sea", "oceano": "sea",
    "sea": "sea", "meer": "sea",
    "jardin": "garden", "garden": "garden", "giardino": "garden",
    "piscine": "pool", "pool": "pool", "piscina": "pool",
    "montagne": "mountain", "mountain": "mountain",
    "ville": "city", "city": "city", "ciudad": "city",
    "climatisee": "ac", "climatisée": "ac", "aircon": "ac",
    "airconditioned": "ac", "ac": "ac",
    "cuisine": "kitchen", "kitchen": "kitchen", "kitchenette": "kitchen",
    "prive": "private", "privee": "private", "private": "private",
    "partage": "shared", "shared": "shared",
}


def _strip_accents(text: str) -> str:
    try:
        return "".join(c for c in unicodedata.normalize("NFD", text)
                       if unicodedata.category(c) != "Mn")
    except Exception:
        return text


def _stem(token: str) -> str:
    """Simple English/French plural: "balconies" → "balcon*"."""
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 3 and token.endswith("s") and not token.endswith("ss"):
        return token[:-1]
    return token


def room_tokens(name) -> frozenset:
    """DISTINCTIVE words of a room name, canonical form.

    "Deluxe Double Room with Balcony — Free Cancellation"    → {deluxe, double, balcony}
    « Chambre Double avec Balcon (Double Room with Balcony) » → {double, balcony}
    """
    txt = _strip_accents(str(name or "")).lower()
    # Parentheses often contain the original name: we keep everything,
    # the union of words does the job.
    txt = re.sub(r"[^a-z0-9]+", " ", txt)
    out = set()
    for raw in txt.split():
        tok = _SYNONYMS.get(raw, raw)
        if tok in _NOISE:
            continue
        tok = _stem(tok)
        tok = _SYNONYMS.get(tok, tok)
        if tok in _NOISE or len(tok) < 2:
            continue
        out.add(tok)
    return frozenset(out)


def normalize_room_name(name) -> str:
    """Canonical form used as ALIAS KEY (case/accent/order insensitive).

    Two labels differing only by punctuation, case, accents or word order
    yield the same key — a recorded alias therefore keeps working if the OTA
    changes "Deluxe Double Room" into "Double Deluxe".
    """
    toks = room_tokens(name)
    if toks:
        return " ".join(sorted(toks))
    # Name entirely made of "noise" words: we fall back to the cleaned text
    # rather than an empty key (which would glue all those names together).
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ",
                                      _strip_accents(str(name or "")).lower())).strip()


def name_score(a, b) -> float:
    """0→1 similarity between two room names, based on the distinctive words.

    Unlike a whole-phrase comparison, the absence of a single discriminating
    word drops the score:
        Double / Deluxe Double                      → 0.50  (was 0.76)
        Double+Balcony / Deluxe Double+Balcony      → 0.67  (was 0.87)
        Double / Move                               → 0.00  (was 0.70)
    """
    ta, tb = room_tokens(a), room_tokens(b)
    if not ta or not tb:
        # No distinctive word on one side: last resort, text comparison.
        return difflib.SequenceMatcher(
            None, normalize_room_name(a), normalize_room_name(b)).ratio()
    if ta == tb:
        return 1.0
    # Weighted overlap: each word of A looks for its best equivalent in B
    # (typo-tolerant), each word of B is taken only once. The denominator is
    # the union → an extra word penalizes as much as a missing one.
    free = set(tb)
    overlap = 0.0
    matched = 0
    for t in ta:
        best, best_s = None, 0.0
        for u in free:
            s = 1.0 if t == u else difflib.SequenceMatcher(None, t, u).ratio()
            if s > best_s:
                best, best_s = u, s
        if best is not None and best_s >= 0.86:
            free.discard(best)
            overlap += best_s
            matched += 1
    union = len(ta) + len(tb) - matched
    return (overlap / union) if union else 0.0


def apply_aliases(ota_names, aliases) -> dict:
    """{index in ota_names → our room} for the already-memorized names.

    `aliases` is the `room_aliases` dictionary of the calibration profile,
    in the form {name displayed by the OTA: our room}. The comparison happens
    on the canonical form, not on the raw text.
    """
    if not aliases:
        return {}
    table = {}
    for ota_name, our in (aliases or {}).items():
        key = normalize_room_name(ota_name)
        if key and our:
            table[key] = our
    out = {}
    for i, nm in enumerate(ota_names or []):
        our = table.get(normalize_room_name(nm))
        if our:
            out[i] = our
    return out


def match_rooms(ota_names, our_rooms, aliases=None,
                threshold=DEFAULT_THRESHOLD, margin=DEFAULT_MARGIN):
    """Matches the names read on the OTA to our rooms.

    Returns (mapping, refus):
      * mapping : {index in ota_names → our room}
      * refus   : {index in ota_names → reason} for what was NOT attributed
                  ("too dissimilar" / "ambiguous between X and Y").

    Three tiers, from the safest to the least safe:
      1. memorized alias (no guessing);
      2. identical name after cleaning (score 1.0);
      3. similarity, safest pair first, and refusal if the second candidate
         is within less than `margin` — better to attribute nothing than to
         put the price on the wrong room.
    """
    ota_names = list(ota_names or [])
    our_rooms = list(our_rooms or [])
    mapping, refus = {}, {}
    if not ota_names or not our_rooms:
        return mapping, {i: "no reference room" for i in range(len(ota_names))}

    # Tier 1 — memorized aliases
    mapping.update(apply_aliases(ota_names, aliases))
    used_rooms = set(mapping.values())
    free_idx = [i for i in range(len(ota_names)) if i not in mapping]

    # Score table (only for what remains to attribute)
    scores = {}
    for i in free_idx:
        for r in our_rooms:
            scores[(i, r)] = name_score(ota_names[i], r)

    # Tiers 2 and 3 — best pairs first (global descending sort)
    pairs = sorted(
        ((scores[(i, r)], i, r) for i in free_idx for r in our_rooms),
        key=lambda t: (-t[0], t[1], t[2]))
    for sc, i, room in pairs:
        if i in mapping or room in used_rooms or sc < threshold:
            continue
        # Ambiguity: does another of OUR rooms still free score almost as
        # well for this same OTA name?
        rival, rival_sc = None, 0.0
        for r2 in our_rooms:
            if r2 == room or r2 in used_rooms:
                continue
            s2 = scores[(i, r2)]
            if s2 > rival_sc:
                rival, rival_sc = r2, s2
        if sc < 1.0 and rival is not None and (sc - rival_sc) < margin:
            refus[i] = f"ambiguous between '{room}' and '{rival}' ({sc:.2f} vs {rival_sc:.2f})"
            continue
        mapping[i] = room
        used_rooms.add(room)

    for i in range(len(ota_names)):
        if i not in mapping and i not in refus:
            best = max((scores.get((i, r), 0.0) for r in our_rooms), default=0.0)
            refus[i] = f"too dissimilar (best score {best:.2f})"
    return mapping, refus


def learn_aliases(existing, pairs) -> dict:
    """Completes the alias dictionary with confirmed pairs.

    `pairs`: list of (name displayed by the OTA, our room).
    The original OTA text is kept as is as the key (readable in the
    calibration file); it is the comparison that is insensitive to case and
    accents. An existing alias for the same name is replaced.
    """
    out = dict(existing or {})
    seen = {normalize_room_name(k): k for k in out}
    for ota_name, our in pairs or []:
        ota_name = (str(ota_name or "")).strip()
        if not ota_name or not our:
            continue
        key = normalize_room_name(ota_name)
        old = seen.get(key)
        if old is not None and old != ota_name:
            out.pop(old, None)
        out[ota_name] = our
        seen[key] = ota_name
    return out


def _median(values):
    vals = sorted(v for v in values if isinstance(v, (int, float)) and v > 0)
    if not vals:
        return None
    n = len(vals)
    return vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2.0


def _history_values(entry) -> list:
    """Usable price list from a `prices_learned` entry.

    Real shape of the calibration file (verified on 2026-07-31):
        {"avg": 1617, "min": 326, "max": 2705, "count": 30, "history": [...]}
    Simpler shapes (raw list, bare number) are accepted too.
    """
    if isinstance(entry, dict):
        vals = entry.get("history")
        if not isinstance(vals, list) or not vals:
            vals = [entry.get("avg", entry.get("average"))]
    elif isinstance(entry, list):
        vals = entry
    else:
        vals = [entry]
    out = []
    for v in vals or []:
        if isinstance(v, dict):
            v = v.get("price", v.get("value"))
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        if v > 0:
            out.append(v)
    return out


def plausibility_warnings(prices, history, min_samples=3,
                          gap=0.05, range_margin=2.0):
    """Compares a survey to the learned history and flags what is wrong.

    `prices`  : {our room: surveyed price}
    `history` : the `prices_learned` of the calibration profile.

    The check bears on the ORDER of the rooms relative to each other, not on
    the absolute price level: on this hotel, the history of a single room
    spans 966 to 2705 depending on season and date, so a gap from the usual
    rate proves nothing — whereas the order itself is stable (Double <
    Deluxe < Balcon < Deluxe+Balcon). A price swap between two rooms breaks
    that order: it is exactly the signature of a price put on the wrong room.

    A second check, deliberately very wide, flags a value outside the whole
    range ever observed (half the minimum / double the maximum).

    Returns a list of messages. Corrects nothing: a genuine re-pricing by the
    hotelier would produce the same signal.
    """
    warns = []
    stats = {}
    for room, entry in (history or {}).items():
        vals = _history_values(entry)
        if len(vals) >= min_samples:
            stats[room] = {"med": _median(vals), "lo": min(vals), "hi": max(vals)}

    rooms = [r for r in (prices or {})
             if r in stats and stats[r]["med"] and prices.get(r)]

    # ── Check 1: is the usual order between two rooms respected? ────────────
    for a_i in range(len(rooms)):
        for b_i in range(a_i + 1, len(rooms)):
            ra, rb = rooms[a_i], rooms[b_i]
            ma, mb = stats[ra]["med"], stats[rb]["med"]
            try:
                pa, pb = float(prices[ra]), float(prices[rb])
            except (TypeError, ValueError):
                continue
            if not (ma and mb and pa and pb):
                continue
            # Significant gap expected AND observed, in both directions?
            if max(ma, mb) / min(ma, mb) < 1 + gap:
                continue          # these two rooms are usually neck and neck
            if max(pa, pb) / min(pa, pb) < 1 + gap:
                continue          # survey neck and neck: nothing to conclude
            expected_cheaper = ra if ma < mb else rb
            current_cheaper  = ra if pa < pb else rb
            if expected_cheaper != current_cheaper:
                warns.append(
                    f"unusual order: '{ra}' at {pa:.0f} and '{rb}' at {pb:.0f} "
                    f"while '{expected_cheaper}' is usually the cheapest "
                    f"({ma:.0f} vs {mb:.0f}) — probable swap of the two prices")

    # ── Check 2: value outside the whole range ever observed ────────────────
    for room, price in (prices or {}).items():
        st = stats.get(room)
        if not st:
            continue
        try:
            p = float(price)
        except (TypeError, ValueError):
            continue
        if p <= 0:
            continue
        if p < st["lo"] / range_margin or p > st["hi"] * range_margin:
            warns.append(
                f"'{room}' at {p:.0f} falls outside the whole known range "
                f"({st['lo']:.0f} – {st['hi']:.0f})")
    return warns
