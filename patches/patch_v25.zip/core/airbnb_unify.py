# -*- coding: utf-8 -*-
"""D110 — ONE SINGLE "Airbnb" OTA, the Expedia model applied to Airbnb.

Owner's finding: "I'm lost, I don't know what matches what". The 4
"Airbnb <room>" entries (one per listing) made the mapping unreadable: every
Airbnb listing displays the SAME title ("Chambre · Baga, Inde"), so a name
cannot distinguish anything — the only reliable identifier is the LISTING
NUMBER in its link.

D110 model (identical to Expedia):
  - the config carries ONE "Airbnb" entry whose `listings` field lists
    the listing links;
  - target prices are per room under "Airbnb" (like Expedia);
  - the mapping lives in room_names.json, "airbnb" entry:
    names = {"Listing …XXXX" label: room}, ids = {listing number: room};
  - the menu displays an Airbnb section: one line per listing (number +
    read price + "view listing" link) → your room.

`unify_airbnb()`: idempotent migration — detects the old per-listing
entries, merges everything, preserves targets/results/history, and
NEVER writes beyond what it migrates. `listing_display()`: the
canonical label of a listing, the same everywhere (scan, menu, logs).
"""
import json
import re

OTA_NAME = "Airbnb"
_FICHE = "airbnb"


def listing_display(lid: str) -> str:
    """Canonical label of a listing — the same at scan time, in the menu and
    in messages: "Annonce …8092" (the number is the identity).
    KEPT IN FRENCH ON PURPOSE: this label is a stored key in
    room_names.json ("names") and is rebuilt identically by the menu
    (tab_blocage_ota) — changing it would orphan existing mappings."""
    return f"Annonce …{str(lid)[-4:]}"


def listing_ids_of(config: dict) -> list:
    """[(lid, url)] of ALL Airbnb listings of the config — unified entry
    (`listings`) as well as legacy (one entry per listing)."""
    out = {}
    for o in (config.get("ota_watch", {}) or {}).get("otas") or []:
        urls = [o.get("url") or ""]
        urls += [str(u) for u in (o.get("listings") or [])]
        for u in urls:
            if "airbnb" not in (u or "").lower():
                continue
            m = re.search(r"/rooms/(\d+)", u)
            if m:
                out.setdefault(m.group(1), u)
    return sorted(out.items())


def _seed_fiche(config: dict, pairs: dict) -> None:
    """'airbnb' entry of the single file: ids + listing labels.
    Never STOMPS an existing value (the menu edit wins)."""
    from core import room_names
    room_names.ensure_ready(config)
    data = room_names.load()
    e = data.setdefault("otas", {}).setdefault(_FICHE,
                                               {"names": {}, "ids": {}})
    for lid, room in pairs.items():
        if not room:
            continue
        e.setdefault("ids", {}).setdefault(str(lid), room)
        e.setdefault("names", {}).setdefault(listing_display(lid), room)
    room_names.save(data)


def unify_airbnb(config: dict) -> bool:
    """Merges the per-listing Airbnb entries into ONE "Airbnb" entry.

    Migration (once, idempotent):
      - otas: N "Airbnb <x>" entries → 1 entry {Airbnb, listings[urls]};
      - target_prices[room]: the "Airbnb <x>" target of the listing of THIS
        room becomes target_prices[room]["Airbnb"];
      - last_results: the per-pseudo-OTA results merge under
        "Airbnb" (rooms in there are already correct, D108);
      - room_names: the per-listing entries merge into the "airbnb"
        entry (ids = the listing number, immutable).
    Returns True if the config changed (to be saved by the caller)."""
    ow = config.setdefault("ota_watch", {})
    otas = ow.get("otas") or []

    ab = []
    for o in otas:
        u = (o.get("url") or "")
        if "airbnb" in u.lower() and "/rooms/" in u:
            ab.append(o)
    if not ab:
        return False
    if len(ab) == 1 and (ab[0].get("name") or "").strip() == OTA_NAME:
        # Already a single "Airbnb" entry. D112: if its `listings` have
        # disappeared (old UI-save bug, fixed in D112), REPAIR from the
        # listing numbers remembered in the "airbnb" entry of the single
        # file — never stay at a single listing without saying so.
        have = list(ab[0].get("listings") or [])
        _known = dict(listing_ids_of(config))
        if len(have) >= len(_known) and have:
            return False                      # healthy, nothing to do
        fiche_ids = []
        try:
            from core import room_names
            fiche_ids = sorted(room_names.id_aliases(_FICHE).keys())
        except Exception:
            pass
        rebuilt = []
        seen = set()
        for lid in list({re.search(r"/rooms/(\d+)", u).group(1)
                         for u in have if re.search(r"/rooms/(\d+)", u)}) + \
                fiche_ids:
            if lid and lid not in seen:
                seen.add(lid)
                rebuilt.append(f"https://www.airbnb.fr/rooms/{lid}")
        if len(rebuilt) <= len(have):
            return False                      # nothing better to offer
        ab[0]["listings"] = rebuilt
        if "airbnb" not in (ab[0].get("url") or "").lower() and rebuilt:
            ab[0]["url"] = rebuilt[0]
        return True

    # room of each listing: its room_names entry (ids, D108)
    _seed_fiche(config, {})               # legacy entries ready
    from core import room_names
    lid_room = {}
    for o in ab:
        m = re.search(r"/rooms/(\d+)", o.get("url") or "")
        if not m:
            continue
        lid = m.group(1)
        try:
            from core.calib_store import _normalize_ota_id, _safe_ota_id
            sid = _safe_ota_id(_normalize_ota_id(o.get("name") or ""))
        except Exception:
            sid = ""
        room = (room_names.id_aliases(sid).get(lid)
                or room_names.id_aliases(_FICHE).get(lid) or "")
        lid_room[lid] = room

    # 1) targets per room: the listing OF the room gives the Airbnb target
    tp = ow.get("target_prices") or {}
    old_names = [o.get("name") for o in ab if o.get("name")]
    for room, per in tp.items():
        if not isinstance(per, dict):
            continue
        mine = None
        for o in ab:
            m = re.search(r"/rooms/(\d+)", o.get("url") or "")
            if not m or lid_room.get(m.group(1)) != room:
                continue
            v = per.get(o.get("name"))
            if v is not None:
                mine = v
                break
        for n in list(per.keys()):
            if n in old_names or (n or "").strip().startswith("Airbnb"):
                per.pop(n, None)
        if mine is not None:
            per[OTA_NAME] = mine

    # 2) results: merge under "Airbnb" (rooms already correct)
    lr = ow.get("last_results") or {}
    merged = {}
    for o in ab:
        d = lr.pop(o.get("name"), None) or {}
        if isinstance(d, dict):
            merged.update(d)
    existing = lr.get(OTA_NAME)
    if isinstance(existing, dict):
        existing.update(merged)
        lr[OTA_NAME] = existing
    elif merged:
        lr[OTA_NAME] = merged

    # 3) one single entry, in place of the first
    urls = [o.get("url") for o in ab if o.get("url")]
    new_entry = {"name": OTA_NAME,
                 "active": any(o.get("active", True) for o in ab),
                 "url": urls[0],
                 "listings": urls}
    idx = otas.index(ab[0])
    otas[idx] = new_entry
    for o in ab[1:]:
        otas.remove(o)
    ow["otas"] = otas
    ow["last_results"] = lr
    ow["target_prices"] = tp

    # 4) single "airbnb" entry: ids + listing labels
    _seed_fiche(config, lid_room)
    return True
