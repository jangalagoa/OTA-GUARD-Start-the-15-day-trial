"""
Calibration storage — one JSON file per OTA.

Before: a single data/calibration_data.json shared by all OTAs. A scan
writing Agoda's calibration while another thread writes Booking's would
step on each other (last `atomic_write_json` wins, the other OTA loses its
write). Here, each OTA has its own file data/calibration_data_<ota_id>.json:
two different OTAs can never collide again.

API (replaces any direct read/write of calibration_data.json):
  - load_calib_data() -> dict        : merge of all per-OTA files, same shape
                                        as the old single file
                                        ({"profiles": {...}, "scan_results": {...}}).
  - save_calib_data(data: dict) -> bool : splits `data["profiles"]` per OTA and
                                        rewrites each file; the rest
                                        (scan_results, etc.) goes into
                                        calibration_data_shared.json.

Migration: on first call, if the old calibration_data.json still exists,
it is merged into the new files then renamed to
calibration_data.json.migrated_bak (never deleted).
"""
import json
import logging
import re
import time

from core.paths import DATA_DIR

_PREFIX = "calibration_data_"
_SHARED_NAME = f"{_PREFIX}shared.json"
_LEGACY_FILE = DATA_DIR / "calibration_data.json"


def _normalize_ota_id(name: str) -> str:
    """Same logic as Tab._name_to_id (tab_calibration.py) — keep in sync."""
    n = (name or "").lower()
    if "agoda" in n:      return "agoda"
    if "booking" in n:    return "booking"
    if "makemytrip" in n: return "makemytrip"
    if "google" in n:     return "google_hotels"
    return n.replace(" ", "_")


def _safe_ota_id(ota_id: str) -> str:
    s = re.sub(r"[^a-z0-9_-]+", "_", (ota_id or "").lower()).strip("_")
    return s or "_other"


def _ota_id_from_profile_key(key: str) -> str:
    """Profile key = "hotel||ota_id" (current format) or just the OTA name/id (legacy)."""
    part = key.split("||", 1)[1] if "||" in key else key
    return _safe_ota_id(_normalize_ota_id(part))


def _ota_file(ota_id: str):
    return DATA_DIR / f"{_PREFIX}{ota_id}.json"


def _existing_ota_ids() -> set:
    ids = set()
    if not DATA_DIR.exists():
        return ids
    for fp in DATA_DIR.glob(f"{_PREFIX}*.json"):
        if fp.name == _SHARED_NAME:
            continue
        ids.add(fp.stem[len(_PREFIX):])
    return ids


def _read_json(fp) -> dict:
    try:
        if fp.exists():
            return json.loads(fp.read_text(encoding="utf-8"))
    except Exception:
        logging.exception("calib_store: unreadable file — %s", fp)
    return {}


def _read_all_parts() -> dict:
    merged = {"profiles": {}, "scan_results": {}}
    for oid in sorted(_existing_ota_ids()):
        part = _read_json(_ota_file(oid))
        merged["profiles"].update(part.get("profiles") or {})
    shared = _read_json(DATA_DIR / _SHARED_NAME)
    for k, v in shared.items():
        merged[k] = v
    return merged


def _migrate_legacy_if_needed():
    if not _LEGACY_FILE.exists():
        return
    old_data = _read_json(_LEGACY_FILE)
    if old_data:
        current = _read_all_parts()
        merged_profiles = dict(old_data.get("profiles") or {})
        merged_profiles.update(current.get("profiles") or {})  # already-migrated wins
        merged = {"profiles": merged_profiles}
        for k, v in old_data.items():
            if k != "profiles":
                merged[k] = v
        for k, v in current.items():
            if k != "profiles":
                merged[k] = v
        save_calib_data(merged)

    backup = DATA_DIR / "calibration_data.json.migrated_bak"
    if backup.exists():
        backup = DATA_DIR / f"calibration_data.json.migrated_bak_{int(time.time())}"
    try:
        _LEGACY_FILE.rename(backup)
    except Exception:
        logging.exception("calib_store: renaming the old calibration_data.json failed")


def load_calib_data() -> dict:
    try:
        _migrate_legacy_if_needed()
    except Exception:
        logging.exception("calib_store: migration failed — reading existing files anyway")
    return _read_all_parts()


def save_calib_data(data: dict) -> bool:
    try:
        from business.secrets import atomic_write_json

        profiles = data.get("profiles", {}) or {}
        buckets = {}
        for key, profile in profiles.items():
            buckets.setdefault(_ota_id_from_profile_key(key), {})[key] = profile

        for oid in _existing_ota_ids() | set(buckets.keys()):
            atomic_write_json(_ota_file(oid), {"profiles": buckets.get(oid, {})})

        shared = {k: v for k, v in data.items() if k != "profiles"}
        atomic_write_json(DATA_DIR / _SHARED_NAME, shared)
        return True
    except Exception:
        logging.exception("calib_store: save failed — calibration NOT saved")
        return False
