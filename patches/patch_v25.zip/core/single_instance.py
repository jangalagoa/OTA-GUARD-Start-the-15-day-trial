"""Single-instance lock (D33, 27/08).

On 27/08, an instance whose window was closed (Exit 16:04) kept pushing
prices until 17:29 while the restarted instance (16:12) was pushing too:
two CDP executors in the SAME BulkUpdate form, two contradictory queues,
chaos. Two app copies on the same CDP port 9222 must never coexist.

Principle: an instance.lock file in DATA_DIR holding the PID.
- at startup: lock present + PID alive → refuse (the user closes the
  other instance); lock present + dead PID (crash) → take over;
- at shutdown: release_lock() removes the lock only if it holds OUR PID.
Never blocking: a lock issue must not prevent the app from starting
(we just warn best-effort — see acquire_lock which returns control on
disk errors).
"""

import os

LOCK_NAME = "instance.lock"


def _lock_path():
    from core.paths import DATA_DIR
    return DATA_DIR / LOCK_NAME


def _pid_alive(pid: int) -> bool:
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        # PROCESS_QUERY_LIMITED_INFORMATION — enough to know whether the
        # process exists, without any particular rights on it.
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = ctypes.windll.kernel32.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            if ctypes.windll.kernel32.GetExitCodeProcess(
                    handle, ctypes.byref(exit_code)):
                return exit_code.value == 259      # STILL_ACTIVE
            return True
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_lock():
    """→ (ok, existing_pid). ok=False: another instance is already alive."""
    try:
        lock = _lock_path()
        if lock.exists():
            old = (lock.read_text(encoding="utf-8") or "").strip()
            if old.isdigit() and _pid_alive(int(old)):
                return False, int(old)
        lock.parent.mkdir(parents=True, exist_ok=True)
        lock.write_text(str(os.getpid()), encoding="utf-8")
        return True, os.getpid()
    except Exception:
        # An unreadable/locked lock must NEVER block startup.
        return True, os.getpid()


def release_lock():
    """Removes the lock only if it holds OUR PID (never someone else's)."""
    try:
        lock = _lock_path()
        if lock.exists():
            current = (lock.read_text(encoding="utf-8") or "").strip()
            if current == str(os.getpid()):
                lock.unlink()
    except Exception:
        pass
