"""
Color and theme management.
All tabs import T to access the current colors.
Usage: from core.theme import T
       bg=T.BG, fg=T.FG ...
"""

THEMES = {
    # ── 1. Warm violet/blue background — light lavender text (~10:1 contrast) ──
    "Catppuccin Mocha": {
        "BG": "#1e1e2e", "FG": "#cdd6f4", "ENTRY_BG": "#313244",
        "SEL_BG": "#45475a", "ACCENT": "#89b4fa",
        "GREEN": "#a6e3a1", "RED": "#f38ba8", "ORANGE": "#fab387", "YELLOW": "#f9e2af",
        "desc": "Dark violet & lavender — the most popular right now (GitHub ★ 7k+)",
    },
    # ── 2. Night violet background — pure white text (~13:1 contrast) ──
    "Dracula": {
        "BG": "#282a36", "FG": "#f8f8f2", "ENTRY_BG": "#1e1f29",
        "SEL_BG": "#44475a", "ACCENT": "#bd93f9",
        "GREEN": "#50fa7b", "RED": "#ff5555", "ORANGE": "#ffb86c", "YELLOW": "#f1fa8c",
        "desc": "Violet & bright pink — pure white text, the most popular on GitHub (★ 20k+)",
    },
    # ── 3. Deep teal background — warm cream text (~11:1 contrast) ──
    "Solarized Dark": {
        "BG": "#002b36", "FG": "#eee8d5", "ENTRY_BG": "#073642",
        "SEL_BG": "#094657", "ACCENT": "#33b8ae",
        "GREEN": "#a8c000", "RED": "#ff5555", "ORANGE": "#f07828", "YELLOW": "#e0b800",
        "desc": "Deep teal & cream — unique identity, very easy on the eyes",
    },
    # ── 4. Forest green background — warm sand text (~9:1 contrast) ──
    "Everforest": {
        "BG": "#1e2718", "FG": "#d3c6aa", "ENTRY_BG": "#272e22",
        "SEL_BG": "#343f2e", "ACCENT": "#a7c080",
        "GREEN": "#83c092", "RED": "#e67e80", "ORANGE": "#e69875", "YELLOW": "#dbbc7f",
        "desc": "Forest green & golden sand — nature theme, very distinctive",
    },
    # ── 5. Warm brown/red background — cream text (~12:1 contrast) ──
    "Warm Ember": {
        "BG": "#1c1210", "FG": "#f0e6d3", "ENTRY_BG": "#2a1e1a",
        "SEL_BG": "#3a2822", "ACCENT": "#e8926e",
        "GREEN": "#7dbb8a", "RED": "#d05050", "ORANGE": "#e8926e", "YELLOW": "#f0c060",
        "desc": "Warm brown & cream — ember tones, far removed from blue themes",
    },
    # ── 6. Sand/wood background — dark brown text (~10:1 contrast) ──
    "Gruvbox Dark": {
        "BG": "#282828", "FG": "#ebdbb2", "ENTRY_BG": "#3c3836",
        "SEL_BG": "#504945", "ACCENT": "#83a598",
        "GREEN": "#b8bb26", "RED": "#fb4934", "ORANGE": "#fe8019", "YELLOW": "#fabd2f",
        "desc": "Retro sand & wood — warm tones, very restful for long sessions",
    },
    # ── 7. Luxury violet background — ivory gold text (~9:1 contrast) ──
    "Hotel Gold": {
        "BG": "#1a1625", "FG": "#e8d5b7", "ENTRY_BG": "#241e35",
        "SEL_BG": "#332846", "ACCENT": "#d4af37",
        "GREEN": "#7ec8a0", "RED": "#e05a5a", "ORANGE": "#e8a87c", "YELLOW": "#f5d76e",
        "desc": "Luxury violet & gold — high-end hospitality theme, elegant and distinctive",
    },
    # ── 8. Navy background — pale sky blue text (~10:1 contrast) ──
    "Ocean Blue": {
        "BG": "#0a192f", "FG": "#ccd6f6", "ENTRY_BG": "#112240",
        "SEL_BG": "#1d3461", "ACCENT": "#64ffda",
        "GREEN": "#64ffda", "RED": "#ff6b6b", "ORANGE": "#ffa726", "YELLOW": "#ffee58",
        "desc": "Navy & cyan — inspired by modern SaaS dashboards",
    },
    # ── 9. Absolute black background — pure white text (21:1 contrast, max accessibility) ──
    "High Contrast": {
        "BG": "#000000", "FG": "#ffffff", "ENTRY_BG": "#111111",
        "SEL_BG": "#222222", "ACCENT": "#00d4ff",
        "GREEN": "#00ff88", "RED": "#ff3333", "ORANGE": "#ff9500", "YELLOW": "#ffe600",
        "desc": "Pure black & white — maximum 21:1 contrast, ideal for accessibility / low vision",
    },
    # ── 10. White background — anthracite text (~16:1 contrast) ──
    "Light Pro": {
        "BG": "#f8f9fa", "FG": "#212529", "ENTRY_BG": "#ffffff",
        "SEL_BG": "#e9ecef", "ACCENT": "#0066cc",
        "GREEN": "#198754", "RED": "#dc3545", "ORANGE": "#fd7e14", "YELLOW": "#7d5a00",
        "desc": "White & professional blue — the only light theme, ideal without dark mode",
    },
}


class _Theme:
    """Singleton object holding the active theme's colors."""
    def __init__(self):
        self._apply(THEMES["Catppuccin Mocha"])

    def _apply(self, t: dict):
        self.BG       = t["BG"]
        self.FG       = t["FG"]
        self.ENTRY_BG = t["ENTRY_BG"]
        self.SEL_BG   = t["SEL_BG"]
        self.ACCENT   = t["ACCENT"]
        self.GREEN    = t["GREEN"]
        self.RED      = t["RED"]
        self.ORANGE   = t["ORANGE"]
        self.YELLOW   = t["YELLOW"]
        self.name     = t.get("desc", "")

    def apply(self, name: str):
        """Change the active theme. All tabs see the change immediately."""
        t = THEMES.get(name, THEMES["Catppuccin Mocha"])
        self._apply(t)
        self.name = name


# Single instance shared by the whole application
T = _Theme()
