"""
Send history — one JSON file per OTA.

WHY THIS MODULE
---------------
To correct an OTA price, we need to know what the OTA did with the LAST price
sent: "I sent 2310, Agoda displayed 1532". Without that trace, no adjustment
is possible — you cannot compare the shipment to the display if you forgot
the shipment.

Before this module, the only trace was `Tab._ota_calib_room_sends`
(tabs/tab_blocage_ota.py) with two flaws:
  1. in memory only → lost when the application closes;
  2. key = room only → Agoda 2100 / Expedia 1650 / MakeMyTrip 1700 for the
     same room overwrote each other.

Here: one file per OTA (data/send_history_<ota_id>.json), same partitioning as
core/calib_store.py — two OTAs cannot collide when writing.

WHAT IS RECORDED AS "SENT"
--------------------------
The price that ACTUALLY went to the Channel Manager FOR THE SCANNED DATE, not
the target price. Between the two there are two transformations that must be
integrated:
  - OTA discount of the rate plan (app_core.py): price / (1 − discount/100);
  - weekend markup per date (scraping/channel_manager.py::weekend_rate_segments):
    × (1 + pct/100) if the scanned day is in `weekend_days`.
Real example: target 2100 ₹, scan on D+1 = Friday, +10 % markup
→ the price really sent for that date is 2310 ₹, not 2100.
Recording 2100 would corrupt any calculation built on top of it.

LIFECYCLE OF A MEASURE
----------------------
A measure is born incomplete and completes at the next scan:

  record_send()        → status="pending"   (sent known, observed unknown)
  record_observation() → status="confirmed" (observed filled in)

Rule decided with the user: an observation only counts if the displayed price
CHANGED compared to `observed_before` (the price displayed at the moment the
send decision was made). While it is identical, the OTA has not yet reflected
the send — OTA updates can take far more than 5 min. The measure is then left
pending instead of recording a fake pair.

RETENTION
---------
No purge: everything is kept, including abandoned measures and simulated
sends (TEST MODE). They are analysis data for later.
Filtering happens at READ time in get_measures() — it decides what is
usable for a calculation (never simulated, optional age window),
without ever deleting anything from the file.
"""
import logging
import time
from datetime import datetime

from core.paths import DATA_DIR

# OTA name normalization: reused from calib_store rather than copied.
# calib_store already warns "keep in sync" with tab_calibration.Tab._name_to_id;
# a THIRD copy would eventually diverge and two modules would file the same
# OTA into two different files.
try:
    from core.calib_store import _normalize_ota_id, _safe_ota_id
except Exception:  # pragma: no cover - calib_store unavailable
    import re

    def _normalize_ota_id(name: str) -> str:
        n = (name or "").lower()
        if "agoda" in n:      return "agoda"
        if "booking" in n:    return "booking"
        if "makemytrip" in n: return "makemytrip"
        if "google" in n:     return "google_hotels"
        return n.replace(" ", "_")

    def _safe_ota_id(ota_id: str) -> str:
        s = re.sub(r"[^a-z0-9_-]+", "_", (ota_id or "").lower()).strip("_")
        return s or "_other"

_PREFIX = "send_history_"

PENDING   = "pending"
CONFIRMED = "confirmed"
ABANDONED = "abandoned"

# Return values of record_observation()
OBS_CONFIRMED  = "confirmed"    # the price moved → measure complete
OBS_UNCHANGED  = "unchanged"    # same as observed_before → OTA not up to date
OBS_NO_PENDING = "no_pending"   # no pending send for this room


def ota_id(ota_name: str) -> str:
    """Displayed OTA name ('Agoda', 'MakeMyTrip'…) → file identifier."""
    return _safe_ota_id(_normalize_ota_id(ota_name))


def _ota_file(oid: str):
    return DATA_DIR / f"{_PREFIX}{oid}.json"


def load(ota_name: str) -> dict:
    """History of ONE OTA: {"measures": {room: [measure, ...]}}."""
    fp = _ota_file(ota_id(ota_name))
    try:
        if fp.exists():
            data = __import__("json").loads(fp.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("measures", {})
                return data
    except Exception:
        logging.exception("send_history: unreadable file — %s", fp)
    return {"measures": {}}


def save(ota_name: str, data: dict) -> bool:
    """Atomic write — never a truncated file if the app is killed."""
    try:
        from business.secrets import atomic_write_json
        atomic_write_json(_ota_file(ota_id(ota_name)), data)
        return True
    except Exception:
        logging.exception("send_history: save failed (%s) — "
                          "history NOT recorded", ota_name)
        return False


def _entries(data: dict, room: str) -> list:
    return data.setdefault("measures", {}).setdefault(room, [])


def record_send(ota_name: str, room: str, *, sent: int, target: int,
                observed_before=None, base_price=None, stay_date: str = "",
                markup_pct: float = 0.0, weekend: bool = False,
                discount_pct: float = 0.0, simulated: bool = False,
                config_room: str = "", device: str = "") -> bool:
    """Records a send, pending the next scan's observation.

    `sent`            : price that ACTUALLY went out for `stay_date` (discount
                        + weekend already applied) — THIS is what feeds the
                        calculations.
    `base_price`      : price before discount/markup, to understand afterwards.
    `observed_before` : price displayed by the OTA at decision time. Acts as a
                        witness: the observation only counts if the price
                        differs from it.
    `simulated`       : True if TEST MODE — nothing actually went out, so the
                        measure must never enter a calculation.

    A send arriving while a measure is already pending marks the latter
    `abandoned`: its observation would no longer make sense, the next send
    changed the situation. It is kept, not deleted.
    """
    if not ota_name or not room:
        return False
    try:
        data = load(ota_name)
        lst  = _entries(data, room)
        for e in lst:
            if e.get("status") == PENDING:
                e["status"] = ABANDONED
                e["abandoned_reason"] = "new send before observation"
        now = time.time()
        lst.append({
            "status":          PENDING,
            "sent":            int(sent),
            "base_price":      int(base_price) if base_price is not None else int(sent),
            "target":          int(target) if target is not None else None,
            "observed_before": int(observed_before) if observed_before else None,
            "observed":        None,
            "stay_date":       stay_date or "",
            "markup_pct":      float(markup_pct or 0.0),
            "weekend":         bool(weekend),
            "discount_pct":    float(discount_pct or 0.0),
            "simulated":       bool(simulated),
            "config_room":     config_room or "",
            "device":          device or "",
            "checks":          0,
            "sent_ts":         now,
            "sent_at":         datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M"),
            "observed_ts":     None,
            "observed_at":     None,
        })
        return save(ota_name, data)
    except Exception:
        logging.exception("send_history: record_send failed (%s / %s)",
                          ota_name, room)
        return False


def record_observation(ota_name: str, room: str, observed) -> str:
    """Completes the pending measure with the price displayed by the OTA.

    Returns:
      OBS_CONFIRMED  → the price changed, the measure is usable
      OBS_UNCHANGED  → same as `observed_before`: the OTA has not yet
                       reflected the send. Nothing is recorded, the `checks`
                       counter is incremented so the caller knows how many
                       times it looked in vain.
      OBS_NO_PENDING → no pending send for this room.
    """
    if not ota_name or not room or not observed:
        return OBS_NO_PENDING
    try:
        observed = int(observed)
        data    = load(ota_name)
        lst     = _entries(data, room)
        pending = next((e for e in reversed(lst)
                        if e.get("status") == PENDING), None)
        if pending is None:
            return OBS_NO_PENDING

        before = pending.get("observed_before")
        if before is not None and observed == int(before):
            pending["checks"] = int(pending.get("checks", 0)) + 1
            pending["last_check_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            save(ota_name, data)
            return OBS_UNCHANGED

        now = time.time()
        pending["observed"]    = observed
        pending["observed_ts"] = now
        pending["observed_at"] = datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M")
        pending["status"]      = CONFIRMED
        save(ota_name, data)
        return OBS_CONFIRMED
    except Exception:
        logging.exception("send_history: record_observation failed (%s / %s)",
                          ota_name, room)
        return OBS_NO_PENDING


def pending(ota_name: str, room: str):
    """Measure pending observation for this room, or None."""
    try:
        lst = load(ota_name).get("measures", {}).get(room, [])
        return next((e for e in reversed(lst)
                     if e.get("status") == PENDING), None)
    except Exception:
        logging.exception("send_history: pending failed (%s / %s)",
                          ota_name, room)
        return None


def get_measures(ota_name: str, room: str, limit=None, max_age_days=None,
                 include_simulated: bool = False, weekend=None,
                 device=None) -> list:
    """COMPLETE and usable measures, from the oldest to the most recent.

    Only returns actually measured (sent, observed) pairs:
      - status confirmed only (neither pending, nor abandoned);
      - simulated sends (TEST MODE) excluded by default: nothing went to the
        Channel Manager, so the OTA could not reflect anything;
      - `max_age_days` drops measures that are too old — the OTA changes
        behavior over time, a week-old measure may describe nothing anymore;
      - `limit` keeps the N most recent.

    Comparability (safety limit):
      - `weekend=True/False` only keeps measures taken on a day of the same
        kind. An OTA can apply a weekend promo different from the weekday
        one; mixing both amounts to fitting a line on two distinct behaviors
        and getting a slope that describes neither.
      - `device` only keeps measures read on the same device. Agoda does not
        display the same price on mobile and desktop.

    The file is never modified: filtering is not deleting.
    """
    try:
        lst = load(ota_name).get("measures", {}).get(room, [])
        out = []
        cutoff = (time.time() - max_age_days * 86400) if max_age_days else None
        for e in lst:
            if e.get("status") != CONFIRMED:
                continue
            if e.get("simulated") and not include_simulated:
                continue
            if not e.get("sent") or not e.get("observed"):
                continue
            if cutoff and float(e.get("observed_ts") or 0) < cutoff:
                continue
            if weekend is not None and bool(e.get("weekend")) != bool(weekend):
                continue
            if device and (e.get("device") or "") != device:
                continue
            out.append(e)
        out.sort(key=lambda e: float(e.get("observed_ts") or 0))
        return out[-limit:] if limit else out
    except Exception:
        logging.exception("send_history: get_measures failed (%s / %s)",
                          ota_name, room)
        return []


def watched_brands(min_checks: int = 1) -> set:
    """D123 — identifiants des OTA ayant au moins un envoi PENDING avec
    `min_checks` scans sans répercution : les marques d'OTA dont la page
    doit être rafraîchie avant que le garde-fou ne compte un strike.
    Lecture seule, jamais d'exception."""
    out = set()
    try:
        from core.paths import DATA_DIR
        for f in DATA_DIR.glob(f"{_PREFIX}*.json"):
            try:
                data = __import__("json").loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            ota = f.stem[len(_PREFIX):]
            for entries in ((data.get("measures") or {}).values()):
                for e in entries or []:
                    if (e or {}).get("status") != "pending":
                        continue
                    try:
                        if int((e or {}).get("checks") or 0) >= min_checks:
                            out.add(ota)
                            break
                    except (TypeError, ValueError):
                        continue
    except Exception:
        pass
    return out


def stalled_checks(ota_name: str, room: str) -> int:
    """How many scans in a row found the displayed price UNCHANGED.

    Counter of the pending measure: each scan that sees exactly the
    pre-send price increments it (see record_observation). A rising counter
    means the Channel Manager did accept the send but the OTA is not
    reflecting it. Sending the same price again would change nothing — and
    worse, would abandon the pending measure, so we would never learn
    anything.

    0 when nothing is pending.
    """
    try:
        return int((pending(ota_name, room) or {}).get("checks", 0) or 0)
    except Exception:
        return 0


def last_sent(ota_name: str, room: str):
    """Last price ACTUALLY sent for this room, measured or not.

    Used when no complete measure exists yet (the OTA has not yet reflected
    the last send): we ignore what it will make of it, but we know at least
    where to start from. Simulated sends (TEST MODE) are excluded — nothing
    went out, the OTA received nothing.
    """
    try:
        for e in reversed(load(ota_name).get("measures", {}).get(room, [])):
            if e.get("simulated"):
                continue
            if e.get("sent"):
                return int(e["sent"])
    except Exception:
        logging.exception("send_history: last_sent failed (%s / %s)",
                          ota_name, room)
    return None


# Minimal (squared) gap between the sent prices for a line to make sense.
# Below it, the points are conflated: the least-squares denominator collapses
# and the resulting slope is pure noise.
_MIN_SPREAD = 1.0

# Minimal slope for a line to be INVERTIBLE. An OTA that barely displays the
# same price whatever the send (Goibibo real case: 3 265→1 888, 5 000→1 868)
# gives a near-zero slope; the inversion (target−b)/a then explodes —
# 18 167 ₹ computed for a 2 000 target. Below this threshold we no longer
# guess: the line is refused.
_MIN_SLOPE = 0.20
_MAX_SLOPE = 3.00

# Maximal extrapolation factors. Even with a healthy slope, a result at 9×
# the target is not a price, it is an artifact: refuse and fall back.
_FACTOR_MIN = 0.40   # sending less than 40 % of the target makes no sense
_FACTOR_MAX = 3.00   # nor more than triple (the OTA keeps at least ~33 % of the price)

# Displayed/sent ratio beyond which the pair is judged aberrant and dropped.
# Safety limit deliberately wide: it targets values that CANNOT come from
# pricing (a price misread on the page, an unconverted currency), not
# aggressive promotions. It therefore does not claim to catch every read
# error — only the ones beyond any doubt.
_RATIO_MIN = 0.10   # the OTA would display less than a tenth of what is sent
_RATIO_MAX = 3.00   # or more than triple (taxes and included fees stay below)

# Age window of the measures used for the proportion (D100). A measure
# describes the PRESENT behavior of the OTA; beyond the window it describes
# another era — different pricing, different price reader, different currency —
# and derails the proportion for nothing (real case: Airbnb ratios polluted by
# cross-reads between listings, Sept 2026). 0 = window disabled.
_RATIO_WINDOW_DAYS = 14.0


def _robust_pts(pts):
    """Drops pairs whose displayed/sent ratio drifts too far from the median
    (≥ 4 points). Targets historical pollution — measures taken during
    attribution bugs (sent 1 300 → displayed 3 500): a single wrong measure
    derails the whole line otherwise. With fewer than 4 points, we cannot
    tell which one is the outlier: we do not filter."""
    if len(pts) < 4:
        return pts, 0
    ratios = sorted(o / s for s, o in pts)
    med = ratios[len(ratios) // 2]
    kept = [(s, o) for s, o in pts
            if med * 0.65 <= o / s <= med * 1.55]
    if len(kept) < 2:
        return pts, 0
    return kept, len(pts) - len(kept)


def predict_sent_for(measures, target, window_days=None):
    """Which price to send so the OTA eventually displays `target`?

    We do NOT try to guess the OTA's internal formula (discount, strike
    price, commission, in-house promo…): it is not published and changes
    without notice. We only look at what is verifiable — the actually
    observed (sent → displayed) pairs — and we invert the observed relation.

      1 measure         → proportion: displayed = k × sent. With a single
                          point we cannot tell a percentage from a fixed
                          amount; the percentage is the common case
                          (commission), so that is what we assume.
      2 measures and up → proportion through the origin (least squares):
                          k = Σ(sent × displayed) / Σ(sent²), hence
                          sent = target / k (D35: an OTA commission is
                          multiplicative — the old affine line and its
                          intercept turned a reachable target into a
                          perpetual resending of the price already in place).

    The proportion is refused if its ratio is null or insane: the OTA no
    longer reacts to sends, or the measures mix incompatible eras. We then
    fall back to the proportion computed on the most recent measure,
    which still aims at the target.

    Returns (price_to_send, method, readable_detail), or (None, reason, "")
    when nothing is usable.
    """
    try:
        target = float(target)
    except (TypeError, ValueError):
        return None, "invalid_target", ""
    if target <= 0:
        return None, "invalid_target", ""

    # Age window (D100): stale measures are rejected first,
    # before any other use — the proportion as well as the fallback on the
    # most recent measure must only speak about the current behavior.
    try:
        _win = float(window_days if window_days is not None
                     else _RATIO_WINDOW_DAYS)
    except (TypeError, ValueError):
        _win = _RATIO_WINDOW_DAYS
    _now = time.time()
    _vieilles, _mes = 0, []
    for m in measures or []:
        try:
            _ts = float(m.get("observed_ts") or m.get("sent_ts") or 0)
        except (TypeError, ValueError):
            _ts = 0.0
        if _ts and _win > 0 and (_now - _ts) > _win * 86400.0:
            _vieilles += 1
            continue
        _mes.append(m)

    pts, ecartes = [], 0
    for m in _mes:
        try:
            _s = float(m.get("sent") or 0)
            _o = float(m.get("observed") or 0)
        except (TypeError, ValueError):
            continue
        if _s <= 0 or _o <= 0:
            continue
        if not (_RATIO_MIN <= _o / _s <= _RATIO_MAX):
            # Impossible pair: price misread on the page, unconverted
            # currency… including it would durably skew the whole line.
            ecartes += 1
            continue
        pts.append((_s, _o))
    pts, _ec_rob = _robust_pts(pts)
    ecartes += _ec_rob
    _notes = []
    if _vieilles:
        _notes.append(f"{_vieilles} measure(s) outside window "
                      f"(>{_win:.0f} d)")
    if ecartes:
        _notes.append(f"{ecartes} outlier measure(s) dropped")
    _note_bare = ", ".join(_notes)
    _note_ec = (" — " + _note_bare) if _notes else ""
    if not pts:
        return None, "no_measure", _note_bare

    # Why the proportion could not be used — carried into the method name so
    # the journal does not pass a fallback off as a full calculation.
    _repli = ""
    if len(pts) >= 2:
        n   = len(pts)
        sxx = sum(s * s for s, _ in pts)
        sxy = sum(s * o for s, o in pts)
        # D35 (27/08): proportion THROUGH THE ORIGIN — no more affine line.
        # The intercept fitted on measures from incompatible eras
        # (≈ 0,88 × sent − 789) turned the 1 400 target into a 2 625 send:
        # a price ALREADY in place, resent with no effect forever
        # (fixed point, "unchanged after 12 scans" counters). An OTA's
        # commission is multiplicative — measured on 27/08 on Agoda:
        # ×0.865 identical across 3 rooms to within 4 decimals —
        # so we fit displayed ≈ k × sent and invert: target / k.
        # A fit through the origin stays stable even when sends repeat
        # (all measures contribute to the same k).
        if sxx <= 0:
            _repli = "sends too close"
        else:
            k = sxy / sxx
            if k < _MIN_SLOPE:
                # The OTA barely reflects the sends: inverting the
                # proportion fabricates absurd prices. Refusal —
                # the caller advances in bounded steps and the
                # "sends suspended" safety limit takes over.
                _repli = "the OTA no longer reacts to changes"
            elif k > _MAX_SLOPE:
                # Absurd upward proportion: the measures mix
                # incompatible eras/behaviors. A real OTA never displays
                # triple what it is sent.
                _repli = "inconsistent proportion (mixed measures)"
            else:
                val = target / k
                if val > 0 and _FACTOR_MIN * target <= val <= _FACTOR_MAX * target:
                    return (int(round(val)), "adjusted proportion",
                            f"{n} measures — displayed ≈ {k:.3f} × sent "
                            f"(the OTA keeps {k * 100:.0f} % of it)" + _note_ec)
                _repli = "target out of the proportion's reach"

    _s, _o = pts[-1]
    if _repli == "the OTA no longer reacts to changes":
        # Display independent of the send: the proportion on the last
        # measure describes nothing (send 4 285 or 2 000 → same display).
        # Refusal: the caller advances in bounded steps toward the target,
        # and the "sends suspended" safety limit eventually takes over.
        return None, _repli, _note_ec.lstrip(" —")
    val = _s * target / _o
    if _FACTOR_MIN * target <= val <= _FACTOR_MAX * target:
        return (int(round(val)),
                "proportion" if not _repli else f"proportion ({_repli})",
                f"last measure {int(_s):,} → {int(_o):,} "
                f"(the OTA keeps {_o / _s * 100:.0f} % of it)" + _note_ec)
    if _repli:
        return None, _repli, _note_ec.lstrip(" —")
    return None, "unusable_measures", _note_ec.lstrip(" —")


def rooms(ota_name: str) -> list:
    """Rooms present in this OTA's history."""
    try:
        return sorted(load(ota_name).get("measures", {}).keys())
    except Exception:
        return []
