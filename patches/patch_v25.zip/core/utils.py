"""
Shared utilities for all menus.
"""
import tkinter as tk
from tkinter import ttk
from core.theme import T


# ── Format prix ──────────────────────────────────────────────────────────────
_CURRENCY_SYMBOL = "₹"
_CURRENCY_RATE   = 1.0

# Currency chosen here = independent of the UI language — a hotel can display
# its prices in any currency, whatever its language.
# Known symbol/name for the most common currencies; rarer currencies fall back
# to their ISO code (never an invented/unverified symbol).
CURRENCY_META = {
    "INR": {"symbol": "₹",   "name": "Indian Rupee"},
    "USD": {"symbol": "$",   "name": "US Dollar"},
    "EUR": {"symbol": "€",   "name": "Euro"},
    "GBP": {"symbol": "£",   "name": "Pound Sterling"},
    "JPY": {"symbol": "¥",   "name": "Japanese Yen"},
    "CNY": {"symbol": "¥",   "name": "Chinese Yuan"},
    "KRW": {"symbol": "₩",   "name": "South Korean Won"},
    "VND": {"symbol": "₫",   "name": "Vietnamese Dong"},
    "THB": {"symbol": "฿",   "name": "Thai Baht"},
    "PHP": {"symbol": "₱",   "name": "Philippine Peso"},
    "RUB": {"symbol": "₽",   "name": "Russian Ruble"},
    "TRY": {"symbol": "₺",   "name": "Turkish Lira"},
    "UAH": {"symbol": "₴",   "name": "Ukrainian Hryvnia"},
    "ILS": {"symbol": "₪",   "name": "Israeli Shekel"},
    "PLN": {"symbol": "zł",  "name": "Polish Zloty"},
    "CZK": {"symbol": "Kč",  "name": "Czech Koruna"},
    "HUF": {"symbol": "Ft",  "name": "Hungarian Forint"},
    "SEK": {"symbol": "kr",  "name": "Swedish Krona"},
    "NOK": {"symbol": "kr",  "name": "Norwegian Krone"},
    "DKK": {"symbol": "kr",  "name": "Danish Krone"},
    "CHF": {"symbol": "CHF", "name": "Swiss Franc"},
    "AUD": {"symbol": "A$",  "name": "Australian Dollar"},
    "NZD": {"symbol": "NZ$", "name": "New Zealand Dollar"},
    "CAD": {"symbol": "C$",  "name": "Canadian Dollar"},
    "HKD": {"symbol": "HK$", "name": "Hong Kong Dollar"},
    "SGD": {"symbol": "S$",  "name": "Singapore Dollar"},
    "TWD": {"symbol": "NT$", "name": "Taiwan Dollar"},
    "MYR": {"symbol": "RM",  "name": "Malaysian Ringgit"},
    "IDR": {"symbol": "Rp",  "name": "Indonesian Rupiah"},
    "PKR": {"symbol": "₨",   "name": "Pakistani Rupee"},
    "BDT": {"symbol": "৳",   "name": "Bangladeshi Taka"},
    "LKR": {"symbol": "₨",   "name": "Sri Lankan Rupee"},
    "NPR": {"symbol": "₨",   "name": "Nepalese Rupee"},
    "LAK": {"symbol": "₭",   "name": "Lao Kip"},
    "KHR": {"symbol": "៛",   "name": "Cambodian Riel"},
    "MMK": {"symbol": "K",   "name": "Myanmar Kyat"},
    "AED": {"symbol": "د.إ", "name": "UAE Dirham"},
    "SAR": {"symbol": "﷼",   "name": "Saudi Riyal"},
    "QAR": {"symbol": "﷼",   "name": "Qatari Riyal"},
    "KWD": {"symbol": "د.ك", "name": "Kuwaiti Dinar"},
    "BHD": {"symbol": "د.ب", "name": "Bahraini Dinar"},
    "OMR": {"symbol": "﷼",   "name": "Omani Rial"},
    "JOD": {"symbol": "د.ا", "name": "Jordanian Dinar"},
    "EGP": {"symbol": "£E",  "name": "Egyptian Pound"},
    "ZAR": {"symbol": "R",   "name": "South African Rand"},
    "NGN": {"symbol": "₦",   "name": "Nigerian Naira"},
    "KES": {"symbol": "KSh", "name": "Kenyan Shilling"},
    "GHS": {"symbol": "₵",   "name": "Ghanaian Cedi"},
    "MAD": {"symbol": "د.م.", "name": "Moroccan Dirham"},
    "DZD": {"symbol": "د.ج", "name": "Algerian Dinar"},
    "TND": {"symbol": "د.ت", "name": "Tunisian Dinar"},
    "BRL": {"symbol": "R$",  "name": "Brazilian Real"},
    "MXN": {"symbol": "$",   "name": "Mexican Peso"},
    "ARS": {"symbol": "$",   "name": "Argentine Peso"},
    "CLP": {"symbol": "$",   "name": "Chilean Peso"},
    "COP": {"symbol": "$",   "name": "Colombian Peso"},
    "PEN": {"symbol": "S/",  "name": "Peruvian Sol"},
    "BGN": {"symbol": "лв",  "name": "Bulgarian Lev"},
    "RON": {"symbol": "lei", "name": "Romanian Leu"},
    "ISK": {"symbol": "kr",  "name": "Icelandic Krona"},
    "GEL": {"symbol": "₾",   "name": "Georgian Lari"},
    "AZN": {"symbol": "₼",   "name": "Azerbaijani Manat"},
    "AMD": {"symbol": "֏",   "name": "Armenian Dram"},
    "KZT": {"symbol": "₸",   "name": "Kazakhstani Tenge"},
    "MNT": {"symbol": "₮",   "name": "Mongolian Tugrik"},
    "XCD": {"symbol": "EC$", "name": "East Caribbean Dollar"},
    "XOF": {"symbol": "CFA", "name": "West African CFA Franc"},
    "XAF": {"symbol": "FCFA","name": "Central African CFA Franc"},
    "XPF": {"symbol": "₣",   "name": "CFP Franc"},
}

def set_currency(code: str, rate: float = 1.0):
    global _CURRENCY_SYMBOL, _CURRENCY_RATE
    _CURRENCY_SYMBOL = CURRENCY_META.get(code, {}).get("symbol", code)
    _CURRENCY_RATE   = rate if rate else 1.0


def fmt_dt(iso: str, with_time: bool = True) -> str:
    """ISO datetime/date → French display "16/08/2026 12:05" or "16/08/2026".

    Accepts "2026-08-16T12:05:33", "2026-08-16 12:05:33", "2026-08-16".
    Returns the input unchanged when it does not look like an ISO date —
    storage keys and parsing never change, only the DISPLAY converts."""
    s = str(iso or "").strip()
    if len(s) >= 10 and s[4] == "-" and s[7] == "-":
        try:
            date_part = f"{s[8:10]}/{s[5:7]}/{s[0:4]}"
            if with_time and len(s) >= 16 and s[10] in " T":
                return f"{date_part} {s[11:16]}"
            return date_part
        except Exception:
            pass
    return s


def parse_dt_any(s: str) -> str:
    """User-entered date → ISO "Y-m-d" for storage/URLs/APIs.

    Accepts the display format "16/08/2026" as well as plain ISO, so the
    d/m/y entry fields keep feeding the ISO-only consumers unchanged.
    Falls back to the input string when neither matches."""
    s = str(s or "").strip()
    if len(s) == 10 and s[2] == "/" and s[5] == "/":
        try:
            return f"{s[6:10]}-{s[3:5]}-{s[0:2]}"
        except Exception:
            pass
    return s


def get_currency_symbol() -> str:
    return _CURRENCY_SYMBOL


# Default rates to INR (fallback when the API is unreachable)
_DEFAULT_INR_RATES = {
    "₹": 1, "₨": 1, "INR": 1, "Rs": 1, "Rs.": 1,
    "$": 96, "USD": 96,
    "€": 107, "EUR": 107,
    "£": 122, "GBP": 122,
    "NPR": 0.72,
    "AED": 26,
    "SGD": 72, "AUD": 63, "CAD": 71,
    "HKD": 12, "MYR": 22, "THB": 2.7,
    "₭": 0.0046, "LAK": 0.0046,   # Lao Kip (1 INR ≈ 217 LAK)
}

# In-memory cache (avoids repeating the request on every call)
_live_rates_cache: dict = {}
_live_rates_ts: float   = 0.0
_CACHE_TTL_SECONDS       = 86400   # 24 hours


def _fetch_live_rates() -> dict:
    """Fetch live exchange rates from open.er-api.com (free, no key).
    Returns {code: rate_to_INR} or {} when offline.
    Disk cache in data/fx_cache.json (24h).
    """
    import time, json, urllib.request, urllib.error, logging
    from core.paths import DATA_DIR

    cache_file = DATA_DIR / "fx_cache.json"

    # ── Read the disk cache if still valid ───────────────────────────────
    try:
        if cache_file.exists():
            data = json.loads(cache_file.read_text(encoding="utf-8"))
            age  = time.time() - data.get("ts", 0)
            if age < _CACHE_TTL_SECONDS and data.get("rates"):
                return data["rates"]
    except Exception:
        pass

    # ── API call: open.er-api.com — rates from USD ────────────────────────
    # Response example: {"rates": {"INR": 83.5, "EUR": 0.92, ...}}
    try:
        url = "https://open.er-api.com/v6/latest/USD"
        req = urllib.request.Request(url, headers={"User-Agent": "OTAGuard/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            payload = json.loads(resp.read().decode("utf-8"))

        usd_rates = payload.get("rates", {})   # {code: value from 1 USD}
        inr_per_usd = float(usd_rates.get("INR", 84))

        # Convert: rate_to_INR = INR_per_USD / other_per_USD
        live = {}
        for code, rate_from_usd in usd_rates.items():
            try:
                if float(rate_from_usd) > 0:
                    live[code.upper()] = round(inr_per_usd / float(rate_from_usd), 4)
            except Exception:
                pass

        # Add common symbols
        sym_map = {"USD": "$", "EUR": "€", "GBP": "£", "INR": "₹", "LAK": "₭"}
        for code, sym in sym_map.items():
            if code in live:
                live[sym] = live[code]
        live.update({"₹": 1, "₨": 1, "INR": 1, "Rs": 1, "Rs.": 1})

        # Save disk cache
        try:
            cache_file.parent.mkdir(exist_ok=True)
            cache_file.write_text(
                json.dumps({"ts": time.time(), "rates": live}, ensure_ascii=False),
                encoding="utf-8")
        except Exception:
            pass

        logging.getLogger(__name__).info(
            "[FX] Live rates fetched (USD/INR=%.2f, EUR/INR=%.2f)",
            live.get("USD", 84), live.get("EUR", 91))
        return live

    except urllib.error.URLError:
        logging.getLogger(__name__).debug("[FX] Offline — default rates used")
    except Exception as e:
        logging.getLogger(__name__).debug("[FX] API error: %s", e)

    return {}


def refresh_fx_rates():
    """Force a reload of the rates from the API (called at app startup)."""
    global _live_rates_cache, _live_rates_ts
    import time
    live = _fetch_live_rates()
    if live:
        _live_rates_cache = live
        _live_rates_ts    = time.time()


def get_inr_rates(config: dict = None) -> dict:
    """Returns {symbol/code: rate_to_INR}.

    Priority:
      1. config['currency_rates']  — rates entered manually by the user
      2. Live cache (open API, refreshed every 24h)
      3. Hardcoded default rates (offline fallback)
    """
    global _live_rates_cache, _live_rates_ts
    import time

    # Load the live cache if not done yet or expired
    if not _live_rates_cache or (time.time() - _live_rates_ts) > _CACHE_TTL_SECONDS:
        live = _fetch_live_rates()
        if live:
            _live_rates_cache = live
            _live_rates_ts    = time.time()

    # Base: live > defaults
    rates = dict(_DEFAULT_INR_RATES)
    rates.update(_live_rates_cache)

    # Override: user config (absolute priority)
    if config:
        for code, val in config.get("currency_rates", {}).items():
            try:
                rates[code.upper()] = float(val)
                rates[code]         = float(val)
            except (ValueError, TypeError):
                pass

    return rates


def get_rate(config: dict, from_cur: str, to_cur: str) -> float:
    """Multiplicative rate to convert an amount from from_cur to to_cur.

    Goes through the rates to INR (get_inr_rates) as a common pivot — same
    principle as the source_currency → hotel_currency conversion already
    used by the calibration wizard. Identity (1.0) when both currencies are
    the same or missing from the rate table.
    """
    from_cur = (from_cur or "INR").upper()
    to_cur   = (to_cur or "INR").upper()
    if from_cur == to_cur:
        return 1.0
    rates     = get_inr_rates(config)
    from_rate = rates.get(from_cur, 1.0) or 1.0
    to_rate   = rates.get(to_cur, 1.0) or 1.0
    return from_rate / to_rate


def get_all_currencies(config: dict = None) -> dict:
    """Returns {code: {"symbol":.., "name":..}} for all currencies available
    at market rate (live when online, offline fallback otherwise).

    Independent of the UI language: the user picks the currency they want,
    with no link to the country associated with the chosen language.
    """
    rates = get_inr_rates(config)
    codes = sorted(c for c in rates if len(c) == 3 and c.isalpha() and c.isupper())
    out = {}
    for code in codes:
        meta = CURRENCY_META.get(code, {})
        out[code] = {"symbol": meta.get("symbol", code), "name": meta.get("name", code)}
    return out


def rates_to_prompt_str(config: dict = None) -> str:
    """Readable string for AI prompts: 'USD×83.5, EUR×90.2, ...'"""
    r = get_inr_rates(config)
    pairs = [("USD", "$"), ("EUR", "€"), ("GBP", "£"),
             ("AED", None), ("SGD", None), ("AUD", None)]
    parts = []
    for code, sym in pairs:
        rate = r.get(code)
        if rate and rate != 1:
            label = f"{code}/{sym}" if sym else code
            v     = round(rate, 1)
            parts.append(f"{label}×{int(v) if v == int(v) else v}")
    return ", ".join(parts)


def scannable_room_types(config: dict) -> list:
    """Rooms to query during a scan or a calibration.

    = room_types, minus rooms marked "CM test only"
    (room_types_test_only) — e.g. a virtual room created to test the
    Channel Manager, absent from the real OTA pages. Central function: every
    scan or calibration engine, whatever the OTA (present or future), must go
    through this rather than read room_types directly, to guarantee the same
    rule everywhere.
    """
    excluded = set(config.get("room_types_test_only", []) or [])
    names = []
    for rt in config.get("room_types", []) or []:
        name = rt if isinstance(rt, str) else rt.get("type", rt.get("name", ""))
        if name and name not in excluded:
            names.append(name)
    return names

# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Voluntarily kept; do not rely on it without rewiring and testing it first.
def fmt_price(v, suffix="") -> str:
    try:
        v = float(v) * _CURRENCY_RATE
        return f"{v:,.0f} {_CURRENCY_SYMBOL}{suffix}"
    except Exception:
        return str(v)


# ── Treeview heading tooltips ────────────────────────────────────────────────
# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Voluntarily kept; do not rely on it without rewiring and testing it first.
def bind_heading_tooltips(tree, col_names, tips):
    """Shows a tooltip when hovering over column headings."""
    _win  = [None]
    _job  = [None]
    _last = [None]

    def _cancel():
        if _job[0]:
            try: tree.after_cancel(_job[0])
            except Exception: pass
            _job[0] = None
        if _win[0]:
            try: _win[0].destroy()
            except Exception: pass
            _win[0] = None

    def _show(text, rx, ry):
        _cancel()
        tw = tk.Toplevel(tree)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{rx+12}+{ry+20}")
        tw.attributes("-topmost", True)
        tk.Label(tw, text=text, bg="#2a2a3e", fg=T.FG,
                 font=("Segoe UI", 9), justify="left",
                 padx=10, pady=6, wraplength=340).pack()
        _win[0] = tw

    def on_motion(e):
        region = tree.identify_region(e.x, e.y)
        if region != "heading":
            _cancel(); _last[0] = None; return
        col_idx = int(tree.identify_column(e.x).replace("#", "")) - 1
        if col_idx < 0 or col_idx >= len(col_names):
            _cancel(); return
        col_name = col_names[col_idx]
        if col_name == _last[0]: return
        _cancel(); _last[0] = col_name
        text = tips.get(col_name, "")
        if text:
            rx, ry = e.x_root, e.y_root
            _job[0] = tree.after(1800, lambda: _show(text, rx, ry))

    tree.bind("<Motion>", on_motion, add="+")
    tree.bind("<Leave>", lambda e: (_cancel(), _last.__setitem__(0, None)), add="+")


# ── Date injection into OTA URLs ─────────────────────────────────────────────
def inject_scan_dates(url: str, days_ahead: int = 1) -> str:
    """Force check-in/check-out dates into an OTA URL — whatever the OTA.

    days_ahead = 1 → tomorrow (recommended default).
    Generic and non-destructive: any URL (not only Agoda/Booking/MakeMyTrip/
    Google — any OTA the user adds themselves in "OTA price blocking")
    receives the two most widespread date parameter formats (checkin/checkout
    AND check_in/check_out), added when missing or replaced when already
    present. The rest of the URL (session tokens, unknown query params) is
    untouched — best-effort: nothing guarantees the target site honors these
    parameters if its own format differs, but the URL always stays valid and
    points to the same page.
    """
    from datetime import datetime, timedelta
    from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
    try:
        cin_dt  = datetime.now() + timedelta(days=days_ahead)
        cout_dt = datetime.now() + timedelta(days=days_ahead + 1)
        cin, cout = cin_dt.strftime("%Y-%m-%d"), cout_dt.strftime("%Y-%m-%d")

        # MakeMyTrip uses a compact MMDDYYYY format (no dashes)
        if "makemytrip" in url.lower():
            cin, cout = cin_dt.strftime("%m%d%Y"), cout_dt.strftime("%m%d%Y")

        parts = urlsplit(url)
        drop_keys = {"checkin", "checkout", "check_in", "check_out"}
        query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
                 if k.lower() not in drop_keys]
        query += [("checkin", cin), ("checkout", cout),
                  ("check_in", cin), ("check_out", cout)]
        url = urlunsplit((parts.scheme, parts.netloc, parts.path,
                           urlencode(query), parts.fragment))
    except Exception:
        pass
    return url


# ── Treeview sorting ─────────────────────────────────────────────────────────
def attach_sort(tv: ttk.Treeview):
    """Column sorting on a Treeview — 3 states per column: natural → ▲ → ▼ → natural.

    Returns a reset() callable to run after each table reload to capture the
    new natural order and clear the sort indicator.
    """
    # Original heading texts (without indicator)
    _orig = {col: tv.heading(col, "text") for col in tv["columns"]}

    # Current state
    _state = {"col": None, "rev": False}   # col=None → natural order active
    _natural = {"ids": []}                  # insertion order (= hotel order)

    def _capture():
        _natural["ids"] = list(tv.get_children(""))

    def _sort_key(val: str):
        """Numeric key when possible, text otherwise — strips ₹, $, emojis."""
        clean = val
        for ch in ("₹", "$", "€", "£", ",", "✓", "—",
                   "🔴", "🟢", "🔵", "⚪", "⚠", "▲", "▼"):
            clean = clean.replace(ch, "")
        clean = clean.strip()
        try:
            return (0, float(clean))
        except ValueError:
            return (1, clean.lower())

    def _click(col):
        prev_col = _state["col"]
        prev_rev = _state["rev"]

        # Clear the previous column indicator
        if prev_col and prev_col != col:
            tv.heading(prev_col, text=_orig[prev_col])

        if prev_col != col:
            # First click on this column → ascending ▲
            new_rev = False
        elif not prev_rev:
            # Was ascending → descending ▼
            new_rev = True
        else:
            # Was descending → back to natural order
            _state["col"] = None
            _state["rev"] = False
            tv.heading(col, text=_orig[col])
            for i, k in enumerate(_natural["ids"]):
                try:
                    tv.move(k, "", i)
                except tk.TclError:
                    pass
            return

        # Sort
        data = [(tv.set(k, col), k) for k in tv.get_children("")]
        data.sort(key=lambda t: _sort_key(t[0]), reverse=new_rev)
        for i, (_, k) in enumerate(data):
            tv.move(k, "", i)

        _state["col"] = col
        _state["rev"] = new_rev
        indicator = " ▼" if new_rev else " ▲"
        tv.heading(col, text=_orig[col] + indicator)

    def reset():
        """Resets sorting and captures the current natural order (run after delete+insert)."""
        if _state["col"]:
            tv.heading(_state["col"], text=_orig.get(_state["col"], _state["col"]))
        _state["col"] = None
        _state["rev"] = False
        _capture()

    # Wire the clicks on each column
    for col in tv["columns"]:
        tv.heading(col, command=lambda c=col: _click(c))

    # Capture the initial order (may be empty if the table is not populated yet)
    _capture()
    return reset


# ── Tooltip ───────────────────────────────────────────────────────────────────
def tooltip(widget, text):
    tip = [None]
    def show(e):
        x = widget.winfo_rootx() + 20
        y = widget.winfo_rooty() + widget.winfo_height() + 4
        tip[0] = tk.Toplevel(widget)
        tip[0].wm_overrideredirect(True)
        tip[0].wm_geometry(f"+{x}+{y}")
        tk.Label(tip[0], text=text, bg="#2a2a3e", fg=T.FG,
                 font=("Segoe UI", 8), relief="flat", padx=6, pady=3).pack()
    def hide(e):
        if tip[0]:
            tip[0].destroy()
            tip[0] = None
    widget.bind("<Enter>", show)
    widget.bind("<Leave>", hide)


# ── Translation ───────────────────────────────────────────────────────────────
def tr_(text: str) -> str:
    try:
        from lang import t as _t
        return _t(text)
    except Exception:
        return text


# ── Adaptive price-correction formula ────────────────────────────────────────
#  Replaces the single fixed formula with one that adapts to what the scan
#  actually managed to read from the OTA (the "sheet" filled in by the scan).
#
#  Target  = final price displayed to the client, the one the hotelier wants.
#  Result  = price to send to the Channel Manager to get close to it.
#
#     Case A  Final price only        last_pushed × (target ÷ observed final)
#     Case B  Final + % discount      target ÷ (1 − discount)
#     Case C  Final + strike price    target × (strike ÷ final)
#     Case D  Final + strike + %      target ÷ (1 − discount) + consistency check
#     Taxes  cross-cutting: always normalize back to the price actually paid
#            before any comparison (an OTA displaying pre-tax prices breaks
#            everything).
#     Loyalty: detected, NEVER in the calculation.
#
#  No min/max bounds here: bounding and alerts are applied by the caller
#  (step 5), after this calculation.

# Tax mentions — the exclusion is tested FIRST ("taxes incluses" contains
# "incl", but "hors taxes" does not contain "incl"). Keywords below mirror
# what OTA pages actually display (kept verbatim, French included).
_TAXES_EXCLUES = (
    "hors taxe", "hors taxes", "+ taxes", "plus taxes", "excl", "exclu",
    "non incluse", "non inclus", "en sus", "avant taxe", "additional tax",
    "taxes extra", "excluding",
)
_TAXES_INCLUSES = (
    "taxes incluses", "taxes inclus", "tout compris", "toutes taxes",
    "incl", "inclus", "included", "including",
)


def normaliser_taxes(fiche):
    """Price actually paid by the client → (amount, mention).

    mention: "TTC" (taxes already in the price), "HT" (taxes on top, they are
    added) or "inconnu" (no mention read → price taken as is).
    """
    _final = (fiche or {}).get("final") or 0
    if not _final:
        return 0, "inconnu"
    _txt = ((fiche or {}).get("tax_text") or "").lower()
    _tax = (fiche or {}).get("tax_incl") or 0
    if _txt:
        for _m in _TAXES_EXCLUES:
            if _m in _txt:
                return int(round(_final + _tax)), "HT"
        for _m in _TAXES_INCLUSES:
            if _m in _txt:
                return int(_final), "TTC"
    return int(_final), "inconnu"


def calculer_prix_a_pousser(cible, fiche=None, dernier_pousse=0, ecart_max=0.05):
    """Picks the formula based on what the scan managed to read, and computes the price.

    Returns a dict:
        prix      : price to send to the CM (int) or None = send nothing
        cas       : "A", "B", "C", "D", or "—" (no sheet → original
                    behavior: the target is sent as is)
        alertes   : list of messages (detected anomalies)
        taxes     : "TTC" / "HT" / "inconnu"
        fidelite  : True if a loyalty discount was detected on the offer
        final     : observed final price, tax-normalized
        fiabilite : "maximale" / "bonne" / "moyenne" / "faible" / "—"
    """
    _out = {"prix": None, "cas": "—", "alertes": [], "taxes": "inconnu",
            "fidelite": False, "final": 0, "fiabilite": "—"}
    try:
        cible = int(cible or 0)
    except (TypeError, ValueError):
        cible = 0
    if cible <= 0:
        _out["alertes"].append("target price missing — no calculation possible")
        return _out

    # No sheet (calibration missing, or scan silent on the
    # details) → we guess nothing: original behavior, the target is sent.
    if not fiche:
        _out["prix"] = cible
        return _out

    _final, _tx = normaliser_taxes(fiche)
    _out["taxes"] = _tx
    _out["final"] = _final
    _out["fidelite"] = bool(fiche.get("loyalty"))
    if _tx == "HT":
        _out["alertes"].append(
            "displayed price excludes taxes — comparison done on the paid price")

    if _final <= 0:
        _out["alertes"].append(
            "displayed price missing or zero — no correction sent")
        return _out

    _remise = fiche.get("discount")
    try:
        _remise = float(_remise) if _remise is not None else None
    except (TypeError, ValueError):
        _remise = None
    _barre = fiche.get("strike") or 0
    try:
        _barre = int(_barre)
    except (TypeError, ValueError):
        _barre = 0

    def _cas_a(_note=None):
        """Common fallback: only the observed final price is available."""
        _out["cas"] = "A"
        _out["fiabilite"] = "faible"
        if _note:
            _out["alertes"].append(_note)
        if _out["fidelite"]:
            # The price may be low only because of a loyalty discount
            # voluntarily enabled by the hotelier. Without any other element
            # to explain it, we do not correct.
            _out["prix"] = None
            _out["alertes"].append(
                "loyalty discount detected with no other element — price left as is")
            return _out
        if not dernier_pousse:
            # First scan: no history to measure the gap.
            _out["prix"] = cible
            _out["alertes"].append("first scan — target sent, "
                                   "adjustment will happen on later scans")
            return _out
        # Direct send of the target — the old proportional formula
        # (dernier_pousse × cible/final) could drift far from the target
        # if dernier_pousse was stale (e.g. Double Room with Balcony
        # sent at 2812 instead of 2500 on 2026-07-27).
        _out["prix"] = cible
        return _out

    _a_remise = _remise is not None
    _a_barre  = _barre > 0

    # ── Case D: final + strike + % ────────────────────────────────────────
    if _a_remise and _a_barre:
        if not (0 < _remise < 100):
            return _cas_a(f"inconsistent discount ({_remise} %) — ignored")
        if _barre < _final:
            return _cas_a(f"strike price ({_barre}) lower than final price "
                          f"({_final}) — strike ignored")
        _out["cas"] = "D"
        _out["fiabilite"] = "maximale"
        _attendu = _barre * (1 - _remise / 100.0)
        if _attendu and abs(_attendu - _final) / _final > ecart_max:
            _out["alertes"].append(
                f"OTA inconsistency: strike {_barre} − {_remise} % would give "
                f"{int(round(_attendu))}, but {_final} is displayed")
        _out["prix"] = int(round(cible / (1 - _remise / 100.0)))
        return _out

    # ── Case B: final + % ─────────────────────────────────────────────────
    if _a_remise:
        if _remise == 0:
            _out["cas"] = "B"
            _out["fiabilite"] = "bonne"
            _out["prix"] = cible
            return _out
        if not (0 < _remise < 100):
            return _cas_a(f"absurd discount ({_remise} %) — fallback formula used")
        _out["cas"] = "B"
        _out["fiabilite"] = "bonne"
        _out["prix"] = int(round(cible / (1 - _remise / 100.0)))
        return _out

    # ── Case C: final + strike ────────────────────────────────────────────
    if _a_barre:
        if _barre == _final:
            _out["cas"] = "C"
            _out["fiabilite"] = "moyenne"
            _out["prix"] = cible
            return _out
        if _barre < _final:
            return _cas_a(f"strike price ({_barre}) lower than final price "
                          f"({_final}) — inconsistent, strike ignored")
        _out["cas"] = "C"
        _out["fiabilite"] = "moyenne"
        _out["prix"] = int(round(cible * (_barre / float(_final))))
        return _out

    # ── Case A: final only ────────────────────────────────────────────────
    return _cas_a()


# ══════════════════════════════════════════════════════════════════════════
#  EFFICIENCY BAR — score and advice calculation
# ══════════════════════════════════════════════════════════════════════════
#  Translates the raw status survey of a scan (see _run_4eng / _health_out)
#  into a score out of 100 per OTA, a global average, and concrete advice when
#  something is wrong. PURE function: no disk read, no network, no side
#  effect — it receives everything it needs as parameters, which makes it
#  testable outside the application.
#
#  Vocabulary deliberately outcome-oriented ("survey", "reading",
#  "detection"): the display must never expose the scan's internal details.

_EFF_SEUIL_VERT   = 75   # ≥: all good, the OTA is not displayed
_EFF_SEUIL_ORANGE = 50   # ≥: watch it; below: red
_EFF_CALIB_VIEILLE = 120  # days beyond which a verification is advised


def ota_profile_key(ota, hotel=""):
    """Key of an OTA's calibration profile, derived from ITS NAME.

    The Calibration menu always writes its profiles under "hotel||identifier",
    where the identifier comes from the NAME displayed in the OTA list
    (`Tab._name_to_id`, copied verbatim into
    `core.calib_store._normalize_ota_id`). So this is THE rule that governs,
    and it alone: the name is what the user reads on screen, it cannot
    designate another site.

    ⚠ NEVER recover a profile from the identifier derived from the address
    (`source_id`). Observed on 2026-07-31: Expedia was surveyed with
    `source_id = "booking"`, which made it load Booking's calibration profile
    (one month old, unrelated prices). Result: all its rates judged "very
    different from usual" and a permanent red alert on an OTA that worked.
    An address-identifier error must never be able to designate the profile
    of ANOTHER OTA.
    """
    try:
        from core.calib_store import _normalize_ota_id
        oid = _normalize_ota_id(ota or "")
    except Exception:
        oid = (ota or "").lower().replace(" ", "_")
    if not oid:
        return ""
    return f"{hotel}||{oid}" if hotel else oid


def _eff_profil(profils, ota, source_id="", hotel=""):
    """Calibration profile of THIS OTA — and of no other.

    `source_id` is no longer used for the lookup (see `ota_profile_key`);
    the argument is kept so existing calls do not break.

    No profile found → empty dict, i.e. "never calibrated".
    This is deliberately the result when in doubt: the displayed advice will
    be "calibrate this OTA", which is risk-free and self-corrects at the very
    next calibration.
    """
    if not profils:
        return {}
    for _k in (ota_profile_key(ota, hotel),      # key written by the calibration
               ota_profile_key(ota),             # old format, without the hotel
               ota):                             # old format, raw name
        if _k and _k in profils:
            return profils.get(_k) or {}
    return {}


def _eff_age_jours(txt):
    """Age in days of a "YYYY-MM-DD…" date. None when unreadable/missing."""
    if not txt:
        return None
    try:
        from datetime import datetime as _dt
        return (_dt.now() - _dt.strptime(str(txt)[:10], "%Y-%m-%d")).days
    except Exception:
        return None


def _eff_date(txt):
    """Date/time of an app timestamp. None when missing or unreadable.

    Two formats coexist: "YYYY-MM-DD HH:MM:SS" (calibrated_at) and
    "YYYY-MM-DD HH:MM" (survey). Comparing them as text would work here,
    but would break at the first different format, without any message.
    """
    from datetime import datetime as _dt
    _s = str(txt or "").strip()
    for _n, _f in ((19, "%Y-%m-%d %H:%M:%S"), (16, "%Y-%m-%d %H:%M"),
                   (10, "%Y-%m-%d")):
        if len(_s) >= _n:
            try:
                return _dt.strptime(_s[:_n], _f)
            except ValueError:
                continue
    return None


def calculer_efficacite(sante, profils=None, hotel=""):
    """Global efficiency score + detail of the problematic OTAs.

    sante   : {ota_name: survey}   (ota_watch["last_health"])
    profils : calibration profiles (core.calib_store.load_calib_data() → "profiles")
    hotel   : hotel name, to find the right calibration key

    Return: {"score": int|None, "lignes": [...]}
      score  = average of the OTA scores (None when no exploitable survey remains)
      lignes = only the NON-green OTAs, lowest first:
               {"ota", "score", "couleur", "conseil", "cible"}
               couleur = "rouge" | "orange" | "info"
               cible = "calibration" | "antidetection" | "" (menu to open)

    "info" = OTA recalibrated after the survey: the complaint no longer holds,
    but nothing yet proves it is fixed. These lines do not count in the score
    and open no menu.
    """
    sante = sante or {}
    scores, lignes = [], []

    for _ota, _h in sante.items():
        if not isinstance(_h, dict):
            continue
        _rooms    = int(_h.get("rooms", 0) or 0)
        _attendu  = int(_h.get("expected", 0) or 0)
        _srcmax   = int(_h.get("sources_max", 0) or 0)
        _bloque   = bool(_h.get("blocked"))
        _f_rooms  = int(_h.get("fiche_rooms", 0) or 0)
        _f_det    = int(_h.get("fiche_details", 0) or 0)
        _rejetes  = int(_h.get("learned_dropped", 0) or 0)

        _prof     = _eff_profil(profils, _ota, _h.get("source_id", ""), hotel)
        _sels     = (_prof.get("manual_field_selectors") or {}) if _prof else {}
        _a_calib  = bool(_prof)
        _age      = _eff_age_jours(_prof.get("calibrated_at")) if _prof else None

        _score, _conseil, _cible = 100, "", ""

        if _rooms == 0:
            # Nothing at all: the most serious case, it takes priority over the rest.
            _score = 0
            if _bloque:
                _conseil = tr_("No price recorded and access refused by the site — activate anti-detection on this OTA.")
                _cible   = "antidetection"
            elif not _a_calib:
                _conseil = tr_("No rates recorded — this OTA has never been calibrated.")
                _cible   = "calibration"
            else:
                _conseil = tr_("No rates noted — redo the calibration on this OTA.")
                _cible   = "calibration"
        else:
            # Base = share of what this OTA USUALLY displays (reference
            # observed by the calibration, not the app's room list: a room
            # the OTA does not sell is not a shortage). No known reference →
            # criterion ignored; the score then only depends on the quality
            # of the survey.
            if _attendu:
                _score = int(round(100.0 * min(_rooms, _attendu) / _attendu))
            # Then the observed weaknesses. Penalties ≥ 30 push an otherwise
            # complete OTA below green, i.e. get it displayed.
            if _rejetes:
                _score -= 30
            if _bloque:
                _score -= 30
            if not _a_calib:
                _score -= 30
            elif _f_rooms == 0 and _sels:
                _score -= 35
            elif _f_det == 0 and (_sels.get("strike") or _sels.get("discount")):
                _score -= 30
            # Minor signals: alone, they are not enough to alert.
            if _srcmax <= 1:
                _score -= 20
            if _age is not None and _age > _EFF_CALIB_VIEILLE:
                _score -= 15
            _score = max(0, min(100, _score))

            # Advice: the first problem that best explains the score.
            if _rejetes:
                _conseil = tr_("Prices noted very different from usual — this OTA has probably changed its site, recalibrate it.")
                _cible   = "calibration"
            elif _attendu and _rooms < _attendu:
                _conseil = tr_("Usually {t} rate(s) recorded on this OTA, only {n} this time — redo the calibration on this OTA.").format(
                                   t=_attendu, n=_rooms)
                _cible   = "calibration"
            elif _bloque:
                _conseil = tr_("Site denied access during survey — enable antidetection on this OTA.")
                _cible   = "antidetection"
            elif not _a_calib:
                _conseil = tr_("This OTA has never been calibrated — the prices recorded are not reliable.")
                _cible   = "calibration"
            elif _f_rooms == 0 and _sels:
                _conseil = tr_("Prices noted but no details read — redo the calibration on this OTA.")
                _cible   = "calibration"
            elif _f_det == 0 and (_sels.get("strike") or _sels.get("discount")):
                _conseil = tr_("Discounts and crossed out prices are no longer detected — redo the calibration on this OTA.")
                _cible   = "calibration"
            elif _srcmax <= 1:
                _conseil = tr_("Price confirmed only once — fragile result; enabling antidetection may help.")
                _cible   = "antidetection"
            elif _age is not None and _age > _EFF_CALIB_VIEILLE:
                _conseil = tr_("Calibration {n} days old — verification is recommended.").format(n=_age)
                _cible   = "calibration"

        # ── Stale complaint: calibration redone AFTER this survey ────────────
        # The survey then describes a state that no longer exists. Keeping to
        # display "recalibrate this OTA" while the user just did exactly that
        # is the defect reported on 2026-07-31: the bar only moved at the next
        # survey, so the calibration seemed to have no effect.
        #
        # We also do not claim it is fixed — nobody re-measured anything.
        # The OTA simply leaves the calculation and shows a neutral line
        # until the next survey. An already-green OTA is not concerned:
        # recalibrating what worked must change nothing on screen.
        if _score < _EFF_SEUIL_VERT and _a_calib:
            _d_calib  = _eff_date(_prof.get("calibrated_at"))
            _d_releve = _eff_date(_h.get("ts"))
            if _d_calib and _d_releve and _d_calib > _d_releve:
                lignes.append({
                    "ota":     _ota,
                    "score":   _score,
                    "couleur": "info",
                    "conseil": tr_("Recalibrated since last reading — run a reading to verify it's set."),
                    "cible":   "",
                })
                continue

        scores.append(_score)
        if _score < _EFF_SEUIL_VERT:
            lignes.append({
                "ota":     _ota,
                "score":   _score,
                "couleur": "orange" if _score >= _EFF_SEUIL_ORANGE else "rouge",
                "conseil": _conseil or tr_("Incomplete statement on this OTA."),
                "cible":   _cible,
            })

    # Neutral lines come after real problems, whatever their score: they are
    # not complaints, they must not go in front.
    lignes.sort(key=lambda _l: (_l["couleur"] == "info", _l["score"]))
    if not scores:
        # No exploitable survey left (everything was just recalibrated): no
        # score, but the neutral lines remain to be displayed.
        return {"score": None, "lignes": lignes}
    return {"score": int(round(sum(scores) / float(len(scores)))),
            "lignes": lignes}


# ── Check-in / check-out times ───────────────────────────────────────────────
# Input accepted in 24 h OR AM/PM; storage always in "HH:MM" 24 h.
import re as _re


def parse_time_flexible(text):
    """Parse a wall-clock time typed in either 24-hour or AM/PM notation.

    Accepts "14:00", "14h30", "14 h", "2:00 pm", "2pm", "2:30 PM",
    "12 am" -> "00:00", "12 pm" -> "12:00", "24:00" -> "00:00".
    Returns "HH:MM" (24-hour, zero-padded) or None when unparsable.
    """
    if not text:
        return None
    t = str(text).strip().lower()
    t = _re.sub(r"([ap])\.\s*m\.?", lambda _m: _m.group(1) + "m", t)
    t = t.replace(",", ":").replace("h", ":")
    t = _re.sub(r"(?<=\d)\.(?=\d)", ":", t)         # "9.15" -> "9:15"
    t = t.replace(".", " ")
    t = " ".join(t.split())
    t = t.replace(" :", ":").replace(": ", ":")     # "14 h 30" -> "14:30"
    t = t.rstrip(":")                               # "14h" -> "14"
    m = _re.match(r"^(\d{1,2})(?::(\d{1,2}))?\s*([ap]m?)?$", t)
    if not m:
        return None
    hh = int(m.group(1))
    mm = int(m.group(2) or 0)
    ap = _re.sub(r"[\s.]", "", m.group(3)) if m.group(3) else ""
    if mm > 59:
        return None
    if ap in ("am", "a"):
        if hh == 12:
            hh = 0
        if hh > 12:
            return None
    elif ap in ("pm", "p"):
        if hh == 12:
            pass
        elif hh < 13:
            hh += 12
        else:
            return None
    elif ap == "":
        if hh == 24 and mm == 0:
            hh = 0
        if hh > 23:
            return None
    else:
        return None
    return "{:02d}:{:02d}".format(hh, mm)
