"""
OTA Guard Wizard — Full guided configuration.
Structure identical to the source software: WizardBase + MasterWizard.
Progress saved automatically, resumable at any time.
"""
import json
import logging
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from datetime import datetime
try:
    from core.utils import tr_, parse_time_flexible
    from core.widgets import tooltip
except Exception:
    def tr_(text, *args, **kwargs): return text

    def parse_time_flexible(text):
        return None

    def tooltip(widget, text):
        return widget

BASE_DIR             = Path(__file__).parent
from core.paths import DATA_DIR
WIZARD_PROGRESS_FILE = DATA_DIR / "wizard_progress.json"

# ── Colors (same as the Catppuccin Mocha theme) ───────────────────────────────
BG       = "#1e1e2e"
FG       = "#cdd6f4"
ENTRY_BG = "#313244"
SEL_BG   = "#45475a"
ACCENT   = "#89b4fa"
GREEN    = "#a6e3a1"
RED      = "#f38ba8"
ORANGE   = "#fab387"
YELLOW   = "#f9e2af"

_SECRET_HINTS = ("password", "token", "secret", "api_key", "apikey",
                 "access_token", "bearer")

# Channel Manager types — brand names (not translated) + "API custom"
# (the only value that is a stored phrase, saved as-is in the config
# "channel_manager"."type").
CM_TYPES_KEYS = ["SiteMinder", "Cloudbeds", "STAAH", "RateGain", "eZee",
                 "MyAllocator", "WuBook", "AxisRooms", "channelmanager.com.au", "API custom"]

def _cm_type_display(key):
    """Text displayed in the Combobox — translated to the active language."""
    return tr_("API custom") if key == "API custom" else key

def _cm_type_from_display(display):
    """Recovers the canonical key from the displayed text (translated or not)."""
    return "API custom" if display == tr_("API custom") else display


def _center_window(win, w=960, h=660, max_w_pct=0.90, max_h_pct=0.85):
    """Center the window on the screen. Shrinks it if the screen is too small."""
    win.update_idletasks()
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()
    # Cap to a max percentage of the screen
    w = min(w, int(sw * max_w_pct))
    h = min(h, int(sh * max_h_pct))
    # Exact centering
    x = (sw - w) // 2
    y = (sh - h) // 2
    win.geometry(f"{w}x{h}+{x}+{y}")


def _scrub_secrets(obj):
    if isinstance(obj, dict):
        return {k: _scrub_secrets(v) for k, v in obj.items()
                if not any(h in str(k).lower() for h in _SECRET_HINTS)}
    if isinstance(obj, list):
        return [_scrub_secrets(x) for x in obj]
    return obj


def _save_progress(data):
    try:
        WIZARD_PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(WIZARD_PROGRESS_FILE, "w", encoding="utf-8") as f:
            json.dump(_scrub_secrets(data), f, ensure_ascii=False, indent=2)
    except Exception:
        logging.exception("Failed to save wizard_progress.json")


def _load_progress():
    try:
        with open(WIZARD_PROGRESS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ══════════════════════════════════════════════════════════════════════════════
# BASE WIZARD — Structure identical to the source software
# ══════════════════════════════════════════════════════════════════════════════

class WizardBase(tk.Toplevel):
    WIZARD_KEY = "base"
    STEPS      = []

    def __init__(self, parent, title="Configuration assistant"):
        super().__init__(parent)
        # Toplevel.title() is not covered by the global patch of main.py
        # (it only intercepts text=/label=) — manual translation here.
        self.title(tr_(title))
        self.configure(bg=BG)
        self.resizable(True, True)
        self.grab_set()

        self._progress = _load_progress()
        self._wiz_data = self._progress.get(self.WIZARD_KEY, {})
        self._step     = self._wiz_data.get("_step", 0)

        self._build_ui()
        self._show_step(self._step)
        # Centering AFTER the content is fully rendered
        self.after(0, lambda: _center_window(self, w=940, h=640))
        # Intercept the close button to persist the entries
        self.protocol("WM_DELETE_WINDOW", self._save_and_quit)

    def _build_ui(self):
        header = tk.Frame(self, bg=ACCENT, pady=10, padx=20)
        header.pack(fill="x")
        tk.Label(header, text=self.title(), bg=ACCENT, fg=BG,
                 font=("Segoe UI", 13, "bold")).pack(side="left")

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)

        self._stepper_frame = tk.Frame(body, bg=SEL_BG, width=220)
        self._stepper_frame.pack(side="left", fill="y")
        self._stepper_frame.pack_propagate(False)

        self._content_frame = tk.Frame(body, bg=BG)
        self._content_frame.pack(side="left", fill="both", expand=True)

        nav = tk.Frame(self, bg=SEL_BG, pady=10, padx=20)
        nav.pack(fill="x", side="bottom")

        self._btn_prev = tk.Button(
            nav, text=tr_("◀ Back"), command=self._prev,
            bg=SEL_BG, fg=FG, font=("Segoe UI", 9, "bold"),
            relief="flat", padx=12, pady=5, cursor="hand2",
            activebackground=ENTRY_BG, activeforeground=FG)
        self._btn_prev.pack(side="left", padx=(0, 8))

        tk.Button(nav, text=tr_("💾 Save & Quit"),
                  command=self._save_and_quit,
                  bg=ORANGE, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=12, pady=5, cursor="hand2").pack(side="left")

        self._step_label = tk.Label(nav, text="", bg=SEL_BG, fg=FG,
                                    font=("Segoe UI", 9))
        self._step_label.pack(side="right", padx=14)

        self._btn_next = tk.Button(
            nav, text=tr_("Next ▶"), command=self._next,
            bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
            relief="flat", padx=12, pady=5, cursor="hand2",
            activebackground=FG, activeforeground=BG)
        self._btn_next.pack(side="right")

    def _build_stepper(self):
        for w in self._stepper_frame.winfo_children():
            w.destroy()
        tk.Label(self._stepper_frame, text=tr_("Steps"), bg=SEL_BG, fg=ACCENT,
                 font=("Segoe UI", 9, "bold"), pady=12).pack(fill="x", padx=10)
        for i, title in enumerate(self.STEPS):
            done    = i < self._step
            current = i == self._step
            if current:
                bg_c, fg_c, icon = ACCENT,    BG,        "▶"
            elif done:
                bg_c, fg_c, icon = ENTRY_BG,  GREEN,     "✓"
            else:
                bg_c, fg_c, icon = SEL_BG,    "#666666", str(i + 1)
            row = tk.Frame(self._stepper_frame, bg=bg_c, padx=10, pady=7)
            row.pack(fill="x", pady=1)
            ir = tk.Frame(row, bg=bg_c); ir.pack(fill="x")
            tk.Label(ir, text=icon, bg=bg_c, fg=fg_c,
                     font=("Segoe UI", 9, "bold"), width=3).pack(side="left")
            tk.Label(ir, text=title, bg=bg_c, fg=fg_c,
                     font=("Segoe UI", 8, "bold" if current else "normal"),
                     wraplength=165, justify="left", anchor="w").pack(side="left")

    def _show_step(self, step):
        self._step = step
        self._build_stepper()
        for w in self._content_frame.winfo_children():
            w.destroy()
        builder = getattr(self, f"_build_step_{step}", None)
        if builder:
            builder(self._content_frame)
            self._guard_value_wheel(self._content_frame)
        self._step_label.config(text=f"{tr_('Step')} {step + 1} / {len(self.STEPS)}")
        self._btn_prev.config(state="normal" if step > 0 else "disabled")
        is_last = step == len(self.STEPS) - 1
        self._btn_next.config(
            text=tr_("✓ Finish") if is_last else tr_("Next ▶"),
            bg=GREEN if is_last else ACCENT)
        self._wiz_data["_step"] = step
        self._persist()

    def _prev(self):
        # Save the current step before going back
        # → the entries (token, URL…) are never lost
        validator = getattr(self, f"_validate_step_{self._step}", None)
        if validator:
            try:
                validator()
            except Exception:
                pass
        if self._step > 0:
            self._show_step(self._step - 1)

    def _next(self):
        validator = getattr(self, f"_validate_step_{self._step}", None)
        if validator and not validator():
            return
        if self._step < len(self.STEPS) - 1:
            self._show_step(self._step + 1)
        else:
            self._finish()

    def _finish(self):
        self._wiz_data["_finished"] = True
        self._persist()
        messagebox.showinfo(tr_("✅ Configuration complete"),
            tr_("OTA Guard is configured and ready to run.\n\n"
            "Click Scan now in the OTA price guard tab to run your first scan."),
            parent=self)
        self.destroy()

    def _save_and_quit(self):
        # Save the current step into the config (without blocking if validation fails)
        # → guarantees the entered fields (tokens, URLs…) are persisted
        validator = getattr(self, f"_validate_step_{self._step}", None)
        if validator:
            try:
                validator()
            except Exception:
                pass
        self._persist()
        messagebox.showinfo(tr_("Progress saved"),
            tr_("Your progress has been saved.\n"
            "The wizard will resume at this step on next opening."),
            parent=self)
        self.destroy()

    def _persist(self):
        self._progress[self.WIZARD_KEY] = self._wiz_data
        _save_progress(self._progress)

    # ── UI helpers ────────────────────────────────────────────────────────────

    def _scrolled(self, parent):
        outer  = tk.Frame(parent, bg=BG)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        sb     = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner  = tk.Frame(canvas, bg=BG)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind("<Enter>", lambda e: canvas.bind_all(
            "<MouseWheel>", lambda e2: canvas.yview_scroll(
                int(-1 * (e2.delta / 120)), "units")))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        return outer, inner

    def _guard_value_wheel(self, root_widget):
        """Prevents the mouse wheel from ACCIDENTALLY changing the value of
        ttk.Combobox / tk.Spinbox widgets (native Windows behavior) while
        scrolling the page. Without this, scrolling over an OTA dropdown fills
        it by itself (e.g.: empty → "Booking.com"). We force the zone to
        scroll instead and block (return "break") the value change."""
        def _scroll_ancestor(e):
            w = e.widget
            while w is not None:
                if isinstance(w, tk.Canvas):
                    w.yview_scroll(int(-1 * (e.delta / 120)), "units")
                    break
                w = getattr(w, "master", None)
            return "break"
        def _walk(w):
            try:
                if w.winfo_class() in ("TCombobox", "Spinbox", "TSpinbox"):
                    w.bind("<MouseWheel>", _scroll_ancestor)
            except tk.TclError:
                return
            for ch in w.winfo_children():
                _walk(ch)
        _walk(root_widget)

    def _field(self, parent, label, var, width=38, show=None):
        r = tk.Frame(parent, bg=BG); r.pack(fill="x", pady=4)
        tk.Label(r, text=tr_(label), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold"), width=24, anchor="w").pack(side="left")
        e = tk.Entry(r, textvariable=var, width=width,
                     bg=ENTRY_BG, fg=FG, insertbackground=FG,
                     relief="flat", highlightthickness=1,
                     highlightbackground=SEL_BG, highlightcolor=ACCENT,
                     font=("Segoe UI", 10))
        if show:
            e.config(show=show)
        e.pack(side="left")
        return e

    def _status(self, parent, text="", color=FG):
        lbl = tk.Label(parent, text=text, bg=BG, fg=color,
                       font=("Segoe UI", 9, "italic"), anchor="w")
        lbl.pack(anchor="w", pady=(4, 0))
        return lbl

    def _section_title(self, parent, text):
        tk.Label(parent, text=tr_(text), bg=BG, fg=ACCENT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(14, 4))
        tk.Frame(parent, bg=SEL_BG, height=1).pack(fill="x", pady=(0, 8))


# ══════════════════════════════════════════════════════════════════════════════
# MASTER WIZARD OTA GUARD
# ══════════════════════════════════════════════════════════════════════════════

class MasterWizard(WizardBase):
    WIZARD_KEY = "master_wizard"

    STEPS = [
        "🧭 Welcome",             # 0
        "🏨 My Hotel",            # 1
        "🚫 My OTAs",             # 2
        "🎯 Target prices",       # 3
        "⚙️ Scan & correction",   # 4
        "🛡️ Price protection",    # 5
        "🔌 Channel Manager",     # 6
        "🎨 Theme",               # 7
    ]

    _STEP_BADGE = {
        0: "Info",        1: "Required", 2: "Required", 3: "Required",
        4: "Recommended", 5: "Recommended", 6: "Required", 7: "Optional",
    }
    _BADGE_COLOR = {"Required": RED, "Recommended": ORANGE,
                    "Automatic": GREEN, "Optional": SEL_BG, "Info": ACCENT}

    def __init__(self, parent, app_config, save_config_fn):
        self._app_config = app_config
        self._save_cfg   = save_config_fn
        super().__init__(parent, "🧭 Configuration assistant — OTA Guard")
        # Override the parent centering with the dedicated MasterWizard size
        self.after(0, lambda: _center_window(self, w=1000, h=700))

        if self._step > 0 and not self._wiz_data.get("_finished"):
            self.after(300, self._show_resume_banner)

    def _show_resume_banner(self):
        step_name = tr_(self.STEPS[self._step]) if self._step < len(self.STEPS) else "?"
        messagebox.showinfo(
            tr_("Configuration resume"),
            tr_("Resuming at step {n}: {step}").format(n=self._step + 1, step=step_name)
            + "\n\n" + tr_("Your previous progress has been restored."),
            parent=self)

    # ── Stepper with badges ──────────────────────────────────────────────────

    def _build_stepper(self):
        for w in self._stepper_frame.winfo_children():
            w.destroy()
        tk.Label(self._stepper_frame, text=tr_("Configuration OTA Guard"),
                 bg=SEL_BG, fg=ACCENT, font=("Segoe UI", 9, "bold"),
                 pady=12).pack(fill="x", padx=8)
        for i, title in enumerate(self.STEPS):
            done    = i < self._step
            current = i == self._step
            badge   = self._STEP_BADGE.get(i, "")
            if current:
                bg_c, fg_c, icon = ACCENT,    BG,        "▶"
            elif done:
                bg_c, fg_c, icon = ENTRY_BG,  GREEN,     "✓"
            else:
                bg_c, fg_c, icon = SEL_BG,    "#666666", str(i + 1)
            row = tk.Frame(self._stepper_frame, bg=bg_c, padx=8, pady=6)
            row.pack(fill="x", pady=1)
            ir = tk.Frame(row, bg=bg_c); ir.pack(fill="x")
            tk.Label(ir, text=icon, bg=bg_c, fg=fg_c,
                     font=("Segoe UI", 9, "bold"), width=3).pack(side="left")
            tk.Label(ir, text=tr_(title), bg=bg_c, fg=fg_c,
                     font=("Segoe UI", 8, "bold" if current else "normal"),
                     wraplength=155, justify="left").pack(side="left")
            if badge and not done:
                badge_color = self._BADGE_COLOR.get(badge, SEL_BG)
                tk.Label(row, text=tr_(badge), bg=badge_color, fg=BG,
                         font=("Segoe UI", 6, "bold"), padx=3, pady=1).pack(
                    anchor="w", padx=(26, 0))

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 0 — Welcome
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_0(self, parent):
        pad = tk.Frame(parent, bg=BG)
        pad.pack(fill="both", expand=True, padx=60, pady=30)
        tk.Label(pad, text=tr_("🛡️ Welcome to OTA Guard"),
                 bg=BG, fg=ACCENT, font=("Segoe UI", 18, "bold"),
                 justify="center").pack(pady=(20, 12))
        tk.Label(pad,
                 text=tr_(
                     "This assistant guides you step by step to configure OTA Guard.\n"
                     "At the end, your software will be ready to monitor and correct\n"
                     "your OTA prices automatically.\n\n"
                     "Your progress is saved automatically.\n"
                     "You can quit at any time and resume later."
                 ),
                 bg=BG, fg=FG, font=("Segoe UI", 11), justify="center").pack(pady=8)
        info = tk.Frame(pad, bg=ENTRY_BG, padx=24, pady=14)
        info.pack(pady=20)
        for txt in [
            "🏨  Step 1 — My Hotel: your rooms and price limits",
            "🚫  Step 2 — My OTAs: your listings detected in Brave",
            "🎯  Step 3 — Target prices: the price the guest must see",
            "⚙️  Step 4 — Scan & correction: pace and rules",
            "🛡️  Step 5 — Price protection: floor/ceiling alerts",
            "🔌  Step 6 — Channel Manager: sending the prices",
            "🎨  Step 7 — Theme: interface customization",
        ]:
            tk.Label(info, text=tr_(txt), bg=ENTRY_BG, fg=FG,
                     font=("Segoe UI", 10), anchor="w").pack(anchor="w", pady=2)
        tk.Label(pad, text=tr_("Click Next to begin."),
                 bg=BG, fg=YELLOW, font=("Segoe UI", 10, "bold")).pack(pady=10)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 1 — My Hotel
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_1(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🏨 Your hotel information")
        tk.Label(inner,
                 text=tr_("This information is used in all scans and reports."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 10))

        cfg = self._app_config
        self._w1_name    = tk.StringVar(value=cfg.get("hotel_name", ""))
        self._w1_city    = tk.StringVar(value=cfg.get("hotel_city", ""))
        self._w1_country = tk.StringVar(value=cfg.get("hotel_country", ""))
        self._w1_ci      = tk.StringVar(value=cfg.get("hotel_checkin", "14:00"))
        self._w1_co      = tk.StringVar(value=cfg.get("hotel_checkout", "11:00"))
        self._w1_currency = tk.StringVar(value=cfg.get("hotel_currency", "INR"))

        self._field(inner, "Hotel name *",    self._w1_name)
        self._field(inner, "City *",              self._w1_city, width=20)
        self._field(inner, "Country *",               self._w1_country, width=14)
        # Check-in / Check-out: 24 h OR AM/PM entry, normalized to "HH:MM"
        # as soon as the field loses focus; stored in 24 h.
        f_ci = self._field(inner, "Check-in (24 h or AM/PM)",
                           self._w1_ci, width=8)
        f_co = self._field(inner, "Check-out (24 h or AM/PM)",
                           self._w1_co, width=8)
        f_ci.bind("<FocusOut>", lambda _e: self._norm_time(self._w1_ci))
        f_co.bind("<FocusOut>", lambda _e: self._norm_time(self._w1_co))

        r_cur = tk.Frame(inner, bg=BG); r_cur.pack(fill="x", pady=4)
        tk.Label(r_cur, text=tr_("Currency"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold"), width=24, anchor="w").pack(side="left")
        ttk.Combobox(r_cur, textvariable=self._w1_currency,
                     values=["INR", "USD", "EUR", "GBP", "THB", "AED", "SGD"],
                     width=7, state="readonly").pack(side="left")

        self._section_title(inner, "🛏 Room types & Price floor / ceiling")
        tk.Label(inner,
                 text=tr_("Define your room types and the price limits your OTAs must respect."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 8))

        # Table in ONE grid: the header (row 0) shares exactly the
        # same columns as the fields (uniform) → guaranteed alignment.
        self._w1_room_rows = []
        self._w1_room_frame = tk.Frame(inner, bg=SEL_BG)
        self._w1_room_frame.pack(fill="x")
        _g = self._w1_room_frame
        for c, weight, minpx in [(0, 5, 0), (1, 2, 56), (2, 2, 86),
                                 (3, 2, 86), (4, 0, 34)]:
            _g.grid_columnconfigure(c, weight=weight, uniform="w1room",
                                    minsize=minpx)
        for c, txt in enumerate(["Room name", "No. of rooms",
                                 "Floor ₹", "Ceiling ₹", ""]):
            if not txt:
                continue
            tk.Label(_g, text=tr_(txt), bg=SEL_BG, fg=ACCENT,
                     font=("Segoe UI", 8, "bold"), anchor="w").grid(
                row=0, column=c, sticky="ew", padx=6, pady=(2, 4))

        room_types = cfg.get("room_types", [])
        inventory  = cfg.get("room_inventory", {})
        for rt in room_types:
            rt_str = rt if isinstance(rt, str) else rt.get("type", "")
            inv    = inventory.get(rt_str, {})
            self._w1_add_room(rt_str, str(inv.get("count", 1)),
                              str(inv.get("floor", 0)), str(inv.get("ceiling", "")))
        if not room_types:
            self._w1_add_room()

        tk.Label(inner,
                 text=tr_("\"No. of rooms\" = how many rooms of this type "
                          "your hotel has (e.g. 5) — not a number."),
                 bg=BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w",
                                                                 pady=(4, 0))

        tk.Button(inner, text=tr_("+ Add a room"),
                  command=self._w1_add_room,
                  bg=GREEN, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=8, pady=4, cursor="hand2").pack(anchor="w", pady=6)

    def _w1_add_room(self, name="", count="1", floor_val="", ceil_val=""):
        g = self._w1_room_frame
        row = len(self._w1_room_rows) + 1
        n_v = tk.StringVar(value=name);   c_v = tk.StringVar(value=count)
        f_v = tk.StringVar(value=floor_val); cl_v = tk.StringVar(value=ceil_val)
        for col, var in enumerate((n_v, c_v, f_v, cl_v)):
            tk.Entry(g, textvariable=var, width=8,
                     bg=ENTRY_BG, fg=FG, insertbackground=FG,
                     relief="flat", font=("Segoe UI", 9)).grid(
                row=row, column=col, sticky="ew", padx=2, pady=2)
        rd = (n_v, c_v, f_v, cl_v, g, row)
        self._w1_room_rows.append(rd)
        tk.Button(g, text="✕",
                  command=lambda r=rd: self._w1_remove_room(r),
                  bg=RED, fg=BG, font=("Segoe UI", 8, "bold"),
                  relief="flat", width=2, cursor="hand2").grid(
            row=row, column=4, padx=2, pady=2)

    def _w1_remove_room(self, rd):
        for w in rd[4].grid_slaves(row=rd[5]):
            w.destroy()
        self._w1_room_rows.remove(rd)

    def _norm_time(self, var):
        # Rewrites the field in 24 h format when the entry is recognizable
        # ("2pm" -> "14:00"); an unreadable entry is left as-is
        # (the warning message at save time flags it).
        raw = var.get().strip()
        parsed = parse_time_flexible(raw) if raw else None
        if parsed:
            var.set(parsed)

    def _validate_step_1(self):
        name    = self._w1_name.get().strip()
        city    = self._w1_city.get().strip()
        country = self._w1_country.get().strip()
        if not name or not city or not country:
            messagebox.showwarning(tr_("Required fields"),
                tr_("Hotel name, city and country are required."), parent=self)
            return False
        rooms = [r for r in self._w1_room_rows if r[0].get().strip()]
        if not rooms:
            messagebox.showwarning(tr_("Missing rooms"),
                tr_("Add at least one room type."), parent=self)
            return False
        # Save
        cfg = self._app_config
        cfg["hotel_name"]    = name
        cfg["hotel_city"]    = city
        cfg["hotel_country"] = country
        ci_raw = self._w1_ci.get().strip()
        co_raw = self._w1_co.get().strip()
        ci = parse_time_flexible(ci_raw) if ci_raw else "14:00"
        co = parse_time_flexible(co_raw) if co_raw else "11:00"
        if not ci or not co:
            messagebox.showwarning(
                tr_("Invalid time"),
                tr_("Invalid time: \"{v}\". Accepted examples: "
                    "14:00, 14:30, 2:00 PM, 2pm.").format(v=ci_raw or co_raw),
                parent=self)
            return False
        cfg["hotel_checkin"] = ci
        cfg["hotel_checkout"] = co
        cfg["hotel_currency"] = self._w1_currency.get().strip() or "INR"
        if "channel_manager" in cfg:
            cfg["channel_manager"]["currency"] = cfg["hotel_currency"]
        new_types = []; new_inv = {}
        for n_v, c_v, f_v, cl_v, _, _ in self._w1_room_rows:
            n = n_v.get().strip()
            if not n: continue
            new_types.append(n)
            try: cnt = int(c_v.get())
            except: cnt = 1
            try: flr = float(f_v.get())
            except: flr = 0.0
            try: clg = float(cl_v.get())
            except: clg = 999999.0
            new_inv[n] = {"count": cnt, "floor": flr, "ceiling": clg}
        cfg["room_types"]     = new_types
        cfg["room_inventory"] = new_inv
        strat = cfg.setdefault("strategy", {})
        strat["floors"]   = {n: v["floor"]   for n, v in new_inv.items() if v["floor"]}
        strat["ceilings"] = {n: v["ceiling"] for n, v in new_inv.items()
                             if v["ceiling"] and v["ceiling"] != 999999.0}
        self._save_cfg(cfg)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 2 — My OTAs
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_2(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🚫 My OTAs")
        tk.Label(inner,
                 text=tr_("Open your hotel's pages on your OTAs in Brave,\n"
                          "then click Detect. You can also add an OTA manually."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 10))

        top = tk.Frame(inner, bg=BG); top.pack(fill="x", pady=(0, 6))
        tk.Button(top, text=tr_("🔄 Detect open tabs in Brave"),
                  command=self._w2_detect_brave,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=5, cursor="hand2").pack(side="left")
        self._w2_status = tk.Label(top, text="", bg=BG, fg=FG,
                                   font=("Segoe UI", 9))
        self._w2_status.pack(side="left", padx=10)

        # Table in ONE grid: header (row 0) + OTA rows —
        # shared columns (uniform) → guaranteed alignment. The Brave
        # detection rebuilds the rows without touching the header (row 0).
        # Column 0 = CLICKABLE selection circle (🟢 monitored /
        # 🔴 ignored for now — the URL stays saved in the config
        # with active=False for future use, e.g. VAE3 module).
        self._w2_ota_vars = []
        self._w2_list_frame = tk.Frame(inner, bg=SEL_BG)
        self._w2_list_frame.pack(fill="x")
        _g = self._w2_list_frame
        for c, weight, minpx in [(0, 0, 52), (1, 2, 150), (2, 5, 300),
                                 (3, 0, 34)]:
            _g.grid_columnconfigure(c, weight=weight, uniform="w2ota",
                                    minsize=minpx)
        for c, txt in [(0, "Active"), (1, "OTA"),
                       (2, "URL of your listing")]:
            tk.Label(_g, text=tr_(txt), bg=SEL_BG, fg=ACCENT,
                     font=("Segoe UI", 8, "bold"), anchor="w").grid(
                row=0, column=c, sticky="ew", padx=6, pady=(2, 4))

        ow = self._app_config.get("ota_watch", {})
        for od in ow.get("otas", []):
            self._w2_add_ota(od.get("name", ""), od.get("url", ""),
                             od.get("active", True))
        if not self._w2_ota_vars:
            self._w2_add_ota("", "", True)

        tk.Button(inner, text=tr_("+ Add an OTA"),
                  command=lambda: self._w2_add_ota("", "", True),
                  bg=GREEN, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=8, pady=4, cursor="hand2"
                  ).pack(anchor="w", pady=6)

    def _w2_add_ota(self, name="", url="", active=True, source="manual"):
        g = self._w2_list_frame
        row = len(self._w2_ota_vars) + 1
        name_v   = tk.StringVar(value=name)
        url_v    = tk.StringVar(value=url)
        active_v = tk.BooleanVar(value=bool(active))

        # Clickable selection circle: GREEN = OTA monitored, RED =
        # ignored for now. A red row is saved with
        # active=False: the URL stays in the config (future use, e.g.
        # VAE3 extranets) but the scans skip it.
        # NB: the 🟢/🔴 emoji do not render in color on Tk Windows
        # buttons → colored "●" dot via fg (reliable).
        def _paint():
            circ.config(fg=(GREEN if active_v.get() else RED))

        def _toggle():
            active_v.set(not active_v.get())
            _paint()

        circ = tk.Button(g, text="●", command=_toggle,
                         font=("Segoe UI", 13, "bold"),
                         bg=SEL_BG, fg=GREEN, relief="flat", width=2, bd=0,
                         cursor="hand2", activebackground=SEL_BG,
                         highlightthickness=0, takefocus=0)
        _paint()
        tooltip(circ, tr_("Click to toggle: green = OTA monitored, "
                          "red = ignored for now (the URL stays "
                          "saved)."))
        circ.grid(row=row, column=0, padx=2, pady=2)
        tk.Entry(g, textvariable=name_v, width=8,
                 bg=ENTRY_BG, fg=FG, insertbackground=FG,
                 relief="flat", font=("Segoe UI", 9)).grid(
            row=row, column=1, sticky="ew", padx=2, pady=2)
        tk.Entry(g, textvariable=url_v, width=8,
                 bg=ENTRY_BG, fg=FG, insertbackground=FG,
                 relief="flat", font=("Segoe UI", 9)).grid(
            row=row, column=2, sticky="ew", padx=2, pady=2)
        rd = {"name": name_v, "url": url_v, "active": active_v,
              "frame": (g, row)}
        self._w2_ota_vars.append(rd)
        tk.Button(g, text="✕",
                  command=lambda r=rd: self._w2_remove_ota(r),
                  bg=RED, fg=BG, font=("Segoe UI", 8, "bold"),
                  relief="flat", width=2, cursor="hand2").grid(
            row=row, column=3, padx=2, pady=2)

    def _w2_remove_ota(self, rd):
        for w in rd["frame"][0].grid_slaves(row=rd["frame"][1]):
            w.destroy()
        self._w2_ota_vars.remove(rd)

    def _w2_detect_brave(self):
        from tabs.tab_blocage_ota import _detect_otas_from_brave
        current = [{"name": d["name"].get().strip(), "url": d["url"].get().strip()}
                   for d in self._w2_ota_vars
                   if d["name"].get().strip() or d["url"].get().strip()]
        try:
            detected = _detect_otas_from_brave(current or None)
        except Exception as e:
            self._w2_status.config(
                text=tr_("⚠ Detection failed: {e}").format(e=e), fg=RED)
            return
        # Destroy only the rows (row >= 1) — the row 0 header stays.
        for w in self._w2_list_frame.winfo_children():
            if w.grid_info().get("row", 0) > 0:
                w.destroy()
        self._w2_ota_vars = []
        n_brave, seen_urls = 0, set()
        for d in detected:
            url = d.get("url", "")
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            src = d.get("source", "brave")
            self._w2_add_ota(d.get("name", ""), url, True, src)
            if src == "brave":
                n_brave += 1
        if not self._w2_ota_vars:
            self._w2_add_ota("", "", True)
        if n_brave:
            self._w2_status.config(
                text=tr_("✅ {n} OTA(s) detected in Brave.").format(n=n_brave),
                fg=GREEN)
        else:
            self._w2_status.config(
                text=tr_("No OTA tab detected — open your listings in Brave "
                         "or add them manually."), fg=ORANGE)
        self._guard_value_wheel(self._w2_list_frame)

    def _validate_step_2(self):
        # ALL rows (green AND red) are saved: a red row goes out as
        # active=False — the URL stays saved in the config for future
        # use (e.g. VAE3 extranets) but the scans skip it. At least one
        # green OTA with name + https URL is required.
        otas = [{"name":   d["name"].get().strip(),
                 "url":    d["url"].get().strip(),
                 "active": bool(d["active"].get())}
                for d in self._w2_ota_vars]
        otas = [o for o in otas if o["name"] or o["url"]]
        valid = [o for o in otas if o["active"] and o["name"]
                 and o["url"].startswith("http")]
        if not valid:
            messagebox.showwarning(
                tr_("Missing OTA"),
                tr_("No OTA selected. Click a circle to turn it "
                    "green (at least one OTA with its name and the URL "
                    "of your listing https://...)."), parent=self)
            return False
        ow = self._app_config.setdefault("ota_watch", {})
        ow["otas"] = otas
        self._save_cfg(self._app_config)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3 — Target prices
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_3(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🎯 Target prices per room")
        tk.Label(inner,
                 text=tr_("The price you want the guest to see on each OTA.\n"
                          "The price sent to the Channel Manager adjusts step by step toward these targets."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 10))

        self._w3t_frame = tk.Frame(inner, bg=BG)
        self._w3t_frame.pack(fill="x")
        self._w3t_vars = {}
        self._w3t_rebuild()

    def _w3t_rebuild(self):
        for w in self._w3t_frame.winfo_children():
            w.destroy()
        rooms = [r if isinstance(r, str) else r.get("type", "")
                 for r in self._app_config.get("room_types", [])]
        rooms = [r for r in rooms if r]
        ow = self._app_config.get("ota_watch", {})
        targets = ow.get("target_prices", {})
        otas = [o.get("name", "") for o in ow.get("otas", [])
                if o.get("name")]
        if not rooms or not otas:
            tk.Label(self._w3t_frame,
                     text=tr_("Go back to the My Hotel and My OTAs steps "
                              "to fill in the rooms and the OTAs."),
                     bg=BG, fg=ORANGE, font=("Segoe UI", 9)).pack(anchor="w")
            return

        canvas = tk.Canvas(self._w3t_frame, bg=BG, highlightthickness=0, height=1)
        hsb = tk.Scrollbar(self._w3t_frame, orient="horizontal", command=canvas.xview)
        canvas.configure(xscrollcommand=hsb.set)
        hsb.pack(side="bottom", fill="x")
        canvas.pack(side="top", fill="x", expand=True)
        body = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0, 0), window=body, anchor="nw")

        def _on_conf(_e=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win, height=body.winfo_reqheight())
            canvas.configure(height=body.winfo_reqheight())
        body.bind("<Configure>", _on_conf)

        # Table in ONE grid: header (row 0) + room rows —
        # the OTA columns widen to their longest label,
        # headers and fields share exactly the same bounds.
        self._w3t_vars = {}
        g = tk.Frame(body, bg=BG)
        g.pack(fill="x")
        g.grid_columnconfigure(0, weight=1, minsize=150)
        for c in range(len(otas)):
            g.grid_columnconfigure(c + 1, weight=0, minsize=110)
        tk.Label(g, text=tr_("Room"), bg=BG, fg=ACCENT,
                 font=("Segoe UI", 8, "bold"), anchor="w").grid(
            row=0, column=0, sticky="ew", padx=4, pady=(2, 4))
        cur = self._app_config.get("hotel_currency", "INR")
        for c, name in enumerate(otas):
            tk.Label(g, text=f"{name} ({cur})", bg=BG, fg=ACCENT,
                     font=("Segoe UI", 8, "bold"), anchor="w").grid(
                row=0, column=c + 1, sticky="ew", padx=4, pady=(2, 4))

        for ri, room in enumerate(rooms):
            rt_data = targets.get(room, {})
            bg_r = ENTRY_BG if ri % 2 == 0 else BG
            tk.Label(g, text=room, bg=bg_r, fg=FG,
                     font=("Segoe UI", 9), anchor="w").grid(
                row=ri + 1, column=0, sticky="ew", padx=4, pady=2)
            self._w3t_vars[room] = {}
            for c, ota_name in enumerate(otas):
                val = rt_data.get(ota_name, "")
                if not val:
                    for _alias in ("MakeMyTrip / Goibibo", "MakeMyTrip", "Goibibo"):
                        if _alias != ota_name:
                            val = rt_data.get(_alias, "")
                            if val:
                                break
                v = tk.StringVar(value=str(int(val)) if val else "")
                tk.Entry(g, textvariable=v, width=8,
                         bg=ENTRY_BG, fg=FG, insertbackground=FG,
                         relief="flat", highlightthickness=1,
                         highlightbackground=SEL_BG,
                         font=("Segoe UI", 10)).grid(
                    row=ri + 1, column=c + 1, sticky="ew", padx=4, pady=2)
                self._w3t_vars[room][ota_name] = v
        _on_conf()

    def _validate_step_3(self):
        target_prices = {}
        for room, ota_dict in self._w3t_vars.items():
            room_t = {}
            for ota_name, v in ota_dict.items():
                raw = v.get().strip()
                if raw:
                    try:
                        room_t[ota_name] = float(raw.replace(",", "."))
                    except ValueError:
                        pass
            if room_t:
                target_prices[room] = room_t
        ow = self._app_config.setdefault("ota_watch", {})
        ow["target_prices"] = target_prices
        self._save_cfg(self._app_config)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 4 — Scan & correction
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_4(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "⚙️ Automatic scan & correction")
        cur = self._app_config.get("hotel_currency", "INR")
        ow = self._app_config.get("ota_watch", {})

        r1 = tk.Frame(inner, bg=BG); r1.pack(fill="x", pady=4)
        self._w4_auto = tk.BooleanVar(value=ow.get("auto_correct", False))
        tk.Checkbutton(r1, text=tr_("Automatic correction after each scan"),
                       variable=self._w4_auto,
                       bg=BG, fg=FG, selectcolor=ENTRY_BG, activebackground=BG,
                       font=("Segoe UI", 10)).pack(side="left")

        r2 = tk.Frame(inner, bg=BG); r2.pack(fill="x", pady=4)
        tk.Label(r2, text=tr_("Scan interval:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self._w4_int_h = tk.StringVar(value=str(ow.get("interval_h", 4)))
        tk.Spinbox(r2, textvariable=self._w4_int_h, from_=0, to=24, width=4,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 2))
        tk.Label(r2, text="h", bg=BG, fg=FG).pack(side="left", padx=(0, 6))
        self._w4_int_m = tk.StringVar(value=str(ow.get("interval_m", 0)))
        tk.Spinbox(r2, textvariable=self._w4_int_m, from_=0, to=59, increment=5, width=4,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 2))
        tk.Label(r2, text=tr_("min"), bg=BG, fg=FG).pack(side="left", padx=(0, 20))
        tk.Label(r2, text=f"{tr_('Correct if gap ≥')} {cur}", bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self._w4_gap = tk.StringVar(value=str(ow.get("min_gap", 50)))
        tk.Spinbox(r2, textvariable=self._w4_gap, from_=0, to=2000, increment=50, width=6,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left")

        r3 = tk.Frame(inner, bg=BG); r3.pack(fill="x", pady=6)
        tk.Label(r3, text=tr_("📅 Observe prices for a stay in:"),
                 bg=BG, fg=FG, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 8))
        self._w4_date_offset = tk.IntVar(value=int(ow.get("date_offset", 1)))
        for _days, _label in [(0, "D+0"), (1, "D+1"), (3, "D+3"),
                              (7, "D+7"), (10, "D+10"), (15, "D+15")]:
            tk.Radiobutton(r3, text=_label, variable=self._w4_date_offset,
                           value=_days, bg=BG, fg=FG, selectcolor=ENTRY_BG,
                           activebackground=BG, font=("Segoe UI", 9),
                           cursor="hand2").pack(side="left", padx=(0, 6))

        r4 = tk.Frame(inner, bg=BG); r4.pack(fill="x", pady=4)
        tk.Label(r4, text=tr_("📅 Apply the new prices from: D+"),
                 bg=BG, fg=FG, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self._w4_corr_off = tk.StringVar(value=str(int(ow.get("correct_date_offset", 0))))
        tk.Spinbox(r4, textvariable=self._w4_corr_off, from_=0, to=365, width=5,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
        tk.Label(r4, text=tr_("for:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(4, 4))
        self._w4_corr_days = tk.StringVar(value=str(int(ow.get("correct_duration_days", 90))))
        tk.Spinbox(r4, textvariable=self._w4_corr_days, from_=1, to=365, width=5,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
        tk.Label(r4, text=tr_("day(s)"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left")

        r5 = tk.Frame(inner, bg=BG); r5.pack(fill="x", pady=4)
        self._w4_wknd_en = tk.BooleanVar(value=ow.get("weekend_markup_enabled", True))
        tk.Checkbutton(r5, text=tr_("🗓️ Markup:"), variable=self._w4_wknd_en,
                       bg=BG, fg=FG, selectcolor=ENTRY_BG, activebackground=BG,
                       font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
        self._w4_wknd_days = []
        for _di, _dl in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]):
            _dv = tk.BooleanVar(value=_di in ow.get("weekend_days", [4, 5]))
            tk.Checkbutton(r5, text=_dl, variable=_dv,
                           bg=BG, fg=FG, selectcolor=ENTRY_BG, activebackground=BG,
                           font=("Segoe UI", 9)).pack(side="left", padx=(1, 0))
            self._w4_wknd_days.append(_dv)
        tk.Label(r5, text="  +", bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(6, 2))
        self._w4_wknd_pct = tk.StringVar(value=str(ow.get("weekend_markup_pct", 20)))
        tk.Spinbox(r5, textvariable=self._w4_wknd_pct, from_=0, to=100, increment=5, width=5,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 2))
        tk.Label(r5, text="%", bg=BG, fg=FG).pack(side="left")

        r6 = tk.Frame(inner, bg=BG); r6.pack(fill="x", pady=4)
        self._w4_calib_auto = tk.BooleanVar(value=ow.get("calib_auto", False))
        tk.Checkbutton(r6, text=tr_("🔄 Auto calibration if floor violated"),
                       variable=self._w4_calib_auto,
                       bg=BG, fg=FG, selectcolor=ENTRY_BG, activebackground=BG,
                       font=("Segoe UI", 10)).pack(side="left", padx=(0, 14))
        tk.Label(r6, text=tr_("Delay between checks (min):"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self._w4_calib_wait = tk.StringVar(value=str(ow.get("calib_wait_min", 5)))
        tk.Spinbox(r6, textvariable=self._w4_calib_wait, from_=5, to=120, increment=5, width=5,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 12))
        tk.Label(r6, text=tr_("Max attempts:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self._w4_calib_max = tk.StringVar(value=str(ow.get("calib_max_retries", 5)))
        tk.Spinbox(r6, textvariable=self._w4_calib_max, from_=1, to=10, width=4,
                   bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10)).pack(side="left")

        tk.Label(inner,
                 text=tr_("If an OTA displays a price below the floor, the software "
                          "sends a higher price, waits for the set delay, re-scans "
                          "and adjusts until it is back above the floor."),
                 bg=BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", padx=8, pady=(4, 0))

    def _validate_step_4(self):
        ow = self._app_config.setdefault("ota_watch", {})
        ow["auto_correct"] = self._w4_auto.get()
        try: ow["interval_h"] = int(self._w4_int_h.get())
        except ValueError: pass
        try: ow["interval_m"] = int(self._w4_int_m.get())
        except ValueError: pass
        try: ow["min_gap"] = float(self._w4_gap.get())
        except ValueError: pass
        ow["date_offset"] = int(self._w4_date_offset.get())
        try: ow["correct_date_offset"] = int(self._w4_corr_off.get())
        except ValueError: pass
        try: ow["correct_duration_days"] = int(self._w4_corr_days.get())
        except ValueError: pass
        ow["weekend_markup_enabled"] = self._w4_wknd_en.get()
        ow["weekend_days"] = [i for i, dv in enumerate(self._w4_wknd_days) if dv.get()]
        try: ow["weekend_markup_pct"] = float(self._w4_wknd_pct.get())
        except ValueError: pass
        ow["calib_auto"] = self._w4_calib_auto.get()
        try: ow["calib_wait_min"] = max(5, int(self._w4_calib_wait.get()))
        except ValueError: pass
        try: ow["calib_max_retries"] = int(self._w4_calib_max.get())
        except ValueError: pass
        self._save_cfg(self._app_config)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 5 — Price protection
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_5(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🛡️ Price floor & ceiling protection")
        tk.Label(inner,
                 text=tr_("The per-room floors and ceilings were defined "
                          "in the My Hotel step.\nChoose here what OTA Guard "
                          "does when a price leaves these bounds."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 10))

        pf = self._app_config.get("price_floors", {})

        r1 = tk.Frame(inner, bg=BG); r1.pack(fill="x", pady=4)
        self._w5_auto = tk.BooleanVar(value=pf.get("auto_correct", False))
        tk.Checkbutton(r1, text=tr_("Automatic monitoring at scan time (alert only)"),
                       variable=self._w5_auto,
                       bg=BG, fg=FG, selectcolor=ENTRY_BG, activebackground=BG,
                       font=("Segoe UI", 10)).pack(anchor="w")
        tk.Label(inner,
                 text=tr_("After each scan, out-of-bounds prices are flagged in "
                          "the journal and sent as an alert — nothing is modified."),
                 bg=BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", padx=16)

        r2 = tk.Frame(inner, bg=BG); r2.pack(fill="x", pady=(8, 4))
        self._w5_push = tk.BooleanVar(value=pf.get("auto_push", False))
        tk.Checkbutton(r2, text=tr_("⚠ Also send the corrections to the Channel Manager"),
                       variable=self._w5_push,
                       bg=BG, fg=ORANGE, selectcolor=ENTRY_BG, activebackground=BG,
                       font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(inner,
                 text=tr_("Out-of-bounds prices are corrected automatically at the CM, "
                          "without confirmation.\nLeave unchecked at first: first verify "
                          "that the detections are accurate."),
                 bg=BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", padx=16)

    def _validate_step_5(self):
        pf = self._app_config.setdefault("price_floors", {})
        pf["auto_correct"] = self._w5_auto.get()
        pf["auto_push"] = self._w5_push.get()
        self._save_cfg(self._app_config)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 6 — Channel Manager
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_6(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🔌 Channel Manager connection")
        tk.Label(inner,
                 text=tr_("The Channel Manager receives your prices and publishes them to your OTAs."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 10))

        cm = self._app_config.get("channel_manager", {})
        CM_TYPES = [_cm_type_display(k) for k in CM_TYPES_KEYS]

        r_type = tk.Frame(inner, bg=BG); r_type.pack(fill="x", pady=4)
        tk.Label(r_type, text=tr_("CM type:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold"), width=24, anchor="w").pack(side="left")
        self._w3_type_v = tk.StringVar(value=_cm_type_display(cm.get("type", "API custom")))
        ttk.Combobox(r_type, textvariable=self._w3_type_v,
                     values=CM_TYPES, width=28, state="readonly").pack(side="left")

        self._w3_endpoint = tk.StringVar(value=cm.get("endpoint", ""))
        self._w3_token    = tk.StringVar(value=cm.get("api_token", ""))
        self._w3_hotel_id = tk.StringVar(value=cm.get("hotel_id", ""))

        self._field(inner, "URL endpoint *",    self._w3_endpoint, width=48)
        self._field(inner, "API token / key *", self._w3_token, width=44, show="*")
        self._field(inner, "Hotel ID / Code",   self._w3_hotel_id, width=16)

        # Currency: read-only, derived from hotel_currency (step 1 — My
        # Hotel). A free field here could drift to a different value and
        # skew the actual shipment to the Channel Manager.
        r_cur = tk.Frame(inner, bg=BG); r_cur.pack(fill="x", pady=4)
        tk.Label(r_cur, text=tr_("Currency"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold"), width=24, anchor="w").pack(side="left")
        tk.Label(r_cur, text=self._app_config.get("hotel_currency", "INR"),
                 bg=BG, fg=YELLOW, font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Label(r_cur, text=tr_("  (defined in the My Hotel step)"), bg=BG,
                 fg="#888888", font=("Segoe UI", 8)).pack(side="left")

        # Test/real mode
        mode_row = tk.Frame(inner, bg=BG); mode_row.pack(fill="x", pady=8)
        self._w3_test_mode = tk.BooleanVar(value=cm.get("test_mode", True))
        tk.Label(mode_row, text=tr_("Send mode:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 12))
        tk.Radiobutton(mode_row, text=tr_("🧪 TEST mode (no real shipment)"),
                       variable=self._w3_test_mode, value=True,
                       bg=BG, fg=GREEN, selectcolor=ENTRY_BG,
                       activebackground=BG, font=("Segoe UI", 9, "bold")
                       ).pack(side="left", padx=6)
        tk.Radiobutton(mode_row, text=tr_("🔴 REAL mode"),
                       variable=self._w3_test_mode, value=False,
                       bg=BG, fg=RED, selectcolor=ENTRY_BG,
                       activebackground=BG, font=("Segoe UI", 9, "bold")
                       ).pack(side="left", padx=6)

        # Connection test
        self._section_title(inner, "🔍 Connection test")
        test_row = tk.Frame(inner, bg=BG); test_row.pack(anchor="w")
        self._w3_test_status = tk.Label(inner, text="", bg=BG, fg=FG,
                                         font=("Segoe UI", 9))
        tk.Button(test_row, text=tr_("🔌 Test the connection"),
                  command=self._w3_test_conn,
                  bg=YELLOW, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=5, cursor="hand2").pack(side="left")
        self._w3_test_status.pack(anchor="w", pady=(6, 0))

        # Room mapping
        self._section_title(inner, "🗺 Room → CM code mapping")
        tk.Label(inner,
                 text=tr_("Map each room to its code in the Channel Manager."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 6))

        # Auto-fetch button from the CM
        fetch_row = tk.Frame(inner, bg=BG); fetch_row.pack(anchor="w", pady=(0, 6))
        tk.Button(fetch_row, text=tr_("🔄 Fetch rooms + mapping from the CM"),
                  command=self._w3_fetch_from_cm,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=5, cursor="hand2"
                  ).pack(side="left", padx=(0, 8))
        self._w3_fetch_status = tk.Label(fetch_row, text="", bg=BG, fg=FG,
                                          font=("Segoe UI", 8, "italic"))
        self._w3_fetch_status.pack(side="left")

        # Table container (rebuildable)
        self._w3_mapping_container = tk.Frame(inner, bg=BG)
        self._w3_mapping_container.pack(fill="x")
        self._w3_rebuild_mapping_table()

    def _w3_rebuild_mapping_table(self):
        """Rebuilds the mapping table from self._app_config.
        One card per room, with 1..N Rate Plans (like the Channel Manager tab)."""
        for w in self._w3_mapping_container.winfo_children():
            w.destroy()

        self._w3_mapping_vars = {}
        cm = self._app_config.get("channel_manager", {})
        room_mapping = cm.get("room_mapping", {})
        rooms = self._app_config.get("room_types", [])

        if not rooms:
            tk.Label(self._w3_mapping_container,
                     text=tr_("No rooms — use the button above or configure in step 1."),
                     bg=BG, fg=ORANGE, font=("Segoe UI", 8, "italic")
                     ).pack(anchor="w", pady=4)
            return

        for rt in rooms:
            room = rt if isinstance(rt, str) else rt.get("type", "")
            if not room:
                continue
            rm = room_mapping.get(room, {})

            card = tk.Frame(self._w3_mapping_container, bg=SEL_BG, padx=8, pady=6,
                            highlightthickness=1, highlightbackground=ACCENT)
            card.pack(fill="x", pady=3)

            title_row = tk.Frame(card, bg=SEL_BG); title_row.pack(fill="x")
            tk.Label(title_row, text=room, bg=SEL_BG, fg=FG,
                     font=("Segoe UI", 10, "bold"), anchor="w"
                     ).pack(side="left", fill="x", expand=True)

            hrow = tk.Frame(card, bg=SEL_BG); hrow.pack(fill="x", pady=(2, 0))
            tk.Label(hrow, text=tr_("Room Code CM:"), bg=SEL_BG, fg=FG,
                     font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
            rc_v = tk.StringVar(
                value=rm.get("room_code", "") if isinstance(rm, dict) else str(rm))
            tk.Entry(hrow, textvariable=rc_v, width=14,
                     bg=ENTRY_BG, fg=FG, insertbackground=FG, relief="flat",
                     font=("Segoe UI", 9)).pack(side="left")

            table_f = tk.Frame(card, bg=SEL_BG); table_f.pack(fill="x", pady=(4, 0))
            table_f.columnconfigure(0, weight=4)   # OTA
            table_f.columnconfigure(1, weight=3)   # OTA CM code
            table_f.columnconfigure(2, weight=3)   # Rate Plan
            table_f.columnconfigure(3, weight=2)   # Discount %
            table_f.columnconfigure(4, weight=0, minsize=28)  # 🗑
            for c, txt in enumerate(["OTA", "OTA CM code", "Rate Plan", "Discount %", ""]):
                tk.Label(table_f, text=tr_(txt), bg=BG, fg=ACCENT,
                         font=("Segoe UI", 8, "bold"), anchor="center"
                         ).grid(row=0, column=c, sticky="ew", padx=(0, 2), pady=(0, 3))

            rp_vars_list = []
            if isinstance(rm, dict):
                rate_plans_cfg = rm.get("rate_plans", [])
                if not rate_plans_cfg:
                    old_rpc = rm.get("rate_plan_code", "")
                    rate_plans_cfg = [{"rate_plan_code": old_rpc}] if old_rpc else [{}]
            else:
                rate_plans_cfg = [{}]

            for rp_data in rate_plans_cfg:
                self._w3_make_rp_row(table_f, rp_data, rp_vars_list)

            add_row = tk.Frame(card, bg=SEL_BG); add_row.pack(fill="x", pady=(3, 0))
            tk.Button(add_row, text=tr_("+ Rate Plan"),
                      command=lambda tf=table_f, l=rp_vars_list: self._w3_make_rp_row(tf, {}, l),
                      bg=ENTRY_BG, fg=ACCENT, font=("Segoe UI", 8, "bold"),
                      relief="flat", padx=6, pady=2, cursor="hand2").pack(side="left")

            self._w3_mapping_vars[room] = {"room_code": rc_v, "rate_plans": rp_vars_list}

    def _w3_make_rp_row(self, table_f, rp_data, rp_vars_list):
        """Adds a Rate Plan row to the grid table (table_f)."""
        ota_v  = tk.StringVar(value=rp_data.get("ota_name", ""))
        otac_v = tk.StringVar(value=str(rp_data.get("ota_code", "")))
        rpc_v  = tk.StringVar(value=rp_data.get("rate_plan_code", ""))
        try:
            disc_val = int(float(rp_data.get("ota_discount_pct", 0) or 0))
        except (ValueError, TypeError):
            disc_val = 0
        disc_v = tk.StringVar(value=str(disc_val))
        rp_vars = {"ota_name": ota_v, "ota_code": otac_v,
                   "rate_plan_code": rpc_v, "ota_discount_pct": disc_v}
        rp_vars_list.append(rp_vars)
        ridx = len(rp_vars_list)

        e0 = tk.Entry(table_f, textvariable=ota_v, bg=ENTRY_BG, fg=ACCENT,
                       relief="flat", font=("Segoe UI", 9, "bold"))
        e0.grid(row=ridx, column=0, sticky="ew", padx=(0, 2), pady=1)
        e1 = tk.Entry(table_f, textvariable=otac_v, bg=ENTRY_BG, fg="#f08030",
                       relief="flat", font=("Segoe UI", 9))
        e1.grid(row=ridx, column=1, sticky="ew", padx=(0, 2), pady=1)
        e2 = tk.Entry(table_f, textvariable=rpc_v, bg=ENTRY_BG, fg=FG,
                       relief="flat", font=("Segoe UI", 9))
        e2.grid(row=ridx, column=2, sticky="ew", padx=(0, 2), pady=1)
        disc_f = tk.Frame(table_f, bg=SEL_BG)
        disc_f.grid(row=ridx, column=3, sticky="ew", padx=(0, 2), pady=1)
        tk.Entry(disc_f, textvariable=disc_v, bg=ENTRY_BG, fg=GREEN,
                 relief="flat", width=5, font=("Segoe UI", 9, "bold")
                 ).pack(side="left", fill="x", expand=True)
        tk.Label(disc_f, text="%", bg=SEL_BG, fg="#888888",
                 font=("Segoe UI", 9)).pack(side="left")

        row_ws = [e0, e1, e2, disc_f]

        def _del(_rv=rp_vars, _ws=row_ws, _lst=rp_vars_list):
            if len(_lst) > 1:
                _lst.remove(_rv)
                for w in _ws:
                    w.destroy()
                _del_btn.destroy()

        _del_btn = tk.Button(table_f, text="🗑", command=_del,
                              bg=SEL_BG, fg=RED, relief="flat",
                              font=("Segoe UI", 9), cursor="hand2", bd=0)
        _del_btn.grid(row=ridx, column=4, pady=1, padx=(2, 0))

    def _w3_fetch_from_cm(self):
        """Fetches rooms + mapping from the CM, updates config and table."""
        endpoint = self._w3_endpoint.get().strip()
        token    = self._w3_token.get().strip()
        hotel_id = self._w3_hotel_id.get().strip()
        if not endpoint or not token or not hotel_id:
            self._w3_fetch_status.config(
                text=tr_("⚠ Fill in URL endpoint, API token and Hotel ID first."),
                fg=ORANGE)
            return
        self._w3_fetch_status.config(text=tr_("⏳ Connecting to the CM…"), fg=YELLOW)

        # Save the CM credentials into the config immediately
        # (otherwise lost if the user does not validate step 3 via "Next")
        cm_persist = self._app_config.setdefault("channel_manager", {})
        cm_persist["endpoint"]  = endpoint
        cm_persist["api_token"] = token
        cm_persist["hotel_id"]  = hotel_id
        cm_persist["currency"]  = self._app_config.get("hotel_currency", "INR")
        cm_persist["type"]      = _cm_type_from_display(self._w3_type_v.get())
        try:
            self._save_cfg(self._app_config)
        except Exception:
            pass

        # Build a temporary cfg for get_room_info
        tmp_cfg = {
            "endpoint":   endpoint,
            "api_token":  token,
            "hotel_id":   hotel_id,
            "currency":   self._app_config.get("hotel_currency", "INR"),
            "type":       _cm_type_from_display(self._w3_type_v.get()),
            "format":     "json",
            "method":     "POST",
            "test_mode":  False,
        }

        def _task():
            try:
                from business.channel_manager import get_room_info
                ok, msg, body = get_room_info(tmp_cfg)
            except Exception as e:
                self.after(0, lambda err=str(e): self._w3_fetch_status.config(
                    text=f"❌ {tr_('Error')}: {err[:60]}", fg=RED))
                return

            # ── Authentication error detection in the body ─────────
            body_low = (body or "").lower()
            auth_errors = {
                "unauthorized":        tr_("❌ Invalid API token or Hotel ID"),
                "10001":               tr_("❌ Authentication refused by the CM"),
                "invalid credential":  tr_("❌ Invalid CM credentials"),
                "invalid auth":        tr_("❌ Invalid authentication"),
                "permission denied":   tr_("❌ Access denied — check the token permissions"),
                "access denied":       tr_("❌ Access denied"),
                "hotel not found":     tr_("❌ Hotel ID not found in the CM"),
                "invalid hotel":       tr_("❌ Invalid Hotel ID"),
            }
            for keyword, error_msg in auth_errors.items():
                if keyword in body_low:
                    detail = f"\n{tr_('Raw response')}: {body[:120]}" if body else ""
                    self.after(0, lambda em=error_msg, d=detail:
                        self._w3_fetch_status.config(
                            text=f"{em}\n{tr_('Check API token + Hotel ID.')}{d}",
                            fg=RED))
                    return

            # Parse JSON then XML as fallback
            rooms = []
            try:
                import json as _json
                data = _json.loads(body)
                for r in data.get("Rooms", []):
                    rname    = r.get("RoomName", "")
                    rid      = str(r.get("RoomId", ""))
                    count    = int(r.get("TotalRooms",
                               r.get("RoomCount",
                               r.get("NumberOfUnits", 0))) or 0)
                    for rp in r.get("RoomRatePlans", [r]):
                        rooms.append({
                            "name":         rname,
                            "room_id":      rid,
                            "count":        count,
                            "rate_plan_id": str(rp.get("RatePlanId", "")),
                        })
            except Exception:
                try:
                    import xml.etree.ElementTree as _ET
                    root_xml = _ET.fromstring(body)
                    for rd in root_xml.findall(".//RoomData"):
                        rname = (rd.findtext("RoomName") or "").strip()
                        rid   = (rd.findtext("RoomId")   or "").strip()
                        count = int(rd.findtext("TotalRooms") or
                                    rd.findtext("NumberOfUnits") or 0)
                        for rp in rd.findall(".//RoomRatePlanData"):
                            rooms.append({
                                "name":         rname,
                                "room_id":      rid,
                                "count":        count,
                                "rate_plan_id": (rp.findtext("RatePlanId") or "").strip(),
                            })
                except Exception as xe:
                    self.after(0, lambda e=str(xe): self._w3_fetch_status.config(
                        text=f"❌ {tr_('Unreadable response')}: {e[:50]}", fg=RED))
                    return

            if not rooms:
                self.after(0, lambda: self._w3_fetch_status.config(
                    text=f"⚠ {tr_('No room found.')} {msg[:40]}", fg=ORANGE))
                return

            # ── Also fetch the OTAs associated with each rate plan ────────
            # (separate /otaInfo call — same logic as the Channel Manager tab)
            ota_rows = []  # [(room_id, rate_plan_id, ota_code, ota_name), ...]
            try:
                import json as _json2
                from business.channel_manager import get_ota_info
                _ok2, _msg2, body2 = get_ota_info(tmp_cfg)
                data2 = _json2.loads(body2)
                for orr in data2.get("OTARooms", []):
                    rid2 = str(orr.get("RoomId", ""))
                    rp2  = str(orr.get("RatePlanId", ""))
                    for o in orr.get("OTAs", []):
                        ota_rows.append((rid2, rp2, str(o.get("OTACode", "")), o.get("OTAName", "")))
            except Exception:
                pass  # not an issue if /otaInfo fails — rate plans are kept without OTA

            # Import into the config
            added       = 0
            updated     = 0
            mapped      = 0
            existing    = [r if isinstance(r, str) else r.get("type", "")
                           for r in self._app_config.get("room_types", [])]
            cm_cfg      = self._app_config.setdefault("channel_manager", {})
            mapping_cfg = cm_cfg.setdefault("room_mapping", {})
            inv_cfg     = self._app_config.setdefault("room_inventory", {})

            # Group all rows (one per rate plan) by room name
            rooms_by_name = {}
            for r in rooms:
                name = r["name"].strip()
                if not name:
                    continue
                rooms_by_name.setdefault(name, []).append(r)

            for name, r_list in rooms_by_name.items():
                first = r_list[0]
                # Add to room_types / inventory (once per room)
                if name not in existing:
                    self._app_config.setdefault("room_types", []).append(name)
                    existing.append(name)
                    inv_cfg[name] = {
                        "count":   first["count"] or 1,
                        "floor":   0,
                        "ceiling": 0,
                    }
                    added += 1
                elif first["count"]:
                    inv_cfg.setdefault(name, {})["count"] = first["count"]
                    updated += 1

                # Do not overwrite a mapping already filled manually
                if name in mapping_cfg and mapping_cfg[name].get("room_code"):
                    continue

                # A rate_plans with one entry per OTA associated with each rate plan
                rate_plans = []
                for r in r_list:
                    rpid = r["rate_plan_id"]
                    if not rpid:
                        continue
                    otas_for = [(oc, on) for (rid2, rp2, oc, on) in ota_rows
                                if rid2 == r["room_id"] and rp2 == rpid]
                    if otas_for:
                        for oc, on in otas_for:
                            rate_plans.append({
                                "ota_name":         on,
                                "ota_code":         oc,
                                "rate_plan_code":   rpid,
                                "ota_discount_pct": 0,
                            })
                    else:
                        rate_plans.append({
                            "ota_name": "", "ota_code": "",
                            "rate_plan_code": rpid, "ota_discount_pct": 0,
                        })
                mapping_cfg[name] = {
                    "room_code":  first["room_id"],
                    "rate_plans": rate_plans,
                }
                mapped += 1

            # Save + refresh the table
            try:
                self._save_cfg(self._app_config)
            except Exception:
                pass

            def _finish():
                self._w3_rebuild_mapping_table()
                self._w3_fetch_status.config(
                    text=f"✅ {len(rooms)} {tr_('room(s)')} — {added} {tr_('added')}, "
                         f"{updated} {tr_('updated')}, {mapped} {tr_('mapped')}",
                    fg=GREEN)
            self.after(0, _finish)

        threading.Thread(target=_task, daemon=True).start()

    def _w3_test_conn(self):
        endpoint = self._w3_endpoint.get().strip()
        token    = self._w3_token.get().strip()
        if not endpoint:
            self._w3_test_status.config(text=tr_("⚠ Missing endpoint URL"), fg=ORANGE)
            return
        self._w3_test_status.config(text=tr_("⏳ Test in progress…"), fg=YELLOW)
        def _task():
            import requests as _req, time
            headers = {"Content-Type": "application/json"}
            if token: headers["Authorization"] = f"Bearer {token}"
            t0 = time.time()
            try:
                r  = _req.get(endpoint, headers=headers, timeout=10)
                ms = int((time.time() - t0) * 1000)
                self.after(0, lambda: self._w3_test_status.config(
                    text=f"✅ HTTP {r.status_code} — {ms} ms", fg=GREEN))
            except Exception as e:
                self.after(0, lambda e=e: self._w3_test_status.config(
                    text=f"❌ {str(e)[:60]}", fg=RED))
        threading.Thread(target=_task, daemon=True).start()

    def _validate_step_6(self):
        endpoint = self._w3_endpoint.get().strip()
        token    = self._w3_token.get().strip()
        if not endpoint:
            messagebox.showwarning(tr_("Missing field"),
                tr_("The Channel Manager endpoint URL is required."), parent=self)
            return False
        if not endpoint.startswith("https://"):
            messagebox.showwarning(tr_("Insecure URL"),
                tr_("The URL must start with https:// to protect your token."),
                parent=self)
            return False
        cm = self._app_config.setdefault("channel_manager", {})
        cm["type"]       = _cm_type_from_display(self._w3_type_v.get())
        cm["endpoint"]   = endpoint
        cm["api_token"]  = token
        cm["hotel_id"]   = self._w3_hotel_id.get().strip()
        cm["requestor_id"] = "OTAGuard"
        cm["currency"]   = self._app_config.get("hotel_currency", "INR")
        cm["test_mode"]  = self._w3_test_mode.get()
        cm["format"]     = "json"
        cm["method"]     = "POST"
        mapping = {}
        for room, vars_ in self._w3_mapping_vars.items():
            rc = vars_["room_code"].get().strip()
            rate_plans = []
            for rp_v in vars_.get("rate_plans", []):
                rpc = rp_v["rate_plan_code"].get().strip()
                if not rpc:
                    continue
                try:
                    disc = float(rp_v["ota_discount_pct"].get().strip().replace(",", ".") or 0)
                except (ValueError, TypeError):
                    disc = 0.0
                rate_plans.append({
                    "ota_name":         rp_v["ota_name"].get().strip(),
                    "ota_code":         rp_v["ota_code"].get().strip(),
                    "rate_plan_code":   rpc,
                    "ota_discount_pct": disc,
                })
            mapping[room] = {"room_code": rc, "rate_plans": rate_plans}
        cm["room_mapping"] = mapping
        self._save_cfg(self._app_config)
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 7 — Theme
    # ─────────────────────────────────────────────────────────────────────────

    def _build_step_7(self, parent):
        outer, inner = self._scrolled(parent)
        outer.pack(fill="both", expand=True, padx=20, pady=10)
        self._section_title(inner, "🎨 Interface theme")
        tk.Label(inner,
                 text=tr_("Click a theme to apply it instantly to the window."),
                 bg=BG, fg="#888888", font=("Segoe UI", 9)
                 ).pack(anchor="w", pady=(0, 10))

        from core.theme import THEMES
        current = self._app_config.get("theme", "Catppuccin Mocha")
        self._w8_theme_var = tk.StringVar(value=current)
        self._w8_rows      = {}
        self._w8_radios    = {}

        for name, theme_data in THEMES.items():
            t_bg       = theme_data.get("BG",       BG)
            t_fg       = theme_data.get("FG",       FG)
            t_accent   = theme_data.get("ACCENT",   ACCENT)
            t_entry_bg = theme_data.get("ENTRY_BG", ENTRY_BG)

            # Clickable card with a small color preview
            card = tk.Frame(inner, bg=t_bg, padx=10, pady=8,
                            highlightthickness=2,
                            highlightbackground=t_accent if name == current else SEL_BG)
            card.pack(fill="x", pady=3)

            # Radio + name
            left = tk.Frame(card, bg=t_bg)
            left.pack(side="left", fill="x", expand=True)

            rb = tk.Radiobutton(
                left, text=name,
                variable=self._w8_theme_var, value=name,
                bg=t_bg, fg=t_fg,
                selectcolor=t_entry_bg,
                activebackground=t_bg, activeforeground=t_accent,
                font=("Segoe UI", 10, "bold"),
                command=lambda n=name: self._w8_select(n))
            rb.pack(side="left", anchor="w")

            # Color dots (preview)
            right = tk.Frame(card, bg=t_bg)
            right.pack(side="right")
            for color_val in (theme_data.get("ACCENT", ACCENT),
                              theme_data.get("GREEN",  GREEN),
                              theme_data.get("ORANGE", ORANGE),
                              theme_data.get("RED",    RED)):
                tk.Label(right, text="●", bg=t_bg, fg=color_val,
                         font=("Segoe UI", 14)).pack(side="left", padx=2)

            # Description
            desc = theme_data.get("desc", "")
            if desc:
                tk.Label(card, text=tr_(desc), bg=t_bg, fg=t_fg,
                         font=("Segoe UI", 8, "italic"),
                         anchor="w").pack(side="bottom", fill="x", pady=(4, 0))

            # Click on the card = select
            def _on_click(_e, n=name):
                self._w8_theme_var.set(n)
                self._w8_select(n)
            for w in (card, left, right):
                w.bind("<Button-1>", _on_click)

            self._w8_rows[name]   = card
            self._w8_radios[name] = rb

    def _w8_select(self, name):
        """Applies the theme immediately to the wizard window."""
        from core.theme import THEMES, T
        theme_data = THEMES.get(name)
        if not theme_data:
            return

        # Update the module global variables for future renders
        global BG, FG, ENTRY_BG, SEL_BG, ACCENT, GREEN, RED, ORANGE, YELLOW
        BG       = theme_data.get("BG",       BG)
        FG       = theme_data.get("FG",       FG)
        ENTRY_BG = theme_data.get("ENTRY_BG", ENTRY_BG)
        SEL_BG   = theme_data.get("SEL_BG",   SEL_BG)
        ACCENT   = theme_data.get("ACCENT",   ACCENT)
        GREEN    = theme_data.get("GREEN",    GREEN)
        RED      = theme_data.get("RED",      RED)
        ORANGE   = theme_data.get("ORANGE",   ORANGE)
        YELLOW   = theme_data.get("YELLOW",   YELLOW)

        # Apply to the global theme (impacts the rest of the app)
        T.apply(name)

        # Save into the config to persist
        self._app_config["theme"] = name
        try:
            self._save_cfg(self._app_config)
        except Exception:
            pass

        # Recolor the wizard window
        try:
            self.configure(bg=BG)
            self._content_frame.configure(bg=BG)
            # Re-render the step with the new colors
            self._show_step(self._step)
        except Exception:
            pass

    def _validate_step_7(self):
        name = self._w8_theme_var.get()
        self._app_config["theme"] = name
        self._save_cfg(self._app_config)
        from core.theme import T
        T.apply(name)
        return True



# ══════════════════════════════════════════════════════════════════════════════
# WIKI OTA GUARD
# ══════════════════════════════════════════════════════════════════════════════

WIKI_ARTICLES = {
    "🚫 Blocage prix OTA": "OTA PRICE GUARD — PRICE MONITORING AND CORRECTION\n════════════════════════════════════════════════════\n\nThis is the main tab of the software. It reads the prices\ndisplayed on your OTA listings, compares them to the target prices\nyou define, and corrects through your Channel Manager.\n\nThe tab contains 4 sections, described one by one.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nTEST MODE BANNER\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nWhile the Channel Manager is in test mode, a pink\nbanner is shown at the top of the tab:\n\"🧪 TEST MODE ACTIVE — no price is sent to the Channel\nManager. Shipments are simulated.\"\nIt disappears as soon as you switch to real mode.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 1: 🎯 MY HOTEL MONITORING — REAL PRICE ON OTA\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"🔄 Refresh\" button: re-detects the OTA tabs\n  open in Brave. Use it after opening a\n  new OTA listing in the browser.\n\n• Detected OTA list: each row shows the name\n  of the OTA, an excerpt of its URL, and an \"Active\" checkbox.\n  - 🟢 in front of the name = OTA detected in Brave.\n  - ➕ in front of the name = OTA added manually.\n  - The \"Active\" checkbox enables or disables the monitoring\n    of this OTA without removing it.\n  - If no OTA is detected, a red message invites you\n    to open your hotel's pages in Brave.\n\n• \"Target prices per room\" grid: your rooms in\n  rows, one column per OTA. Type in each cell\n  the price the guest must see on this OTA.\n  - The price sent to the CM is not the target price: the\n    software measures what the OTA does with each shipment,\n    then adjusts step by step toward the target. Each computation\n    is detailed in the journal (🧮 lines).\n  - Goibibo and MakeMyTrip share a single column\n    \"MakeMyTrip / Goibibo\" (shared inventory, one single\n    CM price).\n\n• \"Automatic correction\" checkbox: after each scan, the\n  gaps are corrected at the CM without intervention.\n\n• \"Interval: X h Y min\": periodicity of the\n  automatic scan.\n\n• \"Correct if gap ≥ ₹ X\": minimal gap threshold\n  triggering a correction. Below it, nothing is\n  touched.\n\n• \"📅 Observe prices for a stay in: D+0, D+1,\n  D+3, D+7, D+10, D+15\": date of the stay observed during\n  the scan. If a room is not found at that date,\n  the scan automatically tries other dates.\n\n• \"📅 Apply the new prices from: D+X\n  for N day(s)\": date range covered by the\n  corrections sent to the CM (e.g. D+0 = today,\n  for 90 days).\n\n• \"🗓️ Markup:\": tick the checkbox, choose the days\n  (Mon to Sun) and the percentage (+X %) applied to\n  the week-end shipments.\n\n• \"🔄 Auto calibration if floor violated\": after each\n  scan, if an OTA displays a price below the floor, the\n  software sends a higher price, waits for the set\n  delay (\"Delay between checks\"), re-scans and adjusts\n  until it is back above the floor (\"Max\n  attempts\"). Each attempt is capped at +₹150.\n\n• \"🚀 Push & Correct\" button: immediately starts the\n  correction of all the detected gaps.\n\n• \"🔍 Scan now\" button: runs an immediate\n  scan without waiting for the automatic interval.\n\n• \"Last scan results\" table: one row per\n  OTA/room with 7 columns — OTA, Room, Target\n  price, Detected price, Gap, To send to CM, Status.\n  - Green = OK, red = too low, orange = too high.\n  - Double-click on a row = correct that single\n    room.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 2: 📋 LATEST SHIPMENTS TO THE CHANNEL MANAGER\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nJournal of the last 30 shipments to the CM — manual or\nautomatic. Each row shows: ✅ or ✗ according to the\nresult, the date and time, the source (OTA price guard,\nOTA calibration…), the target OTA, the rooms and prices\nsent, and the response message from the CM.\n\n• \"🔄 Refresh\" button: reloads the journal.\n• \"🗑 Clear\" button: empties the shipment history.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 3: 🛡️ OTA PRICE FLOOR & CEILING PROTECTION\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nRule: OTA too low → the system raises the rate via\nthe CM. OTA too high → the system lowers the rate via the CM.\n\n• Per-room table with 5 columns: Room,\n  Floor ▼, Ceiling ▲, Min CM shipment, Max CM shipment.\n\n• \"✏ Floor\" button: edits the minimum price of a\n  room (select the row first).\n• \"✏ Ceiling\" button: edits the maximum price.\n• \"✏ Min CM\" / \"✏ Max CM\" buttons: bound the amounts\n  actually sent to the CM (0 = automatic computation).\n\n• \"Automatic monitoring at scan time (alert\n  only)\" checkbox: after each scan, the out-of-bounds prices are\n  flagged in the journal and sent as an alert (email,\n  Telegram, phone) — but nothing is modified.\n\n• \"🔍 Check violations\" button: immediate control\n  of the overruns.\n\n• \"⚠ Also send the corrections to the Channel\n  Manager\" checkbox: the out-of-bounds prices are corrected\n  automatically at the CM, without confirmation. Leave\n  this checkbox unchecked while you verify that the\n  detections are accurate.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 4: 📡 PER-OTA PRICES — CHANNEL MANAGER\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nOne card per OTA (Agoda excluded) to manage prices and\nindependent shipments, which go through your Channel\nManager.\n\nEach card contains:\n\n• Checkbox + badge \"✅ ACTIVE\" / \"⏸ INACTIVE\": enables or\n  disables the automatic shipments of this OTA.\n• \"CM code: X\": the OTA code used by the CM.\n• Per-room table: Room, Floor ₹, Price ₹\n  (the price you decide to send), Ceiling ₹,\n  Last shipment (date of the last push).\n• \"Trigger:\" of your choice:\n  - \"Manual — I click myself\": nothing goes out without\n    your click.\n  - \"Once a day at a fixed time\": automatic daily\n    shipment at the time of the \"Time:\" field (default\n    12:00).\n• \"Period:\" buttons +3d, +7d, +15d, +30d which\n  fill the end date, or free entry of the\n  date in DD/MM/YYYY format.\n• \"🗓️ Markup:\": week-end markup specific to this\n  OTA (checkbox, days, +X %).\n• \"📤 Push\" button: immediately sends the prices\n  of this card to the CM.\n• \"💾 Save\" button: saves the settings of\n  the card.\n\nTIP: start by filling the target price\ngrid, scan, and check the results table\nbefore enabling automatic correction. Adjust the\n\"Correct if gap ≥\" threshold to avoid corrections\nfor a few rupees.\n",
    "🏨 Mon Hôtel": "MY HOTEL — SET UP YOUR PROPERTY\n════════════════════════════════════════════════════\n\nThis tab defines your hotel and your rooms. All the\nother tabs read this information. A green band\nreminds you: \"⚠ Remember to save after every\nchange\", with the \"💾 Save\" button.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 1: GENERAL INFORMATION\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"Hotel name\": the official name (e.g. Jangala\n  Resort). This is the name that identifies your hotel in\n  all the menus.\n\n• \"City\" and \"Country\": location of the property.\n\n• \"Type:\": dropdown — Guest House, Beach Resort,\n  Boutique Hotel, Budget Hotel, Luxury Hotel, Hostel,\n  Villa, Homestay.\n\n• \"Check-in:\" and \"Check-out:\": arrival and\n  departure times (defaults 14:00 and 11:00 — entry in 24 h or AM/PM).\n\n• \"Currency:\": dropdown — INR, USD, EUR, GBP, THB,\n  AED, SGD. This currency is used everywhere: target\n  prices, floors, ceilings, CM shipments.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 2: ROOM TYPES & PRICE FLOOR / CEILING\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nA table with one row per room type and 6\ncolumns:\n\n• \"Room name\": the internal name of the category\n  (e.g. Double Room).\n• \"No. of rooms\": how many rooms of this type the hotel has.\n• \"Floor\": minimum price below which no OTA\n  must sell.\n• \"Ceiling\": maximum price above which no OTA\n  must sell.\n• \"Breakfast\": three choices — \"No breakfast\",\n  \"With breakfast\" or \"Both\" (if the room sells\n  with and without breakfast).\n• \"CM test\": checkbox that marks the room as a test\n  room — it is excluded from the real shipments, useful\n  to train without risk.\n\nThree buttons under the table:\n\n• \"+ Add a room\": adds an empty row.\n• \"💾 Apply\": saves the rooms and prices without\n  closing the menu.\n• \"🔗 Room names on the OTAs\": opens a dialog\n  that tells the software which OTA room matches\n  which room of your hotel, from the names read\n  in the last scan. This is where the mappings are set\n  when an OTA names your rooms\n  differently from your internal name.\n\nTIP: configure this tab first — the room\nlist feeds the target price grid, the\nfloors and the CM mapping. Click \"💾 Apply\" or\n\"💾 Save\" after every change.\n",
    "🔌 Channel Manager": "CHANNEL MANAGER — CONNECTION TO YOUR MANAGER\n════════════════════════════════════════════════════\n\nThe Channel Manager (CM) receives the corrected prices and\nredistributes them to your OTAs. This tab configures the\nconnection, lets you test it room by room, and\nmaps your rooms to the CM codes.\n\nA banner at the top permanently shows the active mode:\nTEST (no real shipment) or REAL (prices sent to the CM).\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 1: 🔌 CHANNEL MANAGER CONNECTION\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"CM type\": dropdown of the Channel Manager type.\n• \"URL endpoint\": the API address provided by your\n  CM provider.\n• \"API token / key\": your authentication key\n  (masked on screen).\n• \"Method\": POST, PUT or PATCH — according to the\n  documentation of your CM.\n• \"Hotel ID / Code\": your hotel identifier at the CM.\n• \"Currency\": shown read-only — it is\n  defined in My Hotel, single source.\n• \"Format:\" JSON or XML.\n\nSend mode — two radio buttons:\n• \"🧪 TEST MODE (no real shipment)\": everything is simulated,\n  no price is modified. Recommended starting\n  mode.\n• \"🔴 REAL MODE (prices sent to the CM)\": the shipments\n  actually modify your prices online.\n\nAction buttons:\n• \"📤 Push the prices\": immediately sends the computed\n  prices to the CM (⚠ real action).\n• \"💾 Save the configuration\": saves the\n  connection.\n• \"🔌 Test the connection\": checks that the CM responds.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 2: 🧪 CHANNEL MANAGER TEST ZONE\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nA \"Test journal\" at the top shows the result of\neach test, with a \"🗑 Clear log\" button.\n\nFour sub-tabs:\n\n1 — Connection:\n  • \"🔌 Test GET\": GET request to check that\n    the endpoint responds.\n  • \"🔌 Test empty POST\": POST without data to\n    test the authentication without modifying any price.\n\n2 — Per-room test:\n  • \"Room:\": dropdown of your rooms, with\n    \"Move room\" first — virtual room of the CM\n    to test without touching your real rooms.\n  • \"Price ₹:\": the test price to send.\n  • \"Room Code CM:\": shown only for Move\n    room or a room without a defined mapping.\n  • \"Arrival date:\" and \"Nights:\": the test stay.\n  • \"👁 Preview only\": shows what would be\n    sent without sending anything.\n  • \"📤 Send to the Channel Manager\": real shipment of the\n    test price.\n\n3 — From scan:\n  Shows the date of the last scan and the number of\n  competitors analyzed.\n  • \"🔍 See the full pipeline\": shows all the\n    steps scan data → payload → CM shipment.\n  • \"📤 Dry Run (simulation)\": simulates the shipment without\n    modifying anything.\n\n4 — Raw payload:\n  • Text area to paste a manual JSON/XML\n    payload.\n  • \"📤 Send raw payload\": sends it as-is to\n    the endpoint.\n  • \"♻ Generate from template\": fills the area with\n    a ready-to-modify example.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSECTION 3: 🗺 ROOM MAPPING → CHANNEL MANAGER\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nMaps each OTA Guard room to its CM codes.\n\n• \"📥 Retrieve Rooms from CM\" button: queries the API\n  of the Channel Manager and shows the list of the available\n  rooms and rate plans — the fastest\n  and safest way to fill the mapping.\n\nFor each room:\n  • \"Room Code CM\": the identifier of the room at\n    the CM.\n  • Several rate plan rows, each with:\n    - the OTA name (e.g. Agoda, Expedia, AirBnB),\n    - the \"OTA code\" (identifier of the OTA at the CM,\n      e.g. 23 = Agoda, 29 = Expedia),\n    - the \"Rate Plan Code\" (the CM rate code),\n    - the \"OTA discount %\": discount applied by the OTA\n      on the sent rate — the software computes\n      automatically the right price to send to the CM to\n      compensate.\n\nWhen an OTA code is filled on a row, the shipment\ntargets only that OTA.\n\nTIP: configure the connection, test it (tab 1),\nthen validate a shipment on \"Move room\" (tab 2) before\nswitching to REAL MODE. Check the OTA codes and rate\nplans with your CM support if a price does not arrive\non an OTA.\n",
    "🔧 Paramètres": "SETTINGS — GENERAL SETTINGS\n════════════════════════════════════════════════════\n\nFive sections, top to bottom.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎨 INTERFACE THEME\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"Active theme:\": dropdown of the themes. The current theme\n  is marked \"★ active\".\n• A color square next to it shows the tint of the\n  selected theme (preview before applying).\n• \"✔ Apply\" button: applies the theme and restarts the\n  software.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🌐 LANGUAGE\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"Active language:\": dropdown of the interface\n  languages (the current language is marked ★).\n• \"✔ Apply\" button: saves the language and restarts\n  the application.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🔑 LICENSE\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• Status shown in color:\n  - \"🆓 Free trial — X day(s) remaining\"\n  - \"✅ License active (type) — expires: date\"\n  - \"⛔ Trial expired — enter your license key\"\n  - \"⛔ License expired on [date]\"\n• \"Machine ID:\": unique identifier of your PC,\n  shown read-only. The 📋 button copies it to\n  the clipboard — this is the ID you will be asked\n  to generate your license key.\n• \"🔑 Enter a license key\" button: opens the\n  activation window with your machine ID reminded,\n  a \"License key:\" field and the \"🔑\n  Activate\" button. On success, the software restarts\n  with the license active.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n💾 BACKUP & RESTORE\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"📤 Export backup\" button: creates a ZIP file\n  containing your whole configuration, your databases and\n  your history. Ideal for a USB key or a\n  transfer to another PC.\n• \"📥 Import backup\" button: restores a ZIP —\n  a confirmation is asked because the operation\n  replaces the whole current configuration.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🔄 COMPONENT UPDATES\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"🔍 Check now\" button: lists the available\n  updates for the internal components.\n• \"⬆ Update all\" button: applies the listed\n  updates.\n• \"🔄 Check OTA Guard updates\" button: looks for a\n  new version of the software and offers its\n  installation if any.\n\nNote: on the compiled (installed) version, the internal\ncomponent updates are unavailable — only the OTA Guard\nupdate check stays active.\n\nTIP: export a backup as soon as your\nconfiguration is complete, and note your machine ID\nbefore switching computers — your license is\nlinked to it.\n",
    "🌐 Extranet Direct (sans API)": "EXTRANET DIRECT — DRIVE THE CM WITHOUT AN API KEY\n════════════════════════════════════════════════════\n\nThis tab drives the web interface of your Channel\nManager like a human would: the software fills\nthe real form in your Brave browser, box by\nbox, digit by digit. No API key is\nneeded — useful when your CM does not provide one or\nwhen its usage is billed per request.\n\nPREREQUISITES: Brave open with your CM session logged in,\nthe BulkUpdate and OTASheet tabs of the CM open. Never\nclose these tabs: the software opens and closes none of\nthem.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nMAIN BUTTONS\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"📥 Load the state\": passively reads the CM grid\n  (rooms, connected OTAs, current prices per date). If the\n  grid is not fresh, the OTASheet tab is woken up\n  automatically then read again.\n\n• \"BLANK TEST\": fills the whole CM form\n  under your eyes (room, OTA, dates, price) but DOES NOT CLICK\n  Update. Nothing is sent — it is the general\n  rehearsal, ideal to verify the configuration.\n\n• \"APPLY (real)\": after a confirmation window\n  recalling the exact parameters, fills the form\n  AND validates. The shipment is then verified on the grid:\n  the journal shows \"verified on the grid\" when the\n  new price is properly set.\n\n• Live journal: every action (read, click, shipment,\n  verification) is traced there line by line.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nTRANSPORT: API OR EXTRANET\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nIn the Channel Manager tab, the \"Transport:\" row\ndecides which way the automatic corrections go:\n🔑 CM API (API keys) or 🌐 Extranet Direct. The status is\nrecalled at the top of this tab. Only one shipment queue at\na time: a second shipment started while another one\nis running is cleanly refused.\n\nTIP: keep the Brave window open (it may\nstay in the background) and disable the automatic\ntranslation for the CM site — a translated page may\nrename the labels and hinder the filling.",
    "📅 Tarifs saisonniers": "SEASONAL RATES — LOCKED PRICES PER PERIOD\n════════════════════════════════════════════════════\n\nThis tab defines prices for specific periods\n(high season, Christmas, local events). A seasonal\nprice is LOCKED: the automatic corrections\nof the OTA price guard tab never overwrite it, even\nif an OTA shows a gap on those dates.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nUSAGE\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"➕ Add an event\": creates a period — name, start\n  date, end date, and the per-room price. Several\n  periods can follow one another (e.g. Christmas then New Year).\n\n• \"📤 Push the locked prices\": immediately sends\n  the period prices to the Channel Manager (⚠ real shipment —\n  keep the CM TEST mode while verifying).\n\n• \"💾 Save\": saves your periods.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nGOOD TO KNOW\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• During a locked period, the software keeps\n  MONITORING the OTA prices normally: it flags the\n  gaps but never corrects those dates.\n• Outside the period, your usual automatic\n  corrections apply unchanged.\n\nTIP: book your high-season periods as soon as the\nsoftware is set up — it is the simplest\nprotection against automatic corrections based on\nlow-season prices.",
    "📱 App mobile": "MOBILE APP — ALERTS AND CONTROL FROM YOUR PHONE\n════════════════════════════════════════════════════\n\nThis tab connects OTA Guard to the companion mobile\napplication (Firebase). The phone receives the alerts\n(price gaps, corrections sent, floor/ceiling\nviolations) and can remotely drive some actions.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nCONFIGURATION (ONLY ONCE)\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n• \"Service account file\": the JSON downloaded\n  from the Firebase Console (Admin SDK). \"📂 Load\n  the JSON file\" button then \"🔌 Test the connection\".\n\n• \"google-services.json\": import the file provided by\n  the Firebase Console — the 5 fields of the form fill\n  automatically.\n\n• \"📷 Show the QR\": a QR code is displayed — scan it\n  from the OTA Guard mobile app to pair the\n  phone with this PC.\n\n• \"❓ Setup help\": complete step-by-step guide.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nALERTS\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nThe alert list is checkable: uncheck the ones you\ndo not want to receive on the phone anymore (e.g. the\nminor corrections). The alerts also go out via\nemail/Telegram if configured elsewhere.\n\nTIP: test the connection after each file\nimport and finish with \"💾 Save\" — the Firebase\nkeys are no longer shown in plain text after\nsaving."
}


def _wiki_topic_labels():
    # Literals passed directly to tr_() — needed so that
    # tools/i18n_extract.py discovers these strings (topic_key is a variable
    # passed dynamically from the "Wiki" buttons of the tabs, invisible
    # to the AST extractor).
    return (
        tr_("🔧 Paramètres"),
        tr_("🚫 Blocage prix OTA"),
        tr_("🔌 Channel Manager"),
        tr_("🏨 Mon Hôtel"),
        tr_("🌐 Extranet Direct (sans API)"),
        tr_("📅 Tarifs saisonniers"),
        tr_("📱 App mobile"),
    )


def show_wiki(parent, topic_key):
    """Shows a wiki article in a popup window.
    The content is translated automatically according to the active language.
    """
    # Import tr_ for the translation (Google Translate + local cache)
    try:
        from core.utils import tr_ as _tr
    except Exception:
        def _tr(s): return s

    dlg = tk.Toplevel(parent)
    dlg.title(f"📖 Wiki — {_tr(topic_key)}")
    dlg.configure(bg=BG)
    dlg.grab_set()
    dlg.after(0, lambda: _center_window(dlg, w=700, h=520))

    header_lbl = tk.Label(dlg, text=f"📖  {_tr(topic_key)}", bg=BG, fg=ACCENT,
                           font=("Segoe UI", 12, "bold"))
    header_lbl.pack(anchor="w", padx=16, pady=(12, 4))
    tk.Frame(dlg, bg=SEL_BG, height=1).pack(fill="x", padx=16, pady=(0, 8))

    def _refresh_header():
        """Refreshes the title and header once the topic_key is translated
        (otherwise they stay frozen in the source language, unlike the article body)."""
        translated_topic = _tr(topic_key)
        dlg.title(f"📖 Wiki — {translated_topic}")
        header_lbl.config(text=f"📖  {translated_topic}")

    # Loading indicator (visible during the translation on first display)
    loading_lbl = tk.Label(dlg, text="", bg=BG, fg=YELLOW,
                            font=("Segoe UI", 9, "italic"))
    loading_lbl.pack(padx=16)

    txt_frame = tk.Frame(dlg, bg=BG)
    txt_frame.pack(fill="both", expand=True, padx=16, pady=(0, 8))
    sb = ttk.Scrollbar(txt_frame, orient="vertical")
    sb.pack(side="right", fill="y")
    txt = tk.Text(txt_frame, bg=ENTRY_BG, fg=FG, font=("Segoe UI", 10),
                  relief="flat", wrap="word", padx=14, pady=10,
                  yscrollcommand=sb.set, state="normal", insertbackground=FG)
    sb.config(command=txt.yview)
    txt.pack(fill="both", expand=True)

    txt.tag_configure("title", font=("Segoe UI", 11, "bold"), foreground=ACCENT)
    txt.tag_configure("h2",    font=("Segoe UI", 10, "bold"), foreground=YELLOW)
    txt.tag_configure("body",  font=("Segoe UI", 10),         foreground=FG)
    txt.tag_configure("tip",   font=("Segoe UI", 10),         foreground=GREEN)

    content = WIKI_ARTICLES.get(topic_key, _tr("No article available for this topic."))

    # Check if the language is the source language → no need to translate
    try:
        from lang import _lang_code as _cur_lang
    except Exception:
        _cur_lang = "fr"

    def _render(content_text):
        """Renders the content into the Text widget with color coding."""
        txt.config(state="normal")
        txt.delete("1.0", "end")
        for i, line in enumerate(content_text.split("\n")):
            if i == 0:
                txt.insert("end", line + "\n", "title")
            elif line.startswith("══") or line.startswith("━━"):
                txt.insert("end", line + "\n", "h2")
            elif any(line.startswith(p) for p in
                     ("CONSEIL", "RÉSULTAT", "AVANTAGE", "POURQUOI",
                      "IMPORTANT", "TIP", "RESULT", "BENEFIT", "WHY")):
                txt.insert("end", line + "\n", "tip")
            else:
                txt.insert("end", line + "\n", "body")
        txt.config(state="disabled")
        loading_lbl.config(text="")

    if _cur_lang == "fr" or _cur_lang == "":
        _render(content)
    else:
        def _is_translatable(ln):
            return bool(ln.strip()) and not ln.startswith("══") and not ln.startswith("━━")

        translated = [ln if not _is_translatable(ln) else _tr(ln) for ln in content.split("\n")]
        _render("\n".join(translated))
        _refresh_header()
    txt.yview_moveto(0)
    tk.Button(dlg, text=tr_("Close"), command=dlg.destroy,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 9, "bold"),
              relief="flat", padx=12, pady=5, cursor="hand2").pack(pady=(0, 12))
