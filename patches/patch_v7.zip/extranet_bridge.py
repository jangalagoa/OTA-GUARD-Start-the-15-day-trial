"""
Couture « Extranet Direct » (VAE 2) ↔ application — miroir de vae_bridge.py.

Rôle (strictement limité, D1/D14 : aucune modification en profondeur de V2) :
  1. lire l'état du CM depuis les captures passives du listener VAE
     (mêmes fichiers que le scanner vae2 — aucune requête émise, R1/R3) ;
  2. exécuter UNE correction via le coordinateur vae2 (brique 3) dans un
     thread séparé — l'UI Tkinter n'est jamais bloquée ;
  3. après un envoi RÉEL vérifié, enregistrer la mesure dans
     core.send_history pour que la boucle V2 (envoyé → affiché) continue
     de fonctionner exactement comme avec l'API CM.

Toute action réelle reste derrière la validation manuelle du propriétaire
(« Appliquer » dans l'onglet) — plan É4 : validation manuelle d'abord.
"""
import json
import threading
from dataclasses import asdict
from pathlib import Path

from core.utils import tr_  # D60 : messages moteur traduits

# D104 — ancre de chemins : JAMAIS __file__ de CE module. Quand ce fichier
# est servi par le chargeur de patchs, __file__ pointe dans
# %APPDATA%\...\data\patches\ — le « PROJECT_ROOT » dérivé de là rendait
# captures_dir et la carte du CM introuvables sur TOUT exe patché
# (« Channel Manager status : 0 chambres » depuis le patch v2, 06/10).
# core.paths.INSTALL_DIR est l'amorce de démarrage (jamais patchée) et
# connaît toujours le vrai dossier du logiciel, exe OU source.
try:
    from core.paths import INSTALL_DIR as _INSTALL_DIR
    PROJECT_ROOT = Path(_INSTALL_DIR)
except Exception:
    PROJECT_ROOT = Path(__file__).resolve().parent
V3_SANDBOX = PROJECT_ROOT / "sandbox" / "e4"
DEFAULT_CM_MAP = "channelmanager_com_au.yaml"

# D55 : limite produit du canal Extranet Direct (annexe A aux conditions
# de vente, §4-c) : un seul établissement, jusqu'à VINGT chambres. Le
# temps de correction monte lineairement avec le nombre de chambres
# (≈1 h de file pour 4 chambres x 60 jours ; 4-5 h à 20 ; 12 h+ à 50 —
# au-dela le canal n'est pas conçu pour). L'API CM reste le canal des
# grands etablissements. Verifie sur la taille REELLE de l'etablissement
# (chambres de la grille du CM), pas sur l'envoi courant.
EXTRANET_MAX_ROOMS = 20


def active_cm_map(app_config=None):
    """D49 — carte du CM ACTIF (un seul à la fois, contrainte produit :
    VAE2 ne travaille jamais avec plusieurs CM simultanément). Lue dans
    channel_manager.extranet_direct.cm_map (nom de fichier dans
    vae2/maps/), défaut = channelmanager_com_au.yaml. Fichier manquant ou
    invalide → repli silencieux sur le défaut, jamais d'exception au
    milieu d'un push."""
    name = ""
    try:
        if app_config is None:
            from core import config as _cfg
            app_config = _cfg.load()
        name = str((((app_config or {}).get("channel_manager") or {})
                    .get("extranet_direct") or {}).get("cm_map") or "").strip()
    except Exception:
        name = ""
    if not name or "/" in name or "\\" in name or ".." in name \
            or not name.lower().endswith(".yaml"):
        name = DEFAULT_CM_MAP
    cand = PROJECT_ROOT / "vae2" / "maps" / name
    if not cand.exists():
        cand = PROJECT_ROOT / "vae2" / "maps" / DEFAULT_CM_MAP
    return cand

# D56 : arrêt UTILISATEUR de la file en cours (bouton ⏹ Stop) — distinct
# de SHUTDOWN (fermeture de l'app). Pose = la file s'arrête AVANT la
# tâche suivante (jamais au milieu d'une frappe : D12). Effacé au
# démarrage de chaque file.
QUEUE_STOP = threading.Event()

# D33 : arrêt propre des files d'envoi à la fermeture de l'app. Le 27/08,
# un processus à fenêtre fermée (Exit 16:04) a continué à pousser des prix
# jusqu'à 17:29 en parallèle de l'instance relancée — deux exécutants dans
# le même formulaire. L'Exit lève ce drapeau ; les boucles lèvent le pied
# AVANT la tâche suivante (jamais au milieu d'une frappe : D12 reste
# maître jusqu'au bout de la tâche en cours).
SHUTDOWN = threading.Event()


# ── D98 : PAUSE GLOBALE (bouton ⏸ à côté de ⏹) ──────────────────────────────
# L'outil n'empêche RIEN de démarrer tant que paused n'est pas posé : le
# propriétaire travaille sur son PC, Brave saute au premier plan (remontées
# D31/D93, bringToFront, rechargements keepalive, scans naviguant les
# onglets) et il doit re-réduire la fenêtre toutes les quelques minutes.
# PAUSE = sérénité totale :
#   - AUCUNE nouvelle opération (scan / push / correction / vérification)
#     : operation_begin refuse ;
#   - AUCUN rechargement keepalive (la boucle saute, reports de 60 s) ;
#   - AUCUNE remontée OS ni bringToFront ni unthrottle (l'exe ne réveille
#     plus la fenêtre Brave) ;
#   - la tâche EN COURS se termine proprement (D12 : jamais au milieu
#     d'une frappe) — pause ≠ stop.
# Session-only, défaut OFF : une pause oubliée arrêterait la protection
# en silence. Le bouton ⏸/▶ (tab_blocage_ota) pose/lève le drapeau.
PAUSED = threading.Event()


def pause_set() -> None:
    """Pose la pause globale — plus aucune activité, plus de fenêtre volée."""
    PAUSED.set()
    try:
        from diagnostic.recorder import event as _bb
        _bb("pause_on", "info", {})
    except Exception:
        pass


def pause_clear() -> None:
    """Lève la pause globale — l'outil reprend son rythme normal."""
    PAUSED.clear()
    try:
        from diagnostic.recorder import event as _bb
        _bb("pause_off", "info", {})
    except Exception:
        pass


def is_paused() -> bool:
    return PAUSED.is_set()


def request_shutdown():
    """Signalé par l'Exit de l'app (app.py::_on_close) — les files
    d'envoi extranet s'arrêtent avant la tâche suivante."""
    SHUTDOWN.set()


# ── E5 : keep-alive de session (D9) — singleton démarré une seule fois ──────

_KEEPALIVE = None
_KEEPALIVE_LOCK = threading.Lock()

# D37-2 : verrou anti-push parallèle — un SEUL exécutant extranet à la
# fois dans tout le processus (file OU tâche manuelle). Le 28/08
# 13:16-13:25, deux files simultanées ont piloté le même formulaire CDP
# (cases décochées par l'autre, calendrier fermé, champs vidés pendant
# la frappe). D33 couvrait Exit propre + 2e instance, pas deux flux
# push concurrents DANS la même app.
_PUSH_LOCK = threading.Lock()

# D52 : UNE SEULE opération à la fois dans tout le processus (scan OU
# correction extranet). Le 29/08, des cycles de scan arrivaient PENDANT
# les files marathon -> refus en série (« déjà en cours »). Désormais
# l'opération en cours bloque proprement le lancement d'une seconde.
_OPERATION = {"kind": None, "since": ""}
_OP_STATE_LOCK = threading.Lock()


def operation_begin(kind: str) -> bool:
    """Réserve le créneau opération. False = une autre opération tourne
    OU la pause globale est posée (D98 — refus tracé, message dédié)."""
    from datetime import datetime as _dt
    with _OP_STATE_LOCK:
        if _OPERATION["kind"] is not None:
            try:  # D91 : boîte noire — refus tracé, jamais fatal
                from diagnostic.recorder import event as _bb
                _bb("operation_refused", "warn",
                    {"kind": kind, "busy_with": _OPERATION["kind"]})
            except Exception:
                pass
            return False
        if PAUSED.is_set():
            try:  # D98 : refus pause — tracé aussi
                from diagnostic.recorder import event as _bb
                _bb("operation_refused", "info",
                    {"kind": kind, "reason": "paused"})
            except Exception:
                pass
            return False
        _OPERATION["kind"] = kind
        _OPERATION["since"] = _dt.now().strftime("%H:%M:%S")
    try:  # D91 : boîte noire — hors verrou, jamais fatal
        from diagnostic.recorder import event as _bb
        _bb("operation_begin", "info", {"kind": kind})
    except Exception:
        pass
    return True


def operation_end(kind: str) -> None:
    """Libère le créneau (idempotent, tolérant aux ordres différents)."""
    with _OP_STATE_LOCK:
        if _OPERATION["kind"] == kind:
            _OPERATION["kind"] = None
            _OPERATION["since"] = ""
    try:  # D91 : boîte noire — jamais fatal
        from diagnostic.recorder import event as _bb
        _bb("operation_end", "info", {"kind": kind})
    except Exception:
        pass


def operation_current() -> str:
    """Nom de l'opération en cours ('' si aucune)."""
    with _OP_STATE_LOCK:
        return _OPERATION["kind"] or ""


def operation_since() -> str:
    with _OP_STATE_LOCK:
        return _OPERATION["since"] or ""


def ensure_keepalive(say=print):
    """Démarre (une seule fois) le keep-alive de session E5 : rechargement
    fort (ignoreCache) des onglets du CM à intervalle ALÉATOIRE 10-20 min,
    JAMAIS pendant une édition (drapeau EDITION), jamais d'onglet ouvert
    ni fermé (D24). Réglages lus dans la carte (session.keepalive)."""
    global _KEEPALIVE
    with _KEEPALIVE_LOCK:
        if _KEEPALIVE is not None:
            return _KEEPALIVE
        try:
            from vae2.keepalive import ExtranetKeepalive
            _ka = ExtranetKeepalive.from_map(
                active_cm_map(), log_sink=lambda m: say(f"[keepalive] {m}"))
            _ka.start()
            _KEEPALIVE = _ka
        except Exception as e:
            say(f"[keepalive] démarrage impossible : {e}")
    return _KEEPALIVE


class _Edition:
    """Context manager : lève le drapeau keepalive.EDITION pendant que
    l'exécuteur conduit un onglet — le keep-alive ne recharge JAMAIS
    pendant ce temps (plan §4.5)."""

    def __enter__(self):
        try:
            from vae2.keepalive import EDITION
            EDITION.set()
        except Exception:
            pass
        return self

    def __exit__(self, *exc):
        try:
            from vae2.keepalive import EDITION
            EDITION.clear()
        except Exception:
            pass
        return False


# ── Dossier des captures passives ──────────────────────────────────────────

def _newest_capture_mtime(d: Path) -> float:
    """mtime of the newest capture file in a folder (0 if none).

    D102: the capture folder is written and purged WHILE we walk it — a
    file can vanish between glob() and stat(). Each stat is guarded so a
    vanished file costs its own skip, never the whole scan (client
    2026-10-07: the CM passive read crashed on this exact race and the
    anchor grid went silent for every room)."""
    newest = 0.0
    try:
        for f in d.glob("*.json"):
            try:
                m = f.stat().st_mtime
            except OSError:
                continue
            if m > newest:
                newest = m
        return newest
    except OSError:
        return 0


def captures_dir(app_config=None) -> Path:
    """Où le listener VAE écrit ses captures :
    1. réglage explicite (config « extranet_direct.captures_dir », lu au
       niveau racine OU sous channel_manager) ;
    2. le dossier le PLUS FRAIS entre vae_standalone (ancienne écoute
       console de dev) et vae/ embarqué (écoute intégrée de l'app).
    Bug 23-26/08 (racine des « submitted_but_change_not_seen » à répétition,
    trouvé le 26/08) : la préférence fixe pour vae_standalone faisait lire
    des captures FIGÉES (dernière du 23/08 17:09) alors que l'écoute
    intégrée écrivait des captures fraîches — l'envoi marchait mais la
    vérification comparaît avec 3 jours de retard. On choisit désormais
    le candidat dont la capture la plus récente est la plus fraîche.
    Aucun de ces dossiers n'est JAMAIS écrit par ce module."""
    for tree in (app_config or {},
                 (app_config or {}).get("channel_manager") or {}):
        try:
            d = (tree.get("extranet_direct") or {}).get("captures_dir")
            if d:
                return Path(d)
        except Exception:
            pass
    cands = [Path.home() / "Downloads" / "vae_standalone" / "vae" / "data"
             / "api_discovery",
             PROJECT_ROOT / "vae" / "data" / "api_discovery"]
    cands = [c for c in cands if c.exists()]
    if not cands:
        return cands[-1] if cands else PROJECT_ROOT / "vae" / "data" / "api_discovery"
    return max(cands, key=_newest_capture_mtime)


# ── Lecture de l'état du CM ────────────────────────────────────────────────

def capture_folders_report(app_config=None):
    """D103 — dossiers de captures candidats, POUR L'AFFICHAGE dans
    l'onglet Extranet Direct. « 0 chambres » ne doit jamais être muet :
    la section montre chaque dossier (chemin, nombre de captures, fraîcheur)
    et celui qui est réellement lu porte chosen=True. Lecture seule,
    jamais d'exception."""
    out = []
    seen = {}

    def _add(label, p):
        try:
            p = Path(p)
            key = str(p)
            if key in seen:
                return
            seen[key] = len(out)
            n, newest = 0, 0.0
            exists = p.is_dir()
            if exists:
                for f in p.glob("*.json"):
                    n += 1
                    try:
                        m = f.stat().st_mtime
                    except OSError:
                        continue
                    if m > newest:
                        newest = m
            out.append({"label": label, "path": key, "count": n,
                        "newest": newest, "exists": exists,
                        "chosen": False})
        except Exception:
            pass

    try:
        for tree, lab in ((app_config or {}, "config"),
                          ((app_config or {}).get("channel_manager") or {},
                           "config(cm)")):
            d = (tree.get("extranet_direct") or {}).get("captures_dir")
            if d:
                _add(lab, d)
    except Exception:
        pass
    _add("vae_standalone",
         Path.home() / "Downloads" / "vae_standalone" / "vae" / "data"
         / "api_discovery")
    _add("app (vae embarqué)", PROJECT_ROOT / "vae" / "data"
         / "api_discovery")
    try:
        chosen = captures_dir(app_config)
        if str(chosen) in seen:
            out[seen[str(chosen)]]["chosen"] = True
        else:
            n, newest, exists = 0, 0.0, False
            try:
                exists = chosen.is_dir()
                if exists:
                    for f in chosen.glob("*.json"):
                        n += 1
                        try:
                            m = f.stat().st_mtime
                        except OSError:
                            continue
                        if m > newest:
                            newest = m
            except Exception:
                pass
            out.append({"label": "dossier lu", "path": str(chosen),
                        "count": n, "newest": newest, "exists": exists,
                        "chosen": True})
    except Exception:
        pass
    return out


_last_scan = None   # cache mémoire : données du dernier scan réussi


def scan_cm(app_config=None, save_before=True, say=print):
    """Scanne les captures et renvoie l'état normalisé (vae2.scanner).
    Sauvegarde aussi le rapport « avant » (référence du futur diff).

    D34 (27/08, comportement « avant il ouvrait l'onglet » restauré) :
    si la lecture ne trouve PAS de grille exploitable (statut != ok ou
    zéro chambre), on RECHARGE l'onglet OTASheet — ouvert s'il manque,
    uniquement avec une session CM vivante (garde incluse dans
    vae2.coordinator.reload_otasheet, recette 22/23) — puis on relit.
    Chemin rapide inchangé quand une grille fraîche existe déjà : aucune
    action sur le navigateur. Un échec du réveil n'empêche jamais la
    lecture : on rend le résultat des captures telles quelles."""
    global _last_scan
    import time as _time
    from vae2.scanner import run_scan

    def _run():
        return run_scan(captures_dir(app_config), active_cm_map(app_config))

    rep = _run()
    if rep.status != "ok" or not rep.rooms:
        say("[EXTRANET] aucune grille exploitable dans les captures — "
            "réveil de l'onglet OTASheet (rechargé/ouvert si besoin)")
        try:
            from vae2.coordinator import reload_otasheet
            import asyncio as _aio
            # Jusqu'à 2 réveils : si l'onglet vient d'être OUVERT, sa
            # grille charge AVANT que le listener ne s'y attache (cycle
            # de détection 10 s — le piège du 27/08 soir) ; le 1er essai
            # laisse le monitor le trouver, le 2e RECHARGE l'onglet
            # désormais écouté → les captures de grille partent à coup sûr.
            for _attempt in range(2):
                _aio.run(reload_otasheet(map_path=active_cm_map(app_config)))
                _time.sleep(12.0 if _attempt == 0 else 4.0)
                rep = _run()
                say(f"[EXTRANET] réveil { _attempt + 1}/2 : status={rep.status}, "
                    f"chambres={len(rep.rooms)}")
                if rep.status == "ok" and rep.rooms:
                    break
        except Exception as e:
            say(f"[EXTRANET] réveil OTASheet impossible ({e}) — lecture "
                "des captures existantes seulement")
    if rep.status == "ok":
        _last_scan = asdict(rep)
        if save_before:
            V3_SANDBOX.mkdir(parents=True, exist_ok=True)
            (V3_SANDBOX / "before_app.json").write_text(
                json.dumps(_last_scan, indent=2, ensure_ascii=False),
                encoding="utf-8")
    return rep


def cm_state(app_config=None):
    """État du dernier scan (scan au préalable si nécessaire).
    Retourne un dict : captured_at, currency, rooms [{code,label}],
    otas [{code,label}], daily {(room,ota,date): price}."""
    global _last_scan
    if _last_scan is None:
        rep = scan_cm(app_config, save_before=False)
        if rep.status != "ok":
            return None
    d = _last_scan
    daily = {}
    for cell in d.get("daily_prices") or []:
        if cell.get("kind") == "availability" or cell.get("price") is None:
            continue
        daily[(str(cell.get("room_id")), str(cell.get("ota_id")),
               str(cell.get("date")))] = cell.get("price")
    return {
        "captured_at": d.get("captured_at"),
        "currency": d.get("currency"),
        "rooms": [{"code": str(r["room_id"]), "label": r["label"]}
                  for r in d.get("rooms") or []],
        "otas": [{"code": str(o["ota_id"]), "label": o["label"]}
                 for o in d.get("otas") or []],
        "daily": daily,
    }


def daily_price(room_code, ota_code, date_iso, app_config=None):
    """Prix quotidien actuel (grille OTASheet) pour chambre×OTA×date."""
    st = cm_state(app_config)
    if not st:
        return None
    return st["daily"].get((str(room_code), str(ota_code), str(date_iso)))


# ── Exécution d'une correction (thread séparé) ─────────────────────────────

def run_correction(task_dict, confirmed=False, say=print, done=None,
                   app_config=None):
    """Lance le coordinateur en arrière-plan.
    `task_dict` : {room_label, ota_label, rate, date_from, date_to, days?}
    `say(line)` : chaque ligne de journal (appelé depuis le thread).
    `done(result_dict)` : appelé à la fin (thread)."""
    from vae2.coordinator import run_task, Task

    def _worker():
        result = None
        try:
            # D98 : pause globale — la tâche est ignorée (message dédié).
            if is_paused():
                say("[EXTRANET] ⏸ " + tr_("pause globale — tâche ignorée "
                                          "(reprise avec ▶ Reprendre)"))
                result = {"outcome": "paused",
                          "error": "pause globale active"}
            # D37-2 : même verrou que la file — un seul exécutant à la fois
            # dans tout le processus, chemin manuel compris.
            elif not _PUSH_LOCK.acquire(blocking=False):
                say("[EXTRANET] 🛑 un envoi extranet est DÉJÀ en cours — "
                    "tâche ignorée (verrou D37)")
                result = {"outcome": "push_locked",
                          "error": "un envoi extranet est déjà en cours"}
            elif not operation_begin("push"):
                _PUSH_LOCK.release()
                say(f"[EXTRANET] 🛑 opération « {operation_current()} » en "
                    f"cours — tâche ignorée (D52 : une seule opération)")
                result = {"outcome": "push_locked",
                          "error": "un scan/une correction est déjà en cours"}
            else:
                try:
                    ensure_keepalive(say)
                    task = Task(**task_dict)
                    with _Edition():
                        result = run_task(
                            task, map_path=active_cm_map(app_config),
                            captures_dir=captures_dir(app_config),
                            confirmed=confirmed,
                            before_report=V3_SANDBOX / "before_app.json",
                            after_out=V3_SANDBOX / "after_app.json",
                            journal_path=V3_SANDBOX / "journal_app.json",
                            log_sink=say)
                    # envoi réel AVEC preuve de POST → la mesure entre dans
                    # la boucle V2 (D38 : submitted_but_change_not_seen
                    # compte aussi — le POST est prouvé parti, seul le
                    # diff n'a pas vu le changement ; sans ça un envoi
                    # manuel ne laissait AUCUNE trace dans l'historique
                    # et l'ancre repartait d'un chiffre périmé).
                    if result.get("outcome") in (
                            "verified", "submitted_but_change_not_seen"):
                        try:
                            _record_send_history(task_dict)
                            say("[send_history] mesure enregistrée (pending)")
                        except Exception as e:
                            say(f"[send_history] échec enregistrement : {e}")
                finally:
                    operation_end("push")
                    _PUSH_LOCK.release()
        except Exception as e:
            say(f"[erreur] {e}")
            result = {"outcome": "exception", "error": str(e)}
        if done:
            try:
                done(result)
            except Exception:
                pass

    t = threading.Thread(target=_worker, daemon=True,
                         name="vae2-extranet-correction")
    t.start()
    return t


def _record_send_history(task_dict):
    """Mesure « envoyé » au même format que les poussages API CM
    (core/send_history.py) — l'observation OTA viendra du scan normal."""
    from core import send_history as _sh
    _sh.record_send(
        ota_name=task_dict.get("ota_label", ""),
        room=task_dict.get("room_label", ""),
        sent=int(float(task_dict.get("rate", 0))),
        target=None,
        observed_before=None,
        stay_date=task_dict.get("date_from", ""),
        simulated=False,
        device="extranet_direct",
    )


# ── Transport dispatcher (couture E4) ───────────────────────────────────────

def push_rates(cm_cfg, room_pushes, checkin=None, nights=1,
               delay_seconds=5, log_cb=None, progress_cb=None,
               stop_event=None):
    """Routeur de transport : Extranet Direct si activé dans la config
    (channel_manager.extranet_direct.enabled), sinon l'API CM classique.
    Contrat IDENTIQUE à business.channel_manager.push_rates_to_cm_by_ota —
    les appelants (app_core._do_push, corrections plancher/plafond) ne
    changent que leur import."""
    # D98 : pause globale — AUCUN transport n'envoie (garde au niveau du
    # routeur : API et Extranet Direct sont couverts d'un seul tenant).
    if is_paused():
        _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))
        _say("[EXTRANET] ⏸ " + tr_("pause globale — envoi refusé "
                                    "(reprise avec ▶ Reprendre)"))
        _groups_p = {}
        for rp in room_pushes:
            _oc = str(rp.get("ota_code", "") or "").strip()
            _groups_p.setdefault(_oc, []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("l'outil est EN PAUSE — aucune activité "
                            "jusqu'à ▶ Reprendre"),
                 "body": "", "n": len(v), "sent": 0}
                for k, v in _groups_p.items()]
    # D79 : grille tarifaire — envois refusés au-dessus de la limite de
    # chambres signée (comptage grille CM > déclaration).
    try:
        from licensing.limits import operation_allowed
        import core.config as _cfg_mod
        _ok, _why = operation_allowed(_cfg_mod.load())
        if not _ok:
            _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))
            _say("[EXTRANET] 🛑 " + _why)
            _groups_d79 = {}
            for rp in room_pushes:
                _oc = str(rp.get("ota_code", "") or "").strip()
                _groups_d79.setdefault(_oc, []).append(rp)
            return [{"ota_code": k, "ok": False, "msg": _why,
                     "body": "", "n": len(v), "sent": 0}
                    for k, v in _groups_d79.items()]
    except Exception:
        pass
    try:
        xd = ((cm_cfg or {}).get("extranet_direct") or {})
        enabled = bool(xd.get("enabled"))
    except Exception:
        enabled = False
    # D80 : journal juridique — consignes confiées au transport (verbatim)
    # puis verdict par groupe. Échec d'écriture non bloquant.
    try:
        from business import legal_ledger as _ll
        _ll.journal_push_order(room_pushes, transport=(
            "extranet-direct" if enabled else "api-cm"))
    except Exception:
        pass
    if enabled:
        results = push_rates_via_extranet(cm_cfg, room_pushes,
                                          checkin=checkin, nights=nights,
                                          log_cb=log_cb,
                                          progress_cb=progress_cb,
                                          stop_event=stop_event)
    else:
        from business.channel_manager import push_rates_to_cm_by_ota
        results = push_rates_to_cm_by_ota(cm_cfg, room_pushes,
                                          checkin=checkin, nights=nights,
                                          delay_seconds=delay_seconds,
                                          log_cb=log_cb)
    # D80 : verdict de chaque groupe au journal de preuves
    try:
        from business import legal_ledger as _ll
        for _r in results or []:
            _ll.journal_push_result(_r.get("ota_code"), _r.get("ok"),
                                    _r.get("sent", _r.get("n")),
                                    _r.get("msg"))
    except Exception:
        pass
    return results


def revive_cm_tabs(cm_cfg, say=print, wait_s=8.0):
    """D87 : réveil des onglets CM quand le formulaire est mort au
    preflight — Page.reload ignoreCache sur les onglets EXISTANTS (la
    mécanique exacte du keepalive ; le navigateur recharge lui-même,
    R4, jamais d'onglet ouvert/fermé). Le formulaire à moitié mort est
    DÉJÀ inutilisable : le rechargement ne peut rien casser et le
    retry repart sur une page vivante. Nb de rechargements en retour."""
    try:
        import asyncio
        from vae2.keepalive import ExtranetKeepalive
        ka = ExtranetKeepalive.from_map(
            active_cm_map(cm_cfg),
            log_sink=lambda m: say(f"[keepalive] {m}"))
        tabs = ka._tabs()
        n = 0

        async def _go():
            nonlocal n
            for _t in tabs:
                if await ka._reload(_t):
                    n += 1
        asyncio.run(_go())
        if n:
            say("[EXTRANET] " + tr_("🔄 réveil CM : {n} onglet(s) "
                                    "rechargé(s) — attente {s} s puis "
                                    "retry du segment").format(
                n=n, s=int(wait_s)))
            import time as _t
            _t.sleep(wait_s)
        return n
    except Exception as e:
        say(f"[EXTRANET] réveil CM impossible : {e}")
        return 0


def push_rates_via_extranet(cm_cfg, room_pushes, checkin=None, nights=1,
                            log_cb=None, progress_cb=None,
                            stop_event=None):
    """Pousse les tarifs via l'exécution extranet (navigateur réel,
    événements de confiance — zéro requête API). Contrat de retour identique
    à push_rates_to_cm_by_ota. Appelé depuis un thread d'arrière-plan
    (l'UI n'est jamais bloquée). Une catégorie à la fois (D8), vérification
    sur la grille après chaque envoi.

    D37-2 : verrou anti-push parallèle — un second push arrivant pendant
    qu'un autre s'exécute est REFUSÉ proprement (résultat ok=False avec
    message explicite), jamais exécuté en parallèle.
    D52 : une seule opération dans tout le processus — un push lancé
    pendant un SCAN est refusé, et progress_cb(done, total, label) suit
    l'avancement de la file."""
    _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))

    # Parité avec le mode test OTA Guard (C16) : rien ne part, tout est OK.
    try:
        from business.channel_manager import _is_test_mode
        if _is_test_mode(cm_cfg):
            _say("[EXTRANET] " + tr_("Mode test OTA Guard — aucun prix envoyé (parité API)"))
            _groups = {}
            for rp in room_pushes:
                _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                                   []).append(rp)
            return [{"ota_code": k, "ok": True,
                     "msg": tr_("Mode test — pas d'envoi réel"),
                     "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    except Exception:
        pass

    if is_paused():   # D98 : pause globale — aucun envoi ne démarre
        _say("[EXTRANET] ⏸ " + tr_("pause globale — envoi refusé "
                                    "(reprise avec ▶ Reprendre)"))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("l'outil est EN PAUSE — aucune activité "
                            "jusqu'à ▶ Reprendre"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    if not _PUSH_LOCK.acquire(blocking=False):
        _say("[EXTRANET] " + tr_("🛑 un push extranet est DÉJÀ en cours — "
                                "demande refusée (verrou anti-push parallèle)"))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("un envoi extranet est déjà en cours — attendez "
                           "sa fin puis relancez (verrou anti-push parallèle)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    if not operation_begin("push"):
        _PUSH_LOCK.release()
        _say("[EXTRANET] " + tr_("🛑 opération « {k} » en cours depuis "
                                "{s} — envoi refusé (D52 : une seule "
                                "opération à la fois)").format(
            k=operation_current(), s=operation_since()))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("un scan/une correction est déjà en cours — "
                           "une seule opération à la fois (D52)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    try:
        return _push_rates_via_extranet_locked(cm_cfg, room_pushes,
                                               checkin=checkin,
                                               nights=nights,
                                               log_cb=log_cb,
                                               progress_cb=progress_cb,
                                               stop_event=stop_event)
    finally:
        operation_end("push")
        _PUSH_LOCK.release()


def _push_rates_via_extranet_locked(cm_cfg, room_pushes, checkin=None,
                                    nights=1, log_cb=None, progress_cb=None,
                                    stop_event=None):
    """Corps d'exécution du push extranet — TOUJOURS appelé sous _PUSH_LOCK."""
    from datetime import date, timedelta
    from vae2.coordinator import run_task, Task

    _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))

    # Résolution code → libellé via la grille lue passivement
    st = cm_state(cm_cfg)
    if not st:
        try:
            scan_cm(cm_cfg, save_before=True, say=_say)
            st = cm_state(cm_cfg)
        except Exception:
            st = None
    if not st:
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("état du CM indisponible (scan des captures)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]

    rooms_by_code = {r["code"]: r["label"] for r in st["rooms"]}
    otas_by_code = {o["code"]: o["label"] for o in st["otas"]}

    # D55 : limite de taille — l'etablissement gere par le CM ne doit pas
    # depasser EXTRANET_MAX_ROOMS chambres. Refus AVANT tout envoi.
    _n_rooms = len(st.get("rooms") or [])
    if _n_rooms > EXTRANET_MAX_ROOMS:
        _say("[EXTRANET] " + tr_("🛑 refusé : l'établissement compte {n} "
                                "chambres (limite Extranet Direct : {m}) — "
                                "les établissements de cette taille "
                                "requièrent l'API CM").format(
            n=_n_rooms, m=EXTRANET_MAX_ROOMS))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("configuration non supportée par le canal "
                           "Extranet Direct : l'établissement compte {n} "
                           "chambres (maximum {m}). Les établissements de "
                           "cette taille requièrent le canal API CM.").format(
                    n=_n_rooms, m=EXTRANET_MAX_ROOMS),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]

    stay_from = checkin or date.today().isoformat()
    try:
        nd = max(1, int(nights or 1))
    except (ValueError, TypeError):
        nd = 1
    stay_to = (date.fromisoformat(stay_from) +
               timedelta(days=nd - 1)).isoformat()

    # Scan « avant » frais pour la vérification par diff
    scan_cm(cm_cfg, save_before=True, say=_say)

    groups, order = {}, []
    for rp in room_pushes:
        key = str(rp.get("ota_code", "")).strip()
        groups.setdefault(key, []).append(rp)
        if key not in order:
            order.append(key)

    def _month_ranges(d_from: date, d_to: date):
        """Découpage multi-mois : le datepicker ne sait PAS naviguer entre
        les mois (flèches inopérantes dans cet état — constaté en réel
        21/37). Chaque sous-plage reste dans UN seul mois → zéro
        navigation nécessaire."""
        out = []
        _d, _end = d_from, d_to
        while _d <= _end:
            _eom = (date(_d.year + 1, 1, 1) if _d.month == 12
                    else date(_d.year, _d.month + 1, 1)) - timedelta(days=1)
            _r_end = min(_end, _eom)
            out.append((_d.isoformat(), _r_end.isoformat()))
            _d = _r_end + timedelta(days=1)
        return out

    def _ranges_for(rp: dict):
        """Plages à envoyer pour CETTE entrée (D33). Le générateur V2
        (weekend / dates verrouillées) découpe déjà des segments datés
        portés par from_date/to_date — on les RESPECTE : chaque prix
        n'atteint que SES dates. Sans dates de segment (push plat
        rétrocompatible), la plage complète demandée. Avant D33, chaque
        segment était appliqué à TOUTE la période : ils s'écrasaient
        mutuellement et le dernier gagnait — majoration weekend écrasée
        (27/08 : 2591 plat au lieu de 2591/2850 semaine/weekend)."""
        _sf = str(rp.get("from_date") or "").strip()
        _st = str(rp.get("to_date") or "").strip()
        try:
            if _sf and _st and _sf <= _st:
                return _month_ranges(date.fromisoformat(_sf),
                                     date.fromisoformat(_st))
        except ValueError:
            _say("[EXTRANET] " + tr_("dates de segment invalides "
                                    "({a}..{b}) → plage complète "
                                    "utilisée").format(a=_sf, b=_st))
        return _month_ranges(date.fromisoformat(stay_from),
                             date.fromisoformat(stay_to))

    results = []
    _consec_failures = 0   # circuit breaker: stop hammering a broken target
    ensure_keepalive(_say)
    # D52 : total de segments connu à l'avance -> progression X/Y
    _total_tasks = 0
    for _key in order:
        for _rp in groups[_key]:
            try:
                _total_tasks += len(_ranges_for(_rp))
            except Exception:
                _total_tasks += 1
    _done_tasks = 0

    def _tick(label: str):
        nonlocal _done_tasks
        _done_tasks += 1
        if progress_cb:
            try:
                progress_cb(_done_tasks, _total_tasks, label)
            except Exception:
                pass

    if progress_cb:
        try:
            progress_cb(0, _total_tasks, "préparation de la file")
        except Exception:
            pass
    QUEUE_STOP.clear()     # D56 : chaque file demarre proprement
    _revives_left = 4     # D87 : max 4 réveils CM par file
    with _Edition():       # E5 : aucun reload keep-alive pendant le lot
      for key in order:
        group = groups[key]
        ota_label = otas_by_code.get(key)
        ok_all, msgs, sent_ok = True, [], []
        for rp in group:
            # D78 : le ⏹ doit pouvoir couper ENTRE les segments — sinon
            # le stop est ignoré pendant toute la phase d'envoi (leçon
            # du 21/09 : clics ignorés pendant 30 min, rien d'affiché).
            if stop_event is not None and stop_event.is_set():
                _say("[EXTRANET] " + tr_("🛑 arrêt demandé — segments "
                                        "restants annulés ({r}/{n} "
                                        "envoyés pour cette OTA)").format(
                    r=len(sent_ok), n=len(group)))
                ok_all = False
                msgs.append(tr_("INTERROMPU : arrêt demandé (⏹) — "
                                "segments restants non envoyés"))
                break
            if _consec_failures >= 3:
                ok_all = False
                msgs.append(tr_("INTERROMPU : 3 échecs consécutifs — "
                                "arrêt du lot pour éviter l'acharnement "
                                "(revenir à l'onglet CM dans Brave puis "
                                "relancer)"))
                _say("[EXTRANET] " + tr_("🛑 Circuit breaker : 3 échecs "
                                        "consécutifs — lot interrompu"))
                break
            room_label = rooms_by_code.get(str(rp.get("room_code", "")).strip())
            if not room_label:
                ok_all = False
                msgs.append(tr_("code chambre {c} introuvable sur la "
                                "grille").format(c=rp.get('room_code')))
                continue
            if not ota_label:
                ok_all = False
                msgs.append(tr_("code OTA {c} introuvable sur la "
                                "grille").format(c=key))
                continue
            try:
                rate = str(int(round(float(rp["price"]))))
            except (KeyError, TypeError, ValueError) as e:
                ok_all = False
                msgs.append(tr_("prix invalide ({e})").format(e=e))
                continue
            _rp_ranges = _ranges_for(rp)
            if len(_rp_ranges) > 1:
                _say("[EXTRANET] " + tr_("plage multi-mois → {n} "
                                        "sous-plages (navigation datepicker "
                                        "non fiable)").format(
                    n=len(_rp_ranges)))
            for _from, _to in _rp_ranges:
                if QUEUE_STOP.is_set():
                    ok_all = False
                    msgs.append(tr_("⏹ arrêté par l'utilisateur — file "
                                    "arrêtée avant la tâche suivante"))
                    _say("[EXTRANET] " + tr_("⏹ Arrêt demandé par "
                                            "l'utilisateur — file arrêtée "
                                            "proprement avant la tâche "
                                            "suivante"))
                    break
                if SHUTDOWN.is_set():
                    ok_all = False
                    msgs.append(tr_("INTERRUPTED : fermeture de "
                                    "l'application — file d'envoi arrêtée "
                                    "avant la tâche suivante"))
                    _say("[EXTRANET] " + tr_("🛑 Fermeture de l'app — "
                                            "file arrêtée proprement avant "
                                            "la tâche suivante"))
                    break
                task = Task(room_label=room_label, ota_label=ota_label,
                            rate=rate, date_from=_from, date_to=_to)
                _say(f"[EXTRANET] {room_label} / {ota_label} → {rate} "
                     f"({_from}..{_to})")
                _outcome = None
                for _retry in range(2):  # 1 essai + 1 retry si transitoire
                    try:
                        res = run_task(task, map_path=active_cm_map(cm_cfg),
                                       captures_dir=captures_dir(cm_cfg),
                                       confirmed=True,
                                       before_report=V3_SANDBOX / "before_app.json",
                                       after_out=V3_SANDBOX / "after_app.json",
                                       journal_path=V3_SANDBOX / "journal_app.json",
                                       log_sink=_say)
                        _outcome = res.get("outcome")
                        if _outcome == "verified":
                            break
                        # retry uniquement sur erreurs transitoires
                        if _outcome in ("executor_failed", "preflight_failed") \
                                and _retry == 0:
                            _say("[EXTRANET] " + tr_("⏳ retry {r} "
                                                    "({o})…").format(
                                r=room_label, o=_outcome))
                            # D87 : formulaire mort au preflight = RECHARGER les
                            # onglets CM avant de rejouer (un simple sommeil
                            # rejouait sur la page encore morte — les 3 échecs
                            # d'affilée du 26/09).
                            if _outcome == "preflight_failed" and _revives_left > 0:
                                _revives_left -= 1
                                revive_cm_tabs(cm_cfg, say=_say)
                            else:
                                import time as _t; _t.sleep(5)
                            continue
                        break
                    except Exception as e:
                        _outcome = f"exception {e}"
                        if _retry == 0:
                            _say("[EXTRANET] " + tr_("⏳ retry après "
                                                    "exception…"))
                            import time as _t; _t.sleep(5)
                            continue
                        break
                _tick(f"{room_label} / {ota_label} → {rate} "
                      f"({_from}..{_to})")
                if _outcome == "verified":
                    _consec_failures = 0
                    sent_ok.append(tr_("{r} → {p} ({a}..{b}) ✓ vérifié "
                                       "grille").format(
                        r=room_label, p=rate, a=_from, b=_to))
                    _say("[EXTRANET] " + tr_("✅ {r} / {o}: vérifié sur la "
                                            "grille ({a}..{b})").format(
                        r=room_label, o=ota_label, a=_from, b=_to))
                elif _outcome == "submitted_but_change_not_seen":
                    # D37-1 : le POST est PROUVÉ parti (post-proof D32) —
                    # seul le diff strict n'a pas vu le changement. Cause
                    # connue : une consigne qui RESTAURE la valeur de début
                    # de file est invisible dans le diff (faux négatif
                    # documenté D33-a). Échouer tout le groupe — donc tout
                    # le push → ok=False → AUCUNE mesure enregistrée — pour
                    # un faux négatif de vérification cassait la boucle
                    # d'apprentissage complète (28/08 : ~75 envois vérifiés,
                    # zéro mesure enregistrée, tout affiché en échec). Le
                    # groupe reste OK ; la note reste visible dans le msg.
                    _consec_failures = 0
                    sent_ok.append(tr_("{r} → {p} ({a}..{b}) ✓ envoyé "
                                       "(preuve POST)").format(
                        r=room_label, p=rate, a=_from, b=_to))
                    _say(f"[EXTRANET] ✅ {room_label} / {ota_label}: "
                         f"envoyé — preuve POST ok, changement non vu sur "
                         f"la grille ({_from}..{_to}) — restauration "
                         f"probable (faux négatif connu)")
                    msgs.append(tr_("{r} ({a}..{b}): envoyé (preuve POST) "
                                    "— changement non détecté sur la grille "
                                    "(restauration probable)").format(
                        r=room_label, a=_from, b=_to))
                elif _outcome == "cm_login_required":
                    # pas un « échec » à comptabiliser : l'auto-login
                    # 2 clics (D26, autofill Brave) a déjà été tenté et
                    # a échoué — action humaine requise, stop propre
                    ok_all = False
                    msgs.append(tr_("session CM expirée — la reconnexion "
                                    "automatique (2 clics, autofill Brave) "
                                    "n'a pas abouti : connectez-vous une "
                                    "fois dans l'onglet BulkUpdate de "
                                    "Brave puis relancez l'envoi"))
                    _say("[EXTRANET] " + tr_("🔑 Session CM expirée — "
                                            "auto-login échoué, connexion "
                                            "manuelle requise dans "
                                            "l'onglet BulkUpdate de Brave "
                                            "(aucun onglet ouvert ni "
                                            "fermé)"))
                    break
                else:
                    _consec_failures += 1
                    ok_all = False
                    msgs.append(tr_("{r} ({a}..{b}): {o}").format(
                        r=room_label, a=_from, b=_to, o=_outcome))
                if _consec_failures >= 3:
                    _say(f"[EXTRANET] 🛑 3 échecs consécutifs — "
                         f"arrêt du lot")
                    break
        # D40 : les ENVOIS RÉUSSIS montent AUSSI dans le message du groupe —
        # le panneau « Latest submissions » doit montrer chambre/prix/dates
        # de ce qui est parti, pas seulement les erreurs. Les échecs
        # restent en tête (lus en premier), les succès derrière.
        # D42 : « sent » = nombre d'envois RÉELLEMENT partis (verified +
        # preuve POST) — le panneau affiche vert si tout est ok, ORANGE si
        # au moins un envoi est parti malgré des échecs, rouge sinon.
        _parts = msgs + (["✓ " + " ; ".join(sent_ok)] if sent_ok else [])
        results.append({"ota_code": key, "ok": ok_all,
                        "msg": " | ".join(_parts) or tr_("envoyé et "
                                                        "vérifié (grille)"),
                        "body": "", "n": len(group),
                        "sent": len(sent_ok)})
    return results
