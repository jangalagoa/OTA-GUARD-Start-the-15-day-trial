"""
VAE Bridge — connects VAE passive interception to OTA Guard's UI.

Converts VAE's HotelData/Room/Price objects into OTA Guard's expected format:
    {ota_name: {room_type: price_int}}

This is the ONLY integration point between VAE and OTA Guard.
The UI, parity detection, CM push, and notifications all consume this dict.
"""

import sys
import difflib
import json
import time
import re as _re
from pathlib import Path

# Add VAE module to Python path
# D104 — même règle que extranet_bridge : ancre INSTALL_DIR (jamais
# patchée) et non __file__ de CE module, faux quand servi depuis patches/.
try:
    from core.paths import INSTALL_DIR as _INSTALL_DIR
    _VAE_ROOT = Path(_INSTALL_DIR) / "vae"
except Exception:
    _VAE_ROOT = Path(__file__).resolve().parent / "vae"
if str(_VAE_ROOT) not in sys.path:
    sys.path.insert(0, str(_VAE_ROOT))


class ScanCancelled(Exception):
    """D53 : levée par le callback de progression quand l'utilisateur
    demande l'arrêt — avalée aux 2 points d'appel pour que la boucle
    saute l'OTA en cours et retourne les résultats PARTIELS."""
    pass


def vae_scan(config: dict, progress_cb=None) -> dict:
    """
    Extract prices from VAE's captured data and return in OTA Guard format.

    Args:
        config: OTA Guard's config dict (contains hotel_currency, room_types,
                ota_watch.otas with OTA names/URLs)
        progress_cb: optional callback(progress_percent: int, message: str)

    Returns:
        {ota_name(str): {room_type(str): price_int}} — same format as old engines.
        Prices are in the target currency (config['hotel_currency']),
        rounded to integers.
    """
    target_currency = config.get("hotel_currency", "INR")
    room_types = config.get("room_types", [])
    otas = config.get("ota_watch", {}).get("otas", [])

    # D79 : grille tarifaire — au-dessus de la limite de chambres signée,
    # le scan de prix est refusé (comptage : grille CM > déclaration).
    try:
        from licensing.limits import operation_allowed
        _ok, _why = operation_allowed(config)
        if not _ok:
            print(f"[VAE_BRIDGE] {_why}")
            if progress_cb:
                progress_cb(100, _why)
            return {}
    except Exception:
        pass

    # Configure VAE target currency
    try:
        from vae.config import set_target_currency
        set_target_currency(target_currency)
    except Exception:
        pass

    # IMPORTANT: a scan must be READ-ONLY with respect to the mappings.
    # Do not regenerate YAML mappings here. Auto-regeneration on every scan
    # can replace a known-good mapping with a path found in an unrelated
    # response (tracking, search, teaser, etc.) and make a working OTA
    # suddenly return no prices. Mapping generation is an explicit maintenance
    # operation, not part of the passive price scan.
    if progress_cb:
        progress_cb(5, "Lecture des données capturées...")

    # Create VAE extractor
    try:
        from vae.src.extractors.generic_extractor import GenericExtractor
        extractor = GenericExtractor(target_currency=target_currency)
    except Exception as e:
        print(f"[VAE_BRIDGE] Cannot initialize VAE extractor: {e}")
        return {}

    if not extractor.mappings:
        print("[VAE_BRIDGE] No OTA mappings loaded. Run auto-mapping generator first.")
        return {}

    # Map OTA Guard OTA names to VAE mapping keys for quick lookup
    ota_name_map = _build_ota_name_map(otas, extractor.mappings)

    # Generalist / metasearch sites are not real OTAs — skip them entirely
    # so they never appear in scan results.
    _GENERALIST_DOMAINS = {"google", "trivago", "kayak", "tripadvisor"}

    results = {}
    total = len(extractor.mappings)
    done = 0
    detected_report = {}   # display_name -> {source_id, rooms:[{name,price,our,rid}]}
    _json_rids = {}        # display_name -> {detected_name: ota machine room id}

    # One pass over capture filenames: which domains actually have data?
    # Leftover auto-generated mappings (trip_com, booking_com, kayak,
    # trivago… — produced whenever those sites were browsed once) used to
    # make the scan bar flash "Extraction : Trip.com…" for sites with NO
    # capture at all. Mappings without captures are now skipped BEFORE any
    # progress message.
    _cap_domains = set()
    try:
        from vae import config as _vcfg_dirs
        _dom_re = _re.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        for _f in _vcfg_dirs.DATA_DIR.glob("*.json"):
            _m = _dom_re.match(_f.name)
            if _m:
                _cap_domains.add(_m.group(1))
    except Exception:
        _cap_domains = None   # check disabled — behave like before

    # ── THE decisive filter: only the OTA profiles the hotelier MONITORS ──
    # Having captures is NOT being watched: trip.com browsed once (2026-08-14)
    # left 29 capture files on disk and kept appearing in the scan bar even
    # with no tab open and no config entry. The active config profiles are
    # the single source of truth. The token is the URL hostname
    # ('www.expedia.co.in' → 'expedia_co_in') matched inside the VAE mapping
    # key ('www_expedia_co_in' ✓, old 'expedia_com' ✗ — stale duplicate
    # excluded at the same time).
    _active_tokens = set()
    try:
        for _o in (otas or []):
            _url = ((_o.get("url") or "").lower() or "").strip()
            if not _o.get("active", True) or not _url.startswith("http"):
                continue
            _host = _url.split("//", 1)[-1].split("/")[0]
            _host = _host.replace(".", "_")
            if _host.startswith("www_"):
                _host = _host[4:]
            if _host:
                _active_tokens.add(_host)
        # Reference OTA (price benchmark), if one is configured: it is
        # deliberately watched, captures or not.
        _ref = (config.get("ota_watch", {}).get("reference") or {})
        _ref_url = ((_ref.get("url") or "").lower() or "").strip()
        if _ref.get("active") and _ref_url.startswith("http"):
            _ref_host = _ref_url.split("//", 1)[-1].split("/")[0]
            _ref_host = _ref_host.replace(".", "_")
            if _ref_host.startswith("www_"):
                _ref_host = _ref_host[4:]
            if _ref_host:
                _active_tokens.add(_ref_host)
    except Exception:
        _active_tokens = set()

    # ── OTA lifecycle, on EVERY scan ───────────────────────────────────
    # Removed OTA → everything of it is purged (captures, mappings,
    # calibration, history): a commercial product leaves zero trace.
    # Newly added OTA with captures but no mapping → wired automatically.
    # Fail-safe: lifecycle issues never block the scan itself.
    try:
        _purged = ota_lifecycle_cleanup(config)
        if any(_purged.values()):
            print(f"[VAE_BRIDGE] Nettoyage OTA retiree(s) : {_purged}",
                  flush=True)
    except Exception:
        pass
    try:
        ota_lifecycle_wire_new(config)
    except Exception:
        pass

    for vae_ota_name in sorted(extractor.mappings.keys()):
        done += 1

        # Skip mappings with zero captures, silently: nothing to extract,
        # nothing to show.
        if _cap_domains is not None and vae_ota_name not in _cap_domains:
            continue
        # Skip anything the hotelier does not monitor, no matter how many
        # captures sit on disk (trip.com case, 2026-08-16).
        if _active_tokens and not any(_t in vae_ota_name
                                      for _t in _active_tokens):
            continue

        display_name = ota_name_map.get(vae_ota_name, vae_ota_name)

        # ── Airbnb: per-listing attribution ─────────────────────────────
        # Each Airbnb config entry IS one listing (URL /rooms/<id>) and one
        # room type. The generic mapping path reads similarListings — the
        # NEIGHBOUR listings' prices — so it must not be used when config
        # entries carry listing URLs. Attribute each capture to its own
        # listing via the metadata tab_url and read the page's OWN
        # displayed price (structuredDisplayPrice).
        if "airbnb" in vae_ota_name.lower():
            _listing_rooms, _listing_rows = _airbnb_listing_data(
                otas, target_currency)
            if _listing_rooms:
                # One key per listing profile — they match the monitored OTA
                # names, so the results survive the tab-bar purge that deleted
                # the old generic "Airbnb" key right after each scan.
                results.update(_listing_rooms)
                detected_report["Airbnb"] = {
                    "source_id": "airbnb",
                    "rooms": _listing_rows,
                }
                if progress_cb:
                    try:
                        progress_cb(int(done * 90 / max(total, 1)),
                                    f"Airbnb: {len(_listing_rooms)} annonces")
                    except ScanCancelled:
                        continue
                continue
            # Config HAS per-listing Airbnb entries but no usable capture
            # was found. The generic mapping path reads similarListings —
            # the NEIGHBOUR listings' prices — and must NEVER be used to
            # price this hotel's rooms: it is exactly how a rescan shuffled
            # room categories with foreign prices. Skip Airbnb for this
            # scan instead of inventing data.
            _has_listing_cfg = any(
                "airbnb" in ((o.get("url") or "").lower())
                and _re.search(r"/rooms/\d+", o.get("url") or "")
                for o in otas or [])
            if _has_listing_cfg:
                print("[VAE_BRIDGE] Airbnb: captures par annonce "
                      "introuvables — annonce ignoree pour ce scan "
                      "(jamais les prix des annonces voisines)", flush=True)
                continue

        # Skip generalist / metasearch sites
        if any(g in vae_ota_name.lower() or g in display_name.lower()
               for g in _GENERALIST_DOMAINS):
            continue

        if progress_cb:
            try:
                pct = int(done / total * 100) if total > 0 else 100
                progress_cb(pct, f"Extraction: {display_name}...")
            except ScanCancelled:
                # arrêt demandé : OTA courante sautée, suivantes aussi
                # (le callback relève l'exception à chaque appel) —
                # résultats partiels conservés
                continue

        try:
            hotel = extractor.extract_ota(vae_ota_name)
        except Exception as e:
            print(f"[VAE_BRIDGE] Error extracting {vae_ota_name}: {e}")
            continue

        if not hotel or not hotel.rooms:
            continue

        # Build {detected_room_name: price} from VAE data
        detected_prices = {}
        rid_by_name = {}     # OTA machine room id per detected name (100% anchor)
        _unnamed_idx = 0
        for room in hotel.rooms:
            if room.price and room.price.has_data:
                # Use the DISCOUNTED price (what the guest actually sees on
                # the OTA) first, then total with taxes, then base as last
                # resort.
                price = (room.price.price_after_discount_normalized
                         or room.price.total_amount_normalized
                         or room.price.base_price_normalized
                         or room.price.price_after_discount
                         or room.price.total_amount
                         or room.price.base_price)
                if price and price > 0:
                    price_int = int(round(price))
                    # Rooms with no name still carry a real price — give them
                    # a synthetic key so they reach the matching step instead
                    # of being silently dropped (Airbnb listings, etc.).
                    room_name = room.name or f"__unnamed_{_unnamed_idx}"
                    if not room.name:
                        _unnamed_idx += 1

                    # If this exact name was already seen at the SAME price,
                    # skip (true duplicate rate plan). But if the same name
                    # appears at a DIFFERENT price, keep both — Google Hotels
                    # and metasearch often label every room with the hotel
                    # name while showing different room-type prices.
                    previous = detected_prices.get(room_name)
                    if previous is None:
                        detected_prices[room_name] = price_int
                        if getattr(room, "id", ""):
                            rid_by_name[room_name] = str(room.id)
                    elif previous != price_int:
                        # Disambiguate: append an index
                        _idx = 2
                        while f"{room_name} ({_idx})" in detected_prices:
                            _idx += 1
                        detected_prices[f"{room_name} ({_idx})"] = price_int
                        if getattr(room, "id", ""):
                            rid_by_name[f"{room_name} ({_idx})"] = str(room.id)
                    # else: same name, same price → skip (duplicate)

        if not detected_prices:
            continue

        # Match detected room names to configured room types
        _src_id = _source_id_from_vae_name(vae_ota_name)
        if room_types:
            _aliases = _calib_room_aliases(_src_id)
            matched = _match_rooms(list(detected_prices.keys()), room_types,
                                   aliases=_aliases)
            # Machine-ID attribution overrides names: ids never repeat,
            # never get translated, never change on an OTA rename.
            matched = _apply_id_aliases(matched, rid_by_name, _src_id, _aliases)
        else:
            # No config room types: use detected names as-is
            matched = {name: name for name in detected_prices}

        # Build {config_room_type: price}
        # Deterministic on purpose: when one OTA name appears at several
        # prices (rate plans → disambiguated as "name" and "name (2)"),
        # several detected names map to the SAME config room. Taking the
        # last one written made the price depend on capture order, which
        # flips between scans. The LOWEST price is kept — the rate a guest
        # can actually book, stable across scans.
        room_results = {}
        for detected_name, config_room in matched.items():
            price = detected_prices.get(detected_name)
            if not price or price <= 0:
                continue
            prev = room_results.get(config_room)
            if prev is None or price < prev:
                room_results[config_room] = price

        # ── Fallback: hotel-level prices → room types ──────────────────
        # ONLY for hotel-level payloads: listings with no room name of
        # their own (metasearch cards, hotel-named listings). A NAMED room
        # that room_match refused must NEVER be force-assigned by price
        # order — that is exactly how a promotion puts the wrong price on
        # the wrong room (Expedia case, 2026-08-15). Named rooms without a
        # safe match (or a memorized alias) are logged and left aside.
        # When the user has defined room mappings ("Room names on OTAs"),
        # price-order guessing is disabled entirely for that OTA: their
        # mapping is the only authority (user report 2026-08-16: rescans
        # were reshuffling room categories by price on every OTA).
        if room_types and not _aliases:
            _assigned = set(room_results.keys())
            _unnamed_prices = sorted(
                set(p for n, p in detected_prices.items()
                    if n.startswith("__unnamed_") and p > 0))
            _free_rooms = [rt for rt in room_types if rt not in _assigned]
            for _price_val, _room in zip(_unnamed_prices, _free_rooms):
                room_results[_room] = _price_val

            _dropped = [n for n in detected_prices
                        if not n.startswith("__unnamed_") and n not in matched]
            for _n in _dropped[:6]:
                print(f"[VAE_BRIDGE] {vae_ota_name}: chambre non rapprochee "
                      f"(laissee de cote) : {_n[:44]} = "
                      f"{detected_prices[_n]}", flush=True)

            # Remove non-config keys that were orphaned
            _to_del = [rt for rt in list(room_results.keys()) if rt not in room_types]
            for _rt in _to_del:
                del room_results[_rt]

        if room_results:
            display_name = ota_name_map.get(vae_ota_name, vae_ota_name)
            results[display_name] = room_results
            detected_report[display_name] = {
                "source_id": _src_id,
                "rooms": [
                    {"name": n, "price": p,
                     "our": matched.get(n) if isinstance(matched, dict) else "",
                     "rid": rid_by_name.get(n, "")}
                    for n, p in detected_prices.items()
                    if not n.startswith("__unnamed_")
                ],
            }
        # Machine ids gathered by the JSON pass, for the DOM merge below:
        # DOM-extracted OTAs (Expedia, MakeMyTrip) replace the JSON results,
        # but the ids their JSON payloads carried survive via name
        # correlation — the dialog can then anchor on ids there too.
        _json_rids[display_name] = dict(rid_by_name)

    if progress_cb:
        progress_cb(100, "Extraction terminée")

    # ── DOM extraction fallback ───────────────────────────────────────
    # Some OTAs (Expedia, MakeMyTrip) render prices client-side in the DOM
    # instead of returning them via capturable JSON APIs.  For any OTA that
    # the JSON extraction missed, try reading prices directly from the live
    # browser tab via CDP.
    try:
        from src.extractors.dom_extractor import DomExtractor
        from src.extractors.dom_extractor import _DOMAIN_NAMES as _DOM_OTAS
        dom = DomExtractor(
            debug_port=9222,
            target_currency=target_currency,
        )
        # OTAs supported by DOM extraction must NEVER be skipped — the DOM
        # (or the SPA state) is the authoritative source for them.  Their
        # JSON APIs are anti-bot blocked or return empty pricing, so a
        # partial JSON capture (e.g. MakeMyTrip with 1 room from the
        # search page) must be replaced by the complete DOM extraction.
        _dom_supported = set(_DOM_OTAS.values())
        _skip = set(results.keys()) - _dom_supported
        dom_results = dom.extract_all(skip_otas=_skip)
        # Merge DOM results — apply the same room-matching logic
        for ota_name, room_prices in dom_results.items():
            if not room_prices:
                continue
            if progress_cb:
                progress_cb(100, f"DOM: {ota_name} ({len(room_prices)} rooms)")

            # Match detected room names to configured room types.
            # SAME alias loading as the JSON path: the mapping the user
            # saved in "Room names on OTAs" is authoritative everywhere.
            # Without this, the DOM path re-derived attribution by name
            # similarity alone and could shuffle rooms between scans.
            _dom_src = _source_id_from_vae_name(str(ota_name).lower())
            _dom_rids = dict(_json_rids.get(ota_name) or {})
            if room_types:
                _dom_aliases = _calib_room_aliases(_dom_src)
                matched = _match_rooms(list(room_prices.keys()), room_types,
                                       aliases=_dom_aliases)
                # Machine-ID attribution (ids inherited from the JSON pass
                # by name correlation) overrides names here too.
                matched = _apply_id_aliases(matched, _dom_rids, _dom_src,
                                            _dom_aliases)
            else:
                matched = {n: n for n in room_prices}

            room_results = {}
            for detected_name, config_room in matched.items():
                price = room_prices.get(detected_name)
                if price and price > 0:
                    room_results[config_room] = price

            # Same rule as the JSON path: a NAMED room without a safe match
            # is left aside — never redistributed by price order.
            if room_types:
                _to_del = [rt for rt in list(room_results.keys())
                           if rt not in room_types]
                for _rt in _to_del:
                    del room_results[_rt]
                for n in (n for n in room_prices if n not in matched):
                    print(f"[VAE_BRIDGE] {ota_name}: chambre non rapprochee "
                          f"(laissee de cote) : {n[:44]} = {room_prices[n]}",
                          flush=True)

            if room_results:
                _existing = results.get(ota_name, {})
                # Replace JSON results only when DOM extraction found at
                # least as many rooms — DOM is authoritative for the OTAs
                # it supports, but a partial DOM result shouldn't evict a
                # better JSON capture.
                if len(room_results) >= len(_existing):
                    results[ota_name] = room_results
                    detected_report[ota_name] = {
                        "source_id": _dom_src,
                        "rooms": [
                            {"name": n, "price": p,
                             "our": matched.get(n) or "",
                             "rid": _dom_rids.get(n, "")}
                            for n, p in room_prices.items()
                        ],
                    }
    except Exception as e:
        print(f"[VAE_BRIDGE] DOM extraction error: {e}")

    _save_detected_report(detected_report)

    # D80 : journal juridique — chaque prix affiché lu part au registre
    # de preuves (append-only, jamais purgé). Échec non bloquant.
    try:
        from business import legal_ledger as _ll
        for _ota, _rooms in (results or {}).items():
            for _room, _price in (_rooms or {}).items():
                _ll.journal_price_read(_ota, _room, _price,
                                       currency=target_currency,
                                       source="scan OTA")
    except Exception:
        pass

    return results


def _save_detected_report(report: dict) -> None:
    """Best-effort persistence of the room names each OTA displayed during
    this scan — feeds the 'Correspondance des chambres OTA' dialog so the
    hotelier maps names picked from real data, never typed blind."""
    if not report:
        return
    try:
        import datetime
        from core.paths import DATA_DIR
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        path = DATA_DIR / "ota_detected_rooms.json"
        path.write_text(
            json.dumps({"updated": datetime.datetime.now().isoformat(timespec="seconds"),
                        "otas": report}, ensure_ascii=False, indent=1),
            encoding="utf-8")
    except Exception:
        pass


def _airbnb_parse_price(s: str):
    """Parse an Airbnb display price in any locale layout.

    Handles symbol-after ("24 €", FR) and symbol-before ("$2,431", EN),
    with FR decimal commas ("24,5 €") vs EN thousands commas ("2,431").
    Returns (float, symbol) or (None, None).
    """
    s = s.replace("\u00a0", " ").replace("\u202f", " ").strip()
    m = (_re.search(r"([\d][\d\s.,]*)\s*(€|₹|\$|£)", s)
         or _re.search(r"(€|₹|\$|£)\s*([\d][\d\s.,]*)", s))
    if not m:
        return None, None
    g = m.groups()
    num_s, sym = (g[0], g[1]) if g[1] in "€₹$£" else (g[1], g[0])
    num_s = num_s.strip()
    if "," in num_s and "." in num_s:
        num_s = num_s.replace(",", "")            # EN: 2,431.00
    elif "," in num_s:
        parts = num_s.split(",")
        if len(parts[-1]) == 3 and all(len(p) == 3 for p in parts[1:]):
            num_s = num_s.replace(",", "")        # thousands: 2,431
        else:
            num_s = num_s.replace(",", ".")       # FR decimal: 24,5
    num_s = num_s.replace(" ", "")
    try:
        return float(num_s), sym
    except ValueError:
        return None, None


def _airbnb_state_price(prices, target_currency: str):
    """Best integer price (target currency) from raw display strings found
    on ONE listing's page (D100).

    A listing page repeats its OWN price across its sections; when several
    distinct values still appear, the most common wins so a stray promo
    badge cannot outweigh the book module."""
    _sym_map = {"€": "EUR", "₹": "INR", "$": "USD", "£": "GBP"}
    conv = None
    try:
        from vae.src.extractors.currency_converter import CurrencyConverter
        conv = CurrencyConverter()
    except Exception:
        conv = None
    votes = {}
    for cand in prices or []:
        p = _airbnb_parse_price(str(cand))
        if p is None:
            continue
        num, sym = p
        cur = _sym_map.get(sym, "EUR")
        if conv is not None and cur != target_currency:
            try:
                num = conv.convert(num, cur, target_currency)
            except Exception:
                continue
        if not num or num <= 0:
            continue
        val = int(round(num))
        votes[val] = votes.get(val, 0) + 1
    if not votes:
        return None
    return max(votes.items(), key=lambda kv: (kv[1], kv[0]))[0]


def _airbnb_live_price(listing_id: str, target_currency: str):
    """Displayed price of an OPEN Airbnb listing tab, via CDP.

    Finds the browser tab whose URL contains /rooms/<listing_id> and reads
    the page's own price — first from its embedded structured state
    (per-listing truth, same shape as the captured API bodies), then from
    the visible text as a last resort. Returns (price_in_target_currency,
    source) with source 'page-state' or 'page-text', or (None, None) when
    the tab is closed, the page has no price yet, or anything fails.
    Pure read — no navigation, no click."""
    import asyncio
    import urllib.request
    import websockets

    def _read_tab():
        try:
            tabs = json.load(urllib.request.urlopen(
                "http://localhost:9222/json", timeout=5))
        except Exception:
            return None
        for t in tabs:
            if t.get("type") == "page" and \
               f"/rooms/{listing_id}" in (t.get("url") or ""):
                return t
        return None

    def _tab_still_on_listing(ws_url: str) -> bool:
        """Anti-crossing re-check AFTER the read.

        The auto-refresh navigates Airbnb tabs between listings. A read that
        started on listing X's tab can land after the tab moved to listing Y
        — the price returned would be Y's, attributed to X (measured
        2026-08-16: scan readings crossed exactly this way). Re-listing the
        tabs and confirming the SAME socket still shows /rooms/<listing_id>
        kills the race: when in doubt, no price at all."""
        try:
            tabs = json.load(urllib.request.urlopen(
                "http://localhost:9222/json", timeout=5))
        except Exception:
            return False
        for t in tabs:
            if t.get("webSocketDebuggerUrl") == ws_url:
                return f"/rooms/{listing_id}" in (t.get("url") or "")
        return False

    async def _evaluate(ws_url: str):
        # D100 — the page's OWN embedded state first, DOM text last.
        # Airbnb hydrates its PDP from <script type="application/json">
        # blobs that contain the very same stayProductDetailPage sections
        # as the captured API bodies — walking them yields the price of
        # THIS listing and only this listing. The legacy text scan took
        # the FIRST "N € au total" of the DOM, which on a hotel PDP can be
        # another room's card or the property-level "from" price — exactly
        # how two listings reported the same price (client bundle
        # 2026-10-07: Double and Balcony both read 1735 INR).
        js = r'''
        (() => {
          const found = [];
          const walk = (n, d) => {
            if (!n || typeof n !== 'object' || d > 16 || found.length >= 8) return;
            for (const k of Object.keys(n)) {
              const v = n[k];
              if (k === 'structuredDisplayPrice' && v && typeof v === 'object') {
                const line = v.primaryLine || {};
                const s = line.discountedPrice || line.price || '';
                if (s) found.push(String(s));
              } else if (v && typeof v === 'object') {
                walk(v, d + 1);
              }
            }
          };
          for (const sc of document.querySelectorAll('script[type="application/json"]')) {
            try { walk(JSON.parse(sc.textContent), 0); } catch (e) {}
            if (found.length) break;
          }
          if (found.length) return JSON.stringify({src: 'state', prices: found});
          const els = document.querySelectorAll('span, div');
          for (const e of els) {
            const t = (e.textContent || '').replace(/\s+/g, ' ').trim();
            if (t.length > 60) continue;
            const m = t.match(/(\d{1,6}(?:[.,]\d{1,2})?)\s*([€$₹])\s*(?:au total|total)/i)
                  || t.match(/(\d{1,6}(?:[.,]\d{1,2})?)\s*([€$₹])\s*\/\s*nuit/i);
            if (m) return JSON.stringify({src: 'text', prices: [m[1] + m[2]]});
          }
          return null;
        })()
        '''
        async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
            await ws.send(json.dumps({
                "id": 1, "method": "Runtime.evaluate",
                "params": {"expression": js, "returnByValue": True}}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(), timeout=6))
                if data.get("id") == 1:
                    return (data.get("result", {}).get("result", {})
                            .get("value"))

    try:
        tab = _read_tab()
        if not tab:
            return None, None
        val = asyncio.run(_evaluate(tab["webSocketDebuggerUrl"]))
        if not val:
            return None, None
        # Navigation race: the tab may have been navigated to another
        # listing between the URL match and the read (auto-refresh). The
        # price read would belong to the WRONG listing — discard it.
        if not _tab_still_on_listing(tab["webSocketDebuggerUrl"]):
            return None, None
        src, prices = "text", []
        try:
            payload = json.loads(val)
            src = payload.get("src") or "text"
            prices = payload.get("prices") or []
        except (TypeError, ValueError):
            prices = [str(val)]
        out = _airbnb_state_price(prices, target_currency)
        if not out:
            return None, None
        return out, ("page-state" if src == "state" else "page-text")
    except Exception:
        return None, None


# How many newest Airbnb capture metas the scan reads when the live read
# misses (D100): parsing is meta-only until a body is selected, so the
# window can be widened cheaply if PDP bodies turn sparse.
_AIRBNB_META_WINDOW = 400


def _airbnb_listing_data(otas: list, target_currency: str):
    """Per-listing Airbnb extraction.

    Returns ({profile_name: {room_type: price_int}}, [{name, price, our}]) —
    one result KEY per configured listing profile ('Airbnb Double Room',
    'Airbnb Deluxe Double Room', …), one entry per listing in the rows.
    The per-profile keys are essential: the OTA-watch tab rebuild purges any
    last_results key that is not a monitored profile name, so the old single
    generic "Airbnb" key was silently deleted right after each scan — Airbnb
    never reached the correction loop (user report 2026-08-16).
    The listing id comes from each config entry's URL (/rooms/<id>). CAPTURE
    ATTRIBUTION is by the listing id found INSIDE each response body when
    possible (the only unfalsifiable source: a body written by listing X
    names listing X); metadata tab_url is only the fallback — it goes stale
    the moment a tab navigates from one listing to another, which is how
    prices rotated between listings (user report 2026-08-16). Among a
    listing's captures, the ones navigated on a FUTURE night are preferred
    (D100 — config check_in dates froze in August and would never match);
    the price read is
    stayProductDetailPage.sections.sections[].section
    .structuredDisplayPrice.primaryLine.price, converted to the target
    currency."""
    from vae import config as _vcfg

    entries = []
    for o in otas or []:
        url = (o.get("url") or "")
        name = (o.get("name") or "").strip()
        m = _re.search(r"/rooms/(\d+)", url)
        if m and "airbnb" in url.lower():
            room = (name[len("Airbnb"):].strip()
                    if name.lower().startswith("airbnb") else name)
            if room:
                ci = _re.search(r"check_in=(\d{4}-\d{2}-\d{2})", url)
                entries.append((m.group(1), room, name or room,
                                ci.group(1) if ci else ""))
    if not entries:
        return {}, []

    _SYM = {"€": "EUR", "₹": "INR", "$": "USD", "£": "GBP"}
    _lid_set = {lid for lid, _, _, _ in entries}

    # Index capture bodies by listing id from the PAGE URL (tab
    # attribution), newest first. Content-based re-keying was tried and
    # REJECTED (2026-08-16): Airbnb payloads reference NEIGHBOUR listings
    # and a neighbour's id can be the ONLY config id inside a page's
    # payload — re-keying on it rotates prices between listings. The tab
    # attribution is kept correct by the monitor's reconnect+context
    # refresh; the page URL (documentURL when present, tab_url otherwise)
    # is the page that actually produced the response.
    by_listing = {lid: [] for lid in _lid_set}
    try:
        metas = list(_vcfg.DATA_DIR.glob("*www_airbnb_fr.json"))
    except Exception:
        metas = []
    # Only the recent captures matter for a live price: scanning the whole
    # history (2 300+ files after a day of reloads) would parse megabytes
    # per scan for nothing.
    metas.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    for meta_path in metas[:_AIRBNB_META_WINDOW]:
        if meta_path.name.endswith("_body.json"):
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        body_path = meta_path.with_name(meta_path.name[:-5] + "_body.json")
        if not (body_path.exists() and body_path.stat().st_size > 500):
            continue
        page_url = meta.get("documentURL") or meta.get("tab_url") or ""
        m = _re.search(r"/rooms/(\d+)", page_url)
        if not m or m.group(1) not in by_listing:
            continue
        by_listing[m.group(1)].append((body_path, page_url,
                                       body_path.stat().st_mtime))
    for lid in by_listing:
        by_listing[lid].sort(key=lambda t: t[2], reverse=True)

    conv = None
    try:
        from vae.src.extractors.currency_converter import CurrencyConverter
        conv = CurrencyConverter()
    except Exception:
        conv = None

    def _price_of(body_path):
        """Displayed price (target currency int) inside one capture, or None."""
        try:
            data = json.loads(body_path.read_text(encoding="utf-8",
                                                  errors="replace"))
        except Exception:
            return None
        sections = (data.get("data", {}).get("presentation", {})
                       .get("stayProductDetailPage", {})
                       .get("sections", {}).get("sections", []))
        for sec in sections:
            if not isinstance(sec, dict):
                continue
            line = ((sec.get("section", {})
                      .get("structuredDisplayPrice") or {})
                    .get("primaryLine") or {})
            # DiscountedDisplayPriceLine carries discountedPrice +
            # originalPrice (struck-through); QualifiedDisplayPriceLine
            # carries price. The CURRENT displayed selling price is
            # discountedPrice when present.
            cand = line.get("discountedPrice") or line.get("price")
            if not cand:
                continue
            p = _airbnb_parse_price(str(cand))
            if p is None:
                continue
            num, sym = p
            cur = _SYM.get(sym, "EUR")
            if conv is not None and cur != target_currency:
                try:
                    num = conv.convert(num, cur, target_currency)
                except Exception:
                    pass
            if num and num > 0:
                return int(round(num))
        return None

    rooms, rows = {}, []
    try:
        _ab_aliases = _calib_room_aliases("airbnb") or {}
    except Exception:
        _ab_aliases = {}
    # Listing-id anchors override name labels: a renamed Airbnb profile
    # (labels are free-form text) cannot break the attribution once the
    # id table has been memorized.
    try:
        _ab_id_aliases = _calib_id_aliases("airbnb") or {}
    except Exception:
        _ab_id_aliases = {}
    _today = time.strftime("%Y-%m-%d")

    def _ci(page_url):
        m = _re.search(r"check_in=(\d{4}-\d{2}-\d{2})", page_url or "")
        return m.group(1) if m else ""

    for lid, room, label, check_in in entries:
        # D100 — live read first, but only its STRUCTURED state is trusted
        # outright: it walks the page's own embedded JSON, so the price
        # belongs to THIS listing (capture-grade attribution, no DOM
        # guessing). A text-only price ("first N € of the page") is the
        # legacy behaviour that read other rooms' cards — it is kept only
        # when no capture of this listing talks.
        found, _lsrc = _airbnb_live_price(lid, target_currency)
        _src = ("page vivante (état de la page)" if _lsrc == "page-state"
                else "page vivante (texte — confiance faible)")
        if _lsrc != "page-state":
            caps = by_listing.get(lid) or []
            # Pass 1: captures navigated on a FUTURE night — their price is
            # live market data. Matching the config entry's check_in died
            # long ago: those URLs froze their dates back in August.
            # Pass 2 (fallback): any capture of this listing — attribution
            # is still by listing id, only the dates may differ.
            passes = [[c for c in caps if _ci(c[1]) >= _today], caps]
            for pool in passes:
                for body_path, _page_url, _mt in pool:
                    _cap = _price_of(body_path)
                    if _cap:
                        found = _cap
                        _src = ("capture datée (nuit à venir)" if pool
                                else "capture")
                        break
                if found:
                    break
        if found:
            if not _src.startswith("capture"):
                print(f"[AIRBNB] {label} (annonce …{lid[-4:]}): "
                      f"{found} {target_currency} [{_src}]", flush=True)
            # Attribution priority: the user-managed name mapping FIRST
            # ("Room names on OTAs" — their truth), the listing id as
            # fallback (rescues if a profile gets renamed), config name
            # last. The id table is RE-synced from the name mapping every
            # scan, so a poisoned id entry heals itself instead of
            # overriding the user forever.
            final_room = (_ab_aliases.get(label)
                          or _ab_id_aliases.get(lid) or room)
            if _ab_aliases.get(label):
                _learn_id_alias("airbnb", lid, _ab_aliases[label])
                _ab_id_aliases[lid] = _ab_aliases[label]
            rooms.setdefault(label, {})[final_room] = found
            rows.append({"name": label, "price": found, "our": final_room,
                         "lid": lid})
    return rooms, rows


def _source_id_from_vae_name(vae_ota_name: str) -> str:
    """Config-style OTA id from a VAE domain-based name.
    'www_expedia_co_in' → 'expedia' (calibration profile key)."""
    n = str(vae_ota_name or "").lower()
    # longest first: 'makemytrip' must win over 'trip'
    for domain in ("makemytrip", "goibibo", "airbnb", "expedia", "agoda",
                   "booking", "google", "hotels", "trivago", "kayak",
                   "tripadvisor", "traveloka", "trip"):
        if domain in n:
            return domain
    return ""


def _calib_room_aliases(source_id: str) -> dict:
    """Room-name mappings memorized in the calibration profile of an OTA.

    Those pairs (OTA-displayed name → our room) are the only reliable way
    to attach names like « Basic Double Room, Garden View » to our room
    types. Read-only access; silent on any failure."""
    if not source_id:
        return {}
    try:
        from core.calib_store import load_calib_data
        data = load_calib_data() or {}
        for key, prof in (data.get("profiles") or {}).items():
            if str(key).split("||")[-1] == source_id:
                aliases = (prof or {}).get("room_aliases") or {}
                if aliases:
                    return dict(aliases)
    except Exception:
        pass
    return {}


def _calib_profile_key(source_id: str):
    """Calibration profile key holding this OTA's memorized mappings."""
    try:
        from core.calib_store import load_calib_data
        data = load_calib_data() or {}
        for key in (data.get("profiles") or {}):
            if str(key).split("||")[-1] == source_id:
                return key
    except Exception:
        pass
    return None


def _calib_id_aliases(source_id: str) -> dict:
    """Machine-ID mappings memorized for this OTA: {ota_room_id: our_room}.

    IDs (Agoda typeId, Goibibo roomCode, MakeMyTrip ratePlan/id, Airbnb
    listing id…) are the only 100%-stable anchor: unlike names they never
    repeat across rooms, never get translated, never change when the OTA
    renames a category. When an id alias exists it OVERRIDES every
    name-based decision."""
    if not source_id:
        return {}
    try:
        from core.calib_store import load_calib_data
        data = load_calib_data() or {}
        for key, prof in (data.get("profiles") or {}).items():
            if str(key).split("||")[-1] == source_id:
                ids = (prof or {}).get("room_id_aliases") or {}
                if ids:
                    return dict(ids)
    except Exception:
        pass
    return {}


def _learn_id_alias(source_id: str, ota_room_id: str, our_room: str) -> None:
    """Memorize {ota_room_id: our_room} for this OTA.

    Called ONLY when the attribution already succeeded through a source we
    trust (a user-confirmed name alias, or an explicit id alias): the id
    then becomes the durable anchor surviving any future rename of the
    room on the OTA. Fire-and-forget, load-modify-save (collision-safe
    with a running app)."""
    if not (source_id and ota_room_id and our_room):
        return
    try:
        from core.calib_store import load_calib_data, save_calib_data
        data = load_calib_data() or {}
        key = _calib_profile_key(source_id) or f"hotel||{source_id}"
        prof = data.setdefault("profiles", {}).setdefault(key, {})
        ids = prof.setdefault("room_id_aliases", {})
        if ids.get(str(ota_room_id)) != our_room:
            ids[str(ota_room_id)] = our_room
            save_calib_data(data)
    except Exception:
        pass


def _apply_id_aliases(matched: dict, rids: dict, source_id: str,
                      name_aliases: dict) -> dict:
    """Enforce machine-ID attribution over any name-based decision.

    `matched` : {detected_name: our_room} from the name engine (may miss
    refused/ambiguous entries). `rids` : {detected_name: ota_room_id}.
    An id alias wins everywhere — including rescuing rooms the name
    engine refused. When a name alias (user-confirmed truth) attributed a
    room and the id is not yet memorized, learn it: next time the OTA
    renames the category, the id still matches."""
    id_al = _calib_id_aliases(source_id)
    for det, rid in (rids or {}).items():
        if not rid:
            continue
        if rid in id_al:
            matched[det] = id_al[rid]
        if det in (name_aliases or {}):
            # The name mapping is the user-managed truth: re-sync the id
            # table from it every scan so a poisoned id entry (learned
            # during a past mis-configuration) heals itself.
            _learn_id_alias(source_id, rid, name_aliases[det])
            matched[det] = name_aliases[det]
    return matched


def _match_rooms(detected_names: list, config_room_types: list,
                 aliases: dict = None) -> dict:
    """
    Match detected room names to configured room types.
    Tries exact match first, then fuzzy matching with difflib.
    Falls back to core.room_match if available.

    Returns: {detected_name: config_room_type}
    """
    # Try OTA Guard's room_match module first.
    # match_rooms() returns (mapping, refus) where mapping uses INTEGER indices
    # into detected_names — we must unpack the tuple and convert indices to names.
    try:
        from core.room_match import match_rooms
        mapping, _refus = match_rooms(detected_names, config_room_types,
                                      aliases=aliases)
        # core.room_match is the AUTHORITY: an empty mapping means deliberate
        # refusals (ambiguity / too-dissimilar). Never fall through to the
        # difflib fallback below — raw sequence-ratio happily pairs
        # « Elite Double Room, Garden View » with the wrong room and puts
        # the price on the wrong card (seen on Expedia, 2026-08-15).
        return {detected_names[i]: room
                for i, room in mapping.items()
                if i < len(detected_names)}
    except Exception:
        pass

    # Fallback: simple fuzzy matching
    matched = {}
    used_config = set()

    # Exact matches first (case-insensitive)
    for det in detected_names:
        det_lower = det.lower().strip()
        for cfg in config_room_types:
            if cfg.lower().strip() == det_lower and cfg not in used_config:
                matched[det] = cfg
                used_config.add(cfg)
                break

    # Fuzzy match for remaining
    remaining_detected = [d for d in detected_names if d not in matched]
    remaining_config = [c for c in config_room_types if c not in used_config]

    for det in remaining_detected:
        best_match = None
        best_score = 0.0
        for cfg in remaining_config:
            score = difflib.SequenceMatcher(None, det.lower(), cfg.lower()).ratio()
            if score > best_score and score >= 0.55:
                best_score = score
                best_match = cfg
        if best_match:
            matched[det] = best_match
            remaining_config.remove(best_match)

    # Unmatched detected rooms keep their original name
    for det in detected_names:
        if det not in matched:
            matched[det] = det

    return matched


def _build_ota_name_map(otas: list, vae_mappings: dict) -> dict:
    """
    Build a mapping from VAE domain-based names to OTA Guard display names.
    e.g., 'goibibo_com' → 'Goibibo', 'www_airbnb_fr' → 'Airbnb'

    Priority: domain_display (generic names) first, then config-based
    matching for domains not in the generic list.  This prevents a VAE
    key like ``www_airbnb_fr`` from being mapped to a room-specific
    config entry such as "Airbnb Deluxe Double Room with Balcony" when
    multiple Airbnb config entries exist.
    """
    result = {}

    # 1) Generic domain → display name (takes priority)
    domain_display = {
        "goibibo": "Goibibo",
        "makemytrip": "MakeMyTrip",
        "agoda": "Agoda",
        "expedia": "Expedia",
        "airbnb": "Airbnb",
        "booking": "Booking.com",
        "google": "Google Hotels",
        "hotels": "Hotels.com",
        "trivago": "Trivago",
        "kayak": "Kayak",
        "tripadvisor": "TripAdvisor",
        "traveloka": "Traveloka",
        "trip": "Trip.com",
    }

    for vae_key in vae_mappings:
        for domain, display in domain_display.items():
            if domain in vae_key.lower():
                result[vae_key] = display
                break

    # 2) Config-based matching for VAE keys not yet mapped
    for ota in otas:
        name = ota.get("name", "")
        source_id = ota.get("source_id", "")
        url = ota.get("url", ota.get("full_url", "")).lower()

        for vae_key in vae_mappings:
            if vae_key in result:
                continue  # already mapped by domain_display
            vae_key_lower = vae_key.replace("_", ".").lower()
            domain_parts = source_id.lower().split(".")
            if any(part in vae_key_lower for part in domain_parts if len(part) > 3):
                result[vae_key] = name
                break
            if url and any(part in vae_key_lower for part in url.split(".") if len(part) > 3):
                result[vae_key] = name
                break

    # 3) Last resort: clean up the key
    for vae_key in vae_mappings:
        if vae_key not in result:
            clean = vae_key.replace("www_", "").replace("_com", "").replace("_fr", "")
            result[vae_key] = clean.replace("_", " ").title()

    return result


def start_vae_listener():
    """
    Start the VAE passive listener in a background thread.
    This connects to Brave/Chrome via CDP and captures API responses.
    Should be called once at application startup.
    """
    import asyncio
    import threading
    import logging

    _log = logging.getLogger("vae_bridge")

    def _run_listener():
        try:
            from vae.src.api.api_analyzer import main as analyzer_main
            asyncio.run(analyzer_main())
        except Exception as e:
            # Log it — a silent death here means Brave is never launched
            # and the whole listening mode is dead without any trace.
            _log.exception("VAE listener crashed: %s", e)

    thread = threading.Thread(target=_run_listener, daemon=True, name="vae-listener")
    thread.start()
    return thread


def generate_mappings():
    """
    Run the auto-mapping generator to create/update YAML mappings
    from captured data. Should be called when new OTA data is captured.
    """
    try:
        from vae.src.extractors.auto_mapping_generator import AutoMappingGenerator
        generator = AutoMappingGenerator()
        generator.run()
    except Exception as e:
        print(f"[VAE_BRIDGE] Auto-mapping error: {e}")


# ── OTA lifecycle: adding wires everything, removing cleans everything ──────

def _lifecycle_profile_ids(config: dict) -> set:
    """OTA ids that must SURVIVE a cleanup: one per configured profile
    (active or not — a deactivated OTA keeps its data), plus the shared
    stores and the generic 'airbnb' profile used by per-listing setups."""
    from core.calib_store import _normalize_ota_id, _safe_ota_id
    keep = set()
    ow = config.get("ota_watch", {}) or {}
    for o in (ow.get("otas") or []):
        name = (o.get("name") or "").strip()
        if name:
            keep.add(_safe_ota_id(_normalize_ota_id(name)))
    ref = (ow.get("reference") or {})
    if (ref.get("name") or "").strip():
        keep.add(_safe_ota_id(_normalize_ota_id(ref.get("name"))))
    keep.add("shared")
    if any(k.startswith("airbnb") for k in keep):
        keep.add("airbnb")       # generic profile: home of the listing mapping
    return keep


def _lifecycle_domain_tokens(config: dict) -> set:
    """URL domain tokens of every configured OTA (active or not)."""
    tokens = set()
    ow = config.get("ota_watch", {}) or {}
    entries = list(ow.get("otas") or [])
    if (ow.get("reference") or {}).get("url"):
        entries.append(ow["reference"])
    for o in entries:
        url = ((o.get("url") or "").lower() or "").strip()
        if not url.startswith("http"):
            continue
        host = url.split("//", 1)[-1].split("/")[0].replace(".", "_")
        if host.startswith("www_"):
            host = host[4:]
        if host:
            tokens.add(host)

    # D33 : l'EXTRANET du Channel Manager n'est pas une OTA surveillée,
    # mais ses captures (grille OTASheet, preuves POST AddBulkUpdate)
    # doivent survivre à la purge. Le 27/08, chaque scan effaçait TOUT
    # l'historique CM (les 12 POSTs réels de 15h détruits au redémarrage
    # 16:12) : le domaine channelmanager_com_au ne matchait aucun token.
    def _add_host(url_or_host):
        u = ((url_or_host or "").lower() or "").strip()
        if not u:
            return
        if "://" in u:
            u = u.split("://", 1)[-1].split("/")[0]
        host = u.split("/")[0].replace(".", "_")
        if host.startswith("www_"):
            host = host[4:]
        if not host:
            return
        tokens.add(host)
        # app.channelmanager.com.au → protéger AUSSI la forme sans le
        # sous-domaine (les captures sont étiquetées sans lui). Un seul
        # niveau, et seulement si ≥4 labels, pour ne jamais retomber sur
        # un token générique type com_au.
        parts = host.split("_")
        if len(parts) >= 4:
            tokens.add("_".join(parts[1:]))

    cm_cfg = config.get("channel_manager", {}) or {}
    for _k in ("endpoint", "api_url"):
        _add_host(cm_cfg.get(_k))
    try:
        from extranet_bridge import active_cm_map   # import paresseux : pas
        import yaml as _yaml                        # de cycle à l'import du
        from pathlib import Path as _P              # module (bridge → vae2)
        _map = _yaml.safe_load(_P(active_cm_map(config)).read_text(
            encoding="utf-8")) or {}
        _add_host("https://" + str(_map.get("extranet") or ""))
    except Exception:
        pass
    return tokens


def ota_lifecycle_cleanup(config: dict) -> dict:
    """Purge EVERYTHING belonging to OTAs that are no longer configured.

    Commercial-product requirement (user report 2026-08-16): removing an
    OTA must leave zero trace — no ghost in the scan bar, no orphan file.
    Deleted for domains/ids matching no configured profile (deactivated
    profiles KEEP their data — only removed ones are cleaned):
      - network captures (meta + body) in vae/data/api_discovery/
      - auto-generated YAML mappings in vae/config/ota_mappings/
      - calibration_data_<id>.json / send_history_<id>.json
    Backups (.bak, *_bak) are never touched. Returns a {kind: count}
    summary for logging. Fail-safe: any error aborts the cleanup, never
    the scan."""
    summary = {"captures": 0, "mappings": 0, "calibration": 0, "history": 0}
    try:
        import re as _re2
        from vae import config as _vcfg
        tokens = _lifecycle_domain_tokens(config)
        if not tokens:
            return summary          # no configured OTA: clean nothing (safety)

        # 1) Captures: <timestamp>_<domain>.json (+ _body.json)
        _dom_re = _re2.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+?)_body\.json$|"
                               r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        for f in list(_vcfg.DATA_DIR.glob("*.json")):
            m = _dom_re.match(f.name)
            if not m:
                continue
            domain = m.group(1) or m.group(2)
            if domain and not any(t in domain for t in tokens):
                try:
                    f.unlink()
                    summary["captures"] += 1
                except OSError:
                    pass

        # 2) Auto-generated mappings
        for f in list(_vcfg.get_mappings_dir().glob("*.yaml")):
            stem = f.stem
            if not any(t in stem for t in tokens):
                try:
                    f.unlink()
                    summary["mappings"] += 1
                except OSError:
                    pass

        # 3) Per-OTA stores in the app data dir
        from core.paths import DATA_DIR as _APP_DATA
        keep = _lifecycle_profile_ids(config)
        import re as _re3
        for f in list(_APP_DATA.glob("calibration_data_*.json")):
            m = _re3.match(r"^calibration_data_(.+)\.json$", f.name)
            if m and m.group(1) not in keep:
                try:
                    f.unlink()
                    summary["calibration"] += 1
                except OSError:
                    pass
        for f in list(_APP_DATA.glob("send_history_*.json")):
            m = _re3.match(r"^send_history_(.+)\.json$", f.name)
            if m and m.group(1) not in keep:
                try:
                    f.unlink()
                    summary["history"] += 1
                except OSError:
                    pass
    except Exception as e:
        print(f"[VAE_BRIDGE] cleanup OTA: {e}", flush=True)
    return summary


def ota_lifecycle_wire_new(config: dict) -> list:
    """Auto-wire newly added OTAs: for every CONFIGURED domain that has
    captures but no YAML mapping yet, generate the missing mapping — and
    only the missing ones. Known-good mappings of existing OTAs are never
    rewritten (auto-regeneration over a working mapping is how a healthy
    OTA suddenly returns no prices). Returns the wired domain list."""
    wired = []
    try:
        import re as _re2
        from vae import config as _vcfg
        from vae.src.extractors.auto_mapping_generator import AutoMappingGenerator
        tokens = _lifecycle_domain_tokens(config)
        if not tokens:
            return wired
        gen = AutoMappingGenerator()
        _dom_re = _re2.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        # Actual capture domains (e.g. 'www_airbnb_fr') for each configured
        # token — mapping files are named after THEM, not the URL token.
        domains = {}
        for f in _vcfg.DATA_DIR.glob("*.json"):
            if f.name.endswith("_body.json"):
                continue
            m = _dom_re.match(f.name)
            if not m:
                continue
            dom = m.group(1)
            if any(t in dom for t in tokens):
                domains.setdefault(dom, []).append(f)
        for dom, files in sorted(domains.items()):
            if (_vcfg.get_mappings_dir() / f"{dom}.yaml").exists():
                continue
            files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            mapping = gen.analyze_ota(files)
            if not mapping:
                continue
            out = _vcfg.get_mappings_dir() / f"{dom}.yaml"
            with open(out, "w", encoding="utf-8") as fh:
                fh.write(gen.generate_yaml(dom, mapping))
            wired.append(dom)
            print(f"[VAE_BRIDGE] OTA cablee automatiquement: {dom}", flush=True)
    except Exception as e:
        print(f"[VAE_BRIDGE] wire OTA: {e}", flush=True)
    return wired


def sync_config_from_otaguard(config: dict):
    """
    Synchronize OTA Guard's config.json → VAE's hotel.yaml and settings.
    Called at startup to keep VAE's hotel identity and target currency
    in sync with OTA Guard's configuration.

    Args:
        config: OTA Guard's config dict (from core.config.load())
    """
    import yaml as _yaml

    _VAE_CONFIG_DIR = _VAE_ROOT / "config"
    _VAE_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # --- Sync hotel.yaml ---
    hotel_data = {
        "hotel": {
            "name": config.get("hotel_name", ""),
            "aliases": [],
            "ota_ids": {},
            "unique_keywords": [],
            "location": {
                "city": config.get("hotel_city", ""),
                "country": config.get("hotel_country", ""),
            },
            "settings": {
                "default_nights": config.get("hotel_nights", 1),
                "default_adults": config.get("hotel_adults", 2),
                "default_currency": config.get("hotel_currency", "INR"),
            },
        }
    }

    # Extract OTA IDs from ota_watch config
    for ota in config.get("ota_watch", {}).get("otas", []):
        source_id = ota.get("source_id", "")
        # Map OTA Guard source_ids to VAE OTA keys
        ota_key_map = {
            "booking": "booking", "expedia": "expedia", "agoda": "agoda",
            "airbnb": "airbnb", "makemytrip": "makemytrip",
            "goibibo": "goibibo", "google_hotels": "google",
            "hotels_com": "hotels_com", "trivago": "trivago",
        }
        key = ota_key_map.get(source_id, source_id)
        # Try to extract ID from URL
        url = ota.get("url", "")
        if key and url:
            hotel_data["hotel"]["ota_ids"][key] = None  # Will be auto-detected

    # Write hotel.yaml
    hotel_file = _VAE_CONFIG_DIR / "hotel.yaml"
    with open(hotel_file, "w", encoding="utf-8") as f:
        _yaml.dump(hotel_data, f, allow_unicode=True, default_flow_style=False)

    # --- Sync target currency ---
    target_currency = config.get("hotel_currency", "INR")
    try:
        from vae.config import set_target_currency
        set_target_currency(target_currency)
    except Exception:
        pass

    # Also update settings.yaml
    settings_file = _VAE_CONFIG_DIR / "settings.yaml"
    if settings_file.exists():
        try:
            with open(settings_file, "r", encoding="utf-8") as f:
                settings = _yaml.safe_load(f) or {}
            settings["target_currency"] = target_currency
            with open(settings_file, "w", encoding="utf-8") as f:
                _yaml.dump(settings, f, allow_unicode=True, default_flow_style=False)
        except Exception:
            pass

    print(f"[VAE_BRIDGE] Config synced: hotel='{hotel_data['hotel']['name']}', "
          f"currency={target_currency}")
