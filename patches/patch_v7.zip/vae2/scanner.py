"""
VAE 2 — Scanner (brick 1, step E2).

Read-only scanner for extranet web UIs (channel managers first, OTA
extranets later). It NEVER emits a request and NEVER mutates anything:
its only input is the passive CDP captures saved on disk by the VAE
listener (the real browser generated the traffic, R1/R3).

Responsibilities (plan §4.2):
  1. locate the data responses among captures by STRUCTURAL
     fingerprints (R8: no hardcoded per-site rules in the code). A map
     may declare several sources — e.g. the CM's real per-date state
     (OTASheet grid) AND the write-side form grid (BulkUpdate);
  2. rebuild the normalized current state (rooms / rate plans / base
     prices / DAILY per-OTA prices / currency / connected OTAs) with
     full traceability (R9) and confidence (R10);
  3. validate against the learned baseline:
       - semantic label tolerance (D11): a renamed label is still
         recognized when the stable ID anchor matches and the fuzzy
         label ratio is high enough;
       - structure-change detection: fingerprint mismatch, vanished
         entity, or a previously-seen source gone → LOCK. A lock means
         ALERT, NEVER ACTION (the executor must refuse to run on a
         locked extranet).

SECURITY: some responses carry credential fields (e.g. OTAs[] on the
CM OTASheet). Extraction is WHITELIST-driven — only fields declared in
the map's ota_whitelist ever reach a report or a baseline.

Site-specific knowledge lives in vae2/maps/<extranet>.yaml — data, not
code.
"""

from __future__ import annotations

import argparse
import difflib
import json
import re
import sys
import unicodedata
import warnings
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# D104 — ancre INSTALL_DIR (jamais patchée) : __file__ est faux quand ce
# module est servi depuis data\patches\ (le dossier maps n'y existe pas).
try:
    from core.paths import INSTALL_DIR as _INSTALL_DIR
    DEFAULT_MAPS_DIR = Path(_INSTALL_DIR) / "vae2" / "maps"
except Exception:
    DEFAULT_MAPS_DIR = Path(__file__).resolve().parent / "maps"


# ── Semantic tolerance (D11) ────────────────────────────────────────────────

# Minimal synonym table, extended by the map's semantic.synonyms entry.
_BASE_SYNONYMS = {
    "dbl": "double",
    "dlx": "deluxe",
    "std": "standard",
    "rm": "room",
    "w": "with",
    "balc": "balcony",
}


def normalize_label(label: str, synonyms: Dict[str, str] = None) -> str:
    """Normalize a human label: lowercase, strip accents, collapse
    whitespace/punctuation, expand synonyms. FR/EN safe."""
    if label is None:
        return ""
    s = unicodedata.normalize("NFKD", str(label))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    table = dict(_BASE_SYNONYMS)
    if synonyms:
        table.update({k.lower(): v.lower() for k, v in synonyms.items()})
    return " ".join(table.get(tok, tok) for tok in s.split())


def label_similarity(a: str, b: str, synonyms: Dict[str, str] = None) -> float:
    """Fuzzy ratio between two labels after normalization (0.0–1.0)."""
    na, nb = normalize_label(a, synonyms), normalize_label(b, synonyms)
    if not na and not nb:
        return 1.0
    if not na or not nb:
        return 0.0
    return difflib.SequenceMatcher(None, na, nb).ratio()


# ── Data model ──────────────────────────────────────────────────────────────

@dataclass
class Trace:
    """R9 — traceability of a single extracted value."""
    source_file: str          # capture file the value comes from
    json_path: str            # JSON path inside the response body
    raw_value: Any            # original value, untouched
    confidence: float         # 0.0–1.0 (R10)
    notes: List[str] = field(default_factory=list)


@dataclass
class FingerprintReport:
    ok: bool
    matched: List[str] = field(default_factory=list)
    missing: List[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.ok:
            return "fingerprint OK (" + ", ".join(self.matched) + ")"
        return "fingerprint MISMATCH — missing: " + "; ".join(self.missing)


@dataclass
class ScanReport:
    """Full result of one scan: state + validation + locks."""
    extranet: str
    status: str                                  # "ok" | "locked" | "empty"
    captured_at: str = ""
    source_files: Dict[str, str] = field(default_factory=dict)
    sources_status: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    fingerprint: Dict[str, Any] = field(default_factory=dict)
    currency: Optional[str] = None
    rooms: List[Dict[str, Any]] = field(default_factory=list)
    rate_plans: List[Dict[str, Any]] = field(default_factory=list)
    otas: List[Dict[str, Any]] = field(default_factory=list)
    daily_prices: List[Dict[str, Any]] = field(default_factory=list)
    semantic: List[Dict[str, Any]] = field(default_factory=list)
    locks: List[str] = field(default_factory=list)

    def is_locked(self) -> bool:
        return bool(self.locks)


# ── Map + fingerprint ───────────────────────────────────────────────────────

def load_map(map_path: Path) -> Dict[str, Any]:
    with open(map_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def matches_fingerprint(body: Any, fp: Dict[str, Any]) -> FingerprintReport:
    """Structural validation of a candidate response body against a
    source fingerprint. Purely structural (R8): keys and array shapes,
    never URL strings."""
    rep = FingerprintReport(ok=True)
    if not isinstance(body, dict):
        rep.ok = False
        rep.missing.append("root object is not a JSON dict")
        return rep
    for arr_name, spec in (fp.get("root_arrays") or {}).items():
        arr = body.get(arr_name)
        if not isinstance(arr, list):
            rep.ok = False
            rep.missing.append(f"root array '{arr_name}' absent or not a list")
            continue
        min_records = int(spec.get("min_records", 1))
        if len(arr) < min_records:
            rep.ok = False
            rep.missing.append(
                f"root array '{arr_name}' has {len(arr)} records (< {min_records})")
            continue
        required = spec.get("required_fields") or []
        missing_fields = set()
        for record in arr:
            for fld in required:
                if fld not in record:
                    missing_fields.add(fld)
        if missing_fields:
            rep.ok = False
            rep.missing.append(
                f"array '{arr_name}' records missing fields: "
                + ", ".join(sorted(missing_fields)))
        else:
            rep.matched.append(
                f"{arr_name}[{len(arr)}] with fields {', '.join(required)}")
    return rep


# ── Capture loading ─────────────────────────────────────────────────────────

def load_capture_body(cap_file: Path) -> Tuple[Optional[Any], Dict[str, Any]]:
    """Load a VAE listener capture: metadata (dict) + decoded body.
    Body is either inline in the metadata file or in the companion
    '<name>_body.json' file. Returns (None, meta) when unavailable."""
    try:
        meta = json.loads(cap_file.read_text(encoding="utf-8"))
    except Exception:
        return None, {}
    body = meta.get("body")
    if body is None and not cap_file.name.endswith("_body.json"):
        companion = cap_file.with_name(
            cap_file.name[: -len(".json")] + "_body.json")
        if companion.exists():
            try:
                body = json.loads(companion.read_text(encoding="utf-8"))
            except Exception:
                body = None
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except Exception:
            return None, meta
    return body, meta


def find_source_candidates(captures_dir: Path, extranet: str,
                           source_name: str, source_cfg: Dict[str, Any],
                           max_candidates: int = 2000) -> List[Dict[str, Any]]:
    """Scan capture files (newest first) and return every candidate whose
    body structurally matches this source fingerprint. The learned
    'endpoint_hint' only ORDERs candidates (a renamed endpoint still
    works, R7/R8).

    Performance: the listener names files after the response domain, so
    a cheap filename pre-filter avoids parsing thousands of unrelated
    captures (tracking spam from other tabs). The URL check stays the
    authority; if the pre-filter matches nothing we fall back to a full
    scan (naming is a hint, not a dependency)."""
    host = extranet.lower()
    token = host.split(".")[0]
    hint = str(source_cfg.get("endpoint_hint", "")).lower()
    fp = source_cfg.get("fingerprint", {})
    # D102 — sort by FILENAME, not stat(): capture names embed the capture
    # timestamp (YYYYMMDD_HHMMSS_micro_domain.json), so name order IS time
    # order — and stat() on 100k+ files both wrecks the scan budget and
    # races the listener/purge: a file deleted between glob() and stat()
    # crashed the whole passive CM read ("Channel Manager status" found
    # no rooms at all — client bundle 2026-10-07).
    files = sorted(captures_dir.glob("*.json"),
                   key=lambda p: p.name, reverse=True)
    prefiltered = [p for p in files if not p.name.endswith("_body.json")
                   and token in p.name.lower()]
    scan_set = prefiltered if prefiltered else \
        [p for p in files if not p.name.endswith("_body.json")]
    out: List[Dict[str, Any]] = []
    for cap in scan_set[:max_candidates]:
        body, meta = load_capture_body(cap)
        if body is None:
            continue
        url = str(meta.get("url") or "")
        if host and host not in url.lower():
            continue
        rep = matches_fingerprint(body, fp)
        if rep.ok:
            out.append({"file": cap, "meta": meta, "body": body,
                        "fingerprint": rep,
                        "hinted": bool(hint and hint in url.lower())})
    hinted = [c for c in out if c["hinted"]]
    hinted.extend([c for c in out if not c["hinted"]])
    return hinted


# ── State building ──────────────────────────────────────────────────────────

def _trace(meta_file: Path, path: str, value: Any,
           confidence: float, notes: List[str] = None) -> Trace:
    return Trace(str(meta_file), path, value, confidence, notes or [])


def _build_identity_from_bulkupdate(candidate: Dict[str, Any],
                                    site_map: Dict[str, Any],
                                    report: ScanReport) -> None:
    """bulkupdate_grid source: rooms / rate plans (BASE prices) / OTAs."""
    body, cap = candidate["body"], candidate["file"]
    model = candidate["source_cfg"].get("state_model", {})
    sem_cfg = site_map.get("semantic", {})
    base_conf = float(sem_cfg.get("base_confidence", 0.99))

    price_notes = ["base/default price (form prefill), NOT live per-date state",
                   "currency not exposed by this endpoint"]
    price_conf = float(model.get("price_confidence_without_currency", 0.85))

    rspec = model.get("rooms", {})
    rooms_by_id: Dict[str, Dict[str, Any]] = {}
    for i, rec in enumerate(body.get(rspec.get("array", "Rooms")) or []):
        rid, rlabel = str(rec.get(rspec.get("id", "RoomId"))), rec.get(rspec.get("label", "RoomName"))
        entry = {
            "room_id": rid,
            "label": rlabel,
            "label_normalized": normalize_label(rlabel, sem_cfg.get("synonyms")),
            "trace": asdict(_trace(cap, f"$.{rspec.get('array', 'Rooms')}[{i}]", rec, base_conf)),
        }
        rooms_by_id[rid] = entry
        report.rooms.append(entry)

    pspec = model.get("rate_plans", {})
    for i, rec in enumerate(body.get(pspec.get("array", "RoomRatePlans")) or []):
        pid = str(rec.get(pspec.get("id", "RoomRatePlanId")))
        room_id = str(rec.get(pspec.get("parent_id", "RoomId")))
        label = rec.get(pspec.get("label", "RatePlanName"))
        price = rec.get(pspec.get("price", "Price"))
        room = rooms_by_id.get(room_id)
        conf = price_conf if isinstance(price, (int, float)) else 0.3
        notes = list(price_notes)
        if room is None:
            notes.append("parent room not resolved by id")
            conf = min(conf, 0.4)
        entry = {
            "rate_plan_id": pid,
            "label": label,
            "label_normalized": normalize_label(label, sem_cfg.get("synonyms")),
            "room_id": room_id,
            "room_label": room["label"] if room else None,
            "base_price": price,
            "extra_prices": {k: rec.get(k) for k in (pspec.get("extra_prices") or [])},
            "trace": asdict(_trace(cap, f"$.{pspec.get('array', 'RoomRatePlans')}[{i}]", rec, conf, notes)),
        }
        report.rate_plans.append(entry)

    ospec = model.get("otas", {})
    for i, rec in enumerate(body.get(ospec.get("array", "ConnectedOTAs")) or []):
        oid = str(rec.get(ospec.get("id", "OTAID")))
        entry = {
            "ota_id": oid,
            "label": rec.get(ospec.get("label", "OTAName")),
            "trace": asdict(_trace(cap, f"$.{ospec.get('array', 'ConnectedOTAs')}[{i}]", rec, base_conf)),
        }
        report.otas.append(entry)


def _build_daily_from_otasheet(candidate: Dict[str, Any],
                               site_map: Dict[str, Any],
                               report: ScanReport) -> None:
    """otasheet_grid source: REAL per-date prices per room/plan/OTA,
    per-date room availability, currency, connected OTAs (whitelisted).

    Cell format (validated against the on-screen grid, 2026-08-22):
    "2112,0,0,0,0,1,0.00:...,0,100" — CSV, position 0 = price."""
    body, cap = candidate["body"], candidate["file"]
    model = candidate["source_cfg"].get("state_model", {})
    sem_cfg = site_map.get("semantic", {})
    base_conf = float(sem_cfg.get("base_confidence", 0.99))

    # Rooms — the GetRoomDayDetails body carries the same Rooms[] array
    # (RoomId/RoomName) as the bulkupdate grid. Bug 2026-08-26: rooms were
    # ONLY extracted from the bulkupdate_grid source, whose fingerprint
    # matches just the RATEPLAN variant of GetRoomRateDetailsForBulkUpdate;
    # when the freshest capture is the AVAILABILITY variant (RoomRatePlans
    # empty — the SPA reloads on its last sub-tab), rooms came out EMPTY
    # and the whole push failed with "code chambre introuvable". Rooms now
    # also come from this source (dedup by room_id, first source wins).
    rspec = model.get("rooms", {})
    seen_rooms = {str(r["room_id"]) for r in report.rooms}
    for i, rec in enumerate(body.get(rspec.get("array", "Rooms")) or []):
        rid = str(rec.get(rspec.get("id", "RoomId")))
        if rid in seen_rooms:
            continue
        rlabel = rec.get(rspec.get("label", "RoomName"))
        report.rooms.append({
            "room_id": rid,
            "label": rlabel,
            "label_normalized": normalize_label(rlabel,
                                                sem_cfg.get("synonyms")),
            "trace": asdict(_trace(cap,
                                   f"$.{rspec.get('array', 'Rooms')}[{i}]",
                                   rec, base_conf)),
        })
        seen_rooms.add(rid)

    # OTAs — WHITELIST extraction only (never credential fields).
    whitelist = set(model.get("ota_whitelist") or
                    ["OTAId", "OTAName", "PrimaryCurrencyCode"])
    seen_otas: Dict[str, Dict[str, Any]] = {}
    for i, rec in enumerate(body.get(model.get("currency", {}).get("array", "OTAs"))
                            or body.get("OTAs") or []):
        oid = str(rec.get("OTAId"))
        safe = {k: rec.get(k) for k in whitelist if k in rec}
        entry = {
            "ota_id": oid,
            "label": rec.get("OTAName"),
            "currency": rec.get(model.get("currency", {}).get("field",
                                                              "PrimaryCurrencyCode")),
            "extra": {k: v for k, v in safe.items()
                      if k not in ("OTAId", "OTAName")},
            "trace": asdict(_trace(cap, f"$.OTAs[{i}]", safe, base_conf,
                                   ["credential fields excluded by whitelist"])),
        }
        seen_otas[oid] = entry
    for oid, entry in seen_otas.items():
        report.otas.append(entry)

    currencies = {e.get("currency") for e in seen_otas.values() if e.get("currency")}
    if len(currencies) == 1:
        report.currency = currencies.pop()

    # Daily prices (RateDayDetails).
    dp = model.get("daily_prices", {})
    arr_name = dp.get("array", "RateDayDetails")
    date_re = re.compile(dp.get("date_key_pattern", r"^\d{4}\.\d{2}\.\d{2}$"))
    sep = dp.get("cell", {}).get("separator", ",")
    pidx = int(dp.get("cell", {}).get("price_index", 0))
    daily_conf = 0.95
    daily_notes = ["cell price position validated against on-screen grid "
                   "(2 exact cross-checks, 2026-08-22)"]
    for i, rec in enumerate(body.get(arr_name) or []):
        head = {
            "room_id": str(rec.get(dp.get("room_key", "RoomId"))),
            "ota_id": str(rec.get("OTAId")),
            "ota_label": rec.get(dp.get("ota_label", "OTAName")),
            "plan_label": rec.get(dp.get("plan_label", "RatePlanName")),
            "room_rate_plan_id": str(rec.get("RoomRatePlanId")),
        }
        for key, cell in rec.items():
            if not date_re.match(key):
                continue
            parts = str(cell).split(sep)
            try:
                price = float(parts[pidx])
            except (ValueError, IndexError):
                price = None
            entry = dict(head)
            entry.update({
                "date": key.replace(".", "-"),
                "price": price,
                "currency": report.currency,
                "raw_cell": cell,
                "trace": asdict(_trace(cap, f"$.{arr_name}[{i}].{key}",
                                       cell, daily_conf, daily_notes)),
            })
            report.daily_prices.append(entry)

    # Per-date room availability (RoomDayDetails) — kept compact.
    ra = model.get("room_availability", {})
    if ra.get("array"):
        for i, rec in enumerate(body.get(ra["array"]) or []):
            rid = str(rec.get("RoomId"))
            for key, cell in rec.items():
                if not date_re.match(key):
                    continue
                parts = str(cell).split(sep or ",")
                try:
                    avail = int(parts[1])
                except (ValueError, IndexError):
                    continue
                report.daily_prices.append({
                    "room_id": rid, "ota_id": None, "ota_label": None,
                    "kind": "availability", "date": key.replace(".", "-"),
                    "available_rooms": avail, "price": None,
                    "raw_cell": cell,
                    "trace": asdict(_trace(cap, f"$.{ra['array']}[{i}].{key}",
                                           cell, 0.9)),
                })


# ── Baseline comparison — semantic tolerance + structure-change lock ────────

def compare_with_baseline(report: ScanReport, baseline: Dict[str, Any],
                          site_map: Dict[str, Any]) -> None:
    """Compare the current scan against the previously learned baseline.

    D11 tolerance: an entity whose stable ID matches the baseline but
    whose label changed is REPORTED as 'label_changed' (recognized, not
    new). An entity with no ID match and only a fuzzy label match is
    'unresolved' → LOCK candidate.

    Structure change: an entity present in the baseline that vanished,
    an unresolved entity, or a previously-seen SOURCE now missing →
    LOCK. A lock is an ALERT, NEVER an action.

    Prices are deliberately NOT compared: values legitimately change —
    the baseline anchors IDENTITY, not values."""
    sem_cfg = site_map.get("semantic", {})
    threshold = float(sem_cfg.get("match_threshold", 0.75))
    synonyms = sem_cfg.get("synonyms") or {}

    base_rooms = {str(r["room_id"]): r for r in baseline.get("rooms", [])}
    base_plans = {str(p["rate_plan_id"]): p for p in baseline.get("rate_plans", [])}
    base_otas = {str(o["ota_id"]): o for o in baseline.get("otas", [])}

    cur_rooms = {str(r["room_id"]) for r in report.rooms}
    cur_plans = {str(p["rate_plan_id"]) for p in report.rate_plans}
    cur_otas = {str(o["ota_id"]) for o in report.otas}

    # 1. previously-seen source now missing
    for src in baseline.get("sources", []):
        if src not in report.sources_status or not report.sources_status[src].get("found"):
            report.locks.append(
                f"source '{src}' was seen in the baseline but is missing now "
                f"— structure change suspected")

    # 2. per current entity: id anchor + fuzzy label (D11)
    for kind, entries, base in (("rooms", report.rooms, base_rooms),
                                ("rate_plans", report.rate_plans, base_plans),
                                ("otas", report.otas, base_otas)):
        id_key = {"rooms": "room_id", "rate_plans": "rate_plan_id",
                  "otas": "ota_id"}[kind]
        for entry in entries:
            eid, label = str(entry.get(id_key)), entry.get("label")
            if eid in base:
                old_label = base[eid].get("label")
                if old_label == label:
                    continue
                ratio = label_similarity(old_label, label, synonyms)
                if ratio >= threshold:
                    report.semantic.append({
                        "kind": kind, "event": "label_changed",
                        "id": eid, "old": old_label, "new": label,
                        "similarity": round(ratio, 3),
                        "action": "recognized via id anchor + fuzzy label"})
                else:
                    report.locks.append(
                        f"{kind[:-1]} id={eid!r} label changed too much: "
                        f"{old_label!r} -> {label!r} (similarity {ratio:.2f}) "
                        f"— structure change suspected")
            else:
                # no ID anchor: fuzzy rescue needs a near-certain label
                best_ratio, best_label = 0.0, None
                for bentry in base.values():
                    ratio = label_similarity(label or "", bentry.get("label", ""), synonyms)
                    if ratio > best_ratio:
                        best_ratio, best_label = ratio, bentry.get("label")
                if best_ratio >= float(sem_cfg.get("id_change_threshold", 0.90)):
                    report.semantic.append({
                        "kind": kind, "event": "id_changed_label_matches",
                        "old_label": best_label, "new_id": eid, "label": label,
                        "similarity": round(best_ratio, 3),
                        "action": "recognized (fuzzy label, high threshold)"})
                else:
                    report.locks.append(
                        f"new {kind[:-1]} id={eid!r} label={label!r} has no "
                        f"baseline match (best fuzzy {best_ratio:.2f}) — "
                        f"structure change suspected")

    # 3. vanished entities
    for kind, cur_ids, base in (("rooms", cur_rooms, base_rooms),
                                ("rate_plans", cur_plans, base_plans),
                                ("otas", cur_otas, base_otas)):
        for eid in base:
            if eid not in cur_ids:
                report.locks.append(
                    f"{kind[:-1]} id={eid!r} ({base[eid].get('label')!r}) present "
                    f"in baseline but absent from grid — structure change suspected")

    if report.locks:
        report.status = "locked"


def baseline_from_report(report: ScanReport) -> Dict[str, Any]:
    """Learned client knowledge: stable IDs + labels (never prices — the
    baseline anchors identity, not values)."""
    return {
        "extranet": report.extranet,
        "learned_at": report.captured_at,
        "sources": [name for name, st in report.sources_status.items()
                    if st.get("found")],
        "rooms": [{"room_id": r["room_id"], "label": r["label"]} for r in report.rooms],
        "rate_plans": [{"rate_plan_id": p["rate_plan_id"], "label": p["label"],
                        "room_id": p["room_id"]} for p in report.rate_plans],
        "otas": [{"ota_id": o["ota_id"], "label": o["label"]} for o in report.otas],
    }


# ── Scan orchestration ──────────────────────────────────────────────────────

def run_scan(captures_dir: Path, map_path: Path, baseline_path: Path = None,
             out_path: Path = None, save_baseline_to: Path = None) -> ScanReport:
    site_map = load_map(map_path)
    extranet = site_map.get("extranet", "?")
    report = ScanReport(extranet=extranet, status="ok")

    sources = site_map.get("sources") or {}
    builders = {"otasheet_grid": _build_daily_from_otasheet,
                "bulkupdate_grid": _build_identity_from_bulkupdate}
    any_found = False
    for name, cfg in sources.items():
        candidates = find_source_candidates(captures_dir, extranet, name, cfg)
        found = bool(candidates)
        report.sources_status[name] = {
            "found": found,
            "file": str(candidates[0]["file"].name) if found else None,
        }
        if not found:
            continue
        any_found = True
        best = candidates[0]
        best["source_cfg"] = cfg
        best["source_name"] = name
        report.fingerprint[name] = {"ok": best["fingerprint"].ok,
                                    "matched": best["fingerprint"].matched,
                                    "missing": best["fingerprint"].missing}
        report.source_files[name] = str(best["file"])
        ts = str(best["meta"].get("timestamp", ""))
        if ts > report.captured_at:
            report.captured_at = ts
        builders.get(name, lambda *a: None)(best, site_map, report)

    # Merge OTAs declared by several sources (one entry per ota_id —
    # the otasheet entry wins: it carries the currency).
    if report.otas:
        merged: Dict[str, Dict[str, Any]] = {}
        for o in report.otas:
            oid = str(o["ota_id"])
            if oid not in merged or o.get("currency"):
                prev = merged.get(oid)
                if prev and not o.get("currency"):
                    o["currency"] = prev.get("currency")
                merged[oid] = o
        report.otas = list(merged.values())

    if not any_found:
        report.status = "locked"
        report.locks.append(
            "no capture in the directory structurally matches any source "
            "fingerprint of the map — structure change or missing capture")

    if baseline_path is not None and baseline_path.exists():
        baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
        compare_with_baseline(report, baseline, site_map)

    if out_path is not None:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(asdict(report), indent=2, ensure_ascii=False),
                            encoding="utf-8")
    if save_baseline_to is not None and report.status == "ok":
        save_baseline_to.parent.mkdir(parents=True, exist_ok=True)
        save_baseline_to.write_text(
            json.dumps(baseline_from_report(report), indent=2, ensure_ascii=False),
            encoding="utf-8")
    return report


# ── Before/after price comparison (verification) ───────────────────────────

def compare_reports(old: Dict[str, Any], new: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Diff the DAILY PRICES of two scan reports: answers 'which price
    changed, on which category, which OTA, which dates, from what to
    what'. Identity labels come from the reports when available.

    The grid shows a rolling date window: dates that slid out/in
    between the two scans are reported as window_slide (informational),
    NOT as changes — only dates present in BOTH scans with different
    prices count as price_changed."""
    def index(report: Dict[str, Any]) -> Dict[Tuple[str, str, str], Dict[str, Any]]:
        out: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
        for d in report.get("daily_prices") or []:
            if d.get("kind") == "availability" or d.get("price") is None:
                continue
            key = (str(d.get("room_id")), str(d.get("ota_id")), str(d.get("date")))
            out[key] = d
        return out

    rooms = {str(r["room_id"]): r.get("label")
             for r in (new.get("rooms") or old.get("rooms") or [])}
    otas = {str(o["ota_id"]): o.get("label")
            for o in (new.get("otas") or old.get("otas") or [])}
    old_ix, new_ix = index(old), index(new)

    def entry(d: Dict[str, Any], event: str, old_price, new_price,
              currency) -> Dict[str, Any]:
        return {
            "room_id": str(d.get("room_id")), "room_label": rooms.get(str(d.get("room_id"))),
            "ota_id": str(d.get("ota_id")),
            "ota_label": otas.get(str(d.get("ota_id"))) or d.get("ota_label"),
            "plan_label": d.get("plan_label"),
            "date": d.get("date"),
            "old_price": old_price, "new_price": new_price,
            "currency": currency, "event": event,
        }

    changes: List[Dict[str, Any]] = []
    for key, newd in new_ix.items():
        oldd = old_ix.get(key)
        if oldd is not None:
            if oldd.get("price") != newd.get("price"):
                changes.append(entry(
                    newd, "price_changed", oldd.get("price"), newd.get("price"),
                    newd.get("currency") or new.get("currency")))
        else:
            # date present only in the new scan: window slid forward
            changes.append(entry(
                newd, "window_slide_in", None, newd.get("price"),
                newd.get("currency") or new.get("currency")))
    for key, oldd in old_ix.items():
        if key not in new_ix:
            changes.append(entry(
                oldd, "window_slide_out", oldd.get("price"), None,
                oldd.get("currency") or old.get("currency")))
    return changes


def _print_changes(changes: List[Dict[str, Any]], old_path: Path, new_path: Path) -> None:
    print("=" * 66)
    print("VAE 2 SCANNER — PRICE CHANGES (before/after)")
    print("=" * 66)
    print(f"before : {old_path.name}")
    print(f"after  : {new_path.name}")
    print()
    slides = [c for c in changes if c["event"].startswith("window_slide")]
    real = [c for c in changes if c["event"] == "price_changed"]
    if slides:
        dates_in = sorted({c["date"] for c in slides if c["event"] == "window_slide_in"})
        dates_out = sorted({c["date"] for c in slides if c["event"] == "window_slide_out"})
        print(f"(window slide — informational, not a change: {len(slides)} cells; "
              f"in {dates_in[0]}..{dates_in[-1] if dates_in else '-'}, "
              f"out {dates_out[0] if dates_out else '-'}..{dates_out[-1] if dates_out else '-'})")
        print()
    if not real:
        print("no price change detected between the two scans.")
        return
    grouped: Dict[Tuple, List[Dict[str, Any]]] = {}
    for c in real:
        grouped.setdefault((c["room_id"], c["room_label"], c["ota_label"]), []).append(c)
    n = 0
    for (room_id, room_label, ota_label), cells in sorted(grouped.items()):
        cells.sort(key=lambda c: c["date"])
        olds = {c["old_price"] for c in cells}
        news = {c["new_price"] for c in cells}
        cur = next((c["currency"] for c in cells if c.get("currency")), "") or ""
        n += len(cells)
        arrow = f"{next(iter(olds)) if len(olds)==1 else 'mixed'} -> " \
                f"{next(iter(news)) if len(news)==1 else 'mixed'}"
        print(f"[{room_id}] {room_label} / {ota_label} — PRICE CHANGED")
        print(f"    {len(cells)} date(s) {cells[0]['date']}..{cells[-1]['date']}  {arrow} {cur}")
        if len(news) > 1 or len(olds) > 1:
            for c in cells:
                print(f"      {c['date']} : {c['old_price']} -> {c['new_price']}")
    print()
    print(f"total: {n} changed cell(s)")



# ── CLI ─────────────────────────────────────────────────────────────────────

def _print_report(report: ScanReport) -> None:
    print("=" * 66)
    print(f"VAE 2 SCANNER — {report.extranet}")
    print("=" * 66)
    print(f"status      : {report.status}")
    print(f"captured_at : {report.captured_at}")
    for name, st in report.sources_status.items():
        print(f"source {name:<16}: {'FOUND ' + str(st['file']) if st['found'] else 'missing'}")
    if report.currency:
        print(f"currency    : {report.currency}")
    print()
    if report.rooms:
        print(f"ROOMS ({len(report.rooms)})")
        for r in report.rooms:
            print(f"  [{r['room_id']}] {r['label']}")
        print()
    if report.rate_plans:
        print(f"RATE PLANS — base prices ({len(report.rate_plans)})")
        for p in report.rate_plans:
            print(f"  [{p['rate_plan_id']}] {p['room_label'] or p['room_id']} / "
                  f"{p['label']} — base {p['base_price']}")
        print()
    if report.otas:
        print(f"CONNECTED OTAS ({len(report.otas)})")
        for o in report.otas:
            cur = f", {o['currency']}" if o.get("currency") else ""
            print(f"  [{o['ota_id']}] {o['label']}{cur}")
        print()
    prices = [d for d in report.daily_prices if d.get("kind") != "availability"]
    if prices:
        print(f"DAILY PRICES ({len(prices)} room/plan/OTA x date cells)")
        by_key: Dict[str, Dict[str, Any]] = {}
        for d in prices:
            k = f"{d['room_id']}/{d['ota_label']}"
            by_key.setdefault(k, []).append(d)
        for k, cells in sorted(by_key.items()):
            vals = [c["price"] for c in cells if c.get("price") is not None]
            rng = f"{min(vals):.0f}-{max(vals):.0f}" if vals else "n/a"
            print(f"  {k:<28} {len(cells):>3} dates  price range {rng}")
        first = prices[0]
        print(f"  sample: room {first['room_id']} / {first['ota_label']} / "
              f"{first['plan_label']} / {first['date']} = {first['price']} "
              f"{first.get('currency') or ''}")
        print()
    if report.semantic:
        print(f"SEMANTIC EVENTS ({len(report.semantic)})")
        for ev in report.semantic:
            print(f"  - {ev['kind']}/{ev['event']}: {ev}")
        print()
    if report.locks:
        print(f"!! LOCKS ({len(report.locks)}) — ALERT, NEVER ACTION")
        for lock in report.locks:
            print(f"  !! {lock}")
    else:
        print("locks       : none")


def main(argv: List[str] = None) -> int:
    warnings.simplefilter("ignore")
    ap = argparse.ArgumentParser(description="VAE 2 scanner (read-only)")
    here = Path(__file__).resolve().parent
    ap.add_argument("--captures", required=False, type=Path,
                    help="VAE listener capture directory (read-only input)")
    ap.add_argument("--map", type=Path, default=here / "maps" / "channelmanager_com_au.yaml")
    ap.add_argument("--baseline", type=Path, default=None,
                    help="previously learned baseline JSON (enables semantic "
                         "tolerance + structure-change lock)")
    ap.add_argument("--out", type=Path, default=None,
                    help="write the full scan report JSON here")
    ap.add_argument("--save-baseline", type=Path, default=None,
                    help="learn/update the client baseline from this scan")
    ap.add_argument("--compare", type=Path, nargs=2, metavar=("OLD", "NEW"),
                    default=None,
                    help="diff the daily prices of two scan report JSONs "
                         "(before/after verification) and exit")
    args = ap.parse_args(argv)

    if args.compare:
        old_path, new_path = args.compare
        old = json.loads(old_path.read_text(encoding="utf-8"))
        new = json.loads(new_path.read_text(encoding="utf-8"))
        _print_changes(compare_reports(old, new), old_path, new_path)
        return 0

    if args.captures is None:
        ap.error("--captures is required unless --compare is used")

    report = run_scan(args.captures, args.map, args.baseline,
                      args.out, args.save_baseline)
    _print_report(report)
    return 0 if report.status == "ok" else 2


if __name__ == "__main__":
    sys.exit(main())
