"""
Historique des envois — un fichier JSON par OTA.

POURQUOI CE MODULE
------------------
Pour corriger un prix OTA, il faut savoir ce que l'OTA a fait du DERNIER prix
envoyé : « j'ai envoyé 2310, Agoda a affiché 1532 ». Sans cette trace, aucun
ajustement n'est possible — on ne peut pas comparer l'envoi à l'affichage si on
a oublié l'envoi.

Avant ce module, la seule trace était `Tab._ota_calib_room_sends`
(tabs/tab_blocage_ota.py) avec deux défauts :
  1. en mémoire seulement → perdue à la fermeture de l'application ;
  2. clé = chambre uniquement → Agoda 2100 / Expedia 1650 / MakeMyTrip 1700
     pour la même chambre s'écrasaient mutuellement.

Ici : un fichier par OTA (data/send_history_<ota_id>.json), même découpage que
core/calib_store.py — deux OTA ne peuvent pas entrer en collision à l'écriture.

CE QUI EST ENREGISTRÉ COMME « ENVOYÉ »
--------------------------------------
Le prix RÉELLEMENT parti au Channel Manager POUR LA DATE SCANNÉE, pas le prix
cible. Entre les deux il y a deux transformations qui doivent être intégrées :
  - remise OTA du rate plan (app_core.py) : prix / (1 − remise/100) ;
  - majoration weekend par date (scraping/channel_manager.py::weekend_rate_segments) :
    × (1 + pct/100) si le jour scanné est dans `weekend_days`.
Exemple réel : cible 2100 ₹, scan sur J+1 = vendredi, majoration +10 %
→ le prix vraiment envoyé pour cette date est 2310 ₹, pas 2100.
Enregistrer 2100 fausserait tout calcul construit dessus.

CYCLE DE VIE D'UNE MESURE
-------------------------
Une mesure naît incomplète et se complète au scan suivant :

  record_send()        → status="pending"   (sent connu, observed inconnu)
  record_observation() → status="confirmed" (observed rempli)

Règle décidée avec l'utilisateur : une observation ne compte QUE si le prix
affiché a CHANGÉ par rapport à `observed_before` (le prix affiché au moment où
la décision d'envoi a été prise). Tant qu'il est identique, l'OTA n'a pas encore
répercuté l'envoi — les mises à jour OTA peuvent dépasser largement 5 min. On
laisse alors la mesure en attente au lieu d'enregistrer un faux couple.

RÉTENTION
---------
Aucune purge : tout est conservé, y compris les mesures abandonnées et les
envois simulés (MODE TEST). Ce sont des données d'analyse pour plus tard.
Le filtrage est fait à la LECTURE par get_measures() — c'est lui qui décide ce
qui est exploitable pour un calcul (jamais de simulé, fenêtre d'âge optionnelle),
sans jamais rien effacer du fichier.
"""
import logging
import time
from datetime import datetime

from core.paths import DATA_DIR

# Normalisation du nom d'OTA : réutilisée depuis calib_store plutôt que
# recopiée. calib_store prévient déjà « à garder en synchro » avec
# tab_calibration.Tab._name_to_id ; une TROISIÈME copie finirait par divarguer
# et deux modules rangeraient la même OTA dans deux fichiers différents.
try:
    from core.calib_store import _normalize_ota_id, _safe_ota_id
except Exception:  # pragma: no cover - calib_store indisponible
    import re

    def _normalize_ota_id(name: str) -> str:
        n = (name or "").lower()
        if "agoda" in n:      return "agoda"
        if "booking" in n:    return "booking"
        if "makemytrip" in n: return "makemytrip"
        if "google" in n:     return "google_hotels"
        return n.replace(" ", "_")

    def _safe_ota_id(ota_id: str) -> str:
        s = re.sub(r"[^a-z0-9_-]+", "_", (ota_id or "").lower()).strip("_")
        return s or "_other"

_PREFIX = "send_history_"

PENDING   = "pending"
CONFIRMED = "confirmed"
ABANDONED = "abandoned"

# Retours de record_observation()
OBS_CONFIRMED  = "confirmed"    # le prix a bougé → mesure complète
OBS_UNCHANGED  = "unchanged"    # identique à observed_before → OTA pas à jour
OBS_NO_PENDING = "no_pending"   # aucun envoi en attente pour cette chambre


def ota_id(ota_name: str) -> str:
    """Nom d'OTA affiché ('Agoda', 'MakeMyTrip'…) → identifiant de fichier."""
    return _safe_ota_id(_normalize_ota_id(ota_name))


def _ota_file(oid: str):
    return DATA_DIR / f"{_PREFIX}{oid}.json"


def load(ota_name: str) -> dict:
    """Historique d'UNE OTA : {"measures": {chambre: [mesure, ...]}}."""
    fp = _ota_file(ota_id(ota_name))
    try:
        if fp.exists():
            data = __import__("json").loads(fp.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("measures", {})
                return data
    except Exception:
        logging.exception("send_history : fichier illisible — %s", fp)
    return {"measures": {}}


def save(ota_name: str, data: dict) -> bool:
    """Écriture atomique — jamais de fichier tronqué si l'app est tuée."""
    try:
        from business.secrets import atomic_write_json
        atomic_write_json(_ota_file(ota_id(ota_name)), data)
        return True
    except Exception:
        logging.exception("send_history : sauvegarde échouée (%s) — "
                          "historique NON enregistré", ota_name)
        return False


def _entries(data: dict, room: str) -> list:
    return data.setdefault("measures", {}).setdefault(room, [])


def record_send(ota_name: str, room: str, *, sent: int, target: int,
                observed_before=None, base_price=None, stay_date: str = "",
                markup_pct: float = 0.0, weekend: bool = False,
                discount_pct: float = 0.0, simulated: bool = False,
                config_room: str = "", device: str = "") -> bool:
    """Note un envoi, en attente de l'observation du scan suivant.

    `sent`            : prix RÉELLEMENT parti pour `stay_date` (remise + weekend
                        déjà appliquées) — c'est LUI qui sert aux calculs.
    `base_price`      : prix avant remise/majoration, pour comprendre après coup.
    `observed_before` : prix affiché par l'OTA au moment de la décision. Sert de
                        témoin : l'observation ne comptera que si le prix en
                        diffère.
    `simulated`       : True si MODE TEST — rien n'est réellement parti, donc la
                        mesure ne devra jamais entrer dans un calcul.

    Un envoi qui arrive alors qu'une mesure est déjà en attente marque cette
    dernière `abandoned` : son observation n'aurait plus de sens, l'envoi
    suivant a changé la donne. Elle est conservée, pas supprimée.
    """
    if not ota_name or not room:
        return False
    try:
        data = load(ota_name)
        lst  = _entries(data, room)
        for e in lst:
            if e.get("status") == PENDING:
                e["status"] = ABANDONED
                e["abandoned_reason"] = "nouvel envoi avant observation"
        now = time.time()
        lst.append({
            "status":          PENDING,
            "sent":            int(sent),
            "base_price":      int(base_price) if base_price is not None else int(sent),
            "target":          int(target) if target is not None else None,
            "observed_before": int(observed_before) if observed_before else None,
            "observed":        None,
            "stay_date":       stay_date or "",
            "markup_pct":      float(markup_pct or 0.0),
            "weekend":         bool(weekend),
            "discount_pct":    float(discount_pct or 0.0),
            "simulated":       bool(simulated),
            "config_room":     config_room or "",
            "device":          device or "",
            "checks":          0,
            "sent_ts":         now,
            "sent_at":         datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M"),
            "observed_ts":     None,
            "observed_at":     None,
        })
        return save(ota_name, data)
    except Exception:
        logging.exception("send_history : record_send a échoué (%s / %s)",
                          ota_name, room)
        return False


def record_observation(ota_name: str, room: str, observed) -> str:
    """Complète la mesure en attente avec le prix affiché par l'OTA.

    Retourne :
      OBS_CONFIRMED  → le prix a changé, la mesure est utilisable
      OBS_UNCHANGED  → identique à `observed_before` : l'OTA n'a pas encore
                       répercuté l'envoi. Rien n'est enregistré, le compteur
                       `checks` est incrémenté pour que l'appelant sache
                       combien de fois il a regardé en vain.
      OBS_NO_PENDING → aucun envoi en attente pour cette chambre.
    """
    if not ota_name or not room or not observed:
        return OBS_NO_PENDING
    try:
        observed = int(observed)
        data    = load(ota_name)
        lst     = _entries(data, room)
        pending = next((e for e in reversed(lst)
                        if e.get("status") == PENDING), None)
        if pending is None:
            return OBS_NO_PENDING

        before = pending.get("observed_before")
        if before is not None and observed == int(before):
            pending["checks"] = int(pending.get("checks", 0)) + 1
            pending["last_check_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            save(ota_name, data)
            return OBS_UNCHANGED

        now = time.time()
        pending["observed"]    = observed
        pending["observed_ts"] = now
        pending["observed_at"] = datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M")
        pending["status"]      = CONFIRMED
        save(ota_name, data)
        return OBS_CONFIRMED
    except Exception:
        logging.exception("send_history : record_observation a échoué (%s / %s)",
                          ota_name, room)
        return OBS_NO_PENDING


def pending(ota_name: str, room: str):
    """Mesure en attente d'observation pour cette chambre, ou None."""
    try:
        lst = load(ota_name).get("measures", {}).get(room, [])
        return next((e for e in reversed(lst)
                     if e.get("status") == PENDING), None)
    except Exception:
        logging.exception("send_history : pending a échoué (%s / %s)",
                          ota_name, room)
        return None


def get_measures(ota_name: str, room: str, limit=None, max_age_days=None,
                 include_simulated: bool = False, weekend=None,
                 device=None) -> list:
    """Mesures COMPLÈTES et exploitables, de la plus ancienne à la plus récente.

    Ne renvoie que des couples (sent, observed) réellement mesurés :
      - status confirmed uniquement (ni pending, ni abandoned) ;
      - envois simulés (MODE TEST) écartés par défaut : rien n'est parti au
        Channel Manager, l'OTA n'a donc rien pu refléter ;
      - `max_age_days` écarte les mesures trop vieilles — l'OTA change de
        comportement au fil du temps, une mesure d'il y a une semaine peut ne
        plus rien décrire ;
      - `limit` garde les N plus récentes.

    Comparabilité (garde-fou) :
      - `weekend=True/False` ne garde que les mesures faites sur un jour de
        même nature. Une OTA peut appliquer une promo de week-end différente de
        celle de la semaine ; mélanger les deux revient à ajuster une droite sur
        deux comportements distincts et à obtenir une pente qui ne décrit ni
        l'un ni l'autre.
      - `device` ne garde que les mesures lues sur le même support. Agoda
        n'affiche pas le même prix sur mobile et sur ordinateur.

    Le fichier n'est jamais modifié : filtrer n'est pas effacer.
    """
    try:
        lst = load(ota_name).get("measures", {}).get(room, [])
        out = []
        cutoff = (time.time() - max_age_days * 86400) if max_age_days else None
        for e in lst:
            if e.get("status") != CONFIRMED:
                continue
            if e.get("simulated") and not include_simulated:
                continue
            if not e.get("sent") or not e.get("observed"):
                continue
            if cutoff and float(e.get("observed_ts") or 0) < cutoff:
                continue
            if weekend is not None and bool(e.get("weekend")) != bool(weekend):
                continue
            if device and (e.get("device") or "") != device:
                continue
            out.append(e)
        out.sort(key=lambda e: float(e.get("observed_ts") or 0))
        return out[-limit:] if limit else out
    except Exception:
        logging.exception("send_history : get_measures a échoué (%s / %s)",
                          ota_name, room)
        return []


def stalled_checks(ota_name: str, room: str) -> int:
    """Combien de scans de suite ont trouvé le prix affiché INCHANGÉ.

    Compteur de la mesure en attente : chaque scan qui revoit exactement le prix
    d'avant l'envoi l'incrémente (cf. record_observation). Un compteur qui monte
    veut dire que le Channel Manager a bien accepté l'envoi mais que l'OTA ne le
    répercute pas. Renvoyer encore un prix n'y changerait rien — et pire,
    abandonnerait la mesure en attente, donc on n'apprendrait jamais rien.

    0 quand rien n'est en attente.
    """
    try:
        return int((pending(ota_name, room) or {}).get("checks", 0) or 0)
    except Exception:
        return 0


def last_sent(ota_name: str, room: str):
    """Dernier prix RÉELLEMENT envoyé pour cette chambre, mesuré ou non.

    Sert quand aucune mesure complète n'existe encore (l'OTA n'a pas encore
    répercuté le dernier envoi) : on ignore ce qu'elle en fera, mais on sait au
    moins d'où repartir. Les envois simulés (MODE TEST) sont écartés — rien
    n'est parti, l'OTA n'a rien reçu.
    """
    try:
        for e in reversed(load(ota_name).get("measures", {}).get(room, [])):
            if e.get("simulated"):
                continue
            if e.get("sent"):
                return int(e["sent"])
    except Exception:
        logging.exception("send_history : last_sent a échoué (%s / %s)",
                          ota_name, room)
    return None


# Écart minimal (au carré) entre les prix envoyés pour qu'une droite ait un
# sens. En dessous, les points sont confondus : le dénominateur des moindres
# carrés s'effondre et la pente obtenue n'est que du bruit.
_MIN_SPREAD = 1.0

# Pente minimale pour qu'une droite soit INVERSIBLE. Une OTA qui affiche à
# peine le même prix quel que soit l'envoi (Goibibo cas réel : 3 265→1 888,
# 5 000→1 868) donne une pente quasi nulle ; l'inversion (cible−b)/a alors
# explose — 18 167 ₹ calculés pour une cible de 2 000. En dessous de ce
# seuil on ne devine plus : la droite est refusée.
_MIN_SLOPE = 0.20
_MAX_SLOPE = 3.00

# Facteurs d'extrapolation maximaux. Même avec une pente saine, un résultat
# à 9× la cible n'est pas un prix, c'est un artefact : refus et repli.
_FACTOR_MIN = 0.40   # envoyer moins de 40 % de la cible n'a pas de sens
_FACTOR_MAX = 3.00   # ni plus du triple (l'OTA garde au moins ~33 % du prix)

# Rapport affiché/envoyé au-delà duquel le couple est jugé aberrant et écarté.
# Garde-fou volontairement large : il vise les valeurs qui ne peuvent PAS venir
# d'une tarification (un prix mal lu sur la page, une devise non convertie), pas
# les promotions agressives. Il ne prétend donc pas attraper toutes les erreurs
# de lecture — seulement celles qui sont hors de tout doute.
_RATIO_MIN = 0.10   # l'OTA afficherait moins du dixième de ce qui est envoyé
_RATIO_MAX = 3.00   # ou plus du triple (taxes et frais inclus restent en deçà)

# Fenêtre d'âge des mesures utilisées pour la proportion (D100). Une mesure
# décrit le comportement PRESENT de l'OTA ; au-delà de la fenêtre elle décrit
# une autre époque — autre tarification, autre lecteur de prix, autre devise —
# et dévie la proportion pour rien (cas réel : ratios Airbnb pollués par des
# lectures croisées entre annonces, sept. 2026). 0 = fenêtre désactivée.
_RATIO_WINDOW_DAYS = 14.0


def _robust_pts(pts):
    """Écarte les couples dont le ratio affiché/envoyé s'écarte trop de la
    médiane (≥ 4 points). Vise la pollution historique — mesures prises
    pendant les bugs d'attribution (envoyé 1 300 → affiché 3 500) : une
    seule mesure fausse dévie toute la droite sinon. Avec moins de 4
    points, on ne peut pas dire qui est l'aberrant : on ne filtre pas."""
    if len(pts) < 4:
        return pts, 0
    ratios = sorted(o / s for s, o in pts)
    med = ratios[len(ratios) // 2]
    kept = [(s, o) for s, o in pts
            if med * 0.65 <= o / s <= med * 1.55]
    if len(kept) < 2:
        return pts, 0
    return kept, len(pts) - len(kept)


def predict_sent_for(measures, target, window_days=None):
    """Quel prix envoyer pour que l'OTA finisse par afficher `target` ?

    On ne cherche PAS à deviner la formule interne de l'OTA (remise, prix
    barré, commission, promo maison…) : elle n'est pas publiée et change sans
    prévenir. On ne regarde que ce qui est vérifiable — les couples
    (envoyé → affiché) réellement observés — et on inverse la relation
    constatée.

      1 mesure          → proportion : affiché = k × envoyé. Avec un seul point
                          on ne peut pas distinguer un pourcentage d'un montant
                          fixe ; le pourcentage est le cas courant (commission),
                          c'est donc lui qu'on suppose.
      2 mesures et plus → proportion par l'origine (moindres carrés) :
                          k = Σ(envoyé × affiché) / Σ(envoyé²), donc
                          envoyé = cible / k (D35 : une commission OTA est
                          multiplicative — l'ancienne droite affine et son
                          intercept transformaient une cible atteignable en
                          renvoi perpétuel du prix déjà en place).

    La proportion est refusée si son rapport est nul ou délirant : l'OTA ne réagit
    plus aux envois, ou les mesures mélangent des époques incompatibles. On
    retombe alors sur la proportion calculée sur la mesure la plus récente,
    qui reste dirigée vers la cible.

    Retourne (prix_à_envoyer, méthode, détail_lisible), ou (None, raison, "")
    quand rien n'est exploitable.
    """
    try:
        target = float(target)
    except (TypeError, ValueError):
        return None, "cible_invalide", ""
    if target <= 0:
        return None, "cible_invalide", ""

    # Fenêtre d'âge (D100) : on rejette d'abord les mesures trop vieilles,
    # avant tout autre usage — la proportion comme le repli sur la mesure
    # la plus récente ne doivent parler que du comportement actuel.
    try:
        _win = float(window_days if window_days is not None
                     else _RATIO_WINDOW_DAYS)
    except (TypeError, ValueError):
        _win = _RATIO_WINDOW_DAYS
    _now = time.time()
    _vieilles, _mes = 0, []
    for m in measures or []:
        try:
            _ts = float(m.get("observed_ts") or m.get("sent_ts") or 0)
        except (TypeError, ValueError):
            _ts = 0.0
        if _ts and _win > 0 and (_now - _ts) > _win * 86400.0:
            _vieilles += 1
            continue
        _mes.append(m)

    pts, ecartes = [], 0
    for m in _mes:
        try:
            _s = float(m.get("sent") or 0)
            _o = float(m.get("observed") or 0)
        except (TypeError, ValueError):
            continue
        if _s <= 0 or _o <= 0:
            continue
        if not (_RATIO_MIN <= _o / _s <= _RATIO_MAX):
            # Couple impossible : prix mal lu sur la page, devise non
            # convertie… l'inclure décalerait durablement toute la droite.
            ecartes += 1
            continue
        pts.append((_s, _o))
    pts, _ec_rob = _robust_pts(pts)
    ecartes += _ec_rob
    _notes = []
    if _vieilles:
        _notes.append(f"{_vieilles} mesure(s) hors fenêtre "
                      f"(>{_win:.0f} j)")
    if ecartes:
        _notes.append(f"{ecartes} mesure(s) aberrante(s) écartée(s)")
    _note_bare = ", ".join(_notes)
    _note_ec = (" — " + _note_bare) if _notes else ""
    if not pts:
        return None, "aucune_mesure", _note_bare

    # Pourquoi la proportion n'a pas pu servir — repris dans le nom de la
    # méthode pour que le journal ne fasse pas passer un repli pour un
    # calcul complet.
    _repli = ""
    if len(pts) >= 2:
        n   = len(pts)
        sxx = sum(s * s for s, _ in pts)
        sxy = sum(s * o for s, o in pts)
        # D35 (27/08) : proportion PAR L'ORIGINE — plus de droite affine.
        # L'intercept fitté sur des mesures d'époques incompatibles
        # (≈ 0,88 × envoyé − 789) transformait la cible 1 400 en envoi
        # 2 625 : un prix DÉJÀ en place, renvoyé sans effet à l'infini
        # (point fixe, compteurs « inchangé après 12 scans »). La
        # commission d'une OTA est multiplicative — mesuré le 27/08 sur
        # Agoda : ×0,865 identique sur 3 chambres à 4 décimales près —
        # donc on fitte affiché ≈ k × envoyé et on inverse : cible / k.
        # Un fit par l'origine reste stable même quand les envois se
        # répètent (toutes les mesures contribuent au même k).
        if sxx <= 0:
            _repli = "envois trop proches"
        else:
            k = sxy / sxx
            if k < _MIN_SLOPE:
                # L'OTA répercute à peine les envois : inverser la
                # proportion fabrique des prix absurdes. Refus —
                # l'appelant avance par pas bornés et le garde-fou
                # « envois suspendus » prend le relais.
                _repli = "l'OTA ne réagit plus aux variations"
            elif k > _MAX_SLOPE:
                # Proportion absurde vers le haut : les mesures mélangent
                # des époques/des comportements incompatibles. Une vraie
                # OTA n'affiche jamais le triple de ce qu'on lui envoie.
                _repli = "proportion incohérente (mesures mélangées)"
            else:
                val = target / k
                if val > 0 and _FACTOR_MIN * target <= val <= _FACTOR_MAX * target:
                    return (int(round(val)), "proportion ajustée",
                            f"{n} mesures — affiché ≈ {k:.3f} × envoyé "
                            f"(l'OTA en garde {k * 100:.0f} %)" + _note_ec)
                _repli = "cible hors de portée de la proportion"

    _s, _o = pts[-1]
    if _repli == "l'OTA ne réagit plus aux variations":
        # Affichage indépendant de l'envoi : la proportion sur la dernière
        # mesure ne décrit rien (envoyer 4 285 ou 2 000 → même affichage).
        # Refus : l'appelant avance par pas bornés vers la cible, et le
        # garde-fou « envois suspendus » finit par prendre le relais.
        return None, _repli, _note_ec.lstrip(" —")
    val = _s * target / _o
    if _FACTOR_MIN * target <= val <= _FACTOR_MAX * target:
        return (int(round(val)),
                "proportion" if not _repli else f"proportion ({_repli})",
                f"dernière mesure {int(_s):,} → {int(_o):,} "
                f"(l'OTA en garde {_o / _s * 100:.0f} %)" + _note_ec)
    if _repli:
        return None, _repli, _note_ec.lstrip(" —")
    return None, "mesures_inexploitables", _note_ec.lstrip(" —")


def rooms(ota_name: str) -> list:
    """Chambres présentes dans l'historique de cette OTA."""
    try:
        return sorted(load(ota_name).get("measures", {}).keys())
    except Exception:
        return []
