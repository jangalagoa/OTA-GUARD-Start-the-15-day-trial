"""
activity_log.py — Traçabilité complète de la session OTA Guard.

OBJECTIF
--------
Un SEUL fichier (activity_log.txt (racine du logiciel)) qui enregistre TOUT ce qui se passe
pendant l'utilisation du logiciel, y compris ce que l'utilisateur NE voit PAS :

  • Tes interactions (navigation d'onglets, clics, lancements de scan…)   → log_ui()
  • Ce que fait le logiciel en interne (scan, moteurs, push CM…)          → log_event()
  • Les ÉCHECS CACHÉS : tout le logging DEBUG existant (là où sont déjà
    la plupart des `except: log.debug(...)`), les exceptions non rattrapées
    dans les threads, et les plantages de callbacks Tkinter (un clic qui
    "ne fait rien").

En lisant activity_log.txt (racine du logiciel), on doit pouvoir reconstituer toute la session
et distinguer « ça a marché » de « ça a échoué silencieusement ».

UTILISATION
-----------
    from business.activity_log import init_activity_log, log_ui, log_event
    init_activity_log()                      # une fois, au tout début (main.py)
    log_ui("Clic", bouton="Lancer scan")     # interaction utilisateur
    log_event("SCAN", "Agoda → 3 prix", ok=True)

Le module ne lève JAMAIS d'exception vers l'appelant (la traçabilité ne doit
jamais casser l'application).
"""
import logging
import logging.handlers
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

from core.paths import DATA_DIR

# ── D97 : amorce du chargeur de patchs signés ────────────────────────────────
# main.py importe CE module très tôt, AVANT sa branche --diagnostic et AVANT
# son propre apply_early (bloc __main__). Sans cet appel, le mode
# diagnostic d'un exe ancien chargeait ses modules diagnostiques COMPILÉS
# (pré-correctifs) : le patch signé ne pouvait jamais agir sur ce chemin.
# apply_early est idempotent, local (aucun réseau) et jamais fatal.
try:
    from core.patch_loader import apply_early as _patch_bootstrap
    _patch_bootstrap()
except Exception:
    pass

# Dans data/ (seul dossier garanti accessible en écriture une fois installé).
ACTIVITY_FILE = DATA_DIR / "activity_log.txt"

# Au-delà de cette taille au démarrage, on archive le fichier courant et on
# repart propre (garde le fichier actif lisible et borné). L'archive conserve
# l'historique précédent : activity_log_<horodatage>.txt (racine du logiciel)
_MAX_SIZE_BYTES = 5 * 1024 * 1024   # 5 Mo

# Logger dédié aux événements explicites (UI / événements applicatifs).
_act = logging.getLogger("ACTIVITY")

# Bibliothèques tierces bruyantes : limitées à WARNING pour ne pas noyer le fichier.
_NOISY = ("matplotlib", "urllib3", "selenium", "playwright", "PIL", "asyncio",
          "fontTools", "comtypes", "websockets", "httpx", "httpcore", "PIL.PngImagePlugin")

_initialized = False
_lock = threading.Lock()


# ── Format ────────────────────────────────────────────────────────────────────

class _ActivityFormatter(logging.Formatter):
    """HH:MM:SS.mmm [LEVEL ] logger | message"""
    def format(self, record):
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        ms = int(record.msecs)
        lvl = record.levelname[:7]
        name = record.name
        # Raccourcir les noms de logger trop longs (scraping.scraping → s.scraping)
        if name.startswith("scraping."):
            name = name.split(".", 1)[1]
        msg = record.getMessage()
        line = f"{ts}.{ms:03d} [{lvl:<7}] {name:<22} | {msg}"
        if record.exc_info:
            line += "\n" + "".join(traceback.format_exception(*record.exc_info)).rstrip()
        return line


# ── Rotation simple au démarrage ──────────────────────────────────────────────

def _rotate_if_large():
    try:
        if ACTIVITY_FILE.exists() and ACTIVITY_FILE.stat().st_size > _MAX_SIZE_BYTES:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            archive = DATA_DIR / f"activity_log_{stamp}.txt"
            ACTIVITY_FILE.replace(archive)
    except Exception:
        pass


# ── Initialisation ────────────────────────────────────────────────────────────

def init_activity_log() -> None:
    """Installe la traçabilité globale. Idempotent — appelable plusieurs fois."""
    global _initialized
    with _lock:
        if _initialized:
            return
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            _rotate_if_large()

            handler = logging.FileHandler(ACTIVITY_FILE, encoding="utf-8", mode="a")
            handler.setLevel(logging.DEBUG)
            handler.setFormatter(_ActivityFormatter())
            handler._is_activity_handler = True   # marqueur anti-doublon

            root = logging.getLogger()
            # Éviter d'ajouter deux fois le handler (relance / réimport)
            if not any(getattr(h, "_is_activity_handler", False) for h in root.handlers):
                root.addHandler(handler)

            # Le niveau racine doit descendre à DEBUG pour que les échecs
            # cachés (log.debug) atteignent le fichier d'activité…
            root.setLevel(logging.DEBUG)
            # …mais on garde les handlers EXISTANTS (console, ota_guard.log) à
            # INFO pour ne pas les inonder de DEBUG.
            for h in root.handlers:
                if getattr(h, "_is_activity_handler", False):
                    continue
                if h.level < logging.INFO:
                    h.setLevel(logging.INFO)

            # Silencier les bibliothèques tierces bruyantes.
            for name in _NOISY:
                logging.getLogger(name).setLevel(logging.WARNING)

            _install_excepthooks()

            _initialized = True
            _banner()
        except Exception:
            # La traçabilité ne doit jamais empêcher l'app de démarrer.
            pass


def _banner():
    try:
        from version import VERSION
    except Exception:
        VERSION = "?"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bar = "=" * 78
    _act.info(bar)
    _act.info("SESSION %s  —  OTA Guard v%s", now, VERSION)
    _act.info(bar)


# ── Capture des exceptions non rattrapées ─────────────────────────────────────

def _install_excepthooks():
    # 1. Exceptions non rattrapées du thread principal
    _prev_hook = sys.excepthook

    def _hook(exc_type, exc_value, exc_tb):
        try:
            _act.critical("EXCEPTION NON RATTRAPÉE (thread principal)",
                          exc_info=(exc_type, exc_value, exc_tb))
        except Exception:
            pass
        if _prev_hook:
            try:
                _prev_hook(exc_type, exc_value, exc_tb)
            except Exception:
                pass

    sys.excepthook = _hook

    # 2. Exceptions non rattrapées dans les threads (scans, scheduler…)
    if hasattr(threading, "excepthook"):
        _prev_thook = threading.excepthook

        def _thook(args):
            try:
                import traceback as _tb
                from business.diagnostics import record_error
                record_error(
                    f"thread:{getattr(args, 'thread', None) and args.thread.name}",
                    "".join(_tb.format_exception(
                        args.exc_type, args.exc_value,
                        args.exc_traceback))[-600:])
            except Exception:
                pass
            try:
                _act.critical("EXCEPTION NON RATTRAPÉE (thread '%s')",
                              getattr(args, "thread", None) and args.thread.name,
                              exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
            except Exception:
                pass
            if _prev_thook:
                try:
                    _prev_thook(args)
                except Exception:
                    pass

        threading.excepthook = _thook


def install_tk_excepthook(root) -> None:
    """Capture les exceptions des callbacks Tkinter (un clic qui 'ne fait rien').

    À appeler depuis App.__init__ avec la fenêtre racine. Sans ça, Tkinter
    avale l'exception du handler et l'écrit juste sur stderr → invisible.
    """
    try:
        def _report(exc, val, tb):
            try:
                # D39 : nourrir l'anneau de diagnostic (remonté au vendeur
                # via le canal ops — aucun contenu sensible, juste la trace)
                import traceback as _tb
                from business.diagnostics import record_error
                record_error("ui", "".join(
                    _tb.format_exception(exc, val, tb))[-600:])
            except Exception:
                pass
            try:
                _act.error("EXCEPTION DANS UN CALLBACK UI (un clic/action a échoué)",
                           exc_info=(exc, val, tb))
            except Exception:
                pass
        root.report_callback_exception = _report
    except Exception:
        pass


# ── API publique ──────────────────────────────────────────────────────────────

def _fmt_details(details: dict) -> str:
    if not details:
        return ""
    parts = []
    for k, v in details.items():
        if k == "ok":
            continue
        parts.append(f"{k}={v}")
    return ("  {" + ", ".join(parts) + "}") if parts else ""


def log_ui(action: str, **details) -> None:
    """Interaction utilisateur (clic, navigation, saisie validée…)."""
    try:
        _act.info("👤 %s%s", action, _fmt_details(details))
    except Exception:
        pass


def log_event(category: str, message: str, ok: bool = None, **details) -> None:
    """Événement applicatif interne.

    ok=True  → ✅ succès
    ok=False → ❌ échec (souvent invisible pour l'utilisateur)
    ok=None  → information neutre
    """
    try:
        mark = "" if ok is None else ("✅ " if ok else "❌ ")
        lvl = logging.INFO if ok is not False else logging.WARNING
        _act.log(lvl, "[%s] %s%s%s", category, mark, message, _fmt_details(details))
    except Exception:
        pass


def section(title: str) -> None:
    """Sépare visuellement une nouvelle phase (ex: début d'un scan complet)."""
    try:
        _act.info("──────── %s ────────", title)
    except Exception:
        pass
