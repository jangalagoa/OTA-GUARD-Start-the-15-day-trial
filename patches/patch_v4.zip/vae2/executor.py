"""
VAE 2 — Executor (brick 2, steps E3/E4).

Drives the REAL extranet form via trusted CDP input events only
(Input.dispatchMouseEvent / Input.dispatchKeyEvent — isTrusted=true).
NEVER emits an HTTP request and never replays XHR/fetch (R1 extended
to writing). Element discovery is READ-ONLY (Runtime.evaluate over the
live DOM — same passive precedent as VAE 1's _airbnb_live_price).

Modes:
  TEST (default) — performs every interaction up to (but NOT
  including) the final submit click. Zero real modification.
  REAL — also clicks submit, but only after every read-back
  verification passed. The coordinator gates REAL behind the owner's
  explicit confirmation (plan E4: manual validation first).

Discipline:
  D5  slower than a human — random delays between every event
  D8  one room/plan + one OTA + one date range per run
  D12 any unexpected state -> stop, leave the page as-is, report

Site-specific knowledge comes from the map (vae2/maps/*.yaml) —
this module stays generic (R8).
"""

from __future__ import annotations

import argparse
import asyncio
import json
import random
import re
import sys
import time
import warnings
from dataclasses import dataclass, field, asdict
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.request import Request, urlopen

from vae2.scanner import load_map, DEFAULT_MAPS_DIR
from vae2.adapters import ExtranetAdapter

try:
    import websockets
    WEBSOCKETS_AVAILABLE = True
except Exception:
    WEBSOCKETS_AVAILABLE = False


class ExecutorError(Exception):
    """Raised on any unexpected state — triggers the D12 stop."""


class CMLoginRequired(ExecutorError):
    """The CM session expired and the page now shows a LOGIN form.
    Recovery belongs to the owner: log in once in the existing tab.
    NEVER navigate, recycle or close tabs in this state — a recycled
    tab just lands on the login page again (live complaint 2026-08-23:
    the retry ladder kept opening new windows, each one asking for the
    password manually)."""


# ── Tab discovery (read-only HTTP to the local CDP endpoint) ────────────────

def list_tabs(debug_port: int = 9222) -> List[dict]:
    url = f"http://127.0.0.1:{debug_port}/json/list"
    with urlopen(Request(url), timeout=3) as resp:
        return json.loads(resp.read().decode())


def find_tab(substr: str, debug_port: int = 9222) -> Optional[dict]:
    for tab in list_tabs(debug_port):
        if tab.get("type") == "page" and substr.lower() in (tab.get("url") or "").lower():
            return tab
    return None


# ── Journal ─────────────────────────────────────────────────────────────────

@dataclass
class ActionLog:
    ts: str
    action: str
    detail: str
    ok: bool = True


# ── Read-only locator JS (built from the map's locate block) ────────────────

_LOCATE_TEMPLATE = r"""
(function() {
    function info(el) {
        if (!el) return null;
        var r = el.getBoundingClientRect();
        return {x: Math.round(r.x + r.width / 2),
                y: Math.round(r.y + r.height / 2),
                w: Math.round(r.width), h: Math.round(r.height),
                inViewport: r.top >= 0 && r.bottom <= window.innerHeight &&
                            r.left >= 0 && r.right <= window.innerWidth};
    }
    function box(el) { var i = info(el); return i ? JSON.stringify(i) : null; }
    var out = {};
    out.url = location.href;
    out.fields = {};
    var fields = %FIELDS%;
    for (var name in fields) {
        var el = document.querySelector(fields[name]);
        out.fields[name] = {css: fields[name], found: !!el,
                            value: el ? (el.value !== undefined ? el.value : null) : null,
                            checked: el ? !!el.checked : null,
                            box: box(el)};
    }
    out.collections = {};
    var colls = %COLLS%;
    for (var cname in colls) {
        var els = document.querySelectorAll(colls[cname]);
        var items = [];
        var v = 0;
        for (var i = 0; i < els.length; i++) {
            // hidden ng-repeat templates duplicate every checkbox — keep
            // only RENDERED elements (offsetParent null = template)
            if (els[i].offsetParent === null) continue;
            var li = els[i].closest('li') || els[i].parentElement;
            var group = els[i].closest('ul') ? els[i].closest('ul').parentElement : null;
            items.push({index: i, vindex: v++,
                        id: els[i].id || '',
                        label: (li ? li.textContent : '').replace(/\s+/g, ' ').trim().slice(0, 60),
                        group: (group ? group.textContent : '').replace(/\s+/g, ' ').trim().slice(0, 120),
                        checked: !!els[i].checked,
                        box: box(els[i])});
        }
        out.collections[cname] = {css: colls[cname], count: items.length, items: items};
    }
    var form = document.querySelector(%FORM_CSS%);
    out.form = {found: !!form, box: box(form)};
    var submit = document.querySelector(%SUBMIT_CSS%);
    out.submit = {found: !!submit,
                  text: submit ? (submit.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60) : null,
                  box: box(submit)};
    return JSON.stringify(out);
})()
"""


# ── Executor ────────────────────────────────────────────────────────────────

class Executor:
    """Drives the real form on one tab via trusted CDP input events."""

    def __init__(self, map_path: Path, test_mode: bool = True,
                 debug_port: int = 9222, log_sink=None):
        if not WEBSOCKETS_AVAILABLE:
            raise ExecutorError("websockets library is required for CDP input")
        self.site_map = load_map(map_path)
        self.adapter = ExtranetAdapter.from_map(map_path)
        self.write_cfg = self.site_map.get("write", {})
        self.loc = self.write_cfg.get("locate", {})
        self.test_mode = test_mode
        self.debug_port = debug_port
        self._log_sink = log_sink or print
        self.journal: List[ActionLog] = []
        self.ws = None
        self.tab_url = ""
        self._cmd_id = 0

    # ── journal ─────────────────────────────────────────────────────────────
    def log(self, action: str, detail: str, ok: bool = True) -> None:
        entry = ActionLog(time.strftime("%Y-%m-%dT%H:%M:%S"), action, detail, ok)
        self.journal.append(entry)
        mark = "OK " if ok else "!! "
        self._log_sink(f"[{mark}] {action}: {detail}")

    # ── connection ──────────────────────────────────────────────────────────
    def _cm_session_live_tabs(self) -> list:
        """Page tabs of this extranet carrying a LIVE session: the URL
        contains the map's extranet domain and is NOT a login/signin
        page. (Login URLs also embed the ReturnUrl, so 'login' in the
        URL reliably identifies them.)"""
        domain = (self.site_map.get("extranet") or "").lower()
        if not domain:
            return []
        live = []
        for t in list_tabs(self.debug_port):
            url = (t.get("url") or "").lower()
            if (t.get("type") == "page" and domain in url
                    and "login" not in url and "signin" not in url):
                live.append(t)
        return live

    async def _open_form_tab(self, url: str, what: str) -> dict:
        """Open ONE tab at `url` — 22/23 behavior, restored 2026-08-24 on
        the owner's order (the purge had made the form unreachable when
        no tab was open). SAFE variant: the caller MUST have checked a
        live session exists (opening on a dead session is what multiplied
        login tabs during the 23/08 incident). NEVER closes anything."""
        from urllib.request import Request as _Req, urlopen as _Uo
        with _Uo(_Req(f"http://127.0.0.1:{self.debug_port}/json/new",
                     method="PUT"), timeout=5) as r:
            tab = json.loads(r.read().decode())
        self.ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                           max_size=25 * 1024 * 1024)
        await self.cdp("Page.navigate", {"url": url})
        for _ in range(25):
            await asyncio.sleep(1)
            try:
                if await self.js("document.readyState") == "complete":
                    break
            except ExecutorError:
                pass
        await asyncio.sleep(2)
        self.log("connect", f"opened one '{what}' tab (live session "
                            f"confirmed): {url[:70]}")
        return tab

    async def connect(self, tab_substr: str = "BulkUpdate") -> None:
        tab = find_tab(tab_substr, self.debug_port)
        if not tab or not tab.get("webSocketDebuggerUrl"):
            # No form tab — 22/23 behavior: open ONE, but ONLY when a
            # LIVE extranet session already exists in another tab. On a
            # dead/absent session: stop (opening would only land on the
            # login page — 23/08 incident).
            if not self._cm_session_live_tabs():
                raise ExecutorError(
                    f"aucun onglet '{tab_substr}' et aucune session CM "
                    f"vivante dans Brave — connectez-vous une fois au CM "
                    f"puis relancez (aucun onglet n'a été ouvert ni fermé)")
            self.log("connect", f"no '{tab_substr}' tab — opening one "
                                f"(live session confirmed)")
            form_url = self.form_url
            if not form_url:
                raise ExecutorError(
                    f"adapter '{self.adapter.name}' has no write page for '{tab_substr}'")
            tab = await self._open_form_tab(form_url, tab_substr)
            self.tab_url = form_url
        else:
            self.tab_url = tab["url"]
            self.ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                               max_size=25 * 1024 * 1024)
            self.log("connect", self.tab_url)
        # PROVEN 2026-08-23: CDP-injected input reaches the page even when
        # the browser is in the background OR minimized. The OS raise is
        # NOT required for input. No tab is EVER closed or reopened here
        # (owner's order 2026-08-24) — a dead-input tab is reported, not
        # recycled.
        try:  # D98 : en pause, même le bringToFront est suspendu
            from extranet_bridge import is_paused
            if not is_paused():
                await self.cdp("Page.bringToFront", {})   # active tab in-browser only
                await self._unthrottle()
        except Exception:
            pass
        # D36 (2026-08-28): a Google Translate overlay on the page swallows
        # the elementFromPoint hit-check — every hit-checked trusted click
        # fails while the CM session is perfectly alive (proven 2026-08-27
        # 23:30: preflight_failed x3). D93: distinguish a REALLY translated
        # page (DOM artifacts → neutralize) from the stale googtrans cookie
        # left over from before the owner disabled translation (client PC
        # 05/10: alarm at EVERY connect with translation off) — the cookie
        # is deleted once and the alarm stops.
        _tr = await self._translate_probe()
        if _tr == "dom":
            self.log("translate",
                     "Google Translate detected on the page — overlay "
                     "neutralized (CSS). Recommended: disable translation "
                     "for this site in Brave", ok=False)
            await self._neutralize_translate()
        elif _tr == "cookie":
            await self._delete_googtrans_cookie()
            self.log("translate",
                     "stale googtrans cookie removed (page NOT translated — "
                     "Brave translation is off)")
        if not await self._input_alive():
            try:
                _t = str(await self.js("document.title||''") or "")
            except Exception:
                _t = ""
            self._raise_browser_window(_t)      # last resort, non-destructive
            await asyncio.sleep(1.0)
            if not await self._input_alive():
                raise ExecutorError(
                    "trusted input is dead on this tab — cliquez une fois "
                    "sur la fenêtre Brave puis relancez (aucun onglet n'a "
                    "été fermé ni ouvert)")
        await self._ensure_form_loaded()

        # D32-4: the form being PRESENT is not enough. A tab reloaded while
        # the window was hidden renders the form but never finishes the
        # Angular bootstrap: native input events still work (typing
        # "succeeds") yet every ng-click handler is dead — submits silently
        # do nothing (proven 2026-08-27 14:00-14:44: 31 submit clicks,
        # 0 POST leaving the browser). Health-check the bootstrap and, if
        # dead, finish it with the proven one-time OS raise (D31 recipe).
        if not await self._angular_alive():
            self.log("angular", "handlers dead (background-reloaded tab) — "
                               "one-time OS raise to finish the bootstrap "
                               "(D32)", ok=False)
            try:
                _t = str(await self.js("document.title||''") or "")
            except Exception:
                _t = ""
            self._raise_browser_window(_t)
            await self._unthrottle()   # D93: help the bootstrap finish
            for _ in range(15):
                await asyncio.sleep(2.0)
                if await self._angular_alive():
                    self.log("angular", "alive after one-time raise")
                    break
            else:
                raise ExecutorError(
                    "les boutons Angular de l'onglet sont morts (page "
                    "rechargée en arrière-plan) — cliquez une fois sur la "
                    "fenêtre Brave, attendez que la page finisse de "
                    "charger, puis relancez (aucun onglet n'a été fermé "
                    "ni ouvert)")

    def _raise_browser_window(self, title_hint: str = "") -> None:
        """Bring the browser window to the OS foreground (PowerShell
        AppActivate). ONLY called as a last-resort fallback when the input
        health check fails after revive — the owner's desktop is never
        disturbed otherwise (proven: input works in background/minimized).

        D98: while the global PAUSE is set this becomes a NO-OP — the
        owner is working and must never have the Brave window stolen.

        D93: `title_hint` (the tab's document.title) targets the window
        actually hosting our CM tab — the old script took the FIRST
        brave/chrome window, which on a multi-window PC raises the wrong
        one and the throttled page never unblocks (client PC 05/10:
        'raise' logged OK then preflight still failed). Brave only first,
        chrome as last-resort fallback."""
        try:  # D98 : pause globale = jamais de fenêtre volée
            from extranet_bridge import is_paused
            if is_paused():
                self.log("raise", "skipped — global pause is set (D98)")
                return
        except Exception:
            pass
        import subprocess
        hint = (title_hint or "").replace("'", " ")[:40].strip()
        try:
            ps = (
                "$sh = New-Object -ComObject 'WScript.Shell';"
                "$hint = '" + hint + "';"
                "$procs = Get-Process -Name 'brave' -ErrorAction "
                "SilentlyContinue | Where-Object "
                "{ $_.MainWindowHandle -ne 0 };"
                "$b = $null;"
                "if ($hint) { $b = $procs | Where-Object "
                "{ $_.MainWindowTitle -like ('*' + $hint + '*') } "
                "| Select-Object -First 1 };"
                "if (-not $b) { $b = $procs | Select-Object -First 1 };"
                "if (-not $b) { $b = Get-Process -Name 'chrome' "
                "-ErrorAction SilentlyContinue | Where-Object "
                "{ $_.MainWindowHandle -ne 0 } | Select-Object -First 1 };"
                "if ($b) { $sh.AppActivate($b.Id) }"
            )
            subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           timeout=8, capture_output=True)
            self.log("raise", "browser window brought to foreground"
                     + (f" (matched '{hint}')" if hint else ""))
        except Exception as e:
            self.log("raise", f"failed: {e}", ok=False)

    async def _unthrottle(self) -> None:
        """D93: keep the page considered FOCUSED and ACTIVE at the Chromium
        level even when its window is hidden/occluded. Background renderer
        throttling is what starves the CM's Angular bootstrap — the form
        never renders and every retry re-navigates a half-dead tab (client
        PC 05/10: 284 preflight_failed overnight while the 22:39 run with
        the window in the foreground pushed 22 segments). CDP-only, no
        launch-flag change (D25 recipe untouched), never fatal."""
        for method, params in (
                ("Emulation.setFocusEmulationEnabled", {"enabled": True}),
                ("Page.setWebLifecycleState", {"state": "active"})):
            try:
                await self.cdp(method, params)
            except Exception:
                pass

    async def _input_alive(self) -> bool:
        """Health check: dispatch one harmless trusted mouse-move and see
        whether the page's DOM receives it."""
        await self.js("(function(){window.__vae2mm=0;"
                      "document.addEventListener('mousemove',function()"
                      "{window.__vae2mm++},true);})()")
        await self.cdp("Input.dispatchMouseEvent",
                       {"type": "mouseMoved", "x": 400, "y": 300})
        await asyncio.sleep(0.5)
        return bool(await self.js("window.__vae2mm"))

    # REVIVED TABS ARE GONE (owner's order 2026-08-24): this executor
    # never closes and never opens a CM tab. If a tab is inert, connect()
    # reports it and the owner decides what to do.

    # Canonical form URL — navigation by URL (R4: browser-driven load, like
    # a reload) instead of text-matched clicks, which can hit the CM's side
    # menu (live incident 2026-08-23: a stray click opened Report/
    # ConnectionStatusOTA in a new tab).
    @property
    def form_url(self) -> Optional[str]:
        """Write-page URL supplied by the active adapter map."""
        return self.adapter.page_url("write")

    async def _login_state(self) -> bool:
        """True when the current page is the CM LOGIN page (session
        expired): a visible password field, or a login/signin URL."""
        raw = await self.js(
            "(function(){var pw=document.querySelector("
            "'input[type=\\\"password\\\"]');var vis=false;"
            "if(pw){var r=pw.getBoundingClientRect();"
            "vis=r.width>0&&r.height>0;}"
            "var h=(location.href||'').toLowerCase();"
            "var u=(h.indexOf('login')>=0||h.indexOf('signin')>=0);"
            "return JSON.stringify({pw:vis,u:u});})()")
        try:
            d = json.loads(raw) if raw else {}
        except (ValueError, TypeError):
            return False
        return bool(d.get("pw") or d.get("u"))

    # Generic login locators (D26 auto-login). They rely on STRUCTURE
    # (a visible text input + a visible password input in the same
    # form), never on a specific site's field names or URLs — any
    # extranet login form qualifies.
    _LOGIN_USER_JS = r"""
    (function(){
      var pws=[].slice.call(document.querySelectorAll('input[type=password]'))
        .filter(function(p){var r=p.getBoundingClientRect();
                             return r.width>0&&r.height>0;});
      if(!pws.length)return 'HIDDEN';
      var form=pws[0].form||document;
      var usr=[].slice.call(form.querySelectorAll(
          'input[type=text],input[type=email],input:not([type])'))
        .filter(function(u){var r=u.getBoundingClientRect();
                             return r.width>0&&r.height>0&&!u.readOnly;});
      if(!usr.length)return 'HIDDEN';
      var el=usr[0];
      el.scrollIntoView({block:'center'});
      var r=el.getBoundingClientRect();
      var x=r.x+r.width/2,y=r.y+r.height/2;
      var hit=document.elementFromPoint(x,y);
      var ok=!!hit&&(hit===el||el.contains(hit)||hit.contains(el));
      return JSON.stringify({x:Math.round(x),y:Math.round(y),
        top:Math.round(r.top),bottom:Math.round(r.bottom),
        ih:Math.round(window.innerHeight),hit:ok});
    })()"""

    _LOGIN_FILL_JS = r"""
    (function(){
      var pws=[].slice.call(document.querySelectorAll('input[type=password]'))
        .filter(function(p){var r=p.getBoundingClientRect();
                             return r.width>0&&r.height>0;});
      if(!pws.length)return JSON.stringify({form:false});
      var form=pws[0].form||document;
      var usr=[].slice.call(form.querySelectorAll(
          'input[type=text],input[type=email],input:not([type])'))
        .filter(function(u){var r=u.getBoundingClientRect();
                             return r.width>0&&r.height>0&&!u.readOnly;});
      return JSON.stringify({form:true,
        user_filled:usr.length>0&&usr[0].value.length>0,
        pwd_filled:pws[0].value.length>0});
    })()"""

    _LOGIN_TYPE_JS = r"""
    function(v,p){
      var pws=[].slice.call(document.querySelectorAll('input[type=password]'))
        .filter(function(p){var r=p.getBoundingClientRect();
                             return r.width>0&&r.height>0;});
      if(!pws.length)return 'NO_FORM';
      var form=pws[0].form||document;
      var target;
      if(isPwd){target=pws[0];}
      else{
        var usr=[].slice.call(form.querySelectorAll(
            'input[type=text],input[type=email],input:not([type])'))
          .filter(function(u){var r=u.getBoundingClientRect();
                               return r.width>0&&r.height>0&&!u.readOnly;});
        if(!usr.length)return 'NO_FORM';
        target=usr[0];
      }
      target.focus();
      target.value='';
      try{document.execCommand('insertText',false,val);}catch(e){
        target.value=val;
      }
      ['input','change'].forEach(function(ev){
        target.dispatchEvent(new Event(ev,{bubbles:true}));});
      return 'OK:'+ (isPwd? 'pwd' : 'user');
    }"""

    _LOGIN_SUBMIT_JS = r"""
    (function(){
      var pws=[].slice.call(document.querySelectorAll('input[type=password]'))
        .filter(function(p){var r=p.getBoundingClientRect();
                             return r.width>0&&r.height>0;});
      if(!pws.length)return 'HIDDEN';
      var form=pws[0].form||document;
      var subs=[].slice.call(
          form.querySelectorAll('button[type=submit],input[type=submit],button'))
        .filter(function(b){var r=b.getBoundingClientRect();
                            return r.width>0&&r.height>0&&!b.disabled;});
      if(!subs.length)return 'HIDDEN';
      var el=subs[0];
      el.scrollIntoView({block:'center'});
      var r=el.getBoundingClientRect();
      var x=r.x+r.width/2,y=r.y+r.height/2;
      var hit=document.elementFromPoint(x,y);
      var ok=!!hit&&(hit===el||el.contains(hit)||hit.contains(el));
      if(!ok)return 'NOHIT';
      return JSON.stringify({x:Math.round(x),y:Math.round(y),
        top:Math.round(r.top),bottom:Math.round(r.bottom),
        ih:Math.round(window.innerHeight),hit:true});
    })()"""

    async def _login_type_credentials(self) -> bool:
        """D89 : remplit user + password avec les identifiants STOCKÉS
        dans secrets.json (cm_user/cm_pass, chiffrés DPAPI). False si
        absents ou si le formulaire est introuvable. Le contenu n'est
        jamais journalisé — seuls les événements OK/KO le sont."""
        try:
            from business.secrets import load_secrets
            s = load_secrets()
        except Exception:
            return False
        user = (s.get("cm_user") or "").strip()
        pwd = (s.get("cm_pass") or "")
        if not user or not pwd:
            return False
        for val, is_pwd, tag in ((user, False, "user"),
                                 (pwd, True, "password")):
            js = ("(function(){var v=" + json.dumps(val) +
                  ",p=" + ("true" if is_pwd else "false") +
                  ";return (" + self._LOGIN_TYPE_JS + ")(v,p);})()")
            try:
                raw = await self.js(js)
            except ExecutorError:
                return False
            if not str(raw).startswith("OK"):
                self.log("autologin", f"typing {tag}: {raw}", ok=False)
                return False
        self.log("autologin", "credentials typed (structure fill)")
        return True

    async def try_auto_login(self) -> bool:
        """D26 (owner's recipe, proven live 2026-08-24): 2-click re-login
        using Brave's OWN autofill — click the visible user field so
        autofill fills BOTH fields, then click the visible submit
        button. NO credential is ever stored, typed or read by this
        software: only field FILLED status is polled (length > 0),
        never the content. Generic for any CM/OTA login form
        (structure-based locators). On any miss — autofill empty,
        button not found, still on the login page — returns False and
        touches NOTHING else (D24: no navigation, no tab recycling);
        the owner logs in manually."""
        if not await self._login_state():
            return True          # not on a login page — nothing to do
        self.log("autologin", "click 1/2: user field (Brave autofill)")
        try:
            await self._click_locator(self._LOGIN_USER_JS, "login user field")
        except ExecutorError as e:
            self.log("autologin", f"user field not clickable: {e}", ok=False)
            return False
        # autofill poll — one extra click if Brave needs a nudge
        filled = False
        for attempt in range(2):
            for _ in range(8):   # ~8 s per attempt
                await asyncio.sleep(1.0)
                try:
                    raw = await self.js(self._LOGIN_FILL_JS)
                    d = json.loads(raw) if raw else {}
                except ExecutorError:
                    d = {}
                if d.get("user_filled") and d.get("pwd_filled"):
                    filled = True
                    break
            if filled:
                break
            try:  # nudge: one more click in the user field
                await self._click_locator(self._LOGIN_USER_JS,
                                          "login user field (nudge)")
            except ExecutorError:
                pass
        if not filled:
            # D89 : Brave n'a pas rempli → secours IDENTIFIANTS DU
            # LOGICIEL (saisis une fois par l'hôtelier, chiffrés DPAPI
            # dans secrets.json — même niveau de protection que le
            # coffre Brave). Remplissage STRUCTUREL (champ texte avant
            # le champ password + events) : générique pour tout CM.
            typed = await self._login_type_credentials()
            if not typed:
                self.log("autologin",
                         "autofill did not fill and no stored credential "
                         "— manual login needed", ok=False)
                return False
            self.log("autologin",
                     "typed stored credentials (DPAPI secrets) — "
                     "click 2/2: submit")
            try:
                await self._click_locator(self._LOGIN_SUBMIT_JS,
                                          "login submit")
            except ExecutorError as e:
                self.log("autologin", f"submit not clickable: {e}",
                         ok=False)
                return False
            for _ in range(25):
                await asyncio.sleep(1.0)
                if not await self._login_state():
                    self.log("autologin",
                             "session restored (stored credentials)")
                    return True
            self.log("autologin", "still on login page after submit",
                     ok=False)
            return False
        self.log("autologin", "autofill OK — click 2/2: submit")
        self.log("autologin", "autofill OK — click 2/2: submit")
        try:
            await self._click_locator(self._LOGIN_SUBMIT_JS, "login submit")
        except ExecutorError as e:
            self.log("autologin", f"submit not clickable: {e}", ok=False)
            return False
        for _ in range(25):      # server round-trip + redirect (~25 s)
            await asyncio.sleep(1.0)
            if not await self._login_state():
                self.log("autologin", "session restored (2-click autofill)")
                return True
        self.log("autologin",
                 "still on the login page after submit — manual login "
                 "needed (wrong autofilled credentials?)", ok=False)
        return False

    async def _click_md_tab(self, label: str) -> bool:
        """Click an md-tab-item by its visible text (hit-checked,
        scrolled to center). Returns False when not found/clickable.
        Live 23/08: the SPA sits on the Availability sub-tab and a
        hash-only navigation does NOT switch it — the tab itself must
        be clicked (trusted input)."""
        expr = ("(function(){var els=document.querySelectorAll("
                "'md-tab-item');"
                "for(var i=0;i<els.length;i++){var T=els[i];"
                "if(T.offsetParent===null)continue;"
                "var t=(T.textContent||'').replace(/\\s+/g,' ').trim();"
                "if(t.toLowerCase().indexOf("
                + json.dumps(label.lower()) + ")<0)continue;"
                "T.scrollIntoView({block:'center'});"
                "var r=T.getBoundingClientRect();"
                "var x=r.x+r.width/2,y=r.y+r.height/2;"
                "var el=document.elementFromPoint(x,y);"
                "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
                "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
                "top:Math.round(r.top),bottom:Math.round(r.bottom),"
                "ih:Math.round(window.innerHeight),hit:hit});}"
                "return null;})()")
        try:
            await self._click_locator(expr, f"md-tab '{label}'")
            return True
        except ExecutorError as e:
            # D36: with Translate active the overlay can fail the hit-check
            # forever — fall back to a direct DOM click on the same tab
            # (proven working 2026-08-27 under the overlay).
            if await self._translate_active():
                self.log("md-tab",
                         f"hit-checked click on '{label}' blocked by the "
                         f"Translate overlay — DOM click fallback (D36)",
                         ok=False)
                clicked = await self._click_md_tab_dom(label)
                if clicked is not None:
                    self.log("md-tab",
                             f"DOM fallback clicked md-tab '{clicked}' (D36)")
                    return True
            self.log("md-tab", f"'{label}' not clickable: {e}", ok=False)
            return False

    async def _click_md_tab_dom(self, label: str) -> Optional[str]:
        """D36 fallback: direct DOM .click() on the md-tab. Deviation from
        the trusted-input discipline (D5) is scoped to this degraded case
        only — the CM has no anti-robot (E1 §9) and the page itself still
        issues any request (R1 intact). Translation renames tabs on the
        fly, so the match tries the label, its likely French rendering,
        or (exactly two visible tabs) the one that is NOT Availability.
        Returns the clicked tab text, or None when nothing matched."""
        expr = ("(function(){var els=document.querySelectorAll("
                "'md-tab-item');var vis=[];"
                "for(var i=0;i<els.length;i++){"
                "var t=(els[i].textContent||'').replace(/\\s+/g,' ').trim();"
                "if(els[i].offsetParent!==null&&t){vis.push([els[i],t]);}}"
                "var cands=" + json.dumps(
                    [label.lower(), "rate plan", "rate", "tarif",
                     "plan tarif"]) + ";"
                "for(var j=0;j<cands.length;j++){"
                "for(var i=0;i<vis.length;i++){"
                "if(vis[i][1].toLowerCase().indexOf(cands[j])>=0){"
                "vis[i][0].click();return vis[i][1];}}}"
                "if(vis.length===2){"
                "for(var i=0;i<2;i++){var low=vis[i][1].toLowerCase();"
                "if(low.indexOf('avail')<0&&low.indexOf('dispo')<0){"
                "vis[i][0].click();return vis[i][1];}}}"
                "return null;})()")
        return await self.js(expr)

    async def _angular_alive(self) -> bool:
        """D32-4: AngularJS handler health, read-only. After a successful
        bootstrap every compiled element exposes its scope/injector; a
        throttled half-bootstrap leaves them undefined while the form is
        already visible. Defensive try/catch: any probe failure counts as
        dead (we refuse to act on an unverified page — D12 spirit)."""
        return bool(await self.js(
            "(function(){try{if(!window.angular){return false;}"
            "var f=document.querySelector('form');if(!f){return false;}"
            "var ae=angular.element(f);"
            "return !!(ae.injector&&ae.injector())||"
            "!!(ae.scope&&ae.scope())||"
            "!!(angular.element(document.body).scope&&"
            "angular.element(document.body).scope());}"
            "catch(e){return false;}})()"))

    async def _translate_probe(self) -> str:
        """D93 : WHICH artifact betrays Google Translate — not just a bool.

        'dom'    → the page is REALLY translated (overlay toolbar or
                   translated-ltr class) : D36 threat, neutralize;
        'cookie' → only the stale googtrans cookie remains. The owner's
                   Brave is set to NOT translate (proven 05/10 on the
                   client PC: warning at EVERY connect while translation
                   was disabled) — the cookie outlives the setting and
                   triggered a false alarm on every single connection.
        ''       → clean."""
        return str(await self.js(
            "(function(){try{"
            "if(document.querySelector('.skiptranslate,#goog-gt-tt,"
            ".goog-te-balloon-frame,iframe.goog-te-menu-frame,"
            "iframe.goog-te-banner-frame')){return 'dom';}"
            "var hs=[document.documentElement,document.body];"
            "for(var i=0;i<hs.length;i++){"
            "var c=(hs[i]&&hs[i].className)||'';"
            "if(/(^|\\s)translated-(ltr|rtl)(\\s|$)/.test(c)){return 'dom';}}"
            "if(/(^|;\\s*)googtrans=/.test(document.cookie)){return 'cookie';}"
            "return '';}catch(e){return '';}})()")) or ""

    async def _delete_googtrans_cookie(self) -> None:
        """D93: remove the stale googtrans cookie via CDP (local browser
        state of the CM tab — no request, nothing OTA). Stops the false
        'Google Translate detected' alarm at every connect."""
        try:
            await self.cdp("Network.deleteCookies",
                           {"name": "googtrans", "url": self.tab_url})
        except Exception:
            pass

    async def _translate_active(self) -> bool:
        """D36 (kept for callers): True only when the page is REALLY
        translated — DOM artifacts, NOT the stale cookie."""
        return (await self._translate_probe()) == "dom"

    async def _neutralize_translate(self) -> None:
        """D36: make the Google Translate overlay click-through. Pure CSS
        injection — no request, no reload (R1/R4 untouched): elementFromPoint
        resolves page elements again and trusted CDP clicks land."""
        await self.js(
            "(function(){var id='otag-d36-no-translate';"
            "if(document.getElementById(id)){return true;}"
            "var s=document.createElement('style');s.id=id;"
            "s.textContent=" + json.dumps(
                ".skiptranslate,#goog-gt-tt,.goog-te-balloon-frame,"
                "iframe.goog-te-menu-frame,iframe.goog-te-banner-frame"
                "{pointer-events:none !important;}") + ";"
            "document.documentElement.appendChild(s);return true;})()")

    async def _ensure_form_loaded(self) -> None:
        """Make sure the RoomRatePlan form is present and usable.

        Ladder (no text-matched navigation clicks — they misfire into the
        CM side menu; and NO tab is ever closed or opened — owner's order
        2026-08-24):
        1. form already present -> done
        2. Page.navigate the EXISTING tab to the canonical
           #/bulk/roomrateplan URL
        2b. one trusted click on the 'Rate Plan' md-tab if the router
            landed on 'availability' instead
        LOGIN WALL: at every stage, a login page aborts the ladder
        immediately (CMLoginRequired) — no further navigation: the owner
        logs in ONCE in the tab that is already open.
        """
        form_css = self.loc.get("form_css", "form")
        if await self.js(f"!!document.querySelector({json.dumps(form_css)})"):
            return
        if await self._login_state():
            raise CMLoginRequired(
                "session CM expirée — connectez-vous une fois dans "
                "l'onglet BulkUpdate de Brave puis relancez (aucun onglet "
                "n'a été fermé ni ouvert)")

        # (2) direct URL navigation in the EXISTING tab
        self.log("navigate", "loading #/bulk/roomrateplan directly")
        await self.cdp("Page.navigate", {"url": self.form_url})
        await self._unthrottle()   # D93: reload must not be throttled
        for _ in range(15):
            await asyncio.sleep(1.0)
            if await self.js(f"!!document.querySelector({json.dumps(form_css)})"):
                self.log("navigate", "RoomRatePlan form loaded")
                return
            if await self._login_state():
                raise CMLoginRequired(
                    "session CM expirée — connectez-vous une fois dans "
                    "l'onglet BulkUpdate de Brave puis relancez (aucun "
                    "onglet n'a été fermé ni ouvert)")

        # (2b) the SPA ignores the hash for tab selection: click the
        # Rate Plan md-tab itself (Availability renders instead — live
        # 23/08: frmUpdateAvailability visible, FormRoomRatePlan absent)
        if await self._click_md_tab("Rate Plan"):
            for _ in range(10):
                await asyncio.sleep(1.0)
                if await self.js(f"!!document.querySelector({json.dumps(form_css)})"):
                    self.log("navigate",
                             "RoomRatePlan form loaded (md-tab clicked)")
                    return

        # (3) LAST RESORT (D31, fix 2026-08-27): the ladder above navigated
        # the EXISTING tab — if that reload happened while the Brave window
        # was hidden, Chromium throttles the page and the Angular bootstrap
        # never finishes: the form never renders and every retry re-navigates
        # a half-dead tab (proven 27/08 13:44: 12/12 preflight_failed; same
        # mechanism as E4 §10, resolved the same way). ONE OS-level raise
        # finishes the bootstrap; input keeps working in background after,
        # so later tasks find the form at step (1) and never raise again.
        self.log("navigate",
                 "form still absent — one-time OS raise to unthrottle the "
                 "page (D31 last resort)", ok=False)
        _title = str(await self.js("document.title||''") or "")
        self._raise_browser_window(_title)
        await self._unthrottle()
        for _ in range(15):
            await asyncio.sleep(2.0)
            if await self.js(f"!!document.querySelector({json.dumps(form_css)})"):
                self.log("navigate",
                         "RoomRatePlan form loaded after one-time raise")
                return
            if await self._login_state():
                raise CMLoginRequired(
                    "session CM expirée — connectez-vous une fois dans "
                    "l'onglet BulkUpdate de Brave puis relancez (aucun "
                    "onglet n'a été fermé ni ouvert)")
        if await self._click_md_tab("Rate Plan"):
            for _ in range(10):
                await asyncio.sleep(1.0)
                if await self.js(f"!!document.querySelector({json.dumps(form_css)})"):
                    self.log("navigate",
                             "RoomRatePlan form loaded (post-raise md-tab)")
                    return

        raise ExecutorError(
            "le formulaire RoomRatePlan n'a pas chargé dans l'onglet "
            "existant — rechargez la page vous-même dans Brave puis "
            "relancez (aucun onglet n'a été fermé ni ouvert)")

    async def close(self) -> None:
        if self.ws:
            await self.ws.close()
            self.ws = None

    async def cdp(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Send a CDP command and await its response. A response that never
        comes (dead websocket — seen live 2026-08-22) triggers ONE reconnect
        + retry instead of hanging the whole run forever."""
        for attempt in (1, 2):
            self._cmd_id += 1
            cmd_id = self._cmd_id
            try:
                if self.ws is None:
                    await self._reconnect()
                await self.ws.send(json.dumps(
                    {"id": cmd_id, "method": method, "params": params}))
                while True:
                    raw = await asyncio.wait_for(self.ws.recv(), timeout=20)
                    data = json.loads(raw)
                    if data.get("id") == cmd_id:
                        if "error" in data:
                            raise ExecutorError(
                                f"CDP {method}: {data['error']}")
                        return data.get("result", {})
            except asyncio.TimeoutError:
                self.log("cdp", f"no response for {method} "
                                f"(attempt {attempt}/2) — reconnecting", ok=False)
                await self._reconnect()
            except (websockets.exceptions.ConnectionClosedError,
                    websockets.exceptions.ConnectionClosedOK,
                    ConnectionResetError, OSError) as e:
                self.log("cdp", f"connection dropped ({type(e).__name__}) — "
                                f"reconnecting (attempt {attempt}/2)", ok=False)
                await self._reconnect()
        raise ExecutorError(
            f"CDP {method}: no response after reconnect (D12 stop)")

    async def _reconnect(self) -> None:
        try:
            if self.ws:
                await self.ws.close()
        except Exception:
            pass
        self.ws = None
        tab = find_tab("BulkUpdate", self.debug_port)
        if not tab or not tab.get("webSocketDebuggerUrl"):
            raise ExecutorError("BulkUpdate tab disappeared from the browser")
        self.ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                           max_size=25 * 1024 * 1024)
        self.log("cdp", "websocket reconnected")

    async def js(self, expression: str) -> Any:
        r = await self.cdp("Runtime.evaluate",
                           {"expression": expression, "returnByValue": True})
        if "exceptionDetails" in r:
            raise ExecutorError(
                f"JS exception: {r['exceptionDetails'].get('text', '?')}")
        return r.get("result", {}).get("value")

    # ── human pacing (D5) ───────────────────────────────────────────────────
    @staticmethod
    async def _sleep(lo: float = 0.8, hi: float = 1.5) -> None:
        await asyncio.sleep(random.uniform(lo, hi))

    # ── read-only location ──────────────────────────────────────────────────
    def _locate_expression(self) -> str:
        expr = _LOCATE_TEMPLATE
        expr = expr.replace("%FIELDS%", json.dumps(self.loc.get("fields", {})))
        expr = expr.replace("%COLLS%", json.dumps(self.loc.get("collections", {})))
        expr = expr.replace("%FORM_CSS%", json.dumps(self.loc.get("form_css", "form")))
        expr = expr.replace("%SUBMIT_CSS%", json.dumps(self.loc.get("submit_css", "")))
        return expr

    async def locate_all(self) -> Dict[str, Any]:
        raw = await self.js(self._locate_expression())
        return json.loads(raw) if raw else {}

    async def _box_of(self, css: str, index: Optional[int] = None) -> Optional[dict]:
        """Fresh bounding box of one element (re-read right before acting)."""
        if index is None:
            sel = f"document.querySelector({json.dumps(css)})"
        else:
            sel = f"document.querySelectorAll({json.dumps(css)})[{index}]"
        expr = (f"(function(){{var el={sel};if(!el)return null;"
                f"var r=el.getBoundingClientRect();"
                f"return JSON.stringify({{x:r.x+r.width/2,y:r.y+r.height/2,"
                f"inV:r.top>=0&&r.bottom<=window.innerHeight&&r.left>=0"
                f"&&r.right<=window.innerWidth}});}})()")
        raw = await self.js(expr)
        return json.loads(raw) if raw else None

    def _vis_sel(self, css: str, vindex: int) -> str:
        """JS expression: rect of the vindex-th VISIBLE element matching
        css (skips hidden ng-repeat templates)."""
        return ("(function(){var els=document.querySelectorAll("
                + json.dumps(css) + ");var n=0;"
                "for(var i=0;i<els.length;i++){var el=els[i];"
                "if(el.offsetParent===null)continue;"
                "if(n===" + str(vindex) + "){var r=el.getBoundingClientRect();"
                "return JSON.stringify({x:r.x+r.width/2,y:r.y+r.height/2,"
                "inV:r.top>=140&&r.bottom<=window.innerHeight-20&&"
                "r.left>=0&&r.right<=window.innerWidth});}n++;}"
                "return null;})()")

    def _vis_sel_hit(self, css: str, vindex: int) -> str:
        """JS: full hit-checked locator {x,y,top,bottom,ih,hit} for the
        vindex-th VISIBLE element matching css — for _click_locator."""
        return ("(function(){var els=document.querySelectorAll("
                + json.dumps(css) + ");var n=0;"
                "for(var i=0;i<els.length;i++){var T=els[i];"
                "if(T.offsetParent===null)continue;"
                "if(n===" + str(vindex) + "){"
                "var r=T.getBoundingClientRect();"
                "var x=r.x+r.width/2,y=r.y+r.height/2;"
                "var el=document.elementFromPoint(x,y);"
                "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
                "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
                "top:Math.round(r.top),bottom:Math.round(r.bottom),"
                "ih:Math.round(window.innerHeight),hit:hit});}n++;}"
                "return null;})()")

    async def read_checked_vis(self, css: str, vindex: int) -> Optional[bool]:
        expr = ("(function(){var els=document.querySelectorAll("
                + json.dumps(css) + ");var n=0;"
                "for(var i=0;i<els.length;i++){var el=els[i];"
                "if(el.offsetParent===null)continue;"
                "if(n===" + str(vindex) + ")return el.checked;n++;}"
                "return null;})()")
        return await self.js(expr)

    def _cb_resolver_js(self, css: str) -> str:
        """Shared JS: iterate VISIBLE checkboxes, resolve one by id /
        label (li text) / group (ul parent text) — same text derivation
        as _LOCATE_TEMPLATE, so indices are never carried across
        re-renders (live 23/08: Angular re-renders the rateplan list
        right after date selection and stale vindexes went nowhere)."""
        return ("var els=document.querySelectorAll("
                + json.dumps(css) + ");"
                "function _m(mode,value){"
                "for(var i=0;i<els.length;i++){var T=els[i];"
                "if(T.offsetParent===null)continue;"
                "if(mode==='id'){if(T.id!==value)continue;return T;}"
                "var li=T.closest('li')||T.parentElement;"
                "var grp=T.closest('ul')?T.closest('ul').parentElement:null;"
                "var label=(li?li.textContent:'')"
                ".replace(/\\s+/g,' ').trim().slice(0,60);"
                "var gtext=(grp?grp.textContent:'')"
                ".replace(/\\s+/g,' ').trim().slice(0,120);"
                "var hay=(mode==='label')?label:gtext;"
                "if(hay.toLowerCase().indexOf("
                "String(value).toLowerCase())>=0)return T;}"
                "return null;}")

    def _cb_checked_js(self, css: str, mode: str, value: str) -> str:
        return ("(function(){" + self._cb_resolver_js(css)
                + "var T=_m(" + json.dumps(mode) + ","
                + json.dumps(value) + ");"
                "return T?T.checked:null;})()")

    def _cb_hit_js(self, css: str, mode: str, value: str) -> str:
        """Resolve, scrollIntoView(center), measure, elementFromPoint —
        all in ONE evaluation so the pressed coordinates are always
        consistent with the post-scroll layout."""
        return ("(function(){" + self._cb_resolver_js(css)
                + "var T=_m(" + json.dumps(mode) + ","
                + json.dumps(value) + ");if(!T)return null;"
                "T.scrollIntoView({block:'center'});"
                "var r=T.getBoundingClientRect();"
                "var x=r.x+r.width/2,y=r.y+r.height/2;"
                "var el=document.elementFromPoint(x,y);"
                "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
                "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
                "top:Math.round(r.top),bottom:Math.round(r.bottom),"
                "ih:Math.round(window.innerHeight),hit:hit});})()")

    async def ensure_checkbox_text(self, css: str, mode: str, value: str,
                                   target: bool, what: str) -> None:
        """Set a checkbox resolved BY TEXT/ID (never by stored index).
        Every attempt re-resolves from the live DOM, so Angular
        re-renders between attempts are absorbed instead of causing
        clicks on the wrong row."""
        for _ in range(3):
            state = await self.js(self._cb_checked_js(css, mode, value))
            if state is None:
                await self._sleep(0.3, 0.6)   # mid-re-render read
                state = await self.js(self._cb_checked_js(css, mode, value))
                if state is None:
                    raise ExecutorError(f"element not found: {what}")
            if state == target:
                self.log("checkbox", f"{what}: {target} (confirmed)")
                return
            try:
                await self._click_locator(self._cb_hit_js(css, mode, value),
                                          what)
            except ExecutorError:
                await self._sleep(0.3, 0.6)
                continue
        state = await self.js(self._cb_checked_js(css, mode, value))
        if state != target:
            raise ExecutorError(
                f"checkbox {what} refused to become {target} (still {state})")

    async def ensure_checkbox_vis(self, css: str, vindex: int, target: bool,
                                  what: str) -> None:
        """Set the vindex-th VISIBLE checkbox to target. Retried with
        hit-checked fresh clicks: Angular re-renders these lists right
        after date selection and a once-measured rect can go stale
        (live 23/08: rateplan checkbox click landed, state unchanged)."""
        for _ in range(3):
            state = await self.read_checked_vis(css, vindex)
            if state == target:
                self.log("checkbox", f"{what}: already {target}")
                return
            await self._scroll_expr_until_visible(
                self._vis_sel(css, vindex), what)
            try:
                await self._click_locator(self._vis_sel_hit(css, vindex),
                                          what)
            except ExecutorError:
                # node probably re-rendered mid-flight: re-resolve & retry
                await self._sleep(0.3, 0.6)
                continue
        state = await self.read_checked_vis(css, vindex)
        if state != target:
            raise ExecutorError(
                f"checkbox {what} refused to become {target} (still {state})")
        self.log("checkbox", f"{what}: now {target}")

    async def _scroll_until_visible(self, css: str, index: Optional[int] = None,
                                    max_steps: int = 30) -> dict:
        """Slow wheel scrolling (allowed for ACTION, plan §4.3) until the
        element is in the viewport — scrolls UP or DOWN as needed."""
        if index is None:
            sel = f"document.querySelector({json.dumps(css)})"
        else:
            sel = f"document.querySelectorAll({json.dumps(css)})[{index}]"
        expr = (f"(function(){{var el={sel};if(!el)return null;"
                f"var r=el.getBoundingClientRect();"
                f"return JSON.stringify({{x:r.x+r.width/2,y:r.y+r.height/2,"
                f"inV:r.top>=140&&r.bottom<=window.innerHeight-20&&r.left>=0"
                f"&&r.right<=window.innerWidth}});}})()")
        return await self._scroll_expr_until_visible(expr, f"{css}[{index}]",
                                                     max_steps)

    async def _scroll_expr_until_visible(self, box_expr: str, what: str,
                                         max_steps: int = 30) -> dict:
        """Generic: evaluate a JS expr returning {x, y, inV} and wheel-scroll
        (both directions) until inV is true. inV already includes a TOP
        margin so the element clears any fixed navbar (otherwise the click
        lands on the overlay — seen live on 2026-08-26). D12 stop after
        max_steps."""
        for _ in range(max_steps):
            raw = await self.js(box_expr)
            box = json.loads(raw) if raw else None
            if box is None:
                raise ExecutorError(f"element not found: {what}")
            if box.get("inV"):
                return box
            # element too high (hidden under fixed header) -> scroll page UP
            # (content moves down); too low -> scroll page DOWN.
            # window.scrollBy via JS: CDP mouseWheel events NEVER respond
            # when the browser window lacks OS focus (known Chromium
            # behavior, seen live 2026-08-22 evening — every other input
            # event responds). This is our trusted extranet form (no
            # anti-bot, study §9) and scrolling emits no request (R1).
            dy = -300 if box.get("y", 0) < 170 else 300
            await self.js(f"window.scrollBy(0, {dy})")
            await self._sleep(0.4, 0.9)
        raise ExecutorError(f"element never reached viewport: {what}")

    # ── trusted input events ────────────────────────────────────────────────
    async def mouse_click(self, css: str, index: Optional[int] = None,
                          what: str = "") -> None:
        box = await self._scroll_until_visible(css, index)
        x, y = int(box["x"]), int(box["y"])
        await self.cdp("Input.dispatchMouseEvent",
                       {"type": "mouseMoved", "x": x, "y": y})
        await self._sleep(0.3, 0.8)
        await self.cdp("Input.dispatchMouseEvent", {
            "type": "mousePressed", "x": x, "y": y,
            "button": "left", "clickCount": 1})
        await self._sleep(0.06, 0.16)
        await self.cdp("Input.dispatchMouseEvent", {
            "type": "mouseReleased", "x": x, "y": y,
            "button": "left", "clickCount": 1})
        await self._sleep()
        self.log("click", f"{what or css} at ({x},{y})")

    async def key_event(self, type_: str, key: str, code: str = "",
                        vk: int = 0, modifiers: int = 0,
                        text: Optional[str] = None) -> None:
        params: Dict[str, Any] = {
            "type": type_, "key": key, "code": code or key,
            "windowsVirtualKeyCode": vk, "nativeVirtualKeyCode": vk,
            "modifiers": modifiers}
        if text is not None:
            params["text"] = text
        await self.cdp("Input.dispatchKeyEvent", params)

    async def type_text(self, text: str) -> None:
        for ch in text:
            vk = ord(ch.upper()) if ch.isalnum() else 0
            await self.key_event("keyDown", key=ch, vk=vk, text=ch)
            await self._sleep(0.08, 0.28)
            await self.key_event("keyUp", key=ch, vk=vk)
            await self._sleep(0.08, 0.28)
        self.log("type", f"'{text}' ({len(text)} chars)")

    async def press_key(self, key: str, vk: int, modifiers: int = 0) -> None:
        await self.key_event("keyDown", key=key, vk=vk, modifiers=modifiers)
        await self._sleep(0.05, 0.15)
        await self.key_event("keyUp", key=key, vk=vk, modifiers=modifiers)
        await self._sleep(0.3, 0.7)
        self.log("key", key)

    # ── higher-level widgets ────────────────────────────────────────────────
    async def read_field(self, css: str) -> Optional[str]:
        return await self.js(
            f"(document.querySelector({json.dumps(css)})||{{}}).value ?? null")

    async def read_checked(self, css: str, index: Optional[int] = None) -> Optional[bool]:
        if index is None:
            sel = f"document.querySelector({json.dumps(css)})"
        else:
            sel = f"document.querySelectorAll({json.dumps(css)})[{index}]"
        raw = await self.js(f"{sel} ? {sel}.checked : null")
        return raw

    async def _clear_field(self, css: str, what: str = "") -> None:
        """Fully empty the field and PROVE it before typing.

        Root cause fixed (2026-08-26 evening): the old single ctrl+A
        sometimes failed to select (Angular re-render between the click
        and the keystroke) — typing then landed ON TOP of the leftover
        text and the read-back came back doubled ('2888' -> '22,888,888').
        Now: click, ctrl+A, Delete, then verify the field reads empty;
        retry a few times; refuse to type on a non-empty field (D12)."""
        current = None
        for attempt in range(3):
            await self.mouse_click(css, what=what or css)
            await self._sleep()
            await self.key_event("keyDown", key="a", code="KeyA", vk=65,
                                 modifiers=2)
            await self.key_event("keyUp", key="a", code="KeyA", vk=65,
                                 modifiers=2)
            await self._sleep(0.08, 0.2)
            await self.press_key("Delete", vk=46)
            current = await self.read_field(css)
            if not (current or "").strip():
                return
            self.log("clear", f"{what or css}: still '{current}' "
                              f"(attempt {attempt + 1}/3)", ok=False)
        raise ExecutorError(
            f"{what or css}: field refused to be emptied "
            f"(still '{current}') — aborting (D12)")

    async def _read_field_stable(self, css: str, what: str = "",
                                 max_wait: float = 3.5) -> Optional[str]:
        """Read the field only once its value STOPPED changing.

        The CM reformats prices ('2735' -> '2,735') on a short Angular
        delay after Tab — reading immediately returned half-written
        values on 2026-08-26. Two consecutive identical reads = stable."""
        stable: Optional[str] = None
        loop = asyncio.get_event_loop()
        deadline = loop.time() + max_wait
        while True:
            current = await self.read_field(css)
            if current is not None and current == stable:
                return current
            stable = current
            if loop.time() >= deadline:
                return stable
            await self._sleep(0.25, 0.5)

    async def set_input(self, css: str, value: str,
                        what: str = "") -> Optional[str]:
        """Click, PROVE the field empty, type char by char, Tab out,
        then read back only once the value has stabilized. Returns the
        stable read-back (site formatting included) so the caller can
        verify; raises on a field that cannot be emptied (D12)."""
        await self._clear_field(css, what=what)
        await self.type_text(value)
        await self.press_key("Tab", vk=9)
        current = await self._read_field_stable(css, what=what)
        self.log("set_input", f"{what or css} -> '{value}' (read-back '{current}')",
                 ok=current is not None)
        return current

    async def ensure_checkbox(self, css: str, index: Optional[int],
                              target: bool, what: str) -> None:
        """Set a checkbox to the target state; verify by re-reading the DOM.
        Refuses to continue if the state did not stick (D12)."""
        state = await self.read_checked(css, index)
        if state == target:
            self.log("checkbox", f"{what}: already {target}")
            return
        await self.mouse_click(css, index=index, what=what)
        state = await self.read_checked(css, index)
        if state != target:
            raise ExecutorError(
                f"checkbox {what} refused to become {target} (still {state})")
        self.log("checkbox", f"{what}: now {target}")

    # ── date helpers ────────────────────────────────────────────────────────
    _MONTHS = {"january": 1, "february": 2, "march": 3, "april": 4, "may": 5,
               "june": 6, "july": 7, "august": 8, "september": 9,
               "october": 10, "november": 11, "december": 12,
               "janvier": 1, "fevrier": 2, "février": 2, "mars": 3, "avril": 4,
               "mai": 5, "juin": 6, "juillet": 7, "aout": 8, "août": 8,
               "septembre": 9, "octobre": 10, "novembre": 11, "decembre": 12,
               "décembre": 12}

    @classmethod
    def _parse_switch(cls, text: str) -> Optional[Tuple[int, int]]:
        """'August 2026' / 'août 2026' -> (2026, 8)."""
        m = re.match(r"^\s*([^\d]+?)\s+(\d{4})\s*$", text or "")
        if not m:
            return None
        month = cls._MONTHS.get(m.group(1).strip().lower())
        return (int(m.group(2)), month) if month else None

    @staticmethod
    def _format_date_like(value: str, iso: str) -> str:
        """Render ISO date (YYYY-MM-DD) using the SAME format as the value
        currently shown in the form field (dd/mm/yyyy or mm/dd/yyyy)."""
        y, m, d = iso.split("-")
        mm = f"{int(m):02d}"
        dd = f"{int(d):02d}"
        match = re.match(r"^(\d{1,2})([/\-.])(\d{1,2})\2(\d{4})$", value or "")
        if match:
            a, sep, b = match.group(1), match.group(2), match.group(3)
            day_first = int(a) > 12 or int(b) <= 12  # heuristic on existing value
            return f"{dd}{sep}{mm}{sep}{y}" if day_first else f"{mm}{sep}{dd}{sep}{y}"
        return f"{dd}/{mm}/{y}"  # site default (AU locale)

    async def _click_xy(self, x: float, y: float, what: str) -> None:
        x, y = int(x), int(y)
        await self.cdp("Input.dispatchMouseEvent",
                       {"type": "mouseMoved", "x": x, "y": y})
        await self._sleep(0.3, 0.7)
        await self.cdp("Input.dispatchMouseEvent", {
            "type": "mousePressed", "x": x, "y": y,
            "button": "left", "clickCount": 1})
        await self._sleep(0.06, 0.15)
        await self.cdp("Input.dispatchMouseEvent", {
            "type": "mouseReleased", "x": x, "y": y,
            "button": "left", "clickCount": 1})
        await self._sleep()
        self.log("click", f"{what} at ({x},{y})")

    async def _click_locator(self, js_expr: str, what: str,
                             tries: int = 3) -> None:
        """Click an element located by a JS snippet that MUST return
        JSON {x, y, top, bottom, ih, hit} — hit is an elementFromPoint
        self-check computed in the SAME evaluation. The pressed
        coordinates are therefore always fresh, and a page that drifts
        between measure and press becomes a RETRY instead of a silent
        click on the wrong element (live 23/08: a stale day-cell rect
        set TDate to 02/10 instead of 28/08 — caught by the D12
        read-back, nothing submitted)."""
        last = None
        for _ in range(tries):
            raw = await self.js(js_expr)
            if raw == "HIDDEN":
                raise ExecutorError(f"{what}: hidden at the picker's "
                                    f"range bound — nothing sent")
            if raw == "DISABLED":
                raise ExecutorError(f"{what}: disabled by the site (past "
                                    f"date or out of range) — nothing sent")
            last = json.loads(raw) if raw else None
            if (last and last.get("hit")
                    and last.get("top", 0) >= 140
                    and last.get("bottom", 0) <= last.get("ih", 0) - 20):
                x, y = int(last["x"]), int(last["y"])
                await self.cdp("Input.dispatchMouseEvent",
                               {"type": "mouseMoved", "x": x, "y": y})
                await self._sleep(0.12, 0.3)
                await self.cdp("Input.dispatchMouseEvent", {
                    "type": "mousePressed", "x": x, "y": y,
                    "button": "left", "clickCount": 1})
                await self._sleep(0.05, 0.12)
                await self.cdp("Input.dispatchMouseEvent", {
                    "type": "mouseReleased", "x": x, "y": y,
                    "button": "left", "clickCount": 1})
                self.log("click", f"{what} at ({x},{y}) [hit-checked]")
                await self._sleep()
                return
            await self._sleep(0.4, 0.8)
        raise ExecutorError(
            f"{what}: crosshair never landed on target after {tries} tries "
            f"(page drifting?) — last={last}")

    async def _visible_picker_prop(self, prop_expr: str) -> Optional[dict]:
        """Evaluate a JS snippet in the context of the VISIBLE datepicker.
        The snippet must use the variable 'p' (the picker element)."""
        expr = ("(function(){var picks=document.querySelectorAll('.datepicker');"
                "for(var i=0;i<picks.length;i++){var p=picks[i];"
                "var st=getComputedStyle(p);"
                "if(st.display==='none'||st.visibility==='hidden')continue;"
                "var r=p.getBoundingClientRect();if(r.width<100)continue;"
                + prop_expr + "}"
                "return null;})()")
        raw = await self.js(expr)
        return json.loads(raw) if raw else None

    _MONTHS_SHORT = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5,
                     "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10,
                     "nov": 11, "dec": 12}

    async def _pick_date(self, css: str, iso: str, what: str) -> None:
        """Set a readOnly date field the human way. STATELESS navigation
        (probe 23/08): the CM picker closes itself ~1.5 s after opening
        and its orientation (top/bottom) is adaptive, so nothing may be
        assumed to persist between two CDP roundtrips. Each loop
        iteration re-derives everything: ensure the picker is open,
        clear the navbar if clipped, read the header, then click either
        the day cell (right month) or one prev/next month chevron of the
        days view. Field-value read-back is the only truth (D12).
        Trusted CDP input only; scrolls are layout-only."""
        y, m, d = (int(x) for x in iso.split("-"))
        current = await self.read_field(css) or ""
        expected = self._format_date_like(current, iso)
        if current == expected:
            self.log("set_date", f"{what}: already '{expected}' — skip")
            return

        # placement: dead-center leaves headroom above AND below (the
        # picker may open either side); residual clipping is fixed after
        # the open by scrolling, never assumed.
        place_js = (
            "(function(){var T=document.querySelector("
            + json.dumps(css) + ");if(!T)return null;"
            "T.scrollIntoView({block:'center'});"
            "var r=T.getBoundingClientRect();"
            "return JSON.stringify({top:Math.round(r.top),"
            "bottom:Math.round(r.bottom),"
            "ih:Math.round(window.innerHeight)});})()")
        place = json.loads(await self.js(place_js) or "null")
        if not place or place["top"] < 150:
            raise ExecutorError(
                f"{what}: field not placeable "
                f"(top={place and place['top']})")
        await self._sleep(0.3, 0.6)

        inp_expr = (
            "(function(){var T=document.querySelector("
            + json.dumps(css) + ");if(!T)return null;"
            "var r=T.getBoundingClientRect();"
            "var x=r.x+r.width/2,y=r.y+r.height/2;"
            "var el=document.elementFromPoint(x,y);"
            "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
            "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
            "top:Math.round(r.top),bottom:Math.round(r.bottom),"
            "ih:Math.round(window.innerHeight),hit:hit});})()")
        icon_expr = (
            "(function(){var T=document.querySelector("
            + json.dumps(css) + ");if(!T)return null;"
            "var btn=T.parentElement.querySelector('.input-group-btn');"
            "if(!btn)return null;var r=btn.getBoundingClientRect();"
            "var x=r.x+r.width/2,y=r.y+r.height/2;"
            "var el=document.elementFromPoint(x,y);"
            "var hit=!!el&&(el===btn||btn.contains(el)||el.contains(btn));"
            "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
            "top:Math.round(r.top),bottom:Math.round(r.bottom),"
            "ih:Math.round(window.innerHeight),hit:hit});})()")
        # every picker locator is ANCHORED to this field's input by
        # horizontal position: the page keeps one .datepicker per date
        # input and several can be visible at once — unanchored loops
        # took the first in DOM order, i.e. sometimes FDate's picker
        # while driving TDate (live 23/08).
        anchor = ("var IN=document.querySelector("
                  + json.dumps(css) + ");"
                  "var IX=IN?IN.getBoundingClientRect().x:-9999;")
        picker_js = ("(function(){" + anchor
                     + "var picks=document.querySelectorAll('.datepicker');"
                     "for(var i=0;i<picks.length;i++){var p=picks[i];"
                     "var st=getComputedStyle(p);"
                     "if(st.display==='none'||st.visibility==='hidden')continue;"
                     "var r0=p.getBoundingClientRect();if(r0.width<100)continue;"
                     "if(Math.abs(r0.left-IX)>200)continue;"
                     "var DAYS=p.querySelector('.datepicker-days');"
                     "if(!DAYS||DAYS.offsetWidth===0)continue;"
                     "return JSON.stringify({top:Math.round(r0.top),"
                     "bottom:Math.round(r0.bottom),"
                     "ih:Math.round(window.innerHeight)});}"
                     "return null;})()")
        header_js = ("(function(){" + anchor
                     + "var picks=document.querySelectorAll('.datepicker');"
                     "for(var i=0;i<picks.length;i++){var p=picks[i];"
                     "var st=getComputedStyle(p);if(st.display==='none')continue;"
                     "if(Math.abs(p.getBoundingClientRect().left-IX)>200)continue;"
                     "var DAYS=p.querySelector('.datepicker-days');"
                     "if(!DAYS||DAYS.offsetWidth===0)continue;"
                     "var sw=p.querySelector('.datepicker-days .datepicker-switch');"
                     "return sw?sw.textContent.trim():null;}"
                     "return null;})()")
        day_expr = (
            "(function(){" + anchor
            + "var picks=document.querySelectorAll('.datepicker');"
            "for(var i=0;i<picks.length;i++){var p=picks[i];"
            "var st=getComputedStyle(p);if(st.display==='none')continue;"
            "if(Math.abs(p.getBoundingClientRect().left-IX)>200)continue;"
            "var DAYS=p.querySelector('.datepicker-days');"
            "if(!DAYS||DAYS.offsetWidth===0)continue;"
            "var tds=DAYS.querySelectorAll('tbody td.day');"
            "for(var j=0;j<tds.length;j++){var T=tds[j];"
            "if(T.classList.contains('old')||T.classList.contains('new'))continue;"
            "if(T.textContent.trim()==='" + str(d) + "'){"
            "if(T.classList.contains('disabled'))return 'DISABLED';"
            "var r=T.getBoundingClientRect();"
            "var x=r.x+r.width/2,y=r.y+r.height/2;"
            "var el=document.elementFromPoint(x,y);"
            "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
            "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
            "top:Math.round(r.top),bottom:Math.round(r.bottom),"
            "ih:Math.round(window.innerHeight),hit:hit});}}"
            "return null;}"
            "return null;})()")

        await self.key_event("keyDown", key="Escape", vk=27)
        await self.key_event("keyUp", key="Escape", vk=27)

        for attempt in range(6):
            # 0. re-center the field: page sections jump when inputs gain
            #    focus (Angular autoscroll — live 23/08: the input went
            #    from y=235 to y=-96 between two attempts)
            await self.js(place_js)
            await self._sleep(0.2, 0.4)

            # 1. ensure the picker is open — dying pickers are expected,
            #    re-opening is always safe (input click shows, not toggles)
            pk_raw = await self.js(picker_js)
            if not pk_raw:
                await self._click_locator(inp_expr, f"{what} input (open)")
                pk_raw = await self.js(picker_js)
                if not pk_raw:
                    await self._click_locator(icon_expr,
                                              f"{what} calendar icon")
                    await self._sleep(0.5, 0.8)
                    pk_raw = await self.js(picker_js)
                if not pk_raw:
                    continue   # picker died instantly — retry the loop
            pk = json.loads(pk_raw)

            # 2. clear the navbar / viewport bottom if clipped (the picker
            #    is document-positioned: scrolling shifts its viewport rect)
            if pk["top"] < 150 or pk["bottom"] > pk["ih"] - 20:
                dy = (pk["top"] - 170 if pk["top"] < 150
                      else pk["bottom"] - (pk["ih"] - 40))
                await self.js(f"window.scrollBy(0, {dy})")
                await self._sleep(0.4, 0.7)
                raw2 = await self.js(picker_js)
                pk2 = json.loads(raw2) if raw2 else None
                if (pk2 is None or pk2["top"] < 150
                        or pk2["bottom"] > pk2["ih"] - 20):
                    raise ExecutorError(
                        f"{what}: picker clipped "
                        f"(top={pk2 and pk2['top']}) and scrolling "
                        f"did not fix it")
                pk = pk2

            # 3. fresh header -> day cell or month chevron
            hdr = await self.js(header_js)
            shown = self._parse_switch(hdr or "")
            if shown is None:
                await self._sleep(0.4, 0.8)   # transient mid-swap read
                continue
            self.log("datepicker",
                     f"{what} shows '{hdr}' (attempt {attempt})")

            if shown == (y, m):
                try:
                    await self._click_locator(day_expr, f"{what} day {d} cell")
                except ExecutorError as e:
                    if "disabled by the site" in str(e):
                        raise ExecutorError(
                            f"{what}: day {d} is disabled by the site "
                            f"(past date or out of allowed range) — "
                            f"nothing sent") from e
                    self.log("datepicker", f"{what}: day click missed "
                                           f"({e}) — retrying", ok=False)
                    continue
                back = await self.read_field(css) or ""
                if back == expected:
                    self.log("set_date", f"{what} -> {expected}")
                    return
                self.log("datepicker", f"{what}: read-back '{back}' after "
                                       f"day click — retrying", ok=False)
                continue

            nav = "next" if shown < (y, m) else "prev"
            arrow_days = (
                "(function(){" + anchor
                + "var picks=document.querySelectorAll('.datepicker');"
                "for(var i=0;i<picks.length;i++){var p=picks[i];"
                "var st=getComputedStyle(p);if(st.display==='none')continue;"
                "if(Math.abs(p.getBoundingClientRect().left-IX)>200)continue;"
                "var DAYS=p.querySelector('.datepicker-days');"
                "if(!DAYS||DAYS.offsetWidth===0)continue;"
                "var T=DAYS.querySelector('thead .%s');if(!T)return null;"
                "if(getComputedStyle(T).visibility==='hidden')return 'HIDDEN';"
                "var r=T.getBoundingClientRect();"
                "var x=r.x+r.width/2,y=r.y+r.height/2;"
                "var el=document.elementFromPoint(x,y);"
                "var hit=!!el&&(el===T||T.contains(el)||el.contains(T));"
                "return JSON.stringify({x:Math.round(x),y:Math.round(y),"
                "top:Math.round(r.top),bottom:Math.round(r.bottom),"
                "ih:Math.round(window.innerHeight),hit:hit});}"
                "return null;})()" % nav)
            try:
                await self._click_locator(arrow_days, f"{what} month {nav}")
            except ExecutorError as e:
                if "range bound" in str(e):
                    raise ExecutorError(
                        f"{what}: month chevron '{nav}' hidden — target "
                        f"{y}-{m:02d} outside the picker's allowed range"
                    ) from e
                self.log("datepicker", f"{what}: arrow click missed "
                                       f"({e}) — retrying", ok=False)

        raise ExecutorError(
            f"{what}: could not reach {iso} in 6 attempts (picker kept "
            f"closing or month unreachable) — nothing submitted")
    # ── main workflow ───────────────────────────────────────────────────────
    async def execute_price_change(self, room_label: str, ota_label: str,
                                   rate: str, date_from: str, date_to: str,
                                   days: Optional[List[str]] = None) -> bool:
        """Fill the real form for ONE room/plan + ONE OTA + ONE date range
        (D8). Returns True when the full sequence completed (test mode:
        submit skipped — zero modification)."""
        fields = self.loc.get("fields", {})
        colls = self.loc.get("collections", {})

        self.log("start",
                 f"mode={'TEST (no submit)' if self.test_mode else 'REAL'} "
                 f"room={room_label!r} ota={ota_label!r} rate={rate} "
                 f"dates={date_from}..{date_to}")

        loc = await self.locate_all()
        # pre-flight: form + submit must exist
        if not loc.get("form", {}).get("found"):
            raise ExecutorError("form FormRoomRatePlan not found on the page")
        if not loc.get("submit", {}).get("found"):
            raise ExecutorError("submit button not found on the page")

        # resolve collections
        ota_items = loc["collections"]["ota"]["items"]
        rp_items = loc["collections"]["rateplan"]["items"]
        day_items = loc["collections"]["days"]["items"]
        ota_index = next((i["vindex"] for i in ota_items
                          if ota_label.lower() in i["label"].lower()), None)
        if ota_index is None:
            raise ExecutorError(f"OTA {ota_label!r} not found among "
                                f"{len(ota_items)} visible checkboxes")
        ota_items = [i for i in ota_items if i.get("vindex") is not None]
        rp_items = [i for i in rp_items if i.get("vindex") is not None]
        day_items = [i for i in day_items if i.get("vindex") is not None]
        self.log("resolve",
                 f"ota[{ota_index}]={ota_label!r} (vindex), "
                 f"room={room_label!r} (par nom), "
                 f"{len(day_items)} day checkboxes")

        # 1. dates — the inputs are readOnly (watchDatepicker directive):
        #    set them the way a human does, via the calendar popup
        for css, iso, what in ((fields["FDate"], date_from, "FDate"),
                               (fields["TDate"], date_to, "TDate")):
            await self._pick_date(css, iso, what=what)

        # Angular re-renders the checkbox lists after date selection —
        # RE-LOCATE everything and never trust a pre-date index again
        loc = await self.locate_all()
        ota_items = loc["collections"]["ota"]["items"]
        rp_items = loc["collections"]["rateplan"]["items"]
        day_items = loc["collections"]["days"]["items"]
        ota_items = [i for i in ota_items if i.get("vindex") is not None]
        rp_items = [i for i in rp_items if i.get("vindex") is not None]
        day_items = [i for i in day_items if i.get("vindex") is not None]

        def _key(item: dict) -> tuple:
            """Stable identity for one checkbox: id if present, else
            its li text (unique per list on this form)."""
            return ("id", item["id"]) if item.get("id") \
                else ("label", item["label"])

        # 2. days of the week — default: check ALL (any date in range matches)
        want_days = {d.lower() for d in days} if days else None
        for item in day_items:
            label = item["label"].lower()
            target = True if want_days is None else any(
                w in label for w in want_days)
            mode, val = _key(item)
            await self.ensure_checkbox_text(
                colls["days"], mode, val, target,
                f"day '{item['label'][:12]}'")

        # 3. room/plan — exactly ONE checked (ours), every other unchecked
        #    (resolution by ROOM NAME, shortest group wins so "Double
        #    Room" never matches "Double Room with Balcony")
        rp_candidates = [i for i in rp_items
                         if room_label.lower() in i["group"].lower()
                         or room_label.lower() in i["label"].lower()]
        if not rp_candidates:
            raise ExecutorError(f"room/plan {room_label!r} not found among "
                                f"{len(rp_items)} visible checkboxes")
        chosen = min(rp_candidates, key=lambda i: len(i["group"]))
        for item in rp_items:
            target = (item["label"] == chosen["label"]
                      and item["group"] == chosen["group"])
            mode, val = _key(item)
            await self.ensure_checkbox_text(
                colls["rateplan"], mode, val, target,
                f"rateplan '{item['group'][:24]}'")

        # 4. OTA — exactly ONE checked (ours), every other unchecked
        for item in ota_items:
            target = ota_label.lower() in item["label"].lower()
            mode, val = _key(item)
            await self.ensure_checkbox_text(
                colls["ota"], mode, val, target,
                f"ota '{item['label'][:20]}'")

        # 5. activate the price field, then type the price — with a clean
        #    retry: on a garbled read-back, fully clear and retype instead
        #    of failing the whole task (fix 2026-08-27); after the last
        #    attempt the run still aborts (D12 — nothing is ever submitted
        #    on an unverified field).
        await self.ensure_checkbox(fields["isRate"], None, True, "isRate")
        back = ""
        for attempt in range(3):
            back = (await self.set_input(fields["Rate"], str(rate),
                                         what="Rate")) or ""
            if back.replace(",", "").strip() == str(rate):
                break
            self.log("rate-retry",
                     f"read-back '{back}' != '{rate}' — full clear + retype "
                     f"(attempt {attempt + 1}/3)", ok=False)
        else:
            raise ExecutorError(
                f"Rate read-back '{back}' != '{rate}' — aborting (D12)")

        # 6. final state snapshot
        final = await self.locate_all()
        self.log("state",
                 f"checked rateplans="
                 f"{[i['index'] for i in final['collections']['rateplan']['items'] if i['checked']]}, "
                 f"otas={[i['label'][:12] for i in final['collections']['ota']['items'] if i['checked']]}, "
                 f"rate='{final['fields']['Rate']['value']}'")

        # 7. submit — ONLY in real mode, ONLY after all verifications passed
        if self.test_mode:
            self.log("submit", "SKIPPED — TEST MODE (zero real modification)")
            return True
        await self.mouse_click(self.loc["submit_css"],
                               what=f"submit '{loc['submit'].get('text')}'")
        await asyncio.sleep(3)
        self.log("submit", "clicked — verification via scanner comes next")
        return True


# ── CLI ─────────────────────────────────────────────────────────────────────

async def _locate_only(map_path: Path, debug_port: int, tab: str) -> int:
    exe = Executor(map_path=map_path, test_mode=True, debug_port=debug_port)
    await exe.connect(tab)
    try:
        loc = await exe.locate_all()
        print(json.dumps(loc, indent=2, ensure_ascii=False))
        ok = (loc.get("form", {}).get("found")
              and loc.get("submit", {}).get("found"))
        print(f"\nform found  : {loc.get('form', {}).get('found')}")
        print(f"submit found: {loc.get('submit', {}).get('found')} "
              f"({loc.get('submit', {}).get('text')})")
        for name, st in loc.get("fields", {}).items():
            print(f"field {name:6}: found={st['found']} value={st['value']!r}")
        for name, c in loc.get("collections", {}).items():
            print(f"collection {name:9}: {c['count']} items")
            for it in c["items"]:
                print(f"   [{it['index']}] checked={it['checked']!s:5} "
                      f"label={it['label'][:40]!r}")
        return 0 if ok else 2
    finally:
        await exe.close()


def main(argv: List[str] = None) -> int:
    warnings.simplefilter("ignore")
    ap = argparse.ArgumentParser(description="VAE 2 executor (trusted CDP input)")
    ap.add_argument("--map", type=Path, default=DEFAULT_MAPS_DIR / "channelmanager_com_au.yaml")
    ap.add_argument("--debug-port", type=int, default=9222)
    ap.add_argument("--tab", default="BulkUpdate",
                    help="substring of the target tab URL")
    ap.add_argument("--locate-only", action="store_true",
                    help="READ-ONLY: locate every element and exit (no click)")
    ap.add_argument("--room-label")
    ap.add_argument("--ota-label")
    ap.add_argument("--rate")
    ap.add_argument("--date-from", help="ISO YYYY-MM-DD")
    ap.add_argument("--date-to", help="ISO YYYY-MM-DD")
    ap.add_argument("--real", action="store_true",
                    help="REAL mode: will click submit (owner-confirmed only)")
    ap.add_argument("--journal-out", type=Path, default=None)
    args = ap.parse_args(argv)

    if args.locate_only:
        return asyncio.run(_locate_only(args.map, args.debug_port, args.tab))

    for req in ("room_label", "ota_label", "rate", "date_from", "date_to"):
        if not getattr(args, req):
            ap.error(f"--{req.replace('_', '-')} is required")

    async def _run() -> Tuple[bool, List[ActionLog]]:
        exe = Executor(map_path=args.map, test_mode=not args.real,
                       debug_port=args.debug_port)
        await exe.connect(args.tab)
        try:
            ok = await exe.execute_price_change(
                args.room_label, args.ota_label, args.rate,
                args.date_from, args.date_to)
            return ok, exe.journal
        finally:
            await exe.close()

    ok, journal = asyncio.run(_run())
    if args.journal_out:
        args.journal_out.parent.mkdir(parents=True, exist_ok=True)
        args.journal_out.write_text(
            json.dumps([asdict(e) for e in journal], indent=2, ensure_ascii=False),
            encoding="utf-8")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
