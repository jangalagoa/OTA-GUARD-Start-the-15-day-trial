"""Livrable vendeur (D91) — zip nettoyé + comparaison de deux rapports.

make_bundle() : empaquette rapport.txt/.json + config masquée + extraits
de journaux masqués + fin de boîte noire. Tout passe par masker — le zip
est destiné à quitter la machine, RIEN de sensible ne doit y entrer.

compare_reports() : diff orienté diagnostic entre le rapport JSON du PC
python et celui du PC installé (la demande d'origine du propriétaire).
"""
import datetime
import json
import zipfile

from core.paths import DATA_DIR

from diagnostic import masker
from diagnostic.report import REPORTS_DIR

_BUNDLE_MAX_LINES = 400


def _tail_file(fp, n=_BUNDLE_MAX_LINES):
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception:
        return ""
    return "".join(masker.mask_text(l) for l in lines[-n:])


def _full_file_masked(fp) -> str:
    """D99 : le journal ENTIÈRE, masqué ligne à ligne — le zip quitte la
    machine, donc chaque ligne passe par le masque (mêmes motifs que la
    boîte noire et les queues). Un journal de 15 Mo prend quelques
    secondes : c'est une action manuelle explicite (bouton 📦)."""
    out = []
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            for line in f:
                out.append(masker.mask_text(line.rstrip("\n")))
    except Exception:
        return ""
    return "\n".join(out) + ("\n" if out else "")


def make_bundle(txt_path, json_path, facts: dict):
    """Crée le zip ; retourne son chemin (dans data/diagnostics/)."""
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = REPORTS_DIR / f"otaguard_bundle_{ts}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        if txt_path and txt_path.exists():
            z.write(txt_path, txt_path.name)
        if json_path and json_path.exists():
            z.write(json_path, json_path.name)

        # Config complète masquée (le diff précis entre deux machines)
        full = ((facts.get("configuration") or {}).get("_sanitized_full"))
        if full is not None:
            z.writestr("config_sanitized.json",
                       json.dumps(masker.mask_dict(full),
                                  ensure_ascii=False, indent=1))

        # Extraits de journaux masqués (lecture rapide)
        for name in ("app.log", "ota_guard.log"):
            tail = _tail_file(DATA_DIR / name)
            if tail:
                z.writestr(f"tail_{name}.txt", tail)

        # D99 : journaux COMPLETS masqués — l'analyse externe (autre IA,
        # vendeur) doit pouvoir juger l'historique entier, pas seulement
        # les queues. app.log + .bak, ota_guard.log + .bak, activity_log.
        for name in ("app.log", "app.log.bak", "ota_guard.log",
                     "ota_guard.log.bak", "activity_log.txt"):
            fp = DATA_DIR / name
            if fp.exists():
                full = _full_file_masked(fp)
                if full:
                    # activity_log.txt se termine déjà par .txt — pas de
                    # double extension
                    arc = f"full_{name}" if name.endswith(".txt") \
                        else f"full_{name}.txt"
                    z.writestr(arc, full)

        # Boîte noire : journées complètes — déjà masquées À L'ÉCRITURE
        # (recorder.event applique mask_dict avant chaque ligne), elles
        # partent telles quelles.
        try:
            bb = DATA_DIR / "blackbox"
            for f in sorted(bb.glob("blackbox_*.jsonl")):
                z.writestr(f"blackbox/{f.name}",
                           f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass

        # Fin de boîte noire (aperçu, comme avant)
        try:
            from diagnostic import recorder
            evts = recorder.recent_events(200)
            if evts:
                z.writestr("blackbox_tail.jsonl",
                           "\n".join(json.dumps(masker.mask_dict(e),
                                                ensure_ascii=False)
                                     for e in evts))
        except Exception:
            pass
    return zip_path


def compare_reports(path_a, path_b) -> list:
    """Diff lisible entre deux rapports .json. Retourne des lignes."""
    def load(p):
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d

    try:
        A, B = load(path_a), load(path_b)
    except Exception as e:
        return [f"❌ Lecture impossible : {e}"]

    L = ["⚖ COMPARAISON DE DEUX RAPPORTS",
         f"  A : {path_a.name}",
         f"  B : {path_b.name}", ""]

    def fa(d):  # facts_lite
        return d.get("facts_lite") or {}

    a, b = fa(A), fa(B)

    def row(label, va, vb):
        if va != vb:
            L.append(f"  • {label} :")
            L.append(f"      A = {_short(va)}")
            L.append(f"      B = {_short(vb)}")

    ia, ib = a.get("identité") or {}, b.get("identité") or {}
    row("version", ia.get("app_version"), ib.get("app_version"))
    row("mode (python/exe)", ia.get("mode"), ib.get("mode"))
    row("score de santé", A.get("score"), B.get("score"))

    ca, cb = a.get("configuration") or {}, b.get("configuration") or {}
    row("dernier scan", ca.get("last_scan_time"),
        cb.get("last_scan_time"))
    row("transport CM", ca.get("transport"), cb.get("transport"))
    row("carte CM", ca.get("cm_map"), cb.get("cm_map"))
    row("OTA actives",
        [o["name"] for o in ca.get("otas") or [] if o.get("active")],
        [o["name"] for o in cb.get("otas") or [] if o.get("active")])
    row("cibles", ca.get("target_prices"), cb.get("target_prices"))
    row("inventaire chambres", sorted((ca.get("room_inventory") or {}).keys()),
        sorted((cb.get("room_inventory") or {}).keys()))

    la, lb = ca.get("last_results") or {}, cb.get("last_results") or {}
    if la != lb:
        L.append("  • derniers prix affichés :")
        for ota in sorted(set(la) | set(lb)):
            if la.get(ota) != lb.get(ota):
                L.append(f"      {ota} : A = {la.get(ota)}  |  "
                         f"B = {lb.get(ota)}")

    ka, kb = a.get("calibrations") or {}, b.get("calibrations") or {}
    row("calibrations (aliases)",
        [(p.get("ota"), p.get("room_aliases"))
         for p in ka.get("profiles") or []],
        [(p.get("ota"), p.get("room_aliases"))
         for p in kb.get("profiles") or []])

    sa, sb = a.get("envois") or {}, b.get("envois") or {}
    row("envois (résumé)",
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sa.get("per_ota") or {}).items()},
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sb.get("per_ota") or {}).items()})

    # Constats divergents
    def titles(d):
        return sorted(f"{f.get('severity', '?')}|{f.get('title', '')}"
                      for f in d.get("findings") or [])
    ta, tb = titles(A), titles(B)
    only_a = [t for t in ta if t not in tb]
    only_b = [t for t in tb if t not in ta]
    if only_a:
        L.append("  • constats présents UNIQUEMENT dans A :")
        L.extend(f"      {t}" for t in only_a[:12])
    if only_b:
        L.append("  • constats présents UNIQUEMENT dans B :")
        L.extend(f"      {t}" for t in only_b[:12])

    if len(L) == 4:
        L.append("  ✅ Aucune différence trouvée sur les points suivis.")
    return L


def _short(v):
    s = json.dumps(v, ensure_ascii=False, default=str) \
        if not isinstance(v, str) else v
    return s if len(s) <= 220 else s[:217] + "…"
