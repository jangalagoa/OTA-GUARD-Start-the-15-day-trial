"""
Onglet : Extranet Direct (VAE 2) — OTA Guard V3

Point d'entrée minimal du module « Extranet Direct » (plan §4.1, version
réduite en attente de l'onglet complet É7) :
  1. État du CM — lecture passive (scanner vae2 sur les captures VAE)
  2. Exécution d'UNE correction — TEST à blanc, ou RÉEL derrière la
     validation explicite du propriétaire (plan É4 : validation manuelle
     d'abord). Une seule catégorie à la fois (D8), journal complet,
     vérification avant/après par le scanner.
"""
import queue
import tkinter as tk
from datetime import date, timedelta
from tkinter import messagebox

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame
from core.base_tab import BaseTab
from core.utils import tr_

import extranet_bridge as xb
from core import config as cfg


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app
        tab = frame

        self._q = queue.Queue()          # lignes de journal → thread UI
        self._busy = False

        # ── Topbar ────────────────────────────────────────────────────────
        topbar = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x")
        lbl(topbar, tr_("🌐 Extranet Direct (sans API)"), bold=True, size=11).pack(side="left")
        btn(topbar, tr_("📖 Wiki"),
            lambda: self._show_wiki('🌐 Extranet Direct (sans API)'), color="#89b4fa", width=10).pack(side="right")
        btn(topbar, tr_("🧰 Intégrer un nouveau CM"),
            lambda: self._open_onboard_wizard(), color="#89b4fa", width=20).pack(side="right", padx=(0, 6))

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        # ══ 0. Channel Manager actif (D49 : UN SEUL CM à la fois) ════════
        s0 = section(inner, tr_("0. Channel Manager actif — un seul à la fois"))
        s0.pack(fill="x", padx=10, pady=(8, 0))
        try:
            from vae2.adapters import AdapterRegistry
            _adapters = AdapterRegistry().discover()
        except Exception:
            _adapters = {}
        _by_name = {}
        for _dom, _ad in sorted(_adapters.items()):
            _by_name[_ad.name] = _ad
        _cm_cfg = app.config.get("channel_manager", {}).get(
            "extranet_direct", {}) or {}
        _cur_file = str(_cm_cfg.get("cm_map") or "channelmanager_com_au.yaml")
        _cur = next((_a for _a in _by_name.values()
                     if _a.map_path.name == _cur_file), None)
        _names = [a.name for a in _by_name.values()] or ["—"]
        r_cm = tk.Frame(s0, bg=T.BG); r_cm.pack(fill="x", pady=3)
        lbl(r_cm, tr_("CM actif :"), bold=True, width=12).pack(side="left")
        self._cm_var = tk.StringVar(
            value=(_cur.name if _cur else (_names[0] if _names else "—")))
        tk.OptionMenu(r_cm, self._cm_var, *_names).pack(side="left", padx=(0, 8))
        btn(r_cm, tr_("💾 Appliquer"), self._save_active_cm,
            color=T.ACCENT, width=12).pack(side="left")
        _dom = _cur.domain if _cur else "?"
        lbl(s0, tr_("Domaine : {d} — le changement prend effet au prochain "
                    "démarrage (keep-alive + écoute). VAE2 ne travaille "
                    "jamais avec plusieurs CM en même temps.").format(d=_dom),
            color="#888888", size=8).pack(anchor="w", pady=(2, 0))

        # ══ 1. État du CM (lecture passive) ══════════════════════════════
        # D89 : identifiants de secours pour la reconnexion automatique
        s0b = section(inner, tr_("🔐 Reconnexion automatique — identifiants "
                                 "de secours (optionnel)"))
        s0b.pack(fill="x")
        lbl(s0b, tr_("Utilisé SEULEMENT si l'autofill de Brave ne remplit "
                     "pas le formulaire. Stocké chiffré (DPAPI, lié à "
                     "cette machine). Vide = comportement actuel (2 "
                     "clics autofill, sinon connexion manuelle)."),
            color="#888888", size=8).pack(anchor="w", pady=(0, 4))
        from business.secrets import load_secrets, save_secrets
        _sec = load_secrets()
        row_u = tk.Frame(s0b, bg=T.BG); row_u.pack(fill="x", pady=1)
        lbl(row_u, tr_("Utilisateur :"), size=9).pack(side="left")
        e_u = tk.Entry(row_u, width=28, bg=T.ENTRY_BG, fg=T.FG,
                       relief="flat", insertbackground=T.FG)
        e_u.insert(0, _sec.get("cm_user", ""))
        e_u.pack(side="left", padx=8)
        row_p = tk.Frame(s0b, bg=T.BG); row_p.pack(fill="x", pady=1)
        lbl(row_p, tr_("Mot de passe :"), size=9).pack(side="left")
        e_p = tk.Entry(row_p, width=28, bg=T.ENTRY_BG, fg=T.FG,
                       relief="flat", insertbackground=T.FG, show="\u2022")
        e_p.insert(0, _sec.get("cm_pass", ""))
        e_p.pack(side="left", padx=8)

        def _save_creds():
            s = load_secrets()
            s["cm_user"] = e_u.get().strip()
            s["cm_pass"] = e_p.get()
            save_secrets(s)
            messagebox.showinfo(
                tr_("Reconnexion automatique"),
                tr_("Identifiants enregistrés (chiffrés DPAPI). La "
                    "reconnexion automatique les utilisera seulement si "
                    "l'autofill Brave échoue."),
                parent=self.app.root)

        btn(s0b, tr_("💾 Enregistrer"), _save_creds,
            color=T.GREEN, width=14).pack(anchor="w", pady=4)

        s1 = section(inner, tr_("1. État du Channel Manager — lecture passive"))
        s1.pack(fill="x", padx=10, pady=8)

        self._state_lbl = lbl(s1, tr_("Non chargé — cliquez sur « Charger l'état ».\n"
                                      "(aucune requête n'est émise : lecture des captures "
                                      "du navigateur)"), size=8)
        self._state_lbl.pack(anchor="w", pady=(0, 6))

        r0 = tk.Frame(s1, bg=T.BG); r0.pack(fill="x", pady=3)
        btn(r0, tr_("🔄 Charger l'état"), self._load_state,
            color=T.ACCENT, width=18).pack(side="left")

        r1 = tk.Frame(s1, bg=T.BG); r1.pack(fill="x", pady=3)
        lbl(r1, tr_("Chambre :"), width=10).pack(side="left")
        self._room_cb = tk.StringVar()
        self._room_menu = tk.OptionMenu(r1, self._room_cb, "—")
        self._room_menu.pack(side="left", padx=(0, 12))
        lbl(r1, tr_("OTA :"), width=6).pack(side="left")
        self._ota_cb = tk.StringVar()
        self._ota_menu = tk.OptionMenu(r1, self._ota_cb, "—")
        self._ota_menu.pack(side="left")

        self._room_cb.trace_add("write", self._refresh_current)
        self._ota_cb.trace_add("write", self._refresh_current)

        r2 = tk.Frame(s1, bg=T.BG); r2.pack(fill="x", pady=3)
        lbl(r2, tr_("Prix à appliquer :"), width=18).pack(side="left")
        self._rate_var = tk.StringVar()
        entry(r2, self._rate_var, width=10).pack(side="left", padx=(0, 12))
        lbl(r2, tr_("Du (AAAA-MM-JJ) :"), width=16).pack(side="left")
        self._from_var = tk.StringVar(value=(date.today() + timedelta(days=4)).isoformat())
        entry(r2, self._from_var, width=12).pack(side="left", padx=(0, 8))
        lbl(r2, tr_("Au :"), width=3).pack(side="left")
        self._to_var = tk.StringVar(value=(date.today() + timedelta(days=4)).isoformat())
        entry(r2, self._to_var, width=12).pack(side="left")

        self._cur_lbl = lbl(s1, "", size=8)
        self._cur_lbl.pack(anchor="w", pady=(6, 0))

        # ══ 2. Exécution ══════════════════════════════════════════════════
        s2 = section(inner, tr_("2. Exécution — une catégorie à la fois"))
        s2.pack(fill="x", padx=10, pady=8)
        lbl(s2, tr_("TEST remplit le formulaire du CM sans jamais valider.\n"
                    "APPLIQUER valide réellement (après votre confirmation)."),
            size=8).pack(anchor="w", pady=(0, 6))

        r3 = tk.Frame(s2, bg=T.BG); r3.pack(fill="x", pady=3)
        self._test_btn = btn(r3, tr_("▶ Exécuter TEST (à blanc)"), self._run_test,
                             color="#94e2d5", width=22)
        self._test_btn.pack(side="left")
        self._apply_btn = btn(r3, tr_("✅ APPLIQUER (réel)"), self._run_real,
                              color="#f97316", width=18)
        self._apply_btn.pack(side="left", padx=(8, 0))

        # Couture E4 : AFFICHAGE du routage (réglé dans l'onglet Channel
        # Manager → Transport — source de vérité unique, pas de 2e case ici)
        r3b = tk.Frame(s2, bg=T.BG); r3b.pack(fill="x", pady=(6, 0))
        self._routing_lbl = lbl(r3b, "", size=8)
        self._routing_lbl.pack(side="left")
        self._refresh_routing_status()

        self._result_lbl = lbl(s2, "", bold=True)
        self._result_lbl.pack(anchor="w", pady=(6, 0))

        # ══ 3. Journal ════════════════════════════════════════════════════
        s3 = section(inner, tr_("3. Journal des actions"))
        s3.pack(fill="x", padx=10, pady=8)
        self._log = tk.Text(s3, height=14, bg=T.ENTRY_BG, fg=T.FG,
                            font=("Courier New", 8), relief="flat")
        self._log.pack(fill="x", padx=4, pady=4)

        self._poll()

    # ── Statut du routage (couture E4, réglé dans l'onglet CM) ──────────────

    def _refresh_routing_status(self):
        cm = self.app.config.get("channel_manager", {}) or {}
        on = bool((cm.get("extranet_direct") or {}).get("enabled"))
        if on:
            self._routing_lbl.configure(
                text=tr_("🟢 Les envois du « Blocage prix OTA » passent par "
                         "ICI (Extranet Direct)"),
                fg=T.GREEN)
        else:
            self._routing_lbl.configure(
                text=tr_("⚪ Envois via l’API CM — pour router ici : onglet "
                         "Channel Manager → Transport → 🌐 Extranet Direct"),
                fg="#888888")

    # ── Lecture de l'état ─────────────────────────────────────────────────

    def _say(self, line):
        self._q.put(str(line))

    def _poll(self):
        try:
            while True:
                line = self._q.get_nowait()
                self._log.insert("end", line + "\n")
                self._log.see("end")
        except queue.Empty:
            pass
        self.app.root.after(150, self._poll)

    def _open_onboard_wizard(self):
        """D51 : assistant pas-a-pas d'integration d'un nouveau CM."""
        from tabs.onboard_wizard import open_wizard
        open_wizard(self.app)

    def _save_active_cm(self):
        """D49 : enregistre le CM actif (choix UNIQUE) dans la config."""
        try:
            _sel = (self._cm_var.get() or "").strip()
            from vae2.adapters import AdapterRegistry
            _ad = AdapterRegistry().discover()
            _match = next((a for a in _ad.values() if a.name == _sel), None)
            if _match is None:
                messagebox.showerror(
                    tr_("CM actif"),
                    tr_("Adaptateur introuvable : {n}").format(n=_sel),
                    parent=self.app.root)
                return
            cm = self.app.config.setdefault("channel_manager", {})
            xd = cm.setdefault("extranet_direct", {})
            xd["cm_map"] = _match.map_path.name
            cfg.save(self.app.config)
            self._say(f"CM actif : {_match.name} (domaine {_match.domain}) — "
                      f"prend effet au prochain démarrage")
            messagebox.showinfo(
                tr_("CM actif"),
                tr_("Channel Manager actif : {n}\nDomaine : {d}\n\n"
                    "Prend effet au prochain démarrage de l'application.")
                    .format(n=_match.name, d=_match.domain),
                parent=self.app.root)
        except Exception as e:
            messagebox.showerror(tr_("CM actif"),
                                 tr_("Erreur : {e}").format(e=e),
                                 parent=self.app.root)

    def _load_state(self):
        """D103 — section « 1. Channel Manager status » REFÁITE : la lecture
        ne peut plus rien cacher. Le journal montre chaque dossier de
        captures candidat (chemin, nombre, fraîcheur) et celui qui est lu ;
        toute erreur du scan est AFFICHÉE (label + journal) au lieu d'un
        « 0 chambres » muet ; un dossier vide ou mal choisi se voit tout
        de suite à l'écran."""
        if self._busy:
            return
        self._state_lbl.configure(text=tr_("Scan des captures en cours…"))
        self._say("── Chargement de l'état du CM (lecture passive) ──")

        def work():
            import time as _t
            # 1. Dossiers de captures : ce qui existe, ce qui est lu.
            try:
                infos = xb.capture_folders_report(self.app.config)
                for info in infos:
                    if not info["exists"]:
                        self._say(f"📁 {info['label']} : ABSENT "
                                  f"({info['path']})")
                        continue
                    if info["newest"]:
                        age_h = (_t.time() - info["newest"]) / 3600.0
                        fresh = f" · plus récente il y a {age_h:.1f} h"
                    else:
                        fresh = " · VIDE"
                    star = " ★" if info["label"].startswith("←") else ""
                    self._say(f"📁 {info['label']} : {info['count']} "
                              f"capture(s){fresh}{star}")
            except Exception as e:
                self._say(f"⚠ diagnostic des dossiers impossible : {e}")
            # 2. Le scan lui-même — toute exception est AFFICHÉE.
            try:
                rep = xb.scan_cm(self.app.config, say=self._say)
            except Exception as e:
                self._q.put(f"✗ ERREUR DU SCAN : {e}\n")
                self.app.root.after(0, lambda: self._state_lbl.configure(
                    text=tr_("✗ Erreur du scan — détail dans le journal")))
                return
            self._q.put(f"── scan : {rep.status} · capturé le "
                        f"{rep.captured_at} · {len(rep.rooms)} chambre(s)\n")
            self.app.root.after(0, lambda: self._fill_state(rep))

        self._run_thread(work)

    def _fill_state(self, rep):
        if rep.status != "ok" or not rep.rooms:
            self._state_lbl.configure(
                text=tr_("✗ Aucune grille CM dans les captures — vois les "
                         "dossiers 📁 dans le journal (dossier lu, nombre "
                         "de captures, fraîcheur)"))
            self._say("✗ Aucune grille exploitable — causes possibles : "
                      "dossier de captures mal choisi (voir 📁), captures "
                      "CM purgées, ou grille jamais chargée dans Brave")
            return
        st = xb.cm_state()
        rooms = [r["label"] for r in st["rooms"]]
        otas = [o["label"] for o in st["otas"]]
        self._room_cb.set(rooms[0] if rooms else "—")
        menu = self._room_menu["menu"]; menu.delete(0, "end")
        for r in rooms: menu.add_command(label=r, command=lambda v=r: self._room_cb.set(v))
        self._ota_cb.set(otas[0] if otas else "—")
        menu = self._ota_menu["menu"]; menu.delete(0, "end")
        for o in otas: menu.add_command(label=o, command=lambda v=o: self._ota_cb.set(v))
        self._state_lbl.configure(text=(
            f"{len(rooms)} chambres · {len(otas)} OTA · devise {st['currency']} · "
            f"capturé le {st['captured_at']}"))
        self._refresh_current()

    def _refresh_current(self, *_):
        st = xb.cm_state()
        if not st:
            return
        room = next((r for r in st["rooms"] if r["label"] == self._room_cb.get()), None)
        ota = next((o for o in st["otas"] if o["label"] == self._ota_cb.get()), None)
        if not room or not ota:
            return
        p = xb.daily_price(room["code"], ota["code"], self._from_var.get().strip())
        if p is not None:
            self._cur_lbl.configure(text=tr_("Prix actuel lu sur la grille "
                                             "(le {d}) : {p:g} {cur}")
                                    .format(d=self._from_var.get(), p=p,
                                            cur=st['currency'] or ''))

    # ── Exécution ─────────────────────────────────────────────────────────

    def _task_dict(self):
        return {
            "room_label": self._room_cb.get(),
            "ota_label": self._ota_cb.get(),
            "rate": self._rate_var.get().strip(),
            "date_from": self._from_var.get().strip(),
            "date_to": self._to_var.get().strip(),
        }

    def _run_test(self):
        self._launch(confirmed=False)

    def _run_real(self):
        t = self._task_dict()
        ok = messagebox.askyesno(
            tr_("Confirmer l'envoi réel"),
            tr_("Modifier RÉELLEMENT le prix sur le Channel Manager ?\n\n"
                "Chambre : {r}\nOTA : {o}\nPrix : {p}\n"
                "Dates : {df} → {dt}").format(
                r=t['room_label'], o=t['ota_label'], p=t['rate'],
                df=t['date_from'], dt=t['date_to']),
            icon="warning", parent=self.app.root)
        if ok:
            self._launch(confirmed=True)

    def _launch(self, confirmed):
        if self._busy:
            messagebox.showinfo(tr_("En cours"), tr_("Une exécution est déjà en cours."),
                                parent=self.app.root)
            return
        t = self._task_dict()
        if t["room_label"] in ("—", "") or not t["rate"] \
                or not t["date_from"] or not t["date_to"]:
            messagebox.showwarning(
                tr_("Incomplet"),
                tr_("Chambre, OTA, prix et dates sont obligatoires."),
                parent=self.app.root)
            return
        self._busy = True
        self._refresh_routing_status()
        self._test_btn.configure(state="disabled")
        self._apply_btn.configure(state="disabled")
        self._result_lbl.configure(text=tr_("Exécution en cours…"), fg=T.FG)
        self._say(f"── {'APPLIQUER (réel)' if confirmed else 'TEST (à blanc)'} : "
                  f"{t['room_label']} / {t['ota_label']} / {t['rate']} "
                  f"du {t['date_from']} au {t['date_to']} ──")

        def done(result):
            def ui():
                self._busy = False
                self._test_btn.configure(state="normal")
                self._apply_btn.configure(state="normal")
                outcome = result.get("outcome")
                if outcome == "test_ok_no_modification":
                    self._result_lbl.configure(
                        text=tr_("✔ TEST terminé — aucune modification envoyée"),
                        fg=T.GREEN)
                elif outcome == "verified":
                    changes = result.get("price_changes") or []
                    self._result_lbl.configure(
                        text=tr_("✔ ENVOYÉ ET VÉRIFIÉ — {n} changement(s) "
                                 "constaté(s) sur la grille").format(
                            n=len(changes)), fg=T.GREEN)
                else:
                    self._result_lbl.configure(
                        text=tr_("✖ Terminé : {o} — page laissée en l'état").format(
                            o=outcome),
                        fg=T.RED)
            self.app.root.after(0, ui)

        xb.run_correction(t, confirmed=confirmed, say=self._say, done=done,
                          app_config=self.app.config)

    def _run_thread(self, work):
        import threading
        threading.Thread(target=work, daemon=True,
                         name="vae2-extranet-ui").start()
