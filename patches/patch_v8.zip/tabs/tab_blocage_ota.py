"""
Onglet : Blocage Ota
Fait partie de ScraperApp via héritage mixin.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import sys as _sys
from pathlib import Path
BASE_DIR = Path(__file__).parent.parent
from core.paths import DATA_DIR

from datetime import datetime, timedelta
import threading
import logging
import re
from core.theme import T, THEMES
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip, zebra_stripe, status_badge, _btn_fg
from core.utils import tr_, attach_sort, fmt_dt, parse_dt_any
from core import config as cfg
from core.base_tab import BaseTab
_attach_sort = attach_sort
RISK_COLORS = {'safe': '#27ae60', 'medium': '#2980b9', 'high': '#e67e22', 'danger': '#c0392b'}
RISK_LABELS  = {'safe': 'SAFE',   'medium': 'MEDIUM',  'high': 'HIGH',    'danger': 'DANGER'}

# Currency symbol map — dynamic so VAE integration can use any host currency.
_CURRENCY_SYMBOLS = {
    'INR': '\u20b9', 'USD': '$', 'EUR': '\u20ac', 'GBP': '\u00a3',
    'THB': '\u0e3f', 'JPY': '\u00a5', 'CNY': '\u00a5', 'AUD': 'A$',
    'CAD': 'C$', 'CHF': 'Fr', 'SGD': 'S$', 'AED': 'AED', 'LAK': '\u20ad',
}


def _currency_symbol(config):
    """Return the display symbol for the configured hotel currency."""
    code = (config.get('hotel_currency')
            or config.get('currency_code')
            or 'INR')
    return _CURRENCY_SYMBOLS.get(str(code).upper(), str(code) + ' ')


def load_config(): return cfg.load()


def _get(name, default=None):
    """Accès aux variables globales de main (couleurs, helpers UI)."""
    return getattr(_sys.modules.get("__main__"), name, default)


def _median(xs):
    """Médiane d'une liste de nombres (moyenne des deux valeurs centrales si
    nombre pair). Retourne None si la liste est vide."""
    xs = sorted(xs)
    n = len(xs)
    if n == 0:
        return None
    if n % 2:
        return xs[n // 2]
    return (xs[n // 2 - 1] + xs[n // 2]) / 2


def _cm_override_for(ov_c: dict, rm: str, fb: str = None) -> dict:
    """D94 : réglage « Envoi min/max CM » d'UNE chambre — nom EXACT
    uniquement (ou repli explicite `fb`, lui-même un nom de chambre déjà
    résolu). JAMAIS de rapprochement flou : l'override 2000 de
    « Double Room with Balcony » fuiait sur « Double Room » (Jaccard
    0,5 ≥ seuil de l'ancien code) et bloquait sa cible à jamais —
    l'écart était visible dans le rapport D92 du PC client (05/10) :
    « prix calculé 1,736 sous le minimum autorisé 2,000 » alors que le
    plancher déclaré de la chambre est 1400. Un override est une décision
    DELIBÉRÉE par chambre : la ressemblance de noms n'a rien à y faire
    (même espèce que D86 : noms imbriqués)."""
    if rm in ov_c:
        return ov_c.get(rm) or {}
    if fb and fb in ov_c:
        return ov_c.get(fb) or {}
    return {}


# ── Garde-fou : pas de montant reçu → pas de prix rendu ─────────────────────
# Sans montant détecté dans le texte, on ne renvoie jamais de prix : un prix
# sans source serait inventé, puis envoyé au Channel Manager comme s'il était
# réel.
#
# Le repli multi-dates (plus bas dans ce fichier) ne se déclenche que pour les
# chambres SANS prix (`_missing`). Un prix inventé ferait croire que la chambre
# est trouvée, bloquerait le changement de date, et partirait au Channel Manager.
#
# La règle est donc : aucun montant dans le texte → la chambre reste sans prix,
# ce qui rend la main au repli multi-dates, dont c'est précisément le rôle.
_PRICE_IN_TEXT = re.compile(
    # 1. montant accolé à une devise (texte visible de la page)
    r"(?:Rs\.?|INR|₹|₨|\$|USD|€|EUR|£|GBP|฿|THB|¥|JPY)\s*\d[\d\s,\.]{2,}"
    r"|\d[\d\s,\.]{2,}\s*(?:Rs\.?|INR|₹|₨|USD|EUR|GBP|THB|JPY)"
    # 2. montant porté par une clé JSON ou un attribut HTML (code de la page :
    #    "price":1234, data-rate='1234'…) — un prix reste un prix même quand
    #    la devise est déclarée ailleurs dans le document.
    r"|(?:price|amount|rate|tarif|prix|total|montant)[\"'\s\]]*[:=][\"'\s]*\d{3,}",
    re.IGNORECASE,
)


def _text_has_price(text: str) -> bool:
    """Le texte contient-il au moins un montant (n'importe où dans la page) ?

    Bug C2 : on testait avant uniquement les 4000 premiers caractères. Il faut
    tester la page entière pour ne pas manquer un prix présent plus loin.
    """
    return bool(text) and bool(_PRICE_IN_TEXT.search(text))


# ── Détection de blocage / CAPTCHA (gratuit, sans IA) ───────────────────────
# Mots-signaux présents sur une page de blocage ou de défi anti-robot. La
# détection est purement textuelle (aucun appel IA, aucun coût). Elle ne sert
# qu'à SAVOIR qu'un blocage a eu lieu — jamais à interrompre un moteur.
#
# Ces mots ne sont cherchés que dans le TEXTE RÉELLEMENT AFFICHÉ, jamais dans
# le code caché de la page (<script>, <style>, commentaires, attributs). De
# très nombreux sites parfaitement accessibles embarquent ces mots dans leur
# configuration JavaScript : Airbnb expose par exemple
# {"disable_google_recaptcha": true} et une clé « datadome_integration »
# alors que la page s'affiche normalement, Google Hotels de même. Chercher
# dans le code brut déclenchait donc une alerte de blocage à chaque relevé
# sur des OTA qui ne bloquaient rien (constaté : Airbnb ×4 et Google Hotels).
_BLOCK_SIGNALS = (
    # anglais
    "captcha", "recaptcha", "hcaptcha", "are you human", "are you a human",
    "human or a bot", "human or bot", "bot or not", "not a robot",
    "unusual traffic", "verify you are", "access denied", "access to this page",
    "datadome", "px-captcha", "perimeterx", "just a moment",
    "checking your browser", "enable javascript and cookies", "security check",
    "press and hold", "confirm you are", "suspicious activity",
    # français — le logiciel navigue en fr-FR sur la plupart des OTA, les
    # pages de blocage y sont donc souvent traduites.
    "accès refusé", "acces refuse", "activité suspecte", "trafic inhabituel",
    "vérification de sécurité", "je ne suis pas un robot",
    "vérifier que vous êtes", "appuyez et maintenez",
)

# Marqueurs d'un défi VISIBLE (grille d'images / texte à résoudre), par
# opposition à un blocage invisible où il n'y a rien à résoudre pour l'IA.
# Ce sont des identifiants de BALISAGE (classes, id, src) : ils sont cherchés
# dans le balisage, mais pas dans le corps des <script> — une simple mention
# de « grecaptcha » dans un bloc de configuration JavaScript ne signifie pas
# qu'un défi est affiché, et cette détection commande une dépense (résolution
# automatique payante).
_VISIBLE_CAPTCHA_MARKERS = (
    "g-recaptcha", "recaptcha/api2", "recaptcha/api.js", "grecaptcha",
    "h-captcha", "hcaptcha.com", "captcha-image", "captcha_image",
    "px-captcha", "press and hold",
)

# Blocs de code jamais affichés à l'écran, à retirer avant toute recherche
# de mots-signaux.
_RE_HIDDEN_BLOCKS = re.compile(
    r"(?is)<script\b.*?</script\s*>"
    r"|<style\b.*?</style\s*>"
    r"|<noscript\b.*?</noscript\s*>"
    r"|<template\b.*?</template\s*>"
    r"|<!--.*?-->")
_RE_ALL_TAGS = re.compile(r"(?s)<[^>]*>")
# Vide le CORPS des <script> mais conserve la balise et ses attributs, afin de
# continuer à voir un <script src="…/recaptcha/api.js">.
_RE_SCRIPT_BODY = re.compile(r"(?is)(<script\b[^>]*>).*?(</script\s*>)")


def _visible_text(html_or_text):
    """Ne conserve que ce que la page affiche vraiment.

    Retire les blocs <script>/<style>/<noscript>/<template>, les commentaires
    HTML, puis toutes les balises (donc aussi leurs attributs, qui contiennent
    souvent des identifiants techniques du genre « captcha-container »).
    Une entrée déjà en texte brut ressort inchangée.
    """
    if not html_or_text:
        return ""
    return _RE_ALL_TAGS.sub(" ", _RE_HIDDEN_BLOCKS.sub(" ", html_or_text))


def _markup_without_scripts(html):
    """Balisage complet, mais privé du contenu exécutable des <script>."""
    if not html:
        return ""
    return _RE_SCRIPT_BODY.sub(r"\1\2", html)


def _looks_blocked(html_or_text):
    """True si la page AFFICHE un blocage / CAPTCHA.

    Détection gratuite par mots-clés — aucune IA. La recherche porte sur le
    texte visible uniquement (cf. _visible_text) : le code caché d'une page
    normale contient très souvent ces mots sans qu'aucun blocage n'existe.
    Cette détection n'est de toute façon exploitée QUE lorsqu'aucun prix n'a
    été trouvé (voir l'étape de récupération dans _run_4eng).
    """
    if not html_or_text:
        return False
    t = _visible_text(html_or_text).lower()
    return any(s in t for s in _BLOCK_SIGNALS)


def _captcha_visible(html):
    """True si le blocage propose un défi VISIBLE (résolvable par l'IA ou à la
    main), False si c'est un blocage invisible (rien à résoudre : score de
    risque en arrière-plan, cf. reCAPTCHA v3 / DataDome / PerimeterX)."""
    if not html:
        return False
    t = _markup_without_scripts(html).lower()
    return any(s in t for s in _VISIBLE_CAPTCHA_MARKERS)


def _xb_scan_end():
    """D52 : libère le créneau opération du scan (idempotent)."""
    try:
        import extranet_bridge as _xb
        _xb.operation_end("scan")
    except Exception:
        pass


# ── Auto-detection OTA from Brave via CDP ──────────────────────────────────

_CDP_PORT = 9222

# Domain substring → display name for known OTAs.
# Regional TLDs are listed so that country-specific domains
# (expedia.fr, booking.com, airbnb.co.uk…) are always detected.
_DOMAIN_DISPLAY = {
    # Agoda
    "agoda.com": "Agoda", "agoda.net": "Agoda",
    # Booking
    "booking.com": "Booking.com",
    # Expedia (all regional TLDs)
    "expedia.com": "Expedia", "expedia.fr": "Expedia",
    "expedia.co.uk": "Expedia", "expedia.de": "Expedia",
    "expedia.ca": "Expedia", "expedia.es": "Expedia",
    "expedia.it": "Expedia", "expedia.nl": "Expedia",
    "expedia.com.au": "Expedia", "expedia.co.in": "Expedia",
    "expedia.co.jp": "Expedia", "expedia.com.br": "Expedia",
    "expedia.com.sg": "Expedia", "expedia.co.th": "Expedia",
    "expedia.ae": "Expedia", "expedia.sa": "Expedia",
    "expedia.com.my": "Expedia", "expedia.co.id": "Expedia",
    "expedia.com.hk": "Expedia", "expedia.com.tw": "Expedia",
    "expedia.com.ph": "Expedia", "expedia.vn": "Expedia",
    # Airbnb
    "airbnb.com": "Airbnb", "airbnb.fr": "Airbnb",
    "airbnb.co.uk": "Airbnb", "airbnb.de": "Airbnb",
    "airbnb.es": "Airbnb", "airbnb.it": "Airbnb",
    "airbnb.ca": "Airbnb", "airbnb.com.au": "Airbnb",
    "airbnb.co.in": "Airbnb", "airbnb.jp": "Airbnb",
    "airbnb.com.br": "Airbnb", "airbnb.nl": "Airbnb",
    "airbnb.be": "Airbnb", "airbnb.ch": "Airbnb",
    # MakeMyTrip
    "makemytrip.com": "MakeMyTrip", "makemytrip.global": "MakeMyTrip",
    # Goibibo
    "goibibo.com": "Goibibo",
    # Kayak
    "kayak.com": "Kayak", "kayak.co.uk": "Kayak", "kayak.fr": "Kayak",
    "kayak.de": "Kayak", "kayak.es": "Kayak", "kayak.it": "Kayak",
    "kayak.ca": "Kayak", "kayak.com.au": "Kayak", "kayak.co.in": "Kayak",
    # TripAdvisor
    "tripadvisor.com": "TripAdvisor", "tripadvisor.fr": "TripAdvisor",
    "tripadvisor.co.uk": "TripAdvisor", "tripadvisor.de": "TripAdvisor",
    "tripadvisor.es": "TripAdvisor", "tripadvisor.it": "TripAdvisor",
    "tripadvisor.ca": "TripAdvisor", "tripadvisor.in": "TripAdvisor",
    "tripadvisor.com.au": "TripAdvisor",
    # Hotels.com
    "hotels.com": "Hotels.com", "hotels.fr": "Hotels.com",
    "hotels.co.uk": "Hotels.com", "hotels.de": "Hotels.com",
    # Traveloka
    "traveloka.com": "Traveloka",
    # Trip.com / Ctrip
    "trip.com": "Trip.com", "ctrip.com": "Trip.com",
    # HRS
    "hrs.com": "HRS",
    # LastMinute
    "lastminute.com": "LastMinute",
    # Weekendesk
    "weekendesk.com": "Weekendesk", "weekendesk.fr": "Weekendesk",
    # Priceline
    "priceline.com": "Priceline",
    # Hostelworld
    "hostelworld.com": "Hostelworld",
    # Almosafer
    "almosafer.com": "Almosafer",
    # Rehlat
    "rehlat.com": "Rehlat",
    # Tiket
    "tiket.com": "Tiket.com",
}

# Brand → display name fallback.  Extracted from the hostname's
# second-level domain, so ANY regional TLD is caught automatically
# (e.g. "expedia.co.nz" → brand "expedia" → "Expedia").
_BRAND_DISPLAY = {
    "agoda": "Agoda",
    "booking": "Booking.com",
    "expedia": "Expedia",
    "airbnb": "Airbnb",
    "makemytrip": "MakeMyTrip",
    "goibibo": "Goibibo",
    "kayak": "Kayak",
    "tripadvisor": "TripAdvisor",
    "hotels": "Hotels.com",
    "traveloka": "Traveloka",
    "trip": "Trip.com",
    "ctrip": "Trip.com",
    "hrs": "HRS",
    "lastminute": "LastMinute",
    "weekendesk": "Weekendesk",
    "priceline": "Priceline",
    "hostelworld": "Hostelworld",
    "almosafer": "Almosafer",
    "rehlat": "Rehlat",
    "tiket": "Tiket.com",
}

# Generalist sites excluded from auto-detection (must be added manually)
_GENERALIST_PATTERNS = (
    "google.com/travel", "google.com/hotels",
    "www.google.com/hotels", "www.google.com/travel",
    "trivago.com",
)

# Rooms that are internal CM test entries — never appear on real booking
# sites, so they must never show in scan results.
_EXCLUDED_ROOMS = {"move room"}

# Known OTA brand names (lowercase) used to group multi-room listings of
# the same OTA together in the UI. Longest brands first so that e.g.
# "google hotels" matches before "google".
_KNOWN_BRANDS = sorted(
    {v.lower() for v in _DOMAIN_DISPLAY.values()} | {
        "google hotels", "trivago", "booknow", "roibos",
    },
    key=len, reverse=True,
)

# Goibibo and MakeMyTrip share the same inventory (same parent company).
# Only one CM price can be sent for both, so they are merged into a single
# column in the target prices grid and share one target price key.
_MMT_GROUP = {"goibibo", "makemytrip"}
_MMT_DISPLAY = "MakeMyTrip / Goibibo"


def _ota_group_key(name):
    """Return the grouped OTA display name if the OTA belongs to a group.

    Goibibo and MakeMyTrip map to the same canonical name so the target
    prices grid shows one column for both.  Other OTAs return themselves.
    """
    brand = _ota_brand_key(name)
    if brand in _MMT_GROUP:
        return _MMT_DISPLAY
    return name


def _ota_brand_key(name):
    """Return the OTA brand (lowercase) used for grouping/sorting.

    'Airbnb Deluxe Double Room' -> 'airbnb'
    'Agoda'                     -> 'agoda'
    'Google Hotels'             -> 'google hotels'
    Unknown names fall back to their first word.
    """
    n = (name or "").lower().strip()
    for b in _KNOWN_BRANDS:
        if n == b or n.startswith(b + " "):
            return b
    return n.split()[0] if n else ""


# ── Per-OTA color palette (visually distinct, auto-assigned) ──────────
# Each new OTA encountered gets the next color in the palette, cycling
# back to the start when exhausted.  foreground only; background is
# handled separately by zebra_stripe().
_OTA_PALETTE = [
    "#ff6b6b",  # coral red
    "#4dabf7",  # dodger blue
    "#51cf66",  # grass green
    "#ffa94d",  # tangerine
    "#cc5de8",  # medium purple
    "#22b8cf",  # cyan
    "#ffd43b",  # golden yellow
    "#f06595",  # pink
    "#20c997",  # teal
    "#748ffc",  # cornflower blue
    "#e599f7",  # light violet
    "#ff922b",  # orange
    "#94d82d",  # lime green
    "#845ef7",  # vivid purple
    "#66d9e8",  # light cyan
    "#f783ac",  # salmon pink
    "#a9e34b",  # yellow green
    "#5c7cfa",  # indigo
    "#ffa8a8",  # light coral
    "#ffe066",  # light gold
]

_ota_color_map: dict[str, str] = {}      # brand_key -> hex color
_ota_color_counter = [0]                 # mutable counter for closures


def _get_ota_color(ota_name: str) -> str:
    """Return a consistent foreground color for *ota_name*.

    On first encounter the OTA is assigned the next available colour
    from ``_OTA_PALETTE``.  Subsequent calls return the same colour.
    The assignment uses the *brand key* so that "Airbnb Room X" and
    "Airbnb Room Y" share one colour.
    """
    key = _ota_brand_key(ota_name)
    if key not in _ota_color_map:
        _ota_color_map[key] = _OTA_PALETTE[
            _ota_color_counter[0] % len(_OTA_PALETTE)]
        _ota_color_counter[0] += 1
    return _ota_color_map[key]


def _detect_otas_from_brave(config_otas=None):
    """Detect OTA tabs from Brave browser via CDP (synchronous, fast).

    Connects to ``http://127.0.0.1:9222/json/list``, lists all browser tabs,
    filters for known OTA domains (excluding generalist sites like Google
    Hotels / Trivago), and returns a list of detected OTA entries.

    When multiple tabs of the same OTA are open (e.g. 4 Airbnb rooms),
    each tab becomes a separate entry.  A room name is extracted from
    the tab title when possible.  Entries are sorted by OTA brand so
    that same-OTA listings appear adjacent in the UI.

    Args:
        config_otas: existing OTA config list used as *fallback* when
            Brave is not running.

    Returns:
        list[dict]: ``[{name, url, domain, title, source}]``
        ``source`` is ``"brave"`` for detected tabs or ``"config"`` for
        fallback entries.
    """
    import json as _json
    import urllib.request as _urllib_req
    from urllib.parse import urlparse as _urlparse

    def _main_domain(url):
        """Extract the registrable domain (handles co.uk, com.br, etc.)."""
        try:
            h = (_urlparse(url).hostname or "").lower().replace("www.", "")
            parts = h.split(".")
            if len(parts) <= 2:
                return h
            # Known multi-part TLDs → keep last 3 parts
            _MULTI_TLD = {"co.uk", "co.jp", "co.kr", "com.br", "com.au",
                          "com.sg", "com.hk", "com.tw", "com.my", "com.ph",
                          "com.vn", "co.in", "co.id", "co.th", "co.nz",
                          "com.mx", "com.ar", "com.co", "co.za"}
            last_two = ".".join(parts[-2:])
            if last_two in _MULTI_TLD and len(parts) >= 3:
                return ".".join(parts[-3:])
            return last_two
        except Exception:
            return ""

    def _ota_name_for_url(url):
        url_lower = url.lower()
        # 1) Exact substring match against known domains (fast path)
        for dom, name in _DOMAIN_DISPLAY.items():
            if dom in url_lower:
                return name
        # 2) Brand-based fallback: extract the hostname's second-level
        # domain (the "brand") and match it.  This catches ANY regional
        # TLD not explicitly listed above (expedia.co.nz, booking.cm…).
        try:
            h = (_urlparse(url).hostname or "").lower().replace("www.", "")
            if h:
                brand = h.split(".")[0]
                if brand in _BRAND_DISPLAY:
                    return _BRAND_DISPLAY[brand]
        except Exception:
            pass
        return None

    def _room_from_title(title):
        """Try to extract a meaningful room name from a browser tab title."""
        if not title:
            return None
        parts = re.split(r'[\|–—·\-\u2013\u2014]', title)
        parts = [p.strip() for p in parts if p.strip()]
        _skip = {
            "airbnb", "booking", "expedia", "agoda", "goibibo", "makemytrip",
            "kayak", "tripadvisor", "hotels", "hotel", "resort", "jangala",
            "baga", "goa", "india", "guesthouse", "guest house", "superhost",
            "places to stay", "stays", "reviews", "book", "help center",
            "travel", "trivago", "google", "google hotels", "home",
            "move room",
        }
        _room_kw = {
            "room", "double", "single", "deluxe", "suite", "standard",
            "twin", "king", "queen", "balcony", "view", "family",
            "premium", "superior", "classic", "villa",
        }
        for p in parts:
            pl = p.lower().strip()
            if len(pl) < 3 or len(pl) > 50:
                continue
            if any(s in pl for s in _skip):
                continue
            # Prioritise parts that contain room keywords
            if any(rw in pl for rw in _room_kw):
                return p.strip()
        # Fallback: first non-skipped part
        for p in parts:
            pl = p.lower().strip()
            if len(pl) < 3 or len(pl) > 50:
                continue
            if not any(s in pl for s in _skip):
                return p.strip()
        return None

    # --- CDP call ---
    detected = []
    try:
        _req = _urllib_req.Request(f"http://127.0.0.1:{_CDP_PORT}/json/list")
        with _urllib_req.urlopen(_req, timeout=2) as _resp:
            tabs = _json.loads(_resp.read().decode())
    except Exception:
        # Brave not available -- fallback to saved config
        if config_otas:
            return [{"name": o.get("name", ""), "url": o.get("url", ""),
                     "domain": "", "title": "",
                     "source": "config"}
                    for o in config_otas if (o.get("name", "") or "").strip()]
        return []

    ota_counts = {}   # brand -> total count (for multi-tab differentiation)
    ota_idx = {}      # brand -> current index

    for tab in tabs:
        if tab.get("type") != "page":
            continue
        url = tab.get("url", "")
        title = tab.get("title", "")
        if not url or url.startswith("chrome://") or url.startswith("about:"):
            continue

        # Skip generalist sites
        url_lower = url.lower()
        if any(g in url_lower for g in _GENERALIST_PATTERNS):
            continue

        ota_name = _ota_name_for_url(url)
        if not ota_name:
            continue

        ota_counts[ota_name] = ota_counts.get(ota_name, 0) + 1
        ota_idx[ota_name] = ota_idx.get(ota_name, 0) + 1

        display = ota_name
        if ota_counts[ota_name] > 1:
            room = _room_from_title(title)
            display = f"{ota_name} ({room})" if room else f"{ota_name} #{ota_idx[ota_name]}"

        detected.append({
            "name": display,
            "url": url,
            "domain": _main_domain(url),
            "title": title,
            "source": "brave",
        })

    # If Brave was reachable but NO OTA tabs were found, return empty —
    # the user may have closed all OTA tabs and they should disappear
    # from the UI.  Only the CDP-connection-failure fallback (above)
    # returns config entries, when Brave itself is not running.
    return detected


def _merge_detected_with_config(detected, config_otas, target_prices):
    """Merge auto-detected OTAs with existing config to preserve names & prices.

    For each detected tab, tries to find a matching config entry (same
    domain → reuse its name so that ``target_prices`` keys stay valid).

    Args:
        detected: list from :func:`_detect_otas_from_brave`
        config_otas: ``config["ota_watch"]["otas"]``
        target_prices: ``config["ota_watch"]["target_prices"]`` (unused
            directly, but callers usually have it on hand)

    Returns:
        list[dict]: merged entries with ``active`` flag set from config.
    """
    from urllib.parse import urlparse as _up

    _MULTI_TLD = {"co.uk", "co.jp", "co.kr", "com.br", "com.au",
                  "com.sg", "com.hk", "com.tw", "com.my", "com.ph",
                  "com.vn", "co.in", "co.id", "co.th", "co.nz",
                  "com.mx", "com.ar", "com.co", "co.za"}

    def _reg_domain(url):
        """Registrable domain (handles multi-part TLDs)."""
        try:
            h = (_up(url).hostname or "").lower().replace("www.", "")
            parts = h.split(".")
            if len(parts) <= 2:
                return h
            last_two = ".".join(parts[-2:])
            if last_two in _MULTI_TLD and len(parts) >= 3:
                return ".".join(parts[-3:])
            return last_two
        except Exception:
            return ""

    def _url_key(url):
        """Stable identity of a page: host + path, no query, no fragment.

        Tab URLs carry volatile query strings (?s=…, unique_share_id=…,
        checkin dates…) that change on every navigation. Only the host+path
        identifies WHICH listing/property page the tab shows."""
        try:
            p = _up((url or "").strip())
            host = (p.netloc or "").lower()
            if host.startswith("www."):
                host = host[4:]
            return f"{host}{p.path or '/'}"
        except Exception:
            return ""

    # Index config entries by URL key and by domain.
    # THE ASSOCIATION TAB↔PROFILE IS MADE BY URL — never by tab order.
    # The old round-robin ("next available entry for this domain")
    # reassigned Airbnb listing profiles to whichever tab came first after
    # a browser restart / tab reorder; the (name, tab-url) pairs were then
    # persisted to config by _ota_watch_save, silently rotating the
    # profiles' URLs — the root cause of every "room inversion" report
    # (2026-08-16: config URLs rotated between two scans the same day).
    cfg_by_url = {}
    cfg_by_domain = {}
    for o in config_otas:
        name = (o.get("name", "") or "").strip()
        url = (o.get("url", "") or "").strip()
        if not name:
            continue
        k = _url_key(url)
        if k:
            cfg_by_url.setdefault(k, o)
        main = _reg_domain(url)
        if main:
            cfg_by_domain.setdefault(main, []).append(o)

    used = set()   # id() of config entries already claimed by a tab
    result = []

    for d in detected:
        url = d.get("url", "")
        main = _reg_domain(url)

        # 1) Exact page match: the tab shows the very page this profile
        #    was created for (Airbnb: same /rooms/<listing id>).
        matched = cfg_by_url.get(_url_key(url))
        if matched is not None and id(matched) in used:
            matched = None

        # 2) Domain with exactly ONE profile (Agoda, Expedia…): the tab is
        #    on the same site, maybe a different query (dates). Claim it.
        if matched is None:
            cands = [o for o in cfg_by_domain.get(main, [])
                     if id(o) not in used]
            if len(cands) == 1:
                matched = cands[0]

        # 3) Multi-profile domain without URL match: NO association. The
        #    round-robin guess here is what rotated the profiles for
        #    weeks — an unmatched tab stays anonymous instead.

        if matched:
            d["name"] = matched["name"]
            d["active"] = matched.get("active", True)
            d["auto_name"] = False
            used.add(id(matched))
        else:
            # D84 : même marque, AUTRE domaine (ex. onglet ouvert sur
            # makemytrip.com alors que le profil est makemytrip.global) :
            # l'association par URL échoue et la ligne devenait
            # « anonyme » avec Active=True par défaut — la
            # désactivation ne s'écrivait JAMAIS dans le profil (constat
            # 22/09). Association par NOM EXACT quand elle est non
            # ambiguë (un seul profil de ce nom, non déjà apparié).
            _tab_name = (d.get("name") or "").strip().lower()
            if _tab_name:
                _by_name = [o for o in config_otas
                            if (o.get("name", "") or "").strip().lower()
                            == _tab_name and id(o) not in used]
                if len(_by_name) == 1:
                    matched = _by_name[0]
                    d["name"] = matched["name"]
                    d["active"] = matched.get("active", True)
                    d["auto_name"] = False
                    used.add(id(matched))
        if matched is None:
            d["active"] = True
            d["auto_name"] = True   # display-only row, never saved as a profile

        result.append(d)

    return result


class Tab(BaseTab):
    def build(self, app, frame):
        self.app = app
        tab = frame
        self._csym = _currency_symbol(app.config)
        # Enregistrer la fonction de scan pour la boucle automatique
        self.app._ota_watch_scan_fn = self._vae_scan
        # Enregistrer la fonction de correction pour les ordres venus du mobile
        # (app_core._on_mobile_command l'appelle via getattr, même pattern).
        self.app._ota_watch_correct_fn = self._ota_watch_correct
        topbar10 = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar10.pack(fill="x")
        lbl(topbar10, tr_("🚫 Blocage prix OTA"), bold=True, size=11).pack(side="left")
        btn(topbar10, tr_("📧 Rapport bug"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar10, tr_("🖥️ Support à distance"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        btn(topbar10, tr_("📖 Wiki"), lambda: self._show_wiki("🚫 Blocage prix OTA"), color="#89b4fa", width=10).pack(side="right")
        btn(topbar10, tr_("💾 Save"), self._ota_watch_save, color=T.ACCENT, width=10).pack(side="right", padx=(4, 0))

        # Bannière MODE TEST (audit G8-1, option A). Le wizard fait démarrer un
        # nouvel utilisateur en test_mode (aucun envoi réel au Channel Manager) ;
        # sans rappel visible, il croit ses prix en ligne alors que tout est
        # simulé. Cette bannière reste affichée tant que test_mode est actif.
        self._test_mode_banner = tk.Label(
            tab, bg="#f38ba8", fg="#1e1e2e", font=("Segoe UI", 9, "bold"),
            anchor="w", padx=12, pady=5)
        self._refresh_test_mode_banner()

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        self._ota_watch_container = tk.Frame(inner, bg=T.BG)
        self._ota_watch_container.pack(fill="x")
        try:
            self._build_ota_watch_section(self._ota_watch_container)
        except Exception:
            import traceback as _tb
            tk.Label(self._ota_watch_container,
                     text=tr_("Erreur construction section OTA Watch:\n{e}").format(
                         e=_tb.format_exc()),
                     bg=T.BG, fg=T.RED, font=("Courier New", 8),
                     justify="left").pack(padx=10, pady=10)

        self._build_cm_history_section(inner)

        tk.Frame(inner, bg=T.SEL_BG, height=2).pack(fill="x", padx=10, pady=(16, 10))

        self._build_price_floor_section(inner)

        self._cm_ota_container = tk.Frame(inner, bg=T.BG)
        self._cm_ota_container.pack(fill="x")
        try:
            self._build_cm_ota_section(self._cm_ota_container)
        except Exception:
            import traceback as _tb
            tk.Label(self._cm_ota_container,
                     text=tr_("Erreur construction section CM-OTA:\n{e}").format(
                         e=_tb.format_exc()),
                     bg=T.BG, fg=T.RED, font=("Courier New", 8),
                     justify="left").pack(padx=10, pady=10)

        # NOTE: Brave tab re-detection is no longer on a fixed 30 s timer —
        # that timer rebuilt the whole section and made the window blink every
        # 30 s. It now runs once at the end of each scan (see _vae_scan_done).
        # Start CM OTA scheduled-push checker (every 60 s)
        self.app.root.after(60_000, self._cm_ota_scheduled_push_loop)

    def _refresh_test_mode_banner(self):
        """Affiche/masque la bannière MODE TEST selon channel_manager.test_mode.
        Appelée au build et à chaque affichage de l'onglet (le réglage peut être
        changé depuis le wizard ou le Channel Manager sans redémarrage)."""
        lbl_w = getattr(self, "_test_mode_banner", None)
        if lbl_w is None or not lbl_w.winfo_exists():
            return
        test_on = bool(self.app.config.get("channel_manager", {}).get("test_mode", False))
        if test_on:
            lbl_w.config(text=tr_(
                "🧪 MODE TEST ACTIF — aucun prix n'est envoyé au Channel Manager. "
                "Les envois sont simulés. Passe en « Mode RÉEL » (Assistant → "
                "Channel Manager, ou Configuration → Channel Manager) pour appliquer "
                "réellement tes prix."))
            lbl_w.pack(fill="x", after=lbl_w.master.winfo_children()[0])
        else:
            lbl_w.pack_forget()

    # ─── BARRE D'EFFICACITÉ ──────────────────────────────────────────────────

    def refresh_on_show(self):
        """Onglet construit une seule fois au démarrage — re-synchronise les
        sections dépendant de room_types (ajout/suppression dans Mon Hôtel)
        à chaque fois que cet onglet redevient visible, sans redémarrage."""
        import logging
        try:
            self._refresh_test_mode_banner()
        except Exception:
            logging.exception("refresh_on_show (tab_blocage_ota): échec bannière mode test")
        for attr, builder in (
            ("_ota_watch_container", self._build_ota_watch_section),
            ("_cm_ota_container",    self._build_cm_ota_section),
        ):
            container = getattr(self, attr, None)
            if container is None or not container.winfo_exists():
                continue
            # Scan en cours : ne pas reconstruire cette section, ça
            # écraserait la barre de progression / le statut en cours
            # (repartirait à 0 jusqu'au prochain tic du scan).
            if attr == "_ota_watch_container" and getattr(self, "_ota_watch_scanning", False):
                continue
            try:
                for w in container.winfo_children():
                    w.destroy()
                builder(container)
            except Exception:
                logging.exception("refresh_on_show (tab_blocage_ota): échec reconstruction %s", attr)
        try:
            self._floor_refresh_trees()
        except Exception:
            logging.exception("refresh_on_show (tab_blocage_ota): échec _floor_refresh_trees")

    # ─── SURVEILLANCE MON HÔTEL SUR OTA ──────────────────────────────────────

    def _ota_watch_refresh_brave(self):
        """Re-detect Brave tabs and rebuild the OTA Watch section + CM OTA
        section in place, without requiring the user to leave the tab."""
        if getattr(self, "_ota_watch_scanning", False):
            return
        # Save current active toggles before rebuild so the user's
        # checkbox choices are not lost on auto-refresh.
        try:
            self._ota_watch_save()
        except Exception:
            pass
        container = getattr(self, "_ota_watch_container", None)
        if container and container.winfo_exists():
            for w in container.winfo_children():
                w.destroy()
            self._build_ota_watch_section(container)
        cm_container = getattr(self, "_cm_ota_container", None)
        if cm_container and cm_container.winfo_exists():
            for w in cm_container.winfo_children():
                w.destroy()
            self._build_cm_ota_section(cm_container)
        # Save the NEW state immediately so config stays in sync —
        # otherwise the next auto-refresh cycle sees a stale config
        # and triggers a redundant rebuild.
        try:
            self._ota_watch_save()
        except Exception:
            pass

    def _ota_watch_detect_tabs(self):
        """Re-detect Brave tabs and rebuild the OTA Watch section IF the set
        of detected OTA names has changed.

        Formerly a fixed 15/30 s timer (`_ota_watch_auto_refresh_loop`), which
        rebuilt the whole section and made the window blink every 30 s. It is
        now called once at the end of each scan (see `_vae_scan_done`), so the
        re-detection only happens when it is useful and never blinks the UI on
        a fixed schedule. Only rebuilds when this tab is visible, no scan is
        running, AND the detected OTA name set has actually changed.
        """
        try:
            _should_refresh = False
            try:
                _container = getattr(self, "_ota_watch_container", None)
                _visible = (
                    _container and _container.winfo_exists()
                    and bool(_container.winfo_ismapped()))
                if _visible and not getattr(self, "_ota_watch_scanning", False):
                    # Compare detected OTA NAMES only (not URLs — URLs change
                    # on every page navigation and would cause endless rebuilds).
                    _cfg_otas = self.app.config.get("ota_watch", {}).get("otas", [])
                    _current_names = {o.get("name", "")
                                      for o in _cfg_otas if o.get("name")}
                    _detected = _detect_otas_from_brave(_cfg_otas or None)
                    _new_names = {d["name"] for d in _detected}
                    if _current_names != _new_names:
                        _should_refresh = True
            except Exception:
                pass
            if _should_refresh:
                self._ota_watch_refresh_brave()
        except Exception:
            pass

    def _cm_ota_scheduled_push_loop(self):
        """Check every 60 s if a CM OTA with trigger='daily_once' is due.
        When the configured time is reached (and the OTA was not already
        pushed today), fires _send_cm_ota_prices automatically."""
        _CHECK_MS = 60_000
        try:
            from datetime import datetime as _dt
            _now   = _dt.now()
            _today = _now.strftime("%Y-%m-%d")
            _cur_hm = _now.strftime("%H:%M")

            cm_ota_cfg = self.app.config.get("cm_ota_prices", {})
            _triggered = False
            for ota_name, ota_data in cm_ota_cfg.items():
                if not isinstance(ota_data, dict):
                    continue
                if ota_data.get("trigger") != "daily_once":
                    continue
                if not ota_data.get("enabled", False):
                    continue
                # Already pushed today?
                if ota_data.get("last_auto_push_date") == _today:
                    continue
                _push_time = (ota_data.get("time") or "12:00").strip()[:5]
                if _cur_hm < _push_time:
                    continue

                # Time reached — fire the push via the UI variables
                _ota_ui = getattr(self, "_cm_ota_vars", {}).get(ota_name, {})
                _rooms  = _ota_ui.get("rooms", {})
                _lbl    = _ota_ui.get("result_lbl")
                _code   = ota_data.get("ota_code", "")
                if _rooms and _lbl and _lbl.winfo_exists():
                    # Mark as pushed BEFORE the call to prevent re-entry
                    ota_data["last_auto_push_date"] = _today
                    _triggered = True
                    self.app.root.after(0, lambda _on=ota_name, _oc=_code,
                                        _rv=_rooms, _rl=_lbl:
                                        self._send_cm_ota_prices(_on, _oc, _rv, _rl))
                    try:
                        from business.app_logger import app_log as _alog
                        _alog(f"[CM-OTA-AUTO] Push auto pour {_on} à {_cur_hm}",
                              level="info", engine="CM-OTA-AUTO")
                    except Exception:
                        pass
            if _triggered:
                try:
                    from core import config as _cfgmod
                    _cfgmod.save(self.app.config)
                except Exception:
                    pass
        except Exception:
            pass
        self.app.root.after(_CHECK_MS, self._cm_ota_scheduled_push_loop)

    def _build_ota_watch_section(self, parent):
        """Section de surveillance du prix de mon hôtel sur les OTAs."""
        try:
            # Clear existing widgets before rebuild (used by +/− callbacks)
            for w in parent.winfo_children():
                w.destroy()

            cfg = self.app.config.get("ota_watch", {})

            s = section(parent, tr_("🎯 Surveillance mon hôtel — Prix réel sur OTA"))
            s.pack(fill="x", padx=10, pady=10)
            _hdr = tk.Frame(s, bg=s.cget("bg")); _hdr.pack(fill="x", pady=(0, 4))
            lbl(_hdr, tr_("Scanne ta fiche sur les OTAs, détecte les écarts de prix et corrige automatiquement via le CM."),
                color=T.YELLOW, size=9).pack(side="left", anchor="w")
            # Refresh button: re-detect Brave tabs without leaving the tab
            tooltip(
                btn(_hdr, tr_("🔄 Actualiser"), self._ota_watch_refresh_brave,
                    color=T.ACCENT, width=14),
                tr_("Re-détecte les onglets Brave ouverts "
                    "(utile après avoir ouvert une nouvelle OTA).")
            ).pack(side="right", padx=(4, 0))

            # ── Auto-detect OTAs from Brave tabs ─────────────────────
            config_otas   = cfg.get("otas", [])
            target_prices = cfg.get("target_prices", {})

            detected = _detect_otas_from_brave(config_otas or None)
            merged   = _merge_detected_with_config(detected, config_otas, target_prices)

            # Sort OTAs by brand so same-OTA listings stay adjacent
            # (e.g. all Airbnb rooms grouped together, not interleaved
            # with Agoda / Goibibo / Expedia).
            merged.sort(
                key=lambda d: (_ota_brand_key(d.get("name", "")),
                               d.get("name", "").lower()))

            # Store for "+" / "−" operations
            self._ota_watch_detected_list = list(merged)

            # ── OTA list UI ─────────────────────────────────────────
            ota_list_frame = tk.Frame(s, bg=T.BG)
            ota_list_frame.pack(fill="x", pady=(0, 4))

            self._ota_watch_ota_vars = []

            if merged:
                # Compact header
                hdr = tk.Frame(ota_list_frame, bg=T.BG)
                hdr.pack(fill="x", pady=(0, 2))
                lbl(hdr, tr_("OTA détectée depuis Brave"), bold=True, color=T.ACCENT,
                    size=9).pack(side="left", padx=(4, 8))
                lbl(hdr, tr_("Active"), bold=True, color=T.ACCENT,
                    size=9).pack(side="right", padx=(0, 20))

                for d in merged:
                    bg_row = T.ENTRY_BG if len(self._ota_watch_ota_vars) % 2 == 0 else T.BG
                    row = tk.Frame(ota_list_frame, bg=bg_row, padx=8, pady=4)
                    row.pack(fill="x", pady=(0, 1))

                    src = d.get("source", "brave")
                    icon = "🟢" if src == "brave" else "➕"
                    lbl(row, f"{icon} {d['name']}", color=T.FG, size=9).pack(
                        side="left", padx=(0, 6))

                    # Short URL hint
                    _url_s = (d.get("url") or "")[:55]
                    if _url_s:
                        lbl(row, _url_s + ("…" if len(d.get("url") or "") > 55 else ""),
                            color="#888888", size=7).pack(side="left", padx=(0, 6))

                    # Active toggle
                    active_v = tk.BooleanVar(value=d.get("active", True))
                    tk.Checkbutton(row, text=tr_("Active"), variable=active_v,
                                   bg=bg_row, fg=T.FG, selectcolor=T.BG,
                                   activebackground=bg_row,
                                   font=("Segoe UI", 8)).pack(side="right", padx=(0, 4))

                    self._ota_watch_ota_vars.append({
                        "name": d["name"],
                        "url": d.get("url", ""),
                        "active": active_v,
                        "source": src,
                    })
            else:
                lbl(ota_list_frame,
                    tr_("❌ Aucun onglet OTA détecté dans Brave. "
                        "Ouvre les pages de ton hôtel sur les OTAs dans Brave, "
                        "puis reviens ici."),
                    color=T.RED, size=9).pack(anchor="w", padx=8)

            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=8)

            # ── Target prices grid (dynamic columns by OTA name) ─────
            # Merge Goibibo + MakeMyTrip into one column (same inventory,
            # one CM price).  Other OTAs keep their own column.
            _raw_otas = [d for d in self._ota_watch_ota_vars if d.get("name")]
            _seen_groups: set[str] = set()
            active_otas: list[dict] = []
            for _d in _raw_otas:
                _gk = _ota_group_key(_d["name"])
                if _gk != _d["name"] and _gk in _seen_groups:
                    continue  # duplicate in a merged group — skip
                _seen_groups.add(_gk)
                if _gk != _d["name"]:
                    _merged = dict(_d)
                    _merged["name"] = _gk
                    active_otas.append(_merged)
                else:
                    active_otas.append(_d)

            lbl(s, tr_("Prix cibles par chambre — prix que tu veux que le client voie sur l'OTA"),
                bold=True).pack(anchor="w", pady=(4, 2))
            lbl(s, tr_("Le prix envoyé au Channel Manager n'est pas le prix cible : le "
                       "logiciel mesure ce que l'OTA fait de chaque envoi (envoyé → "
                       "affiché), puis s'ajuste par étapes vers la cible. Tant qu'aucune "
                       "mesure n'existe, la cible est envoyée telle quelle. Le calcul de "
                       "chaque envoi est détaillé dans le journal (lignes 🧮)."),
                color="#888888", size=8, wraplength=760, justify="left").pack(
                    anchor="w", padx=8, pady=(0, 4))
            lbl(s, tr_("ℹ️  Les OTAs affichent des prix variables selon l'appareil et le profil du visiteur. "
                   "Une légère différence entre le prix cible et le prix réellement affiché est normale "
                   "et inhérente aux algorithmes OTA."),
                color="#666666", size=7).pack(anchor="w", padx=8, pady=(0, 6))

            _tg_outer = tk.Frame(s, bg=T.BG); _tg_outer.pack(fill="x", pady=4)
            _tg_canvas = tk.Canvas(_tg_outer, bg=T.BG, highlightthickness=0, height=1)
            _tg_hsb = tk.Scrollbar(_tg_outer, orient="horizontal", command=_tg_canvas.xview)
            _tg_canvas.configure(xscrollcommand=_tg_hsb.set)
            _tg_hsb.pack(side="bottom", fill="x")
            _tg_canvas.pack(side="top", fill="x", expand=True)
            tg = tk.Frame(_tg_canvas, bg=T.BG)
            _tg_win = _tg_canvas.create_window((0, 0), window=tg, anchor="nw")

            def _tg_on_configure(_e=None):
                _tg_canvas.configure(scrollregion=_tg_canvas.bbox("all"))
                _tg_canvas.itemconfig(_tg_win, height=tg.winfo_reqheight())
                _tg_canvas.configure(height=tg.winfo_reqheight())
            tg.bind("<Configure>", _tg_on_configure)

            # Column headers — OTA names directly (not "OTA 1..10").
            # Widths ADAPT to the real content: the room column fits the
            # longest category name (fully readable — the space at the
            # right of the grid was unused), OTA headers fit their name up
            # to a cap so a long listing name doesn't blow up the grid.
            import tkinter.font as _tgfont
            _tgf = _tgfont.Font(family="Segoe UI", size=9)
            _room_types_pre = [rt if isinstance(rt, str) else rt.get("type", "")
                               for rt in self.app.config.get("room_types", [])]
            _room_types_pre = [r for r in _room_types_pre if r]
            _room_col_w = max(26, max((_tgf.measure(r) for r in _room_types_pre),
                                      default=0) // 7 + 3)

            headers = ["Chambre"] + [f"{a['name']} {self._csym}" for a in active_otas]
            for col, txt in enumerate(headers):
                # Use per-OTA colour for OTA columns, default accent for "Chambre"
                if col == 0:
                    fg = T.ACCENT
                    w = _room_col_w
                else:
                    fg = _get_ota_color(active_otas[col - 1]["name"])
                    w = max(16, min(26, _tgf.measure(txt) // 7 + 2))
                tk.Label(tg, text=txt, bg=T.BG, fg=fg,
                         font=("Segoe UI", 9, "bold"),
                         width=w, anchor="w").grid(
                             row=0, column=col, padx=4, pady=2)

            self._ota_watch_target_vars = {}
            room_types = _room_types_pre

            for ri, room in enumerate(room_types):
                rt_data = target_prices.get(room, {})
                bg_r = T.ENTRY_BG if ri % 2 == 0 else T.BG
                tk.Label(tg, text=room, bg=bg_r, fg=T.FG, font=("Segoe UI", 9),
                         width=_room_col_w, anchor="w").grid(row=ri+1, column=0, padx=4, pady=2)
                self._ota_watch_target_vars[room] = {}
                for oi, a in enumerate(active_otas):
                    ota_name = a["name"]
                    # Load target: try exact key first, then group aliases
                    # (e.g. "MakeMyTrip / Goibibo" falls back to "MakeMyTrip"
                    # or "Goibibo" from a previous config that didn't merge).
                    val = rt_data.get(ota_name, "")
                    if not val:
                        for _alias in ("MakeMyTrip", "Goibibo"):
                            if _alias != ota_name:
                                val = rt_data.get(_alias, "")
                                if val:
                                    break
                    v = tk.StringVar(value=str(int(val)) if val else "")
                    tk.Entry(tg, textvariable=v, width=10, bg=T.ENTRY_BG, fg=T.FG,
                             relief="flat", highlightthickness=1, highlightbackground=T.SEL_BG,
                             font=("Segoe UI", 10)).grid(row=ri+1, column=oi+1, padx=4, pady=2)
                    self._ota_watch_target_vars[room][ota_name] = v
            _tg_on_configure()

            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=8)

            # ── Surveillance auto ──
            surv = tk.Frame(s, bg=T.BG); surv.pack(fill="x", pady=4)
            self._ota_watch_auto_v = tk.BooleanVar(value=cfg.get("auto_correct", False))
            tk.Checkbutton(surv, text=tr_("Correction automatique"),
                           variable=self._ota_watch_auto_v,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(surv, tr_("Intervalle :"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_interval_v = tk.StringVar(value=str(cfg.get("interval_h", 4)))
            tk.Spinbox(surv, textvariable=self._ota_watch_interval_v,
                       from_=0, to=24, increment=1, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 3))
            lbl(surv, "h", bold=False).pack(side="left", padx=(0, 6))
            self._ota_watch_interval_m_v = tk.StringVar(value=str(cfg.get("interval_m", 0)))
            tk.Spinbox(surv, textvariable=self._ota_watch_interval_m_v,
                       from_=0, to=59, increment=5, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 3))
            lbl(surv, tr_("min"), bold=False).pack(side="left", padx=(0, 16))
            lbl(surv, tr_("Corriger si écart ≥ {c} :").format(c=self._csym),
                bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_min_gap_v = tk.StringVar(value=str(cfg.get("min_gap", 50)))
            tk.Spinbox(surv, textvariable=self._ota_watch_min_gap_v,
                       from_=0, to=2000, increment=50, width=6,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left")

            # ── Date du scan (offset check-in) ──
            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=(6, 4))
            date_row = tk.Frame(s, bg=T.BG); date_row.pack(fill="x", pady=2)
            lbl(date_row, tr_("📅 Observer les prix pour un séjour dans :"), bold=True).pack(side="left", padx=(0, 8))
            self._ota_watch_date_offset_v = tk.IntVar(value=int(cfg.get("date_offset", 1)))
            for _days, _label in [(0, "J+0"), (1, "J+1 ✦"), (3, "J+3"), (7, "J+7"), (10, "J+10"), (15, "J+15")]:
                tk.Radiobutton(date_row, text=_label,
                               variable=self._ota_watch_date_offset_v, value=_days,
                               bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.BG, font=("Segoe UI", 9),
                               cursor="hand2").pack(side="left", padx=(0, 6))
            lbl(date_row,
                tr_("Si une chambre est introuvable à cette date, le scan continue automatiquement sur d'autres dates jusqu'à trouver tous les prix"),
                color="#888888", size=8).pack(side="left", padx=(10, 0))

            # ── Date d'envoi de la correction au CM (offset libre, pas de valeurs imposées) ──
            correct_date_row = tk.Frame(s, bg=T.BG); correct_date_row.pack(fill="x", pady=2)
            lbl(correct_date_row, tr_("📅 Appliquer les nouveaux prix à partir de : J+"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_correct_offset_v = tk.StringVar(
                value=str(int(cfg.get("correct_date_offset", 0))))
            tk.Spinbox(correct_date_row, textvariable=self._ota_watch_correct_offset_v,
                       from_=0, to=365, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
            lbl(correct_date_row, tr_("pendant :"), bold=True).pack(side="left", padx=(4, 4))
            self._ota_watch_correct_days_v = tk.StringVar(
                value=str(int(cfg.get("correct_duration_days", 90))))
            tk.Spinbox(correct_date_row, textvariable=self._ota_watch_correct_days_v,
                       from_=1, to=365, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
            lbl(correct_date_row, tr_("jour(s)"), bold=True).pack(side="left", padx=(0, 6))
            lbl(correct_date_row, tr_("(ex. : à partir de J+0 = aujourd'hui, pendant 90 jours)"),
                color="#888888", size=8).pack(side="left")

            # ── Majoration weekend (vendredi/samedi) ──
            wknd_row = tk.Frame(s, bg=T.BG); wknd_row.pack(fill="x", pady=2)
            self._ota_watch_wknd_v = tk.BooleanVar(
                value=cfg.get("weekend_markup_enabled", True))
            tk.Checkbutton(wknd_row, text=tr_("🗓️ Majoration :"),
                           variable=self._ota_watch_wknd_v,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
            _DAY_FR_G = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
            _saved_days_g = cfg.get("weekend_days", [4, 5])
            self._ota_watch_wknd_days_v = []
            for _di, _dl in enumerate(_DAY_FR_G):
                _ddv = tk.BooleanVar(value=_di in _saved_days_g)
                tk.Checkbutton(wknd_row, text=_dl, variable=_ddv,
                               bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.BG,
                               font=("Segoe UI", 9)).pack(side="left", padx=(1, 0))
                self._ota_watch_wknd_days_v.append(_ddv)
            lbl(wknd_row, "  +", bold=True).pack(side="left", padx=(6, 2))
            self._ota_watch_wknd_pct_v = tk.StringVar(
                value=str(cfg.get("weekend_markup_pct", 20)))
            tk.Spinbox(wknd_row, textvariable=self._ota_watch_wknd_pct_v,
                       from_=0, to=100, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 2))
            lbl(wknd_row, "%").pack(side="left")

            # ── Calibration itérative ──
            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=(8, 4))
            calib_row = tk.Frame(s, bg=T.BG); calib_row.pack(fill="x", pady=2)
            self._ota_calib_auto_v = tk.BooleanVar(value=cfg.get("calib_auto", False))
            tk.Checkbutton(calib_row, text=tr_("🔄 Calibration auto si plancher violé"),
                           variable=self._ota_calib_auto_v,
                           bg=T.BG, fg=T.ACCENT, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(calib_row, tr_("Délai entre vérifs (min, ≥5) :"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_calib_wait_v = tk.StringVar(value=str(cfg.get("calib_wait_min", 5)))
            tk.Spinbox(calib_row, textvariable=self._ota_calib_wait_v,
                       from_=5, to=120, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(calib_row, tr_("Max tentatives :"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_calib_max_v = tk.StringVar(value=str(cfg.get("calib_max_retries", 5)))
            tk.Spinbox(calib_row, textvariable=self._ota_calib_max_v,
                       from_=1, to=10, increment=1, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left")
            lbl(s, tr_("ℹ Après chaque scan auto, si l'OTA est sous le plancher stratégie → le logiciel envoie un prix plus haut au CM, attend le délai défini, re-scanne et ajuste jusqu'à ce que l'OTA soit ≥ plancher (max N tentatives, +{c}150 par essai).").format(c=self._csym),
                color="#888888", size=8).pack(anchor="w", padx=8, pady=(0, 6))

            # ── Boutons ──
            br = tk.Frame(s, bg=T.BG); br.pack(fill="x", pady=(10, 4))
            btn(br, tr_("🚀 Push & Corriger"),      lambda: self._ota_watch_correct(),
                color="#f38ba8", width=22).pack(side="left", padx=(0, 8))
            self._ota_watch_scan_btn = btn(br, tr_("🔍 Scanner maintenant"),
                self._vae_scan,
                color=T.ORANGE, width=20)
            self._ota_watch_scan_btn.pack(side="left")
            # D53 : arret immediat (cooperatif) du scan en cours
            self._ota_watch_stop_btn = btn(br, tr_("⏹ Stop"),
                                           self._ota_watch_stop_operation,
                                           color=T.RED, width=8)
            self._ota_watch_stop_btn.pack(side="left", padx=(6, 0))
            self._ota_watch_stop_btn.config(state="disabled")
            # D98 : pause globale — le propriétaire travaille, l'outil
            # ne doit plus voler la fenêtre Brave ni rien démarrer.
            self._ota_watch_pause_btn = btn(br, tr_("⏸ Tout mettre en pause"),
                                            self._ota_watch_toggle_pause,
                                            color=T.ACCENT, width=22)
            self._ota_watch_pause_btn.pack(side="left", padx=(6, 0))
            tooltip(self._ota_watch_pause_btn,
                    tr_("Suspend TOUT (scans, envois, rechargements, "
                        "remontées de fenêtre) jusqu'à reprise — "
                        "la tâche en cours se termine proprement."))

            self._ota_watch_status = tk.Label(s, text="", bg=T.BG, fg=T.YELLOW,
                                              font=("Segoe UI", 9, "italic"))
            self._ota_watch_status.pack(anchor="w", pady=(2, 2))
            self._ota_watch_prog = ttk.Progressbar(s, mode="determinate",
                                                    length=280, maximum=100)
            self._ota_watch_prog.pack(anchor="w", pady=(0, 6))
            # D52 : progression des ENVOIS vers le CM (même emplacement)
            self._push_prog = ttk.Progressbar(s, mode="determinate",
                                              length=280, maximum=100)
            self._push_prog.pack(anchor="w", pady=(0, 2))
            self._push_prog_lbl = tk.Label(s, text="", bg=T.BG, fg=T.ACCENT,
                                           font=("Segoe UI", 8, "italic"))
            self._push_prog_lbl.pack(anchor="w", pady=(0, 6))
            # accessibles depuis app_core (pattern _cm_history_text)
            self.app._push_prog = self._push_prog
            self.app._push_prog_lbl = self._push_prog_lbl
            self.app._ota_watch_stop_btn = self._ota_watch_stop_btn
            self.app._ota_watch_pause_btn = self._ota_watch_pause_btn

            # ── Tableau résultats ──
            lbl(s, tr_("Résultats du dernier scan :"), bold=True, color=T.ACCENT).pack(anchor="w", pady=(4, 2))
            lbl(s, tr_("Double-clic sur une ligne → corriger cette chambre seulement."),
                color="#888888", size=8).pack(anchor="w", padx=8, pady=(0, 4))

            rf = tk.Frame(s, bg=T.BG); rf.pack(fill="x")
            # Inner frame for the tree + vertical scrollbar (sits above the
            # horizontal scrollbar) so both can coexist cleanly.
            tw = tk.Frame(rf, bg=T.BG); tw.pack(side="top", fill="both", expand=True)
            vsb_w = ttk.Scrollbar(tw, orient="vertical"); vsb_w.pack(side="right", fill="y")
            wcols = ("ota", "room", "target", "detected", "gap", "to_send", "status")
            self._ota_watch_tree = ttk.Treeview(tw, columns=wcols, show="headings",
                                                 height=8, selectmode="browse",
                                                 yscrollcommand=vsb_w.set)
            vsb_w.config(command=self._ota_watch_tree.yview)
            # Horizontal scrollbar — keeps every column reachable on narrow
            # windows without ever hiding OTA / Chambre (they stay first).
            hsb_w = ttk.Scrollbar(rf, orient="horizontal",
                                  command=self._ota_watch_tree.xview)
            hsb_w.pack(side="bottom", fill="x")
            self._ota_watch_tree.config(xscrollcommand=hsb_w.set)
            for cid, txt, w, anc, can_stretch in [
                ("ota",      "OTA",            110, "w",     False),
                ("room",     "Chambre",         150, "w",     False),
                ("target",   "Prix cible",       88, "center", True),
                ("detected", "Prix détecté",     88, "center", True),
                ("gap",      "Écart",           140, "center", True),
                ("to_send",  "À envoyer CM",     90, "center", True),
                ("status",   "Statut",           92, "center", True),
            ]:
                self._ota_watch_tree.heading(cid, text=txt)
                self._ota_watch_tree.column(
                    cid, width=w, minwidth=w, anchor=anc, stretch=can_stretch)
            self._ota_watch_tree.pack(side="left", fill="both", expand=True)
            self._ota_watch_tree.tag_configure("ok",   foreground=T.GREEN)
            self._ota_watch_tree.tag_configure("low",  foreground=T.RED)
            self._ota_watch_tree.tag_configure("high", foreground=T.ORANGE)
            self._ota_watch_tree.tag_configure("none", foreground="#888888")
            self._ota_watch_sort_reset = attach_sort(self._ota_watch_tree)

            def _on_row_dbl(event):
                try:
                    item = self._ota_watch_tree.focus()
                    vals = self._ota_watch_tree.item(item, "values")
                    if vals and len(vals) >= 2:
                        self._ota_watch_correct(room=vals[1], ota_name=vals[0])
                except Exception:
                    pass
            self._ota_watch_tree.bind("<Double-Button-1>", _on_row_dbl)

            # Barre de synthèse affichée sous le tableau (maj après chaque scan)
            self._ota_watch_summary = tk.Label(
                s, text="", bg=T.BG, fg=T.FG, anchor="w",
                font=("Segoe UI", 8, "bold"))
            self._ota_watch_summary.pack(anchor="w", pady=(4, 0))

            # Charger derniers résultats — filtrer les OTAs qui ne sont
            # plus surveillées (ex. onglet Brave fermé / OTA retirée).
            try:
                last = dict(cfg.get("last_results", {}))
                if last:
                    _active_names = {d["name"] for d in merged
                                     if d.get("active", True)}
                    _stale = [k for k in last if k not in _active_names]
                    if _stale:
                        for k in _stale:
                            del last[k]
                        # Persist the cleaned version so stale OTAs don't
                        # come back on the next rebuild.
                        cfg["last_results"] = last
                        self.app.config["ota_watch"] = cfg
                    if last:
                        self._ota_watch_fill_tree(last)
                    elif hasattr(self, "_ota_watch_tree"):
                        self._ota_watch_tree.delete(
                            *self._ota_watch_tree.get_children())
                    ts = cfg.get("last_scan_time", "")
                    if ts and hasattr(self, "_ota_watch_status"):
                        self._ota_watch_status.config(
                            text=tr_("Dernier scan : {ts}").format(ts=fmt_dt(ts)), fg="#888888")
            except Exception:
                pass

        except Exception:
            pass

    def _ota_watch_save(self):
        """Save OTA watch config to config.

        The new data structure uses plain strings for name/url (auto-detected
        or manually added) and BooleanVar only for the active toggle.  Target
        prices are keyed by OTA name (not slot index).
        """
        try:
            ota_cfg = dict(self.app.config.get("ota_watch", {}))

            # Save OTA list. PERSISTENCE POLICY (bug hunt 2026-08-16):
            # - an existing profile is NEVER deleted implicitly: a closed
            #   tab at scan time must not wipe the config entry;
            # - a matched row updates ONLY its Active flag — the URL the
            #   user entered at creation is the identity of the profile,
            #   the live tab identifies it, it does not redefine it;
            # - unmatched tabs (auto_name) never become profiles: that is
            #   how "Airbnb #2" junk entries were created. A NEW OTA is
            #   added deliberately via the add-dialog with a proper name.
            _ui_rows = {}
            for d in (self._ota_watch_ota_vars or []):
                _n = (d.get("name") or "").strip()
                if _n:
                    _ui_rows[_n] = d
            otas = []
            for o in (ota_cfg.get("otas") or []):
                _n = (o.get("name", "") or "").strip()
                if not _n:
                    continue
                d = _ui_rows.get(_n)
                if d is not None:
                    otas.append({"name": _n,
                                 "url": (o.get("url", "") or "").strip(),
                                 "active": d["active"].get()})
                else:
                    otas.append({"name": _n,
                                 "url": (o.get("url", "") or "").strip(),
                                 "active": o.get("active", True)})
            ota_cfg["otas"] = otas
            # Legacy manual_otas key cleared (feature removed)
            ota_cfg.pop("manual_otas", None)

            # Target prices keyed by OTA name (no duplicate-slot logic needed)
            target_prices = {}
            for room, ota_dict in self._ota_watch_target_vars.items():
                room_t = {}
                for ota_name, v in ota_dict.items():
                    raw = v.get().strip()
                    if raw:
                        try:
                            room_t[ota_name] = float(raw.replace(",", "."))
                        except ValueError:
                            pass
                # Migrate old standalone Goibibo/MakeMyTrip keys into the
                # grouped key so stale per-OTA values don't linger.
                if room_t:
                    _old = {k: v for k, v in room_t.items()
                            if k in ("Goibibo", "MakeMyTrip")}
                    if _old and _MMT_DISPLAY not in room_t:
                        room_t[_MMT_DISPLAY] = list(_old.values())[0]
                    for _k in list(room_t):
                        if _k in ("Goibibo", "MakeMyTrip"):
                            del room_t[_k]
                if room_t:
                    target_prices[room] = room_t
            ota_cfg["target_prices"] = target_prices

            ota_cfg["auto_correct"] = self._ota_watch_auto_v.get()
            try:
                ota_cfg["interval_h"] = int(self._ota_watch_interval_v.get())
            except (ValueError, AttributeError):
                ota_cfg["interval_h"] = 4
            try:
                ota_cfg["interval_m"] = int(self._ota_watch_interval_m_v.get())
            except (ValueError, AttributeError):
                ota_cfg["interval_m"] = 0
            try:
                ota_cfg["min_gap"] = int(self._ota_watch_min_gap_v.get())
            except (ValueError, AttributeError):
                ota_cfg["min_gap"] = 50
            try:
                ota_cfg["calib_auto"] = self._ota_calib_auto_v.get()
            except AttributeError:
                pass
            try:
                ota_cfg["fast_scan"] = self._ota_watch_fast_v.get()
            except AttributeError:
                pass
            try:
                ota_cfg["calib_wait_min"] = max(5, int(self._ota_calib_wait_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["calib_wait_min"] = 5
            try:
                ota_cfg["calib_max_retries"] = max(1, int(self._ota_calib_max_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["calib_max_retries"] = 5
            try:
                ota_cfg["date_offset"] = int(self._ota_watch_date_offset_v.get())
            except (ValueError, AttributeError):
                ota_cfg["date_offset"] = 1
            try:
                ota_cfg["correct_date_offset"] = max(0, int(self._ota_watch_correct_offset_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["correct_date_offset"] = 0
            try:
                ota_cfg["correct_duration_days"] = max(1, min(365, int(
                    self._ota_watch_correct_days_v.get())))
            except (ValueError, AttributeError):
                ota_cfg["correct_duration_days"] = 90
            try:
                ota_cfg["weekend_markup_enabled"] = bool(self._ota_watch_wknd_v.get())
            except AttributeError:
                pass
            try:
                ota_cfg["weekend_markup_pct"] = max(0.0, float(
                    self._ota_watch_wknd_pct_v.get().replace(",", ".")))
            except (ValueError, AttributeError):
                ota_cfg["weekend_markup_pct"] = 20
            try:
                ota_cfg["weekend_days"] = [
                    i for i, v in enumerate(self._ota_watch_wknd_days_v) if v.get()]
            except AttributeError:
                pass

            self.app.config["ota_watch"] = ota_cfg
            cfg.save(self.app.config)
            # D41 : re-synchroniser le moteur VAE IMMÉDIATEMENT (config →
            # hotel.yaml/settings). Jusqu'ici cette synchro n'était faite
            # qu'au démarrage (main.py) : modifier la liste des OTA (cases
            # « Active », ajouts/suppressions) changeait le fichier config
            # mais pas le moteur déjà monté — le changement ne devenait
            # visible dans les résultats de scan qu'après un redémarrage
            # complet de l'app (constat propriétaire 29/08).
            try:
                from vae_bridge import sync_config_from_otaguard
                sync_config_from_otaguard(self.app.config)
            except Exception:
                import logging
                logging.exception("D41 : re-sync moteur VAE après save échouée")
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=tr_("✅ Configuration sauvegardée."), fg=T.GREEN)
        except Exception as e:
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=tr_("❌ Erreur sauvegarde : {e}").format(e=e), fg=T.RED)

    # ─── HISTORIQUE ENVOIS CM ────────────────────────────────────────────────

    def _build_cm_history_section(self, parent):
        from core.widgets import section
        s = section(parent, tr_("📋 Derniers envois au Channel Manager"))
        s.pack(fill="x", padx=10, pady=(10, 4))
        lbl(s, tr_("Trace de chaque push vers le CM — manuel ou automatique."),
            color="#888888", size=9).pack(anchor="w", pady=(0, 4))

        # Scrollable history: newest entries first (insert(0, ...) in
        # app_core) — the scrollbar reveals the older ones below.
        hist_frame = tk.Frame(s, bg=T.BG)
        hist_frame.pack(fill="x", pady=(0, 4))
        self._cm_history_sb = ttk.Scrollbar(hist_frame, orient="vertical")
        self._cm_history_sb.pack(side="right", fill="y")
        self._cm_history_text = tk.Text(
            hist_frame, bg=T.ENTRY_BG, fg=T.FG, font=("Consolas", 9),
            height=8, relief="flat", state="disabled",
            highlightthickness=0,
            yscrollcommand=self._cm_history_sb.set)
        self._cm_history_text.pack(side="left", fill="both", expand=True)
        self._cm_history_sb.config(command=self._cm_history_text.yview)
        self._cm_history_text.tag_config("ok",    foreground=T.GREEN)
        self._cm_history_text.tag_config("err",   foreground=T.RED)
        self._cm_history_text.tag_config("part",  foreground="#e67e22")  # D42 : envoi partiel
        self._cm_history_text.tag_config("muted", foreground="#888888")

        self.app._cm_history_text = self._cm_history_text
        self.app._cm_refresh_history_fn = self._cm_refresh_history

        btn_row = tk.Frame(s, bg=T.BG)
        btn_row.pack(anchor="e", pady=(0, 2))
        btn(btn_row, tr_("🔄 Rafraîchir"), self._cm_refresh_history,
            color=T.SEL_BG, width=12).pack(side="left", padx=(0, 6))
        btn(btn_row, tr_("🗑 Effacer"),
            lambda: (
                self.app.config.get("channel_manager", {}).update({"push_history": []}),
                cfg.save(self.app.config),
                self._cm_refresh_history()
            ), color=T.SEL_BG, width=10).pack(side="left")

        self._cm_refresh_history()

    def _cm_refresh_history(self):
        try:
            if not hasattr(self, "_cm_history_text"):
                return
            hist = self.app.config.get("channel_manager", {}).get("push_history", [])
            self._cm_history_text.config(state="normal")
            self._cm_history_text.delete("1.0", "end")
            if not hist:
                self._cm_history_text.insert("end", "Aucun envoi enregistré.\n", "muted")
            else:
                for e in hist[:30]:
                    ts_s   = fmt_dt(e.get("ts", ""))   # "16/08/2026 12:05"
                    # D42 : TROIS états — tout ok = vert ; au moins un
                    # envoi réellement parti malgré des échecs = ORANGE ;
                    # rien parti = rouge. Les entrées anciennes (sans
                    # champ « sent ») sont déduites de leur message : un
                    # « ✓ »/« ✅ » de détail D40-D42 ou un groupe ✅ devant
                    # signifie qu'au moins un envoi était parti.
                    _sent = e.get("sent")
                    if _sent is None:
                        _m = str(e.get("msg", ""))
                        _sent = 1 if ("✓" in _m or "✅" in _m) else 0
                    if e.get("ok"):
                        icon, tag = "✅", "ok"
                    elif int(_sent or 0) > 0:
                        icon, tag = "🟠", "part"
                    else:
                        icon, tag = "✗ ", "err"
                    source = e.get("source", "?")
                    ota    = e.get("ota", "")
                    label  = f"{source} → {ota}" if ota else source
                    msg_s  = e.get("msg", "")  # D42 : détail complet, plus de coupe
                    # Room and price side by side when the pairs exist
                    # (entries recorded since 2026-08-16); older entries
                    # keep the legacy "rooms → prices" rendering.
                    pairs  = e.get("pairs") or []
                    if pairs:
                        detail = "  ·  ".join(pairs)
                    else:
                        rooms  = e.get("rooms", "?")
                        prices = e.get("prices", "?")
                        detail = f"{rooms} → {prices}"
                    line   = f"{icon} {ts_s}  [{label}]  {detail}"
                    if msg_s:
                        line += f"  — {msg_s}"
                    self._cm_history_text.insert("end", line + "\n", tag)
            self._cm_history_text.config(state="disabled")
        except Exception:
            pass


    def _ota_watch_toggle_pause(self):
        """D98 : pose/lève la pause globale. En pause : plus aucun scan,
        push, rechargement keepalive ni remontée de fenêtre Brave — le
        propriétaire travaille tranquille. La tâche en cours se termine
        proprement (D12). Session-only : jamais persistée (une pause
        oubliée arrêterait la protection en silence)."""
        try:
            import extranet_bridge as _xb
            from core.widgets import _btn_fg
            if _xb.is_paused():
                _xb.pause_clear()
                try:
                    self._ota_watch_pause_btn.config(
                        text=tr_("⏸ Tout mettre en pause"),
                        bg=T.ACCENT, fg=_btn_fg(T.ACCENT))
                    self._ota_watch_status.config(
                        text=tr_("▶ Reprise — l'outil reprend son rythme "
                                 "normal (scans, corrections, keepalive)."),
                        fg=T.GREEN)
                except Exception:
                    pass
                self.app._log_journal(
                    "▶ " + tr_("pause levée — l'outil reprend son rythme "
                               "normal"), engine="PAUSE")
            else:
                _xb.pause_set()
                try:
                    self._ota_watch_pause_btn.config(
                        text=tr_("▶ Reprendre"),
                        bg=T.GREEN, fg=_btn_fg(T.GREEN))
                    self._ota_watch_status.config(
                        text=tr_("⏸ EN PAUSE — plus aucun scan, envoi, "
                                 "rechargement ni remontée de fenêtre. "
                                 "Clique ▶ Reprendre pour relancer."),
                        fg=T.ORANGE)
                except Exception:
                    pass
                self.app._log_journal(
                    "⏸ " + tr_("pause globale posée — plus aucune activité "
                               "ni fenêtre volée jusqu'à reprise"),
                    engine="PAUSE")
        except Exception:
            logging.exception("bascule pause impossible")

    def _ota_watch_stop_operation(self):
        """D56 : arrête l'opération en cours — scan OU correction extranet.
        Remplacé par le bouton ⏹ Stop (les deux mécanismes coexistent)."""
        try:
            import extranet_bridge as _xb
            cur = _xb.operation_current()
        except Exception:
            cur = ""
        # D76 : ⏹ arrête AUSSI la boucle de correction saisonnière
        # (posé quel que soit le créneau — la boucle fait reset_stop()
        # à son démarrage, un STOP résiduel est donc inoffensif).
        try:
            from business import seasonal_loop as _sloop
            _sloop.STOP.set()
            # D78 : trace VISIBLE dans le journal, quel que soit
            # l'onglet où se trouve l'utilisateur (leçon du 21/09 :
            # clics sans aucun retour apparent).
            self.app._log_journal(
                "⏹ " + tr_("arrêt demandé — l'envoi en cours se termine, "
                           "le reste est annulé"), engine="SEASONAL")
        except Exception:
            pass
        if cur == "scan":
            self._ota_watch_stop_scan()
            return
        if cur == "push":
            try:
                import extranet_bridge as _xb
                _xb.QUEUE_STOP.set()
            except Exception:
                return
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("⏹ Arrêt de la correction demandé — la file "
                             "s'arrête avant la tâche suivante."),
                    fg=T.YELLOW)
            try:
                if hasattr(self, "_push_prog_lbl") and                         self._push_prog_lbl.winfo_exists():
                    self._push_prog_lbl.config(
                        text=tr_("⏹ Arrêt demandé — la file s'arrête avant "
                                 "la tâche suivante…"))
            except Exception:
                pass
            return

    def _ota_watch_stop_scan(self):
        """Demande l'arrêt du scan en cours.

        Coopératif, pas préemptif : l'OTA en cours de scan (appels réseau
        Playwright déjà lancés) va jusqu'au bout, mais aucune OTA suivante
        ne démarrera — vérifié avant chaque grande étape (boucle OTAs, mire
        de référence, extraction VAE). Les résultats déjà obtenus sont quand
        même affichés/persistés (comportement identique à un scan normal
        où une OTA n'aurait rien retourné)."""
        if not getattr(self, "_ota_watch_scanning", False):
            return
        self._ota_watch_cancel_requested = True
        if hasattr(self, "_ota_watch_status"):
            self._ota_watch_status.config(
                text=tr_("⏹ Arrêt demandé — fin de l'OTA en cours puis arrêt…"),
                fg=T.YELLOW)

    def _vae_scan(self, _skip_save=False):
        """
        Scan via VAE passive interception.
        Results format: {ota_name: {room_type: price_int}}.
        """
        # D98 : en pause globale, aucun scan — message clair (pas un
        # refus D52 générique).
        try:
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._log_journal(
                    "⏸ " + tr_("scan impossible — l'outil est EN PAUSE "
                               "(bouton ▶ Reprendre pour relancer)"),
                    level="warn", engine="PAUSE")
                return
        except Exception:
            pass
        if getattr(self, "_ota_watch_scanning", False):
            return
        try:
            from licensing.license_checker import _ck
            if not _ck():
                return
        except Exception:
            pass

        import extranet_bridge as _xb_ops
        if _xb_ops.operation_current():
            try:
                from core.utils import tr_ as _tr2
                messagebox.showwarning(
                    tr_("Scan"),
                    tr_("Impossible : une {k} est en cours (depuis {s}).\n"
                        "Une seule opération à la fois — attendez sa fin.")
                        .format(k=_xb_ops.operation_current(),
                                s=_xb_ops.operation_since()),
                    parent=self.app.root)
            except Exception:
                pass
            return
        _xb_ops.operation_begin("scan")
        self._ota_watch_scanning = True
        self._ota_watch_cancel_requested = False
        try:
            if hasattr(self, "_ota_watch_stop_btn") and                     self._ota_watch_stop_btn.winfo_exists():
                self._ota_watch_stop_btn.config(state="normal")
        except Exception:
            pass

        # Update UI: disable scan button, reset progress bar
        try:
            if hasattr(self, "_ota_watch_scan_btn") and \
               self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="disabled", text=tr_("⏳ Scan..."))
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = 0
        except Exception:
            pass

        if not _skip_save:
            try:
                self._ota_watch_save()
            except Exception:
                pass

        import threading as _thr_vae
        def _thread():
            results = {}
            try:
                from vae_bridge import vae_scan

                def _progress(pct, msg):
                    # D53 : l'arret demande interrompt la boucle des OTA
                    if self._ota_watch_cancel_requested:
                        from vae_bridge import ScanCancelled
                        raise ScanCancelled()
                    try:
                        self.app.root.after(0, lambda: self._vae_update_progress(pct, msg))
                    except Exception:
                        pass

                results = vae_scan(self.app.config, progress_cb=_progress)
            except Exception as e:
                import logging
                logging.getLogger(__name__).error("VAE scan error: %s", e, exc_info=True)
            finally:
                # Schedule UI update on main thread
                try:
                    _was_cancelled = self._ota_watch_cancel_requested
                    self.app.root.after(0, lambda: self._vae_scan_done(
                        results, _skip_save, was_cancelled=_was_cancelled))
                except Exception:
                    self._ota_watch_scanning = False
        _xb_scan_end()

        _thr_vae.Thread(target=_thread, daemon=True, name="vae-scan").start()

    def _vae_update_progress(self, pct, msg):
        """Update progress UI during VAE scan."""
        try:
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=f"{msg} ({pct}%)")
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = pct
        except Exception:
            pass

    def _vae_scan_done(self, results, _skip_save=False, was_cancelled=False):
        """Called on main thread when VAE scan completes."""
        self._ota_watch_scanning = False
        _xb_scan_end()
        try:
            if hasattr(self, "_ota_watch_stop_btn") and                     self._ota_watch_stop_btn.winfo_exists():
                self._ota_watch_stop_btn.config(state="disabled")
        except Exception:
            pass
        self._ota_watch_cancel_requested = False

        # Re-enable scan button, fill progress bar to 100%
        try:
            if hasattr(self, "_ota_watch_scan_btn") and \
               self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="normal", text=tr_("🔍 Scan"))
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = 100
        except Exception:
            pass

        if not results:
            try:
                from core.utils import tr_ as _tr
                messagebox.showinfo(tr_("Scan"),
                    tr_("Aucun prix capturé.\n"
                        "Naviguez sur les OTA dans Brave/Chrome puis relancez le scan."),
                    parent=self.app.root)
            except Exception:
                pass
            return

        # Store results in config
        try:
            self.app.config.setdefault("ota_watch", {})["last_results"] = results
            self.app.config.setdefault("ota_watch", {})["last_scan_time"] = \
                __import__("datetime").datetime.now().isoformat()
        except Exception:
            pass

        # Re-detect Brave tabs now that a scan just finished — replaces the
        # old fixed 30 s timer that made the whole window blink every 30 s.
        # Only rebuilds the section if the set of OTA tabs actually changed.
        # Placed before fill_tree so that, if a rebuild happens, it reloads
        # last_results (just saved above); fill_tree then refreshes the tree.
        try:
            self._ota_watch_detect_tabs()
        except Exception:
            pass

        # Display results in Treeview
        try:
            self._ota_watch_fill_tree(results)
        except Exception:
            pass

        # Post-processing: parity check, notifications, mobile publish
        try:
            self._ota_watch_on_scan_done(results, stopped=was_cancelled)
        except Exception:
            pass

        # Save config
        if not _skip_save:
            try:
                self._ota_watch_save()
            except Exception:
                pass

    def _ota_watch_on_scan_done(self, results, stopped=False):
        """Callback appelé après scan — remplit le tableau et auto-corrige si activé."""
        self._ota_watch_scanning = False
        _xb_scan_end()
        self._ota_watch_cancel_requested = False
        try:
            self._ota_watch_fill_tree(results)
            cfg = self.app.config.get("ota_watch", {})
            ts  = fmt_dt(cfg.get("last_scan_time", ""))
            if hasattr(self, "_ota_watch_status"):
                if stopped:
                    self._ota_watch_status.config(
                        text=tr_("⏹ Scan arrêté par l'utilisateur à {ts} (résultats partiels).").format(ts=ts),
                        fg=T.YELLOW)
                else:
                    self._ota_watch_status.config(text=tr_("✅ Scan terminé à {ts}.").format(ts=ts), fg=T.GREEN)
            # ── Historique : apparier ce scan avec le dernier envoi ──────
            # AVANT la branche calibration, qui sort de la fonction : sinon
            # les scans de calibration — précisément ceux qui mesurent l'effet
            # d'un envoi — ne seraient jamais enregistrés.
            try:
                self._record_observation_history(results)
            except Exception:
                logging.exception("historique des envois : observation non enregistrée")

            # Si c'est un scan de calibration → vérifier les planchers
            if getattr(self, "_ota_calib_rescanning", False):
                self._ota_calib_rescanning = False
                self._ota_calib_check(results)
                return
            # ── Notification : prix incorrect détecté ────────────────────
            try:
                self._notify_price_gaps(results)
            except Exception:
                pass
            # ── Passerelle mobile : publier l'état vers l'app compagnon ───
            try:
                self._publish_mobile_state(results)
            except Exception:
                pass
            # ── Protection plancher / plafond (audit G2-1) ────────────────
            # La case « Correction automatique au scan » (section 🛡️ Protection
            # prix plancher & plafond) ne déclenchait RIEN : son unique lecture
            # servait à cocher la case au démarrage. Elle est désormais reliée
            # au moteur, en MODE ALERTE SEULE par défaut (journal + email +
            # Telegram + téléphone, aucun envoi au Channel Manager).
            try:
                if self.app.config.get("price_floors", {}).get("auto_correct")                         and not stopped:
                    self._floor_auto_check_and_correct()
            except Exception:
                logging.exception("Protection plancher/plafond : contrôle échoué")
            if cfg.get("auto_correct") and not stopped:
                self._ota_watch_correct(min_gap=cfg.get("min_gap", 50), silent=True)
        except Exception:
            pass

    def _publish_mobile_state(self, results):
        """Publie l'état du scan vers Firebase pour l'app mobile compagnon.

        Fail-safe (convention D8) : si la passerelle mobile n'est pas
        configurée/connectée, publish_state() retourne False sans rien casser.
        L'envoi réseau tourne dans un thread daemon pour ne jamais bloquer
        l'interface (même si Firestore est lent / injoignable)."""
        ota_cfg       = self.app.config.get("ota_watch", {})
        target_prices = ota_cfg.get("target_prices", {})
        min_gap       = ota_cfg.get("min_gap", 50)

        def _worker():
            try:
                from business.mobile_gateway import publish_state, publish_target_prices
                publish_state(results, target_prices, min_gap)
                publish_target_prices(target_prices)
            except Exception:
                pass

        import threading as _thr
        _thr.Thread(target=_worker, daemon=True).start()

    def _publish_mobile_state_correction(self, sent_ctx):
        """Met à jour l'état déjà publié pour le téléphone dès qu'une
        correction est envoyée avec SUCCÈS au Channel Manager, sans attendre
        le prochain scan (qui peut prendre plusieurs minutes — le téléphone
        garderait l'alerte rouge affichée alors que le prix vient d'être
        corrigé).

        `sent_ctx` = `_sent_ctx` construit par `_ota_watch_correct`
        (clé = (ota_minuscule, nom OTA brut de la chambre), valeur contient
        `config_room` et `target`) — couvre les DEUX origines d'une
        correction (bouton PC et ordre mobile), puisque les deux passent par
        `_ota_watch_correct` puis ici. Fail-safe (D8), thread daemon."""
        pushed = [
            {"room": ctx.get("config_room"), "ota_name": ctx.get("ota_name"),
             "target": ctx.get("target")}
            for ctx in (sent_ctx or {}).values()
            if ctx.get("config_room") and ctx.get("ota_name") and ctx.get("target") is not None
        ]
        if not pushed:
            return

        def _worker():
            try:
                from business.mobile_gateway import mark_rooms_corrected
                mark_rooms_corrected(pushed)
            except Exception:
                pass

        import threading as _thr
        _thr.Thread(target=_worker, daemon=True).start()

    def _notify_price_gaps(self, results):
        """Envoie une notification si des écarts de prix ont été détectés."""
        try:
            from business.notifications import send_notifications
            ota_cfg      = self.app.config.get("ota_watch", {})
            target_prices = ota_cfg.get("target_prices", {})
            min_gap       = ota_cfg.get("min_gap", 50)
            gaps          = {}
            for ota_name, room_prices in results.items():
                if not isinstance(room_prices, dict):
                    continue
                for room, detected in room_prices.items():
                    if not detected:
                        continue
                    targets = target_prices.get(room, {})
                    # Try exact key, then group alias, then any available
                    target = (targets.get(ota_name)
                              or targets.get(_MMT_DISPLAY)
                              or (list(targets.values())[0] if targets else None))
                    if target is None:
                        continue
                    gap = abs(float(target) - float(detected))
                    if gap >= min_gap:
                        gaps[f"{room} ({ota_name})"] = {
                            "detected": detected,
                            "target":   target,
                            "gap":      gap,
                            "ota":      ota_name,
                        }
            if gaps:
                send_notifications(
                    "price_gap_detected", gaps,
                    self.app.config,
                    triggers=self.app.config.get("automation", {}).get("triggers", {}))
        except Exception:
            pass

    def _wknd_cfg(self):
        """Config majoration weekend → dict {enabled, pct} pour _do_push."""
        ow = self.app.config.get("ota_watch", {})
        try:
            pct = float(ow.get("weekend_markup_pct", 20))
        except (ValueError, TypeError):
            pct = 20.0
        days = ow.get("weekend_days", [4, 5])
        return {"enabled": bool(ow.get("weekend_markup_enabled", True)), "pct": pct, "days": days}

    # ─── HISTORIQUE DES ENVOIS (prix envoyé → prix affiché) ───────────────────

    def _scanned_stay_date(self):
        """Date de séjour que le scan OTA lit réellement (aujourd'hui + date_offset).

        C'est la date qui compte pour l'historique : le prix affiché par l'OTA
        est celui de CETTE date, donc le prix « envoyé » à mettre en face doit
        être celui envoyé pour CETTE date — majoration weekend comprise.
        """
        ow = self.app.config.get("ota_watch", {})
        try:
            _off = max(0, int(ow.get("date_offset", 1)))
        except (ValueError, TypeError):
            _off = 1
        return (datetime.now() + timedelta(days=_off)).date()

    def _ota_discount_pct(self, room_key, ota_low):
        """Remise configurée pour le rate plan de cette OTA (0 si aucune).

        Lue dans channel_manager.room_mapping — c'est la valeur qu'utilise
        app_core.py::_do_push pour diviser le prix avant l'envoi.
        """
        try:
            _rm = (self.app.config.get("channel_manager", {})
                   .get("room_mapping", {}).get(room_key, {}))
            for _rp in _rm.get("rate_plans", []) or []:
                _n = (_rp.get("ota_name", "") or "").strip().lower()
                # Goibibo et MakeMyTrip = même inventaire (cf. app_core.py).
                if _n == "goibibo":
                    _n = "makemytrip"
                if _n and _n == (ota_low or "").strip().lower():
                    return float(_rp.get("ota_discount_pct", 0) or 0)
        except Exception:
            logging.exception("remise OTA illisible (%s / %s)", room_key, ota_low)
        return 0.0

    def _real_sent_price(self, base_price, room_key, ota_low):
        """Prix RÉELLEMENT parti au Channel Manager pour la date scannée.

        Entre le prix calculé et ce qui circule sur le réseau, deux
        transformations s'appliquent. Elles sont reproduites ici à l'identique,
        sinon l'historique enregistrerait un chiffre qui n'a jamais été envoyé
        et tout calcul bâti dessus serait faux :

          1. remise du rate plan — app_core.py :
                 prix / (1 − ota_discount_pct/100)
          2. majoration weekend par date — channel_manager.py::weekend_rate_segments :
                 × (1 + pct/100) si le jour scanné est dans weekend_days

        Exemple réel : cible 2100 ₹, scan sur J+1 = vendredi, majoration +10 %
        → 2310 ₹ réellement envoyés pour cette date.

        Retourne (prix_envoyé, remise_pct, majoration_pct, est_weekend, date_iso).
        """
        _price = float(base_price)
        _disc  = self._ota_discount_pct(room_key, ota_low)
        if 0 < _disc < 100:
            _price = _price / (1.0 - _disc / 100.0)

        _w      = self._wknd_cfg()
        _date   = self._scanned_stay_date()
        _is_wk  = bool(_w.get("enabled")) and _date.weekday() in (_w.get("days") or [])
        _mkp    = float(_w.get("pct", 0) or 0) if _is_wk else 0.0
        if _is_wk:
            _price = _price * (1.0 + _mkp / 100.0)

        return (int(round(_price)), _disc, _mkp, _is_wk, _date.strftime("%Y-%m-%d"))

    def _base_from_sent(self, sent_price, room_key, ota_low):
        """Inverse exact de _real_sent_price : prix envoyé → prix de base.

        Le calcul adaptatif raisonne sur le prix RÉELLEMENT parti — c'est celui
        que l'OTA a transformé. Mais la correction doit produire un prix de
        BASE : la remise du rate plan (app_core.py) et la majoration weekend
        (channel_manager.py) seront réappliquées plus loin. Sans ce retour en
        arrière, la majoration serait comptée deux fois et le prix envoyé
        dériverait de +10 % à chaque tour de boucle.

        Les deux opérations sont défaites dans l'ordre INVERSE de
        _real_sent_price — toute divergence entre les deux méthodes fausserait
        l'historique et donc tous les calculs bâtis dessus.
        """
        _price = float(sent_price)

        _w    = self._wknd_cfg()
        _date = self._scanned_stay_date()
        if bool(_w.get("enabled")) and _date.weekday() in (_w.get("days") or []):
            _mkp = float(_w.get("pct", 0) or 0)
            if _mkp > -100:
                _price = _price / (1.0 + _mkp / 100.0)

        _disc = self._ota_discount_pct(room_key, ota_low)
        if 0 < _disc < 100:
            _price = _price * (1.0 - _disc / 100.0)

        return int(round(_price))

    # Mesures retenues pour le calcul adaptatif : les 6 plus récentes, rien de
    # plus vieux que 14 jours. Une OTA change de comportement (promo, saison,
    # commission) ; une mesure d'il y a un mois ne décrit plus rien.
    _ADAPT_MAX_POINTS   = 6
    _ADAPT_MAX_AGE_DAYS = 14
    # Filet : un prix calculé ne peut pas s'écarter de plus de ×3 (ou ÷3) de la
    # cible. Ce n'est pas un réglage tarifaire — les vraies bornes sont celles
    # des réglages (_borner) — mais une protection contre une extrapolation
    # absurde issue d'une droite mal conditionnée.
    _ADAPT_MAX_RATIO = 3.0
    # Pas maximum d'un tour à l'autre, en % du dernier prix envoyé. Un calcul
    # très éloigné n'est pas refusé : il est atteint en plusieurs tours. Et ce
    # n'est pas qu'une précaution — chaque tour intermédiaire ajoute une mesure,
    # donc le calcul suivant est mieux fondé que celui d'aujourd'hui.
    _ADAPT_MAX_STEP_PCT = 25.0

    def _stall_limit(self):
        """Scans sans réaction de l'OTA avant de suspendre les envois (0 = jamais)."""
        try:
            return max(0, int(self.app.config.get("ota_watch", {})
                              .get("stall_checks", 3)))
        except (TypeError, ValueError):
            return 3

    def _ota_stalled(self, ota_name, raw_room):
        """L'OTA a-t-elle cessé de répercuter nos envois ? → (suspendu, nb_scans).

        Le Channel Manager a accepté l'envoi — sinon rien ne serait en attente
        dans l'historique — mais N scans de suite ont revu exactement le prix
        d'avant. Renvoyer un prix de plus n'y changerait rien, et surtout cela
        abandonnerait la mesure en attente : on n'apprendrait donc jamais ce que
        l'OTA fait de nos envois, et la boucle tournerait à vide des heures
        durant.

        Le blocage se lève tout seul dès que le prix bouge : c'est à cet instant
        que la mesure se complète et que l'attente disparaît.
        """
        _seuil = self._stall_limit()
        if _seuil <= 0:
            return False, 0
        try:
            from core import send_history as _sh
            _n = _sh.stalled_checks(ota_name, raw_room)
        except Exception:
            logging.exception("garde-fou : compteur d'immobilité illisible "
                              "(%s / %s)", ota_name, raw_room)
            return False, 0
        return (_n >= _seuil), _n

    def _cm_grid_price(self, ota_name, config_room):
        """D38 : prix ACTUEL du CM sur la grille OTASheet (lecture passive
        des captures — aucune action navigateur) pour chambre×OTA, à la
        date scannée. None si la grille est muette pour cette case.

        Pourquoi : le 28/08 19h04, l'ancre D35 a calculé avec un « dernier
        envoi » historique du 18/08 (3 500) alors que le CM tenait 1 600
        (posé manuellement 30 min plus tôt) → consigne 3 793 au lieu de
        ~1 618, écrasant le 1 600. La grille est la vérité à la minute
        près ; l'historique peut être à sec, périmé ou mal clé."""
        try:
            import extranet_bridge as _eb
            st = _eb.cm_state(self.app.config)
            if not st:
                return None
            _date = self._scanned_stay_date().isoformat()
            _ol = (ota_name or "").strip().lower()
            # Goibibo et MakeMyTrip partagent le MÊME inventaire : la case
            # grille de MakeMyTrip EST celle de Goibibo (miroir du renommage
            # goibibo→makemytrip déjà appliqué au push par app_core).
            _ol = "goibibo" if _ol == "makemytrip" else _ol
            _oc = None
            for _o in st.get("otas") or []:
                if str(_o.get("label", "")).strip().lower() == _ol:
                    _oc = str(_o.get("code"))
                    break
            if _oc is None:
                return None
            _rl = (config_room or "").strip().lower()
            for _r in st.get("rooms") or []:
                if str(_r.get("label", "")).strip().lower() == _rl:
                    _p = (st.get("daily") or {}).get(
                        (str(_r.get("code")), _oc, _date))
                    if _p is not None:
                        try:
                            return int(round(float(_p)))
                        except (TypeError, ValueError):
                            return None
                    return None
            return None
        except Exception:
            logging.exception("ancre grille CM : lecture impossible (%s / %s)",
                              ota_name, config_room)
            return None

    def _next_send_base(self, ota_name, raw_room, config_room, target, detected):
        """Prix de BASE à envoyer maintenant pour viser `target` sur cette OTA.

        Remplace l'envoi de la cible brute. Envoyer 2100 alors que le scan
        montre qu'Agoda affiche 1532 pour ce même envoi ne pouvait produire
        qu'un éternel 1532 : la cible repartait identique à chaque tour, donc
        l'affichage aussi.

        Trois régimes, du mieux informé au moins informé :

          1. au moins une mesure (envoyé → affiché) : on inverse la relation
             observée — proportion sur une mesure, droite dès deux
             (core/send_history.predict_sent_for) ;
          2. aucune mesure mais un envoi précédent connu : on avance de l'écart
             qui reste (cible − affiché) à partir du dernier prix réellement
             envoyé. C'est dirigé vers la cible et proportionné à la distance ;
          3. rien du tout (tout premier envoi) : la cible telle quelle — il n'y
             a rien de mieux tant qu'on n'a rien observé.

        Retourne (prix_de_base, méthode, détail_lisible).
        """
        from core import send_history as _sh
        _ota_low = (ota_name or "").strip().lower()

        # ── Mesures comparables ───────────────────────────────────────────
        # Nature du jour qui sera scanné. Une OTA peut appliquer une promo de
        # week-end différente de celle de la semaine : ajuster une droite sur un
        # mélange des deux donne une pente qui ne décrit ni l'un ni l'autre.
        _w  = self._wknd_cfg()
        _d  = self._scanned_stay_date()
        _wk = bool(_w.get("enabled")) and _d.weekday() in (_w.get("days") or [])

        _ms, _scope = [], ""
        try:
            _ms = _sh.get_measures(ota_name, raw_room,
                                   limit=self._ADAPT_MAX_POINTS,
                                   max_age_days=self._ADAPT_MAX_AGE_DAYS,
                                   weekend=_wk)
            if len(_ms) >= 2:
                _scope = (tr_("week-ends seuls") if _wk
                          else tr_("jours de semaine seuls"))
            else:
                # Trop peu de mesures comparables pour une droite : mieux vaut
                # élargir que rester aveugle — mais il faut le dire, le calcul
                # est moins sûr.
                _large = _sh.get_measures(ota_name, raw_room,
                                          limit=self._ADAPT_MAX_POINTS,
                                          max_age_days=self._ADAPT_MAX_AGE_DAYS)
                if len(_large) > len(_ms):
                    _ms    = _large
                    _scope = tr_("tous jours confondus, faute de mesures comparables")
        except Exception:
            logging.exception("calcul adaptatif : historique illisible (%s / %s)",
                              ota_name, raw_room)
            _ms = []

        _last = None
        try:
            _last = _sh.last_sent(ota_name, raw_room)
        except Exception:
            logging.exception("calcul adaptatif : dernier envoi illisible "
                              "(%s / %s)", ota_name, raw_room)

        # ── D38 : le « dernier envoyé » devient le prix CM ACTUEL lu sur
        # la grille (lecture passive) quand elle parle — l'historique ne
        # sert plus que de repli. Le 28/08 19h04 : ancre calculée sur un
        # envoi du 18/08 (3 500) alors que le CM tenait 1 600 → 3 793
        # envoyé au lieu de ~1 618. Toutes les gardes en aval (pas max
        # 25 %, écrêtage ×ratio, anti-point-fixe) suivent la MÊME
        # référence : on borne le mouvement par rapport à ce qui est
        # réellement en place, pas à un chiffre périmé.
        _cur = self._cm_grid_price(ota_name, config_room)
        _ref = _cur if _cur else _last
        _src = (tr_("prix CM actuel {c:,}").format(c=_cur) if _cur
                else (tr_("dernier envoi {l:,}").format(l=int(_last))
                      if _last else tr_("aucune référence")))

        # ── D35 : ancre fraîche (priorité sur l'historique) ─────────────
        # Le couple (prix en place, affiché ACTUEL) est l'observation la
        # plus récente de la façon dont l'OTA transforme nos envois.
        # base = prix_en_place × cible / affiché : mathématiquement,
        # l'envoi BOUGE dès que l'affichage n'est pas à la cible — le
        # point fixe du 27/08 (renvoyer 2 625 déjà en place pendant
        # qu'Agoda affichait 2 271, cible 1 400) devient impossible.
        _tgt_f, _det_f = float(target or 0), float(detected or 0)
        _anchor = None
        if _ref and _det_f > 0 and _tgt_f > 0 and abs(_det_f - _tgt_f) >= 1:
            _cand = int(round(float(_ref) * _tgt_f / _det_f))
            if _cand > 0 and _cand != int(_ref):
                _anchor = _cand

        if _anchor is not None:
            _sent, _meth = _anchor, tr_("ancre fraîche")
            _det = tr_("{src} → affiché {d:,} : pour afficher "
                       "{t:,}, envoyer {r:,} × {t:,} ÷ {d:,}").format(
                src=_src, d=int(_det_f), t=int(_tgt_f), r=int(_ref))
        else:
            _sent, _meth, _det = _sh.predict_sent_for(_ms, target)

        if _sent is None:
            if _ref and detected:
                _reste = int(target) - int(detected)
                _sent  = int(_ref) + _reste
                _meth  = tr_("pas vers la cible")
                _det   = tr_("{src} + écart restant {gap}").format(
                    src=_src, gap=f"{_reste:+,}")
            else:
                return (int(target), tr_("cible"),
                        tr_("aucune mesure — cible envoyée telle quelle"))

        _gardes = []

        # ── Garde-fou : pas maximum d'un tour à l'autre ────────────────────
        if _ref:
            _pas = max(1, int(round(abs(_ref) * self._ADAPT_MAX_STEP_PCT / 100.0)))
            _cap = min(max(int(_sent), int(_ref) - _pas), int(_ref) + _pas)
            if _cap != int(_sent):
                _gardes.append(tr_("pas limité à {p} % — envoi {csym}{v}").format(
                    p=int(self._ADAPT_MAX_STEP_PCT), v=f"{int(_cap):,}", csym=self._csym))
                _sent = _cap

        # ── Filet anti-extrapolation ──────────────────────────────────────
        # Les vraies bornes (min/max des réglages) sont appliquées ensuite par
        # _borner ; ce filet protège même quand aucune borne n'est réglée.
        _lo      = float(target) / self._ADAPT_MAX_RATIO
        _hi      = float(target) * self._ADAPT_MAX_RATIO
        _clamped = int(round(min(max(float(_sent), _lo), _hi)))
        if _clamped != int(_sent):
            _gardes.append(tr_("écrêté à ×{r} de la cible").format(
                r=int(self._ADAPT_MAX_RATIO)))
            _sent = _clamped

        # ── D35 : garde anti-point-fixe ─────────────────────────────────
        # Ne JAMAIS renvoyer tel quel le prix déjà en place alors que
        # l'affichage n'est pas à la cible : un renvoi identique est un
        # envoi sans effet qui n'apprend rien — c'est lui qui gonflait
        # les compteurs « inchangé après N scans ». Mouvement minimum :
        # 2 % du dernier envoi, dans le sens de la cible.
        if _ref and _det_f > 0 and _tgt_f > 0 \
                and abs(_det_f - _tgt_f) >= 1 and int(_sent) == int(_ref):
            _sens = -1 if _det_f > _tgt_f else 1
            _pas_min = max(1, int(round(abs(float(_ref)) * 0.02)))
            _sent = int(_ref) + _sens * _pas_min
            _gardes.append(tr_("point fixe évité — mouvement de {p}").format(
                p=f"{_sens * _pas_min:+,}"))

        _bits = [x for x in ([_det, _scope] + _gardes) if x]
        return (self._base_from_sent(_sent, config_room, _ota_low),
                _meth, " — ".join(_bits))

    def _fuzzy_target(self, rm, ota_n, target_prices):
        """(chambre affichée par l'OTA, OTA) → (prix cible, clé de config).

        Le nom affiché par l'OTA ne correspond pas toujours mot pour mot à
        celui de la configuration : rapprochement par mots communs
        (Jaccard ≥ 0.5). Retourne (0, rm) si aucune cible n'est configurée.

        Méthode partagée par la correction et la calibration : les deux DOIVENT
        viser exactement la même cible, sinon l'une corrigerait vers un prix et
        l'autre vers un autre, indéfiniment.
        """
        # Try exact OTA name, then group aliases (Goibibo↔MakeMyTrip).
        room_targets = target_prices.get(rm, {}) or {}
        for _key in (ota_n, "MakeMyTrip", "Goibibo", _MMT_DISPLAY):
            if _key == ota_n:
                continue
            if _key not in (room_targets or {}):
                continue
            # Only accept aliases that belong to the same group
            if _ota_group_key(ota_n) == _ota_group_key(_key):
                val = room_targets.get(_key, 0) or 0
                if val:
                    return val, rm
        exact = room_targets.get(ota_n, 0) or 0
        if exact:
            return exact, rm
        rm_w = set(w.lower() for w in rm.split() if len(w) > 2)
        if not rm_w:
            return 0, rm
        best_s, best_v, best_r = 0.0, 0, rm
        # D86 : candidat portant UNE CIBLE POUR CETTE OTA — prioritaire sur
        # tout le reste. Bug réel (23/09) : l'annonce Airbnb « Double Room
        # with Balcony » affichait sa chambre sous le nom « Double Room » ;
        # le match parfait (score 1.0) vers la config « Double Room » —
        # dont la seule cible est Agoda — éclipsait le match 0.5 vers
        # « Double Room with Balcony » qui PORTE la cible Airbnb 2200 →
        # valeur 0 → « No discrepancies » alors que l'écart était réel.
        best_o_s, best_o_v, best_o_r = 0.0, 0, rm
        for tp_r, tp_d in (target_prices or {}).items():
            tp_w = set(w.lower() for w in tp_r.split() if len(w) > 2)
            if not tp_w:
                continue
            score = len(rm_w & tp_w) / len(rm_w | tp_w)
            if score > best_s and score >= 0.5:
                best_s = score
                # Also check group aliases for fuzzy-matched room
                for _k in (ota_n, "MakeMyTrip", "Goibibo", _MMT_DISPLAY):
                    _pv = (tp_d or {}).get(_k, 0) or 0
                    if _pv:
                        best_v = _pv
                        break
                best_r = tp_r
            # piste prioritaire : ce nom de config porte une cible
            # pour CETTE OTA (ou son alias de groupe)
            if score > best_o_s and score >= 0.5:
                _ov = 0
                for _k in (ota_n, "MakeMyTrip", "Goibibo", _MMT_DISPLAY):
                    _pv = (tp_d or {}).get(_k, 0) or 0
                    if _pv:
                        _ov = _pv
                        break
                if _ov:
                    best_o_s, best_o_v, best_o_r = score, _ov, tp_r
        if best_o_v:
            return best_o_v, best_o_r
        return best_v, best_r

    def _record_send_history(self, corrections_by_ota, sent_ctx):
        """Note dans l'historique ce qui vient de partir, OTA par OTA.

        Appelé UNIQUEMENT quand le Channel Manager a accepté l'envoi. En MODE
        TEST, channel_manager.py renvoie « réussi » sans rien envoyer : la
        mesure est alors marquée `simulated` pour ne jamais entrer dans un
        calcul, tout en restant visible dans le fichier.
        """
        from core import send_history as _sh
        _simulated = bool(self.app.config.get("channel_manager", {})
                          .get("test_mode", False))
        for (_ota_low, _raw_room), _ctx in (sent_ctx or {}).items():
            try:
                _ck = _ctx.get("config_room") or ""
                # Goibibo et MakeMyTrip partagent le MÊME inventaire : le prix
                # réellement parti au Channel Manager via le canal Goibibo est
                # celui calculé pour MakeMyTrip (renommage goibibo→makemytrip
                # dans app_core.py::_do_push). Enregistrer ici le prix calculé
                # « côté Goibibo » — jamais envoyé — apprendrait à l'historique
                # une relation fausse : c'est l'origine de la pente quasi nulle
                # constatée le 2026-08-16 (l'affichage bougeait, mais pas en
                # fonction du chiffre noté en face).
                _price_src = "makemytrip" if _ota_low == "goibibo" else _ota_low
                _base = ((corrections_by_ota.get(_ck) or {}).get(_price_src)
                         or (corrections_by_ota.get(_ck) or {}).get(_ota_low))
                if not _base:
                    continue
                _sent, _disc, _mkp, _wknd, _date = self._real_sent_price(
                    _base, _ck, _ota_low)
                _ok = _sh.record_send(
                    _ctx.get("ota_name") or _ota_low, _raw_room,
                    sent=_sent, target=_ctx.get("target"),
                    observed_before=_ctx.get("observed_before"),
                    base_price=_base, stay_date=_date,
                    markup_pct=_mkp, weekend=_wknd, discount_pct=_disc,
                    simulated=_simulated, config_room=_ck)
                if _ok:
                    _note = tr_(" (simulé — MODE TEST)") if _simulated else ""
                    _mkp_note = (tr_(" · dont majoration weekend +{p}%").format(
                        p=int(_mkp)) if _wknd else "")
                    self.app._log_journal(
                        tr_("📓 Historique {ota} / {room} : envoyé {csym}{sent} pour le "
                            "{date}{mkp} — affiché avant envoi {csym}{before}{note}").format(
                                ota=_ctx.get("ota_name") or _ota_low,
                                room=_raw_room, sent=f"{_sent:,}", date=_date,
                                mkp=_mkp_note, csym=self._csym,
                                before=_ctx.get("observed_before") or "?",
                                note=_note),
                        engine="OTA_WATCH")
            except Exception:
                logging.exception("historique des envois : %s / %s non enregistré",
                                  _ota_low, _raw_room)

    def _record_observation_history(self, results):
        """Complète l'historique avec les prix affichés par le scan qui vient de finir.

        Une observation ne devient une mesure que si le prix a CHANGÉ depuis
        l'envoi : les OTA mettent parfois bien plus de 5 min à répercuter un
        tarif, et enregistrer un prix pas encore rafraîchi créerait un faux
        couple qui faussserait durablement les calculs.
        """
        from core import send_history as _sh
        for _ota_n, _rooms in (results or {}).items():
            for _raw_room, _price in (_rooms or {}).items():
                if not _price:
                    continue
                try:
                    _st = _sh.record_observation(_ota_n, _raw_room, _price)
                    if _st == _sh.OBS_CONFIRMED:
                        # La mesure vient de passer en « confirmed » : c'est la
                        # dernière de la liste. include_simulated pour que le
                        # journal reste lisible aussi en MODE TEST.
                        _done = _sh.get_measures(_ota_n, _raw_room, limit=1,
                                                 include_simulated=True)
                        _sent = (_done[-1] if _done else {}).get("sent")
                        self.app._log_journal(
                            tr_("📓 Mesure {ota} / {room} : envoyé {csym}{sent} → "
                                "affiché {csym}{obs}").format(
                                    ota=_ota_n, room=_raw_room, csym=self._csym,
                                    sent=f"{int(_sent):,}" if _sent else "?",
                                    obs=f"{int(_price):,}"),
                            engine="OTA_WATCH")
                    elif _st == _sh.OBS_UNCHANGED:
                        self.app._log_journal(
                            tr_("⏳ {ota} / {room} : prix inchangé ({csym}{obs}) — "
                                "l'OTA n'a pas encore répercuté l'envoi, "
                                "aucune mesure enregistrée").format(
                                    ota=_ota_n, room=_raw_room, csym=self._csym,
                                    obs=f"{int(_price):,}"),
                            engine="OTA_WATCH")
                except Exception:
                    logging.exception("historique : observation %s / %s échouée",
                                      _ota_n, _raw_room)

    def _ota_watch_fill_tree(self, results):
        """Remplit le tableau de résultats à partir de {ota_name: {room: price}}."""
        try:
            self._ota_watch_tree.delete(*self._ota_watch_tree.get_children())
            cfg           = self.app.config.get("ota_watch", {})
            target_prices = cfg.get("target_prices", {})

            # ── Configure per-OTA colour tags on the treeview ──
            _seen_ota_colors: set[str] = set()
            for _on in results:
                _oc = _get_ota_color(_on)
                if _oc not in _seen_ota_colors:
                    # Use group key so Goibibo & MakeMyTrip share one tag
                    _gk = _ota_group_key(_on).replace(' ', '_')
                    _tag_name = f"ota_{_gk}"
                    self._ota_watch_tree.tag_configure(
                        _tag_name, foreground=_oc)
                    _seen_ota_colors.add(_oc)

            # Prix CM actuels depuis heatmap (date la plus récente)
            _hm_prices = {}
            try:
                for _hk, _hv in sorted(self.app.config.get("heatmap_data", {}).items()):
                    _hp = _hk.split("_", 1)
                    _hm_prices[_hp[1] if len(_hp) > 1 else _hk] = _hv.get("my_price", 0) or 0
            except Exception:
                pass

            # Planchers depuis la stratégie
            _strat_floors = {}
            try:
                _strat_floors = self.app.config.get("strategy", {}).get("floors", {})
            except Exception:
                pass

            # Correspondance fuzzy nom de chambre OTA → target_prices (Jaccard ≥ 0.5)
            def _fuzzy_target(rm, ota_n):
                # Try exact key then group aliases (Goibibo↔MakeMyTrip).
                room_t = target_prices.get(rm, {}) or {}
                for _k in (ota_n, "MakeMyTrip", "Goibibo", _MMT_DISPLAY):
                    if _k == ota_n:
                        continue
                    if _ota_group_key(ota_n) != _ota_group_key(_k):
                        continue
                    _v = room_t.get(_k, 0) or 0
                    if _v:
                        return _v, rm
                exact = room_t.get(ota_n, 0) or 0
                if exact:
                    return exact, rm
                rm_w = set(w.lower() for w in rm.split() if len(w) > 2)
                if not rm_w:
                    return 0, rm
                best_s, best_v, best_r = 0.0, 0, rm
                for tp_r, tp_d in target_prices.items():
                    tp_w = set(w.lower() for w in tp_r.split() if len(w) > 2)
                    if not tp_w:
                        continue
                    score = len(rm_w & tp_w) / len(rm_w | tp_w)
                    if score > best_s and score >= 0.5:
                        best_s = score
                        for _k2 in (ota_n, "MakeMyTrip", "Goibibo", _MMT_DISPLAY):
                            _pv = (tp_d or {}).get(_k2, 0) or 0
                            if _pv:
                                best_v = _pv
                                break
                        best_r = tp_r
                return best_v, best_r

            if not results:
                self._ota_watch_tree.insert("", "end",
                    values=("—", "Aucun résultat", "—", "—", "—", "—", "—"),
                    tags=("none",))
                return

            for ota_name, room_prices in results.items():
                # Skip generalist / metasearch sites that slipped through
                # (defensive — they should be blocked at scan time).
                _on_lower = ota_name.lower()
                if any(g in _on_lower for g in
                       ("google hotel", "google travel", "trivago",
                        "kayak", "tripadvisor")):
                    continue
                # Build the OTA-specific tag name (foreground = OTA colour)
                _gk = _ota_group_key(ota_name).replace(' ', '_')
                _ota_tag = f"ota_{_gk}"
                if not room_prices:
                    self._ota_watch_tree.insert("", "end",
                        values=(ota_name, "Aucun prix détecté",
                                "—", "—", "—", "—", "⚪"),
                        tags=(_ota_tag,))
                    continue
                for room, detected in room_prices.items():
                    if not detected:
                        continue
                    # Skip internal CM test rooms (e.g. "move room") that
                    # never appear on real booking sites.
                    if room.lower().strip() in _EXCLUDED_ROOMS:
                        continue
                    target, _matched_r = _fuzzy_target(room, ota_name)
                    # Prix cible = prix SEMAINE (base). La majoration weekend est
                    # appliquée par DATE à l'envoi CM (ven/sam), pas ici.
                    _cm_price = _hm_prices.get(room, 0) or _hm_prices.get(_matched_r, 0)
                    _floor    = _strat_floors.get(room, 0) or _strat_floors.get(_matched_r, 0)
                    if target and detected:
                        gap = target - detected
                        _pct = (gap / target * 100.0) if target else 0.0
                        if gap > 0:
                            # OTA trop basse → envoyer la cible exacte (ou le plancher si supérieur)
                            to_send = int(max(target, _floor) if _floor else target)
                            gap_str  = f"▼ -{self._csym}{abs(int(gap)):,} ({_pct:+.0f}%)"
                            status   = "🔴 Trop bas"
                            _row_tag = "low"
                        elif gap < 0:
                            # OTA trop haute → envoyer la cible directement
                            to_send  = int(target)
                            gap_str  = f"▲ +{self._csym}{abs(int(gap)):,} ({_pct:+.0f}%)"
                            status   = "🔵 Surplus"
                            _row_tag = "high"
                        else:
                            to_send  = int(detected)
                            gap_str  = "✓ 0%"
                            status   = "🟢 OK"
                            _row_tag = "ok"
                        send_str = f"{self._csym}{to_send:,}"
                    else:
                        gap_str  = "—"
                        send_str = "—"
                        status   = "⚪ Cible N/D"
                        _row_tag = "none"
                    self._ota_watch_tree.insert("", "end", values=(
                        ota_name, room,
                        f"{self._csym}{int(target):,}" if target else "—",
                        f"{self._csym}{int(detected):,}",
                        gap_str, send_str, status,
                    ), tags=(_ota_tag, _row_tag))

            # ── Re-configure status tags AFTER OTA brand tags so that the
            #    foreground reflects status (green/red/orange/gray) rather
            #    than the vivid OTA brand colour.  In ttk.Treeview the LAST
            #    tag_configure that sets foreground wins per-item.
            #    This makes room names readable like the Target Prices grid. ──
            self._ota_watch_tree.tag_configure("ok",   foreground=T.GREEN)
            self._ota_watch_tree.tag_configure("low",  foreground=T.RED)
            self._ota_watch_tree.tag_configure("high", foreground=T.ORANGE)
            self._ota_watch_tree.tag_configure("none", foreground="#888888")

            # ── Réordonner selon l'ordre des chambres défini dans l'hôtel ──
            _rt_raw = self.app.config.get("room_types", [])
            _hotel_order = [r if isinstance(r, str) else r.get("type", r.get("name", ""))
                            for r in _rt_raw]
            _rank = {r: i for i, r in enumerate(_hotel_order)}

            def _natural_key(item_id):
                vals = self._ota_watch_tree.item(item_id, "values")
                room_val = vals[1] if len(vals) > 1 else ""
                ota_val  = vals[0] if vals else ""
                # Cherche le rang exact, puis fuzzy (substring)
                r = _rank.get(room_val)
                if r is None:
                    for i, rt in enumerate(_hotel_order):
                        if room_val.lower() in rt.lower() or rt.lower() in room_val.lower():
                            r = i
                            break
                return (r if r is not None else len(_hotel_order), ota_val)

            _items = list(self._ota_watch_tree.get_children(""))
            for _i, _iid in enumerate(sorted(_items, key=_natural_key)):
                self._ota_watch_tree.move(_iid, "", _i)
            # Bandes alternées par groupe de chambre — regroupe visuellement
            # chaque catégorie de chambre (remplace le zebra ligne-par-ligne).
            self._stripe_by_room()
            # Barre de synthèse sous le tableau.
            self._update_ota_summary()

            # Capture cet ordre comme ordre naturel (base pour le tri par colonne)
            try:
                self._ota_watch_sort_reset()
            except Exception:
                pass

        except Exception:
            pass

    def _stripe_by_room(self):
        """Alternance de fond par groupe de chambre (et non par ligne).

        Regroupe visuellement chaque catégorie de chambre : toutes les lignes
        d'une même chambre partagent la même teinte de fond, et la teinte
        bascule à chaque changement de chambre. Préserve les tags de
        foreground (statut, couleur OTA) — seul le ``background`` est touché.
        À appeler une fois les lignes dans leur ordre final (tri par chambre).
        """
        tree = self._ota_watch_tree
        tree.tag_configure("_grp_a", background="#f5f0e1")   # beige pastel
        tree.tag_configure("_grp_b", background="#dff0ea")   # turquoise pastel
        prev_room = None
        grp = 0  # 0 = _grp_a (teinte principale), 1 = _grp_b (teinte alternée)
        for iid in tree.get_children(""):
            vals = tree.item(iid, "values")
            room_val = vals[1] if len(vals) > 1 else ""
            if room_val != prev_room:
                # Bascule la teinte seulement à partir du 2e groupe (le 1er
                # reste _grp_a) afin que l'alternance commence par la teinte
                # principale.
                if prev_room is not None:
                    grp = 1 - grp
                prev_room = room_val
            cur_tags = tuple(t for t in tree.item(iid, "tags")
                             if not t.startswith("_grp_"))
            tree.item(iid, tags=cur_tags + (("_grp_a",) if grp == 0 else ("_grp_b",)))

    def _update_ota_summary(self):
        """Met à jour la barre de synthèse sous le tableau de résultats."""
        if not hasattr(self, "_ota_watch_summary"):
            return
        tree = self._ota_watch_tree
        try:
            kids = tree.get_children("")
            if not kids:
                self._ota_watch_summary.config(text="")
                return
            _rooms = set()
            _otas = set()
            _alerts = 0
            _ok = 0
            for iid in kids:
                vals = tree.item(iid, "values")
                if len(vals) > 1:
                    _rooms.add(vals[1])
                if vals:
                    _otas.add(vals[0])
                tags = tree.item(iid, "tags")
                if "low" in tags:
                    _alerts += 1
                elif "ok" in tags:
                    _ok += 1
            self._ota_watch_summary.config(
                text=tr_("📊 {r} chambre(s) · {o} OTA(s) · 🔴 {a} alerte(s) "
                         "· 🟢 {k} OK").format(r=len(_rooms), o=len(_otas),
                                               a=_alerts, k=_ok))
        except Exception:
            pass

    def _ota_watch_correct(self, room=None, ota_name=None, min_gap=None, silent=False):
        """Calcule et pousse les prix corrigés. min_gap=None → lire depuis config."""
        # D98 : en pause globale, aucun envoi — message clair.
        try:
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._log_journal(
                    "⏸ " + tr_("envoi impossible — l'outil est EN PAUSE "
                               "(bouton ▶ Reprendre pour relancer)"),
                    level="warn", engine="PAUSE")
                return
        except Exception:
            pass
        try:
            ota_cfg       = self.app.config.get("ota_watch", {})
            results       = ota_cfg.get("last_results", {})
            _alertes_prix = []   # anomalies remontées par la formule
            _notes_calc   = []   # trace du calcul adaptatif, chambre par chambre
            # OTAs actives dans le monitoring — seules cibles du push "Corriger tout"
            # Repère générique attendu côté Channel Manager : chaque annonce
            # Airbnb (Double Room, Deluxe Double Room, …) est un profil de scan
            # distinct, mais ota_name du mapping CM est toujours "AirBnB"
            # générique — sans cette normalisation, ota_filter rejette Airbnb
            # avant même le calcul de prix (même cause que pour per_ota plus bas).
            _monitored_otas = {
                ("Airbnb" if o["name"].strip().lower().startswith("airbnb")
                 else o["name"].strip())
                for o in ota_cfg.get("otas", [])
                if o.get("active") and o.get("name", "").strip()
            }
            target_prices = ota_cfg.get("target_prices", {})
            if min_gap is None:
                min_gap = ota_cfg.get("min_gap", 50)

            # Prix CM actuels depuis heatmap (date la plus récente)
            _hm_prices = {}
            try:
                for _hk, _hv in sorted(self.app.config.get("heatmap_data", {}).items()):
                    _hp = _hk.split("_", 1)
                    _hm_prices[_hp[1] if len(_hp) > 1 else _hk] = _hv.get("my_price", 0) or 0
            except Exception:
                pass

            # Planchers depuis la stratégie
            _strat_floors_c = {}
            try:
                _strat_floors_c = self.app.config.get("strategy", {}).get("floors", {})
            except Exception:
                pass

            # ── Bornes du prix ENVOYÉ au Channel Manager ──────────────────
            # Même règle que l'écran « Planchers / Plafonds » (voir
            # _floor_refresh) : un réglage « Envoi min/max CM » a la priorité,
            # sinon on retombe sur le plancher / plafond de la stratégie.
            _ceils_c = {}
            _cm_ov_c = {}
            try:
                _ceils_c = self.app.config.get("strategy", {}).get("ceilings", {}) or {}
                _cm_ov_c = (self.app.config.get("price_floors", {})
                            .get("cm_overrides", {}) or {})
            except Exception:
                pass

            def _key_fuzzy_c(_d, _rm, _fb=None):
                """Clé de `_d` désignant cette chambre : exacte, repli, puis Jaccard ≥ 0.5."""
                if _rm in _d:
                    return _rm
                if _fb and _fb in _d:
                    return _fb
                _w = set(w.lower() for w in _rm.split() if len(w) > 2)
                if not _w:
                    return None
                _bs, _bk = 0.0, None
                for _k in _d:
                    _kw = set(w.lower() for w in _k.split() if len(w) > 2)
                    if not _kw:
                        continue
                    _sc = len(_w & _kw) / len(_w | _kw)
                    if _sc > _bs and _sc >= 0.5:
                        _bs, _bk = _sc, _k
                return _bk

            def _bornes_cm(_rm, _fb=None):
                """(min, max) autorisés pour le prix envoyé au CM. 0 = pas de borne.
                D94 : l'override « Envoi min/max CM » ne s'applique qu'au nom
                EXACT de sa chambre (_cm_override_for) — plus de flou, qui
                laissait le 2000 de « Double Room with Balcony » fuier sur
                « Double Room » (rapport D92). Les planchers/plafonds de la
                stratégie gardent le rapprochement tolérant : ce sont des
                réglages par chambre classique et _rm est déjà un nom de
                config résolu."""
                _ov = _cm_override_for(_cm_ov_c, _rm, _fb)
                _fk = _key_fuzzy_c(_strat_floors_c, _rm, _fb)
                _ck = _key_fuzzy_c(_ceils_c, _rm, _fb)
                _mn = _ov.get("gross_min") or (_strat_floors_c.get(_fk, 0) if _fk else 0)
                _mx = _ov.get("gross_max") or (_ceils_c.get(_ck, 0) if _ck else 0)
                try:
                    return int(_mn or 0), int(_mx or 0)
                except (TypeError, ValueError):
                    return 0, 0

            def _borner(_prix, _rm, _fb=None, _ctx=""):
                """Ramène un prix dans ses bornes. Toute sortie de borne est signalée."""
                _mn, _mx = _bornes_cm(_rm, _fb)
                if _mn and _mx and _mn > _mx:
                    _alertes_prix.append(
                        f"{_ctx}{_rm} : bornes incohérentes (min {_mn:,} > max {_mx:,}) "
                        f"— seul le minimum est appliqué")
                    _mx = 0
                if _mn and _prix < _mn:
                    _alertes_prix.append(
                        f"{_ctx}{_rm} : prix calculé {int(_prix):,} sous le minimum "
                        f"autorisé {_mn:,} — ramené au minimum")
                    return _mn
                if _mx and _prix > _mx:
                    _alertes_prix.append(
                        f"{_ctx}{_rm} : prix calculé {int(_prix):,} au-dessus du maximum "
                        f"autorisé {_mx:,} — ramené au maximum")
                    return _mx
                return int(_prix)

            # Correspondance fuzzy nom de chambre OTA → target_prices.
            # Implémentation unique dans self._fuzzy_target, partagée avec la
            # calibration : deux copies finiraient par diverger et les deux
            # boucles viseraient des cibles différentes.
            def _fuzzy_target_c(rm, ota_n):
                return self._fuzzy_target(rm, ota_n, target_prices)

            # Fuzzy match nom OTA → clé interne strat_floors (Jaccard ≥ 0.5)
            def _floor_for(ota_rm, fallback_key=None):
                """Retourne (floor_value, clé_config) pour un nom de chambre OTA."""
                fl = _strat_floors_c.get(ota_rm, 0)
                if fl:
                    return fl, ota_rm
                if fallback_key:
                    fl = _strat_floors_c.get(fallback_key, 0)
                    if fl:
                        return fl, fallback_key
                _w = set(w.lower() for w in ota_rm.split() if len(w) > 2)
                if not _w:
                    return 0, ota_rm
                best_s, best_fl, best_k = 0.0, 0, ota_rm
                for _fk, _fv in _strat_floors_c.items():
                    _fw = set(w.lower() for w in _fk.split() if len(w) > 2)
                    if not _fw:
                        continue
                    sc = len(_w & _fw) / len(_w | _fw)
                    if sc > best_s and sc >= 0.5:
                        best_s, best_fl, best_k = sc, _fv, _fk
                return best_fl, best_k

            corrections = {}  # {room: prix_à_envoyer} — valeur de repli, toutes OTA confondues
            # {room: {ota_name en minuscule: prix_à_envoyer}} — cible RÉELLE par OTA. Sans ceci,
            # deux OTA avec des prix cibles différents pour la même chambre (ex. Agoda 1600 /
            # MakeMyTrip 2000) finissaient toutes deux avec la même valeur écrasée dans
            # `corrections`, qui était ensuite broadcastée à TOUTES les OTA surveillées par
            # _do_push — d'où des prix corrects sur une seule OTA et faux/absents sur les autres.
            corrections_by_ota = {}
            # Contexte de chaque envoi, pour l'historique (core/send_history) :
            # {(ota_minuscule, chambre TELLE QUE L'OTA l'affiche): {...}}.
            # La clé est le nom OTA brut et non le nom de config, parce que c'est
            # la SEULE clé commune avec les résultats du prochain scan — c'est
            # elle qui permettra d'apparier « prix envoyé » et « prix affiché ».
            _sent_ctx = {}

            def _record_by_ota(_room_key, _ota, _price, _lower_is_better,
                               _raw_room="", _detected=None, _target=None):
                _ok = (_ota or "").strip().lower()
                if not _ok:
                    return
                _slot = corrections_by_ota.setdefault(_room_key, {})
                _prev = _slot.get(_ok)
                if _prev is None:
                    _slot[_ok] = _price
                elif _lower_is_better and _price < _prev:
                    _slot[_ok] = _price
                elif not _lower_is_better and _price > _prev:
                    _slot[_ok] = _price
                if _raw_room:
                    _sent_ctx[(_ok, _raw_room)] = {
                        "config_room":     _room_key,
                        # Prix affiché par l'OTA à l'instant de la décision : il
                        # servira de témoin. L'observation du prochain scan ne
                        # comptera comme mesure que si le prix en diffère.
                        "observed_before": _detected,
                        "ota_name":        (_ota or "").strip(),
                        "target":          _target,
                    }

            for ota_n, room_prices in results.items():
                if ota_name and ota_n != ota_name:
                    continue
                for rm, detected in room_prices.items():
                    if room and rm != room:
                        continue
                    if not detected:
                        continue

                    # ── Garde-fou : l'OTA ne répercute plus nos envois ─────
                    # Placé AVANT tout calcul et avant la branche « pas de
                    # cible » : quel que soit le chemin, insister n'aurait
                    # aucun effet et ferait perdre la mesure en attente.
                    _fige, _nb_scans = self._ota_stalled(ota_n, rm)
                    if _fige:
                        _alertes_prix.append(
                            f"{ota_n} / {rm} : prix affiché inchangé "
                            f"({self._csym}{int(detected):,}) après {_nb_scans} scans, alors "
                            f"que le Channel Manager a accepté l'envoi — envois "
                            f"suspendus pour cette chambre. À vérifier à la main : "
                            f"mapping du rate plan, restriction en ligne, ou "
                            f"simple lenteur de mise à jour de l'OTA. La "
                            f"suspension se lève d'elle-même dès que le prix bouge.")
                        continue

                    target, _matched_r = _fuzzy_target_c(rm, ota_n)
                    # Prix cible = prix SEMAINE (base). La majoration weekend est
                    # appliquée par DATE à l'envoi CM (ven/sam), pas ici.

                    # ── Cas : pas de prix cible configuré ──────────────────────
                    # Vérifier quand même le plancher : si OTA < floor → corriger
                    if not target:
                        _fl_c, _fl_key = _floor_for(rm)
                        if _fl_c and detected < _fl_c:
                            # Plancher exact, sans calcul — mais vérifié quand
                            # même contre le maximum autorisé (un plancher
                            # au-dessus du plafond serait un réglage incohérent).
                            to_send = _borner(int(_fl_c), rm, _fl_key,
                                              _ctx=f"{ota_n} / ")
                            if _fl_key not in corrections or to_send > corrections[_fl_key]:
                                corrections[_fl_key] = to_send
                            _record_by_ota(_fl_key, ota_n, to_send, _lower_is_better=False,
                                           _raw_room=rm, _detected=detected,
                                           _target=target)
                        continue  # pas de cible → pas d'ajustement gap classique

                    _floor_c, _ = _floor_for(rm, _matched_r)
                    gap = target - detected
                    # Clé interne (nom config) — pas le nom OTA brut — pour que tous les
                    # lookups downstream (room_mapping, room_auto_update, heatmap_data) fonctionnent
                    _ck = _matched_r

                    # ── Prix à envoyer : calcul adaptatif ─────────────────
                    # La cible n'est PLUS envoyée telle quelle. Envoyer 2100
                    # alors que le scan montre qu'Agoda affiche 1532 pour ce
                    # même envoi ne pouvait donner qu'un éternel 1532.
                    # On repart de ce que l'OTA a réellement fait des envois
                    # précédents (core/send_history) pour remonter au prix
                    # qui, une fois transformé par elle, donnera la cible.
                    # Aucune formule fondée sur le prix barré ou la remise
                    # affichée : ces valeurs sont inventées par l'OTA et ne
                    # décrivent pas son calcul réel.
                    _prix, _meth, _det = self._next_send_base(
                        ota_n, rm, _matched_r, target, detected)
                    _notes_calc.append(
                        f"{ota_n} / {rm} : affiché {self._csym}{int(detected):,}, "
                        f"cible {self._csym}{int(target):,} → base {self._csym}{int(_prix):,} "
                        f"[{_meth}]" + (f" — {_det}" if _det else ""))

                    # ── Bornes prioritaires ───────────────────────────────
                    # Le min/max des réglages passe AVANT le résultat de la
                    # formule : un calcul hors bornes est ramené à la borne et
                    # signalé. `_floor_c` n'est plus appliqué ici — le plancher
                    # est déjà compris dans le minimum ci-dessous, et l'y
                    # remettre pourrait faire repasser un prix au-dessus du
                    # maximum autorisé.
                    _prix = _borner(_prix, rm, _matched_r, _ctx=f"{ota_n} / ")

                    if gap >= min_gap:
                        # Trop basse : envoyer le prix calculé
                        to_send = int(_prix)
                        if _ck not in corrections or to_send > corrections[_ck]:
                            corrections[_ck] = to_send
                        _record_by_ota(_ck, ota_n, to_send, _lower_is_better=False,
                                       _raw_room=rm, _detected=detected,
                                       _target=target)
                    elif gap <= -min_gap:
                        # Trop haute : envoyer le prix calculé
                        to_send = int(_prix)
                        if _ck not in corrections or to_send < corrections[_ck]:
                            corrections[_ck] = to_send
                        _record_by_ota(_ck, ota_n, to_send, _lower_is_better=True,
                                       _raw_room=rm, _detected=detected,
                                       _target=target)

            # ── Vérification finale avant envoi ───────────────────────────
            # Dernier contrôle sur ce qui va RÉELLEMENT partir au Channel
            # Manager, quel que soit le chemin qui l'a produit. Le bornage a
            # déjà eu lieu plus haut : si un prix ressort encore hors limites
            # ici, il est corrigé et signalé.
            for _vk in list(corrections):
                _vv = corrections[_vk]
                _vb = _borner(_vv, _vk, _ctx="vérification finale — ")
                if _vb != _vv:
                    corrections[_vk] = _vb
            for _vk, _by_ota in corrections_by_ota.items():
                for _vo, _vv in list(_by_ota.items()):
                    _vb = _borner(_vv, _vk, _ctx=f"vérification finale ({_vo}) — ")
                    if _vb != _vv:
                        _by_ota[_vo] = _vb

            # Anomalies détectées pendant le calcul (remise absurde, barré
            # incohérent, prix hors taxes, prix illisible…) : toujours
            # journalisées, y compris en mode silencieux — c'est la trace qui
            # permet de comprendre après coup pourquoi un prix a bougé ou non.
            for _msg in _alertes_prix:
                try:
                    self.app._log_journal("⚠ " + _msg, level="warning",
                                          engine="OTA_WATCH")
                except Exception:
                    logging.warning("OTA correction: %s", _msg)

            # Comment chaque prix a été obtenu : méthode retenue et mesures
            # utilisées. Toujours journalisé, y compris en mode silencieux —
            # sans cette trace, impossible de relire après coup pourquoi tel
            # prix est parti plutôt qu'un autre.
            for _msg in _notes_calc:
                try:
                    self.app._log_journal("🧮 " + _msg, engine="OTA_WATCH")
                except Exception:
                    logging.info("OTA correction: %s", _msg)

            if not corrections:
                if not silent:
                    messagebox.showinfo(tr_("Correction OTA"),
                        tr_("Aucun écart à corriger — tous les prix sont dans la limite."),
                        parent=self.app.root)
                return

            if not silent:
                lines = "\n".join(f"  • {rm} → {self._csym}{int(p):,}" for rm, p in corrections.items())
                ok = messagebox.askyesno(tr_("Confirmer correction OTA"),
                    f"Prix à envoyer au Channel Manager :\n{lines}\n\nConfirmer ?",
                    parent=self.app.root)
                if not ok:
                    return

            # Même normalisation que ota_filter ci-dessus, appliquée cette fois
            # aux clés de correction par-OTA transmises à _do_push. Les clés
            # internes de corrections_by_ota restent les noms de profil bruts
            # (nécessaire pour l'appariement avec l'historique des envois via
            # _sent_ctx) — seule cette copie destinée au Channel Manager est
            # normalisée.
            def _cm_ota_key(_k):
                return "airbnb" if _k.startswith("airbnb") else _k

            valid_results  = {rm: {"final": p,
                                    "per_ota": {_cm_ota_key(_k): _v for _k, _v
                                                in corrections_by_ota.get(rm, {}).items()}}
                              for rm, p in corrections.items()}
            cm             = self.app.config.get("channel_manager", {})
            _correct_offset = max(0, int(ota_cfg.get("correct_date_offset", 0)))
            checkin        = (datetime.now() + timedelta(days=_correct_offset)).strftime("%Y-%m-%d")
            try:
                _correct_days = max(1, min(365, int(ota_cfg.get("correct_duration_days", 90))))
            except (ValueError, TypeError):
                _correct_days = 90

            def _ota_corr_done(ok, msg, sent_items=None):
                try:
                    if hasattr(self, "_ota_watch_status"):
                        if ok:
                            self._ota_watch_status.config(
                                text=tr_("✅ CM : nouveau prix envoyé au Channel Manager — {msg}").format(msg=msg),
                                fg=T.GREEN)
                        else:
                            self._ota_watch_status.config(
                                text=tr_("✗ CM : envoi échoué — {msg}").format(msg=msg), fg=T.RED)
                except Exception:
                    pass
                # D105-2 : lot en échec de groupe MAIS avec des segments
                # réellement partis (preuve POST) → les mesurer QUAND MÊME.
                # Sans ça, 1-2 segments ratés sur 95 privaient l'apprentissage
                # de toutes les mesures du lot (PC client 08-09/10 : « AUCUN
                # envoi jamais enregistré » sur Expedia malgré des envois
                # massifs vérifiés).
                if not ok and sent_items:
                    try:
                        from extranet_bridge import record_queue_sent_items
                        _n = record_queue_sent_items(
                            sent_items, self.app.config)
                        if _n:
                            self.app._log_journal(
                                tr_("📓 Historique : {n} envoi(s) du lot "
                                    "partiellement échoué enregistré(s) "
                                    "(preuve POST)").format(n=_n),
                                engine="OTA_WATCH")
                    except Exception:
                        logging.exception("historique des envois (lot "
                                          "partiel) non enregistré")
                # Mettre à jour heatmap_data avec les prix envoyés
                # → le prochain scan utilisera ces prix comme base → escalade automatique
                if ok:
                    try:
                        hd = self.app.config.get("heatmap_data", {})
                        _updated = False
                        for _rm, _pr in corrections.items():
                            for _hk in sorted(hd.keys(), reverse=True):
                                if _hk.split("_", 1)[-1] == _rm:
                                    hd[_hk]["my_price"] = float(_pr)
                                    _updated = True
                                    break
                        if _updated:
                            self.app.config["heatmap_data"] = hd
                            cfg.save(self.app.config)
                    except Exception:
                        pass

                    # ── Historique des envois ────────────────────────────
                    # Trace « prix envoyé pour telle date → prix affiché »,
                    # par OTA et par chambre, sauvegardée sur le disque.
                    # C'est la mémoire qui manquait : sans elle, impossible
                    # d'ajuster un prix au vu de l'effet du précédent, et le
                    # logiciel renvoyait indéfiniment la même valeur.
                    try:
                        self._record_send_history(corrections_by_ota, _sent_ctx)
                    except Exception:
                        logging.exception("historique des envois : enregistrement échoué")

            def _ota_corr_done_with_notif(ok, msg, sent_items=None):
                _ota_corr_done(ok, msg, sent_items)
                if ok:
                    try:
                        self._publish_mobile_state_correction(_sent_ctx)
                    except Exception:
                        pass
                    try:
                        from business.notifications import send_notifications
                        send_notifications(
                            "correction_envoyee",
                            {room: prix for room, prix in corrections.items()},
                            self.app.config,
                            triggers=self.app.config.get(
                                "automation", {}).get("triggers", {}))
                    except Exception:
                        pass

            # Message d'ATTENTE posé AVANT le push : le résultat réel est écrit
            # ensuite par _ota_corr_done (✅ envoyé / ✗ échoué).
            # Auparavant un « ✅ Corrigé » était posé APRÈS l'appel et écrasait le
            # « ✗ CM : envoi échoué » que _do_push émet en synchrone quand il
            # n'a rien à envoyer (aucun rate plan retenu par ota_filter, endpoint
            # vide, aucun résultat) : l'utilisateur lisait « Corrigé » alors
            # qu'AUCUN prix n'était parti vers le Channel Manager.
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("⏳ Envoi de la correction au Channel Manager : {rooms}…").format(
                        rooms=", ".join(corrections.keys())), fg=T.YELLOW)

            self._do_push(valid_results, cm, checkin, _correct_days, getattr(self, "_cm_log", None),
                          silent=True, on_done=_ota_corr_done_with_notif, source="OTA Blocage",
                          weekend_markup=self._wknd_cfg(),
                          ota_filter=_monitored_otas or None)

            # ── Lancer la calibration itérative si activée ──
            try:
                _cw_cfg = self.app.config.get("ota_watch", {})
                if _cw_cfg.get("calib_auto") and corrections:
                    self._ota_calib_active      = True
                    self._ota_calib_rescanning  = False
                    # Plus de mémoire des envois ici : elle était en RAM (perdue
                    # à la fermeture) et indexée par chambre seulement, donc
                    # Agoda/Expedia/MakeMyTrip s'écrasaient mutuellement pour une
                    # même chambre. C'est core/send_history qui tient ce rôle,
                    # sur disque et séparé par OTA.
                    self._ota_calib_retries_cnt = {}
                    _wait_min = max(5, _cw_cfg.get("calib_wait_min", 5))
                    try:
                        _prev = getattr(self, "_ota_calib_after_id", None)
                        if _prev:
                            self.app.root.after_cancel(_prev)
                    except Exception:
                        pass
                    self._ota_calib_after_id = self.app.root.after(
                        _wait_min * 60 * 1000, self._ota_calib_tick)
                    if hasattr(self, "_ota_watch_status"):
                        self._ota_watch_status.config(
                            text=tr_("🔄 Calibration démarrée — re-vérification dans {n} min").format(n=_wait_min),
                            fg=T.YELLOW)
            except Exception:
                pass

        except Exception as e:
            if not silent:
                messagebox.showerror(tr_("Erreur correction OTA"), str(e), parent=self.app.root)
            else:
                # Ne PAS remettre « import logging » ici : Python considérerait
                # alors « logging » comme une variable locale sur TOUTE la
                # fonction, et les trois usages plus haut (lignes ~4195, ~4205,
                # ~4271) planteraient avec « cannot access local variable
                # 'logging' ». Le module est déjà importé en haut du fichier.
                logging.exception("_ota_watch_correct (mode silencieux) a échoué")
                self.app._log_journal(f"❌ Correction auto OTA échouée : {e}", level="error", engine="OTA_WATCH")

    # ─── CALIBRATION ITÉRATIVE ────────────────────────────────────────────────

    def _ota_calib_tick(self):
        """Re-scan OTA dans le cadre de la calibration itérative."""
        try:
            if not getattr(self, "_ota_calib_active", False):
                return
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("🔄 Calibration — re-scan OTA en cours…"), fg=T.YELLOW)
            self._ota_calib_rescanning = True
            self._vae_scan()
        except Exception:
            self._ota_calib_active = False

    def _calib_warn(self, ota_n, room, prix, raison):
        """Signale au journal un prix de calibration ramené à une borne."""
        try:
            self.app._log_journal(
                tr_("⚠ Calibration {ota} / {room} : prix calculé {p} {raison} "
                    "— ramené à la borne").format(
                        ota=ota_n, room=room, p=f"{self._csym}{int(prix):,}", raison=raison),
                level="warning", engine="OTA_WATCH")
        except Exception:
            logging.warning("Calibration %s / %s : %s %s", ota_n, room, prix, raison)

    def _ota_calib_check(self, results):
        """Appelé après un scan de calibration : la boucle qui vise la cible.

        Auparavant cette boucle ne regardait que le plancher et avançait de
        +150 ₹ à l'aveugle. Trois conséquences :

          - une chambre affichée à 1532 ₹ pour une cible de 2100 ₹ était
            déclarée « calibration réussie » du moment qu'elle passait le
            plancher : la cible n'était jamais visée ;
          - +150 ₹ par tour, à raison d'un tour par heure, demandait des
            dizaines d'heures pour quelques centaines de roupies d'écart, sans
            jamais tenir compte de ce que l'OTA faisait de ces 150 ₹ ;
          - le prix était poussé sur AUJOURD'HUI pour 1 nuit, alors que le scan
            lit J+`date_offset` : la calibration ne pouvait pas influencer ce
            qui allait être mesuré au tour suivant.

        Maintenant : arrêt quand l'affichage est à moins de `min_gap` de la
        cible, prix déduit des mesures (envoyé → affiché) par le même calcul
        que la correction normale, et envoi sur la même plage de dates que la
        correction — donc sur la date qui sera effectivement scannée.
        """
        try:
            strat_floors  = self.app.config.get("strategy", {}).get("floors", {}) or {}
            strat_ceils   = self.app.config.get("strategy", {}).get("ceilings", {}) or {}
            cfg_ota       = self.app.config.get("ota_watch", {})
            target_prices = cfg_ota.get("target_prices", {}) or {}
            max_retries   = max(1, cfg_ota.get("calib_max_retries", 5))
            wait_min      = max(5, cfg_ota.get("calib_wait_min", 5))
            retries_cnt   = getattr(self, "_ota_calib_retries_cnt", {})
            try:
                min_gap = int(cfg_ota.get("min_gap", 50))
            except (TypeError, ValueError):
                min_gap = 50

            # Fuzzy match nom OTA → clé interne strat_floors (Jaccard ≥ 0.5)
            def _calib_floor(ota_rm):
                fl = strat_floors.get(ota_rm, 0)
                if fl:
                    return fl, ota_rm
                _w = set(w.lower() for w in ota_rm.split() if len(w) > 2)
                if not _w:
                    return 0, ota_rm
                best_s, best_fl, best_k = 0.0, 0, ota_rm
                for _fk, _fv in strat_floors.items():
                    _fw = set(w.lower() for w in _fk.split() if len(w) > 2)
                    if not _fw:
                        continue
                    sc = len(_w & _fw) / len(_w | _fw)
                    if sc > best_s and sc >= 0.5:
                        best_s, best_fl, best_k = sc, _fv, _fk
                return best_fl, best_k

            # ── Ce qui reste à corriger ───────────────────────────────────
            # Clé = (OTA, chambre telle que l'OTA l'affiche). Deux OTA peuvent
            # avoir des cibles différentes pour la même chambre ; les mélanger
            # revenait à envoyer le prix de l'une à l'autre.
            todo = {}   # {(ota, chambre OTA): (cible, prix affiché, clé config)}
            for _ota_n, _rps in (results or {}).items():
                for _rm, _ota_p in (_rps or {}).items():
                    if not _ota_p:
                        continue
                    _tgt, _ck = self._fuzzy_target(_rm, _ota_n, target_prices)
                    if _tgt:
                        # Cible configurée : c'est elle qui décide, dans les
                        # deux sens — trop bas ET trop haut.
                        if abs(int(_tgt) - int(_ota_p)) >= min_gap:
                            todo[(_ota_n, _rm)] = (int(_tgt), int(_ota_p), _ck)
                        continue
                    # Aucune cible pour cette OTA : on garde l'ancienne règle du
                    # plancher, sinon ces chambres ne seraient plus suivies.
                    _fl, _fl_key = _calib_floor(_rm)
                    if _fl and _ota_p < _fl:
                        todo[(_ota_n, _rm)] = (int(_fl), int(_ota_p), _fl_key)

            if not todo:
                # ✅ Toutes les chambres sont à leur cible (ou au-dessus de leur
                #    plancher quand aucune cible n'est configurée)
                self._ota_calib_active = False
                n = max(retries_cnt.values()) if retries_cnt else 1
                # Rafraîchir avec les résultats frais du scan (pas last_results stale)
                try:
                    self._ota_watch_fill_tree(results)
                except Exception:
                    pass
                ts = fmt_dt(self.app.config.get("ota_watch", {}).get("last_scan_time", ""))
                if hasattr(self, "_ota_watch_status"):
                    self._ota_watch_status.config(
                        text=tr_("✅ Calibration réussie en {n} tentative(s) — scan {ts}").format(n=n, ts=ts),
                        fg=T.GREEN)
                return

            # ── Nouveau prix pour chaque chambre encore loin de sa cible ───
            new_pushes         = {}   # {clé config: {"final": p, "per_ota": {...}}}
            corrections_by_ota = {}   # même forme que la correction, pour l'historique
            _sent_ctx          = {}
            detail_bits        = []
            _figees            = 0    # chambres dont l'OTA ne répercute plus rien
            for (_ota_n, _rm), (_tgt, _ota_p, _ck) in todo.items():
                # ── Garde-fou : l'OTA ne répercute plus nos envois ─────────
                _fige, _nb_scans = self._ota_stalled(_ota_n, _rm)
                if _fige:
                    _figees += 1
                    try:
                        self.app._log_journal(
                            tr_("⚠ Calibration {ota} / {room} : prix affiché "
                                "inchangé ({csym}{p}) après {n} scans — envois "
                                "suspendus, à vérifier à la main").format(
                                    ota=_ota_n, room=_rm,
                                    p=f"{int(_ota_p):,}",
                                    csym=self._csym,
                                    n=_nb_scans),
                            level="warning", engine="OTA_WATCH")
                    except Exception:
                        logging.warning("Calibration figée : %s / %s", _ota_n, _rm)
                    continue

                # Compteur par (OTA, chambre) et non par chambre seule : sans
                # ça, un blocage sur Agoda consommait les tentatives d'Expedia.
                _ol = (_ota_n or "").strip().lower()
                _rk = (_ol, _rm)
                cnt = retries_cnt.get(_rk, 0)
                if cnt >= max_retries:
                    continue    # max atteint pour cette chambre sur cette OTA
                retries_cnt[_rk] = cnt + 1

                _base, _meth, _det = self._next_send_base(
                    _ota_n, _rm, _ck, _tgt, _ota_p)

                # Bornes des réglages : la calibration poussait jusqu'ici sans
                # aucun contrôle min/max. `_ck` est déjà la clé de config (le
                # rapprochement fuzzy a eu lieu au-dessus), lecture directe.
                _mn = strat_floors.get(_ck, 0) or 0
                _mx = strat_ceils.get(_ck, 0) or 0
                if _mn and _base < _mn:
                    self._calib_warn(_ota_n, _rm, _base,
                                     tr_("sous le minimum {v}").format(v=f"{int(_mn):,}"))
                    _base = int(_mn)
                elif _mx and _base > _mx:
                    self._calib_warn(_ota_n, _rm, _base,
                                     tr_("au-dessus du maximum {v}").format(v=f"{int(_mx):,}"))
                    _base = int(_mx)
                _base = int(_base)

                corrections_by_ota.setdefault(_ck, {})[_ol] = _base
                _sent_ctx[(_ol, _rm)] = {
                    "config_room":     _ck,
                    "observed_before": _ota_p,
                    "ota_name":        (_ota_n or "").strip(),
                    "target":          _tgt,
                }
                _slot = new_pushes.setdefault(_ck, {"final": _base, "per_ota": {}})
                _slot["per_ota"][_ol] = _base
                # `final` ne sert que de repli pour une OTA sans prix propre :
                # on garde le plus élevé, comme la correction normale.
                if _base > _slot["final"]:
                    _slot["final"] = _base
                detail_bits.append(
                    f"{_ota_n} / {_rm} : affiché {self._csym}{_ota_p:,}, cible {self._csym}{_tgt:,} "
                    f"→ base {self._csym}{_base:,} [{_meth}]" + (f" — {_det}" if _det else ""))

            self._ota_calib_retries_cnt = retries_cnt

            if not new_pushes:
                # Plus rien à envoyer : soit le maximum de tentatives est
                # atteint partout, soit les OTA concernées ne répercutent plus
                # rien. Les deux causes appellent des vérifications
                # différentes, le message doit donc les distinguer.
                self._ota_calib_active = False
                try:
                    self._ota_watch_fill_tree(results)
                except Exception:
                    pass
                if hasattr(self, "_ota_watch_status"):
                    if _figees:
                        _txt = tr_("⚠ Calibration arrêtée — {n} chambre(s) dont le prix "
                                   "affiché ne bouge plus malgré des envois acceptés : "
                                   "à vérifier à la main").format(n=_figees)
                    else:
                        _txt = tr_("⚠ Calibration : max tentatives atteint — vérifier manuellement")
                    self._ota_watch_status.config(text=_txt, fg=T.ORANGE)
                return

            # Comment chaque prix de calibration a été obtenu.
            for _msg in detail_bits:
                try:
                    self.app._log_journal("🧮 " + tr_("Calibration") + " — " + _msg,
                                          engine="OTA_WATCH")
                except Exception:
                    logging.info("Calibration OTA: %s", _msg)

            # ONE correction master. When OTA Blocage's auto-correct is
            # enabled it already pushes computed prices on its own
            # schedule; the calibration loop pushing its own values in
            # between made the two engines alternate conflicting prices
            # for the same rooms (2026-08-16, Expedia: 3,387 at 21:23 then
            # 3,043 at 21:33) — the display oscillated instead of
            # converging. The calibration loop keeps measuring; only its
            # push is disabled.
            if cfg_ota.get("auto_correct"):
                self._ota_calib_active = False
                try:
                    self.app._log_journal(
                        "ℹ " + tr_("Calibration : envoi CM ignoré — la "
                                   "correction auto (Blocage prix OTA) est "
                                   "active et pilote seule les prix."),
                        engine="OTA_WATCH")
                except Exception:
                    pass
                if hasattr(self, "_ota_watch_status"):
                    self._ota_watch_status.config(
                        text=tr_("ℹ Calibration : mesure seule — la correction "
                                 "auto pilote les envois CM"),
                        fg="#888888")
                return

            # Push nouveaux prix — MÊME plage de dates et MÊMES options que la
            # correction normale. Avec l'ancien couple (aujourd'hui, 1 nuit), le
            # prix de calibration ne couvrait pas la date lue par le scan
            # (J+date_offset) : la boucle mesurait donc l'effet d'un envoi qui
            # n'avait jamais touché la date observée.
            cm = self.app.config.get("channel_manager", {})
            try:
                _cal_offset = max(0, int(cfg_ota.get("correct_date_offset", 0)))
            except (TypeError, ValueError):
                _cal_offset = 0
            try:
                _cal_days = max(1, min(365, int(cfg_ota.get("correct_duration_days", 90))))
            except (TypeError, ValueError):
                _cal_days = 90
            checkin = (datetime.now() + timedelta(days=_cal_offset)).strftime("%Y-%m-%d")
            _cal_otas = {
                o["name"].strip()
                for o in cfg_ota.get("otas", [])
                if o.get("active") and o.get("name", "").strip()
            }

            def _calib_push_done(ok, msg):
                if ok:
                    # L'envoi n'entre dans l'historique QUE s'il est vraiment
                    # parti : sinon la mesure du prochain scan serait mise en
                    # face d'un prix qui n'a jamais quitté l'application.
                    try:
                        self._record_send_history(corrections_by_ota, _sent_ctx)
                    except Exception:
                        logging.exception("calibration : historique des envois "
                                          "non enregistré")
                try:
                    if hasattr(self, "_ota_watch_status"):
                        if ok:
                            self._ota_watch_status.config(
                                text=tr_("✅ CM : prix de calibration envoyé — {msg}").format(msg=msg),
                                fg=T.GREEN)
                        else:
                            self._ota_watch_status.config(
                                text=tr_("✗ CM : calibration — envoi échoué — {msg}").format(msg=msg), fg=T.RED)
                except Exception:
                    pass

            self._do_push(new_pushes, cm, checkin, _cal_days,
                          getattr(self, "_cm_log", None),
                          silent=True, on_done=_calib_push_done,
                          source="Calibration OTA",
                          weekend_markup=self._wknd_cfg(),
                          ota_filter=_cal_otas or None)

            # Rafraîchir le tableau avec les résultats frais du scan courant
            try:
                self._ota_watch_fill_tree(results)
            except Exception:
                pass

            n_max  = max(retries_cnt.values())
            detail = ", ".join(f"{rm} → {self._csym}{int(v['final']):,}"
                               for rm, v in new_pushes.items())
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("🔄 Calibration {n}/{max} : {detail} — re-vérif dans {wait} min").format(
                        n=n_max, max=max_retries, detail=detail, wait=wait_min),
                    fg=T.YELLOW)

            # Planifier prochain tick
            try:
                _prev = getattr(self, "_ota_calib_after_id", None)
                if _prev:
                    self.app.root.after_cancel(_prev)
            except Exception:
                pass
            self._ota_calib_after_id = self.app.root.after(
                wait_min * 60 * 1000, self._ota_calib_tick)

        except Exception:
            self._ota_calib_active = False

    # ─── PRIX PLANCHER / PLAFOND OTA ─────────────────────────────────────────

    def _build_price_floor_section(self, parent):
        lbl(parent, tr_("🛡️ Protection prix plancher & plafond OTA"),
            bold=True, size=12, color=T.ACCENT).pack(anchor="w", padx=10, pady=(12, 2))
        lbl(parent,
            "Plancher : OTA trop bas → le système remonte le tarif via CM.   Plafond : OTA trop haut → le système baisse le tarif via CM.",
            color=T.FG, size=9).pack(anchor="w", padx=10, pady=(0, 10))

        cols_frame = tk.Frame(parent, bg=T.BG)
        cols_frame.pack(fill="x", padx=10, pady=(0, 8))
        cols_frame.columnconfigure(0, weight=1)

        # ── Plancher & Plafond par chambre ──
        left = tk.Frame(cols_frame, bg=T.ENTRY_BG, padx=10, pady=8)
        left.grid(row=0, column=0, sticky="nsew")

        tk.Label(left, text=tr_("💰 Plancher & Plafond par chambre"), bg=T.ENTRY_BG, fg=T.ACCENT,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 6))

        tree_floor_frame = tk.Frame(left, bg=T.ENTRY_BG)
        tree_floor_frame.pack(fill="x")
        sb_f = ttk.Scrollbar(tree_floor_frame, orient="vertical")
        sb_f.pack(side="right", fill="y")
        cols_f = ("room", "floor", "ceiling", "gross_min", "gross_max")
        self._tree_floor = ttk.Treeview(tree_floor_frame, columns=cols_f, show="headings",
                                        height=6, selectmode="browse", yscrollcommand=sb_f.set)
        sb_f.config(command=self._tree_floor.yview)
        for col, txt, w in [
            ("room",      "Chambre",         150),
            ("floor",     "Plancher ▼",       95),
            ("ceiling",   "Plafond ▲",        95),
            ("gross_min", "Envoi min CM",    100),
            ("gross_max", "Envoi max CM",    100),
        ]:
            self._tree_floor.heading(col, text=txt)
            self._tree_floor.column(col, width=w, anchor="center" if col != "room" else "w")
        self._tree_floor.pack(side="left", fill="x", expand=True)
        self._tree_floor.tag_configure("warn", foreground=T.ORANGE)
        self._tree_floor.tag_configure("ok",   foreground=T.GREEN)
        self._tree_floor.tag_configure("conflict", foreground=T.RED)
        self._tree_floor_sort_reset = _attach_sort(self._tree_floor)

        btn_f = tk.Frame(left, bg=T.ENTRY_BG)
        btn_f.pack(anchor="w", pady=(6, 0))
        btn(btn_f, tr_("✏ Plancher"), self._floor_edit_floor,    color=T.GREEN,  width=12).pack(side="left", padx=(0, 6))
        btn(btn_f, tr_("✏ Plafond"),  self._floor_edit_ceiling,  color=T.ORANGE, width=12).pack(side="left", padx=(0, 6))

        btn_f2 = tk.Frame(left, bg=T.ENTRY_BG)
        btn_f2.pack(anchor="w", pady=(4, 0))
        btn(btn_f2, tr_("✏ Min CM"),  self._floor_edit_gross_min, color="#89b4fa", width=12).pack(side="left", padx=(0, 6))
        btn(btn_f2, tr_("✏ Max CM"),  self._floor_edit_gross_max, color="#89b4fa", width=12).pack(side="left", padx=(0, 6))
        tk.Label(btn_f2, text=tr_("(0 = calcul auto)"), bg=T.ENTRY_BG, fg="#888888",
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(4, 0))


        # ── Ligne surveillance ──
        surv = tk.Frame(parent, bg=T.BG)
        surv.pack(fill="x", padx=10, pady=(8, 4))

        self._floor_auto_var = tk.BooleanVar(value=self.app.config.get("price_floors", {}).get("auto_correct", False))
        tk.Checkbutton(surv, text=tr_("Surveillance automatique au scan (alerte seule)"),
                       variable=self._floor_auto_var,
                       command=self._floor_save_auto,
                       bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                       font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
        btn(surv, tr_("🔍 Vérifier violations"), self._floor_check_violations, color="#cba6f7", width=18).pack(side="left")
        self._floor_status_lbl = tk.Label(surv, text="", bg=T.BG, fg=T.FG, font=("Segoe UI", 9))
        self._floor_status_lbl.pack(side="left", padx=12)
        # Envoi réel — volontairement séparé de la surveillance : détecter est
        # sans risque, envoyer modifie les prix réellement en vente.
        surv2 = tk.Frame(parent, bg=T.BG)
        surv2.pack(fill="x", padx=10, pady=(2, 0))
        self._floor_push_var = tk.BooleanVar(
            value=self.app.config.get("price_floors", {}).get("auto_push", False))
        tk.Checkbutton(surv2,
                       text=tr_("⚠ Envoyer aussi les corrections au Channel Manager"),
                       variable=self._floor_push_var,
                       command=self._floor_save_push,
                       bg=T.BG, fg=T.ORANGE, selectcolor=T.ENTRY_BG,
                       activebackground=T.BG,
                       font=("Segoe UI", 9, "bold")).pack(side="left")
        lbl(parent,
            tr_("Après chaque scan, les prix sous le plancher ou au-dessus du plafond "
                "sont signalés dans le journal ET envoyés en alerte (email, Telegram, "
                "téléphone).\n"
                "Case du dessus seule = surveillance sans aucun envoi : elle permet de "
                "vérifier d'abord que les détections sont justes.\n"
                "Seconde case = les prix hors bornes sont corrigés automatiquement chez "
                "votre Channel Manager, sans confirmation."),
            size=8, color="#888888", wraplength=760, justify="left").pack(
                anchor="w", padx=10, pady=(2, 0))

        # ── Zone violations ──
        self._floor_viol_frame = tk.Frame(parent, bg=T.BG)
        self._floor_viol_frame.pack(fill="x", padx=10, pady=(0, 4))

        self._floor_refresh_trees()

    def _floor_refresh_trees(self):
        cfg_data  = self.app.config
        strat     = cfg_data.get("strategy", {})
        floors    = strat.get("floors", {})
        ceilings  = strat.get("ceilings", {})
        pf_cfg    = cfg_data.get("price_floors", {})

        self._tree_floor.delete(*self._tree_floor.get_children())
        rooms = cfg_data.get("room_types", [])
        if not rooms:
            rooms = sorted(set(list(floors.keys()) + list(ceilings.keys())))
        cm_overrides = pf_cfg.get("cm_overrides", {})
        for room in rooms:
            fl  = floors.get(room, 0)
            cel = ceilings.get(room, 0)
            ov  = cm_overrides.get(room, {})
            gross_min = ov.get("gross_min") or fl or 0
            gross_max = ov.get("gross_max") or cel or 0
            if fl and cel and gross_min > gross_max:
                tag = "conflict"
                fl_str  = f"{self._csym}{fl:,.0f}"
                cel_str = f"{self._csym}{cel:,.0f} ⚠"
            elif fl or cel:
                tag = "ok"
                fl_str  = f"{self._csym}{fl:,.0f}" if fl else "—"
                cel_str = f"{self._csym}{cel:,.0f}" if cel else "—"
            else:
                tag = "warn"
                fl_str = cel_str = "— non défini —"
            gmin_str = f"{self._csym}{gross_min:,.0f}" if gross_min else "—"
            gmax_str = f"{self._csym}{gross_max:,.0f}" if gross_max else "—"
            self._tree_floor.insert("", "end",
                values=(room, fl_str, cel_str, gmin_str, gmax_str), tags=(tag,))
        zebra_stripe(self._tree_floor)
        try:
            self._tree_floor_sort_reset()
        except Exception:
            pass

    def _floor_edit_floor(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Sélection"), tr_("Sélectionne une chambre dans le tableau."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        floors = self.app.config.setdefault("strategy", {}).setdefault("floors", {})
        current = floors.get(room, 0)
        val = simpledialog.askfloat("Prix plancher",
                                    f"Prix plancher pour '{room}' (INR) :\n(minimum en dessous duquel aucun OTA ne peut vendre)",
                                    initialvalue=current, minvalue=0, maxvalue=99999,
                                    parent=self.app.root)
        if val is not None:
            floors[room] = val
            self.app.config.setdefault("room_inventory", {}).setdefault(room, {})["floor"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_ceiling(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Sélection"), tr_("Sélectionne une chambre dans le tableau."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        ceilings = self.app.config.setdefault("strategy", {}).setdefault("ceilings", {})
        current = ceilings.get(room, 0)
        val = simpledialog.askfloat("Prix plafond",
                                    f"Prix plafond pour '{room}' (INR) :\n(maximum au-dessus duquel aucun OTA ne peut vendre)",
                                    initialvalue=current, minvalue=0, maxvalue=999999,
                                    parent=self.app.root)
        if val is not None:
            ceilings[room] = val
            self.app.config.setdefault("room_inventory", {}).setdefault(room, {})["ceiling"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_gross_min(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Sélection"), tr_("Sélectionne une chambre dans le tableau."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        overrides = self.app.config.setdefault("price_floors", {}).setdefault("cm_overrides", {})
        current = overrides.get(room, {}).get("gross_min", 0)
        val = simpledialog.askfloat(
            "Envoi min CM",
            f"Prix minimum à envoyer au CM pour '{room}' (INR) :\n"
            f"(ce que tu envoies au CM pour que le client voit au moins ton plancher)\n"
            f"Entrez 0 pour revenir au calcul automatique.",
            initialvalue=current, minvalue=0, maxvalue=999999, parent=self.app.root)
        if val is not None:
            overrides.setdefault(room, {})["gross_min"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_gross_max(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Sélection"), tr_("Sélectionne une chambre dans le tableau."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        overrides = self.app.config.setdefault("price_floors", {}).setdefault("cm_overrides", {})
        current = overrides.get(room, {}).get("gross_max", 0)
        val = simpledialog.askfloat(
            "Envoi max CM",
            f"Prix maximum à envoyer au CM pour '{room}' (INR) :\n"
            f"(le logiciel ne dépassera jamais ce montant lors des envois)\n"
            f"Entrez 0 pour revenir au calcul automatique (= plafond).",
            initialvalue=current, minvalue=0, maxvalue=999999, parent=self.app.root)
        if val is not None:
            overrides.setdefault(room, {})["gross_max"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()


    def _floor_save_auto(self):
        pf = self.app.config.setdefault("price_floors", {})
        pf["auto_correct"] = self._floor_auto_var.get()
        # Surveillance décochée → l'envoi automatique n'a plus de sens (il ne
        # serait de toute façon jamais déclenché) : on le désactive aussi pour
        # que l'interface ne laisse pas croire qu'il reste actif.
        if not self._floor_auto_var.get() and pf.get("auto_push"):
            pf["auto_push"] = False
            if hasattr(self, "_floor_push_var"):
                self._floor_push_var.set(False)
        cfg.save(self.app.config)

    def _floor_save_push(self):
        """Active/désactive l'ENVOI RÉEL des corrections au Channel Manager.

        Séparé de la surveillance (audit G2-1) : la détection est sans risque,
        l'envoi modifie les prix réellement en vente. Activation protégée par
        une confirmation explicite — et refusée si la surveillance est éteinte,
        puisque rien ne déclencherait le contrôle.
        """
        pf = self.app.config.setdefault("price_floors", {})
        if self._floor_push_var.get():
            if not self._floor_auto_var.get():
                messagebox.showwarning(
                    tr_("Protection plancher / plafond"),
                    tr_("Active d'abord « Surveillance automatique au scan ».\n\n"
                        "Sans elle, aucun contrôle n'est effectué : l'envoi "
                        "automatique ne se déclencherait jamais."),
                    parent=self.app.root)
                self._floor_push_var.set(False)
                return
            if not messagebox.askyesno(
                    tr_("Envoi automatique au Channel Manager"),
                    tr_("⚠ Cette option modifie vos VRAIS PRIX EN VENTE.\n\n"
                        "À chaque scan, tout prix détecté sous le plancher ou "
                        "au-dessus du plafond sera corrigé automatiquement et "
                        "envoyé au Channel Manager, sans confirmation.\n\n"
                        "N'activez ceci qu'après avoir vérifié, sur plusieurs "
                        "scans, que les alertes reçues sont justes.\n\n"
                        "Activer l'envoi automatique ?"),
                    parent=self.app.root):
                self._floor_push_var.set(False)
                return
        pf["auto_push"] = self._floor_push_var.get()
        cfg.save(self.app.config)
        try:
            self.app._log_journal(
                tr_("🛡️ Protection plancher/plafond : envoi automatique au "
                    "Channel Manager {etat}.").format(
                        etat=tr_("ACTIVÉ") if pf["auto_push"] else tr_("désactivé")),
                level="warning" if pf["auto_push"] else "info",
                engine="FLOOR_AUTO")
        except Exception:
            pass

    def _floor_check_violations(self):
        for w in self._floor_viol_frame.winfo_children():
            w.destroy()
        self._floor_status_lbl.config(text=tr_("Analyse en cours…"), fg=T.YELLOW)
        self.app.root.update_idletasks()

        strat    = self.app.config.get("strategy", {})
        floors   = strat.get("floors", {})
        ceilings = strat.get("ceilings", {})
        if not floors and not ceilings:
            self._floor_status_lbl.config(text=tr_("Aucun plancher ni plafond défini."), fg=T.ORANGE)
            return

        try:
            from business.database import init_db, query_scans
            self._ensure_db_init()
            scans = query_scans(days=3, limit=2000)
        except Exception as e:
            self._floor_status_lbl.config(text=tr_("Erreur base de données : {e}").format(e=e), fg=T.RED)
            return

        violations = []
        for s in scans:
            if s.get("status") != "OK" or not s.get("price") or not s.get("room_type"):
                continue
            room  = s["room_type"]
            price = float(s["price"])
            fl    = floors.get(room)
            cel   = ceilings.get(room)

            if fl and price < fl:
                violations.append({
                    "kind":    "floor",
                    "room":    room,
                    "ota":     s.get("source", "OTA"),
                    "type":    "—",
                    "rate":    0,
                    "scraped": price,
                    "net":     round(price),
                    "limit":   fl,
                    "needed":  fl,
                })

            if cel and price > cel:
                violations.append({
                    "kind":    "ceiling",
                    "room":    room,
                    "ota":     s.get("source", "OTA"),
                    "type":    "—",
                    "rate":    0,
                    "scraped": price,
                    "net":     round(price),
                    "limit":   cel,
                    "needed":  cel,
                })

        # Deduplicate — floor: keep worst per room+ota, ceiling: keep worst per room
        seen = {}
        for v in violations:
            if v["kind"] == "floor":
                k = ("floor", v["room"], v["ota"])
                if k not in seen or v["net"] < seen[k]["net"]:
                    seen[k] = v
            else:
                k = ("ceiling", v["room"])
                if k not in seen or v["scraped"] > seen[k]["scraped"]:
                    seen[k] = v
        violations = list(seen.values())

        if not violations:
            self._floor_status_lbl.config(text=tr_("✓ Aucune violation détectée (3 derniers jours)."), fg=T.GREEN)
            lbl(self._floor_viol_frame,
                "✓ Tous les prix scrapés respectent les planchers et plafonds définis.",
                color=T.GREEN).pack(pady=8)
            return

        nb_floor   = sum(1 for v in violations if v["kind"] == "floor")
        nb_ceiling = sum(1 for v in violations if v["kind"] == "ceiling")
        parts = []
        if nb_floor:   parts.append(tr_("{n} plancher(s) violé(s)").format(n=nb_floor))
        if nb_ceiling: parts.append(tr_("{n} plafond(s) violé(s)").format(n=nb_ceiling))
        self._floor_status_lbl.config(text=f"⚠ {' · '.join(parts)} !", fg=T.RED)
        lbl(self._floor_viol_frame, tr_("⚠ {n} violation(s) détectée(s) :").format(n=len(violations)),
            bold=True, color=T.RED).pack(anchor="w", pady=(6, 4))

        for v in violations:
            is_floor = v["kind"] == "floor"
            border   = T.RED if is_floor else T.ORANGE
            icon     = "🚨" if is_floor else "🔺"
            card = tk.Frame(self._floor_viol_frame, bg=T.ENTRY_BG, padx=10, pady=8,
                            highlightthickness=1, highlightbackground=border)
            card.pack(fill="x", pady=3)

            if is_floor:
                title = f"{icon}  {v['room']}  ·  {v['ota']} ({v['type']} -{v['rate']}%)  — TROP BAS"
                detail = (f"Prix scrapé : {self._csym}{v['scraped']:,.0f}  →  net client : {self._csym}{v['net']:,.0f}  "
                          f"|  Plancher : {self._csym}{v['limit']:,.0f}  |  Déficit : {self._csym}{v['limit']-v['net']:,.0f}")
                tip = f"💡 Envoi au CM ≥ {self._csym}{v['needed']:,.0f}  (plancher, remise OTA appliquée à l'envoi)"
                btn_txt = "↑ Remonter le tarif"
            else:
                title = f"{icon}  {v['room']}  ·  {v['ota']}  — TROP HAUT"
                detail = (f"Prix scrapé : {self._csym}{v['scraped']:,.0f}  |  Plafond : {self._csym}{v['limit']:,.0f}  "
                          f"|  Excès : {self._csym}{v['scraped']-v['limit']:,.0f}")
                tip = f"💡 Envoyer {self._csym}{v['needed']:,.0f} au CM  (= plafond directement)"
                btn_txt = "↓ Baisser le tarif"

            tk.Label(card, text=title, bg=T.ENTRY_BG, fg=border,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w")
            tk.Label(card, text=detail, bg=T.ENTRY_BG, fg=T.FG,
                     font=("Segoe UI", 9)).pack(anchor="w", pady=(4, 2))
            tk.Label(card, text=tip, bg=T.ENTRY_BG, fg=T.YELLOW,
                     font=("Segoe UI", 9)).pack(anchor="w")

            def do_correct(viol=v):
                self._floor_apply_one_correction(viol)
            btn(card, btn_txt, do_correct, color=border, width=18).pack(anchor="w", pady=(6, 0))

        if len(violations) > 1:
            btn(self._floor_viol_frame, tr_("Corriger toutes ({n})").format(n=len(violations)),
                lambda vl=violations: self._floor_apply_all_corrections(vl),
                color=T.RED, width=22).pack(anchor="w", pady=(8, 0))

    def _floor_push_correction(self, violations_list):
        # Couture E4 : routeur de transport (API CM ou Extranet Direct)
        from extranet_bridge import push_rates as push_rates_to_cm_by_ota
        cm_cfg    = self.app.config.get("channel_manager", {})
        rooms_cfg = self.app.config.get("room_inventory", {})

        # For floor violations: pick highest "needed" per room (most protective)
        # For ceiling violations: pick lowest "needed" per room (most restrictive)
        by_room_floor   = {}
        by_room_ceiling = {}
        for v in violations_list:
            room = v["room"]
            if v["kind"] == "floor":
                if room not in by_room_floor or v["needed"] > by_room_floor[room]["needed"]:
                    by_room_floor[room] = v
            else:
                if room not in by_room_ceiling or v["needed"] < by_room_ceiling[room]["needed"]:
                    by_room_ceiling[room] = v

        # Merge: for same room, take max(floor_needed, ceiling_needed) but warn if conflict
        final = {}
        for room, v in by_room_floor.items():
            final[room] = {"needed": v["needed"], "v": v, "kind": "floor"}
        for room, v in by_room_ceiling.items():
            if room in final:
                # Both floor and ceiling violation — take floor (safer, protect revenue)
                final[room]["note"] = f"plafond aussi à {self._csym}{v['needed']:,.0f}"
            else:
                final[room] = {"needed": v["needed"], "v": v, "kind": "ceiling"}

        cm_mapping = cm_cfg.get("room_mapping", {})
        pushes  = []
        skipped = []
        for room, data in final.items():
            m  = cm_mapping.get(room, {})
            rc = (m.get("room_code", "").strip() if isinstance(m, dict) else str(m).strip())
            if not rc:
                skipped.append(room)
                continue
            rate_plans_cfg = m.get("rate_plans", []) if isinstance(m, dict) else []
            if rate_plans_cfg:
                for plan in rate_plans_cfg:
                    rp  = (plan.get("rate_plan_code", "") or "1").strip()
                    ocp = str(plan.get("ota_code", "")).strip()
                    # Apply OTA discount reverse: push = needed / (1 − disc%)
                    # so the OTA displays exactly the floor/ceiling price.
                    try:
                        _disc = float(plan.get("ota_discount_pct", 0) or 0)
                    except (ValueError, TypeError):
                        _disc = 0.0
                    _needed = float(data["needed"])
                    if 0 < _disc < 100:
                        _push_price = round(_needed / (1.0 - _disc / 100.0))
                    else:
                        _push_price = round(_needed)
                    p   = {"room_code": rc, "rate_plan_code": rp,
                           "price": _push_price,
                           "_room": room, "_data": data}
                    if ocp:
                        p["ota_code"] = ocp
                    pushes.append(p)
            else:
                rp = ((m.get("rate_plan_code", "") or "1").strip()
                      if isinstance(m, dict) else "1")
                try:
                    _disc = float(m.get("ota_discount_pct", 0) or 0) \
                        if isinstance(m, dict) else 0.0
                except (ValueError, TypeError):
                    _disc = 0.0
                _needed = float(data["needed"])
                if 0 < _disc < 100:
                    _push_price = round(_needed / (1.0 - _disc / 100.0))
                else:
                    _push_price = round(_needed)
                pushes.append({"room_code": rc, "rate_plan_code": rp,
                               "price": _push_price,
                               "_room": room, "_data": data})

        def _task():
            results = []
            if pushes:
                clean_pushes = [{"room_code": p["room_code"], "rate_plan_code": p["rate_plan_code"],
                                 "price": p["price"], "ota_code": p.get("ota_code", "")}
                                for p in pushes]
                _cm_results = push_rates_to_cm_by_ota(cm_cfg, clean_pushes, log_cb=self.app._log_journal)
                _by_ota = {r["ota_code"]: r for r in _cm_results}
                for p in pushes:
                    v     = p["_data"]["v"]
                    kind  = p["_data"]["kind"]
                    note  = p["_data"].get("note", "")
                    ok    = _by_ota.get(p.get("ota_code", ""), {"ok": False})["ok"]
                    arrow = "↑" if kind == "floor" else "↓"
                    label = tr_("plancher") if kind == "floor" else tr_("plafond")
                    line  = f"{'✓' if ok else '✗'} {arrow}  {p['_room']}  →  {self._csym}{p['price']:,.0f}  ({label} {self._csym}{v['limit']:,.0f})"
                    if note:
                        line += f"  [{note}]"
                    results.append(line)

            def _ui():
                msg_parts = []
                if results:
                    msg_parts.append(tr_("Envois Channel Manager :") + "\n" + "\n".join(results))
                if skipped:
                    msg_parts.append(
                        tr_("⚠ Codes CM manquants (configure dans Channel Manager → Inventaire) :") + "\n"
                        + "\n".join(f"  • {r}" for r in skipped)
                    )
                messagebox.showinfo(tr_("Correction OTA"), "\n\n".join(msg_parts) if msg_parts else tr_("Rien à envoyer."),
                                    parent=self.app.root)
            self.app.root.after(0, _ui)

        threading.Thread(target=_task, daemon=True).start()

    def _floor_apply_one_correction(self, v):
        self._floor_push_correction([v])

    def _floor_apply_all_corrections(self, violations):
        self._floor_push_correction(violations)

    def _floor_auto_check_and_correct(self, alert_only=None):
        """Contrôle plancher/plafond sur les scans du jour.

        BRANCHÉE le 2026-07-22 (audit G2-1) — elle n'avait jusque-là AUCUN
        appelant : la case « Correction automatique au scan » ne déclenchait
        rien du tout.

        alert_only : True  → détecte, journalise et ALERTE (journal + email +
                             Telegram + téléphone), **sans rien envoyer au
                             Channel Manager**.
                     False → alerte ET envoie les corrections au CM.
                     None  → lit `price_floors.auto_push` (défaut **False**,
                             donc alerte seule).

        Le défaut volontairement prudent : cette fonction n'avait jamais tourné,
        son comportement n'est prouvé par aucun usage réel. On observe d'abord
        ce qu'elle détecte, on activera l'envoi ensuite (`auto_push = true`).
        """
        if alert_only is None:
            alert_only = not self.app.config.get("price_floors", {}).get("auto_push", False)
        strat    = self.app.config.get("strategy", {})
        floors   = strat.get("floors", {})
        ceilings = strat.get("ceilings", {})
        if not floors and not ceilings:
            return
        try:
            from business.database import init_db, query_scans
            self._ensure_db_init()
            scans = query_scans(days=1, limit=500)
        except Exception as e:
            # Ne jamais échouer en silence total : la protection auto planchers/
            # plafonds doit laisser une trace si elle ne peut pas tourner, sinon
            # l'utilisateur croit être protégé alors que rien n'est vérifié.
            try:
                self.app._log_journal(
                    f"❌ Correction auto plancher/plafond impossible (BDD) : {e}",
                    level="error", engine="FLOOR_AUTO")
            except Exception:
                pass
            return

        violations = {}
        for s in scans:
            if s.get("status") != "OK" or not s.get("price") or not s.get("room_type"):
                continue
            room  = s["room_type"]
            price = float(s["price"])
            fl    = floors.get(room)
            cel   = ceilings.get(room)

            if fl and price < fl:
                k = ("floor", room)
                if k not in violations or price < violations[k]["scraped"]:
                    violations[k] = {
                        "kind": "floor", "room": room, "ota": s.get("source", "OTA"),
                        "type": "—", "rate": 0, "scraped": price,
                        "net": round(price), "limit": fl, "needed": fl,
                    }

            if cel and price > cel:
                k = ("ceiling", room)
                if k not in violations or price > violations[k]["scraped"]:
                    violations[k] = {
                        "kind": "ceiling", "room": room, "ota": s.get("source", "OTA"),
                        "type": "—", "rate": 0, "scraped": price,
                        "net": round(price), "limit": cel, "needed": cel,
                    }

        if not violations:
            return

        viol_list = list(violations.values())
        # push_ok : None = rien à envoyer (aucun room_code mappé), True/False =
        # résultat réel de l'envoi au Channel Manager — ne jamais annoncer
        # "corrigé" tant que ce n'est pas confirmé True.
        push_ok  = None
        push_msg = ""

        # ── Journal + alerte multi-canaux (toujours, quel que soit le mode) ──
        for _v in viol_list:
            _sens = (tr_("sous le plancher") if _v["kind"] == "floor"
                     else tr_("au-dessus du plafond"))
            try:
                self.app._log_journal(
                    tr_("🛡️ {room} ({ota}) : {csym}{p} {sens} {csym}{lim}", csym=self._csym).format(
                        room=_v["room"], ota=_v["ota"], p=int(_v["scraped"]),
                        sens=_sens, lim=int(_v["limit"])),
                    level="warning", engine="FLOOR_AUTO")
            except Exception:
                pass
        try:
            # Alerte email + Telegram + TÉLÉPHONE (app compagnon).
            # `triggers` est forcé : c'est la case « Correction automatique au
            # scan » qui fait office d'autorisation — l'alerte ne doit pas
            # dépendre en plus d'un déclencheur non configuré dans Paramètres.
            from business.notifications import send_notifications
            send_notifications("floor_violation", violations, self.app.config,
                               triggers={"floor_violation": True})
        except Exception:
            logging.exception("Alerte plancher/plafond : envoi échoué")

        if alert_only:
            self._push_alert(
                "vae", "floor_violation",
                tr_("🛡️ {n} prix hors bornes détecté(s) — alerte seule, "
                    "rien envoyé au CM").format(n=len(viol_list)),
                priority="high",
                data={"violations": len(viol_list)})
            return

        def _task():
            push_ok  = None
            push_msg = ""
            try:
                # Couture E4 : routeur de transport (API CM ou Extranet Direct)
                from extranet_bridge import push_rates as push_rates_to_cm_by_ota
                cm_cfg     = self.app.config.get("channel_manager", {})
                cm_mapping = cm_cfg.get("room_mapping", {})
                by_room = {}
                for v in viol_list:
                    room = v["room"]
                    if room not in by_room:
                        by_room[room] = v
                    elif v["kind"] == "floor" and v["needed"] > by_room[room]["needed"]:
                        by_room[room] = v
                pushes = []
                for room, v in by_room.items():
                    m  = cm_mapping.get(room, {})
                    rc = (m.get("room_code", "").strip() if isinstance(m, dict) else str(m).strip())
                    if not rc:
                        continue
                    rate_plans_cfg = m.get("rate_plans", []) if isinstance(m, dict) else []
                    if rate_plans_cfg:
                        for plan in rate_plans_cfg:
                            rp  = (plan.get("rate_plan_code", "") or "1").strip()
                            ocp = str(plan.get("ota_code", "")).strip()
                            p   = {"room_code": rc, "rate_plan_code": rp, "price": float(v["needed"])}
                            if ocp:
                                p["ota_code"] = ocp
                            pushes.append(p)
                    else:
                        rp = ((m.get("rate_plan_code", "") or "1").strip()
                              if isinstance(m, dict) else "1")
                        pushes.append({"room_code": rc, "rate_plan_code": rp,
                                       "price": float(v["needed"])})
                if pushes:
                    _cm_results = push_rates_to_cm_by_ota(cm_cfg, pushes, log_cb=self.app._log_journal)
                    push_ok  = all(r["ok"] for r in _cm_results) if _cm_results else False
                    push_msg = " | ".join(
                        f"{'✅' if r['ok'] else '✗'} {r['ota_code'] or 'toutes OTA'} : {r['msg']}"
                        for r in _cm_results)
            except Exception as e:
                push_ok, push_msg = False, str(e)

            nb_floor   = sum(1 for v in viol_list if v["kind"] == "floor")
            nb_ceiling = sum(1 for v in viol_list if v["kind"] == "ceiling")
            parts = []
            if nb_floor:   parts.append(f"↑{nb_floor} plancher")
            if nb_ceiling: parts.append(f"↓{nb_ceiling} plafond")

            if push_ok:
                self._push_alert(
                    "vae", "floor_correction",
                    f"🛡️ Prix OTA corrigés ({', '.join(parts)})",
                    priority="medium",
                    data={"floor": nb_floor, "ceiling": nb_ceiling},
                )
            elif push_ok is False:
                # L'envoi au Channel Manager a réellement échoué (ou a levé une
                # exception) — ne jamais annoncer "corrigé" dans ce cas, sinon
                # l'hôtel croit le plancher/plafond appliqué alors que le prix
                # envoyé au CM n'a jamais été confirmé.
                self._push_alert(
                    "vae", "floor_correction_failed",
                    f"❌ Correction OTA échouée ({', '.join(parts)}) — {push_msg}",
                    priority="high",
                    data={"floor": nb_floor, "ceiling": nb_ceiling},
                )

        threading.Thread(target=_task, daemon=True).start()

    # ══════════════════════════════════════════════════════════════════════
    # Section Prix par OTA — Channel Manager (envoi manuel)
    # ══════════════════════════════════════════════════════════════════════

    def _build_cm_ota_section(self, parent):
        """Section fusionnée Prix par OTA + Automatic update :
        seuils plancher/plafond, trigger, heure fixe, période → push CM."""

        cm_cfg     = self.app.config.get("channel_manager", {})
        mapping    = cm_cfg.get("room_mapping", {})
        rooms_cfg  = self.app.config.get("room_inventory", {})
        room_types = [r for r in self.app.config.get("room_types", [])
                      if r and r.lower() != "move room"]

        # Collecter toutes les OTAs (sauf Agoda) depuis le mapping CM.
        # Construire en parallèle un index name-lower → (name, code) pour
        # le rapprochement avec les OTAs surveillées dans OTA Watch.
        seen_otas      = {}                       # ota_name -> ota_code
        _rp_by_name_lc = {}                       # name_lower → (name, code)
        for rm_data in mapping.values():
            if isinstance(rm_data, dict):
                for rp in rm_data.get("rate_plans", []):
                    name = rp.get("ota_name", "").strip()
                    code = str(rp.get("ota_code", "")).strip()
                    if name and code and name.lower() != "agoda":
                        seen_otas[name] = code
                    if name:
                        _lc = name.lower()
                        if _lc != "agoda" and _lc not in _rp_by_name_lc:
                            _rp_by_name_lc[_lc] = (name, code)

        # Synchroniser avec les OTAs actives de OTA Watch : une OTA
        # surveillée dans Brave doit aussi apparaître ici pour que
        # l'utilisateur puisse définir son prix / seuils — même si le
        # rate_plan correspondant n'a pas encore d'ota_code renseigné.
        _ota_watch_cfg = self.app.config.get("ota_watch", {})
        for _o in _ota_watch_cfg.get("otas", []):
            if not _o.get("active", True):
                continue
            _on = (_o.get("name") or "").strip()
            if not _on or _on.lower() == "agoda":
                continue
            if _on in seen_otas:
                continue
            # Rapprochement insensible à la casse avec les rate_plans
            _match = _rp_by_name_lc.get(_on.lower())
            if _match:
                seen_otas[_match[0]] = _match[1]
            elif _on not in seen_otas:
                seen_otas[_on] = ""  # carte affichée, code cherché au push

        if not seen_otas or not room_types:
            return

        ota_prices_cfg = self.app.config.setdefault("cm_ota_prices", {})

        tk.Frame(parent, bg=T.SEL_BG, height=2).pack(fill="x", padx=10, pady=(16, 10))

        s = section(parent, tr_("📡 Prix par OTA — Channel Manager"))
        s.pack(fill="x", padx=10, pady=6)
        lbl(s,
            "Définissez les prix et seuils par chambre pour chaque OTA. "
            "OTA Guard applique les corrections plancher/plafond avant envoi au CM.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 2))
        lbl(s,
            "Passe par ton Channel Manager (une seule connexion) qui redistribue "
            "ensuite vers les OTAs — différent de \"OTA Direct Push\" qui parle "
            "directement à chaque OTA sans passer par le CM.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 8))

        self._cm_ota_vars = {}
        # Littéraux passés directement à tr_() — nécessaire pour que
        # tools/i18n_extract.py découvre ces chaînes (le menu déroulant
        # affiche le texte traduit, mais la sauvegarde compare toujours
        # aux clés canoniques "manual"/"daily_once").
        _TRIG_DISP_INV = {"manual":     tr_("Manuel — je clique moi-même"),
                          "daily_once": tr_("Une fois par jour à heure fixe")}
        _TRIG_DISP = [_TRIG_DISP_INV["manual"], _TRIG_DISP_INV["daily_once"]]
        _TRIG_KEY  = {v: k for k, v in _TRIG_DISP_INV.items()}

        for ota_name, ota_code in sorted(seen_otas.items()):
            ota_cfg = ota_prices_cfg.setdefault(ota_name, {
                "ota_code": ota_code, "rooms": {}})
            ota_cfg["ota_code"] = ota_code

            # ── Carte OTA ──────────────────────────────────────────────
            card = tk.Frame(s, bg=T.SEL_BG, padx=10, pady=8,
                            highlightthickness=1, highlightbackground=T.ACCENT)
            card.pack(fill="x", pady=4)

            # ── Header ─────────────────────────────────────────────────
            h = tk.Frame(card, bg=T.SEL_BG); h.pack(fill="x", pady=(0, 6))
            _en_v = tk.BooleanVar(value=ota_cfg.get("enabled", False))
            _tag  = status_badge(
                h,
                tr_("✅ ACTIF") if _en_v.get() else tr_("⏸ INACTIF"),
                T.GREEN if _en_v.get() else "#888888")
            tk.Checkbutton(h, variable=_en_v, bg=T.SEL_BG,
                           activebackground=T.SEL_BG,
                           selectcolor=T.SEL_BG).pack(side="left")
            lbl(h, ota_name, bold=True, size=10, bg=T.SEL_BG).pack(side="left")
            _tag.pack(side="left", padx=8)
            lbl(h, tr_("Code CM : {code}").format(code=ota_code), color="#888888", size=8,
                bg=T.SEL_BG).pack(side="left", padx=(4, 0))

            def _make_toggle(tl, bv):
                def _cb(*_):
                    tl.config(text=tr_("✅ ACTIF") if bv.get() else tr_("⏸ INACTIF"),
                              bg=T.GREEN if bv.get() else "#888888",
                              fg=_btn_fg(T.GREEN if bv.get() else "#888888"))
                return _cb
            _en_v.trace_add("write", _make_toggle(_tag, _en_v))

            result_lbl = tk.Label(h, text="", bg=T.SEL_BG, fg=T.GREEN,
                                  font=("Segoe UI", 9))
            result_lbl.pack(side="right", padx=(8, 4))
            btn(h, tr_("📤 Pousser"),
                lambda _on=ota_name, _oc=ota_code:
                    self._send_cm_ota_prices(
                        _on, _oc,
                        self._cm_ota_vars.get(_on, {}).get("rooms", {}),
                        self._cm_ota_vars.get(_on, {}).get("result_lbl")),
                color="#cba6f7", width=10).pack(side="right")

            # ── Tableau prix/seuils (grid pleine largeur) ───────────────
            table_f = tk.Frame(card, bg=T.SEL_BG)
            table_f.pack(fill="x", pady=(0, 6))
            table_f.columnconfigure(0, weight=4)
            table_f.columnconfigure(1, weight=2)
            table_f.columnconfigure(2, weight=2)
            table_f.columnconfigure(3, weight=2)
            table_f.columnconfigure(4, weight=3)

            for c, txt in enumerate(["Chambre", f"Plancher {self._csym}",
                                     f"Prix {self._csym}", f"Plafond {self._csym}", "Dernier envoi"]):
                tk.Label(table_f, text=txt, bg=T.BG, fg=T.ACCENT,
                         font=("Segoe UI", 9, "bold"), anchor="center"
                         ).grid(row=0, column=c, sticky="ew", padx=2, pady=(0, 3))

            room_vars = {}
            for ridx, room in enumerate(room_types, start=1):
                room_cfg  = ota_cfg["rooms"].setdefault(room, {})
                inv       = rooms_cfg.get(room, {})
                floor_d   = float(room_cfg.get("floor",   inv.get("floor",   0)))
                ceil_d    = float(room_cfg.get("ceiling", inv.get("ceiling", 999999)))
                last_s    = room_cfg.get("last_sent", "")
                price_d   = room_cfg.get("price", "")

                floor_v   = tk.StringVar(value=str(int(floor_d)) if floor_d else "")
                current_v = tk.StringVar(
                    value=str(int(float(price_d))) if price_d else "")
                ceiling_v = tk.StringVar(
                    value=str(int(ceil_d)) if ceil_d < 999999 else "")

                tk.Label(table_f, text=room, bg=T.SEL_BG, fg=T.FG,
                         font=("Segoe UI", 9), anchor="w"
                         ).grid(row=ridx, column=0, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=floor_v, bg=T.ENTRY_BG,
                         fg=T.GREEN, relief="flat", font=("Segoe UI", 9)
                         ).grid(row=ridx, column=1, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=current_v, bg=T.ENTRY_BG,
                         fg=T.ACCENT, relief="flat",
                         font=("Segoe UI", 9, "bold")
                         ).grid(row=ridx, column=2, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=ceiling_v, bg=T.ENTRY_BG,
                         fg="#e06c75", relief="flat", font=("Segoe UI", 9)
                         ).grid(row=ridx, column=3, sticky="ew", padx=2, pady=1)
                st = tk.Label(table_f, text=fmt_dt(last_s) if last_s else "—",
                              bg=T.SEL_BG, fg="#888888",
                              font=("Segoe UI", 8), anchor="w")
                st.grid(row=ridx, column=4, sticky="ew", padx=2, pady=1)
                room_vars[room] = {"floor": floor_v, "current": current_v,
                                   "ceiling": ceiling_v, "status": st}

            # ── Trigger + Heure ─────────────────────────────────────────
            _tr_row = tk.Frame(card, bg=T.SEL_BG)
            _tr_row.pack(fill="x", pady=(4, 2))
            _tr_row.columnconfigure(1, weight=1)
            tk.Label(_tr_row, text=tr_("Déclencheur :"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).grid(row=0, column=0, sticky="w", padx=(0, 8))
            _trf = tk.Frame(_tr_row, bg=T.SEL_BG)
            _trf.columnconfigure(0, weight=1)
            _trf.grid(row=0, column=1, sticky="ew")
            _trig_v = tk.StringVar(
                value=_TRIG_DISP_INV.get(ota_cfg.get("trigger", "manual"),
                                          "Manuel — je clique moi-même"))
            ttk.Combobox(_trf, textvariable=_trig_v,
                         values=_TRIG_DISP, state="readonly"
                         ).grid(row=0, column=0, sticky="ew", padx=(0, 12))
            tk.Label(_trf, text=tr_("Heure :"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).grid(row=0, column=1, sticky="w", padx=(0, 6))
            _time_v = tk.StringVar(value=ota_cfg.get("time", "12:00"))
            tk.Entry(_trf, textvariable=_time_v, width=7,
                     bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                     font=("Segoe UI", 9)
                     ).grid(row=0, column=2, sticky="w")

            # ── Période : presets + date libre ──────────────────────────
            _dt_row = tk.Frame(card, bg=T.SEL_BG)
            _dt_row.pack(fill="x", pady=(2, 6))
            tk.Label(_dt_row, text=tr_("Période :"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).pack(side="left", padx=(0, 8))
            _date_v = tk.StringVar(value=fmt_dt(ota_cfg.get("date_to", ""), with_time=False))
            for _days, _lbl in [(3, "+3j"), (7, "+7j"), (15, "+15j"), (30, "+30j")]:
                def _set_date(d=_days, v=_date_v):
                    from datetime import timedelta as _tdd
                    v.set((datetime.now() + _tdd(days=d)).strftime("%d/%m/%Y"))
                tk.Button(_dt_row, text=_lbl, command=_set_date,
                          bg=T.SEL_BG, fg=T.ACCENT, relief="flat",
                          font=("Segoe UI", 9, "bold"),
                          cursor="hand2", bd=0, padx=6
                          ).pack(side="left", padx=2)
            tk.Label(_dt_row, text=tr_("ou"), bg=T.SEL_BG, fg="#888888",
                     font=("Segoe UI", 8)).pack(side="left", padx=8)
            tk.Entry(_dt_row, textvariable=_date_v, width=12,
                     bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                     font=("Segoe UI", 9)).pack(side="left")

            # ── Majoration jours ─────────────────────────────────────
            _wknd_row = tk.Frame(card, bg=T.SEL_BG)
            _wknd_row.pack(fill="x", pady=(2, 2))
            _wknd_en_v  = tk.BooleanVar(value=ota_cfg.get("weekend_markup_enabled", False))
            _wknd_pct_v = tk.StringVar(value=str(ota_cfg.get("weekend_markup_pct", 20)))
            tk.Checkbutton(_wknd_row, text=tr_("🗓️ Majoration :"),
                           variable=_wknd_en_v,
                           bg=T.SEL_BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                           activebackground=T.SEL_BG,
                           font=("Segoe UI", 9)).pack(side="left", padx=(0, 4))
            _DAY_FR_OTA = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
            _saved_days_ota = ota_cfg.get("weekend_days", [4, 5])
            _wknd_days_v = []
            for _di, _dl in enumerate(_DAY_FR_OTA):
                _ddv = tk.BooleanVar(value=_di in _saved_days_ota)
                tk.Checkbutton(_wknd_row, text=_dl, variable=_ddv,
                               bg=T.SEL_BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.SEL_BG,
                               font=("Segoe UI", 8)).pack(side="left", padx=(1, 0))
                _wknd_days_v.append(_ddv)
            lbl(_wknd_row, "  +", bold=True, size=9, bg=T.SEL_BG).pack(side="left", padx=(4, 2))
            tk.Spinbox(_wknd_row, textvariable=_wknd_pct_v,
                       from_=0, to=100, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 9)
                       ).pack(side="left", padx=(0, 2))
            lbl(_wknd_row, "%", size=9, bg=T.SEL_BG).pack(side="left")

            # ── Bouton sauvegarder ──────────────────────────────────────
            btn_row = tk.Frame(card, bg=T.SEL_BG); btn_row.pack(fill="x", pady=(2, 0))
            btn(btn_row, tr_("💾 Sauvegarder"),
                lambda _on=ota_name, _rv=room_vars, _rl=result_lbl,
                       _ev=_en_v, _tv=_trig_v, _tmv=_time_v, _dv=_date_v,
                       _km=_TRIG_KEY, _wen=_wknd_en_v, _wpct=_wknd_pct_v,
                       _wdays=_wknd_days_v:
                    self._save_cm_ota_floors(_on, _rv, _rl, _ev, _tv, _tmv, _dv, _km,
                                             _wen, _wpct, _wdays),
                color=T.ACCENT, width=16).pack(side="right", padx=4)

            self._cm_ota_vars[ota_name] = {
                "rooms":      room_vars,
                "result_lbl": result_lbl,
                "enabled":    _en_v,
                "trigger":    _trig_v,
                "time":       _time_v,
                "date":       _date_v,
                "wknd_en":    _wknd_en_v,
                "wknd_pct":   _wknd_pct_v,
                "wknd_days":  _wknd_days_v,
            }

    def _save_cm_ota_floors(self, ota_name, room_vars, result_lbl=None,
                             enabled_v=None, trigger_v=None, time_v=None,
                             date_v=None, trig_key_map=None,
                             wknd_en_v=None, wknd_pct_v=None, wknd_days_v=None):
        """Sauvegarde seuils + trigger/heure/période dans cm_ota_prices."""
        try:
            ota_data  = self.app.config.setdefault("cm_ota_prices", {}) \
                                       .setdefault(ota_name, {"rooms": {}})
            ota_rooms = ota_data.setdefault("rooms", {})
            saved  = []
            errors = []

            # ── Seuils et prix par chambre ──────────────────────────────
            for room, v in room_vars.items():
                try:
                    fl = float(v["floor"].get() or 0)
                    ce_raw = v["ceiling"].get().strip()
                    ce = float(ce_raw) if ce_raw else 999999
                    if fl > ce:
                        errors.append(f"{room}: plancher({int(fl)}) > plafond({int(ce)})")
                        continue
                    ota_rooms.setdefault(room, {})
                    ota_rooms[room]["floor"]   = fl
                    ota_rooms[room]["ceiling"] = ce
                    raw_price = v["current"].get().strip()
                    if raw_price:
                        ota_rooms[room]["price"] = float(raw_price)
                    saved.append(f"{room}: {int(fl)}–{int(ce)}")
                except Exception as e_room:
                    errors.append(f"{room}: {e_room}")

            # ── Trigger / heure / période / enabled ─────────────────────
            if enabled_v is not None:
                ota_data["enabled"] = bool(enabled_v.get())
            if trigger_v is not None and trig_key_map is not None:
                ota_data["trigger"] = trig_key_map.get(
                    trigger_v.get(), "manual")
            if time_v is not None:
                ota_data["time"] = (time_v.get().strip() or "12:00")
            if date_v is not None:
                # Field displays d/m/y; consumers (fromisoformat, OTA URLs)
                # need ISO — normalize on save.
                ota_data["date_to"] = parse_dt_any(date_v.get().strip())
            if wknd_en_v is not None:
                ota_data["weekend_markup_enabled"] = bool(wknd_en_v.get())
            if wknd_pct_v is not None:
                try:
                    ota_data["weekend_markup_pct"] = max(0.0, float(
                        wknd_pct_v.get().replace(",", ".")))
                except Exception:
                    ota_data["weekend_markup_pct"] = 20.0
            if wknd_days_v is not None:
                ota_data["weekend_days"] = [
                    i for i, v in enumerate(wknd_days_v) if v.get()]

            cfg.save(self.app.config)

            msg_parts = []
            if saved:
                msg_parts.append("✅ Seuils sauvegardés")
            if errors:
                msg_parts.append("⚠ " + " | ".join(errors))
            final_msg = " | ".join(msg_parts) if msg_parts else "✅ OK"

            if result_lbl:
                result_lbl.config(
                    text=final_msg,
                    fg=T.GREEN if not errors else T.ORANGE)
                if not errors:
                    self.app.root.after(4000, lambda: result_lbl.config(text=""))

        except Exception as e_save:
            from tkinter import messagebox as _mb
            _mb.showerror("Erreur sauvegarde",
                          f"OTA : {ota_name}\nErreur : {e_save}")
            if result_lbl:
                result_lbl.config(text=f"❌ {e_save}", fg=T.RED)

    def _send_cm_ota_prices(self, ota_name, ota_code, room_vars, result_lbl):
        """Envoie les prix saisis pour une OTA vers le CM avec OTACode."""
        from business.channel_manager import push_rates_to_cm, build_rate_push_json
        try:
            from business.app_logger import app_log as _alog
        except Exception:
            _alog = lambda *a, **k: None

        cm_cfg = self.app.config.get("channel_manager", {})
        _alog(f"[CM-OTA] Démarrage envoi OTA={ota_name} code={ota_code} "
              f"token={'OUI' if cm_cfg.get('api_token') else 'NON'} "
              f"hotel={cm_cfg.get('hotel_id','?')} "
              f"test_mode={cm_cfg.get('test_mode', False)}",
              level="info", engine="CM-OTA")
        mapping = cm_cfg.get("room_mapping", {})
        pushes  = []
        skipped = []
        warnings = []

        for room, v in room_vars.items():
            raw = v["current"].get().strip()
            if not raw:
                skipped.append(room)
                continue
            try:
                price = float(raw.replace(",", ".").replace(" ", ""))
            except ValueError:
                skipped.append(room)
                continue

            # Floor / ceiling are informational bounds only in this
            # section — the user explicitly sets the price to send.
            # No clamping: send the Price column value as-is.
            try:
                floor   = float(v["floor"].get())
                ceiling = float(v["ceiling"].get())
            except (ValueError, TypeError):
                floor, ceiling = 0, 999999

            if floor and price < floor:
                warnings.append(f"{room} < {self._csym}{int(floor)} (plancher)")
            if ceiling < 999999 and price > ceiling:
                warnings.append(f"{room} > {self._csym}{int(ceiling)} (plafond)")

            rm = mapping.get(room, {})
            if not isinstance(rm, dict):
                skipped.append(room)
                continue
            rc = rm.get("room_code", "").strip()
            if not rc:
                skipped.append(room)
                continue
            # Trouver rate_plan_code pour cet OTA code
            rp = next((p.get("rate_plan_code", "")
                       for p in rm.get("rate_plans", [])
                       if str(p.get("ota_code", "")) == str(ota_code)), "")
            if not rp:
                rp = next((p.get("rate_plan_code", "")
                           for p in rm.get("rate_plans", [])), "3628")

            pushes.append({"room_code": rc, "rate_plan_code": rp,
                           "ota_code": ota_code, "price": price, "_room": room})

        if not pushes:
            result_lbl.config(text=tr_("⚠ Aucun prix saisi."), fg=T.ORANGE)
            return

        result_lbl.config(text=tr_("⏳ Envoi en cours…"), fg=T.YELLOW)

        # Lire majoration weekend depuis l'UI (avant le thread)
        _ota_ui   = self._cm_ota_vars.get(ota_name, {})
        _wknd_var = _ota_ui.get("wknd_en")
        _wknd_en  = bool(_wknd_var.get()) if _wknd_var is not None else False
        _wpct_var = _ota_ui.get("wknd_pct")
        try:
            _wknd_pct = float(_wpct_var.get().replace(",", ".")) if _wpct_var else 20.0
        except Exception:
            _wknd_pct = 20.0
        _wdays_list = _ota_ui.get("wknd_days") or []
        _wknd_days  = [i for i, v in enumerate(_wdays_list) if v.get()] if _wdays_list else [4, 5]

        def _task():
            import json as _json, requests as _req
            clean = [{"room_code": p["room_code"],
                      "rate_plan_code": p["rate_plan_code"],
                      "ota_code": p["ota_code"],
                      "price":    p["price"]} for p in pushes]
            try:
                # Calculer nights depuis la date de fin configurée
                _date_to_str = (self.app.config
                                .get("cm_ota_prices", {})
                                .get(ota_name, {})
                                .get("date_to", ""))
                try:
                    from datetime import timedelta as _tdd2
                    if _date_to_str:
                        _nights = max(1, (
                            datetime.fromisoformat(_date_to_str) - datetime.now()
                        ).days)
                    else:
                        _nights = 90
                except Exception:
                    _nights = 90
                # Appliquer majoration weekend + sauter dates verrouillées
                _today = datetime.now().date().isoformat()
                try:
                    from business.price_calendar import get_locked_dates
                    _cal_locked = get_locked_dates(self.app.config, _today, _nights)
                except Exception:
                    _cal_locked = set()

                if _wknd_en or _cal_locked:
                    from business.channel_manager import segments_skipping_locked as _ssl
                    _wknd_cfg = {"enabled": _wknd_en, "pct": _wknd_pct,
                                 "weekend_days": _wknd_days}
                    _expanded = []
                    for _e in clean:
                        for _fd, _td, _pr in _ssl(
                                _e["price"], _today, _nights,
                                _cal_locked, _wknd_cfg):
                            _expanded.append({**_e, "price": _pr,
                                              "from_date": _fd, "to_date": _td})
                    if _expanded:
                        clean = _expanded

                payload = build_rate_push_json(cm_cfg, clean, nights=_nights)

                endpoint = cm_cfg.get("endpoint", "").strip()
                token    = cm_cfg.get("api_token", "").strip()
                headers  = {"Content-Type": "application/json"}
                if token:
                    headers["Authorization"] = f"Bearer {token}"
                try:
                    headers.update(_json.loads(cm_cfg.get("headers", "{}")))
                except Exception:
                    pass

                _alog(f"[CM-OTA] JSON → {_json.dumps(payload, ensure_ascii=False)[:600]}",
                      level="info", engine="CM-OTA")

                r    = _req.post(endpoint, headers=headers, json=payload, timeout=20)
                body = r.text[:1000]
                try:
                    data = r.json()
                    ok   = data.get("APIResponse", {}).get("IsSuccess",
                                                           r.status_code < 300)
                    msg  = data.get("APIResponse", {}).get("APIResponseText",
                                                           f"HTTP {r.status_code}")
                except Exception:
                    ok  = r.status_code < 300
                    msg = f"HTTP {r.status_code}"
                _alog(f"[CM-OTA] Réponse : ok={ok}  msg={msg}  body={body[:300]}",
                      level="ok" if ok else "error", engine="CM-OTA")
            except Exception as _e:
                _alog(f"[CM-OTA] EXCEPTION : {_e}", level="error", engine="CM-OTA")
                ok, msg, body = False, str(_e), ""

            now    = datetime.now().strftime("%d/%m %H:%M")
            now_ts = datetime.now().strftime("%Y-%m-%d %H:%M")
            rooms_str  = ", ".join(p["_room"] for p in pushes)
            prices_str = ", ".join(f"{self._csym}{int(p['price']):,}" for p in pushes)

            # self.app.config est partagé avec le thread principal (autres
            # sauvegardes possibles en parallèle) — muter + cfg.save() ici,
            # dans le thread de fond, exposait à une course avec le
            # copy.deepcopy() interne de core/config.py::save(). On marshale
            # sur le thread principal via after(), comme _cm_record_push
            # dans app_core.py.
            def _persist():
                ota_rooms = self.app.config.setdefault(
                    "cm_ota_prices", {}).setdefault(ota_name, {}).setdefault("rooms", {})
                for p in pushes:
                    ota_rooms.setdefault(p["_room"], {})["last_sent"] = \
                        f"{self._csym}{int(p['price']):,} — {now}"

                hist_entry = {
                    "ts":     now_ts,
                    "ok":     ok,
                    "source": ota_name,
                    "rooms":  rooms_str,
                    "prices": prices_str,
                    "msg":    msg[:80],
                }
                hist = self.app.config.setdefault(
                    "channel_manager", {}).setdefault("push_history", [])
                hist.insert(0, hist_entry)
                if len(hist) > 100:
                    del hist[100:]
                cfg.save(self.app.config)
            self.app.root.after(0, _persist)

            def _update():
                for p in pushes:
                    room_vars[p["_room"]]["status"].config(
                        text=f"{self._csym}{int(p['price']):,} {now}",
                        fg=T.GREEN if ok else T.RED)
                parts = [f"✅ {len(pushes)} chambre(s)" if ok else f"❌ {msg[:80]}"]
                if warnings:
                    parts.append(f"ℹ Hors seuils : {', '.join(warnings)}")
                result_lbl.config(text=" | ".join(parts),
                                  fg=T.GREEN if ok else T.RED)
                try:
                    self._cm_refresh_history()
                except Exception:
                    pass
            self.app.root.after(0, _update)

        threading.Thread(target=_task, daemon=True).start()








