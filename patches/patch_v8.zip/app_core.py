"""
AppCore — méthodes métier nécessaires à OTA Guard.
Toutes les méthodes appelées par les tabs via BaseTab.__getattr__ sont ici.
"""
import json
import logging
import threading
import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from pathlib import Path

from core import config as cfg
from core.utils import tr_
from core.utils import set_currency
from core.utils import get_currency_symbol

from core.paths import DATA_DIR, INSTALL_DIR
LAST_SCAN_FILE = DATA_DIR / "last_scan.json"


class AppCore:

    # ── Thread-safe UI call ───────────────────────────────────────────────

    def _ui_call(self, fn):
        try:
            self.root.after(0, fn)
        except (RuntimeError, tk.TclError):
            pass

    # ── Devise ───────────────────────────────────────────────────────────

    def _apply_currency(self, code: str, rate=None):
        try:
            set_currency(code, float(rate) if rate else 1.0)
        except Exception:
            pass

    # ── Dernier scan ─────────────────────────────────────────────────────

    def _load_last_scan(self):
        try:
            if LAST_SCAN_FILE.exists():
                with open(LAST_SCAN_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save_last_scan(self, results):
        try:
            with open(LAST_SCAN_FILE, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False)
        except Exception:
            logging.exception("_save_last_scan échoué")

    # ── Base de données ───────────────────────────────────────────────────

    def _ensure_db_init(self):
        if getattr(self, "_db_init_done", False):
            return
        try:
            from business.database import init_db
            init_db()
        except Exception:
            logging.exception("init_db échoué")
        self._db_init_done = True

    # ── Alertes ───────────────────────────────────────────────────────────

    def _push_alert(self, motor: str, alert_type: str, message: str,
                    priority: str = "info", data: dict = None):
        entry = {
            "motor":    motor,
            "type":     alert_type,
            "message":  message,
            "priority": priority,
            "data":     data or {},
            "date":     datetime.now().strftime("%H:%M:%S"),
        }
        def _apply():
            self._all_alerts.append(entry)
            if len(self._all_alerts) > 500:
                self._all_alerts = self._all_alerts[-500:]
            try:
                self._log_journal(f"[{motor}] {message}")
            except Exception:
                pass
        try:
            self.root.after(0, _apply)
        except (RuntimeError, tk.TclError):
            pass

    # ── Journal ───────────────────────────────────────────────────────────

    def _log_journal(self, message: str, level: str = "info", engine: str = ""):
        try:
            with self._journal_lock:
                self._journal_entries.append(
                    f"{datetime.now().strftime('%H:%M:%S')}  {message}"
                )
                if len(self._journal_entries) > 2000:
                    self._journal_entries = self._journal_entries[-2000:]
        except Exception:
            pass
        try:
            from business.app_logger import app_log
            app_log(message, level=level, engine=engine)
        except Exception:
            pass

    # ── Threads de travail (D33 : l'Exit les arrête et les attend) ────────

    def _spawn(self, target):
        """Lance un thread de travail daemon ET l'enregistre. Avant D33,
        l'Exit fermait la fenêtre mais des threads non-daemon (firebase,
        listener) gardaient le processus en vie : un push a continué
        85 minutes derrière une fenêtre fermée (27/08 16:04→17:29)."""
        import threading as _th
        t = _th.Thread(target=target, daemon=True)
        try:
            self._workers.append(t)
        except AttributeError:
            self._workers = [t]
        t.start()
        return t

    def join_workers(self, timeout: float = 8.0):
        """Attend la fin des threads de travail (budget total `timeout`).
        Appelé par l'Exit après request_shutdown() : les files s'arrêtent
        avant leur tâche suivante, on leur laisse le temps de finir
        proprement celle en cours."""
        import time as _time
        _end = _time.time() + timeout
        for t in getattr(self, "_workers", []):
            try:
                if t.is_alive():
                    t.join(timeout=max(0.1, _end - _time.time()))
            except RuntimeError:
                pass

    # ── Push Channel Manager ──────────────────────────────────────────────

    def _do_push(self, valid_results, cm, checkin, nights, log_widget=None,
                 silent=False, on_done=None, source="Manuel", weekend_markup=None,
                 ota_filter=None):
        try:
            from licensing.license_checker import _ck
            if not _ck():
                if on_done:
                    on_done(False, "")
                return
        except Exception:
            pass
        # Couture E4 (Extranet Direct) : le routeur choisit le transport —
        # API CM classique, ou pilotage du vrai formulaire si
        # channel_manager.extranet_direct.enabled. Contrat identique.
        from extranet_bridge import push_rates as _push_transport
        import extranet_bridge as _xb_ops

        # D52 : une seule opération — refus immédiat si scan/push en cours
        if _xb_ops.operation_current():
            _msg52 = ("Impossible : un {k} est en cours (depuis {s}) — une "
                      "seule opération à la fois, attendez sa fin.").format(
                k=_xb_ops.operation_current(), s=_xb_ops.operation_since())
            if not silent:
                messagebox.showwarning(tr_("Push CM"), _msg52, parent=self.root)
            if on_done:
                on_done(False, _msg52)
            return

        def _progress52(done, total, label):
            """Progression de la file extranet -> barre UI (thread-safe)."""
            try:
                self.root.after(0, lambda: self._push_progress(done, total,
                                                               label))
            except Exception:
                pass

        _endpoint = (cm.get("endpoint") or cm.get("api_url") or "").strip()
        if not _endpoint:
            if not silent:
                messagebox.showwarning(
                    tr_("Push CM"),
                    tr_("Channel Manager non configuré : l'URL endpoint est vide.\n"
                        "Renseigne-la dans Configuration → Channel Manager."),
                    parent=self.root)
            if on_done:
                on_done(False, "Endpoint CM vide")
            return

        if not valid_results:
            if not silent:
                messagebox.showwarning(
                    tr_("Push CM"),
                    tr_("Aucun résultat de scan disponible.\n"
                        "Lancez d'abord un scan depuis l'onglet Blocage prix OTA,\n"
                        "ou utilisez le push par chambre dans Configuration → Channel Manager."),
                    parent=self.root)
            if on_done:
                on_done(False, "Aucun résultat de scan")
            return

        mapping         = cm.get("room_mapping", {})
        strat_floors    = self.config.get("strategy", {}).get("floors", {})
        strat_ceilings  = self.config.get("strategy", {}).get("ceilings", {})
        room_pushes     = []
        skipped         = []
        skipped_ceiling = []
        filtered_out = 0        # rate plans écartés par ota_filter (message d'erreur)
        per_ota_summary = {}    # ota_code/nom → {"name": ota_name, "rooms": {room: prix}}

        # Durée d'application (jours) — vient du réglage « pendant : N jour(s) »
        # de Blocage OTA via le paramètre `nights` (défaut appelants : 90 ou 1).
        try:
            _total_days = max(1, min(365, int(nights)))
        except (ValueError, TypeError):
            _total_days = 90
        # Mode weekend : la durée est découpée en lots de 15 jours max — même
        # taille de requête CM qu'avant, mais la durée demandée est respectée
        # (l'ancien code figeait 2 lots de 15 j quel que soit `nights`).
        _lots = []                # [(checkin_iso, nb_jours)]
        _cursor = datetime.fromisoformat(checkin).date()
        _left = _total_days
        while _left > 0:
            _span = min(15, _left)
            _lots.append((_cursor.isoformat(), _span))
            _cursor += timedelta(days=_span)
            _left -= _span
        lot_pushes = [[] for _ in _lots]

        # Locked dates from annual price calendar — D+ push skips these
        # entirely so that locked seasonal prices (Noël, events…) are
        # never overwritten by adaptive corrections.
        try:
            from business.price_calendar import get_locked_dates
            _locked_dates = get_locked_dates(self.config, checkin, _total_days)
        except Exception:
            _locked_dates = set()

        for room, r in valid_results.items():
            m = mapping.get(room, {})
            room_code = (m.get("room_code", "").strip()
                         if isinstance(m, dict) else str(m).strip())
            if not room_code:
                skipped.append(room)
                continue

            # Prix cible = ce que le client doit voir sur l'OTA après remise
            target_price = float(r["final"])
            if target_price <= 0:
                # Sécurité : ne jamais envoyer un prix nul ou négatif au CM.
                skipped.append(room)
                continue

            # Correction propre à chaque OTA pour CETTE chambre (Blocage prix OTA
            # peut calculer une cible différente par OTA — ex. Agoda 1600 / MakeMyTrip
            # 2000). Clé = nom OTA en minuscule. Absent/vide pour les appelants qui
            # n'envoient qu'un prix unique par chambre (Manuel, Mobile…) → comportement
            # inchangé, `target_price` reste utilisé pour tous les rate plans.
            _per_ota = (r.get("per_ota") or {}) if isinstance(r, dict) else {}

            # Garde-fou plancher/plafond — protège TOUTES les sources de push
            # (Manuel, OTA Blocage, Calibration OTA, Mobile), pas seulement le
            # mobile (qui avait déjà _mobile_guardrail_check). Même convention
            # que le reste du code : plancher = on relève, plafond = on rejette.
            _floor = strat_floors.get(room)
            _ceil  = strat_ceilings.get(room)
            if _floor and target_price < float(_floor):
                target_price = float(_floor)
            if _ceil and target_price > float(_ceil):
                skipped_ceiling.append(room)
                continue

            # ── Rate plans : multi-OTA ou rétrocompatibilité ──────────────
            if isinstance(m, dict) and m.get("rate_plans"):
                rate_plans_list = m["rate_plans"]
            else:
                # Ancienne config à une seule ligne
                _rpc  = (m.get("rate_plan_code", "").strip()
                         if isinstance(m, dict) else "") or "1"
                _disc = float(m.get("ota_discount_pct", 0) or 0) \
                        if isinstance(m, dict) else 0.0
                rate_plans_list = [{"rate_plan_code":   _rpc,
                                    "ota_discount_pct": _disc}]

            for rp_entry in rate_plans_list:
                # Filtre OTA : accepte un nom unique ou un set/liste de noms.
                # Deux règles, décidées après l'audit G1 (constat G1-2) :
                #   1. `ota_name` VIDE = « s'applique à toutes les OTA ». Le champ
                #      est documenté comme purement informatif (D20) et n'est
                #      soumis à aucun contrôle de saisie : un champ vide, ou une
                #      ancienne config à un seul `rate_plan_code` (rétrocompat D20,
                #      qui ne porte aucun `ota_name`), écartait TOUT le push en
                #      silence.
                #   2. Comparaison insensible à la casse et aux espaces
                #      (« agoda » ≡ « Agoda »).
                _ota_n = (rp_entry.get("ota_name", "") or "").strip().lower()
                # Goibibo et MakeMyTrip sont le même inventaire OTA sous deux
                # noms différents (même canal Channel Manager) — le prix
                # calculé pour MakeMyTrip doit être utilisé pour le rate plan
                # Goibibo. Le code CM envoyé reste bien celui de Goibibo
                # (_ota_code, lu séparément ci-dessous) : seul le prix change.
                if _ota_n == "goibibo":
                    _ota_n = "makemytrip"
                # Code CM de cette OTA — propagé jusqu'au paquet envoyé pour que
                # push_rates_to_cm_by_ota() puisse regrouper et espacer les envois
                # par OTA au lieu de tout mélanger dans un seul paquet "toutes OTA".
                _ota_code = (rp_entry.get("ota_code", "") or "").strip()
                if ota_filter:
                    if _ota_n:
                        if isinstance(ota_filter, (set, list, frozenset)):
                            _wanted = {str(x).strip().lower() for x in ota_filter}
                            if _ota_n not in _wanted:
                                filtered_out += 1
                                continue
                        elif _ota_n != str(ota_filter).strip().lower():
                            filtered_out += 1
                            continue

                # Prix RÉEL pour CE rate plan : la correction propre à son OTA si
                # Blocage prix OTA en a calculé une, sinon le prix générique de la
                # chambre. Une correction par-OTA existe pour cette chambre mais ne
                # couvre PAS cette OTA précise → on n'envoie rien pour ce rate plan
                # plutôt que de lui appliquer le prix calculé pour une autre OTA.
                if _per_ota and _ota_n:
                    if _ota_n not in _per_ota:
                        filtered_out += 1
                        continue
                    _rp_price = float(_per_ota[_ota_n])
                    if _floor and _rp_price < float(_floor):
                        _rp_price = float(_floor)
                    if _ceil and _rp_price > float(_ceil):
                        if room not in skipped_ceiling:
                            skipped_ceiling.append(room)
                        continue
                else:
                    _rp_price = target_price

                rp_code = (rp_entry.get("rate_plan_code", "") or "1").strip()
                try:
                    disc_pct = float(rp_entry.get("ota_discount_pct", 0) or 0)
                except (ValueError, TypeError):
                    disc_pct = 0.0

                # Calcul du prix à envoyer au CM pour que l'OTA affiche _rp_price
                # push_price = target / (1 − remise/100)
                # Ex : target=2000, Agoda remise=20% → push=2500
                #      (Agoda affiche 2500×0.80=2000 ✓)
                if 0 < disc_pct < 100:
                    push_price = _rp_price / (1.0 - disc_pct / 100.0)
                else:
                    push_price = _rp_price
                push_price = round(push_price)

                # Trace par OTA pour l'historique CM (une ligne par OTA à
                # l'affichage) — prix de référence par chambre, avant
                # segmentation weekend éventuelle.
                _ota_disp = (rp_entry.get("ota_name", "") or "").strip() or (_ota_code or "?")
                _ota_key  = _ota_code or _ota_disp
                per_ota_summary.setdefault(_ota_key, {"name": _ota_disp, "rooms": {}})
                per_ota_summary[_ota_key]["rooms"][room] = push_price

                # Segmentation par date : saute les dates verrouillées du
                # calendrier saisonnier et applique la majoration weekend
                # sur les dates non verrouillées.  Si ni verrou ni weekend
                # → envoi plat classique (un seul prix pour toute la période).
                _wknd_active = weekend_markup and weekend_markup.get("enabled")
                if _locked_dates or _wknd_active:
                    from business.channel_manager import segments_skipping_locked
                    _wknd_cfg = None
                    if _wknd_active:
                        _wknd_cfg = {
                            "enabled": True,
                            "pct":     float(weekend_markup.get("pct", 20)),
                            "weekend_days": weekend_markup.get("days", [4, 5]),
                        }
                    for _li, (_lstart, _lspan) in enumerate(_lots):
                        for _fd, _td, _pr in segments_skipping_locked(
                                push_price, _lstart, _lspan,
                                _locked_dates, _wknd_cfg):
                            lot_pushes[_li].append({
                                "room_code":      room_code,
                                "rate_plan_code": rp_code,
                                "price":          _pr,
                                "from_date":      _fd,
                                "to_date":        _td,
                                "ota_code":       _ota_code,
                            })
                else:
                    room_pushes.append({
                        "room_code":      room_code,
                        "rate_plan_code": rp_code,
                        "price":          push_price,
                        "ota_code":       _ota_code,
                    })

        if not room_pushes and not any(lot_pushes):
            # Message précis : le cas « code CM manquant » et le cas « aucun Rate
            # Plan ne correspond aux OTA surveillées » ont des causes et des
            # solutions différentes. L'ancien message unique désignait toujours le
            # code CM, même quand il était correctement configuré.
            if filtered_out:
                _why_ui = tr_(
                    "Aucun Rate Plan ne correspond aux OTA surveillées.\n"
                    "{n} ligne(s) écartée(s) : le champ « OTA » du Rate Plan ne "
                    "correspond à aucune OTA active dans Blocage prix OTA.\n"
                    "Corrige le nom dans Configuration → Channel Manager, ou "
                    "laisse ce champ vide pour appliquer le prix à toutes les OTA."
                ).format(n=filtered_out)
                _why_cb = f"Aucun Rate Plan ne correspond aux OTA surveillées ({filtered_out} écartée(s))"
            else:
                _why_ui = tr_("Aucune chambre n'a de code CM configuré.\n"
                              "Configure le mapping dans Configuration → Channel Manager.")
                _why_cb = "Aucun room_code configuré"
            if not silent:
                messagebox.showwarning(tr_("Push CM"), _why_ui, parent=self.root)
            if on_done:
                on_done(False, _why_cb)
            return

        def _fmt_results(_results):
            _ok  = all(r["ok"] for r in _results) if _results else False
            _msg = " | ".join(
                f"{'✅' if r['ok'] else '✗'} {r['ota_code'] or 'toutes OTA'} : {r['msg']}"
                for r in _results
            )
            return _ok, _msg

        def _sent_total(_results):
            """D42 : nombre d'envois RÉELLEMENT partis dans ces résultats.
            Transport extranet : champ « sent » (verified + preuve POST).
            Chemin API (pas de champ) : si le groupe est ok, tout est
            parti (n) ; sinon rien n'est compté — l'API ne fournit pas
            de détail intermédiaire."""
            _t = 0
            for r in (_results or []):
                if "sent" in r:
                    _t += int(r.get("sent") or 0)
                elif r.get("ok"):
                    _t += int(r.get("n") or 0)
            return _t

        def _task():
            try:
                if any(lot_pushes):
                    # Mode weekend : un envoi par lot de 15 jours, dans l'ordre ;
                    # et pour chaque lot, un envoi séparé par OTA (avec pause de
                    # 5s entre chaque) plutôt qu'un envoi groupé.
                    # D39 (28/08, ordre propriétaire) : un lot partiellement
                    # échoué n'abandonne PLUS les lots suivants — l'ancien
                    # `break` jetait jusqu'à 45 jours du « pendant 60 jours »
                    # parce qu'UN segment avait raté son POST (« il n'envoie
                    # jamais tout »). Les lots continuent ; les segments tombés
                    # sont repris au cycle de scan suivant par la boucle 24/7.
                    # Seule une panne TOTALE (session CM expirée, état du CM
                    # indisponible) arrête la chaîne : plus rien ne passerait
                    # après, inutile de marteler.
                    _lot_oks, _lot_msgs = [], []
                    _sent = 0
                    _sent_items = []
                    for _li, _lp in enumerate(lot_pushes):
                        if not _lp:
                            continue
                        _lstart, _lspan = _lots[_li]
                        _results = _push_transport(
                            cm, _lp, _lstart, _lspan, log_cb=self._log_journal,
                            progress_cb=_progress52)
                        _lok, _lmsg = _fmt_results(_results)
                        if not _lok:
                            _lmsg = f"Lot {_li + 1}/{len(_lots)} : {_lmsg}"
                        _lot_oks.append(_lok)
                        _lot_msgs.append(_lmsg)
                        _sent += _sent_total(_results)
                        for _r in _results:
                            _sent_items.extend(_r.get("sent_items") or [])
                        if "session CM expirée" in _lmsg or \
                           "état du CM indisponible" in _lmsg:
                            break
                    ok = all(_lot_oks) if _lot_oks else False
                    msg = " | ".join(_lot_msgs)
                else:
                    _results = _push_transport(
                        cm, room_pushes, checkin, _total_days,
                        log_cb=self._log_journal, progress_cb=_progress52)
                    ok, msg = _fmt_results(_results)
                    _sent = _sent_total(_results)
                    _sent_items = []
                    for _r in _results:
                        _sent_items.extend(_r.get("sent_items") or [])
                body = ""
            except Exception as e:
                ok, msg, body = False, str(e), ""
                _sent = 0

            def _ui():
                if not silent:
                    if ok:
                        messagebox.showinfo(tr_("✅ Push CM"),
                                            f"Prix envoyés avec succès.\n{msg}",
                                            parent=self.root)
                    else:
                        messagebox.showerror(tr_("✗ Push CM échoué"), msg,
                                             parent=self.root)
                try:
                    if on_done:
                        _cb = msg
                        if skipped:
                            _cb += f" | ⚠ Ignorées (mapping manquant) : {', '.join(skipped)}"
                        if skipped_ceiling:
                            _cb += f" | ⚠ Ignorées (au-dessus du plafond configuré) : {', '.join(skipped_ceiling)}"
                        # D105-2 : les segments réellement partis traversent le
                        # callback quand il en accepte 3 — l'appelant peut
                        # enregistrer les mesures même en échec de groupe.
                        import inspect as _inspect
                        if len(_inspect.signature(on_done).parameters) >= 3:
                            on_done(ok, _cb, _sent_items)
                        else:
                            on_done(ok, _cb)
                except Exception:
                    pass
                try:
                    self._cm_record_push(
                        {r: v.get("final", 0) for r, v in valid_results.items()},
                        source, ok, msg, per_ota=per_ota_summary,
                        sent_count=_sent)
                except Exception:
                    pass
                # Passerelle mobile : confirmer le push vers l'app compagnon
                # (uniquement si le push CM a réellement réussi).
                try:
                    if ok:
                        self._publish_mobile_push_confirmation(valid_results)
                except Exception:
                    pass

            self._ui_call(_ui)

        self._spawn(_task)

    def _mobile_guardrail_check(self, room, ota):
        """GARDIEN FINAL — appelé avant tout push déclenché par le mobile.

        Vérifie que le prix cible de (chambre, OTA) respecte les bornes
        plancher/plafond configurées (strategy.floors / strategy.ceilings).
        Le moteur applique déjà le plancher (max(cible, plancher)), mais PAS
        le plafond : cette vérification comble ce trou pour les ordres mobiles.

        Retourne (True, "") si l'ordre peut passer, (False, raison) sinon.
        Conservateur : en cas de donnée manquante ou de doute, on REJETTE
        plutôt que de pousser un prix non vérifié."""
        try:
            ota_cfg       = self.config.get("ota_watch", {})
            target_prices = ota_cfg.get("target_prices", {})
            _room_t = target_prices.get(room, {}) or {}
            # OTA group aliasing: after the desktop merge, the target is
            # stored under "MakeMyTrip / Goibibo" — resolve a bare
            # "Goibibo"/"MakeMyTrip" from the phone against that key.
            _n = (ota or "").lower()
            target = _room_t.get(ota)
            if not target and any(g in _n for g in ("goibibo", "makemytrip")):
                target = (_room_t.get("MakeMyTrip / Goibibo")
                          or _room_t.get("MakeMyTrip")
                          or _room_t.get("Goibibo"))
            if not target:
                return False, f"Aucun prix cible configuré pour {room} / {ota}"
            target = float(target)

            strat   = self.config.get("strategy", {})
            floor   = (strat.get("floors", {}) or {}).get(room)
            ceiling = (strat.get("ceilings", {}) or {}).get(room)

            # Prix effectif que le moteur enverra = max(cible, plancher).
            effective = target
            if floor:
                effective = max(effective, float(floor))
            # Le plafond doit être respecté sur ce prix effectif.
            if ceiling and effective > float(ceiling):
                return (False,
                        f"Prix {int(effective)} au-dessus du plafond "
                        f"{int(float(ceiling))} pour {room}")
            return True, ""
        except Exception:
            return False, "Vérification des garde-fous impossible"

    def _mobile_guardrail_check_new_target(self, room, new_target):
        """GARDIEN — appelé avant d'enregistrer un NOUVEAU prix cible proposé
        par le mobile (action `update_target_price`).

        Contrairement à `_mobile_guardrail_check` (qui revalide un prix cible
        déjà en config avant un push), celle-ci valide la VALEUR PROPOSÉE
        elle-même contre les bornes plancher/plafond, avant tout enregistrement
        disque. Conservateur : rejette en cas de donnée manquante ou de doute."""
        try:
            new_target = float(new_target)
        except (TypeError, ValueError):
            return False, "Prix cible invalide"
        if new_target <= 0:
            return False, "Le prix cible doit être positif"

        strat   = self.config.get("strategy", {})
        floor   = (strat.get("floors", {}) or {}).get(room)
        ceiling = (strat.get("ceilings", {}) or {}).get(room)
        if floor and new_target < float(floor):
            return (False,
                    f"Prix {int(new_target)} en dessous du plancher "
                    f"{int(float(floor))} pour {room}")
        if ceiling and new_target > float(ceiling):
            return (False,
                    f"Prix {int(new_target)} au-dessus du plafond "
                    f"{int(float(ceiling))} pour {room}")
        return True, ""

    def _publish_mobile_target_prices(self):
        """Republie la config des prix cibles vers Firebase après un ordre
        mobile réussi, pour que le téléphone voie le changement sans attendre
        le prochain scan. Fire-and-forget, fail-safe (convention D8)."""
        target_prices = self.config.get("ota_watch", {}).get("target_prices", {})

        def _worker():
            try:
                from business.mobile_gateway import publish_target_prices
                publish_target_prices(target_prices)
            except Exception:
                pass

        self._spawn(_worker)

    def _on_mobile_command(self, doc_id, data):
        """Reçoit et EXÉCUTE un ordre du téléphone — thread principal Tkinter
        (marshalé par scraping/mobile_commands.py via root.after).

        Le PC est le GARDIEN FINAL : avant tout push Channel Manager, on
        re-valide les garde-fous prix plancher/plafond, même pour un ordre
        venu du mobile. Un ordre qui violerait ces bornes est REJETÉ, jamais
        poussé. L'exécution elle-même passe par le moteur de correction déjà
        validé (_ota_watch_correct) — aucune logique de prix réécrite ici."""
        def _log(msg, action, room, ota, ok=True):
            try:
                from business.activity_log import log_event
                log_event("MOBILE", msg, ok=ok,
                          action=action, room=room, ota=ota, doc_id=doc_id)
            except Exception:
                pass

        def _status(st, detail=""):
            try:
                from business.mobile_commands import update_command_status
                update_command_status(doc_id, st, detail)
            except Exception:
                pass

        try:
            action = (data or {}).get("action", "?")
            room   = str((data or {}).get("room", "")).strip()
            ota    = str((data or {}).get("ota", "")).strip()

            # 1. Action connue et bien formée ?
            if action not in ("correct_price", "update_target_price", "update_notification_prefs"):
                _log(f"Ordre ignoré — action inconnue : {action}", action, room, ota, ok=False)
                _status("rejected", f"Action inconnue : {action}")
                return

            # update_notification_prefs ne porte pas de chambre/OTA — traité
            # avant la vérification room/ota ci-dessous, qui ne s'applique
            # qu'aux ordres liés à une chambre précise.
            if action == "update_notification_prefs":
                self._on_mobile_update_notification_prefs(data, _log, _status)
                return

            if not room or not ota:
                _log("Ordre rejeté — chambre ou OTA manquante", action, room, ota, ok=False)
                _status("rejected", "Chambre ou OTA manquante")
                return

            if action == "update_target_price":
                self._on_mobile_update_target_price(data, room, ota, _log, _status)
                return

            # 2. GARDIEN FINAL : re-valider min/max AVANT tout push.
            okg, reason = self._mobile_guardrail_check(room, ota)
            if not okg:
                _log(f"Ordre REJETÉ par le gardien prix : {reason}", action, room, ota, ok=False)
                _status("rejected", reason)
                return

            # 3. Exécution via le moteur de correction validé (mêmes garde-fous
            #    internes : planchers, min_gap, refus prix<=0 dans _do_push).
            #    silent=True : la confirmation a déjà eu lieu sur le téléphone.
            correct_fn = getattr(self, "_ota_watch_correct_fn", None)
            if not callable(correct_fn):
                _log("Ordre non exécuté — moteur de correction indisponible",
                     action, room, ota, ok=False)
                _status("rejected", "Moteur de correction indisponible")
                return

            _log("Ordre accepté — correction lancée via le moteur validé",
                 action, room, ota, ok=True)
            _status("accepted", "Correction envoyée au moteur (garde-fous OK)")
            try:
                correct_fn(room=room, ota_name=ota, silent=True)
            except Exception:
                import logging
                logging.exception("_on_mobile_command: échec _ota_watch_correct")
        except Exception:
            import logging
            logging.exception("_on_mobile_command: échec de traitement")

    def _on_mobile_update_target_price(self, data, room, ota, _log, _status):
        """Traite l'action `update_target_price` : le mobile propose un nouveau
        prix cible pour (chambre, OTA). Revalidé contre planchers/plafonds
        (`_mobile_guardrail_check_new_target`) puis écrit dans la config sur
        disque via `core.config.save` — même mécanisme que l'édition depuis
        l'onglet Blocage OTA (tabs/tab_blocage_ota.py)."""
        action = "update_target_price"
        new_target = (data or {}).get("new_target")

        okg, reason = self._mobile_guardrail_check_new_target(room, new_target)
        if not okg:
            _log(f"Nouveau prix cible REJETÉ par le gardien : {reason}", action, room, ota, ok=False)
            _status("rejected", reason)
            return

        try:
            ota_cfg = self.config.setdefault("ota_watch", {})
            target_prices = ota_cfg.setdefault("target_prices", {})
            # Normalize Goibibo / MakeMyTrip orders onto the merged key so
            # the phone never creates a stale standalone entry.
            _n = (ota or "").lower()
            _write_key = ota
            if any(g in _n for g in ("goibibo", "makemytrip")):
                _write_key = "MakeMyTrip / Goibibo"
            target_prices.setdefault(room, {})[_write_key] = float(new_target)
            from core import config as cfg
            cfg.save(self.config)
        except Exception:
            import logging
            logging.exception("_on_mobile_update_target_price: échec d'enregistrement")
            _log("Échec d'enregistrement du nouveau prix cible", action, room, ota, ok=False)
            _status("rejected", "Échec d'enregistrement côté PC")
            return

        # Le symbole suit la devise configurée par l'hôtel : ce texte part tel
        # quel vers le téléphone (`pc_detail`), et un « ₹ » codé en dur ferait
        # afficher une roupie à un hôtel qui travaille en euros.
        from core.utils import get_currency_symbol
        _sym = get_currency_symbol()
        _log(f"Prix cible mis à jour depuis le mobile → {_sym}{int(float(new_target))}",
             action, room, ota, ok=True)
        _status("accepted", f"Prix cible enregistré : {_sym}{int(float(new_target))}")
        self._publish_mobile_target_prices()

    _MOBILE_NOTIFICATION_KEYS = ("price_gap_detected", "correction_envoyee", "floor_violation")

    def _on_mobile_update_notification_prefs(self, data, _log, _status):
        """Traite l'action `update_notification_prefs` : le téléphone (ou le
        PC) propose un nouvel état pour les toggles de notification mobile.
        Réglage global partagé — écrit dans config["mobile_notifications"]
        (lu par scraping/notifications.py::send_mobile_push) puis republié
        vers Firestore pour que tous les téléphones appairés voient le
        changement sans attendre le prochain scan."""
        action = "update_notification_prefs"
        prefs = (data or {}).get("prefs")
        if not isinstance(prefs, dict) or not prefs:
            _log("Ordre rejeté — préférences invalides", action, "", "", ok=False)
            _status("rejected", "Préférences invalides")
            return

        cleaned = {k: bool(prefs[k]) for k in self._MOBILE_NOTIFICATION_KEYS if k in prefs}
        if not cleaned:
            _log("Ordre rejeté — aucune préférence reconnue", action, "", "", ok=False)
            _status("rejected", "Aucune préférence reconnue")
            return

        try:
            mn = self.config.setdefault("mobile_notifications", {})
            mn.update(cleaned)
            from core import config as cfg
            cfg.save(self.config)
        except Exception:
            import logging
            logging.exception("_on_mobile_update_notification_prefs: échec d'enregistrement")
            _log("Échec d'enregistrement des préférences", action, "", "", ok=False)
            _status("rejected", "Échec d'enregistrement côté PC")
            return

        _log("Préférences de notification mises à jour depuis le mobile", action, "", "", ok=True)
        _status("accepted", "Préférences enregistrées")
        self._publish_mobile_notification_prefs()

    def _publish_mobile_notification_prefs(self):
        """Republie les préférences de notification mobile vers Firebase,
        fire-and-forget, fail-safe (convention D8) — même pattern que
        `_publish_mobile_target_prices`."""
        prefs = self.config.get("mobile_notifications", {})

        def _worker():
            try:
                from business.mobile_gateway import publish_notification_prefs
                publish_notification_prefs(prefs)
            except Exception:
                pass

        self._spawn(_worker)

    def _publish_mobile_push_confirmation(self, valid_results):
        """Publie une confirmation de push vers Firebase (app mobile compagnon).

        Un enregistrement par chambre dans la collection push_history. Fail-safe
        (convention D8) : si la passerelle mobile n'est pas connectée,
        publish_push_confirmation() retourne False sans rien casser. L'envoi
        réseau tourne dans un thread daemon pour ne jamais bloquer l'interface.

        Note : ota_pushes est laissé vide ici (détail par rate plan non
        reconstruit à ce stade) — la confirmation contient chambre + prix cible
        + horodatage, suffisant pour l'app mobile actuelle."""
        rooms = {}
        try:
            for room, r in (valid_results or {}).items():
                if isinstance(r, dict) and r.get("final"):
                    rooms[room] = float(r["final"])
        except Exception:
            return
        if not rooms:
            return

        def _worker():
            try:
                from business.mobile_gateway import publish_push_confirmation
                for room, price in rooms.items():
                    publish_push_confirmation(room, price, [], mode="applied")
            except Exception:
                pass

        self._spawn(_worker)

    def _push_progress(self, done, total, label):
        """D52 : barre de progression des envois CM (onglet Blocage)."""
        # D56 : le bouton Stop est actif pendant une correction
        try:
            sb = getattr(self, "_ota_watch_stop_btn", None)
            if sb is not None and sb.winfo_exists():
                if 0 < done and done < max(1, int(total)):
                    sb.config(state="normal")
                elif done >= max(1, int(total)):
                    sb.config(state="disabled", text=tr_("⏹ Stop"))
        except Exception:
            pass
        try:
            tb = getattr(self, "_push_prog", None)
            tl = getattr(self, "_push_prog_lbl", None)
            if tb is not None and tb.winfo_exists():
                tb["maximum"] = max(1, int(total))
                tb["value"] = int(done)
            if tl is not None and tl.winfo_exists():
                if done >= total and total > 0:
                    tl.config(text=tr_("✅ Envois terminés ({n}).").format(n=total))
                else:
                    tl.config(text=tr_("🛠 Correction en cours : {d}/{t} — {l}")
                              .format(d=done, t=total, l=label[:60]))
        except Exception:
            pass

    def _cm_record_push(self, rooms_prices, source, ok, msg, per_ota=None,
                        sent_count=None):
        """Enregistre le résultat d'un push dans push_history.

        Si `per_ota` contient un détail par OTA (Blocage prix OTA, qui peut
        calculer une cible différente par OTA), une entrée SÉPARÉE est créée
        par OTA — chacune avec le nom de l'OTA et les prix qui lui ont été
        envoyés spécifiquement. Sinon (Manuel, Mobile… un seul prix par
        chambre), on retombe sur l'ancienne entrée unique groupant toutes
        les chambres — comportement inchangé.

        D42 : `sent_count` = nombre d'envois RÉELLEMENT partis (transport
        extranet : verified + preuve POST ; API : n si groupe ok). Le
        panneau l'utilise pour l'état PARTIEL (vert si tout ok, orange si
        au moins un envoi parti malgré des échecs, rouge sinon). Le msg
        n'est plus tronqué — les détails d'envoi (D40) doivent rester
        lisibles en entier.
        """
        try:
            ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            sym = get_currency_symbol()

            entries = []
            if per_ota:
                for _data in per_ota.values():
                    _rooms = _data.get("rooms") or {}
                    if not _rooms:
                        continue
                    # D77 : verdict PROPRE à chaque OTA quand le transport
                    # le porte (une OTA en échec ne peint plus les autres
                    # en ❌ — constat du push saisonnier du 20/09 18h57 :
                    # Agoda ✅ mais ❌ global partout).
                    _g_ok = _data.get("ok")
                    _g_sent = _data.get("sent")
                    entries.append({
                        "ts":     ts,
                        "rooms":  ", ".join(str(r) for r in _rooms),
                        "prices": " / ".join(f"{sym}{int(float(p)):,}" for p in _rooms.values()),
                        # Room and its price kept TOGETHER — the display
                        # shows "Room: ₹price" instead of two parallel lists
                        # the reader has to line up by hand.
                        "pairs":  [f"{r}: {sym}{int(float(p)):,}"
                                   for r, p in _rooms.items()],
                        "source": source,
                        "ota":    _data.get("name", ""),
                        "ok":     bool(_g_ok) if _g_ok is not None else bool(ok),
                        "sent":   int(_g_sent) if _g_sent is not None else (int(sent_count) if sent_count is not None else None),
                        "msg":    str(msg or ""),  # D42 : plus de troncature
                    })
            if not entries:
                entries = [{
                    "ts":     ts,
                    "rooms":  ", ".join(str(r) for r in rooms_prices) if rooms_prices else "—",
                    "prices": " / ".join(f"{sym}{int(float(p)):,}" for p in rooms_prices.values()) if rooms_prices else "—",
                    "pairs":  [f"{r}: {sym}{int(float(p)):,}"
                               for r, p in (rooms_prices or {}).items()],
                    "source": source,
                    "ota":    "",
                    "ok":     bool(ok),
                    "sent":   int(sent_count) if sent_count is not None else None,
                    "msg":    str(msg or ""),  # D42 : plus de troncature
                }]

            cm   = self.config.setdefault("channel_manager", {})
            hist = cm.setdefault("push_history", [])
            for entry in reversed(entries):
                hist.insert(0, entry)
            if len(hist) > 50:
                cm["push_history"] = hist[:50]
            cfg.save(self.config)
            for entry in entries:
                _label = f"{entry['source']} → {entry['ota']}" if entry.get("ota") else entry['source']
                self._log_journal(
                    f"CM push {'✅' if entry['ok'] else '❌'} [{_label}] "
                    f"{entry['rooms']} → {entry['prices']}")
            fn = getattr(self, "_cm_refresh_history_fn", None)
            if fn:
                self.root.after(0, fn)
        except Exception:
            pass

    # ── Wiki ─────────────────────────────────────────────────────────────

    def _show_wiki(self, topic_key):
        from wizard_engine import show_wiki
        show_wiki(self.root, topic_key)

    def _send_bug_report(self):
        import os, sys, platform, urllib.parse, webbrowser, subprocess
        from datetime import datetime
        from core.paths import DATA_DIR
        from core.utils import tr_
        try:
            from version import VERSION, BUILD_DATE
        except Exception:
            VERSION, BUILD_DATE = "?", "?"

        log_path = DATA_DIR / "app.log"

        lines = [
            "=== OTA Guard — Rapport de bug ===",
            f"Version  : {VERSION}  (build {BUILD_DATE})",
            f"OS       : {platform.system()} {platform.release()} — {platform.version()}",
            f"Date     : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            "",
            "⚠ Le dossier contenant app.log vient de s'ouvrir, avec le "
            "fichier sélectionné : glissez-le dans cet email avant de l'envoyer "
            "(la messagerie ne permet pas de joindre un fichier automatiquement).",
            "",
            "=== Activity log (50 dernières lignes, pour aperçu rapide) ===",
        ]
        try:
            with open(log_path, encoding="utf-8", errors="replace") as f:
                log_lines = f.readlines()
            lines += [l.rstrip() for l in log_lines[-50:]]
        except Exception as e:
            lines.append(f"[Log non disponible : {e}]")

        lines += [
            "",
            "=== Description du problème ===",
            "(Décrivez ici ce qui s'est passé, les étapes pour reproduire, etc.)",
        ]

        body = "\n".join(lines)
        subject = f"Bug Report — OTA Guard {VERSION}"
        mailto = (
            "mailto:otaguard@proton.me"
            f"?subject={urllib.parse.quote(subject)}"
            f"&body={urllib.parse.quote(body)}"
        )

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(body)
            self.root.update()
        except Exception:
            pass

        from tkinter import messagebox
        messagebox.showinfo(
            tr_("Rapport de bug"),
            tr_("Le rapport a été copié dans le presse-papier.\n\n"
                "Si votre messagerie ne s'ouvre pas automatiquement à l'étape "
                "suivante : ouvrez votre boîte mail habituelle (Gmail, Outlook…) "
                "et collez le rapport (Ctrl+V) dans un nouvel email à "
                "otaguard@proton.me."),
            parent=self.root)

        webbrowser.open(mailto)

        # Explorateur ouvert avec un léger délai (pas en même temps que mailto)
        # pour ne pas interrompre le choix de messagerie de Windows si aucun
        # client mail par défaut n'est configuré. Sert à glisser-déposer le
        # fichier log complet dans l'email (mailto ne joint pas de fichier).
        def _open_explorer():
            try:
                if log_path.exists():
                    subprocess.Popen(f'explorer /select,"{log_path}"')
            except Exception:
                pass
        self.root.after(2000, _open_explorer)

    def _remote_support_exe_path(self):
        return str(INSTALL_DIR / "AnyDesk.exe")

    def _open_remote_support(self):
        import os
        import subprocess
        from tkinter import messagebox
        from core.utils import tr_

        exe = self._remote_support_exe_path()
        if os.path.exists(exe):
            try:
                subprocess.Popen([exe])
            except Exception as e:
                messagebox.showerror(tr_("Support à distance"),
                                      tr_("Impossible de lancer l'outil de support :") + f"\n{e}",
                                      parent=self.root)
            return

        if messagebox.askyesno(
            tr_("Support à distance"),
            tr_("L'outil de support à distance n'est pas encore installé sur ce poste.") + "\n\n" +
            tr_("Téléchargez la version portable (aucune installation requise), "
                "placez le fichier AnyDesk.exe dans :") + f"\n{INSTALL_DIR}\n\n" +
            tr_("Ouvrir la page de téléchargement maintenant ?"),
            parent=self.root,
        ):
            import webbrowser
            webbrowser.open("https://anydesk.com/en/downloads/windows")

    # ── Préférences UI (persistance légère) ──────────────────────────────

    def _ui_pref(self, key: str, default):
        return self.config.get("_ui_prefs", {}).get(key, default)

    def _ui_pref_save(self, key: str, value):
        prefs = self.config.setdefault("_ui_prefs", {})
        prefs[key] = value

    # ── OTA Watch boucle auto ─────────────────────────────────────────────

    def _ota_watch_interval_ms(self) -> int:
        """Délai avant le prochain scan automatique, en millisecondes.

        L'intervalle réglé par l'utilisateur (interval_h / interval_m) est
        respecté EN MOYENNE, mais plus à la seconde près : on y ajoute une
        variation aléatoire de ±12 %. Un scan qui tombe toutes les 4 h 00 min
        00 s exactement, jour après jour et depuis la même adresse Internet,
        est un métronome — c'est le motif le plus simple à repérer côté OTA.
        Avec la variation, deux visites consécutives ne tombent jamais au même
        moment de l'heure. Le plancher de 5 minutes d'origine est conservé.
        """
        try:
            cfg  = self.config.get("ota_watch", {})
            h    = int(cfg.get("interval_h", 4))
            m    = int(cfg.get("interval_m", 0))
            secs = h * 3600 + m * 60
            ms   = max(secs * 1000, 300_000) if secs > 0 else 14_400_000
        except Exception:
            ms = 14_400_000
        try:
            # Random jitter (±8%) so scan intervals are not perfectly
            # regular — harder for OTA anti-bot systems to fingerprint.
            import random as _rnd
            _jitter = _rnd.uniform(0.92, 1.08)
            return max(int(ms * _jitter), 300_000)
        except Exception:
            return ms

    def _ota_watch_auto_loop_delayed_start(self):
        """Attend l'intervalle configuré avant le 1er scan automatique."""
        self.root.after(self._ota_watch_interval_ms(), self._ota_watch_auto_loop)

    def _ota_watch_auto_loop(self):
        """Boucle périodique — scan automatique selon l'intervalle configuré."""
        try:
            # D98 : pause globale — le planificateur ne déclenche RIEN
            # (il se re-programme et repartira à la reprise).
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._ota_watch_auto_id = self.root.after(
                    self._ota_watch_interval_ms(), self._ota_watch_auto_loop)
                return
        except Exception:
            pass
        try:
            from licensing.license_checker import _ck
            if not _ck():
                # Reschedule sans rien faire
                self._ota_watch_auto_id = self.root.after(14_400_000, self._ota_watch_auto_loop)
                return
        except Exception:
            pass
        try:
            cfg  = self.config.get("ota_watch", {})
            if cfg.get("auto_correct"):
                otas = [o for o in cfg.get("otas", [])
                        if o.get("active") and o.get("url", "").startswith("http")]
                busy = (getattr(self, "_ota_watch_scanning", False) or
                        getattr(self, "_any_scan_running", False))
                scan_fn = getattr(self, "_ota_watch_scan_fn", None)
                if otas and not busy and scan_fn:
                    try:
                        scan_fn(_skip_save=True)
                    except Exception as e:
                        import logging
                        logging.exception("OTA Watch — scan auto échoué")
                        self._log_journal(f"❌ OTA Watch — scan auto échoué : {e}", level="error", engine="OTA_WATCH")
        except Exception:
            pass
        # Reschedule (intervalle légèrement variable — voir _ota_watch_interval_ms)
        self._ota_watch_auto_id = self.root.after(
            self._ota_watch_interval_ms(), self._ota_watch_auto_loop)

    # ── Copier/coller universel ───────────────────────────────────────────
    #
    # Mécanisme (revu après l'audit G1, constat G1-5) : les liaisons sont posées
    # UNE FOIS sur la *classe* de widget (bind_class), pas widget par widget.
    # Elles valent donc pour tous les widgets de cette classe, y compris ceux
    # créés plus tard (tableaux reconstruits après un scan, cartes, fenêtres
    # secondaires) — plus besoin de re-parcourir tout l'arbre Tkinter toutes les
    # 3 secondes. Le menu lui-même est construit au moment du clic droit et
    # détruit au clic suivant : au plus UN menu vivant à la fois.
    #
    # Ancien fonctionnement : un tk.Menu créé par widget rencontré, jamais
    # détruit, plus un re-balayage complet toutes les 3 s. Mesuré pendant
    # l'audit : 20 champs détruits/recréés 5 fois → 20, 40, 60, 80, 100 menus
    # accumulés définitivement.

    _CTX_INPUT_CLASSES = ("Entry", "Text", "TEntry", "Spinbox", "TSpinbox", "TCombobox")
    _CTX_READ_CLASSES  = ("Label", "TLabel")
    _CTX_TREE_CLASSES  = ("Treeview",)

    def _ctx_copy(self, text):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(str(text))
        except Exception:
            pass

    def _ctx_select_all(self, w):
        try:
            cls = w.winfo_class()
            if cls in ("Entry", "TEntry", "Spinbox", "TSpinbox", "TCombobox"):
                w.select_range(0, "end")
                w.icursor("end")
            elif cls == "Text":
                w.tag_add("sel", "1.0", "end")
        except Exception:
            pass

    def _ctx_tree_rows(self, tree, iids):
        return "\n".join(
            "\t".join(str(v) for v in tree.item(i, "values")) for i in iids
        )

    def _ctx_close(self):
        """Détruit le menu contextuel précédent — garantit qu'il n'en existe
        jamais plus d'un seul en mémoire."""
        m = getattr(self, "_ctx_menu", None)
        if m is not None:
            try:
                m.destroy()
            except Exception:
                pass
            self._ctx_menu = None

    def _ctx_popup(self, event, kind):
        """Construit le menu adapté au widget cliqué, l'affiche, et libère le
        précédent. Les libellés sont retraduits à chaque ouverture : un
        changement de langue est donc pris en compte sans redémarrage."""
        w = event.widget
        try:
            self._ctx_close()
            m = tk.Menu(self.root, tearoff=0)
            self._ctx_menu = m

            if kind == "input":
                m.add_command(label=tr_("Copier"),
                              command=lambda: w.event_generate("<<Copy>>"))
                m.add_command(label=tr_("Couper"),
                              command=lambda: w.event_generate("<<Cut>>"))
                m.add_command(label=tr_("Coller"),
                              command=lambda: w.event_generate("<<Paste>>"))
                m.add_separator()
                m.add_command(label=tr_("Tout sélectionner"),
                              command=lambda: self._ctx_select_all(w))
            elif kind == "label":
                m.add_command(label=tr_("Copier"),
                              command=lambda: self._ctx_copy(w.cget("text")))
            else:  # tableau
                m.add_command(label=tr_("Copier ligne(s) sélectionnée(s)"),
                              command=lambda: self._ctx_copy(
                                  self._ctx_tree_rows(w, w.selection())))
                m.add_command(label=tr_("Copier tout le tableau"),
                              command=lambda: self._ctx_copy(
                                  "\t".join(str(w.heading(c, "text")) for c in w["columns"])
                                  + "\n" + self._ctx_tree_rows(w, w.get_children(""))))
                m.add_separator()
                m.add_command(label=tr_("Tout sélectionner"),
                              command=lambda: w.selection_set(w.get_children("")))

            m.tk_popup(event.x_root, event.y_root)
        except Exception:
            logging.exception("_ctx_popup: échec ouverture du menu contextuel")
        finally:
            try:
                if getattr(self, "_ctx_menu", None) is not None:
                    self._ctx_menu.grab_release()
            except Exception:
                pass

    def _bind_context_menu_all(self, widget=None):
        """Installe le menu contextuel copier/coller pour TOUTE l'application.

        Couvre Entry, Text, Combobox, Spinbox, Label et Treeview — y compris les
        widgets créés après cet appel, puisque les liaisons sont posées sur la
        classe et non sur chaque widget. Idempotent : les appels suivants (ou un
        appel avec un widget particulier, conservé pour compatibilité) ne font
        rien de plus.
        """
        if getattr(self, "_ctx_class_bindings_done", False):
            return
        root = getattr(self, "root", None)
        if root is None:
            return
        self._ctx_class_bindings_done = True
        self._ctx_menu = None

        # add="+" : ne remplace jamais les liaisons natives de Tk pour ces
        # classes (édition, navigation clavier, tri des colonnes…).
        try:
            for _cls in self._CTX_INPUT_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "input"), add="+")
                root.bind_class(_cls, "<Control-a>",
                                lambda e: (self._ctx_select_all(e.widget), "break")[1], add="+")
                root.bind_class(_cls, "<Control-A>",
                                lambda e: (self._ctx_select_all(e.widget), "break")[1], add="+")
            for _cls in self._CTX_READ_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "label"), add="+")
            for _cls in self._CTX_TREE_CLASSES:
                root.bind_class(_cls, "<Button-3>",
                                lambda e: self._ctx_popup(e, "tree"), add="+")
                root.bind_class(_cls, "<Control-c>",
                                lambda e: (self._ctx_copy(
                                    self._ctx_tree_rows(e.widget, e.widget.selection())),
                                    "break")[1], add="+")
                root.bind_class(_cls, "<Control-a>",
                                lambda e: (e.widget.selection_set(
                                    e.widget.get_children("")), "break")[1], add="+")
        except Exception:
            logging.exception("_bind_context_menu_all: installation des liaisons de classe échouée")
