# patch de test v1 - canal hot-patch (D39)
TEST_V1 = 1
