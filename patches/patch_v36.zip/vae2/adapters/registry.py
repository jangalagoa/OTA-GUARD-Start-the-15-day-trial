"""
VAE 2 — Adapter registry.

Drop a new <extranet>.yaml into maps/ and it becomes discoverable. The
registry contains no site-specific logic.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional
from .base import ExtranetAdapter


class AdapterRegistry:
    def __init__(self, maps_dir: Optional[Path] = None):
        self.maps_dir = Path(maps_dir or (Path(__file__).resolve().parent.parent / "maps"))
        self._adapters: Dict[str, ExtranetAdapter] = {}

    def discover(self) -> Dict[str, ExtranetAdapter]:
        self._adapters.clear()
        if not self.maps_dir.exists():
            return {}
        for path in sorted(self.maps_dir.glob("*.yaml")):
            try:
                adapter = ExtranetAdapter.from_map(path)
                self._adapters[adapter.domain.lower()] = adapter
            except Exception:
                # Invalid maps are reported by explicit validation tooling;
                # discovery never turns an invalid map into browser activity.
                continue
        return dict(self._adapters)

    def get(self, domain: str) -> Optional[ExtranetAdapter]:
        if not self._adapters:
            self.discover()
        return self._adapters.get((domain or "").lower())

    def for_url(self, url: str) -> Optional[ExtranetAdapter]:
        if not self._adapters:
            self.discover()
        low = (url or "").lower()
        matches = [a for a in self._adapters.values() if a.domain.lower() in low]
        return max(matches, key=lambda a: len(a.domain)) if matches else None
