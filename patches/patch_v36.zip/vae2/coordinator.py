"""
VAE 2 — Coordinator (brick 3, step E4).

Orchestrates ONE correction at a time end-to-end:
  1. activity-window check (D10 — plausible local hours only)
  2. pre-flight: read-only element location on the target tab
  3. execution via the executor (brick 2) — TEST mode by default;
     REAL mode requires the owner's explicit confirmation
     (plan E4: manual validation first, auto later)
  4. after a REAL run: verification loop — reload the OTASheet tab
     (R4: browser reload is acceptable), let the passive listener
     capture the fresh grid, re-scan and DIFF the daily prices

Policies (plan §4.4): single queue, one task per run (D8), full
journal on disk, retry policy = +5 min / max 3 (logged, enforced by
the future daemon — single-shot here).
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
import warnings
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from vae2.executor import (Executor, ExecutorError, CMLoginRequired,
                           StopRequested, find_tab)
from vae2.scanner import (run_scan, compare_reports, load_map,
                           grid_shows_rate, _same_grid_label,
                          DEFAULT_MAPS_DIR)
from vae2.adapters import ExtranetAdapter

try:
    import websockets
except Exception:
    websockets = None  # only needed for the OTASheet reload

RETRY_POLICY = {"retry_after_seconds": 300, "max_retries": 3}
FRESH_GRID_TIMEOUT_SECONDS = 75.0
# D23 (2026-08-23): OTA pricing robots work 24/7 — so does ours. The
# default activity window is ALWAYS OPEN; a client may still restrict it
# via channel_manager.extranet_direct.activity_window = ['HH:MM','HH:MM'].
DEFAULT_ACTIVITY_WINDOW = ("00:00", "23:59")


@dataclass
class Task:
    room_label: str
    ota_label: str
    rate: str
    date_from: str            # ISO YYYY-MM-DD
    date_to: str              # ISO YYYY-MM-DD
    days: Optional[List[str]] = None   # None = all days


def in_activity_window(window=None) -> bool:
    """D10 — plausible local hours only. Window read from the config
    (channel_manager.extranet_direct.activity_window = ['HH:MM','HH:MM']);
    absent config = default 06:00–23:59."""
    try:
        from core import config as _cfg
        _c = _cfg.load() if hasattr(_cfg, "load") else {}
        _w = (((_c.get("channel_manager") or {})
               .get("extranet_direct") or {}).get("activity_window"))
        if isinstance(_w, (list, tuple)) and len(_w) == 2:
            window = tuple(_w)
    except Exception:
        pass
    w = window or DEFAULT_ACTIVITY_WINDOW
    # D141: compare at MINUTE granularity. "23:59" as an end bound means
    # "until the end of that minute" — comparing with full seconds rejected
    # 23:59:01–23:59:59 although the window is set to "all day", tripping
    # the circuit breaker on a full-day configuration (28/10 23:59 log:
    # every remaining shipment REFUSED "outside activity window", batch
    # marked failed while its POSTs had gone out and been verified).
    now = datetime.now().time().replace(second=0, microsecond=0)
    lo = datetime.strptime(w[0], "%H:%M").time()
    hi = datetime.strptime(w[1], "%H:%M").time().replace(second=59, microsecond=999999)
    return lo <= now <= hi


async def reload_otasheet(debug_port: int = 9222, ignore_cache: bool = True,
                          map_path: Path | None = None,
                          date_from: str | None = None) -> str:
    """Reload the OTASheet tab so the browser itself re-fetches the grid
    (R4). 22/23 behavior restored 24/08 (owner's order): opens the tab
    when missing, but ONLY if a LIVE CM session exists in another tab —
    never on a dead session (that multiplied login tabs, 23/08 incident),
    and NEVER closes anything. Returns the tab URL."""
    from urllib.request import Request, urlopen
    if websockets is None:
        raise RuntimeError("websockets library required")
    if map_path is None:
        map_path = DEFAULT_MAPS_DIR / "channelmanager_com_au.yaml"
    adapter = ExtranetAdapter.from_map(map_path)
    domain = adapter.domain
    card_url = adapter.page_url("read") or adapter.page_url("otasheet")
    # D128: follow the CM's current address (learned hosts) — the grid
    # is read where the CM lives NOW, not where the card still points.
    try:
        from business import cm_sites as _cms
        domains = _cms.all_hosts(domain)
        sheet_url = _cms.page_for("read", card_url or "")
    except Exception:
        domains = [domain]
        sheet_url = card_url
    domains = [d.lower() for d in domains if d]
    tab = find_tab("OTASheet", debug_port)
    fresh = False
    if not tab:
        # live-session guard: any CM page tab (card domain + learned
        # D128 addresses) that is not a login page
        with urlopen(f"http://127.0.0.1:{debug_port}/json/list",
                     timeout=3) as r:
            tabs = json.loads(r.read().decode())
        live = [t for t in tabs if t.get("type") == "page"
                and any(d in (t.get("url") or "").lower() for d in domains)
                and "login" not in (t.get("url") or "").lower()
                and "signin" not in (t.get("url") or "").lower()]
        if not live:
            # D128-2: an open tab carrying one of the card's page PATHS on
            # an unknown host is the moved CM (rebranded domain) — learn
            # it and re-check before giving up.
            try:
                from business import cm_sites as _cms
                _pages = {"read": card_url}
                _w = adapter.page_url("write")
                if _w:
                    _pages["write"] = _w
                if _cms.learn_from_tab_paths(tabs, _pages):
                    domains = [d for d in _cms.all_hosts(domain) if d]
                    live = [t for t in tabs if t.get("type") == "page"
                            and any(d in (t.get("url") or "").lower()
                                    for d in domains)
                            and "login" not in (t.get("url") or "").lower()
                            and "signin" not in (t.get("url") or "").lower()]
                    sheet_url = _cms.page_for("read", card_url or "")
            except Exception:
                pass
        if not live:
            raise RuntimeError(
                "no OTASheet tab and no LIVE CM session — log in to the "
                "CM once then retry (no tab was opened)")
        with urlopen(Request(f"http://127.0.0.1:{debug_port}/json/new",
                             method="PUT"), timeout=5) as r:
            tab = json.loads(r.read().decode())
        fresh = True
    ws = await websockets.connect(tab["webSocketDebuggerUrl"],
                                  max_size=10 * 1024 * 1024)
    try:
        if fresh or date_from:
            from urllib.parse import urlsplit, urlunsplit
            import re
            anchor = date_from or datetime.now().strftime("%Y-%m-%d")
            datetime.strptime(anchor, "%Y-%m-%d")
            parts = urlsplit((sheet_url if fresh else tab["url"]) or "")
            fragment = parts.fragment
            if re.search(r"D=\d{4}-\d{2}-\d{2}", fragment):
                fragment = re.sub(r"D=\d{4}-\d{2}-\d{2}",
                                  "D=" + anchor, fragment)
            else:
                fragment = "/D=" + anchor
            target_url = urlunsplit(parts._replace(fragment=fragment))
            same_page = target_url == tab.get("url")
            # a /json/new tab is blank — NAVIGATE it to the grid (R4:
            # the browser itself fetches the data)
            await ws.send(json.dumps({
                "id": 1, "method": "Page.reload" if same_page else "Page.navigate",
                "params": ({"ignoreCache": ignore_cache} if same_page
                           else {"url": target_url})}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(),
                                                         timeout=20))
                if data.get("id") == 1:
                    break
            for _ in range(20):        # let the grid load before returning
                await asyncio.sleep(1)
                await ws.send(json.dumps({
                    "id": 999, "method": "Runtime.evaluate",
                    "params": {"expression": "document.readyState",
                               "returnByValue": True}}))
                ready = None
                while True:
                    data = json.loads(await asyncio.wait_for(ws.recv(),
                                                             timeout=10))
                    if data.get("id") == 999:
                        ready = (data.get("result", {})
                                 .get("result", {}).get("value"))
                        break
                if ready == "complete":
                    break
            tab = dict(tab, url=target_url)
        else:
            await ws.send(json.dumps({
                "id": 1, "method": "Page.reload",
                "params": {"ignoreCache": ignore_cache}}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(),
                                                         timeout=20))
                if data.get("id") == 1:
                    break
    finally:
        await ws.close()
    return tab["url"]


def _verify_by_dom(room_label: str, ota_label: str, date_iso: str,
                   rate: str, debug_port: int = 9222) -> Optional[bool]:
    """Fallback verification when the capture-based diff sees nothing:
    read the RENDERED OTASheet grid directly via CDP (R1-safe — reading
    the DOM of an open tab, same precedent as VAE 1's
    _airbnb_live_price). Looks for the sent rate in the room's Standard
    row. Returns True/False, or None when the read itself fails."""
    import urllib.request

    async def _read():
        import websockets
        with urllib.request.urlopen(
                f"http://127.0.0.1:{debug_port}/json/list", timeout=3) as r:
            tabs = json.loads(r.read().decode())
        tab = next((t for t in tabs if t.get("type") == "page"
                    and "OTASheet" in (t.get("url") or "")), None)
        if not tab:
            return None
        ws = await websockets.connect(tab["webSocketDebuggerUrl"])
        try:
            await ws.send(json.dumps({
                "id": 1, "method": "Runtime.evaluate",
                "params": {
                    "expression":
                        "(function(){var rows=document.querySelectorAll('tr');"
                        "var roomRe=new RegExp(" + json.dumps(room_label) + ",'i');"
                        "var rb=-1;"
                        "for(var i=0;i<rows.length;i++){"
                        "if(roomRe.test((rows[i].textContent||'').slice(0,60))){rb=i;break;}}"
                        "if(rb<0)return 'null';"
                        "for(var k=rb;k<Math.min(rb+4,rows.length);k++){"
                        "var row=rows[k];var t=(row.textContent||'');"
                        "if(t.indexOf('Standard')<0)continue;"
                        "var otaRe=new RegExp(" + json.dumps(ota_label) + ",'i');"
                        "if(!otaRe.test(t))continue;"
                        "var cells=row.querySelectorAll('td');"
                        "for(var c=1;c<cells.length;c++){"
                        "var v=(cells[c].textContent||'').replace(/[,\\s]/g,'');"
                        "if(v===" + json.dumps(rate) + ")return v;}"
                        "return 'miss';}"
                        "return 'null';})()",
                    "returnByValue": True}}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(), timeout=15))
                if data.get("id") == 1:
                    return data.get("result", {}).get("result", {}).get("value")
        finally:
            await ws.close()

    try:
        raw = asyncio.run(_read())
        if raw is None or raw == "null":
            return None
        return raw != "miss"
    except Exception:
        return None


def _wait_addbulkupdate_post(captures_dir, t_after: float,
                             timeout: float = 15.0, say=print) -> Optional[str]:
    """D32-1: POST PROOF — poll the passive captures for an AddBulkUpdate
    request emitted after `t_after`. Pure file reading: nothing is ever
    sent (R1). A submit click that produces no POST means the page's
    Angular handlers are dead and the send never left the browser (the
    2026-08-27 14:00 false-"verified" file: 31 clicks, 0 POST)."""
    cdir = Path(captures_dir)
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            for f in cdir.glob("*.json"):
                try:
                    if f.stat().st_mtime < t_after - 2.0:
                        continue
                    d = json.loads(f.read_text(encoding="utf-8"))
                    url = str(d.get("url")
                              or (d.get("request") or {}).get("url") or "")
                    if "AddBulkUpdate" in url:
                        return f.name
                except Exception:
                    continue
        except Exception:
            pass
        time.sleep(2.0)
    return None


def _revive_browser(map_path: Path, debug_port: int = 9222, say=print) -> None:
    """D32-1 companion: one OS-level raise (proven D31 recipe, reused
    verbatim through the Executor method) so a half-dead tab finishes its
    Angular bootstrap — used when the POST proof fails, so the NEXT task
    of the queue runs on a live page instead of hammering a dead one."""
    try:
        exe = Executor(map_path=map_path, test_mode=True,
                       debug_port=debug_port, log_sink=say)
        exe._raise_browser_window()
    except Exception as e:
        say(f"[revive] could not raise the browser window: {e}")


def run_task(task: Task, *, map_path: Path, captures_dir: Path,
             confirmed: bool = False, before_report: Optional[Path] = None,
             after_out: Optional[Path] = None,
             journal_path: Optional[Path] = None,
             debug_port: int = 9222,
             log_sink=None) -> Dict[str, Any]:
    _say = log_sink or print
    result: Dict[str, Any] = {"task": asdict(task), "confirmed": confirmed,
                              "phases": [], "ts_start": datetime.now().isoformat()}

    def phase(name: str, status: str, detail: str = "") -> None:
        result["phases"].append({"phase": name, "status": status,
                                 "detail": detail,
                                 "ts": datetime.now().isoformat()})
        _say(f"[{name}] {status} {detail}")

    # D107 : STOP = STOP — checked between EVERY phase of a task. A ⏹ can
    # no longer be ignored because the task already started: the running
    # phase finishes (at most the browser action in flight), the following
    # ones are cancelled. Never retried, never counted as a failure.
    from vae2.executor import STOP_REQUESTED as _STOP  # local: import loop

    def _stopped() -> bool:
        return _STOP.is_set()

    def _refuse_stopped(where: str) -> bool:
        if not _stopped():
            return False
        phase(where, "STOPPED (⏹)", "stop requested by the user")
        result["outcome"] = "stopped_by_user"
        _save(result, journal_path)
        return True

    # 1. activity window (D10)
    if not in_activity_window():
        phase("window", "REFUSED",
              f"outside activity window {DEFAULT_ACTIVITY_WINDOW}")
        result["outcome"] = "refused_window"
        return result
    phase("window", "ok", f"inside {DEFAULT_ACTIVITY_WINDOW}")
    if _refuse_stopped("window"):
        return result

    # 2. pre-flight: read-only location of every form element
    async def preflight() -> Dict[str, Any]:
        exe = Executor(map_path=map_path, test_mode=True, debug_port=debug_port,
                       log_sink=_say)
        try:
            try:
                await exe.connect("BulkUpdate")
            except CMLoginRequired:
                # D26: 2-click re-login via Brave autofill (no credential
                # ever stored/read) — on success retry ONCE, on failure the
                # CMLoginRequired propagates (manual login, D24).
                _say("[autologin] CM session expired — 2-click "
                     "re-login (Brave autofill)")
                if not await exe.try_auto_login():
                    raise
                await exe.close()                    # drop login socket
                await exe.connect("BulkUpdate")      # fresh, form loads
            return await exe.locate_all()
        finally:
            await exe.close()

    try:
        loc = asyncio.run(preflight())
    except CMLoginRequired as e:
        phase("preflight", "LOGIN REQUIRED (2-click auto-login failed)",
              str(e))
        result["outcome"] = "cm_login_required"
        _save(result, journal_path)
        return result
    except ExecutorError as e:
        phase("preflight", "FAILED", str(e))
        result["outcome"] = "preflight_failed"
        _save(result, journal_path)
        return result
    except StopRequested as e:
        # D107 : ⏹ during preflight — nothing was touched.
        phase("preflight", "STOPPED (⏹)", str(e))
        result["outcome"] = "stopped_by_user"
        _save(result, journal_path)
        return result
    if not (loc.get("form", {}).get("found") and loc.get("submit", {}).get("found")):
        phase("preflight", "FAILED", "form or submit not found on the page")
        result["outcome"] = "preflight_failed"
        _save(result, journal_path)
        return result
    phase("preflight", "ok",
          f"form+submit found, {len(loc['collections']['ota']['items'])} OTAs, "
          f"{len(loc['collections']['rateplan']['items'])} rateplans")
    if _refuse_stopped("preflight"):
        return result

    # 3. execution (test mode unless the owner confirmed REAL)
    async def execute() -> List[dict]:
        exe = Executor(map_path=map_path, test_mode=not confirmed,
                       debug_port=debug_port, log_sink=_say)
        try:
            try:
                await exe.connect("BulkUpdate")
            except CMLoginRequired:
                # D26: same 2-click autofill re-login as preflight
                _say("[autologin] CM session expired — 2-click "
                     "re-login (Brave autofill)")
                if not await exe.try_auto_login():
                    raise
                await exe.close()
                await exe.connect("BulkUpdate")
            await exe.execute_price_change(
                task.room_label, task.ota_label, task.rate,
                task.date_from, task.date_to, task.days)
            return [asdict(e) for e in exe.journal]
        finally:
            await exe.close()

    _t_execute_start = time.time()   # D32-1: POST-proof time origin
    try:
        journal = asyncio.run(asyncio.wait_for(execute(), timeout=420))
        result["executor_journal"] = journal
        phase("execute", "ok",
              "TEST mode — submit skipped" if not confirmed else "REAL — submitted")
    except CMLoginRequired as e:
        phase("execute", "LOGIN REQUIRED (2-click auto-login failed, "
              "page left as-is)", str(e))
        result["outcome"] = "cm_login_required"
        _save(result, journal_path)
        return result
    except asyncio.TimeoutError:
        phase("execute", "FAILED (D12 stop, page left as-is)",
              "global watchdog: execution exceeded 420 s")
        result["outcome"] = "executor_timeout"
        result["retry_policy"] = RETRY_POLICY
        _save(result, journal_path)
        return result
    except StopRequested as e:
        # D107 : ⏹ during typing/submit — page left as-is, no following
        # step, no retry.
        phase("execute", "STOPPED (⏹, page left as-is)", str(e))
        result["outcome"] = "stopped_by_user"
        _save(result, journal_path)
        return result
    except ExecutorError as e:
        phase("execute", "FAILED (D12 stop, page left as-is)", str(e))
        result["outcome"] = "executor_failed"
        result["retry_policy"] = RETRY_POLICY
        _save(result, journal_path)
        return result

    if not confirmed:
        result["outcome"] = "test_ok_no_modification"
        _save(result, journal_path)
        return result

    # ── D32-1: POST PROOF (REAL runs only) ─────────────────────────────
    # The submit click having been made proves NOTHING: on a half-dead
    # Angular tab the click lands and no request ever leaves the browser.
    # The ONLY acceptable proof is a captured AddBulkUpdate POST newer
    # than the execution start (passive capture reading, R1 — zero
    # request emitted by us). Without it: D12 failure + one revive so the
    # next task of the queue runs on a live page.
    # D107 : the ⏹ does NOT cut the POST proof of an ALREADY-clicked
    # submit — reading what actually left the browser remains the minimum
    # duty ; the grid verification behind it, however, is cancelled.
    post_file = _wait_addbulkupdate_post(captures_dir, _t_execute_start,
                                         timeout=15.0, say=_say)
    if post_file is None:
        phase("post-proof", "FAILED",
              "NO AddBulkUpdate POST captured after the Update click — "
              "the shipment never left the browser (dead Angular "
              "buttons) ; reviving the tab for the next task")
        _revive_browser(map_path, debug_port=debug_port, say=_say)
        result["outcome"] = "post_missing_after_submit"
        result["retry_policy"] = RETRY_POLICY
        _save(result, journal_path)
        return result
    phase("post-proof", "ok", f"AddBulkUpdate POST captured: {post_file}")
    # D80 : legal ledger — THE proof that this shipment left the browser
    # (cited passive-capture file). Non-blocking failure.
    try:
        from business import legal_ledger as _ll
        _ll.journal_post_proof(
            post_file, room=task.room_label, ota=task.ota_label,
            rate=task.rate, from_date=task.date_from,
            to_date=task.date_to)
    except Exception:
        pass

    # 4. verification: reload OTASheet -> scan -> diff (REAL runs only)
    # D107 : a ⏹ also cancels the wait for the newly captured grid.
    if _refuse_stopped("verify"):
        return result
    try:
        verification_started = time.time()
        url = asyncio.run(reload_otasheet(
            debug_port, ignore_cache=True, map_path=map_path,
            date_from=task.date_from))
        phase("verify", "otasheet reloaded", url)
        # The listener discovers tabs and retrieves response bodies on its
        # own schedule. A fixed 18-second delay produced false unverified
        # results when a valid capture arrived later. Poll only for a grid
        # captured after this reload; never accept an older file.
        deadline = time.monotonic() + FRESH_GRID_TIMEOUT_SECONDS
        # D138: the proof is PROVOKED, not hoped for. When half the
        # budget has passed without any fresh grid capture, reload the
        # OTASheet tab a SECOND time: the first reload sometimes lands
        # before the server applied the change (or the listener missed
        # it), and the wait used to die of timeout with nothing to show.
        _reloaded_again = False
        while True:
            if _refuse_stopped("verify"):
                return result
            report = run_scan(captures_dir, map_path,
                              min_capture_time=verification_started)
            if (report.status == "ok" and
                    report.sources_status.get("otasheet_grid", {}).get("found")):
                break
            remaining = deadline - time.monotonic()
            if not _reloaded_again and remaining <= FRESH_GRID_TIMEOUT_SECONDS / 2:
                _reloaded_again = True
                try:
                    url2 = asyncio.run(reload_otasheet(
                        debug_port, ignore_cache=True, map_path=map_path,
                        date_from=task.date_from))
                    phase("verify", "otasheet reloaded again", url2)
                except Exception as _exc:
                    phase("verify", "second reload failed", str(_exc))
            if remaining <= 0:
                break
            time.sleep(min(3.0, remaining))
        if after_out:
            after_out.parent.mkdir(parents=True, exist_ok=True)
            after_out.write_text(json.dumps(asdict(report), indent=2,
                                            ensure_ascii=False),
                                 encoding="utf-8")
        phase("verify", "scanned",
              f"captured_at={report.captured_at} status={report.status}")
        if (report.status != "ok" or
                not report.sources_status.get("otasheet_grid", {}).get("found")):
            phase("verify", "unconfirmed",
                  "no fresh OTASheet capture after submission; old prices ignored")
            result["outcome"] = "submitted_but_change_not_seen"
            _save(result, journal_path)
            return result
        if before_report and before_report.exists():
            old = json.loads(before_report.read_text(encoding="utf-8"))
            changes = compare_reports(old, asdict(report))
            real_changes = [c for c in changes if c["event"] == "price_changed"]
            result["price_changes"] = real_changes
            phase("verify", "diff",
                  f"{len(real_changes)} real price change(s)")
            for c in real_changes:
                _say(f"   {c['room_label']} / {c['ota_label']} "
                     f"{c['date']}: {c['old_price']} -> {c['new_price']} "
                     f"{c['currency'] or ''}")
            expected_room = task.room_label.lower()

            def _is_consigned(c: dict) -> bool:
                """D32-2: STRICT criterion — 24/08 standard restored. The
                observed change must BE the consigned one: right room,
                right OTA, a date inside the task's own range, and the new
                price exactly the rate we typed. 'Some change for that
                room+OTA' is NOT verification (that looseness produced the
                2026-08-27 false-'verified' file by re-counting one older
                landed send against every task of the queue)."""
                if not _same_grid_label(task.room_label,
                                        c.get("room_label") or ""):
                    return False
                if not _same_grid_label(task.ota_label,
                                        c.get("ota_label") or ""):
                    return False
                d = str(c.get("date") or "")
                if not (task.date_from <= d <= task.date_to):
                    return False
                try:
                    return int(float(c["new_price"])) == int(float(task.rate))
                except (KeyError, TypeError, ValueError):
                    return False

            matched = [c for c in real_changes if _is_consigned(c)]
            grid_complete = grid_shows_rate(
                asdict(report), task.room_label, task.ota_label, task.rate,
                task.date_from, task.date_to)
            if matched and grid_complete:
                result["outcome"] = "verified"
            else:
                # D117 : "already in place" — the POST did leave (proof
                # read above) and the AFTER grid already shows the sent
                # price over the range: nothing failed. The diff cannot
                # see a change when the same value is being restored
                # (D33-a) — the old "probable rollback" note was a false
                # alarm for this case (observed 12/10: diff 0 at every
                # verification, POSTs captured nevertheless).
                if grid_complete:
                    phase("verify", "already-in-place",
                          f"grid already shows {task.rate} — nothing failed")
                    result["outcome"] = "already_in_place"
                else:
                    # Fallback: the listener may have missed the grid capture —
                    # read the rendered OTASheet directly (proven method).
                    dom_ok = _verify_by_dom(task.room_label, task.ota_label,
                                            task.date_from, task.rate, debug_port)
                    phase("verify", "dom-fallback",
                          "one rate visible in DOM; full date range not proven"
                          if dom_ok is True else "full date range not proven")
                    result["outcome"] = "submitted_but_change_not_seen"
        else:
            result["outcome"] = (
                "already_in_place" if grid_shows_rate(
                    asdict(report), task.room_label, task.ota_label,
                    task.rate, task.date_from, task.date_to)
                else "submitted_scan_saved_no_before")
    except Exception as e:
        # D150: an exception here (usually an EMPTY-message CDP timeout on
        # the grid reload, observed 02/11 ×3 at the end of a long queue)
        # means the PROOF READ failed — never the POST, which is already
        # proven above (post-proof). Re-read the captures ONCE before
        # declaring verify_error: a grid showing the sent rate is a full
        # success (already_in_place), not a failure.
        try:
            time.sleep(3.0)
            _retry_started = time.time()
            report2 = run_scan(captures_dir, map_path,
                               min_capture_time=_retry_started - 600)
            if report2.status == "ok" and grid_shows_rate(
                    asdict(report2), task.room_label, task.ota_label,
                    task.rate, task.date_from, task.date_to):
                phase("verify", "already-in-place (retry)",
                      f"grid already shows {task.rate}")
                result["outcome"] = "already_in_place"
                _save(result, journal_path)
                return result
        except Exception:
            pass
        phase("verify", "ERROR", f"{type(e).__name__}: {e}")
        result["outcome"] = "verify_error"

    _save(result, journal_path)
    return result


def _save(result: Dict[str, Any], journal_path: Optional[Path]) -> None:
    if not journal_path:
        return
    journal_path.parent.mkdir(parents=True, exist_ok=True)
    existing = []
    if journal_path.exists():
        try:
            existing = json.loads(journal_path.read_text(encoding="utf-8"))
        except Exception:
            existing = []
    existing.append(result)
    journal_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False),
                            encoding="utf-8")


def main(argv: List[str] = None) -> int:
    warnings.simplefilter("ignore")
    ap = argparse.ArgumentParser(description="VAE 2 coordinator (brick 3)")
    ap.add_argument("--task", required=True, type=Path,
                    help="JSON file: {room_label, ota_label, rate, date_from, date_to, days?}")
    ap.add_argument("--map", type=Path, default=DEFAULT_MAPS_DIR / "channelmanager_com_au.yaml")
    ap.add_argument("--captures", type=Path, required=True,
                    help="VAE listener capture directory")
    ap.add_argument("--before", type=Path, default=None,
                    help="scan report JSON taken BEFORE the run (enables the diff)")
    ap.add_argument("--after-out", type=Path, default=None)
    ap.add_argument("--journal", type=Path, default=None)
    ap.add_argument("--confirmed", action="store_true",
                    help="REAL mode: submit the form (owner-confirmed only)")
    args = ap.parse_args(argv)

    task = Task(**json.loads(args.task.read_text(encoding="utf-8")))
    result = run_task(task, map_path=args.map, captures_dir=args.captures,
                      confirmed=args.confirmed, before_report=args.before,
                      after_out=args.after_out, journal_path=args.journal)
    print(f"\nOUTCOME: {result.get('outcome')}")
    good = result.get("outcome") in ("test_ok_no_modification", "verified")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
