"""
Tab: OTA Blocking
Part of ScraperApp via mixin inheritance.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import sys as _sys
from pathlib import Path
BASE_DIR = Path(__file__).parent.parent
from core.paths import DATA_DIR

from datetime import datetime, timedelta
import threading
import logging
import re
from copy import deepcopy
from core.theme import T, THEMES
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip, zebra_stripe, status_badge, _btn_fg
from core.utils import tr_, attach_sort, fmt_dt, parse_dt_any
from core import config as cfg
from core.base_tab import BaseTab
from core.ota_selection import (page_key, merge_pages, save_page_choices,
                                selected_page_keys, profile_urls)
_attach_sort = attach_sort
RISK_COLORS = {'safe': '#27ae60', 'medium': '#2980b9', 'high': '#e67e22', 'danger': '#c0392b'}
RISK_LABELS  = {'safe': 'SAFE',   'medium': 'MEDIUM',  'high': 'HIGH',    'danger': 'DANGER'}

# Currency symbol map — dynamic so VAE integration can use any host currency.
_CURRENCY_SYMBOLS = {
    'INR': '\u20b9', 'USD': '$', 'EUR': '\u20ac', 'GBP': '\u00a3',
    'THB': '\u0e3f', 'JPY': '\u00a5', 'CNY': '\u00a5', 'AUD': 'A$',
    'CAD': 'C$', 'CHF': 'Fr', 'SGD': 'S$', 'AED': 'AED', 'LAK': '\u20ad',
}


def _currency_symbol(config):
    """Return the display symbol for the configured hotel currency."""
    code = (config.get('hotel_currency')
            or config.get('currency_code')
            or 'INR')
    return _CURRENCY_SYMBOLS.get(str(code).upper(), str(code) + ' ')


def load_config(): return cfg.load()


def _get(name, default=None):
    """Access to main's global variables (colors, UI helpers)."""
    return getattr(_sys.modules.get("__main__"), name, default)


def _median(xs):
    """Median of a list of numbers (average of the two middle values if
    even count). Returns None if the list is empty."""
    xs = sorted(xs)
    n = len(xs)
    if n == 0:
        return None
    if n % 2:
        return xs[n // 2]
    return (xs[n // 2 - 1] + xs[n // 2]) / 2


def _cm_override_for(ov_c: dict, rm: str, fb: str = None) -> dict:
    """D94: "CM send min/max" setting of ONE room — EXACT name only
    (or explicit `fb` fallback, itself an already-resolved room name).
    NEVER fuzzy matching: the 2000 override of "Double Room with
    Balcony" leaked onto "Double Room" (Jaccard 0.5 >= old code
    threshold) and blocked its target forever — the gap was visible
    in the client PC D92 report (05/10): "computed price 1,736 below
    the allowed minimum 2,000" while the room's declared floor is
    1400. An override is a DELIBERATE per-room decision: name
    similarity has nothing to do with it (same kind as D86: nested
    names)."""
    if rm in ov_c:
        return ov_c.get(rm) or {}
    if fb and fb in ov_c:
        return ov_c.get(fb) or {}
    return {}


# ── Safety limit: no amount received → no price returned ────────────────────
# Without an amount detected in the text, we never return a price: a price
# without a source would be invented, then sent to the Channel Manager as if
# it were real.
#
# The multi-date fallback (lower in this file) only triggers for rooms WITHOUT
# a price (`_missing`). An invented price would make it look like the room was
# found, would block the date change, and would go to the Channel Manager.
#
# The rule is therefore: no amount in the text → the room stays without a
# price, which hands control back to the multi-date fallback, whose exact
# role this is.
_PRICE_IN_TEXT = re.compile(
    # 1. amount attached to a currency (visible page text)
    r"(?:Rs\.?|INR|₹|₨|\$|USD|€|EUR|£|GBP|฿|THB|¥|JPY)\s*\d[\d\s,\.]{2,}"
    r"|\d[\d\s,\.]{2,}\s*(?:Rs\.?|INR|₹|₨|USD|EUR|GBP|THB|JPY)"
    # 2. amount carried by a JSON key or an HTML attribute (page code:
    #    "price":1234, data-rate='1234'…) — a price is still a price even when
    #    the currency is declared elsewhere in the document.
    r"|(?:price|amount|rate|tarif|prix|total|montant)[\"'\s\]]*[:=][\"'\s]*\d{3,}",
    re.IGNORECASE,
)


def _text_has_price(text: str) -> bool:
    """Does the text contain at least one amount (anywhere in the page)?

    Bug C2: previously only the first 4000 characters were tested. The whole
    page must be tested so as not to miss a price located further down.
    """
    return bool(text) and bool(_PRICE_IN_TEXT.search(text))


# ── Blocking / CAPTCHA detection (free, no AI) ──────────────────────────────
# Signal words present on a blocking or anti-robot challenge page. The
# detection is purely textual (no AI call, no cost). It only serves to KNOW
# that a block happened — never to interrupt an engine.
#
# These words are only searched in the TEXT ACTUALLY DISPLAYED, never in the
# page's hidden code (<script>, <style>, comments, attributes). Many perfectly
# accessible sites embed these words in their JavaScript configuration:
# Airbnb for example exposes {"disable_google_recaptcha": true} and a
# "datadome_integration" key while the page displays normally; Google Hotels
# likewise. Searching the raw code therefore triggered a blocking alert on
# every reading of OTAs that blocked nothing (observed: Airbnb ×4 and Google
# Hotels).
_BLOCK_SIGNALS = (
    # English
    "captcha", "recaptcha", "hcaptcha", "are you human", "are you a human",
    "human or a bot", "human or bot", "bot or not", "not a robot",
    "unusual traffic", "verify you are", "access denied", "access to this page",
    "datadome", "px-captcha", "perimeterx", "just a moment",
    "checking your browser", "enable javascript and cookies", "security check",
    "press and hold", "confirm you are", "suspicious activity",
    # French — the software browses in fr-FR on most OTAs, so blocking pages
    # are often translated there. (DATA strings: match French page text.)
    "accès refusé", "acces refuse", "activité suspecte", "trafic inhabituel",
    "vérification de sécurité", "je ne suis pas un robot",
    "vérifier que vous êtes", "appuyez et maintenez",
)

# Markers of a VISIBLE challenge (image grid / text to solve), as opposed to
# an invisible block where there is nothing for the AI to solve.
# These are MARKUP identifiers (classes, id, src): they are searched in the
# markup, but not inside <script> bodies — a mere mention of "grecaptcha" in
# a JavaScript configuration block does not mean a challenge is displayed, and
# this detection triggers a paid expense (automatic resolution).
_VISIBLE_CAPTCHA_MARKERS = (
    "g-recaptcha", "recaptcha/api2", "recaptcha/api.js", "grecaptcha",
    "h-captcha", "hcaptcha.com", "captcha-image", "captcha_image",
    "px-captcha", "press and hold",
)

# Code blocks never displayed on screen, removed before any signal-word
# search.
_RE_HIDDEN_BLOCKS = re.compile(
    r"(?is)<script\b.*?</script\s*>"
    r"|<style\b.*?</style\s*>"
    r"|<noscript\b.*?</noscript\s*>"
    r"|<template\b.*?</template\s*>"
    r"|<!--.*?-->")
_RE_ALL_TAGS = re.compile(r"(?s)<[^>]*>")
# Empties the BODY of <script> tags but keeps the tag and its attributes, so
# that a <script src="…/recaptcha/api.js"> remains visible.
_RE_SCRIPT_BODY = re.compile(r"(?is)(<script\b[^>]*>).*?(</script\s*>)")


def _visible_text(html_or_text):
    """Keep only what the page actually displays.

    Removes <script>/<style>/<noscript>/<template> blocks, HTML comments, then
    all tags (thus also their attributes, which often contain technical
    identifiers like "captcha-container").
    An input already in plain text comes out unchanged.
    """
    if not html_or_text:
        return ""
    return _RE_ALL_TAGS.sub(" ", _RE_HIDDEN_BLOCKS.sub(" ", html_or_text))


def _markup_without_scripts(html):
    """Full markup, but stripped of the executable content of <script> tags."""
    if not html:
        return ""
    return _RE_SCRIPT_BODY.sub(r"\1\2", html)


def _looks_blocked(html_or_text):
    """True if the page DISPLAYS a block / CAPTCHA.

    Free keyword-based detection — no AI. The search covers the visible text
    only (see _visible_text): the hidden code of a normal page very often
    contains these words without any actual block. In any case this detection
    is only used when NO price was found (see the recovery step in _run_4eng).
    """
    if not html_or_text:
        return False
    t = _visible_text(html_or_text).lower()
    return any(s in t for s in _BLOCK_SIGNALS)


def _captcha_visible(html):
    """True if the block offers a VISIBLE challenge (solvable by AI or by
    hand), False if it is an invisible block (nothing to solve: background
    risk score, see reCAPTCHA v3 / DataDome / PerimeterX)."""
    if not html:
        return False
    t = _markup_without_scripts(html).lower()
    return any(s in t for s in _VISIBLE_CAPTCHA_MARKERS)


def _xb_scan_end():
    """D52: releases the scan operation slot (idempotent)."""
    try:
        import extranet_bridge as _xb
        _xb.operation_end("scan")
    except Exception:
        pass


# ── Auto-detection OTA from Brave via CDP ──────────────────────────────────

_CDP_PORT = 9222

# Domain substring → display name for known OTAs.
# Regional TLDs are listed so that country-specific domains
# (expedia.fr, booking.com, airbnb.co.uk…) are always detected.
_DOMAIN_DISPLAY = {
    # Agoda
    "agoda.com": "Agoda", "agoda.net": "Agoda",
    # Booking
    "booking.com": "Booking.com",
    # Expedia (all regional TLDs)
    "expedia.com": "Expedia", "expedia.fr": "Expedia",
    "expedia.co.uk": "Expedia", "expedia.de": "Expedia",
    "expedia.ca": "Expedia", "expedia.es": "Expedia",
    "expedia.it": "Expedia", "expedia.nl": "Expedia",
    "expedia.com.au": "Expedia", "expedia.co.in": "Expedia",
    "expedia.co.jp": "Expedia", "expedia.com.br": "Expedia",
    "expedia.com.sg": "Expedia", "expedia.co.th": "Expedia",
    "expedia.ae": "Expedia", "expedia.sa": "Expedia",
    "expedia.com.my": "Expedia", "expedia.co.id": "Expedia",
    "expedia.com.hk": "Expedia", "expedia.com.tw": "Expedia",
    "expedia.com.ph": "Expedia", "expedia.vn": "Expedia",
    # Airbnb
    "airbnb.com": "Airbnb", "airbnb.fr": "Airbnb",
    "airbnb.co.uk": "Airbnb", "airbnb.de": "Airbnb",
    "airbnb.es": "Airbnb", "airbnb.it": "Airbnb",
    "airbnb.ca": "Airbnb", "airbnb.com.au": "Airbnb",
    "airbnb.co.in": "Airbnb", "airbnb.jp": "Airbnb",
    "airbnb.com.br": "Airbnb", "airbnb.nl": "Airbnb",
    "airbnb.be": "Airbnb", "airbnb.ch": "Airbnb",
    # MakeMyTrip
    "makemytrip.com": "MakeMyTrip", "makemytrip.global": "MakeMyTrip",
    # Goibibo
    "goibibo.com": "Goibibo",
    # Kayak
    "kayak.com": "Kayak", "kayak.co.uk": "Kayak", "kayak.fr": "Kayak",
    "kayak.de": "Kayak", "kayak.es": "Kayak", "kayak.it": "Kayak",
    "kayak.ca": "Kayak", "kayak.com.au": "Kayak", "kayak.co.in": "Kayak",
    # TripAdvisor
    "tripadvisor.com": "TripAdvisor", "tripadvisor.fr": "TripAdvisor",
    "tripadvisor.co.uk": "TripAdvisor", "tripadvisor.de": "TripAdvisor",
    "tripadvisor.es": "TripAdvisor", "tripadvisor.it": "TripAdvisor",
    "tripadvisor.ca": "TripAdvisor", "tripadvisor.in": "TripAdvisor",
    "tripadvisor.com.au": "TripAdvisor",
    # Hotels.com
    "hotels.com": "Hotels.com", "hotels.fr": "Hotels.com",
    "hotels.co.uk": "Hotels.com", "hotels.de": "Hotels.com",
    # Traveloka
    "traveloka.com": "Traveloka",
    # Trip.com / Ctrip
    "trip.com": "Trip.com", "ctrip.com": "Trip.com",
    # HRS
    "hrs.com": "HRS",
    # LastMinute
    "lastminute.com": "LastMinute",
    # Weekendesk
    "weekendesk.com": "Weekendesk", "weekendesk.fr": "Weekendesk",
    # Priceline
    "priceline.com": "Priceline",
    # Hostelworld
    "hostelworld.com": "Hostelworld",
    # Almosafer
    "almosafer.com": "Almosafer",
    # Rehlat
    "rehlat.com": "Rehlat",
    # Tiket
    "tiket.com": "Tiket.com",
}

# Brand → display name fallback.  Extracted from the hostname's
# second-level domain, so ANY regional TLD is caught automatically
# (e.g. "expedia.co.nz" → brand "expedia" → "Expedia").
_BRAND_DISPLAY = {
    "agoda": "Agoda",
    "booking": "Booking.com",
    "expedia": "Expedia",
    "airbnb": "Airbnb",
    "makemytrip": "MakeMyTrip",
    "goibibo": "Goibibo",
    "kayak": "Kayak",
    "tripadvisor": "TripAdvisor",
    "hotels": "Hotels.com",
    "traveloka": "Traveloka",
    "trip": "Trip.com",
    "ctrip": "Trip.com",
    "hrs": "HRS",
    "lastminute": "LastMinute",
    "weekendesk": "Weekendesk",
    "priceline": "Priceline",
    "hostelworld": "Hostelworld",
    "almosafer": "Almosafer",
    "rehlat": "Rehlat",
    "tiket": "Tiket.com",
}

# Generalist sites excluded from auto-detection (must be added manually)
_GENERALIST_PATTERNS = (
    "google.com/travel", "google.com/hotels",
    "www.google.com/hotels", "www.google.com/travel",
    "trivago.com",
)

# D131 : les pages EXTRANET (OTA admin, CM, portails de connexion) ne sont
# PAS des annonces publiques — elles n'ont jamais leur place dans la liste
# « OTA detected from Brave » (constat propriétaire 18/10 : des pages de
# login Booking et d'extranets se cochaient toutes seules).
_EXTRANET_PATTERNS = (
    "signin", "sign-in", "sign_in", "/login", "login?",
    "accounts.", "account.booking", "//admin.", "admin.booking",
    "partners.airbnb", "portal.agoda", "ycs.agoda", "extranet",
    "channelmanager", "merusync", "update247", "hotel-admin",
    "/dashboard",
)

# Rooms that are internal CM test entries — never appear on real booking
# sites, so they must never show in scan results.
_EXCLUDED_ROOMS = {"move room"}

# Known OTA brand names (lowercase) used to group multi-room listings of
# the same OTA together in the UI. Longest brands first so that e.g.
# "google hotels" matches before "google".
_KNOWN_BRANDS = sorted(
    {v.lower() for v in _DOMAIN_DISPLAY.values()} | {
        "google hotels", "trivago", "booknow", "roibos",
    },
    key=len, reverse=True,
)

# Goibibo and MakeMyTrip share the same inventory (same parent company).
# Only one CM price can be sent for both, so they are merged into a single
# column in the target prices grid and share one target price key.
_MMT_GROUP = {"goibibo", "makemytrip"}
_MMT_DISPLAY = "MakeMyTrip / Goibibo"


def _ota_group_key(name):
    """Return the grouped OTA display name if the OTA belongs to a group.

    Goibibo and MakeMyTrip map to the same canonical name so the target
    prices grid shows one column for both.  Other OTAs return themselves.
    """
    brand = _ota_brand_key(name)
    if brand in _MMT_GROUP:
        return _MMT_DISPLAY
    return name


def _target_for_ota(room_targets, ota_name):
    """Find this OTA's target; only MakeMyTrip/Goibibo share an alias."""
    wanted = (ota_name or "").strip().casefold()
    for key, value in (room_targets or {}).items():
        if str(key).strip().casefold() == wanted and value:
            return value
    if _ota_group_key(ota_name) == _MMT_DISPLAY:
        for key, value in (room_targets or {}).items():
            if _ota_group_key(str(key)) == _MMT_DISPLAY and value:
                return value
    return 0


def _ota_brand_key(name):
    """Return the OTA brand (lowercase) used for grouping/sorting.

    'Airbnb Deluxe Double Room' -> 'airbnb'
    'Agoda'                     -> 'agoda'
    'Google Hotels'             -> 'google hotels'
    Unknown names fall back to their first word.
    """
    n = (name or "").lower().strip()
    for b in _KNOWN_BRANDS:
        if n == b or n.startswith(b + " "):
            return b
    return n.split()[0] if n else ""


# ── Per-OTA color palette (visually distinct, auto-assigned) ──────────
# Each new OTA encountered gets the next color in the palette, cycling
# back to the start when exhausted.  foreground only; background is
# handled separately by zebra_stripe().
_OTA_PALETTE = [
    "#ff6b6b",  # coral red
    "#4dabf7",  # dodger blue
    "#51cf66",  # grass green
    "#ffa94d",  # tangerine
    "#cc5de8",  # medium purple
    "#22b8cf",  # cyan
    "#ffd43b",  # golden yellow
    "#f06595",  # pink
    "#20c997",  # teal
    "#748ffc",  # cornflower blue
    "#e599f7",  # light violet
    "#ff922b",  # orange
    "#94d82d",  # lime green
    "#845ef7",  # vivid purple
    "#66d9e8",  # light cyan
    "#f783ac",  # salmon pink
    "#a9e34b",  # yellow green
    "#5c7cfa",  # indigo
    "#ffa8a8",  # light coral
    "#ffe066",  # light gold
]

_ota_color_map: dict[str, str] = {}      # brand_key -> hex color
_ota_color_counter = [0]                 # mutable counter for closures


def _get_ota_color(ota_name: str) -> str:
    """Return a consistent foreground color for *ota_name*.

    On first encounter the OTA is assigned the next available colour
    from ``_OTA_PALETTE``.  Subsequent calls return the same colour.
    The assignment uses the *brand key* so that "Airbnb Room X" and
    "Airbnb Room Y" share one colour.
    """
    key = _ota_brand_key(ota_name)
    if key not in _ota_color_map:
        _ota_color_map[key] = _OTA_PALETTE[
            _ota_color_counter[0] % len(_OTA_PALETTE)]
        _ota_color_counter[0] += 1
    return _ota_color_map[key]


def _detect_otas_from_brave(config_otas=None):
    """Detect OTA tabs from Brave browser via CDP (synchronous, fast).

    Connects to ``http://127.0.0.1:9222/json/list``, lists all browser tabs,
    filters for known OTA domains (excluding generalist sites like Google
    Hotels / Trivago), and returns a list of detected OTA entries.

    When multiple tabs of the same OTA are open (e.g. 4 Airbnb rooms),
    each tab becomes a separate entry.  A room name is extracted from
    the tab title when possible.  Entries are sorted by OTA brand so
    that same-OTA listings appear adjacent in the UI.

    Args:
        config_otas: existing OTA config list used as *fallback* when
            Brave is not running.

    Returns:
        list[dict]: ``[{name, url, domain, title, source}]``
        ``source`` is ``"brave"`` for detected tabs or ``"config"`` for
        fallback entries.
    """
    import json as _json
    import urllib.request as _urllib_req
    from urllib.parse import urlparse as _urlparse

    def _main_domain(url):
        """Extract the registrable domain (handles co.uk, com.br, etc.)."""
        try:
            h = (_urlparse(url).hostname or "").lower().replace("www.", "")
            parts = h.split(".")
            if len(parts) <= 2:
                return h
            # Known multi-part TLDs → keep last 3 parts
            _MULTI_TLD = {"co.uk", "co.jp", "co.kr", "com.br", "com.au",
                          "com.sg", "com.hk", "com.tw", "com.my", "com.ph",
                          "com.vn", "co.in", "co.id", "co.th", "co.nz",
                          "com.mx", "com.ar", "com.co", "co.za"}
            last_two = ".".join(parts[-2:])
            if last_two in _MULTI_TLD and len(parts) >= 3:
                return ".".join(parts[-3:])
            return last_two
        except Exception:
            return ""

    def _ota_name_for_url(url):
        host = (_urlparse(url).hostname or "").lower()
        # 1) Exact substring match against known domains (fast path)
        for dom, name in _DOMAIN_DISPLAY.items():
            if host == dom or host.endswith("." + dom):
                return name
        # 2) Brand-based fallback: extract the hostname's second-level
        # domain (the "brand") and match it.  This catches ANY regional
        # TLD not explicitly listed above (expedia.co.nz, booking.cm…).
        try:
            h = (_urlparse(url).hostname or "").lower().replace("www.", "")
            if h:
                brand = _main_domain(url).split(".")[0]
                if brand in _BRAND_DISPLAY:
                    return _BRAND_DISPLAY[brand]
        except Exception:
            pass
        return None

    def _room_from_title(title):
        """Try to extract a meaningful room name from a browser tab title."""
        if not title:
            return None
        parts = re.split(r'[\|–—·\-\u2013\u2014]', title)
        parts = [p.strip() for p in parts if p.strip()]
        _skip = {
            "airbnb", "booking", "expedia", "agoda", "goibibo", "makemytrip",
            "kayak", "tripadvisor", "hotels", "hotel", "resort", "jangala",
            "baga", "goa", "india", "guesthouse", "guest house", "superhost",
            "places to stay", "stays", "reviews", "book", "help center",
            "travel", "trivago", "google", "google hotels", "home",
            "move room",
        }
        _room_kw = {
            "room", "double", "single", "deluxe", "suite", "standard",
            "twin", "king", "queen", "balcony", "view", "family",
            "premium", "superior", "classic", "villa",
        }
        for p in parts:
            pl = p.lower().strip()
            if len(pl) < 3 or len(pl) > 50:
                continue
            if any(s in pl for s in _skip):
                continue
            # Prioritise parts that contain room keywords
            if any(rw in pl for rw in _room_kw):
                return p.strip()
        # Fallback: first non-skipped part
        for p in parts:
            pl = p.lower().strip()
            if len(pl) < 3 or len(pl) > 50:
                continue
            if not any(s in pl for s in _skip):
                return p.strip()
        return None

    # --- CDP call ---
    detected = []
    try:
        _req = _urllib_req.Request(f"http://127.0.0.1:{_CDP_PORT}/json/list")
        with _urllib_req.urlopen(_req, timeout=2) as _resp:
            tabs = _json.loads(_resp.read().decode())
    except Exception:
        # Brave not available -- fallback to saved config
        if config_otas:
            return [{"name": o.get("name", ""), "url": u,
                     "domain": "", "title": "",
                     "source": "config"}
                    for o in config_otas if (o.get("name", "") or "").strip()
                    for u in profile_urls(o)]
        return []

    ota_counts = {}   # brand -> total count (for multi-tab differentiation)
    ota_idx = {}      # brand -> current index

    # D114: UNIFIED Airbnb (D110) — several Airbnb tabs open at once are
    # NORMAL (one listing per tab) and all belong to THE single "Airbnb"
    # entry: never "Airbnb #2/#3/#4" (the ghost columns of the 12/10
    # report).
    _airbnb_unified = False
    try:
        _ab_cfg = [o for o in (config_otas or [])
                   if "airbnb" in (o.get("url") or "").lower()]
        _airbnb_unified = len(_ab_cfg) == 1
    except Exception:
        _airbnb_unified = False

    for tab in tabs:
        if tab.get("type") != "page":
            continue
        url = tab.get("url", "")
        title = tab.get("title", "")
        if not url or url.startswith("chrome://") or url.startswith("about:"):
            continue

        # Skip generalist sites
        url_lower = url.lower()
        if any(g in url_lower for g in _GENERALIST_PATTERNS):
            continue
        # D131 : skip extranet / sign-in pages — never OTA listings
        if any(g in url_lower for g in _EXTRANET_PATTERNS):
            continue

        ota_name = _ota_name_for_url(url)
        if not ota_name:
            continue

        ota_counts[ota_name] = ota_counts.get(ota_name, 0) + 1
        ota_idx[ota_name] = ota_idx.get(ota_name, 0) + 1

        display = ota_name

        detected.append({
            "name": display,
            "brand_name": ota_name,
            "url": url,
            "domain": _main_domain(url),
            "title": title,
            "source": "brave",
        })

    # If Brave was reachable but NO OTA tabs were found, return empty —
    # the user may have closed all OTA tabs and they should disappear
    # from the UI.  Only the CDP-connection-failure fallback (above)
    # returns config entries, when Brave itself is not running.
    return detected


def _merge_detected_with_config(detected, config_otas, target_prices):
    """Keep each page's choice independent of names and Brave tab order."""
    return merge_pages(detected, {
        "otas": config_otas or [], "tab_choices": _TAB_CHOICES["choices"],
    })


_TAB_CHOICES = {"choices": {}}   # D131 : mémoire vivante {url_key: bool}

def set_tab_choices(choices: dict) -> None:
    """D131 : l'onglet publie ici les choix enregistrés (ota_watch.tab_choices)."""
    _TAB_CHOICES["choices"] = {str(k): bool(v) for k, v in (choices or {}).items()}

def _remembered_tab_choice(url: str):
    """D131 : le choix mémorisé pour cette page, False si aucun (décoché)."""
    return _TAB_CHOICES["choices"].get(_url_key_of(url), False)


def _url_key_of(url: str) -> str:
    return page_key(url)


class Tab(BaseTab):
    def build(self, app, frame):
        self.app = app
        tab = frame
        self._csym = _currency_symbol(app.config)
        # D110: A SINGLE "Airbnb" OTA — one-shot config migration
        # (entries/targets/results), persisted here once and for all.
        try:
            from core.airbnb_unify import unify_airbnb
            if unify_airbnb(app.config):
                from core import config as _cfgmod
                _cfgmod.save(app.config)
                self.app._log_journal(
                    "🔗 " + tr_("Airbnb unified: one single OTA, one "
                                "mapping per listing number "
                                "('OTA room matching' menu)"),
                    engine="AIRBNB")
        except Exception:
            pass
        # Register the scan function for the automatic loop
        self.app._ota_watch_scan_fn = self._vae_scan
        # Register the correction function for orders coming from the mobile
        # (app_core._on_mobile_command calls it via getattr, same pattern).
        self.app._ota_watch_correct_fn = self._ota_watch_correct
        topbar10 = tk.Frame(tab, bg=T.SEL_BG, pady=6, padx=10)
        topbar10.pack(fill="x")
        lbl(topbar10, tr_("🚫 OTA price block"), bold=True, size=11).pack(side="left")
        btn(topbar10, tr_("📧 Bug report"), self._send_bug_report,
            color="#f38ba8", width=13).pack(side="right", padx=(4, 0))
        btn(topbar10, tr_("🖥️ Remote support"), self._open_remote_support,
            color="#94e2d5", width=17).pack(side="right", padx=(4, 0))
        btn(topbar10, tr_("📖 Wiki"), lambda: self._show_wiki("🚫 Blocage prix OTA"), color="#89b4fa", width=10).pack(side="right")
        btn(topbar10, tr_("💾 Save"), self._ota_watch_save, color=T.ACCENT, width=10).pack(side="right", padx=(4, 0))

        # TEST MODE banner (G8-1 audit, option A). The wizard starts a new
        # user in test_mode (no real send to the Channel Manager); without a
        # visible reminder, they believe their prices are online while
        # everything is simulated. This banner stays displayed as long as
        # test_mode is active.
        self._test_mode_banner = tk.Label(
            tab, bg="#f38ba8", fg="#1e1e2e", font=("Segoe UI", 9, "bold"),
            anchor="w", padx=12, pady=5)
        self._refresh_test_mode_banner()

        outer, inner = scrolled_frame(tab)
        outer.pack(fill="both", expand=True)

        self._ota_watch_container = tk.Frame(inner, bg=T.BG)
        self._ota_watch_container.pack(fill="x")
        try:
            self._build_ota_watch_section(self._ota_watch_container)
        except Exception:
            import traceback as _tb
            tk.Label(self._ota_watch_container,
                     text=tr_("Error building OTA Watch section:\n{e}").format(
                         e=_tb.format_exc()),
                     bg=T.BG, fg=T.RED, font=("Courier New", 8),
                     justify="left").pack(padx=10, pady=10)

        self._build_cm_history_section(inner)

        tk.Frame(inner, bg=T.SEL_BG, height=2).pack(fill="x", padx=10, pady=(16, 10))

        self._build_price_floor_section(inner)

        self._cm_ota_container = tk.Frame(inner, bg=T.BG)
        self._cm_ota_container.pack(fill="x")
        try:
            self._build_cm_ota_section(self._cm_ota_container)
        except Exception:
            import traceback as _tb
            tk.Label(self._cm_ota_container,
                     text=tr_("CM-OTA section construction error:\n{e}").format(
                         e=_tb.format_exc()),
                     bg=T.BG, fg=T.RED, font=("Courier New", 8),
                     justify="left").pack(padx=10, pady=10)

        # NOTE: Brave tab re-detection is no longer on a fixed 30 s timer —
        # that timer rebuilt the whole section and made the window blink every
        # 30 s. It now runs once at the end of each scan (see _vae_scan_done).
        # Start CM OTA scheduled-push checker (every 60 s)
        self.app.root.after(60_000, self._cm_ota_scheduled_push_loop)

    def _refresh_test_mode_banner(self):
        """Shows/hides the TEST MODE banner according to channel_manager.test_mode.
        Called at build time and each time the tab is shown (the setting can be
        changed from the wizard or the Channel Manager without restart)."""
        lbl_w = getattr(self, "_test_mode_banner", None)
        if lbl_w is None or not lbl_w.winfo_exists():
            return
        test_on = bool(self.app.config.get("channel_manager", {}).get("test_mode", False))
        if test_on:
            lbl_w.config(text=tr_("🧪 TEST MODE ACTIVE — no prices are sent to the Channel Manager. Shipments are simulated. Switch to “REAL Mode” (Wizard → Channel Manager, or Configuration → Channel Manager) to actually apply your prices."))
            lbl_w.pack(fill="x", after=lbl_w.master.winfo_children()[0])
        else:
            lbl_w.pack_forget()

    # ─── EFFICIENCY BAR ──────────────────────────────────────────────────────

    def refresh_on_show(self):
        """Tab built once at startup — re-synchronizes sections that depend on
        room_types (added/removed in My Hotel) each time this tab becomes
        visible again, without restart."""
        import logging
        try:
            self._refresh_test_mode_banner()
        except Exception:
            logging.exception("refresh_on_show (tab_blocage_ota): test mode banner failed")
        for attr, builder in (
            ("_ota_watch_container", self._build_ota_watch_section),
            ("_cm_ota_container",    self._build_cm_ota_section),
        ):
            container = getattr(self, attr, None)
            if container is None or not container.winfo_exists():
                continue
            # Scan in progress: do not rebuild this section, it would
            # wipe the progress bar / current status (back to 0 until
            # the next scan tick).
            if attr == "_ota_watch_container" and getattr(self, "_ota_watch_scanning", False):
                continue
            try:
                for w in container.winfo_children():
                    w.destroy()
                builder(container)
            except Exception:
                logging.exception("refresh_on_show (tab_blocage_ota): rebuild failed %s", attr)
        try:
            self._floor_refresh_trees()
        except Exception:
            logging.exception("refresh_on_show (tab_blocage_ota): _floor_refresh_trees failed")

    # ─── MY HOTEL PRICE WATCH ON OTAs ────────────────────────────────────────

    def _ota_watch_refresh_brave(self):
        """Re-detect Brave tabs and rebuild the OTA Watch section + CM OTA
        section in place, without requiring the user to leave the tab."""
        if getattr(self, "_ota_watch_scanning", False):
            return
        # Save current active toggles before rebuild so the user's
        # checkbox choices are not lost on auto-refresh.
        try:
            self._ota_watch_save()
        except Exception:
            pass
        container = getattr(self, "_ota_watch_container", None)
        if container and container.winfo_exists():
            for w in container.winfo_children():
                w.destroy()
            self._build_ota_watch_section(container)
        cm_container = getattr(self, "_cm_ota_container", None)
        if cm_container and cm_container.winfo_exists():
            for w in cm_container.winfo_children():
                w.destroy()
            self._build_cm_ota_section(cm_container)
        # Save the NEW state immediately so config stays in sync —
        # otherwise the next auto-refresh cycle sees a stale config
        # and triggers a redundant rebuild.
        try:
            self._ota_watch_save()
        except Exception:
            pass

    def _ota_watch_detect_tabs(self):
        """Re-detect Brave tabs and rebuild the OTA Watch section IF the set
        of detected OTA names has changed.

        Formerly a fixed 15/30 s timer (`_ota_watch_auto_refresh_loop`), which
        rebuilt the whole section and made the window blink every 30 s. It is
        now called once at the end of each scan (see `_vae_scan_done`), so the
        re-detection only happens when it is useful and never blinks the UI on
        a fixed schedule. Only rebuilds when this tab is visible, no scan is
        running, AND the detected OTA name set has actually changed.
        """
        try:
            _should_refresh = False
            try:
                _container = getattr(self, "_ota_watch_container", None)
                _visible = (
                    _container and _container.winfo_exists()
                    and bool(_container.winfo_ismapped()))
                if _visible and not getattr(self, "_ota_watch_scanning", False):
                    # Stable page identities detect newly opened/closed listings
                    # without rebuilding for date or tracking parameter changes.
                    _cfg_otas = self.app.config.get("ota_watch", {}).get("otas", [])
                    _current_names = {page_key(o.get("url"))
                                      for o in self._ota_watch_ota_vars}
                    _detected = _detect_otas_from_brave(_cfg_otas or None)
                    _new_names = {page_key(d.get("url")) for d in _detected}
                    if _current_names != _new_names:
                        _should_refresh = True
            except Exception:
                pass
            if _should_refresh:
                self._ota_watch_refresh_brave()
        except Exception:
            pass

    def _cm_ota_scheduled_push_loop(self):
        """Check every 60 s if a CM OTA with trigger='daily_once' is due.
        When the configured time is reached (and the OTA was not already
        pushed today), fires _send_cm_ota_prices automatically."""
        _CHECK_MS = 60_000
        try:
            from datetime import datetime as _dt
            _now   = _dt.now()
            _today = _now.strftime("%Y-%m-%d")
            _cur_hm = _now.strftime("%H:%M")

            cm_ota_cfg = self.app.config.get("cm_ota_prices", {})
            _triggered = False
            for ota_name, ota_data in cm_ota_cfg.items():
                if not isinstance(ota_data, dict):
                    continue
                if ota_data.get("trigger") != "daily_once":
                    continue
                if not ota_data.get("enabled", False):
                    continue
                # Already pushed today?
                if ota_data.get("last_auto_push_date") == _today:
                    continue
                _push_time = (ota_data.get("time") or "12:00").strip()[:5]
                if _cur_hm < _push_time:
                    continue

                # Time reached — fire the push via the UI variables
                _ota_ui = getattr(self, "_cm_ota_vars", {}).get(ota_name, {})
                _rooms  = _ota_ui.get("rooms", {})
                _lbl    = _ota_ui.get("result_lbl")
                _code   = ota_data.get("ota_code", "")
                if _rooms and _lbl and _lbl.winfo_exists():
                    # Mark as pushed BEFORE the call to prevent re-entry
                    ota_data["last_auto_push_date"] = _today
                    _triggered = True
                    self.app.root.after(0, lambda _on=ota_name, _oc=_code,
                                        _rv=_rooms, _rl=_lbl:
                                        self._send_cm_ota_prices(_on, _oc, _rv, _rl))
                    try:
                        from business.app_logger import app_log as _alog
                        _alog(f"[CM-OTA-AUTO] Auto push for {_on} at {_cur_hm}",
                              level="info", engine="CM-OTA-AUTO")
                    except Exception:
                        pass
            if _triggered:
                try:
                    from core import config as _cfgmod
                    _cfgmod.save(self.app.config)
                except Exception:
                    pass
        except Exception:
            pass
        self.app.root.after(_CHECK_MS, self._cm_ota_scheduled_push_loop)

    def _build_ota_watch_section(self, parent):
        """My hotel price watch section on the OTAs."""
        try:
            # Clear existing widgets before rebuild (used by +/− callbacks)
            for w in parent.winfo_children():
                w.destroy()

            cfg = self.app.config.get("ota_watch", {})

            s = section(parent, tr_("🎯 Monitoring my hotel — Real price on OTA"))
            s.pack(fill="x", padx=10, pady=10)
            _hdr = tk.Frame(s, bg=s.cget("bg")); _hdr.pack(fill="x", pady=(0, 4))
            lbl(_hdr, tr_("Scan your OTAs file, detect price discrepancies and automatically correct via the CM."),
                color=T.YELLOW, size=9).pack(side="left", anchor="w")
            # Refresh button: re-detect Brave tabs without leaving the tab
            tooltip(
                btn(_hdr, tr_("🔄 Refresh"), self._ota_watch_refresh_brave,
                    color=T.ACCENT, width=14),
                tr_("Re-detects open Brave tabs (useful after opening a new OTA).")
            ).pack(side="right", padx=(4, 0))

            # ── Auto-detect OTAs from Brave tabs ─────────────────────
            config_otas   = cfg.get("otas", [])
            target_prices = cfg.get("target_prices", {})

            detected = _detect_otas_from_brave(config_otas or None)
            # D131 : charger les choix mémorisés AVANT la fusion (les
            # onglets sans profil reprennent l'état choisi par l'utilisateur)
            set_tab_choices(cfg.get("tab_choices") or {})
            merged   = _merge_detected_with_config(detected, config_otas, target_prices)

            # Sort OTAs by brand so same-OTA listings stay adjacent
            # (e.g. all Airbnb rooms grouped together, not interleaved
            # with Agoda / Goibibo / Expedia).
            merged.sort(
                key=lambda d: (_ota_brand_key(d.get("name", "")),
                               d.get("name", "").lower()))

            # Store for "+" / "−" operations
            self._ota_watch_detected_list = list(merged)

            # ── OTA list UI ─────────────────────────────────────────
            ota_list_frame = tk.Frame(s, bg=T.BG)
            ota_list_frame.pack(fill="x", pady=(0, 4))

            self._ota_watch_ota_vars = []

            if merged:
                # Compact header
                hdr = tk.Frame(ota_list_frame, bg=T.BG)
                hdr.pack(fill="x", pady=(0, 2))
                lbl(hdr, tr_("OTA detected from Brave"), bold=True, color=T.ACCENT,
                    size=9).pack(side="left", padx=(4, 8))
                lbl(hdr, tr_("Active"), bold=True, color=T.ACCENT,
                    size=9).pack(side="right", padx=(0, 20))

                for d in merged:
                    bg_row = T.ENTRY_BG if len(self._ota_watch_ota_vars) % 2 == 0 else T.BG
                    row = tk.Frame(ota_list_frame, bg=bg_row, padx=8, pady=4)
                    row.pack(fill="x", pady=(0, 1))

                    src = d.get("source", "brave")
                    icon = "🟢" if src == "brave" else "➕"
                    lbl(row, f"{icon} {d['name']}", color=T.FG, size=9).pack(
                        side="left", padx=(0, 6))

                    # Short URL hint
                    _url_s = (d.get("url") or "")[:55]
                    if _url_s:
                        lbl(row, _url_s + ("…" if len(d.get("url") or "") > 55 else ""),
                            color="#888888", size=7).pack(side="left", padx=(0, 6))

                    # Active toggle
                    active_v = tk.BooleanVar(value=d.get("active", True))
                    tk.Checkbutton(row, text=tr_("Active"), variable=active_v,
                                   bg=bg_row, fg=T.FG, selectcolor=T.BG,
                                   activebackground=bg_row,
                                   font=("Segoe UI", 8),
                                   command=lambda k=page_key(d["url"]), v=active_v:
                                       self._ota_page_toggled(k, v)).pack(side="right", padx=(0, 4))

                    self._ota_watch_ota_vars.append({
                        "name": d["name"],
                        "url": d.get("url", ""),
                        "active": active_v,
                        "source": src,
                        "profile_name": d.get("profile_name", ""),
                        "brand_name": d.get("brand_name", d["name"]),
                    })
            else:
                lbl(ota_list_frame,
                    tr_("❌ No OTA tabs detected in Brave. Open your hotel's OTA pages in Brave, then come back here."),
                    color=T.RED, size=9).pack(anchor="w", padx=8)

            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=8)

            # ── Target prices grid (dynamic columns by OTA name) ─────
            # Merge Goibibo + MakeMyTrip into one column (same inventory,
            # one CM price).  Other OTAs keep their own column.
            _raw_otas = [d for d in self._ota_watch_ota_vars if d.get("name")]
            _seen_groups: set[str] = set()
            active_otas: list[dict] = []
            for _d in _raw_otas:
                _gk = _ota_group_key(_d["name"])
                # D116: deduplication on the group name WITHOUT exception —
                # the old condition only skipped RENAMED entries
                # (Goibibo/MakeMyTrip); since D114, every Airbnb tab
                # produces an exact "Airbnb" row → N identical Airbnb
                # columns in the targets table (12/10 report).
                if _gk in _seen_groups:
                    continue  # duplicate (grouped or exact) — one column
                _seen_groups.add(_gk)
                if _gk != _d["name"]:
                    _merged = dict(_d)
                    _merged["name"] = _gk
                    active_otas.append(_merged)
                else:
                    active_otas.append(_d)

            lbl(s, tr_("Target prices per room — price you want the guest to see on the OTA"),
                bold=True).pack(anchor="w", pady=(4, 2))
            lbl(s, tr_("The price sent to the Channel Manager is not the target price: the software measures what the OTA does with each shipment (sent → displayed), then adjusts in steps towards the target. As long as no measurements exist, the target is sent as is. The calculation of each shipment is detailed in the log (lines 🧮)."),
                color="#888888", size=8, wraplength=760, justify="left").pack(
                    anchor="w", padx=8, pady=(0, 4))
            lbl(s, tr_("i️ OTAs display variable prices depending on the device and visitor profile. A slight difference between the target price and the actual displayed price is normal and inherent to OTA algorithms."),
                color="#666666", size=7).pack(anchor="w", padx=8, pady=(0, 6))

            _tg_outer = tk.Frame(s, bg=T.BG); _tg_outer.pack(fill="x", pady=4)
            _tg_canvas = tk.Canvas(_tg_outer, bg=T.BG, highlightthickness=0, height=1)
            _tg_hsb = tk.Scrollbar(_tg_outer, orient="horizontal", command=_tg_canvas.xview)
            _tg_canvas.configure(xscrollcommand=_tg_hsb.set)
            _tg_hsb.pack(side="bottom", fill="x")
            _tg_canvas.pack(side="top", fill="x", expand=True)
            tg = tk.Frame(_tg_canvas, bg=T.BG)
            _tg_win = _tg_canvas.create_window((0, 0), window=tg, anchor="nw")

            def _tg_on_configure(_e=None):
                _tg_canvas.configure(scrollregion=_tg_canvas.bbox("all"))
                _tg_canvas.itemconfig(_tg_win, height=tg.winfo_reqheight())
                _tg_canvas.configure(height=tg.winfo_reqheight())
            tg.bind("<Configure>", _tg_on_configure)

            # Column headers — OTA names directly (not "OTA 1..10").
            # Widths ADAPT to the real content: the room column fits the
            # longest category name (fully readable — the space at the
            # right of the grid was unused), OTA headers fit their name up
            # to a cap so a long listing name doesn't blow up the grid.
            import tkinter.font as _tgfont
            _tgf = _tgfont.Font(family="Segoe UI", size=9)
            _room_types_pre = [rt if isinstance(rt, str) else rt.get("type", "")
                               for rt in self.app.config.get("room_types", [])]
            _room_types_pre = [r for r in _room_types_pre if r]
            _room_col_w = max(26, max((_tgf.measure(r) for r in _room_types_pre),
                                      default=0) // 7 + 3)

            # D115 (owner order): the Airbnb columns carry a name that
            # DIFFERENTIATES the rooms — the single "Airbnb" entry is
            # split into one column per listing: "Airbnb Double Room",
            # "Airbnb Deluxe Double Room"… A column's cell is editable
            # only on ITS room's row (one listing = one room); the save
            # stores each value under the canonical "Airbnb" key — the
            # correction loop is unchanged.
            _target_cols = []   # [{label, key, only_room|None}]
            for a in active_otas:
                _n = a.get("name") or ""
                if _n != "Airbnb":
                    _target_cols.append({"label": _n, "key": _n,
                                         "only_room": None})
                    continue
                try:
                    from core import room_names as _rn115
                    _fiche115 = _rn115.id_aliases("airbnb")
                except Exception:
                    _fiche115 = {}
                _by_room = {}
                for _lid, _room in _fiche115.items():
                    if _room:
                        _by_room.setdefault(_room, _lid)
                _seen_lids = set()
                for _rt in _room_types_pre:
                    if _rt in _by_room:
                        _target_cols.append({"label": f"Airbnb {_rt}",
                                             "key": "Airbnb",
                                             "only_room": _rt})
                        _seen_lids.add(_by_room[_rt])
                # listings without a mapped room: column visible but
                # not editable — the mapping is done in "🔗 OTA room
                # matching"
                for _lid in sorted(_fiche115):
                    if _lid not in _seen_lids:
                        _target_cols.append({
                            "label": f"Airbnb Listing …{_lid[-4:]}",
                            "key": "Airbnb", "only_room": "__unmapped__",
                            "lid": _lid})

            headers = ["Room"] + [f"{c['label']} {self._csym}"
                                  for c in _target_cols]
            for col, txt in enumerate(headers):
                # Use per-OTA colour for OTA columns, default accent for "Room"
                if col == 0:
                    fg = T.ACCENT
                    w = _room_col_w
                else:
                    fg = _get_ota_color(_target_cols[col - 1]["key"])
                    w = max(16, min(26, _tgf.measure(txt) // 7 + 2))
                tk.Label(tg, text=txt, bg=T.BG, fg=fg,
                         font=("Segoe UI", 9, "bold"),
                         width=w, anchor="w").grid(
                             row=0, column=col, padx=4, pady=2)

            self._ota_watch_target_vars = {}
            room_types = _room_types_pre

            for ri, room in enumerate(room_types):
                rt_data = target_prices.get(room, {})
                bg_r = T.ENTRY_BG if ri % 2 == 0 else T.BG
                tk.Label(tg, text=room, bg=bg_r, fg=T.FG,
                         font=("Segoe UI", 9),
                         width=_room_col_w, anchor="w").grid(row=ri+1, column=0, padx=4, pady=2)
                self._ota_watch_target_vars[room] = {}
                for oi, c in enumerate(_target_cols):
                    ota_name = c["key"]
                    _only = c.get("only_room")
                    # Load target: try exact key first, then group aliases
                    # (e.g. "MakeMyTrip / Goibibo" falls back to "MakeMyTrip"
                    # or "Goibibo" from a previous config that didn't merge).
                    val = rt_data.get(ota_name, "")
                    if not val:
                        for _alias in ("MakeMyTrip", "Goibibo"):
                            if _alias != ota_name:
                                val = rt_data.get(_alias, "")
                                if val:
                                    break
                    if _only in (None, room):
                        v = tk.StringVar(value=str(int(val)) if val else "")
                        tk.Entry(tg, textvariable=v, width=10, bg=T.ENTRY_BG, fg=T.FG,
                                 relief="flat", highlightthickness=1, highlightbackground=T.SEL_BG,
                                 font=("Segoe UI", 10)).grid(row=ri+1, column=oi+1, padx=4, pady=2)
                        self._ota_watch_target_vars[room][ota_name] = v
                    else:
                        # off-diagonal: grayed NON-editable cell —
                        # this column belongs to another room
                        _e = tk.Entry(tg, width=10, bg=T.BG, fg="#555555",
                                      relief="flat", highlightthickness=1,
                                      highlightbackground=T.SEL_BG,
                                      disabledbackground=T.BG,
                                      font=("Segoe UI", 10))
                        _e.insert(0, "—")
                        _e.configure(state="disabled")
                        _e.grid(row=ri+1, column=oi+1, padx=4, pady=2)
            _tg_on_configure()

            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=8)

            # ── Surveillance auto ──
            surv = tk.Frame(s, bg=T.BG); surv.pack(fill="x", pady=4)
            self._ota_watch_auto_v = tk.BooleanVar(value=cfg.get("auto_correct", False))
            tk.Checkbutton(surv, text=tr_("Automatic correction"),
                           variable=self._ota_watch_auto_v,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(surv, tr_("Interval :"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_interval_v = tk.StringVar(value=str(cfg.get("interval_h", 4)))
            tk.Spinbox(surv, textvariable=self._ota_watch_interval_v,
                       from_=0, to=24, increment=1, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 3))
            lbl(surv, "h", bold=False).pack(side="left", padx=(0, 6))
            self._ota_watch_interval_m_v = tk.StringVar(value=str(cfg.get("interval_m", 0)))
            tk.Spinbox(surv, textvariable=self._ota_watch_interval_m_v,
                       from_=0, to=59, increment=5, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 3))
            lbl(surv, tr_("min"), bold=False).pack(side="left", padx=(0, 16))
            lbl(surv, tr_("Correct if deviation ≥ {c}:").format(c=self._csym),
                bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_min_gap_v = tk.StringVar(value=str(cfg.get("min_gap", 50)))
            tk.Spinbox(surv, textvariable=self._ota_watch_min_gap_v,
                       from_=0, to=2000, increment=50, width=6,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left")

            # ── Scan date (check-in offset) ──
            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=(6, 4))
            date_row = tk.Frame(s, bg=T.BG); date_row.pack(fill="x", pady=2)
            lbl(date_row, tr_("📅 Check prices for a stay starting in:"), bold=True).pack(side="left", padx=(0, 8))
            self._ota_watch_date_offset_v = tk.IntVar(value=int(cfg.get("date_offset", 1)))
            for _days, _label in [(0, "D+0"), (1, "D+1 ✦"), (3, "D+3"), (7, "D+7"), (10, "D+10"), (15, "D+15")]:
                tk.Radiobutton(date_row, text=_label,
                               variable=self._ota_watch_date_offset_v, value=_days,
                               bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.BG, font=("Segoe UI", 9),
                               cursor="hand2").pack(side="left", padx=(0, 6))
            lbl(date_row,
                tr_("If a room cannot be found at this date, the scan automatically keeps trying other dates until every room has a price"),
                color="#888888", size=8).pack(side="left", padx=(10, 0))

            # ── Correction send date to the CM (free offset, no imposed values) ──
            correct_date_row = tk.Frame(s, bg=T.BG); correct_date_row.pack(fill="x", pady=2)
            lbl(correct_date_row, tr_("📅 Apply the new prices from: D+"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_watch_correct_offset_v = tk.StringVar(
                value=str(int(cfg.get("correct_date_offset", 0))))
            tk.Spinbox(correct_date_row, textvariable=self._ota_watch_correct_offset_v,
                       from_=0, to=365, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 6))
            lbl(correct_date_row, tr_("for:"), bold=True).pack(side="left", padx=(4, 4))
            self._ota_watch_correct_days_v = tk.StringVar(
                value=str(int(cfg.get("correct_duration_days", 90))))
            tk.Spinbox(correct_date_row, textvariable=self._ota_watch_correct_days_v,
                       from_=1, to=365, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
            lbl(correct_date_row, tr_("day(s)"), bold=True).pack(side="left", padx=(0, 6))
            lbl(correct_date_row, tr_("(e.g.: from D+0 = today, for 90 days)"),
                color="#888888", size=8).pack(side="left")

            # ── Weekend markup (Friday/Saturday) ──
            wknd_row = tk.Frame(s, bg=T.BG); wknd_row.pack(fill="x", pady=2)
            self._ota_watch_wknd_v = tk.BooleanVar(
                value=cfg.get("weekend_markup_enabled", True))
            tk.Checkbutton(wknd_row, text=tr_("🗓️ Increase:"),
                           variable=self._ota_watch_wknd_v,
                           bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
            _DAY_FR_G = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            _saved_days_g = cfg.get("weekend_days", [4, 5])
            self._ota_watch_wknd_days_v = []
            for _di, _dl in enumerate(_DAY_FR_G):
                _ddv = tk.BooleanVar(value=_di in _saved_days_g)
                tk.Checkbutton(wknd_row, text=_dl, variable=_ddv,
                               bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.BG,
                               font=("Segoe UI", 9)).pack(side="left", padx=(1, 0))
                self._ota_watch_wknd_days_v.append(_ddv)
            lbl(wknd_row, "  +", bold=True).pack(side="left", padx=(6, 2))
            self._ota_watch_wknd_pct_v = tk.StringVar(
                value=str(cfg.get("weekend_markup_pct", 20)))
            tk.Spinbox(wknd_row, textvariable=self._ota_watch_wknd_pct_v,
                       from_=0, to=100, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 2))
            lbl(wknd_row, "%").pack(side="left")

            # ── Iterative calibration ──
            tk.Frame(s, bg=T.SEL_BG, height=1).pack(fill="x", pady=(8, 4))
            calib_row = tk.Frame(s, bg=T.BG); calib_row.pack(fill="x", pady=2)
            self._ota_calib_auto_v = tk.BooleanVar(value=cfg.get("calib_auto", False))
            tk.Checkbutton(calib_row, text=tr_("🔄 Auto calibration if floor violated"),
                           variable=self._ota_calib_auto_v,
                           bg=T.BG, fg=T.ACCENT, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                           font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(calib_row, tr_("Delay between checks (min, ≥5):"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_calib_wait_v = tk.StringVar(value=str(cfg.get("calib_wait_min", 5)))
            tk.Spinbox(calib_row, textvariable=self._ota_calib_wait_v,
                       from_=5, to=120, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
            lbl(calib_row, tr_("Max attempts:"), bold=True).pack(side="left", padx=(0, 4))
            self._ota_calib_max_v = tk.StringVar(value=str(cfg.get("calib_max_retries", 5)))
            tk.Spinbox(calib_row, textvariable=self._ota_calib_max_v,
                       from_=1, to=10, increment=1, width=4,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)).pack(side="left")
            lbl(s, tr_("ℹ After each auto scan, if the OTA is below the strategy floor → the software sends a higher price to the CM, waits the defined delay, re-scans and adjusts until the OTA is ≥ floor (max N attempts, +{c}150 per trial).").format(c=self._csym),
                color="#888888", size=8).pack(anchor="w", padx=8, pady=(0, 6))

            # ── Buttons ──
            br = tk.Frame(s, bg=T.BG); br.pack(fill="x", pady=(10, 4))
            btn(br, tr_("🚀 Push & Fix"),      lambda: self._ota_watch_correct(),
                color="#f38ba8", width=22).pack(side="left", padx=(0, 8))
            self._ota_watch_scan_btn = btn(br, tr_("🔍 Scan now"),
                self._vae_scan,
                color=T.ORANGE, width=20)
            self._ota_watch_scan_btn.pack(side="left")
            # D53: immediate (cooperative) stop of the running scan
            self._ota_watch_stop_btn = btn(br, tr_("⏹ Stop"),
                                           self._ota_watch_stop_operation,
                                           color=T.RED, width=8)
            self._ota_watch_stop_btn.pack(side="left", padx=(6, 0))
            # D111: the button is ALWAYS active — a grayed-out ⏹ during
            # the start of a correction left an owner click with no
            # effect AND no trace (12/10 09:40, 5-segment queue).
            # D98: global pause — the owner is working, the tool must no
            # longer steal the Brave window or start anything.
            self._ota_watch_pause_btn = btn(br, tr_("⏸ Pause everything"),
                                            self._ota_watch_toggle_pause,
                                            color=T.ACCENT, width=22)
            self._ota_watch_pause_btn.pack(side="left", padx=(6, 0))
            tooltip(self._ota_watch_pause_btn,
                    tr_("Suspends EVERYTHING (scans, sends, reloads, window pop-ups) until resumed — the current task ends properly."))

            # ── The TWO date-walk scan types (owner order): normal
            # (walk dates until a price shows up per category, +14 cap)
            # and deep (read EVERY date of a configurable duration and
            # accumulate the full price history). Engine: scan_dates.
            dr = tk.Frame(s, bg=T.BG)
            dr.pack(fill="x", pady=(0, 4))
            # D143: the THREE operation buttons of this tab carry refs and
            # DISTINCT labels — their state (running / blocked-by-which) is
            # kept visible at all times (_refresh_operation_buttons).
            self._dates_normal_btn = btn(dr, tr_("🔎 Dates — quick scan"),
                lambda: self._scan_dates_run("normal"),
                color="#a6e3a1", width=22)
            self._dates_normal_btn.pack(side="left", padx=(0, 8))
            self._dates_deep_btn = btn(dr, tr_("🛡️ Dates — deep scan"),
                lambda: self._scan_dates_run("deep"),
                color="#89b4fa", width=22)
            self._dates_deep_btn.pack(side="left", padx=(0, 8))
            lbl(dr, tr_("Deep duration (days):"), bold=True) \
                .pack(side="left", padx=(0, 4))
            self._deep_days_var = tk.StringVar(value="30")
            tk.Spinbox(dr, textvariable=self._deep_days_var,
                       from_=1, to=180, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)) \
                .pack(side="left")
            # D153: the NORMAL walk cap is the owner's setting too —
            # walk until a price shows up, as far as he decides.
            lbl(dr, tr_("Normal search (days):"), bold=True) \
                .pack(side="left", padx=(14, 4))
            self._normal_days_var = tk.StringVar(value="14")
            tk.Spinbox(dr, textvariable=self._normal_days_var,
                       from_=1, to=365, increment=1, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 10)) \
                .pack(side="left")
            tooltip(dr,
                    tr_("Normal: per room category, walk dates until a price shows up (max +14 days). Deep: read EVERY date of the chosen duration and accumulate the full price history — detects future price changes."))

            self._ota_watch_status = tk.Label(s, text="", bg=T.BG, fg=T.YELLOW,
                                              font=("Segoe UI", 9, "italic"))
            self._ota_watch_status.pack(anchor="w", pady=(2, 2))
            self._ota_watch_prog = ttk.Progressbar(s, mode="determinate",
                                                    length=280, maximum=100)
            self._ota_watch_prog.pack(anchor="w", pady=(0, 6))
            # D52: progress of SENDS to the CM (same location)
            self._push_prog = ttk.Progressbar(s, mode="determinate",
                                              length=280, maximum=100)
            self._push_prog.pack(anchor="w", pady=(0, 2))
            self._push_prog_lbl = tk.Label(s, text="", bg=T.BG, fg=T.ACCENT,
                                           font=("Segoe UI", 8, "italic"))
            self._push_prog_lbl.pack(anchor="w", pady=(0, 6))
            # accessibles depuis app_core (pattern _cm_history_text)
            self.app._push_prog = self._push_prog
            self.app._push_prog_lbl = self._push_prog_lbl
            self.app._ota_watch_stop_btn = self._ota_watch_stop_btn
            self.app._ota_watch_pause_btn = self._ota_watch_pause_btn

            # ── Results table ──
            lbl(s, tr_("Results of the last scan:"), bold=True, color=T.ACCENT).pack(anchor="w", pady=(4, 2))
            lbl(s, tr_("Double-click on a line → correct this room only."),
                color="#888888", size=8).pack(anchor="w", padx=8, pady=(0, 4))

            rf = tk.Frame(s, bg=T.BG); rf.pack(fill="x")
            # Inner frame for the tree + vertical scrollbar (sits above the
            # horizontal scrollbar) so both can coexist cleanly.
            tw = tk.Frame(rf, bg=T.BG); tw.pack(side="top", fill="both", expand=True)
            vsb_w = ttk.Scrollbar(tw, orient="vertical"); vsb_w.pack(side="right", fill="y")
            wcols = ("ota", "room", "target", "detected", "gap", "to_send", "status")
            self._ota_watch_tree = ttk.Treeview(tw, columns=wcols, show="headings",
                                                 height=8, selectmode="browse",
                                                 yscrollcommand=vsb_w.set)
            vsb_w.config(command=self._ota_watch_tree.yview)
            # Horizontal scrollbar — keeps every column reachable on narrow
            # windows without ever hiding OTA / Room (they stay first).
            hsb_w = ttk.Scrollbar(rf, orient="horizontal",
                                  command=self._ota_watch_tree.xview)
            hsb_w.pack(side="bottom", fill="x")
            self._ota_watch_tree.config(xscrollcommand=hsb_w.set)
            for cid, txt, w, anc, can_stretch in [
                ("ota",      "OTA",            110, "w",     False),
                ("room",     "Room",            150, "w",     False),
                ("target",   "Target price",    88, "center", True),
                ("detected", "Detected price",  88, "center", True),
                ("gap",      "Gap",             140, "center", True),
                ("to_send",  "To send CM",      90, "center", True),
                ("status",   "Status",          92, "center", True),
            ]:
                self._ota_watch_tree.heading(cid, text=txt)
                self._ota_watch_tree.column(
                    cid, width=w, minwidth=w, anchor=anc, stretch=can_stretch)
            self._ota_watch_tree.pack(side="left", fill="both", expand=True)
            self._ota_watch_tree.tag_configure("ok",   foreground=T.GREEN)
            self._ota_watch_tree.tag_configure("low",  foreground=T.RED)
            self._ota_watch_tree.tag_configure("high", foreground=T.ORANGE)
            self._ota_watch_tree.tag_configure("none", foreground="#888888")
            self._ota_watch_sort_reset = attach_sort(self._ota_watch_tree)

            def _on_row_dbl(event):
                try:
                    item = self._ota_watch_tree.focus()
                    vals = self._ota_watch_tree.item(item, "values")
                    if vals and len(vals) >= 2:
                        self._ota_watch_correct(room=vals[1], ota_name=vals[0])
                except Exception:
                    pass
            self._ota_watch_tree.bind("<Double-Button-1>", _on_row_dbl)

            # Summary bar displayed below the table (updated after each scan)
            self._ota_watch_summary = tk.Label(
                s, text="", bg=T.BG, fg=T.FG, anchor="w",
                font=("Segoe UI", 8, "bold"))
            self._ota_watch_summary.pack(anchor="w", pady=(4, 0))

            # Load last results — filter out OTAs that are no longer
            # watched (e.g. closed Brave tab / removed OTA).
            try:
                last = dict(cfg.get("last_results", {}))
                if last:
                    _active_names = {d["name"] for d in merged
                                     if d.get("active", True)}
                    _stale = [k for k in last if k not in _active_names]
                    if _stale:
                        for k in _stale:
                            del last[k]
                        # Persist the cleaned version so stale OTAs don't
                        # come back on the next rebuild.
                        cfg["last_results"] = last
                        self.app.config["ota_watch"] = cfg
                    if last:
                        self._ota_watch_fill_tree(last)
                    elif hasattr(self, "_ota_watch_tree"):
                        self._ota_watch_tree.delete(
                            *self._ota_watch_tree.get_children())
                    ts = cfg.get("last_scan_time", "")
                    if ts and hasattr(self, "_ota_watch_status"):
                        self._ota_watch_status.config(
                            text=tr_("Last scan: {ts}").format(ts=fmt_dt(ts)), fg="#888888")
            except Exception:
                pass

        except Exception:
            pass

    def _ota_selection_rows(self):
        return [dict(row, active=bool(row["active"].get()))
                for row in getattr(self, "_ota_watch_ota_vars", [])]

    def _ota_page_toggled(self, key, variable):
        # Duplicate tabs of the same page share one identity; other pages do not.
        value = bool(variable.get())
        for row in self._ota_watch_ota_vars:
            if page_key(row.get("url")) == key:
                row["active"].set(value)
        old = self.app.config.get("ota_watch", {})
        updated = save_page_choices(old, self._ota_selection_rows())
        if selected_page_keys(old) != selected_page_keys(updated):
            # Never correct from a previous selection's cached prices.
            updated["last_results"] = {}
            updated.pop("last_scan_time", None)
        candidate = dict(self.app.config, ota_watch=updated)
        try:
            if not cfg.save(candidate):
                raise OSError("Configuration could not be saved")
        except Exception as exc:
            from core.ota_selection import page_active
            for row in self._ota_watch_ota_vars:
                row["active"].set(page_active(old, row.get("url")))
            logging.exception("Saving OTA page selection failed")
            from diagnostic import usage as _usage
            _usage.trace("ota_pages", phase="selected", status="failed")
            messagebox.showerror(tr_("OTA selection"), str(exc), parent=self.app.root)
            return
        self.app.config["ota_watch"] = updated
        from diagnostic import usage as _usage
        _usage.pages_checkpoint("selected", updated, self._ota_selection_rows())
        set_tab_choices(updated.get("tab_choices") or {})
        tree = getattr(self, "_ota_watch_tree", None)
        if not updated.get("last_results") and tree is not None:
            tree.delete(*tree.get_children())
        if hasattr(self, "_ota_watch_status"):
            self._ota_watch_status.config(
                text=tr_("Selection saved. Scan to refresh prices."), fg=T.GREEN)

    def _ota_watch_save(self):
        """Save OTA watch config to config.

        The new data structure uses plain strings for name/url (auto-detected
        or manually added) and BooleanVar only for the active toggle.  Target
        prices are keyed by OTA name (not slot index).
        """
        try:
            ota_cfg = dict(self.app.config.get("ota_watch", {}))

            ota_cfg = save_page_choices(ota_cfg, self._ota_selection_rows())
            ota_cfg.pop("manual_otas", None)

            # Target prices keyed by OTA name (no duplicate-slot logic needed)
            target_prices = {r: dict(v) for r, v in
                             (ota_cfg.get("target_prices") or {}).items()}
            for room, ota_dict in self._ota_watch_target_vars.items():
                room_t = dict(target_prices.get(room) or {})
                for ota_name, v in ota_dict.items():
                    raw = v.get().strip()
                    room_t.pop(ota_name, None)
                    if raw:
                        try:
                            room_t[ota_name] = float(raw.replace(",", "."))
                        except ValueError:
                            pass
                # Migrate old standalone Goibibo/MakeMyTrip keys into the
                # grouped key so stale per-OTA values don't linger.
                if room_t:
                    _old = {k: v for k, v in room_t.items()
                            if k in ("Goibibo", "MakeMyTrip")}
                    if _old and _MMT_DISPLAY not in room_t:
                        room_t[_MMT_DISPLAY] = list(_old.values())[0]
                    for _k in list(room_t):
                        if _k in ("Goibibo", "MakeMyTrip"):
                            del room_t[_k]
                target_prices[room] = room_t
            ota_cfg["target_prices"] = target_prices

            ota_cfg["auto_correct"] = self._ota_watch_auto_v.get()
            try:
                ota_cfg["interval_h"] = int(self._ota_watch_interval_v.get())
            except (ValueError, AttributeError):
                ota_cfg["interval_h"] = 4
            try:
                ota_cfg["interval_m"] = int(self._ota_watch_interval_m_v.get())
            except (ValueError, AttributeError):
                ota_cfg["interval_m"] = 0
            try:
                ota_cfg["min_gap"] = int(self._ota_watch_min_gap_v.get())
            except (ValueError, AttributeError):
                ota_cfg["min_gap"] = 50
            try:
                ota_cfg["calib_auto"] = self._ota_calib_auto_v.get()
            except AttributeError:
                pass
            try:
                ota_cfg["fast_scan"] = self._ota_watch_fast_v.get()
            except AttributeError:
                pass
            try:
                ota_cfg["calib_wait_min"] = max(5, int(self._ota_calib_wait_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["calib_wait_min"] = 5
            try:
                ota_cfg["calib_max_retries"] = max(1, int(self._ota_calib_max_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["calib_max_retries"] = 5
            try:
                ota_cfg["date_offset"] = int(self._ota_watch_date_offset_v.get())
            except (ValueError, AttributeError):
                ota_cfg["date_offset"] = 1
            try:
                ota_cfg["correct_date_offset"] = max(0, int(self._ota_watch_correct_offset_v.get()))
            except (ValueError, AttributeError):
                ota_cfg["correct_date_offset"] = 0
            try:
                ota_cfg["correct_duration_days"] = max(1, min(365, int(
                    self._ota_watch_correct_days_v.get())))
            except (ValueError, AttributeError):
                ota_cfg["correct_duration_days"] = 90
            try:
                ota_cfg["weekend_markup_enabled"] = bool(self._ota_watch_wknd_v.get())
            except AttributeError:
                pass
            try:
                ota_cfg["weekend_markup_pct"] = max(0.0, float(
                    self._ota_watch_wknd_pct_v.get().replace(",", ".")))
            except (ValueError, AttributeError):
                ota_cfg["weekend_markup_pct"] = 20
            try:
                ota_cfg["weekend_days"] = [
                    i for i, v in enumerate(self._ota_watch_wknd_days_v) if v.get()]
            except AttributeError:
                pass

            self.app.config["ota_watch"] = ota_cfg
            if not cfg.save(self.app.config):
                raise OSError("Configuration could not be saved")
            from diagnostic import usage as _usage
            _usage.pages_checkpoint("saved", ota_cfg, self._ota_selection_rows())
            # D41: re-synchronize the VAE engine IMMEDIATELY (config →
            # hotel.yaml/settings). Until now this sync was only done at
            # startup (main.py): modifying the OTA list (Active
            # checkboxes, additions/removals) changed the config file but
            # not the already-mounted engine — the change only became
            # visible in scan results after a full app restart (owner
            # report 29/08).
            try:
                from vae_bridge import sync_config_from_otaguard
                sync_config_from_otaguard(self.app.config)
            except Exception:
                import logging
                logging.exception("D41: VAE engine re-sync after save failed")
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=tr_("✅ Configuration saved."), fg=T.GREEN)
        except Exception as e:
            from diagnostic import usage as _usage
            _usage.trace("ota_pages", phase="saved", status="failed")
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=tr_("❌ Save error: {e}").format(e=e), fg=T.RED)

    # ─── CM SENDS HISTORY ────────────────────────────────────────────────────

    def _build_cm_history_section(self, parent):
        from core.widgets import section
        s = section(parent, tr_("📋 Latest submissions to Channel Manager"))
        s.pack(fill="x", padx=10, pady=(10, 4))
        lbl(s, tr_("Trace of each push to the CM — manual or automatic."),
            color="#888888", size=9).pack(anchor="w", pady=(0, 4))

        # Scrollable history: newest entries first (insert(0, ...) in
        # app_core) — the scrollbar reveals the older ones below.
        hist_frame = tk.Frame(s, bg=T.BG)
        hist_frame.pack(fill="x", pady=(0, 4))
        self._cm_history_sb = ttk.Scrollbar(hist_frame, orient="vertical")
        self._cm_history_sb.pack(side="right", fill="y")
        self._cm_history_text = tk.Text(
            hist_frame, bg=T.ENTRY_BG, fg=T.FG, font=("Consolas", 9),
            height=8, relief="flat", state="disabled",
            highlightthickness=0,
            yscrollcommand=self._cm_history_sb.set)
        self._cm_history_text.pack(side="left", fill="both", expand=True)
        self._cm_history_sb.config(command=self._cm_history_text.yview)
        self._cm_history_text.tag_config("ok",    foreground=T.GREEN)
        self._cm_history_text.tag_config("err",   foreground=T.RED)
        self._cm_history_text.tag_config("part",  foreground="#e67e22")  # D42: partial send
        self._cm_history_text.tag_config("muted", foreground="#888888")

        self.app._cm_history_text = self._cm_history_text
        self.app._cm_refresh_history_fn = self._cm_refresh_history

        btn_row = tk.Frame(s, bg=T.BG)
        btn_row.pack(anchor="e", pady=(0, 2))
        btn(btn_row, tr_("🔄 Refresh"), self._cm_refresh_history,
            color=T.SEL_BG, width=12).pack(side="left", padx=(0, 6))
        btn(btn_row, tr_("🗑 Clear"),
            lambda: (
                self.app.config.get("channel_manager", {}).update({"push_history": []}),
                cfg.save(self.app.config),
                self._cm_refresh_history()
            ), color=T.SEL_BG, width=10).pack(side="left")

        self._cm_refresh_history()

    def _cm_refresh_history(self):
        try:
            if not hasattr(self, "_cm_history_text"):
                return
            hist = self.app.config.get("channel_manager", {}).get("push_history", [])
            self._cm_history_text.config(state="normal")
            self._cm_history_text.delete("1.0", "end")
            if not hist:
                self._cm_history_text.insert("end", "No send recorded.\n", "muted")
            else:
                for e in hist[:30]:
                    ts_s   = fmt_dt(e.get("ts", ""))   # "16/08/2026 12:05"
                    # D42: THREE states — all ok = green; at least one
                    # send actually went out despite failures = ORANGE;
                    # nothing sent = red. Older entries (without the
                    # "sent" field) are inferred from their message: a
                    # "✓"/"✅" D40-D42 detail or a leading ✅ group
                    # means at least one send went out.
                    _sent = e.get("sent")
                    if _sent is None:
                        _m = str(e.get("msg", ""))
                        _sent = 1 if ("✓" in _m or "✅" in _m) else 0
                    if e.get("ok"):
                        icon, tag = "✅", "ok"
                    elif int(_sent or 0) > 0:
                        icon, tag = "🟠", "part"
                    else:
                        icon, tag = "✗ ", "err"
                    source = e.get("source", "?")
                    ota    = e.get("ota", "")
                    label  = f"{source} → {ota}" if ota else source
                    msg_s  = e.get("msg", "")  # D42: full detail, no more truncation
                    # Room and price side by side when the pairs exist
                    # (entries recorded since 2026-08-16); older entries
                    # keep the legacy "rooms → prices" rendering.
                    pairs  = e.get("pairs") or []
                    if pairs:
                        detail = "  ·  ".join(pairs)
                    else:
                        rooms  = e.get("rooms", "?")
                        prices = e.get("prices", "?")
                        detail = f"{rooms} → {prices}"
                    line   = f"{icon} {ts_s}  [{label}]  {detail}"
                    if msg_s:
                        line += f"  — {msg_s}"
                    self._cm_history_text.insert("end", line + "\n", tag)
            self._cm_history_text.config(state="disabled")
        except Exception:
            pass


    def _ota_watch_toggle_pause(self):
        """D98: sets/clears the global pause. While paused: no scan,
        push, keepalive reload or Brave window raise — the owner works
        in peace. The running task ends properly (D12). Session-only:
        never persisted (a forgotten pause would stop the protection in
        silence)."""
        try:
            import extranet_bridge as _xb
            from core.widgets import _btn_fg
            if _xb.is_paused():
                _xb.pause_clear()
                try:
                    self._ota_watch_pause_btn.config(
                        text=tr_("⏸ Pause everything"),
                        bg=T.ACCENT, fg=_btn_fg(T.ACCENT))
                    self._ota_watch_status.config(
                        text=tr_("▶ Resume — the tool resumes its normal rhythm (scans, corrections, keepalive)."),
                        fg=T.GREEN)
                except Exception:
                    pass
                self.app._log_journal(
                    "▶ " + tr_("pause lifted — the tool resumes its normal rhythm"), engine="PAUSE")
            else:
                _xb.pause_set()
                try:
                    self._ota_watch_pause_btn.config(
                        text=tr_("▶ Resume"),
                        bg=T.GREEN, fg=_btn_fg(T.GREEN))
                    self._ota_watch_status.config(
                        text=tr_("⏸ PAUSED — no more scanning, sending, reloading or window popping. Click ▶ Resume to restart."),
                        fg=T.ORANGE)
                except Exception:
                    pass
                self.app._log_journal(
                    "⏸ " + tr_("global pause set — no more activity or stolen window until resumed"),
                    engine="PAUSE")
        except Exception:
            logging.exception("pause toggle failed")

    # ── Date-walk scans (normal + deep) — owner's two scan types ────

    def _operation_buttons(self):
        """The THREE operation buttons of this tab — (kind, widget, idle
        label). Two of them share the 'date scan' slot kind on purpose:
        they block each other and are blocked by the OTA scan alike."""
        return [
            ("scan", getattr(self, "_ota_watch_scan_btn", None),
             tr_("🔍 Scan now")),
            ("date scan", getattr(self, "_dates_normal_btn", None),
             tr_("🔎 Dates — quick scan")),
            ("date scan", getattr(self, "_dates_deep_btn", None),
             tr_("🛡️ Dates — deep scan")),
        ]

    def _refresh_operation_buttons(self):
        """D143 — the state of the slot is ALWAYS visible on the buttons:
        own operation running → ⏳ (orange, disabled); another operation
        holds the slot → ⛔ {operation} (grey, disabled); idle → own
        label and own color restored. Works from any UI-thread context."""
        try:
            import extranet_bridge as _xb
            current = _xb.operation_current() or ""
        except Exception:
            current = ""
        if not hasattr(self, "_op_btn_idle_bg"):
            self._op_btn_idle_bg = {}
        for kind, w, idle in self._operation_buttons():
            if not w:
                continue
            try:
                if not w.winfo_exists():
                    continue
            except Exception:
                continue
            key = str(w)
            if key not in self._op_btn_idle_bg:
                try:
                    self._op_btn_idle_bg[key] = w.cget("bg")
                except Exception:
                    self._op_btn_idle_bg[key] = T.ACCENT
            if current == kind:
                state, text, bg = "disabled", "⏳ " + idle, "#fab387"
            elif current:
                state, text, bg = "disabled", "⛔ " + current, "#6c7086"
            else:
                state, text, bg = "normal", idle, self._op_btn_idle_bg[key]
            try:
                w.config(state=state, text=text, bg=bg, fg=_btn_fg(bg))
            except Exception:
                pass

    def _scan_dates_run(self, mode: str):
        """Runs scan_dates.run_scan in a thread: 'normal' walks dates
        until every category shows a price (+14 cap); 'deep' reads
        EVERY date of the configurable duration and accumulates the
        full price history. Live log in the journal; results saved to
        data/scan_dates/."""
        try:
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._log_journal(
                    "⏸ " + tr_("scan impossible — the tool is PAUSED "
                                "(▶ Resume button to restart)"),
                    level="warn", engine="DATES")
                return
        except Exception:
            pass
        if getattr(self, "_scan_dates_running", False):
            return
        try:
            from licensing.license_checker import _ck
            if not _ck():
                return
        except Exception:
            pass
        import extranet_bridge as _xb_ops
        if not _xb_ops.operation_begin("date scan"):
            messagebox.showwarning(
                tr_("OTA Guard scan"),
                tr_("Impossible: a {k} is in progress (since {s}).\nOne operation at a time — wait for it to complete.")
                    .format(k=_xb_ops.operation_current(),
                            s=_xb_ops.operation_since()),
                parent=self.app.root)
            self._refresh_operation_buttons()
            return
        self._scan_dates_running = True
        self._refresh_operation_buttons()
        days = 30
        try:
            days = max(1, int(self._deep_days_var.get()))
        except Exception:
            pass
        max_walk = 14
        try:
            max_walk = max(1, int(self._normal_days_var.get()))
        except Exception:
            pass
        watch = self.app.config.get("ota_watch") or {}
        profiles = [o for o in (watch.get("otas") or [])
                    if o.get("active") and o.get("url")]
        rooms = [r for r in (self.app.config.get("room_types") or []) if r]
        tracked = [r for r, t in (watch.get("target_prices") or {}).items()
                   if isinstance(t, dict) and t]
        if tracked:
            rooms = [r for r in rooms if r in tracked] or tracked
        self._log_journal(
            f"🔎 " + tr_("Deep scan (dates)") if mode == "deep"
            else "🔎 " + tr_("Normal scan (dates)"),
            engine="DATES")
        self._log_journal(
            tr_("{n} OTA × {c} categories")
                .format(n=len(profiles), c=len(rooms))
            + (tr_(", duration {d} days").format(d=days)
               if mode == "deep" else ""),
            engine="DATES")

        def work():
            import scan_dates
            stop_seen = []

            def cb(msg):
                stop_seen.append(False)

                def _emit(m=str(msg)):
                    self._log_journal(str(m), engine="DATES")

                self.app.root.after(0, _emit)
            try:
                res = scan_dates.run_scan(
                    mode=mode, days=days, config_profiles=profiles,
                    room_types=rooms, log=cb,
                    progress_cb=lambda pct, msg: self.app.root.after(
                        0, lambda p=pct, m=msg: self._vae_update_progress(p, m)),
                    max_walk=max_walk)
                self.app.root.after(
                    0, lambda: self._scan_dates_done(res, mode))
            except Exception as e:
                err = f"{type(e).__name__}: {e}"

                def _fail():
                    self._log_journal("❌ Scan dates: " + err,
                                      level="error", engine="DATES")
                    self._scan_dates_finish()

                self.app.root.after(0, _fail)
        threading.Thread(target=work, daemon=True).start()

    def _scan_dates_finish(self):
        """Releases the operation slot and the local busy flag."""
        self._scan_dates_running = False
        try:
            import extranet_bridge as _xb_ops
            _xb_ops.operation_end("date scan")
        except Exception:
            pass
        self._refresh_operation_buttons()

    def _scan_dates_done(self, res: dict, mode: str):
        """Saves the full result to data/scan_dates/ and prints a
        per-OTA summary in the journal."""
        try:
            import json as _json
            out_dir = Path(DATA_DIR) / "scan_dates"
            out_dir.mkdir(parents=True, exist_ok=True)
            f = out_dir / f"scan_{mode}_{datetime.now():%Y%m%d_%H%M%S}.json"
            f.write_text(_json.dumps(res, ensure_ascii=False, indent=1,
                                     default=str), encoding="utf-8")
            self._log_journal(
                "✅ " + tr_("Scan finished — full results: {p}")
                    .format(p=f), engine="DATES")
        except Exception as e:
            self._log_journal(
                "⚠️ " + tr_("results not saved: {e}").format(e=e),
                level="warn", engine="DATES")
        for ota, r in (res or {}).items():
            if not isinstance(r, dict):
                continue
            if r.get("error"):
                self._log_journal(f"  ❌ {ota}: {r['error']}",
                                  level="error", engine="DATES")
                continue
            if r.get("stopped"):
                self._log_journal(f"  ⏹ {ota}: "
                                  + tr_("stopped by the user"),
                                  engine="DATES")
            if mode == "normal":
                prices = r.get("prices") or {}
                dates = r.get("dates") or {}
                parts = [f"{k}={v}" + (f" @{d}" if dates.get(k) else "")
                         for k, v in prices.items() if v is not None]
                if parts:
                    self._log_journal(f"  ✅ {ota}: " + ", ".join(parts),
                                      engine="DATES")
                else:
                    self._log_journal(
                        f"  ⚠️ {ota}: " + tr_("no price read"),
                        level="warn", engine="DATES")
            else:
                hist = r.get("history") or {}
                changes = r.get("changes") or {}
                self._log_journal(
                    f"  ✅ {ota}: "
                    + tr_("{c} categories accumulated, {a} with price changes")
                        .format(c=len(hist), a=len(changes)),
                    engine="DATES")
                for room, segs in (changes or {}).items():
                    txt = " → ".join(f"{d}: {p}" for d, p in segs)
                    self._log_journal(f"     ↺ {room}: {txt}",
                                      engine="DATES")
        self._scan_dates_finish()

    def _ota_watch_stop_operation(self):
        """D56: stops the running operation — scan OR extranet correction.
        Replaced by the ⏹ Stop button (both mechanisms coexist)."""
        try:
            import extranet_bridge as _xb
            cur = _xb.operation_current()
        except Exception:
            cur = ""
        from diagnostic import usage as _usage
        _usage.trace("stop_requested", operation=cur or "none")
        # D76: ⏹ ALSO stops the seasonal correction loop
        # (set regardless of the slot — the loop calls reset_stop()
        # at startup, so a residual STOP is harmless).
        try:
            from business import seasonal_loop as _sloop
            _sloop.STOP.set()
            # D78: VISIBLE trace in the journal, whatever the
            # tab the user is on (lesson of 21/09: clicks with no
            # visible feedback whatsoever).
            self.app._log_journal(
                "⏹ " + tr_("stop requested — the current sending ends, the rest is canceled"), engine="SEASONAL")
        except Exception:
            pass
        # Date-walk scans (normal/deep) also honour the ⏹ — checked
        # between every date step inside scan_dates.
        try:
            import scan_dates as _sd
            _sd.request_stop()
        except Exception:
            pass
        if cur == "scan":
            self._ota_watch_stop_scan()
            return
        if cur == "push":
            try:
                import extranet_bridge as _xb
                # D107: STOP = STOP — sets the queue AND the executor: the
                # running segment stops at its step (typing, submit,
                # verification), not "at the next task".
                _xb.request_stop()
            except Exception:
                return
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("⏹ Correction stop requested — the current "
                             "step stops, the rest is cancelled."),
                    fg=T.YELLOW)
            try:
                if hasattr(self, "_push_prog_lbl") and                         self._push_prog_lbl.winfo_exists():
                    self._push_prog_lbl.config(
                        text=tr_("⏹ Stop requested — the current step "
                                 "stops, the rest is cancelled…"))
            except Exception:
                pass
            return
        # D111: button always active — say when there is nothing to stop
        if hasattr(self, "_ota_watch_status"):
            self._ota_watch_status.config(
                text=tr_("⬜ Nothing to stop: no operation running."),
                fg=T.YELLOW)

    def _ota_watch_stop_scan(self):
        """Requests the stop of the running scan.

        Cooperative, not preemptive: the OTA currently being scanned
        (already launched Playwright network calls) runs to completion, but
        no following OTA will start — checked before each major step (OTA
        loop, reference mirror, VAE extraction). Results already obtained
        are still displayed/persisted (same behavior as a normal scan where
        an OTA returned nothing)."""
        if not getattr(self, "_ota_watch_scanning", False):
            return
        self._ota_watch_cancel_requested = True
        if hasattr(self, "_ota_watch_status"):
            self._ota_watch_status.config(
                text=tr_("⏹ Stop requested — end of current OTA then stop…"),
                fg=T.YELLOW)

    def _vae_scan(self, _skip_save=False):
        """
        Scan via VAE passive interception.
        Results format: {ota_name: {room_type: price_int}}.
        """
        # D98: under global pause, no scan — clear message (not a
        # generic D52 refusal).
        try:
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._log_journal(
                    "⏸ " + tr_("scan impossible — the tool is PAUSED (▶ Resume button to restart)"),
                    level="warn", engine="PAUSE")
                return
        except Exception:
            pass
        if getattr(self, "_ota_watch_scanning", False):
            return
        try:
            from licensing.license_checker import _ck
            if not _ck():
                return
        except Exception:
            pass

        import extranet_bridge as _xb_ops
        if not _xb_ops.operation_begin("scan"):
            try:
                from core.utils import tr_ as _tr2
                messagebox.showwarning(
                    tr_("OTA Guard scan"),
                    tr_("Impossible: a {k} is in progress (since {s}).\nOne operation at a time — wait for it to complete.")
                        .format(k=_xb_ops.operation_current(),
                                s=_xb_ops.operation_since()),
                    parent=self.app.root)
            except Exception:
                pass
            self._refresh_operation_buttons()
            return
        self._ota_watch_scanning = True
        self._refresh_operation_buttons()
        self._ota_watch_cancel_requested = False
        try:
            import uuid as _uuid_usage
            self._diagnostic_scan_id = _uuid_usage.uuid4().hex[:12]
            from diagnostic import usage as _usage
            _usage.trace("scan", phase="started",
                         run_id=self._diagnostic_scan_id,
                         selected_count=len(selected_page_keys(
                             self.app.config.get("ota_watch") or {})))
        except Exception:
            pass  # Diagnostics cannot keep the scan slot locked.
        try:
            if hasattr(self, "_ota_watch_stop_btn") and                     self._ota_watch_stop_btn.winfo_exists():
                self._ota_watch_stop_btn.config(state="normal")
        except Exception:
            pass

        # Update UI: disable scan button, reset progress bar
        try:
            if hasattr(self, "_ota_watch_scan_btn") and \
               self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="disabled", text=tr_("⏳ OTA Guard Scan..."))
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = 0
        except Exception:
            pass

        if not _skip_save:
            try:
                self._ota_watch_save()
            except Exception:
                pass

        try:
            _scan_config = deepcopy(self.app.config)
            _scan_pages = selected_page_keys(_scan_config.get("ota_watch", {}))
        except Exception:
            self._ota_watch_scanning = False
            _xb_scan_end()
            try:
                from diagnostic import usage as _usage
                _usage.trace("scan", phase="finished", status="failed",
                             run_id=getattr(self, "_diagnostic_scan_id", ""))
            except Exception:
                pass
            logging.exception("Could not prepare the OTA scan")
            if hasattr(self, "_ota_watch_scan_btn") and self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="normal", text=tr_("🔍 Scan"))
            self._refresh_operation_buttons()
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("❌ Scan could not start. See the log."), fg=T.RED)
            return

        import threading as _thr_vae
        def _thread():
            results = {}
            _scan_crash = None      # D109: the REAL error, if crash
            # D144: elapsed-seconds heartbeat for the whole scan
            try:
                self._progress_heartbeat_start()
            except Exception:
                pass
            from diagnostic import scan_trace as _scan_trace
            _trace_token = _scan_trace.begin(
                _scan_config, getattr(self, "_diagnostic_scan_id", ""))
            # D123 : le garde-fou « scans sans répercution » doit juger sur
            # des données FRAÎCHES — recharge les onglets des OTA ayant un
            # envoi en attente (leur page affiche le prix tel qu'au
            # chargement, pas le prix mis à jour côté OTA). Une fois par
            # scan, puis 10 s pour que les captures arrivent.
            try:
                from core import send_history as _sh123
                import vae_bridge as _vb123
                _brands = _sh123.watched_brands(min_checks=1)
                if _brands:
                    _n_re = _vb123.refresh_ota_tabs(_brands)
                    try:
                        self.app.root.after(0, lambda: self._vae_update_progress(
                            2, f"Refreshing OTA pages ({_n_re} tab(s)) before reading..."))
                    except Exception:
                        pass
                    import time as _t123
                    _t123.sleep(10)
            except Exception:
                pass
            try:
                from vae_bridge import vae_scan

                def _progress(pct, msg):
                    # D53: the requested stop interrupts the OTA loop
                    if self._ota_watch_cancel_requested:
                        from vae_bridge import ScanCancelled
                        raise ScanCancelled()
                    # D144: heartbeat stamp — elapsed seconds stay visible
                    import time as _t144
                    _st = getattr(self, "_scan_progress_stamp", None)
                    if _st is not None:
                        _st[0] = _t144.time()
                        _st[1] = str(msg)
                        _st[2] = pct
                    try:
                        self.app.root.after(0, lambda: self._vae_update_progress(pct, msg))
                    except Exception:
                        pass

                results = vae_scan(_scan_config, progress_cb=_progress,
                                   # D107: STOP = STOP — the ⏹ flag is
                                   # checked at EVERY phase of the scan.
                                   cancel_cb=lambda: bool(
                                       getattr(self,
                                               "_ota_watch_cancel_requested",
                                               False)))
            except Exception as e:
                _scan_trace.error("scan_exception", e)
                import logging
                import traceback
                logging.getLogger(__name__).error("VAE scan error: %s", e, exc_info=True)
                # D109: a scan crash must NEVER disguise itself as
                # "no price captured" (11/10 report: the popup lied
                # while the real problem — obsolete patch v9 —
                # existed only in the log file). The REAL error goes
                # to the window journal AND to a popup.
                _tb = traceback.format_exc()
                try:
                    self.app.root.after(0, lambda e=str(e), _tb=_tb: self._log_journal(
                        "❌ " + tr_("Scan error: {e}\n{tb}").format(
                            e=e, tb=_tb[-600:]), level="error",
                        engine="SCAN"))
                except Exception:
                    pass
                _scan_crash = str(e)   # D109
                try:
                    self.app.root.after(0, lambda e=str(e), _tb=_tb: messagebox.showerror(
                        tr_("OTA Guard scan"),
                        tr_("The scan crashed — this is the REAL error "
                            "(copy it as-is):\n\n{e}\n\n{tb}").format(
                                e=e, tb=_tb[-800:]),
                        parent=self.app.root))
                except Exception:
                    pass
            finally:
                _scan_trace.finish(_trace_token, results, _scan_crash)
                # Schedule UI update on main thread
                try:
                    _was_cancelled = self._ota_watch_cancel_requested
                    self.app.root.after(0, lambda: self._vae_scan_done(
                        results, _skip_save, was_cancelled=_was_cancelled,
                        crashed=_scan_crash is not None, selection_keys=_scan_pages))
                except Exception:
                    self._ota_watch_scanning = False
                    _xb_scan_end()
                    try:
                        from diagnostic import usage as _usage
                        _usage.trace("scan", phase="finished", status="failed",
                                     run_id=getattr(self, "_diagnostic_scan_id", ""))
                    except Exception:
                        pass
        try:
            _thr_vae.Thread(target=_thread, daemon=True, name="vae-scan").start()
        except Exception:
            # Thread startup failed: release the slot rather than leaving
            # every subsequent scan and push blocked.
            self._ota_watch_scanning = False
            self._progress_heartbeat_stop()
            _xb_scan_end()
            try:
                from diagnostic import usage as _usage
                _usage.trace("scan", phase="finished", status="failed",
                             run_id=getattr(self, "_diagnostic_scan_id", ""))
            except Exception:
                pass
            if hasattr(self, "_ota_watch_scan_btn") and self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="normal", text=tr_("🔍 Scan"))
            self._refresh_operation_buttons()
            logging.exception("Could not start the OTA scan thread")
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("❌ Scan could not start. See the log."), fg=T.RED)

    def _vae_update_progress(self, pct, msg):
        """Update progress UI during VAE scan."""
        try:
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(text=f"{msg} ({pct}%)")
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = pct
        except Exception:
            pass

    def _progress_heartbeat_start(self):
        """D144 — a scan phase can sit on one pct for a long time; the
        status line keeps counting ELAPSED seconds so the owner always
        sees the scan is alive ("on sait si ça scanne")."""
        import time as _t
        self._scan_progress_stamp = [_t.time(), "", 0]
        self._scan_hb_stop = threading.Event()

        def _tick():
            while not self._scan_hb_stop.wait(5.0):
                st = getattr(self, "_scan_progress_stamp", None)
                if not st:
                    continue
                elapsed = int(_t.time() - st[0])

                def _emit(e=elapsed, m=st[1], p=st[2]):
                    try:
                        if hasattr(self, "_ota_watch_status"):
                            self._ota_watch_status.config(
                                text=f"{m} ({p}%) — {e}s")
                    except Exception:
                        pass
                try:
                    self.app.root.after(0, _emit)
                except Exception:
                    return

        threading.Thread(target=_tick, daemon=True).start()

    def _progress_heartbeat_stop(self):
        ev = getattr(self, "_scan_hb_stop", None)
        if ev is not None:
            try:
                ev.set()
            except Exception:
                pass

    def _vae_scan_done(self, results, _skip_save=False, was_cancelled=False,
                       crashed=False, selection_keys=None):
        """Called on main thread when VAE scan completes."""
        self._ota_watch_scanning = False
        self._progress_heartbeat_stop()
        _xb_scan_end()
        self._ota_watch_cancel_requested = False
        _selection_changed = (selection_keys is not None and selection_keys !=
                              selected_page_keys(self.app.config.get("ota_watch", {})))
        scan_errors = list(getattr(results, "errors", []))
        status = ("crashed" if crashed else "stopped" if was_cancelled
                  else "selection_changed" if _selection_changed
                  else "partial" if scan_errors else "empty" if not results else "completed")
        from core.scan_state import record_outcome
        record_outcome(self.app.config.setdefault("ota_watch", {}), results, status,
                       datetime.now().isoformat(), scan_errors, selection_keys)
        state_saved = None
        if not _skip_save:
            try:
                state_saved = bool(cfg.save(self.app.config))
                if not state_saved:
                    logging.error("Could not persist scan outcome: configuration save returned failure")
            except Exception:
                logging.exception("Could not persist scan outcome")
                state_saved = False
        from diagnostic.scan_trace import append_checkpoint
        append_checkpoint(getattr(self, "_diagnostic_scan_id", ""), "ui_outcome",
                          status=status, state_saved=state_saved,
                          selection_changed=_selection_changed, received=dict(results),
                          persisted=self.app.config.get("ota_watch", {}).get("last_results"), errors=scan_errors)
        try:
            from diagnostic.checkpoints import rooms as _trace_rooms
            _trace_rooms("scan_finished", {ota: list(rooms) for ota, rooms in results.items()},
                         getattr(self, "_diagnostic_scan_id", ""))
        except Exception:
            logging.exception("Could not record scan room checkpoint")
        try:
            from diagnostic import usage as _usage
            _usage.trace("scan", phase="finished",
                         run_id=getattr(self, "_diagnostic_scan_id", ""),
                         status=("crashed" if crashed else "stopped" if was_cancelled
                                 else "selection_changed" if _selection_changed
                                 else "empty" if not results else "completed"),
                         ota_count=len(results or {}),
                         room_count=sum(len(rooms) for rooms in (results or {}).values()
                                        if isinstance(rooms, dict)))
        except Exception:
            pass

        # Re-enable scan button, fill progress bar to 100%
        try:
            if hasattr(self, "_ota_watch_scan_btn") and \
               self._ota_watch_scan_btn.winfo_exists():
                self._ota_watch_scan_btn.config(state="normal", text=tr_("🔍 Scan"))
            if hasattr(self, "_ota_watch_prog") and self._ota_watch_prog.winfo_exists():
                self._ota_watch_prog["value"] = 100
        except Exception:
            pass

        if _selection_changed:
            self._ota_watch_fill_tree({})
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("Selection changed. Scan again to refresh prices."),
                    fg=T.YELLOW)
            return

        if not results:
            self._ota_watch_fill_tree({})
            # D109: after a CRASH, the real error was already displayed
            # (journal + dedicated popup) — the "No price captured" from
            # here would be a lie masking the problem (11/10 report).
            if crashed or was_cancelled:
                try:
                    self._log_journal(
                        "⬜ " + tr_("scan ended without results (crash "
                                    "— see the error above)"),
                        engine="SCAN")
                except Exception:
                    pass
                return
            try:
                from core.utils import tr_ as _tr
                if scan_errors:
                    messagebox.showwarning(tr_("OTA Guard scan"),
                        "\n".join(str(e.get("error", e)) for e in scan_errors), parent=self.app.root)
                else:
                    messagebox.showinfo(tr_("OTA Guard scan"),
                        tr_("No current price returned. See the diagnostic scan trace for the recorded reading stages."), parent=self.app.root)
            except Exception:
                pass
            return

        # The outcome was recorded above, including empty and failed attempts.

        # Re-detect Brave tabs now that a scan just finished — replaces the
        # old fixed 30 s timer that made the whole window blink every 30 s.
        # Only rebuilds the section if the set of OTA tabs actually changed.
        # Placed before fill_tree so that, if a rebuild happens, it reloads
        # last_results (just saved above); fill_tree then refreshes the tree.
        try:
            self._ota_watch_detect_tabs()
        except Exception:
            pass

        # Display results in Treeview
        try:
            self._ota_watch_fill_tree(results)
        except Exception:
            pass

        # Post-processing: parity check, notifications, mobile publish
        try:
            self._ota_watch_on_scan_done(results, stopped=was_cancelled, partial=bool(scan_errors))
            if scan_errors:
                messagebox.showwarning(tr_("OTA Guard scan"),
                    "\n".join(str(e.get("error", e)) for e in scan_errors), parent=self.app.root)
        except Exception:
            pass

        # Save config
        if not _skip_save:
            try:
                self._ota_watch_save()
            except Exception:
                pass

    def _ota_watch_on_scan_done(self, results, stopped=False, partial=False):
        """Callback called after scan — fills the table and auto-corrects if enabled."""
        self._ota_watch_scanning = False
        _xb_scan_end()
        self._ota_watch_cancel_requested = False
        try:
            self._ota_watch_fill_tree(results)
            cfg = self.app.config.get("ota_watch", {})
            ts  = fmt_dt(cfg.get("last_scan_time", ""))
            if hasattr(self, "_ota_watch_status"):
                if partial:
                    self._ota_watch_status.config(text=tr_("Partial scan: reading errors recorded. Automatic corrections skipped."), fg=T.YELLOW)
                elif stopped:
                    self._ota_watch_status.config(
                        text=tr_("⏹ Scan stopped by user at {ts} (partial results).").format(ts=ts),
                        fg=T.YELLOW)
                else:
                    self._ota_watch_status.config(text=tr_("✅ Scan completed at {ts}.").format(ts=ts), fg=T.GREEN)
            if partial:
                return
            # ── History: pair this scan with the last send ──────────────
            # BEFORE the calibration branch, which exits the function:
            # otherwise calibration scans — precisely those measuring the
            # effect of a send — would never be recorded.
            try:
                self._record_observation_history(results)
            except Exception:
                logging.exception("send history: observation not recorded")

            # If this is a calibration scan → check the floors
            if getattr(self, "_ota_calib_rescanning", False):
                self._ota_calib_rescanning = False
                self._ota_calib_check(results)
                return
            # ── Notification: wrong price detected ──────────────────────
            try:
                self._notify_price_gaps(results)
            except Exception:
                pass
            # ── Mobile gateway: publish state to the companion app ──────
            try:
                self._publish_mobile_state(results)
            except Exception:
                pass
            # ── Floor / ceiling protection (G2-1 audit) ─────────────────
            # The "Automatic correction on scan" checkbox (🛡️ Floor &
            # ceiling price protection section) triggered NOTHING: its
            # only read served to tick the box at startup. It is now
            # wired to the engine, in ALERT-ONLY mode by default (journal
            # + email + Telegram + phone, no send to the Channel Manager).
            try:
                if self.app.config.get("price_floors", {}).get("auto_correct")                         and not stopped:
                    self._floor_auto_check_and_correct()
            except Exception:
                logging.exception("Floor/ceiling protection: check failed")
            if cfg.get("auto_correct") and not stopped:
                self._ota_watch_correct(min_gap=cfg.get("min_gap", 50), silent=True)
        except Exception:
            pass

    def _publish_mobile_state(self, results):
        """Publishes the scan state to Firebase for the companion mobile app.

        Fail-safe (convention D8): if the mobile gateway is not
        configured/connected, publish_state() returns False without breaking
        anything. The network send runs in a daemon thread so it never blocks
        the UI (even if Firestore is slow / unreachable)."""
        ota_cfg       = self.app.config.get("ota_watch", {})
        target_prices = ota_cfg.get("target_prices", {})
        min_gap       = ota_cfg.get("min_gap", 50)

        def _worker():
            try:
                from business.mobile_gateway import publish_state, publish_target_prices
                publish_state(results, target_prices, min_gap)
                publish_target_prices(target_prices)
            except Exception:
                pass

        import threading as _thr
        _thr.Thread(target=_worker, daemon=True).start()

    def _publish_mobile_state_correction(self, sent_ctx):
        """Updates the state already published for the phone as soon as a
        correction is sent with SUCCESS to the Channel Manager, without
        waiting for the next scan (which can take several minutes — the
        phone would keep the red alert displayed while the price has just
        been corrected).

        `sent_ctx` = `_sent_ctx` built by `_ota_watch_correct`
        (key = (lowercase ota, raw OTA name of the room), value contains
        `config_room` and `target`) — covers BOTH origins of a
        correction (PC button and mobile order), since both go through
        `_ota_watch_correct` then here. Fail-safe (D8), daemon thread."""
        pushed = [
            {"room": ctx.get("config_room"), "ota_name": ctx.get("ota_name"),
             "target": ctx.get("target")}
            for ctx in (sent_ctx or {}).values()
            if ctx.get("config_room") and ctx.get("ota_name") and ctx.get("target") is not None
        ]
        if not pushed:
            return

        def _worker():
            try:
                from business.mobile_gateway import mark_rooms_corrected
                mark_rooms_corrected(pushed)
            except Exception:
                pass

        import threading as _thr
        _thr.Thread(target=_worker, daemon=True).start()

    def _notify_price_gaps(self, results):
        """Sends a notification if price gaps have been detected."""
        try:
            from business.notifications import send_notifications
            ota_cfg      = self.app.config.get("ota_watch", {})
            target_prices = ota_cfg.get("target_prices", {})
            min_gap       = ota_cfg.get("min_gap", 50)
            gaps          = {}
            for ota_name, room_prices in results.items():
                if not isinstance(room_prices, dict):
                    continue
                for room, detected in room_prices.items():
                    if not detected:
                        continue
                    targets = target_prices.get(room, {})
                    # Try exact key, then group alias, then any available
                    target = (targets.get(ota_name)
                              or targets.get(_MMT_DISPLAY)
                              or (list(targets.values())[0] if targets else None))
                    if target is None:
                        continue
                    gap = abs(float(target) - float(detected))
                    if gap >= min_gap:
                        gaps[f"{room} ({ota_name})"] = {
                            "detected": detected,
                            "target":   target,
                            "gap":      gap,
                            "ota":      ota_name,
                        }
            if gaps:
                send_notifications(
                    "price_gap_detected", gaps,
                    self.app.config,
                    triggers=self.app.config.get("automation", {}).get("triggers", {}))
        except Exception:
            pass

    def _wknd_cfg(self):
        """Weekend markup config → dict {enabled, pct} for _do_push."""
        ow = self.app.config.get("ota_watch", {})
        try:
            pct = float(ow.get("weekend_markup_pct", 20))
        except (ValueError, TypeError):
            pct = 20.0
        days = ow.get("weekend_days", [4, 5])
        return {"enabled": bool(ow.get("weekend_markup_enabled", True)), "pct": pct, "days": days}

    # ─── SEND HISTORY (sent price → displayed price) ────────────────────────

    def _scanned_stay_date(self):
        """Stay date the OTA scan actually reads (today + date_offset).

        This is the date that matters for the history: the price displayed
        by the OTA is the one of THIS date, so the "sent" price to pair
        with it must be the one sent for THIS date — weekend markup
        included.
        """
        ow = self.app.config.get("ota_watch", {})
        try:
            _off = max(0, int(ow.get("date_offset", 1)))
        except (ValueError, TypeError):
            _off = 1
        return (datetime.now() + timedelta(days=_off)).date()

    def _ota_discount_pct(self, room_key, ota_low):
        """Discount configured for this OTA's rate plan (0 if none).

        Read from channel_manager.room_mapping — this is the value
        app_core.py::_do_push uses to divide the price before sending.
        """
        try:
            _rm = (self.app.config.get("channel_manager", {})
                   .get("room_mapping", {}).get(room_key, {}))
            for _rp in _rm.get("rate_plans", []) or []:
                _n = (_rp.get("ota_name", "") or "").strip().lower()
                # Goibibo and MakeMyTrip = same inventory (see app_core.py).
                if _n == "goibibo":
                    _n = "makemytrip"
                if _n and _n == (ota_low or "").strip().lower():
                    return float(_rp.get("ota_discount_pct", 0) or 0)
        except Exception:
            logging.exception("unreadable OTA discount (%s / %s)", room_key, ota_low)
        return 0.0

    def _real_sent_price(self, base_price, room_key, ota_low):
        """Price that ACTUALLY went to the Channel Manager for the scanned date.

        Between the computed price and what circulates on the network, two
        transformations apply. They are reproduced here identically,
        otherwise the history would record a figure that was never sent
        and every calculation built on it would be wrong:

          1. rate plan discount — app_core.py:
                 price / (1 − ota_discount_pct/100)
          2. per-date weekend markup — channel_manager.py::weekend_rate_segments:
                 × (1 + pct/100) if the scanned day is in weekend_days

        Real example: target 2100 ₹, scan on D+1 = Friday, +10 % markup
        → 2310 ₹ actually sent for that date.

        Returns (sent_price, discount_pct, markup_pct, is_weekend, date_iso).
        """
        _price = float(base_price)
        _disc  = self._ota_discount_pct(room_key, ota_low)
        if 0 < _disc < 100:
            _price = _price / (1.0 - _disc / 100.0)

        _w      = self._wknd_cfg()
        _date   = self._scanned_stay_date()
        _is_wk  = bool(_w.get("enabled")) and _date.weekday() in (_w.get("days") or [])
        _mkp    = float(_w.get("pct", 0) or 0) if _is_wk else 0.0
        if _is_wk:
            _price = _price * (1.0 + _mkp / 100.0)

        return (int(round(_price)), _disc, _mkp, _is_wk, _date.strftime("%Y-%m-%d"))

    def _base_from_sent(self, sent_price, room_key, ota_low):
        """Exact inverse of _real_sent_price: sent price → base price.

        The adaptive calculation reasons on the price that ACTUALLY went
        out — that is the one the OTA transformed. But the correction must
        produce a BASE price: the rate plan discount (app_core.py) and the
        weekend markup (channel_manager.py) will be reapplied further
        down. Without this step back, the markup would be counted twice
        and the sent price would drift by +10 % on every loop turn.

        The two operations are undone in the INVERSE order of
        _real_sent_price — any divergence between the two methods would
        corrupt the history and therefore every calculation built on it.
        """
        _price = float(sent_price)

        _w    = self._wknd_cfg()
        _date = self._scanned_stay_date()
        if bool(_w.get("enabled")) and _date.weekday() in (_w.get("days") or []):
            _mkp = float(_w.get("pct", 0) or 0)
            if _mkp > -100:
                _price = _price / (1.0 + _mkp / 100.0)

        _disc = self._ota_discount_pct(room_key, ota_low)
        if 0 < _disc < 100:
            _price = _price * (1.0 - _disc / 100.0)

        return int(round(_price))

    # Measurements kept for the adaptive calculation: the 6 most recent, nothing
    # older than 14 days. An OTA changes behavior (promo, season, commission);
    # a month-old measurement no longer describes anything.
    _ADAPT_MAX_POINTS   = 6
    _ADAPT_MAX_AGE_DAYS = 14
    # Safety net: a computed price cannot deviate by more than ×3 (or ÷3) from
    # the target. This is not a pricing setting — the real bounds are those of
    # the settings (_borner) — but a protection against absurd extrapolation
    # from a poorly conditioned line.
    _ADAPT_MAX_RATIO = 3.0
    # Maximum step from one turn to the next, in % of the last sent price. A
    # very distant computation is not refused: it is reached over several
    # turns. And it is not just a precaution — every intermediate turn adds a
    # measurement, so the next computation is better grounded than today's.
    _ADAPT_MAX_STEP_PCT = 25.0

    def _stall_limit(self):
        """Scans without an OTA reaction before suspending sends (0 = never)."""
        try:
            return max(0, int(self.app.config.get("ota_watch", {})
                              .get("stall_checks", 3)))
        except (TypeError, ValueError):
            return 3

    def _ota_stalled(self, ota_name, raw_room):
        """Has the OTA stopped reflecting our sends? → (suspended, nb_scans).

        The Channel Manager accepted the send — otherwise nothing would be
        pending in the history — but N scans in a row saw exactly the same
        price as before. Sending one more price would not change that, and
        above all it would abandon the pending measurement: we would never
        learn what the OTA does with our sends, and the loop would spin
        empty for hours.

        The block lifts by itself as soon as the price moves: that is the
        moment the measurement completes and the wait disappears.
        """
        _seuil = self._stall_limit()
        if _seuil <= 0:
            return False, 0
        try:
            from core import send_history as _sh
            _n = _sh.stalled_checks(ota_name, raw_room)
        except Exception:
            logging.exception("safety limit: unreadable stall counter "
                              "(%s / %s)", ota_name, raw_room)
            return False, 0
        return (_n >= _seuil), _n

    def _cm_grid_price(self, ota_name, config_room):
        """D38: CURRENT CM price on the OTASheet grid (passive reading of
        the captures — no browser action) for room×OTA, at the
        scanned date. None if the grid is mute for this cell.

        Why: on 28/08 at 19:04, the D35 anchor computed with a historical
        "last send" from 18/08 (3,500) while the CM held 1,600
        (set manually 30 minutes earlier) → order 3,793 instead of
        ~1,618, overwriting the 1,600. The grid is the truth to the
        minute; the history can be dry, stale or badly keyed."""
        try:
            import extranet_bridge as _eb
            st = _eb.cm_state(self.app.config)
            if not st:
                return None
            _date = self._scanned_stay_date().isoformat()
            _ol = (ota_name or "").strip().lower()
            # Goibibo and MakeMyTrip share the SAME inventory: the grid
            # cell of MakeMyTrip IS Goibibo's (mirror of the goibibo→
            # makemytrip renaming already applied at push by app_core).
            _ol = "goibibo" if _ol == "makemytrip" else _ol
            _oc = None
            for _o in st.get("otas") or []:
                if str(_o.get("label", "")).strip().lower() == _ol:
                    _oc = str(_o.get("code"))
                    break
            if _oc is None:
                return None
            _rl = (config_room or "").strip().lower()
            for _r in st.get("rooms") or []:
                if str(_r.get("label", "")).strip().lower() == _rl:
                    _p = (st.get("daily") or {}).get(
                        (str(_r.get("code")), _oc, _date))
                    if _p is not None:
                        try:
                            return int(round(float(_p)))
                        except (TypeError, ValueError):
                            return None
                    return None
            return None
        except Exception:
            logging.exception("CM grid anchor: unreadable (%s / %s)",
                              ota_name, config_room)
            return None

    def _next_send_base(self, ota_name, raw_room, config_room, target, detected):
        """BASE price to send now to aim at `target` on this OTA.

        Replaces sending the raw target. Sending 2100 while the scan shows
        Agoda displaying 1532 for that same send could only produce an
        eternal 1532: the target went out identical on every turn, so the
        display too.

        Three regimes, from best informed to least informed:

          1. at least one measurement (sent → displayed): invert the
             observed relation — proportion on one measurement, line from
             two (core/send_history.predict_sent_for);
          2. no measurement but a known previous send: advance by the
             remaining gap (target − displayed) from the last price
             actually sent. This is directed at the target and
             proportional to the distance;
          3. nothing at all (very first send): the target as is — there is
             nothing better until something has been observed.

        Returns (base_price, method, readable_detail).
        """
        from core import send_history as _sh
        _ota_low = (ota_name or "").strip().lower()

        # ── Comparable measurements ──────────────────────────────────────
        # Nature of the day that will be scanned. An OTA may apply a
        # week-end promo different from the weekday one: fitting a line on
        # a mix of both gives a slope describing neither.
        _w  = self._wknd_cfg()
        _d  = self._scanned_stay_date()
        _wk = bool(_w.get("enabled")) and _d.weekday() in (_w.get("days") or [])

        _ms, _scope = [], ""
        try:
            _ms = _sh.get_measures(ota_name, raw_room,
                                   limit=self._ADAPT_MAX_POINTS,
                                   max_age_days=self._ADAPT_MAX_AGE_DAYS,
                                   weekend=_wk)
            if len(_ms) >= 2:
                _scope = (tr_("weekends alone") if _wk
                          else tr_("weekdays alone"))
            else:
                # Too few comparable measurements for a line: better to
                # widen than stay blind — but it must be said, the
                # computation is less safe.
                _large = _sh.get_measures(ota_name, raw_room,
                                          limit=self._ADAPT_MAX_POINTS,
                                          max_age_days=self._ADAPT_MAX_AGE_DAYS)
                if len(_large) > len(_ms):
                    _ms    = _large
                    _scope = tr_("all days combined, due to lack of comparable measurements")
        except Exception:
            logging.exception("adaptive computation: unreadable history (%s / %s)",
                              ota_name, raw_room)
            _ms = []

        _last = None
        try:
            _last = _sh.last_sent(ota_name, raw_room)
        except Exception:
            logging.exception("adaptive computation: unreadable last send "
                              "(%s / %s)", ota_name, raw_room)

        # ── D38: the "last sent" becomes the CURRENT CM price read from
        # the grid (passive reading) when the grid speaks — the history is
        # only a fallback now. On 28/08 at 19:04 the anchor was computed
        # from an 18/08 send (3,500) while the CM held 1,600 → 3,793 sent
        # instead of ~1,618. Every downstream guard (max 25 % step,
        # ×ratio clip, anti-fixed-point) follows the SAME reference: the
        # movement is bounded against what is ACTUALLY in place, not
        # against a stale figure.
        _cur = self._cm_grid_price(ota_name, config_room)
        _ref = _cur if _cur else _last
        _src = (tr_("current CM price {c:,}").format(c=_cur) if _cur
                else (tr_("last sending {l:,}").format(l=int(_last))
                      if _last else tr_("no reference")))

        # ── D35: fresh anchor (priority over the history) ───────────────
        # The (price in place, CURRENT displayed) pair is the most recent
        # observation of how the OTA transforms our sends.
        # base = price_in_place × target / displayed: mathematically, the
        # send MOVES as soon as the display is not at the target — the
        # fixed point of 27/08 (resending 2,625 already in place while
        # Agoda displayed 2,271, target 1,400) becomes impossible.
        _tgt_f, _det_f = float(target or 0), float(detected or 0)
        _anchor = None
        if _ref and _det_f > 0 and _tgt_f > 0 and abs(_det_f - _tgt_f) >= 1:
            _cand = int(round(float(_ref) * _tgt_f / _det_f))
            if _cand > 0 and _cand != int(_ref):
                _anchor = _cand

        if _anchor is not None:
            _sent, _meth = _anchor, tr_("fresh anchor")
            _det = tr_("{src} → displayed {d:,}: to display {t:,}, send {r:,} × {t:,} ÷ {d:,}").format(
                src=_src, d=int(_det_f), t=int(_tgt_f), r=int(_ref))
        else:
            _sent, _meth, _det = _sh.predict_sent_for(_ms, target)

        if _sent is None:
            if _ref and detected:
                _reste = int(target) - int(detected)
                _sent  = int(_ref) + _reste
                _meth  = tr_("not towards the target")
                _det   = tr_("{src} + remaining gap {gap}").format(
                    src=_src, gap=f"{_reste:+,}")
            else:
                return (int(target), tr_("target"),
                        tr_("no measurements — target sent as is"))

        _gardes = []

        # ── Safety limit: maximum step from one turn to the next ────────
        if _ref:
            _pas = max(1, int(round(abs(_ref) * self._ADAPT_MAX_STEP_PCT / 100.0)))
            _cap = min(max(int(_sent), int(_ref) - _pas), int(_ref) + _pas)
            if _cap != int(_sent):
                _gardes.append(tr_("not limited to {p} % — sending {csym}{v}").format(
                    p=int(self._ADAPT_MAX_STEP_PCT), v=f"{int(_cap):,}", csym=self._csym))
                _sent = _cap

        # ── Anti-extrapolation net ────────────────────────────────────────
        # The real bounds (min/max from the settings) are applied later by
        # _borner; this net protects even when no bound is configured.
        _lo      = float(target) / self._ADAPT_MAX_RATIO
        _hi      = float(target) * self._ADAPT_MAX_RATIO
        _clamped = int(round(min(max(float(_sent), _lo), _hi)))
        if _clamped != int(_sent):
            _gardes.append(tr_("clipped at ×{r} of target").format(
                r=int(self._ADAPT_MAX_RATIO)))
            _sent = _clamped

        # ── D35: anti-fixed-point guard ─────────────────────────────────
        # NEVER resend the price already in place as-is while the display
        # is not at the target: an identical resending is a send with no
        # effect that teaches nothing — it is what inflated the
        # "unchanged after N scans" counters. Minimum movement:
        # 2 % of the last send, in the direction of the target.
        if _ref and _det_f > 0 and _tgt_f > 0 \
                and abs(_det_f - _tgt_f) >= 1 and int(_sent) == int(_ref):
            _sens = -1 if _det_f > _tgt_f else 1
            _pas_min = max(1, int(round(abs(float(_ref)) * 0.02)))
            _sent = int(_ref) + _sens * _pas_min
            _gardes.append(tr_("fixed point avoided — movement of {p}").format(
                p=f"{_sens * _pas_min:+,}"))

        _bits = [x for x in ([_det, _scope] + _gardes) if x]
        return (self._base_from_sent(_sent, config_room, _ota_low),
                _meth, " — ".join(_bits))

    def _fuzzy_target(self, rm, ota_n, target_prices):
        """(room displayed by the OTA, OTA) → (target price, config key).

        The name displayed by the OTA does not always match the
        configuration word for word: matching by common words
        (Jaccard >= 0.5). Returns (0, rm) if no target is configured.

        Method shared by the correction and the calibration: both MUST
        aim at exactly the same target, otherwise one would correct
        towards one price and the other towards another, endlessly.
        """
        room_targets = target_prices.get(rm, {}) or {}
        exact = _target_for_ota(room_targets, ota_n)
        if exact:
            return exact, rm
        rm_w = set(w.lower() for w in rm.split() if len(w) > 2)
        if not rm_w:
            return 0, rm
        # Only rooms carrying a target for THIS OTA compete. A closer room
        # with a different OTA's target must not eclipse the right room.
        best_score, best_value, best_room = 0.0, 0, rm
        for tp_r, tp_d in (target_prices or {}).items():
            tp_w = set(w.lower() for w in tp_r.split() if len(w) > 2)
            if not tp_w:
                continue
            score = len(rm_w & tp_w) / len(rm_w | tp_w)
            value = _target_for_ota(tp_d, ota_n)
            if score >= 0.5 and score > best_score and value:
                best_score, best_value, best_room = score, value, tp_r
        return best_value, best_room

    def _record_send_history(self, corrections_by_ota, sent_ctx):
        """Record in the history what just went out, OTA by OTA.

        Called ONLY when the Channel Manager accepted the send. In TEST
        MODE, channel_manager.py reports "success" without sending
        anything: the measurement is then marked `simulated` so it never
        enters a computation, while staying visible in the file.
        """
        from core import send_history as _sh
        _simulated = bool(self.app.config.get("channel_manager", {})
                          .get("test_mode", False))
        for (_ota_low, _raw_room), _ctx in (sent_ctx or {}).items():
            try:
                _ck = _ctx.get("config_room") or ""
                # Goibibo and MakeMyTrip share the SAME inventory: the price
                # that actually went to the Channel Manager through the
                # Goibibo channel is the one computed for MakeMyTrip
                # (goibibo→makemytrip renaming in app_core.py::_do_push).
                # Recording here the "Goibibo side" price — never sent —
                # would teach the history a false relation: it is the
                # origin of the near-zero slope observed on 2026-08-16
                # (the display moved, but not according to the recorded
                # figure).
                _price_src = "makemytrip" if _ota_low == "goibibo" else _ota_low
                _base = ((corrections_by_ota.get(_ck) or {}).get(_price_src)
                         or (corrections_by_ota.get(_ck) or {}).get(_ota_low))
                if not _base:
                    continue
                _sent, _disc, _mkp, _wknd, _date = self._real_sent_price(
                    _base, _ck, _ota_low)
                _ok = _sh.record_send(
                    _ctx.get("ota_name") or _ota_low, _raw_room,
                    sent=_sent, target=_ctx.get("target"),
                    observed_before=_ctx.get("observed_before"),
                    base_price=_base, stay_date=_date,
                    markup_pct=_mkp, weekend=_wknd, discount_pct=_disc,
                    simulated=_simulated, config_room=_ck)
                if _ok:
                    _note = tr_(" (simulated — TEST MODE)") if _simulated else ""
                    _mkp_note = (tr_(" · including weekend increase +{p}%").format(
                        p=int(_mkp)) if _wknd else "")
                    self.app._log_journal(
                        tr_("📓 History {ota} / {room}: sent {csym}{sent} for {date}{mkp} — displayed before sending {csym}{before}{note}").format(
                                ota=_ctx.get("ota_name") or _ota_low,
                                room=_raw_room, sent=f"{_sent:,}", date=_date,
                                mkp=_mkp_note, csym=self._csym,
                                before=_ctx.get("observed_before") or "?",
                                note=_note),
                        engine="OTA_WATCH")
            except Exception:
                logging.exception("send history: %s / %s not recorded",
                                  _ota_low, _raw_room)

    def _record_observation_history(self, results):
        """Completes the history with the prices displayed by the scan that just
        finished.

        An observation only becomes a measurement if the price CHANGED since
        the send: OTAs sometimes take far more than 5 min to pass on a rate,
        and recording a not-yet-refreshed price would create a false pair
        that would durably corrupt the computations.
        """
        from core import send_history as _sh
        for _ota_n, _rooms in (results or {}).items():
            for _raw_room, _price in (_rooms or {}).items():
                if not _price:
                    continue
                try:
                    _st = _sh.record_observation(_ota_n, _raw_room, _price)
                    if _st == _sh.OBS_CONFIRMED:
                        # The measurement just became "confirmed": it is the
                        # latest of the list. include_simulated so the
                        # journal stays readable in TEST MODE too.
                        _done = _sh.get_measures(_ota_n, _raw_room, limit=1,
                                                 include_simulated=True)
                        _sent = (_done[-1] if _done else {}).get("sent")
                        self.app._log_journal(
                            tr_("📓 Measurement {ota} / {room}: sent {csym}{sent} → displayed {csym}{obs}").format(
                                    ota=_ota_n, room=_raw_room, csym=self._csym,
                                    sent=f"{int(_sent):,}" if _sent else "?",
                                    obs=f"{int(_price):,}"),
                            engine="OTA_WATCH")
                    elif _st == _sh.OBS_UNCHANGED:
                        self.app._log_journal(
                            tr_("⏳ {ota} / {room}: price unchanged ({csym}{obs}) — the OTA has not yet passed on the shipment, no action recorded").format(
                                    ota=_ota_n, room=_raw_room, csym=self._csym,
                                    obs=f"{int(_price):,}"),
                            engine="OTA_WATCH")
                except Exception:
                    logging.exception("history: observation %s / %s failed",
                                      _ota_n, _raw_room)

    def _ota_watch_fill_tree(self, results):
        """Fills the results table from {ota_name: {room: price}}."""
        try:
            self._ota_watch_tree.delete(*self._ota_watch_tree.get_children())
            cfg           = self.app.config.get("ota_watch", {})
            target_prices = cfg.get("target_prices", {})

            # ── Configure per-OTA colour tags on the treeview ──
            _seen_ota_colors: set[str] = set()
            for _on in results:
                _oc = _get_ota_color(_on)
                if _oc not in _seen_ota_colors:
                    # Use group key so Goibibo & MakeMyTrip share one tag
                    _gk = _ota_group_key(_on).replace(' ', '_')
                    _tag_name = f"ota_{_gk}"
                    self._ota_watch_tree.tag_configure(
                        _tag_name, foreground=_oc)
                    _seen_ota_colors.add(_oc)

            # Current CM prices from heatmap (most recent date)
            _hm_prices = {}
            try:
                for _hk, _hv in sorted(self.app.config.get("heatmap_data", {}).items()):
                    _hp = _hk.split("_", 1)
                    _hm_prices[_hp[1] if len(_hp) > 1 else _hk] = _hv.get("my_price", 0) or 0
            except Exception:
                pass

            # Floors from the strategy
            _strat_floors = {}
            try:
                _strat_floors = self.app.config.get("strategy", {}).get("floors", {})
            except Exception:
                pass

            # Fuzzy match room name → target_prices key (Jaccard >= 0.5)
            def _fuzzy_target(rm, ota_n):
                return self._fuzzy_target(rm, ota_n, target_prices)

            if not results:
                self._ota_watch_tree.insert("", "end",
                    values=("—", "No result", "—", "—", "—", "—", "—"),
                    tags=("none",))
                return

            for ota_name, room_prices in results.items():
                # Skip generalist / metasearch sites that slipped through
                # (defensive — they should be blocked at scan time).
                _on_lower = ota_name.lower()
                if any(g in _on_lower for g in
                       ("google hotel", "google travel", "trivago",
                        "kayak", "tripadvisor")):
                    continue
                # Build the OTA-specific tag name (foreground = OTA colour)
                _gk = _ota_group_key(ota_name).replace(' ', '_')
                _ota_tag = f"ota_{_gk}"
                if not room_prices:
                    self._ota_watch_tree.insert("", "end",
                        values=(ota_name, "No price detected",
                                "—", "—", "—", "—", "⚪"),
                        tags=(_ota_tag,))
                    continue
                for room, detected in room_prices.items():
                    if not detected:
                        continue
                    # Skip internal CM test rooms (e.g. "move room") that
                    # never appear on real booking sites.
                    if room.lower().strip() in _EXCLUDED_ROOMS:
                        continue
                    target, _matched_r = _fuzzy_target(room, ota_name)
                    # Target price = WEEKDAY price (base). The weekend markup
                    # is applied per DATE at the CM send (Fri/Sat), not here.
                    _cm_price = _hm_prices.get(room, 0) or _hm_prices.get(_matched_r, 0)
                    _floor    = _strat_floors.get(room, 0) or _strat_floors.get(_matched_r, 0)
                    if target and detected:
                        gap = target - detected
                        _pct = (gap / target * 100.0) if target else 0.0
                        if gap > 0:
                            # OTA too low → send the exact target (or the floor if higher)
                            to_send = int(max(target, _floor) if _floor else target)
                            gap_str  = f"▼ -{self._csym}{abs(int(gap)):,} ({_pct:+.0f}%)"
                            status   = "🔴 Too low"
                            _row_tag = "low"
                        elif gap < 0:
                            # OTA too high → send the target directly
                            to_send  = int(target)
                            gap_str  = f"▲ +{self._csym}{abs(int(gap)):,} ({_pct:+.0f}%)"
                            status   = "🔵 Surplus"
                            _row_tag = "high"
                        else:
                            to_send  = int(detected)
                            gap_str  = "✓ 0%"
                            status   = "🟢 OK"
                            _row_tag = "ok"
                        send_str = f"{self._csym}{to_send:,}"
                    else:
                        gap_str  = "—"
                        send_str = "—"
                        status   = "⚪ Target N/A"
                        _row_tag = "none"
                    self._ota_watch_tree.insert("", "end", values=(
                        ota_name, room,
                        f"{self._csym}{int(target):,}" if target else "—",
                        f"{self._csym}{int(detected):,}",
                        gap_str, send_str, status,
                    ), tags=(_ota_tag, _row_tag))

            # ── Re-configure status tags AFTER OTA brand tags so that the
            #    foreground reflects status (green/red/orange/gray) rather
            #    than the vivid OTA brand colour.  In ttk.Treeview the LAST
            #    tag_configure that sets foreground wins per-item.
            #    This makes room names readable like the Target Prices grid. ──
            self._ota_watch_tree.tag_configure("ok",   foreground=T.GREEN)
            self._ota_watch_tree.tag_configure("low",  foreground=T.RED)
            self._ota_watch_tree.tag_configure("high", foreground=T.ORANGE)
            self._ota_watch_tree.tag_configure("none", foreground="#888888")

            # ── Reorder according to the room order defined in the hotel ──
            _rt_raw = self.app.config.get("room_types", [])
            _hotel_order = [r if isinstance(r, str) else r.get("type", r.get("name", ""))
                            for r in _rt_raw]
            _rank = {r: i for i, r in enumerate(_hotel_order)}

            def _natural_key(item_id):
                vals = self._ota_watch_tree.item(item_id, "values")
                room_val = vals[1] if len(vals) > 1 else ""
                ota_val  = vals[0] if vals else ""
                # Look for the exact rank, then fuzzy (substring)
                r = _rank.get(room_val)
                if r is None:
                    for i, rt in enumerate(_hotel_order):
                        if room_val.lower() in rt.lower() or rt.lower() in room_val.lower():
                            r = i
                            break
                return (r if r is not None else len(_hotel_order), ota_val)

            _items = list(self._ota_watch_tree.get_children(""))
            for _i, _iid in enumerate(sorted(_items, key=_natural_key)):
                self._ota_watch_tree.move(_iid, "", _i)
            # Alternating bands per room group — visually groups each
            # room category (replaces line-by-line zebra striping).
            self._stripe_by_room()
            # Summary bar below the table.
            self._update_ota_summary()

            # Capture this order as the natural order (base for column sort)
            try:
                self._ota_watch_sort_reset()
            except Exception:
                pass

        except Exception:
            logging.exception("Could not render OTA scan table")
        finally:
            # No list comprehension here: Nuitka 4.1.2 crashes cloning a
            # comprehension inside a finally block (AssertionError listcomp_*.0_clone).
            try:
                from diagnostic.scan_trace import append_checkpoint
                tree = self._ota_watch_tree
                rows = []
                for i in tree.get_children(""):
                    rows.append(list(tree.item(i, "values")))
                append_checkpoint(getattr(self, "_diagnostic_scan_id", ""), "ui_render",
                                  rows=rows, received=results)
            except Exception:
                logging.exception("Could not record OTA scan table evidence")

    def _stripe_by_room(self):
        """Background alternation per room group (not per line).

        Visually groups each room category: all the lines of the same
        room share the same background tint, and the tint switches at
        every room change. Preserves the foreground tags (status, OTA
        colour) — only the ``background`` is touched.
        Call once the lines are in their final order (room sort).
        """
        tree = self._ota_watch_tree
        tree.tag_configure("_grp_a", background="#f5f0e1")   # soft beige
        tree.tag_configure("_grp_b", background="#dff0ea")   # soft turquoise
        prev_room = None
        grp = 0  # 0 = _grp_a (main tint), 1 = _grp_b (alternating tint)
        for iid in tree.get_children(""):
            vals = tree.item(iid, "values")
            room_val = vals[1] if len(vals) > 1 else ""
            if room_val != prev_room:
                # Switch tint only from the 2nd group on (the 1st one
                # stays _grp_a) so the alternation starts with the main
                # tint.
                if prev_room is not None:
                    grp = 1 - grp
                prev_room = room_val
            cur_tags = tuple(t for t in tree.item(iid, "tags")
                             if not t.startswith("_grp_"))
            tree.item(iid, tags=cur_tags + (("_grp_a",) if grp == 0 else ("_grp_b",)))

    def _update_ota_summary(self):
        """Updates the summary bar below the results table."""
        if not hasattr(self, "_ota_watch_summary"):
            return
        tree = self._ota_watch_tree
        try:
            kids = tree.get_children("")
            if not kids:
                self._ota_watch_summary.config(text="")
                return
            _rooms = set()
            _otas = set()
            _alerts = 0
            _ok = 0
            for iid in kids:
                vals = tree.item(iid, "values")
                if len(vals) > 1:
                    _rooms.add(vals[1])
                if vals:
                    _otas.add(vals[0])
                tags = tree.item(iid, "tags")
                if "low" in tags:
                    _alerts += 1
                elif "ok" in tags:
                    _ok += 1
            self._ota_watch_summary.config(
                text=tr_("📊 {r} room(s) · {o} OTA(s) · 🔴 {a} alert(s) · 🟢 {k} OK").format(r=len(_rooms), o=len(_otas),
                                               a=_alerts, k=_ok))
        except Exception:
            pass

    def _ota_watch_correct(self, room=None, ota_name=None, min_gap=None, silent=False):
        """Computes and pushes the corrected prices. min_gap=None → read from config."""
        # D98: under global pause, no sending — clear message.
        try:
            import extranet_bridge as _xb
            if _xb.is_paused():
                self._log_journal(
                    "⏸ " + tr_("sending impossible — the tool is PAUSED (▶ Resume button to restart)"),
                    level="warn", engine="PAUSE")
                return
        except Exception:
            pass
        try:
            ota_cfg       = self.app.config.get("ota_watch", {})
            results       = ota_cfg.get("last_results", {})
            _alertes_prix = []   # anomalies reported by the formula
            _notes_calc   = []   # trace of the adaptive computation, room by room
            # OTAs active in the monitoring — the only targets of the "Correct all" push.
            # Generic marker expected on the Channel Manager side: every Airbnb
            # listing (Double Room, Deluxe Double Room, …) is a distinct scan
            # profile, but the CM mapping's ota_name is always the generic
            # "AirBnB" — without this normalization, ota_filter rejects Airbnb
            # before the price computation is even reached (same cause as for
            # per_ota below).
            _monitored_otas = {
                ("Airbnb" if o["name"].strip().lower().startswith("airbnb")
                 else o["name"].strip())
                for o in ota_cfg.get("otas", [])
                if o.get("active") and o.get("name", "").strip()
            }
            target_prices = ota_cfg.get("target_prices", {})
            if min_gap is None:
                min_gap = ota_cfg.get("min_gap", 50)

            # Current CM prices from heatmap (most recent date)
            _hm_prices = {}
            try:
                for _hk, _hv in sorted(self.app.config.get("heatmap_data", {}).items()):
                    _hp = _hk.split("_", 1)
                    _hm_prices[_hp[1] if len(_hp) > 1 else _hk] = _hv.get("my_price", 0) or 0
            except Exception:
                pass

            # Floors from the strategy
            _strat_floors_c = {}
            try:
                _strat_floors_c = self.app.config.get("strategy", {}).get("floors", {})
            except Exception:
                pass

            # ── Bounds of the price SENT to the Channel Manager ───────────
            # Same rule as the "Floors / Ceilings" screen (see
            # _floor_refresh): a "CM send min/max" setting takes priority,
            # otherwise fall back to the strategy floor / ceiling.
            _ceils_c = {}
            _cm_ov_c = {}
            try:
                _ceils_c = self.app.config.get("strategy", {}).get("ceilings", {}) or {}
                _cm_ov_c = (self.app.config.get("price_floors", {})
                            .get("cm_overrides", {}) or {})
            except Exception:
                pass

            def _key_fuzzy_c(_d, _rm, _fb=None):
                """Key of `_d` designating this room: exact, fallback, then Jaccard >= 0.5."""
                if _rm in _d:
                    return _rm
                if _fb and _fb in _d:
                    return _fb
                _w = set(w.lower() for w in _rm.split() if len(w) > 2)
                if not _w:
                    return None
                _bs, _bk = 0.0, None
                for _k in _d:
                    _kw = set(w.lower() for w in _k.split() if len(w) > 2)
                    if not _kw:
                        continue
                    _sc = len(_w & _kw) / len(_w | _kw)
                    if _sc > _bs and _sc >= 0.5:
                        _bs, _bk = _sc, _k
                return _bk

            def _bornes_cm(_rm, _fb=None):
                """(min, max) allowed for the price sent to the CM. 0 = no bound.
                D94: the "CM send min/max" override applies only to the EXACT
                name of its room (_cm_override_for) — no more fuzziness, which
                let the 2000 of "Double Room with Balcony" leak onto
                "Double Room" (D92 report). The strategy floors/ceilings keep
                the tolerant matching: they are classic per-room settings and
                _rm is already a resolved config name."""
                _ov = _cm_override_for(_cm_ov_c, _rm, _fb)
                _fk = _key_fuzzy_c(_strat_floors_c, _rm, _fb)
                _ck = _key_fuzzy_c(_ceils_c, _rm, _fb)
                _mn = _ov.get("gross_min") or (_strat_floors_c.get(_fk, 0) if _fk else 0)
                _mx = _ov.get("gross_max") or (_ceils_c.get(_ck, 0) if _ck else 0)
                try:
                    return int(_mn or 0), int(_mx or 0)
                except (TypeError, ValueError):
                    return 0, 0

            def _borner(_prix, _rm, _fb=None, _ctx=""):
                """Brings a price back within its bounds. Every out-of-bound exit is reported."""
                _mn, _mx = _bornes_cm(_rm, _fb)
                if _mn and _mx and _mn > _mx:
                    _alertes_prix.append(
                        f"{_ctx}{_rm}: inconsistent bounds (min {_mn:,} > max {_mx:,}) "
                        f"— only the minimum is applied")
                    _mx = 0
                if _mn and _prix < _mn:
                    _alertes_prix.append(
                        f"{_ctx}{_rm}: computed price {int(_prix):,} below the minimum "
                        f"allowed {_mn:,} — brought back to the minimum")
                    return _mn
                if _mx and _prix > _mx:
                    _alertes_prix.append(
                        f"{_ctx}{_rm}: computed price {int(_prix):,} above the maximum "
                        f"allowed {_mx:,} — brought back to the maximum")
                    return _mx
                return int(_prix)

            # Fuzzy match of the OTA room name → target_prices.
            # Single implementation in self._fuzzy_target, shared with the
            # calibration: two copies would eventually diverge and the two
            # loops would aim at different targets.
            def _fuzzy_target_c(rm, ota_n):
                return self._fuzzy_target(rm, ota_n, target_prices)

            # Fuzzy match of the OTA room name → internal strat_floors key (Jaccard >= 0.5)
            def _floor_for(ota_rm, fallback_key=None):
                """Returns (floor_value, config_key) for an OTA room name."""
                fl = _strat_floors_c.get(ota_rm, 0)
                if fl:
                    return fl, ota_rm
                if fallback_key:
                    fl = _strat_floors_c.get(fallback_key, 0)
                    if fl:
                        return fl, fallback_key
                _w = set(w.lower() for w in ota_rm.split() if len(w) > 2)
                if not _w:
                    return 0, ota_rm
                best_s, best_fl, best_k = 0.0, 0, ota_rm
                for _fk, _fv in _strat_floors_c.items():
                    _fw = set(w.lower() for w in _fk.split() if len(w) > 2)
                    if not _fw:
                        continue
                    sc = len(_w & _fw) / len(_w | _fw)
                    if sc > best_s and sc >= 0.5:
                        best_s, best_fl, best_k = sc, _fv, _fk
                return best_fl, best_k

            corrections = {}  # {room: price_to_send} — fallback value, all OTAs combined
            # {room: {lowercase ota_name: price_to_send}} — REAL per-OTA target. Without this,
            # two OTAs with different target prices for the same room (e.g. Agoda 1600 /
            # MakeMyTrip 2000) both ended up with the same overwritten value in
            # `corrections`, which was then broadcast to ALL the OTAs watched by
            # _do_push — hence correct prices on a single OTA and wrong/missing ones
            # on the others.
            corrections_by_ota = {}
            # Context of each send, for the history (core/send_history):
            # {(lowercase ota, room AS THE OTA DISPLAYS IT): {...}}.
            # The key is the raw OTA name, not the config name, because it is
            # the ONLY key shared with the next scan's results — it is what
            # will pair the "sent price" with the "displayed price".
            _sent_ctx = {}

            def _record_by_ota(_room_key, _ota, _price, _lower_is_better,
                               _raw_room="", _detected=None, _target=None):
                _ok = (_ota or "").strip().lower()
                if not _ok:
                    return
                _slot = corrections_by_ota.setdefault(_room_key, {})
                _prev = _slot.get(_ok)
                if _prev is None:
                    _slot[_ok] = _price
                elif _lower_is_better and _price < _prev:
                    _slot[_ok] = _price
                elif not _lower_is_better and _price > _prev:
                    _slot[_ok] = _price
                if _raw_room:
                    _sent_ctx[(_ok, _raw_room)] = {
                        "config_room":     _room_key,
                        # Price displayed by the OTA at the moment of the
                        # decision: it will serve as a witness. The next
                        # scan's observation only counts as a measurement
                        # if the price differs from it.
                        "observed_before": _detected,
                        "ota_name":        (_ota or "").strip(),
                        "target":          _target,
                    }

            for ota_n, room_prices in results.items():
                if ota_name and ota_n != ota_name:
                    continue
                for rm, detected in room_prices.items():
                    if room and rm != room:
                        continue
                    if not detected:
                        continue

                    # ── Safety limit: the OTA no longer passes on our sends ─────
                    # Placed BEFORE any computation and before the "no
                    # target" branch: whatever the path, insisting would
                    # have no effect and would lose the pending
                    # measurement.
                    _fige, _nb_scans = self._ota_stalled(ota_n, rm)
                    if _fige:
                        _alertes_prix.append(
                            f"{ota_n} / {rm}: displayed price unchanged "
                            f"({self._csym}{int(detected):,}) after {_nb_scans} scans, while "
                            f"the Channel Manager accepted the send — sends "
                            f"suspended for this room. To check by hand: "
                            f"rate plan mapping, online restriction, or "
                            f"simple OTA update lag. The "
                            f"suspension lifts by itself as soon as the price moves.")
                        continue

                    target, _matched_r = _fuzzy_target_c(rm, ota_n)
                    # Target price = WEEKDAY price (base). The weekend markup
                    # is applied per DATE at the CM send (Fri/Sat), not here.

                    # ── Case: no target price configured ──────────────────────
                    # Check the floor anyway: if OTA < floor → correct
                    if not target:
                        _fl_c, _fl_key = _floor_for(rm)
                        if _fl_c and detected < _fl_c:
                            # Exact floor, no computation — but still checked
                            # against the allowed maximum (a floor above
                            # the ceiling would be an inconsistent setting).
                            to_send = _borner(int(_fl_c), rm, _fl_key,
                                              _ctx=f"{ota_n} / ")
                            if _fl_key not in corrections or to_send > corrections[_fl_key]:
                                corrections[_fl_key] = to_send
                            _record_by_ota(_fl_key, ota_n, to_send, _lower_is_better=False,
                                           _raw_room=rm, _detected=detected,
                                           _target=target)
                        continue  # no target → no classic gap adjustment

                    _floor_c, _ = _floor_for(rm, _matched_r)
                    gap = target - detected
                    # Internal key (config name) — not the raw OTA name — so that all
                    # downstream lookups (room_mapping, room_auto_update, heatmap_data) work
                    _ck = _matched_r

                    # ── Price to send: adaptive computation ───────────────
                    # The target is NO LONGER sent as-is. Sending 2100
                    # while the scan shows Agoda displaying 1532 for that
                    # same send could only produce an eternal 1532.
                    # We start from what the OTA actually did with the
                    # previous sends (core/send_history) to work back to the
                    # price which, once transformed by it, will yield the
                    # target. No formula based on the struck-through price
                    # or the displayed discount: these values are invented
                    # by the OTA and do not describe its real computation.
                    _prix, _meth, _det = self._next_send_base(
                        ota_n, rm, _matched_r, target, detected)
                    _notes_calc.append(
                        f"{ota_n} / {rm} : displayed {self._csym}{int(detected):,}, "
                        f"target {self._csym}{int(target):,} → base {self._csym}{int(_prix):,} "
                        f"[{_meth}]" + (f" — {_det}" if _det else ""))

                    # ── Priority bounds ───────────────────────────────────
                    # The settings' min/max comes BEFORE the formula's
                    # result: an out-of-bounds computation is brought back
                    # to the bound and reported. `_floor_c` is no longer
                    # applied here — the floor is already included in the
                    # minimum below, and putting it back could push a price
                    # above the allowed maximum again.
                    _prix = _borner(_prix, rm, _matched_r, _ctx=f"{ota_n} / ")

                    if gap >= min_gap:
                        # Too low: send the computed price
                        to_send = int(_prix)
                        if _ck not in corrections or to_send > corrections[_ck]:
                            corrections[_ck] = to_send
                        _record_by_ota(_ck, ota_n, to_send, _lower_is_better=False,
                                       _raw_room=rm, _detected=detected,
                                       _target=target)
                    elif gap <= -min_gap:
                        # Too high: send the computed price
                        to_send = int(_prix)
                        if _ck not in corrections or to_send < corrections[_ck]:
                            corrections[_ck] = to_send
                        _record_by_ota(_ck, ota_n, to_send, _lower_is_better=True,
                                       _raw_room=rm, _detected=detected,
                                       _target=target)

            # ── Final check before sending ────────────────────────────────
            # Last control on what will REALLY go to the Channel
            # Manager, whatever path produced it. The clamping already
            # happened above: if a price still comes out of bounds
            # here, it is corrected and reported.
            for _vk in list(corrections):
                _vv = corrections[_vk]
                _vb = _borner(_vv, _vk, _ctx="final check — ")
                if _vb != _vv:
                    corrections[_vk] = _vb
            for _vk, _by_ota in corrections_by_ota.items():
                for _vo, _vv in list(_by_ota.items()):
                    _vb = _borner(_vv, _vk, _ctx=f"final check ({_vo}) — ")
                    if _vb != _vv:
                        _by_ota[_vo] = _vb

            # Anomalies detected during the computation (absurd discount,
            # inconsistent strike-through, tax-exclusive price, unreadable
            # price…): always logged, including in silent mode — this is
            # the trace that makes it possible to understand afterwards
            # why a price moved or not.
            for _msg in _alertes_prix:
                try:
                    self.app._log_journal("⚠ " + _msg, level="warning",
                                          engine="OTA_WATCH")
                except Exception:
                    logging.warning("OTA correction: %s", _msg)

            # How each price was obtained: chosen method and measurements
            # used. Always logged, including in silent mode —
            # without this trace, it is impossible to reread afterwards why
            # such a price went out rather than another.
            for _msg in _notes_calc:
                try:
                    self.app._log_journal("🧮 " + _msg, engine="OTA_WATCH")
                except Exception:
                    logging.info("OTA correction: %s", _msg)

            if not corrections:
                if not silent:
                    messagebox.showinfo(tr_("OTA fix"),
                        tr_("No discrepancies to correct — all prices are within limit."),
                        parent=self.app.root)
                return

            if not silent:
                lines = "\n".join(f"  • {rm} → {self._csym}{int(p):,}" for rm, p in corrections.items())
                ok = messagebox.askyesno(tr_("Confirm OTA fix"),
                    f"Prices to send to the Channel Manager:\n{lines}\n\nConfirm?",
                    parent=self.app.root)
                if not ok:
                    return

            # Same normalization as ota_filter above, this time applied
            # to the per-OTA correction keys passed to _do_push. The internal
            # keys of corrections_by_ota stay the raw profile names
            # (needed for the pairing with the send history via
            # _sent_ctx) — only this copy destined to the Channel Manager is
            # normalized.
            def _cm_ota_key(_k):
                return "airbnb" if _k.startswith("airbnb") else _k

            valid_results  = {rm: {"final": p,
                                    "per_ota": {_cm_ota_key(_k): _v for _k, _v
                                                in corrections_by_ota.get(rm, {}).items()}}
                              for rm, p in corrections.items()}
            cm             = self.app.config.get("channel_manager", {})
            _correct_offset = max(0, int(ota_cfg.get("correct_date_offset", 0)))
            checkin        = (datetime.now() + timedelta(days=_correct_offset)).strftime("%Y-%m-%d")
            try:
                _correct_days = max(1, min(365, int(ota_cfg.get("correct_duration_days", 90))))
            except (ValueError, TypeError):
                _correct_days = 90

            def _ota_corr_done(ok, msg, sent_items=None):
                try:
                    if hasattr(self, "_ota_watch_status"):
                        if ok:
                            self._ota_watch_status.config(
                                text=tr_("✅ CM: new price sent to Channel Manager — {msg}").format(msg=msg),
                                fg=T.GREEN)
                        else:
                            self._ota_watch_status.config(
                                text=tr_("✗ CM: sending failed — {msg}").format(msg=msg), fg=T.RED)
                except Exception:
                    pass
                # D105-2: batch with a failed group BUT with segments
                # that actually went out (POST proof) → measure them
                # ANYWAY. Without this, 1-2 failed segments out of 95
                # deprived the learning of all the batch's measurements
                # (client PC 08-09/10: "NO send ever recorded" on Expedia
                # despite massive verified sends).
                if not ok and sent_items:
                    try:
                        from extranet_bridge import record_queue_sent_items
                        _n = record_queue_sent_items(
                            sent_items, self.app.config)
                        if _n:
                            self.app._log_journal(
                                tr_("📓 History: {n} partially failed batch shipment(s) recorded (POST proof)").format(n=_n),
                                engine="OTA_WATCH")
                    except Exception:
                        logging.exception("send history (partial "
                                          "batch) not recorded")
                # Update heatmap_data with the sent prices
                # → the next scan will use these prices as base → automatic escalation
                if ok:
                    try:
                        hd = self.app.config.get("heatmap_data", {})
                        _updated = False
                        for _rm, _pr in corrections.items():
                            for _hk in sorted(hd.keys(), reverse=True):
                                if _hk.split("_", 1)[-1] == _rm:
                                    hd[_hk]["my_price"] = float(_pr)
                                    _updated = True
                                    break
                        if _updated:
                            self.app.config["heatmap_data"] = hd
                            cfg.save(self.app.config)
                    except Exception:
                        pass

                    # ── Send history ─────────────────────────────────────
                    # Trace "price sent for such a date → displayed price",
                    # per OTA and per room, saved on disk.
                    # This is the missing memory: without it, impossible
                    # to adjust a price in view of the previous one's effect,
                    # and the software resent the same value endlessly.
                    try:
                        self._record_send_history(corrections_by_ota, _sent_ctx)
                    except Exception:
                        logging.exception("send history: recording failed")

            def _ota_corr_done_with_notif(ok, msg, sent_items=None):
                _ota_corr_done(ok, msg, sent_items)
                if ok:
                    try:
                        self._publish_mobile_state_correction(_sent_ctx)
                    except Exception:
                        pass
                    try:
                        from business.notifications import send_notifications
                        send_notifications(
                            "correction_envoyee",
                            {room: prix for room, prix in corrections.items()},
                            self.app.config,
                            triggers=self.app.config.get(
                                "automation", {}).get("triggers", {}))
                    except Exception:
                        pass

            # WAITING message set BEFORE the push: the real result is written
            # afterwards by _ota_corr_done (✅ sent / ✗ failed).
            # Previously a "✅ Corrected" was set AFTER the call and overwrote
            # the "✗ CM: sending failed" that _do_push emits synchronously when it
            # has nothing to send (no rate plan retained by ota_filter, empty
            # endpoint, no result): the user read "Corrected" while
            # NO price had gone to the Channel Manager.
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("⏳ Sending the correction to the Channel Manager: {rooms}…").format(
                        rooms=", ".join(corrections.keys())), fg=T.YELLOW)

            self._do_push(valid_results, cm, checkin, _correct_days, getattr(self, "_cm_log", None),
                          silent=True, on_done=_ota_corr_done_with_notif, source="OTA Price Guard",
                          weekend_markup=self._wknd_cfg(),
                          ota_filter=_monitored_otas or None)

            # ── Start the iterative calibration if enabled ──
            try:
                _cw_cfg = self.app.config.get("ota_watch", {})
                if _cw_cfg.get("calib_auto") and corrections:
                    self._ota_calib_active      = True
                    self._ota_calib_rescanning  = False
                    # No memory of the sends here: it used to live in RAM (lost
                    # on close) and was indexed by room only, so
                    # Agoda/Expedia/MakeMyTrip overwrote each other for a
                    # same room. core/send_history holds that role now,
                    # on disk and separated per OTA.
                    self._ota_calib_retries_cnt = {}
                    _wait_min = max(5, _cw_cfg.get("calib_wait_min", 5))
                    try:
                        _prev = getattr(self, "_ota_calib_after_id", None)
                        if _prev:
                            self.app.root.after_cancel(_prev)
                    except Exception:
                        pass
                    self._ota_calib_after_id = self.app.root.after(
                        _wait_min * 60 * 1000, self._ota_calib_tick)
                    if hasattr(self, "_ota_watch_status"):
                        self._ota_watch_status.config(
                            text=tr_("🔄 Calibration started — re-verification in {n} min").format(n=_wait_min),
                            fg=T.YELLOW)
            except Exception:
                pass

        except Exception as e:
            if not silent:
                messagebox.showerror(tr_("OTA fix error"), str(e), parent=self.app.root)
            else:
                # Do NOT put "import logging" here: Python would then treat
                # "logging" as a local variable over the WHOLE
                # function, and the three uses above (~lines 4195, 4205,
                # 4271) would fail with "cannot access local variable
                # 'logging'". The module is already imported at the top of the file.
                logging.exception("_ota_watch_correct (silent mode) failed")
                self.app._log_journal(f"❌ Auto OTA correction failed: {e}", level="error", engine="OTA_WATCH")

    # ─── ITERATIVE CALIBRATION ────────────────────────────────────────────────

    def _ota_calib_tick(self):
        """Re-scan the OTAs as part of the iterative calibration."""
        try:
            if not getattr(self, "_ota_calib_active", False):
                return
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("🔄 Calibration — OTA re-scan in progress…"), fg=T.YELLOW)
            self._ota_calib_rescanning = True
            self._vae_scan()
        except Exception:
            self._ota_calib_active = False

    def _calib_warn(self, ota_n, room, prix, raison):
        """Reports to the journal a calibration price brought back to a bound."""
        try:
            self.app._log_journal(
                tr_("⚠ Calibration {ota} / {room}: calculated price {p} {raison} — reduced to the terminal").format(
                        ota=ota_n, room=room, p=f"{self._csym}{int(prix):,}", raison=raison),
                level="warning", engine="OTA_WATCH")
        except Exception:
            logging.warning("Calibration %s / %s: %s %s", ota_n, room, prix, raison)

    def _ota_calib_check(self, results):
        """Called after a calibration scan: the loop aiming at the target.

        Previously this loop only watched the floor and advanced by
        +150 ₹ blindly. Three consequences:

          - a room displayed at 1532 ₹ for a target of 2100 ₹ was
            declared "calibration successful" as long as it passed the
            floor: the target was never aimed at;
          - +150 ₹ per turn, at one turn per hour, required dozens of
            hours for a few hundred rupees of gap, without ever taking
            into account what the OTA did with those 150 ₹;
          - the price was pushed on TODAY for 1 night, while the scan
            reads D+`date_offset`: the calibration could not influence
            what would be measured at the next turn.

        Now: stop when the display is within `min_gap` of the
        target, price inferred from the measurements (sent → displayed)
        by the same computation as the normal correction, and send over
        the same date range as the correction — i.e. over the date that
        will actually be scanned.
        """
        try:
            strat_floors  = self.app.config.get("strategy", {}).get("floors", {}) or {}
            strat_ceils   = self.app.config.get("strategy", {}).get("ceilings", {}) or {}
            cfg_ota       = self.app.config.get("ota_watch", {})
            target_prices = cfg_ota.get("target_prices", {}) or {}
            max_retries   = max(1, cfg_ota.get("calib_max_retries", 5))
            wait_min      = max(5, cfg_ota.get("calib_wait_min", 5))
            retries_cnt   = getattr(self, "_ota_calib_retries_cnt", {})
            try:
                min_gap = int(cfg_ota.get("min_gap", 50))
            except (TypeError, ValueError):
                min_gap = 50

            # Fuzzy match of the OTA room name → internal strat_floors key (Jaccard >= 0.5)
            def _calib_floor(ota_rm):
                fl = strat_floors.get(ota_rm, 0)
                if fl:
                    return fl, ota_rm
                _w = set(w.lower() for w in ota_rm.split() if len(w) > 2)
                if not _w:
                    return 0, ota_rm
                best_s, best_fl, best_k = 0.0, 0, ota_rm
                for _fk, _fv in strat_floors.items():
                    _fw = set(w.lower() for w in _fk.split() if len(w) > 2)
                    if not _fw:
                        continue
                    sc = len(_w & _fw) / len(_w | _fw)
                    if sc > best_s and sc >= 0.5:
                        best_s, best_fl, best_k = sc, _fv, _fk
                return best_fl, best_k

            # ── What remains to correct ───────────────────────────────────
            # Key = (OTA, room as the OTA displays it). Two OTAs can
            # have different targets for the same room; mixing them
            # meant sending the price of one to the other.
            todo = {}   # {(ota, OTA room): (target, displayed price, config key)}
            for _ota_n, _rps in (results or {}).items():
                for _rm, _ota_p in (_rps or {}).items():
                    if not _ota_p:
                        continue
                    _tgt, _ck = self._fuzzy_target(_rm, _ota_n, target_prices)
                    if _tgt:
                        # Configured target: it decides, in both
                        # directions — too low AND too high.
                        if abs(int(_tgt) - int(_ota_p)) >= min_gap:
                            todo[(_ota_n, _rm)] = (int(_tgt), int(_ota_p), _ck)
                        continue
                    # No target for this OTA: keep the old floor rule,
                    # otherwise these rooms would no longer be watched.
                    _fl, _fl_key = _calib_floor(_rm)
                    if _fl and _ota_p < _fl:
                        todo[(_ota_n, _rm)] = (int(_fl), int(_ota_p), _fl_key)

            if not todo:
                # ✅ All the rooms are at their target (or above their
                #    floor when no target is configured)
                self._ota_calib_active = False
                n = max(retries_cnt.values()) if retries_cnt else 1
                # Refresh with the fresh scan results (not stale last_results)
                try:
                    self._ota_watch_fill_tree(results)
                except Exception:
                    pass
                ts = fmt_dt(self.app.config.get("ota_watch", {}).get("last_scan_time", ""))
                if hasattr(self, "_ota_watch_status"):
                    self._ota_watch_status.config(
                        text=tr_("✅ Calibration successful in {n} attempt(s) — scan {ts}").format(n=n, ts=ts),
                        fg=T.GREEN)
                return

            # ── New price for each room still far from its target ───
            new_pushes         = {}   # {config key: {"final": p, "per_ota": {...}}}
            corrections_by_ota = {}   # same shape as the correction, for the history
            _sent_ctx          = {}
            detail_bits        = []
            _figees            = 0    # rooms whose OTA no longer passes anything through
            for (_ota_n, _rm), (_tgt, _ota_p, _ck) in todo.items():
                # ── Safety limit: the OTA no longer passes on our sends ─────────
                _fige, _nb_scans = self._ota_stalled(_ota_n, _rm)
                if _fige:
                    _figees += 1
                    try:
                        self.app._log_journal(
                            tr_("⚠ Calibration {ota} / {room}: price displayed unchanged ({csym}{p}) after {n} scans — shipments suspended, to be checked manually").format(
                                    ota=_ota_n, room=_rm,
                                    p=f"{int(_ota_p):,}",
                                    csym=self._csym,
                                    n=_nb_scans),
                            level="warning", engine="OTA_WATCH")
                    except Exception:
                        logging.warning("Calibration stalled: %s / %s", _ota_n, _rm)
                    continue

                # Counter per (OTA, room) and not per room alone: without
                # this, a block on Agoda consumed Expedia's attempts.
                _ol = (_ota_n or "").strip().lower()
                _rk = (_ol, _rm)
                cnt = retries_cnt.get(_rk, 0)
                if cnt >= max_retries:
                    continue    # max reached for this room on this OTA
                retries_cnt[_rk] = cnt + 1

                _base, _meth, _det = self._next_send_base(
                    _ota_n, _rm, _ck, _tgt, _ota_p)

                # Settings bounds: the calibration pushed so far without
                # any min/max control. `_ck` is already the config key (the
                # fuzzy matching happened above), direct read.
                _mn = strat_floors.get(_ck, 0) or 0
                _mx = strat_ceils.get(_ck, 0) or 0
                if _mn and _base < _mn:
                    self._calib_warn(_ota_n, _rm, _base,
                                     tr_("below the minimum {v}").format(v=f"{int(_mn):,}"))
                    _base = int(_mn)
                elif _mx and _base > _mx:
                    self._calib_warn(_ota_n, _rm, _base,
                                     tr_("above the maximum {v}").format(v=f"{int(_mx):,}"))
                    _base = int(_mx)
                _base = int(_base)

                corrections_by_ota.setdefault(_ck, {})[_ol] = _base
                _sent_ctx[(_ol, _rm)] = {
                    "config_room":     _ck,
                    "observed_before": _ota_p,
                    "ota_name":        (_ota_n or "").strip(),
                    "target":          _tgt,
                }
                _slot = new_pushes.setdefault(_ck, {"final": _base, "per_ota": {}})
                _slot["per_ota"][_ol] = _base
                # `final` is only a fallback for an OTA without its own price:
                # keep the highest one, like the normal correction.
                if _base > _slot["final"]:
                    _slot["final"] = _base
                detail_bits.append(
                    f"{_ota_n} / {_rm}: displayed {self._csym}{_ota_p:,}, target {self._csym}{_tgt:,} "
                    f"→ base {self._csym}{_base:,} [{_meth}]" + (f" — {_det}" if _det else ""))

            self._ota_calib_retries_cnt = retries_cnt

            if not new_pushes:
                # Nothing left to send: either the maximum number of
                # attempts is reached everywhere, or the concerned OTAs no
                # longer pass anything through. The two causes call for
                # different checks, so the message must distinguish them.
                self._ota_calib_active = False
                try:
                    self._ota_watch_fill_tree(results)
                except Exception:
                    pass
                if hasattr(self, "_ota_watch_status"):
                    if _figees:
                        _txt = tr_("⚠ Calibration stopped — {n} room(s) whose displayed price no longer changes despite accepted shipments: to be checked manually").format(n=_figees)
                    else:
                        _txt = tr_("⚠ Calibration: max attempts reached — check manually")
                    self._ota_watch_status.config(text=_txt, fg=T.ORANGE)
                return

            # How each calibration price was obtained.
            for _msg in detail_bits:
                try:
                    self.app._log_journal("🧮 " + tr_("Calibration") + " — " + _msg,
                                          engine="OTA_WATCH")
                except Exception:
                    logging.info("Calibration OTA: %s", _msg)

            # ONE correction master. When OTA Blocage's auto-correct is
            # enabled it already pushes computed prices on its own
            # schedule; the calibration loop pushing its own values in
            # between made the two engines alternate conflicting prices
            # for the same rooms (2026-08-16, Expedia: 3,387 at 21:23 then
            # 3,043 at 21:33) — the display oscillated instead of
            # converging. The calibration loop keeps measuring; only its
            # push is disabled.
            if cfg_ota.get("auto_correct"):
                self._ota_calib_active = False
                try:
                    self.app._log_journal(
                        "ℹ " + tr_("Calibration: CM sending ignored — auto correction (OTA price blocking) is active and controls prices alone."),
                        engine="OTA_WATCH")
                except Exception:
                    pass
                if hasattr(self, "_ota_watch_status"):
                    self._ota_watch_status.config(
                        text=tr_("ℹ Calibration: measurement only — auto correction controls CM sendings"),
                        fg="#888888")
                return

            # Push the new prices — SAME date range and SAME options as the
            # normal correction. With the old pair (today, 1 night), the
            # calibration price did not cover the date read by the scan
            # (D+date_offset): the loop was thus measuring the effect of a
            # send that never touched the observed date.
            cm = self.app.config.get("channel_manager", {})
            try:
                _cal_offset = max(0, int(cfg_ota.get("correct_date_offset", 0)))
            except (TypeError, ValueError):
                _cal_offset = 0
            try:
                _cal_days = max(1, min(365, int(cfg_ota.get("correct_duration_days", 90))))
            except (TypeError, ValueError):
                _cal_days = 90
            checkin = (datetime.now() + timedelta(days=_cal_offset)).strftime("%Y-%m-%d")
            _cal_otas = {
                o["name"].strip()
                for o in cfg_ota.get("otas", [])
                if o.get("active") and o.get("name", "").strip()
            }

            def _calib_push_done(ok, msg):
                if ok:
                    # The send only enters the history if it REALLY
                    # went out: otherwise the next scan's measurement would
                    # be paired with a price that never left the application.
                    try:
                        self._record_send_history(corrections_by_ota, _sent_ctx)
                    except Exception:
                        logging.exception("calibration: send history "
                                          "not recorded")
                try:
                    if hasattr(self, "_ota_watch_status"):
                        if ok:
                            self._ota_watch_status.config(
                                text=tr_("✅ CM: calibration price sent — {msg}").format(msg=msg),
                                fg=T.GREEN)
                        else:
                            self._ota_watch_status.config(
                                text=tr_("✗ CM: calibration — sending failed — {msg}").format(msg=msg), fg=T.RED)
                except Exception:
                    pass

            self._do_push(new_pushes, cm, checkin, _cal_days,
                          getattr(self, "_cm_log", None),
                          silent=True, on_done=_calib_push_done,
                          source="OTA Calibration",
                          weekend_markup=self._wknd_cfg(),
                          ota_filter=_cal_otas or None)

            # Refresh the table with the fresh results of the current scan
            try:
                self._ota_watch_fill_tree(results)
            except Exception:
                pass

            n_max  = max(retries_cnt.values())
            detail = ", ".join(f"{rm} → {self._csym}{int(v['final']):,}"
                               for rm, v in new_pushes.items())
            if hasattr(self, "_ota_watch_status"):
                self._ota_watch_status.config(
                    text=tr_("🔄 Calibration {n}/{max}: {detail} — re-check in {wait} min").format(
                        n=n_max, max=max_retries, detail=detail, wait=wait_min),
                    fg=T.YELLOW)

            # Schedule next tick
            try:
                _prev = getattr(self, "_ota_calib_after_id", None)
                if _prev:
                    self.app.root.after_cancel(_prev)
            except Exception:
                pass
            self._ota_calib_after_id = self.app.root.after(
                wait_min * 60 * 1000, self._ota_calib_tick)

        except Exception:
            self._ota_calib_active = False

    # ─── PRIX PLANCHER / PLAFOND OTA ─────────────────────────────────────────

    def _build_price_floor_section(self, parent):
        lbl(parent, tr_("🛡️ OTA floor & ceiling price protection"),
            bold=True, size=12, color=T.ACCENT).pack(anchor="w", padx=10, pady=(12, 2))
        lbl(parent,
            "Floor: OTA too low → the system raises the rate via the CM.   Ceiling: OTA too high → the system lowers the rate via the CM.",
            color=T.FG, size=9).pack(anchor="w", padx=10, pady=(0, 10))

        cols_frame = tk.Frame(parent, bg=T.BG)
        cols_frame.pack(fill="x", padx=10, pady=(0, 8))
        cols_frame.columnconfigure(0, weight=1)

        # ── Plancher & Plafond par chambre ──
        left = tk.Frame(cols_frame, bg=T.ENTRY_BG, padx=10, pady=8)
        left.grid(row=0, column=0, sticky="nsew")

        tk.Label(left, text=tr_("💰 Floor & Ceiling per room"), bg=T.ENTRY_BG, fg=T.ACCENT,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 6))

        tree_floor_frame = tk.Frame(left, bg=T.ENTRY_BG)
        tree_floor_frame.pack(fill="x")
        sb_f = ttk.Scrollbar(tree_floor_frame, orient="vertical")
        sb_f.pack(side="right", fill="y")
        cols_f = ("room", "floor", "ceiling", "gross_min", "gross_max")
        self._tree_floor = ttk.Treeview(tree_floor_frame, columns=cols_f, show="headings",
                                        height=6, selectmode="browse", yscrollcommand=sb_f.set)
        sb_f.config(command=self._tree_floor.yview)
        for col, txt, w in [
            ("room",      "Chambre",         150),
            ("floor",     "Plancher ▼",       95),
            ("ceiling",   "Plafond ▲",        95),
            ("gross_min", "Envoi min CM",    100),
            ("gross_max", "Envoi max CM",    100),
        ]:
            self._tree_floor.heading(col, text=txt)
            self._tree_floor.column(col, width=w, anchor="center" if col != "room" else "w")
        self._tree_floor.pack(side="left", fill="x", expand=True)
        self._tree_floor.tag_configure("warn", foreground=T.ORANGE)
        self._tree_floor.tag_configure("ok",   foreground=T.GREEN)
        self._tree_floor.tag_configure("conflict", foreground=T.RED)
        self._tree_floor_sort_reset = _attach_sort(self._tree_floor)

        btn_f = tk.Frame(left, bg=T.ENTRY_BG)
        btn_f.pack(anchor="w", pady=(6, 0))
        btn(btn_f, tr_("✏ Floor"), self._floor_edit_floor,    color=T.GREEN,  width=12).pack(side="left", padx=(0, 6))
        btn(btn_f, tr_("✏ Ceiling"),  self._floor_edit_ceiling,  color=T.ORANGE, width=12).pack(side="left", padx=(0, 6))

        btn_f2 = tk.Frame(left, bg=T.ENTRY_BG)
        btn_f2.pack(anchor="w", pady=(4, 0))
        btn(btn_f2, tr_("✏ Min CM"),  self._floor_edit_gross_min, color="#89b4fa", width=12).pack(side="left", padx=(0, 6))
        btn(btn_f2, tr_("✏ Max CM"),  self._floor_edit_gross_max, color="#89b4fa", width=12).pack(side="left", padx=(0, 6))
        tk.Label(btn_f2, text=tr_("(0 = auto calculation)"), bg=T.ENTRY_BG, fg="#888888",
                 font=("Segoe UI", 8, "italic")).pack(side="left", padx=(4, 0))


        # ── Ligne surveillance ──
        surv = tk.Frame(parent, bg=T.BG)
        surv.pack(fill="x", padx=10, pady=(8, 4))

        self._floor_auto_var = tk.BooleanVar(value=self.app.config.get("price_floors", {}).get("auto_correct", False))
        tk.Checkbutton(surv, text=tr_("Automatic monitoring during scanning (alert only)"),
                       variable=self._floor_auto_var,
                       command=self._floor_save_auto,
                       bg=T.BG, fg=T.FG, selectcolor=T.ENTRY_BG, activebackground=T.BG,
                       font=("Segoe UI", 10)).pack(side="left", padx=(0, 16))
        btn(surv, tr_("🔍 Check violations"), self._floor_check_violations, color="#cba6f7", width=18).pack(side="left")
        self._floor_status_lbl = tk.Label(surv, text="", bg=T.BG, fg=T.FG, font=("Segoe UI", 9))
        self._floor_status_lbl.pack(side="left", padx=12)
        # Real sending — deliberately separate from monitoring: detecting is
        # risk-free, sending changes the prices actually on sale.
        surv2 = tk.Frame(parent, bg=T.BG)
        surv2.pack(fill="x", padx=10, pady=(2, 0))
        self._floor_push_var = tk.BooleanVar(
            value=self.app.config.get("price_floors", {}).get("auto_push", False))
        tk.Checkbutton(surv2,
                       text=tr_("⚠ Also send corrections to Channel Manager"),
                       variable=self._floor_push_var,
                       command=self._floor_save_push,
                       bg=T.BG, fg=T.ORANGE, selectcolor=T.ENTRY_BG,
                       activebackground=T.BG,
                       font=("Segoe UI", 9, "bold")).pack(side="left")
        lbl(parent,
            tr_("After each scan, prices below the floor or above the ceiling are reported in the log AND sent as an alert (email, Telegram, telephone).\nTop box only = monitoring without any sending: it allows you to first check that the detections are correct.\nSecond box = prices outside the limits are automatically corrected by your Channel Manager, without confirmation."),
            size=8, color="#888888", wraplength=760, justify="left").pack(
                anchor="w", padx=10, pady=(2, 0))

        # ── Zone violations ──
        self._floor_viol_frame = tk.Frame(parent, bg=T.BG)
        self._floor_viol_frame.pack(fill="x", padx=10, pady=(0, 4))

        self._floor_refresh_trees()

    def _floor_refresh_trees(self):
        cfg_data  = self.app.config
        strat     = cfg_data.get("strategy", {})
        floors    = strat.get("floors", {})
        ceilings  = strat.get("ceilings", {})
        pf_cfg    = cfg_data.get("price_floors", {})

        self._tree_floor.delete(*self._tree_floor.get_children())
        rooms = cfg_data.get("room_types", [])
        if not rooms:
            rooms = sorted(set(list(floors.keys()) + list(ceilings.keys())))
        cm_overrides = pf_cfg.get("cm_overrides", {})
        for room in rooms:
            fl  = floors.get(room, 0)
            cel = ceilings.get(room, 0)
            ov  = cm_overrides.get(room, {})
            gross_min = ov.get("gross_min") or fl or 0
            gross_max = ov.get("gross_max") or cel or 0
            if fl and cel and gross_min > gross_max:
                tag = "conflict"
                fl_str  = f"{self._csym}{fl:,.0f}"
                cel_str = f"{self._csym}{cel:,.0f} ⚠"
            elif fl or cel:
                tag = "ok"
                fl_str  = f"{self._csym}{fl:,.0f}" if fl else "—"
                cel_str = f"{self._csym}{cel:,.0f}" if cel else "—"
            else:
                tag = "warn"
                fl_str = cel_str = "— not set —"
            gmin_str = f"{self._csym}{gross_min:,.0f}" if gross_min else "—"
            gmax_str = f"{self._csym}{gross_max:,.0f}" if gross_max else "—"
            self._tree_floor.insert("", "end",
                values=(room, fl_str, cel_str, gmin_str, gmax_str), tags=(tag,))
        zebra_stripe(self._tree_floor)
        try:
            self._tree_floor_sort_reset()
        except Exception:
            pass

    def _floor_edit_floor(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Selection"), tr_("Select a room from the table."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        floors = self.app.config.setdefault("strategy", {}).setdefault("floors", {})
        current = floors.get(room, 0)
        val = simpledialog.askfloat("Prix plancher",
                                    f"Prix plancher pour '{room}' (INR) :\n(minimum en dessous duquel aucun OTA ne peut vendre)",
                                    initialvalue=current, minvalue=0, maxvalue=99999,
                                    parent=self.app.root)
        if val is not None:
            floors[room] = val
            self.app.config.setdefault("room_inventory", {}).setdefault(room, {})["floor"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_ceiling(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Selection"), tr_("Select a room from the table."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        ceilings = self.app.config.setdefault("strategy", {}).setdefault("ceilings", {})
        current = ceilings.get(room, 0)
        val = simpledialog.askfloat("Prix plafond",
                                    f"Prix plafond pour '{room}' (INR) :\n(maximum au-dessus duquel aucun OTA ne peut vendre)",
                                    initialvalue=current, minvalue=0, maxvalue=999999,
                                    parent=self.app.root)
        if val is not None:
            ceilings[room] = val
            self.app.config.setdefault("room_inventory", {}).setdefault(room, {})["ceiling"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_gross_min(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Selection"), tr_("Select a room from the table."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        overrides = self.app.config.setdefault("price_floors", {}).setdefault("cm_overrides", {})
        current = overrides.get(room, {}).get("gross_min", 0)
        val = simpledialog.askfloat(
            "Envoi min CM",
            f"Minimum price to send to the CM for '{room}' (INR):\n"
            f"(ce que tu envoies au CM pour que le client voit au moins ton plancher)\n"
            f"Entrez 0 pour revenir au calcul automatique.",
            initialvalue=current, minvalue=0, maxvalue=999999, parent=self.app.root)
        if val is not None:
            overrides.setdefault(room, {})["gross_min"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()

    def _floor_edit_gross_max(self):
        sel = self._tree_floor.selection()
        if not sel:
            messagebox.showinfo(tr_("Selection"), tr_("Select a room from the table."), parent=self.app.root)
            return
        room = self._tree_floor.item(sel[0])["values"][0]
        overrides = self.app.config.setdefault("price_floors", {}).setdefault("cm_overrides", {})
        current = overrides.get(room, {}).get("gross_max", 0)
        val = simpledialog.askfloat(
            "Envoi max CM",
            f"Maximum price to send to the CM for '{room}' (INR):\n"
            f"(the software will never exceed this amount when sending)\n"
            f"Entrez 0 pour revenir au calcul automatique (= plafond).",
            initialvalue=current, minvalue=0, maxvalue=999999, parent=self.app.root)
        if val is not None:
            overrides.setdefault(room, {})["gross_max"] = val
            cfg.save(self.app.config)
            self._floor_refresh_trees()


    def _floor_save_auto(self):
        pf = self.app.config.setdefault("price_floors", {})
        pf["auto_correct"] = self._floor_auto_var.get()
        # Monitoring unchecked → automatic sending no longer makes sense (it
        # would never be triggered anyway): it is disabled too so that
        # que l'interface ne laisse pas croire qu'il reste actif.
        if not self._floor_auto_var.get() and pf.get("auto_push"):
            pf["auto_push"] = False
            if hasattr(self, "_floor_push_var"):
                self._floor_push_var.set(False)
        cfg.save(self.app.config)

    def _floor_save_push(self):
        """Enable/disable the REAL sending of corrections to the Channel Manager.

        Separate from monitoring (G2-1 audit): detection is risk-free,
        sending changes the prices actually on sale. Activation is protected by
        an explicit confirmation — and refused if monitoring is off,
        since nothing would trigger the check.
        """
        pf = self.app.config.setdefault("price_floors", {})
        if self._floor_push_var.get():
            if not self._floor_auto_var.get():
                messagebox.showwarning(
                    tr_("Floor/ceiling protection"),
                    tr_("First activate “Automatic Monitoring on Scan”.\n\nWithout it, no control is carried out: automatic sending would never be triggered."),
                    parent=self.app.root)
                self._floor_push_var.set(False)
                return
            if not messagebox.askyesno(
                    tr_("Automatic sending to Channel Manager"),
                    tr_("⚠ This option modifies your REAL SALE PRICES.\n\nWith each scan, any price detected below the floor or above the ceiling will be corrected automatically and sent to the Channel Manager, without confirmation.\n\nOnly activate this after having verified, on several scans, that the alerts received are correct.\n\nEnable auto-send?"),
                    parent=self.app.root):
                self._floor_push_var.set(False)
                return
        pf["auto_push"] = self._floor_push_var.get()
        cfg.save(self.app.config)
        try:
            self.app._log_journal(
                tr_("🛡️ Floor/ceiling protection: automatic sending to Channel Manager {etat}.").format(
                        etat=tr_("ENABLED") if pf["auto_push"] else tr_("disabled")),
                level="warning" if pf["auto_push"] else "info",
                engine="FLOOR_AUTO")
        except Exception:
            pass

    def _floor_check_violations(self):
        for w in self._floor_viol_frame.winfo_children():
            w.destroy()
        self._floor_status_lbl.config(text=tr_("Analysis in progress…"), fg=T.YELLOW)
        self.app.root.update_idletasks()

        strat    = self.app.config.get("strategy", {})
        floors   = strat.get("floors", {})
        ceilings = strat.get("ceilings", {})
        if not floors and not ceilings:
            self._floor_status_lbl.config(text=tr_("No defined floor or ceiling."), fg=T.ORANGE)
            return

        try:
            from business.database import init_db, query_scans
            self._ensure_db_init()
            scans = query_scans(days=3, limit=2000)
        except Exception as e:
            self._floor_status_lbl.config(text=tr_("Database error: {e}").format(e=e), fg=T.RED)
            return

        violations = []
        for s in scans:
            if s.get("status") != "OK" or not s.get("price") or not s.get("room_type"):
                continue
            room  = s["room_type"]
            price = float(s["price"])
            fl    = floors.get(room)
            cel   = ceilings.get(room)

            if fl and price < fl:
                violations.append({
                    "kind":    "floor",
                    "room":    room,
                    "ota":     s.get("source", "OTA"),
                    "type":    "—",
                    "rate":    0,
                    "scraped": price,
                    "net":     round(price),
                    "limit":   fl,
                    "needed":  fl,
                })

            if cel and price > cel:
                violations.append({
                    "kind":    "ceiling",
                    "room":    room,
                    "ota":     s.get("source", "OTA"),
                    "type":    "—",
                    "rate":    0,
                    "scraped": price,
                    "net":     round(price),
                    "limit":   cel,
                    "needed":  cel,
                })

        # Deduplicate — floor: keep worst per room+ota, ceiling: keep worst per room
        seen = {}
        for v in violations:
            if v["kind"] == "floor":
                k = ("floor", v["room"], v["ota"])
                if k not in seen or v["net"] < seen[k]["net"]:
                    seen[k] = v
            else:
                k = ("ceiling", v["room"])
                if k not in seen or v["scraped"] > seen[k]["scraped"]:
                    seen[k] = v
        violations = list(seen.values())

        if not violations:
            self._floor_status_lbl.config(text=tr_("✓ No violations detected (last 3 days)."), fg=T.GREEN)
            lbl(self._floor_viol_frame,
                "✓ All scraped prices respect the defined floors and ceilings.",
                color=T.GREEN).pack(pady=8)
            return

        nb_floor   = sum(1 for v in violations if v["kind"] == "floor")
        nb_ceiling = sum(1 for v in violations if v["kind"] == "ceiling")
        parts = []
        if nb_floor:   parts.append(tr_("{n} violated floor(s)").format(n=nb_floor))
        if nb_ceiling: parts.append(tr_("{n} ceiling(s) violated").format(n=nb_ceiling))
        self._floor_status_lbl.config(text=f"⚠ {' · '.join(parts)} !", fg=T.RED)
        lbl(self._floor_viol_frame, tr_("⚠ {n} violation(s) detected:").format(n=len(violations)),
            bold=True, color=T.RED).pack(anchor="w", pady=(6, 4))

        for v in violations:
            is_floor = v["kind"] == "floor"
            border   = T.RED if is_floor else T.ORANGE
            icon     = "🚨" if is_floor else "🔺"
            card = tk.Frame(self._floor_viol_frame, bg=T.ENTRY_BG, padx=10, pady=8,
                            highlightthickness=1, highlightbackground=border)
            card.pack(fill="x", pady=3)

            if is_floor:
                title = f"{icon}  {v['room']}  ·  {v['ota']} ({v['type']} -{v['rate']}%)  — TOO LOW"
                detail = (f"Scraped price: {self._csym}{v['scraped']:,.0f}  →  guest net: {self._csym}{v['net']:,.0f}  "
                          f"|  Floor: {self._csym}{v['limit']:,.0f}  |  Shortfall: {self._csym}{v['limit']-v['net']:,.0f}")
                tip = f"💡 Send to CM ≥ {self._csym}{v['needed']:,.0f}  (floor, OTA discount applied to the shipment)"
                btn_txt = "↑ Raise the rate"
            else:
                title = f"{icon}  {v['room']}  ·  {v['ota']}  — TOO HIGH"
                detail = (f"Scraped price: {self._csym}{v['scraped']:,.0f}  |  Ceiling: {self._csym}{v['limit']:,.0f}  "
                          f"|  Excess: {self._csym}{v['scraped']-v['limit']:,.0f}")
                tip = f"💡 Send {self._csym}{v['needed']:,.0f} to the CM  (= ceiling directly)"
                btn_txt = "↓ Baisser le tarif"

            tk.Label(card, text=title, bg=T.ENTRY_BG, fg=border,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w")
            tk.Label(card, text=detail, bg=T.ENTRY_BG, fg=T.FG,
                     font=("Segoe UI", 9)).pack(anchor="w", pady=(4, 2))
            tk.Label(card, text=tip, bg=T.ENTRY_BG, fg=T.YELLOW,
                     font=("Segoe UI", 9)).pack(anchor="w")

            def do_correct(viol=v):
                self._floor_apply_one_correction(viol)
            btn(card, btn_txt, do_correct, color=border, width=18).pack(anchor="w", pady=(6, 0))

        if len(violations) > 1:
            btn(self._floor_viol_frame, tr_("Correct all ({n})").format(n=len(violations)),
                lambda vl=violations: self._floor_apply_all_corrections(vl),
                color=T.RED, width=22).pack(anchor="w", pady=(8, 0))

    def _floor_push_correction(self, violations_list):
        # Couture E4 : routeur de transport (API CM ou Extranet Direct)
        from extranet_bridge import push_rates as push_rates_to_cm_by_ota
        cm_cfg    = self.app.config.get("channel_manager", {})
        rooms_cfg = self.app.config.get("room_inventory", {})

        # For floor violations: pick highest "needed" per room (most protective)
        # For ceiling violations: pick lowest "needed" per room (most restrictive)
        by_room_floor   = {}
        by_room_ceiling = {}
        for v in violations_list:
            room = v["room"]
            if v["kind"] == "floor":
                if room not in by_room_floor or v["needed"] > by_room_floor[room]["needed"]:
                    by_room_floor[room] = v
            else:
                if room not in by_room_ceiling or v["needed"] < by_room_ceiling[room]["needed"]:
                    by_room_ceiling[room] = v

        # Merge: for same room, take max(floor_needed, ceiling_needed) but warn if conflict
        final = {}
        for room, v in by_room_floor.items():
            final[room] = {"needed": v["needed"], "v": v, "kind": "floor"}
        for room, v in by_room_ceiling.items():
            if room in final:
                # Both floor and ceiling violation — take floor (safer, protect revenue)
                final[room]["note"] = f"ceiling too at {self._csym}{v['needed']:,.0f}"
            else:
                final[room] = {"needed": v["needed"], "v": v, "kind": "ceiling"}

        cm_mapping = cm_cfg.get("room_mapping", {})
        pushes  = []
        skipped = []
        for room, data in final.items():
            m  = cm_mapping.get(room, {})
            rc = (m.get("room_code", "").strip() if isinstance(m, dict) else str(m).strip())
            if not rc:
                skipped.append(room)
                continue
            rate_plans_cfg = m.get("rate_plans", []) if isinstance(m, dict) else []
            if rate_plans_cfg:
                for plan in rate_plans_cfg:
                    rp  = (plan.get("rate_plan_code", "") or "1").strip()
                    ocp = str(plan.get("ota_code", "")).strip()
                    # Apply OTA discount reverse: push = needed / (1 − disc%)
                    # so the OTA displays exactly the floor/ceiling price.
                    try:
                        _disc = float(plan.get("ota_discount_pct", 0) or 0)
                    except (ValueError, TypeError):
                        _disc = 0.0
                    _needed = float(data["needed"])
                    if 0 < _disc < 100:
                        _push_price = round(_needed / (1.0 - _disc / 100.0))
                    else:
                        _push_price = round(_needed)
                    p   = {"room_code": rc, "rate_plan_code": rp,
                           "price": _push_price,
                           "_room": room, "_data": data}
                    if ocp:
                        p["ota_code"] = ocp
                    pushes.append(p)
            else:
                rp = ((m.get("rate_plan_code", "") or "1").strip()
                      if isinstance(m, dict) else "1")
                try:
                    _disc = float(m.get("ota_discount_pct", 0) or 0) \
                        if isinstance(m, dict) else 0.0
                except (ValueError, TypeError):
                    _disc = 0.0
                _needed = float(data["needed"])
                if 0 < _disc < 100:
                    _push_price = round(_needed / (1.0 - _disc / 100.0))
                else:
                    _push_price = round(_needed)
                pushes.append({"room_code": rc, "rate_plan_code": rp,
                               "price": _push_price,
                               "_room": room, "_data": data})

        def _task():
            results = []
            if pushes:
                clean_pushes = [{"room_code": p["room_code"], "rate_plan_code": p["rate_plan_code"],
                                 "price": p["price"], "ota_code": p.get("ota_code", "")}
                                for p in pushes]
                _cm_results = push_rates_to_cm_by_ota(cm_cfg, clean_pushes, log_cb=self.app._log_journal)
                _by_ota = {r["ota_code"]: r for r in _cm_results}
                for p in pushes:
                    v     = p["_data"]["v"]
                    kind  = p["_data"]["kind"]
                    note  = p["_data"].get("note", "")
                    ok    = _by_ota.get(p.get("ota_code", ""), {"ok": False})["ok"]
                    arrow = "↑" if kind == "floor" else "↓"
                    label = tr_("floor") if kind == "floor" else tr_("ceiling")
                    line  = f"{'✓' if ok else '✗'} {arrow}  {p['_room']}  →  {self._csym}{p['price']:,.0f}  ({label} {self._csym}{v['limit']:,.0f})"
                    if note:
                        line += f"  [{note}]"
                    results.append(line)

            def _ui():
                msg_parts = []
                if results:
                    msg_parts.append(tr_("Channel Manager sends:") + "\n" + "\n".join(results))
                if skipped:
                    msg_parts.append(
                        tr_("⚠ Missing CM codes (configured in Channel Manager → Inventory):") + "\n"
                        + "\n".join(f"  • {r}" for r in skipped)
                    )
                messagebox.showinfo(tr_("OTA fix"), "\n\n".join(msg_parts) if msg_parts else tr_("Nothing to send."),
                                    parent=self.app.root)
            self.app.root.after(0, _ui)

        threading.Thread(target=_task, daemon=True).start()

    def _floor_apply_one_correction(self, v):
        self._floor_push_correction([v])

    def _floor_apply_all_corrections(self, violations):
        self._floor_push_correction(violations)

    def _floor_auto_check_and_correct(self, alert_only=None):
        """Floor/ceiling check on today's scans.

        WIRED on 2026-07-22 (G2-1 audit) — until then it had NO
        caller: the "Automatic correction at scan" checkbox did not
        rien du tout.

        alert_only: True  → detects, logs and ALERTS (journal + email +
                             Telegram + phone), **without sending anything to the
                             Channel Manager**.
                     False → alerte ET envoie les corrections au CM.
                     None  → reads `price_floors.auto_push` (default **False**,
                             donc alerte seule).

        Deliberately cautious default: this function had never run,
        its behaviour is proven by no real usage. We first observe
        what it detects, then enable sending (`auto_push = true`).
        """
        if alert_only is None:
            alert_only = not self.app.config.get("price_floors", {}).get("auto_push", False)
        strat    = self.app.config.get("strategy", {})
        floors   = strat.get("floors", {})
        ceilings = strat.get("ceilings", {})
        if not floors and not ceilings:
            return
        try:
            from business.database import init_db, query_scans
            self._ensure_db_init()
            scans = query_scans(days=1, limit=500)
        except Exception as e:
            # Never fail in total silence: the automatic floor/
            # plafonds doit laisser une trace si elle ne peut pas tourner, sinon
            # the user believes they are protected while nothing is checked.
            try:
                self.app._log_journal(
                    f"❌ Correction auto plancher/plafond impossible (BDD) : {e}",
                    level="error", engine="FLOOR_AUTO")
            except Exception:
                pass
            return

        violations = {}
        for s in scans:
            if s.get("status") != "OK" or not s.get("price") or not s.get("room_type"):
                continue
            room  = s["room_type"]
            price = float(s["price"])
            fl    = floors.get(room)
            cel   = ceilings.get(room)

            if fl and price < fl:
                k = ("floor", room)
                if k not in violations or price < violations[k]["scraped"]:
                    violations[k] = {
                        "kind": "floor", "room": room, "ota": s.get("source", "OTA"),
                        "type": "—", "rate": 0, "scraped": price,
                        "net": round(price), "limit": fl, "needed": fl,
                    }

            if cel and price > cel:
                k = ("ceiling", room)
                if k not in violations or price > violations[k]["scraped"]:
                    violations[k] = {
                        "kind": "ceiling", "room": room, "ota": s.get("source", "OTA"),
                        "type": "—", "rate": 0, "scraped": price,
                        "net": round(price), "limit": cel, "needed": cel,
                    }

        if not violations:
            return

        viol_list = list(violations.values())
        # push_ok: None = nothing to send (no mapped room_code), True/False =
        # actual result of the send to the Channel Manager — never announce
        # "corrected" until confirmed True.
        push_ok  = None
        push_msg = ""

        # ── Journal + alerte multi-canaux (toujours, quel que soit le mode) ──
        for _v in viol_list:
            _sens = (tr_("under the floor") if _v["kind"] == "floor"
                     else tr_("above the ceiling"))
            try:
                self.app._log_journal(
                    tr_("🛡️ {room} ({ota}) : {csym}{p} {sens} {csym}{lim}", csym=self._csym).format(
                        room=_v["room"], ota=_v["ota"], p=int(_v["scraped"]),
                        sens=_sens, lim=int(_v["limit"])),
                    level="warning", engine="FLOOR_AUTO")
            except Exception:
                pass
        try:
            # Alerte email + Telegram + TÉLÉPHONE (app compagnon).
            # `triggers` is forced: it is the "Automatic correction at
            # scan » qui fait office d'autorisation — l'alerte ne doit pas
            # additionally depend on a trigger not configured in Settings.
            from business.notifications import send_notifications
            send_notifications("floor_violation", violations, self.app.config,
                               triggers={"floor_violation": True})
        except Exception:
            logging.exception("Floor/ceiling alert: send failed")

        if alert_only:
            self._push_alert(
                "vae", "floor_violation",
                tr_("🛡️ {n} price outside limits detected — alert only, nothing sent to CM").format(n=len(viol_list)),
                priority="high",
                data={"violations": len(viol_list)})
            return

        def _task():
            push_ok  = None
            push_msg = ""
            try:
                # Couture E4 : routeur de transport (API CM ou Extranet Direct)
                from extranet_bridge import push_rates as push_rates_to_cm_by_ota
                cm_cfg     = self.app.config.get("channel_manager", {})
                cm_mapping = cm_cfg.get("room_mapping", {})
                by_room = {}
                for v in viol_list:
                    room = v["room"]
                    if room not in by_room:
                        by_room[room] = v
                    elif v["kind"] == "floor" and v["needed"] > by_room[room]["needed"]:
                        by_room[room] = v
                pushes = []
                for room, v in by_room.items():
                    m  = cm_mapping.get(room, {})
                    rc = (m.get("room_code", "").strip() if isinstance(m, dict) else str(m).strip())
                    if not rc:
                        continue
                    rate_plans_cfg = m.get("rate_plans", []) if isinstance(m, dict) else []
                    if rate_plans_cfg:
                        for plan in rate_plans_cfg:
                            rp  = (plan.get("rate_plan_code", "") or "1").strip()
                            ocp = str(plan.get("ota_code", "")).strip()
                            p   = {"room_code": rc, "rate_plan_code": rp, "price": float(v["needed"])}
                            if ocp:
                                p["ota_code"] = ocp
                            pushes.append(p)
                    else:
                        rp = ((m.get("rate_plan_code", "") or "1").strip()
                              if isinstance(m, dict) else "1")
                        pushes.append({"room_code": rc, "rate_plan_code": rp,
                                       "price": float(v["needed"])})
                if pushes:
                    _cm_results = push_rates_to_cm_by_ota(cm_cfg, pushes, log_cb=self.app._log_journal)
                    push_ok  = all(r["ok"] for r in _cm_results) if _cm_results else False
                    push_msg = " | ".join(
                        f"{'✅' if r['ok'] else '✗'} {r['ota_code'] or 'toutes OTA'} : {r['msg']}"
                        for r in _cm_results)
            except Exception as e:
                push_ok, push_msg = False, str(e)

            nb_floor   = sum(1 for v in viol_list if v["kind"] == "floor")
            nb_ceiling = sum(1 for v in viol_list if v["kind"] == "ceiling")
            parts = []
            if nb_floor:   parts.append(f"↑{nb_floor} plancher")
            if nb_ceiling: parts.append(f"↓{nb_ceiling} plafond")

            if push_ok:
                self._push_alert(
                    "vae", "floor_correction",
                    f"🛡️ OTA prices corrected ({', '.join(parts)})",
                    priority="medium",
                    data={"floor": nb_floor, "ceiling": nb_ceiling},
                )
            elif push_ok is False:
                # The send to the Channel Manager really failed (or raised an
                # exception) — never announce "corrected" in that case, otherwise
                # the hotel believes the floor/ceiling was applied while the price
                # sent to the CM was never confirmed.
                self._push_alert(
                    "vae", "floor_correction_failed",
                    f"❌ OTA correction failed ({', '.join(parts)}) — {push_msg}",
                    priority="high",
                    data={"floor": nb_floor, "ceiling": nb_ceiling},
                )

        threading.Thread(target=_task, daemon=True).start()

    # ══════════════════════════════════════════════════════════════════════
    # Section Prix par OTA — Channel Manager (envoi manuel)
    # ══════════════════════════════════════════════════════════════════════

    def _build_cm_ota_section(self, parent):
        """Merged section Per-OTA prices + Automatic update:
        floor/ceiling thresholds, trigger, fixed time, period → CM push."""

        cm_cfg     = self.app.config.get("channel_manager", {})
        mapping    = cm_cfg.get("room_mapping", {})
        rooms_cfg  = self.app.config.get("room_inventory", {})
        room_types = [r for r in self.app.config.get("room_types", [])
                      if r and r.lower() != "move room"]

        # Collecter toutes les OTAs (sauf Agoda) depuis le mapping CM.
        # Also build a name-lower → (name, code) index for
        # matching with the OTAs monitored in OTA Watch.
        seen_otas      = {}                       # ota_name -> ota_code
        _rp_by_name_lc = {}                       # name_lower → (name, code)
        for rm_data in mapping.values():
            if isinstance(rm_data, dict):
                for rp in rm_data.get("rate_plans", []):
                    name = rp.get("ota_name", "").strip()
                    code = str(rp.get("ota_code", "")).strip()
                    if name and code and name.lower() != "agoda":
                        seen_otas[name] = code
                    if name:
                        _lc = name.lower()
                        if _lc != "agoda" and _lc not in _rp_by_name_lc:
                            _rp_by_name_lc[_lc] = (name, code)

        # Synchroniser avec les OTAs actives de OTA Watch : une OTA
        # monitored in Brave must also appear here so that
        # the user can set its price / thresholds — even if the
        # matching rate_plan has no ota_code filled yet.
        _ota_watch_cfg = self.app.config.get("ota_watch", {})
        for _o in _ota_watch_cfg.get("otas", []):
            if not _o.get("active", True):
                continue
            _on = (_o.get("name") or "").strip()
            if not _on or _on.lower() == "agoda":
                continue
            if _on in seen_otas:
                continue
            # Case-insensitive matching with the rate_plans
            _match = _rp_by_name_lc.get(_on.lower())
            if _match:
                seen_otas[_match[0]] = _match[1]
            elif _on not in seen_otas:
                seen_otas[_on] = ""  # card displayed, code looked up at push time

        if not seen_otas or not room_types:
            return

        ota_prices_cfg = self.app.config.setdefault("cm_ota_prices", {})

        tk.Frame(parent, bg=T.SEL_BG, height=2).pack(fill="x", padx=10, pady=(16, 10))

        s = section(parent, tr_("📡 Price per OTA — Channel Manager"))
        s.pack(fill="x", padx=10, pady=6)
        lbl(s,
            "Set the per-room prices and thresholds for each OTA. "
            "OTA Guard applies floor/ceiling corrections before sending to the CM.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 2))
        lbl(s,
            "Goes through your Channel Manager (one single connection) which then "
            "redistributes to the OTAs — different from \"OTA Direct Push\" which "
            "talks directly to each OTA without going through the CM.",
            color="#888888", size=9).pack(anchor="w", pady=(0, 8))

        self._cm_ota_vars = {}
        # Literals passed directly to tr_() — needed so that
        # tools/i18n_extract.py discovers these strings (the dropdown
        # affiche le texte traduit, mais la sauvegarde compare toujours
        # to the canonical keys "manual"/"daily_once").
        _TRIG_DISP_INV = {"manual":     tr_("Manual — I click myself"),
                          "daily_once": tr_("Once a day at a fixed time")}
        _TRIG_DISP = [_TRIG_DISP_INV["manual"], _TRIG_DISP_INV["daily_once"]]
        _TRIG_KEY  = {v: k for k, v in _TRIG_DISP_INV.items()}

        for ota_name, ota_code in sorted(seen_otas.items()):
            ota_cfg = ota_prices_cfg.setdefault(ota_name, {
                "ota_code": ota_code, "rooms": {}})
            ota_cfg["ota_code"] = ota_code

            # ── Carte OTA ──────────────────────────────────────────────
            card = tk.Frame(s, bg=T.SEL_BG, padx=10, pady=8,
                            highlightthickness=1, highlightbackground=T.ACCENT)
            card.pack(fill="x", pady=4)

            # ── Header ─────────────────────────────────────────────────
            h = tk.Frame(card, bg=T.SEL_BG); h.pack(fill="x", pady=(0, 6))
            _en_v = tk.BooleanVar(value=ota_cfg.get("enabled", False))
            _tag  = status_badge(
                h,
                tr_("✅ ACTIVE") if _en_v.get() else tr_("⏸ INACTIVE"),
                T.GREEN if _en_v.get() else "#888888")
            tk.Checkbutton(h, variable=_en_v, bg=T.SEL_BG,
                           activebackground=T.SEL_BG,
                           selectcolor=T.SEL_BG).pack(side="left")
            lbl(h, ota_name, bold=True, size=10, bg=T.SEL_BG).pack(side="left")
            _tag.pack(side="left", padx=8)
            lbl(h, tr_("CM code: {code}").format(code=ota_code), color="#888888", size=8,
                bg=T.SEL_BG).pack(side="left", padx=(4, 0))

            def _make_toggle(tl, bv):
                def _cb(*_):
                    tl.config(text=tr_("✅ ACTIVE") if bv.get() else tr_("⏸ INACTIVE"),
                              bg=T.GREEN if bv.get() else "#888888",
                              fg=_btn_fg(T.GREEN if bv.get() else "#888888"))
                return _cb
            _en_v.trace_add("write", _make_toggle(_tag, _en_v))

            result_lbl = tk.Label(h, text="", bg=T.SEL_BG, fg=T.GREEN,
                                  font=("Segoe UI", 9))
            result_lbl.pack(side="right", padx=(8, 4))
            btn(h, tr_("📤 Push"),
                lambda _on=ota_name, _oc=ota_code:
                    self._send_cm_ota_prices(
                        _on, _oc,
                        self._cm_ota_vars.get(_on, {}).get("rooms", {}),
                        self._cm_ota_vars.get(_on, {}).get("result_lbl")),
                color="#cba6f7", width=10).pack(side="right")

            # ── Tableau prix/seuils (grid pleine largeur) ───────────────
            table_f = tk.Frame(card, bg=T.SEL_BG)
            table_f.pack(fill="x", pady=(0, 6))
            table_f.columnconfigure(0, weight=4)
            table_f.columnconfigure(1, weight=2)
            table_f.columnconfigure(2, weight=2)
            table_f.columnconfigure(3, weight=2)
            table_f.columnconfigure(4, weight=3)

            for c, txt in enumerate(["Chambre", f"Plancher {self._csym}",
                                     f"Prix {self._csym}", f"Plafond {self._csym}", "Dernier envoi"]):
                tk.Label(table_f, text=txt, bg=T.BG, fg=T.ACCENT,
                         font=("Segoe UI", 9, "bold"), anchor="center"
                         ).grid(row=0, column=c, sticky="ew", padx=2, pady=(0, 3))

            room_vars = {}
            for ridx, room in enumerate(room_types, start=1):
                room_cfg  = ota_cfg["rooms"].setdefault(room, {})
                inv       = rooms_cfg.get(room, {})
                floor_d   = float(room_cfg.get("floor",   inv.get("floor",   0)))
                ceil_d    = float(room_cfg.get("ceiling", inv.get("ceiling", 999999)))
                last_s    = room_cfg.get("last_sent", "")
                price_d   = room_cfg.get("price", "")

                floor_v   = tk.StringVar(value=str(int(floor_d)) if floor_d else "")
                current_v = tk.StringVar(
                    value=str(int(float(price_d))) if price_d else "")
                ceiling_v = tk.StringVar(
                    value=str(int(ceil_d)) if ceil_d < 999999 else "")

                tk.Label(table_f, text=room, bg=T.SEL_BG, fg=T.FG,
                         font=("Segoe UI", 9), anchor="w"
                         ).grid(row=ridx, column=0, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=floor_v, bg=T.ENTRY_BG,
                         fg=T.GREEN, relief="flat", font=("Segoe UI", 9)
                         ).grid(row=ridx, column=1, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=current_v, bg=T.ENTRY_BG,
                         fg=T.ACCENT, relief="flat",
                         font=("Segoe UI", 9, "bold")
                         ).grid(row=ridx, column=2, sticky="ew", padx=2, pady=1)
                tk.Entry(table_f, textvariable=ceiling_v, bg=T.ENTRY_BG,
                         fg="#e06c75", relief="flat", font=("Segoe UI", 9)
                         ).grid(row=ridx, column=3, sticky="ew", padx=2, pady=1)
                st = tk.Label(table_f, text=fmt_dt(last_s) if last_s else "—",
                              bg=T.SEL_BG, fg="#888888",
                              font=("Segoe UI", 8), anchor="w")
                st.grid(row=ridx, column=4, sticky="ew", padx=2, pady=1)
                room_vars[room] = {"floor": floor_v, "current": current_v,
                                   "ceiling": ceiling_v, "status": st}

            # ── Trigger + Heure ─────────────────────────────────────────
            _tr_row = tk.Frame(card, bg=T.SEL_BG)
            _tr_row.pack(fill="x", pady=(4, 2))
            _tr_row.columnconfigure(1, weight=1)
            tk.Label(_tr_row, text=tr_("Trigger:"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).grid(row=0, column=0, sticky="w", padx=(0, 8))
            _trf = tk.Frame(_tr_row, bg=T.SEL_BG)
            _trf.columnconfigure(0, weight=1)
            _trf.grid(row=0, column=1, sticky="ew")
            _trig_v = tk.StringVar(
                value=_TRIG_DISP_INV.get(ota_cfg.get("trigger", "manual"),
                                          _TRIG_DISP_INV["manual"]))
            ttk.Combobox(_trf, textvariable=_trig_v,
                         values=_TRIG_DISP, state="readonly"
                         ).grid(row=0, column=0, sticky="ew", padx=(0, 12))
            tk.Label(_trf, text=tr_("Hour :"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).grid(row=0, column=1, sticky="w", padx=(0, 6))
            _time_v = tk.StringVar(value=ota_cfg.get("time", "12:00"))
            tk.Entry(_trf, textvariable=_time_v, width=7,
                     bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                     font=("Segoe UI", 9)
                     ).grid(row=0, column=2, sticky="w")

            # ── Period: presets + free date ──────────────────────────
            _dt_row = tk.Frame(card, bg=T.SEL_BG)
            _dt_row.pack(fill="x", pady=(2, 6))
            tk.Label(_dt_row, text=tr_("Period :"), bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 9, "bold")
                     ).pack(side="left", padx=(0, 8))
            _date_v = tk.StringVar(value=fmt_dt(ota_cfg.get("date_to", ""), with_time=False))
            for _days, _lbl in [(3, "+3j"), (7, "+7j"), (15, "+15j"), (30, "+30j")]:
                def _set_date(d=_days, v=_date_v):
                    from datetime import timedelta as _tdd
                    v.set((datetime.now() + _tdd(days=d)).strftime("%d/%m/%Y"))
                tk.Button(_dt_row, text=_lbl, command=_set_date,
                          bg=T.SEL_BG, fg=T.ACCENT, relief="flat",
                          font=("Segoe UI", 9, "bold"),
                          cursor="hand2", bd=0, padx=6
                          ).pack(side="left", padx=2)
            tk.Label(_dt_row, text=tr_("Or"), bg=T.SEL_BG, fg="#888888",
                     font=("Segoe UI", 8)).pack(side="left", padx=8)
            tk.Entry(_dt_row, textvariable=_date_v, width=12,
                     bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                     font=("Segoe UI", 9)).pack(side="left")

            # ── Majoration jours ─────────────────────────────────────
            _wknd_row = tk.Frame(card, bg=T.SEL_BG)
            _wknd_row.pack(fill="x", pady=(2, 2))
            _wknd_en_v  = tk.BooleanVar(value=ota_cfg.get("weekend_markup_enabled", False))
            _wknd_pct_v = tk.StringVar(value=str(ota_cfg.get("weekend_markup_pct", 20)))
            tk.Checkbutton(_wknd_row, text=tr_("🗓️ Increase:"),
                           variable=_wknd_en_v,
                           bg=T.SEL_BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                           activebackground=T.SEL_BG,
                           font=("Segoe UI", 9)).pack(side="left", padx=(0, 4))
            _DAY_FR_OTA = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
            _saved_days_ota = ota_cfg.get("weekend_days", [4, 5])
            _wknd_days_v = []
            for _di, _dl in enumerate(_DAY_FR_OTA):
                _ddv = tk.BooleanVar(value=_di in _saved_days_ota)
                tk.Checkbutton(_wknd_row, text=_dl, variable=_ddv,
                               bg=T.SEL_BG, fg=T.FG, selectcolor=T.ENTRY_BG,
                               activebackground=T.SEL_BG,
                               font=("Segoe UI", 8)).pack(side="left", padx=(1, 0))
                _wknd_days_v.append(_ddv)
            lbl(_wknd_row, "  +", bold=True, size=9, bg=T.SEL_BG).pack(side="left", padx=(4, 2))
            tk.Spinbox(_wknd_row, textvariable=_wknd_pct_v,
                       from_=0, to=100, increment=5, width=5,
                       bg=T.ENTRY_BG, fg=T.FG, font=("Segoe UI", 9)
                       ).pack(side="left", padx=(0, 2))
            lbl(_wknd_row, "%", size=9, bg=T.SEL_BG).pack(side="left")

            # ── Bouton sauvegarder ──────────────────────────────────────
            btn_row = tk.Frame(card, bg=T.SEL_BG); btn_row.pack(fill="x", pady=(2, 0))
            btn(btn_row, tr_("💾 Save"),
                lambda _on=ota_name, _rv=room_vars, _rl=result_lbl,
                       _ev=_en_v, _tv=_trig_v, _tmv=_time_v, _dv=_date_v,
                       _km=_TRIG_KEY, _wen=_wknd_en_v, _wpct=_wknd_pct_v,
                       _wdays=_wknd_days_v:
                    self._save_cm_ota_floors(_on, _rv, _rl, _ev, _tv, _tmv, _dv, _km,
                                             _wen, _wpct, _wdays),
                color=T.ACCENT, width=16).pack(side="right", padx=4)

            self._cm_ota_vars[ota_name] = {
                "rooms":      room_vars,
                "result_lbl": result_lbl,
                "enabled":    _en_v,
                "trigger":    _trig_v,
                "time":       _time_v,
                "date":       _date_v,
                "wknd_en":    _wknd_en_v,
                "wknd_pct":   _wknd_pct_v,
                "wknd_days":  _wknd_days_v,
            }

    def _save_cm_ota_floors(self, ota_name, room_vars, result_lbl=None,
                             enabled_v=None, trigger_v=None, time_v=None,
                             date_v=None, trig_key_map=None,
                             wknd_en_v=None, wknd_pct_v=None, wknd_days_v=None):
        """Save thresholds + trigger/time/period into cm_ota_prices."""
        try:
            ota_data  = self.app.config.setdefault("cm_ota_prices", {}) \
                                       .setdefault(ota_name, {"rooms": {}})
            ota_rooms = ota_data.setdefault("rooms", {})
            saved  = []
            errors = []

            # ── Seuils et prix par chambre ──────────────────────────────
            for room, v in room_vars.items():
                try:
                    fl = float(v["floor"].get() or 0)
                    ce_raw = v["ceiling"].get().strip()
                    ce = float(ce_raw) if ce_raw else 999999
                    if fl > ce:
                        errors.append(f"{room}: plancher({int(fl)}) > plafond({int(ce)})")
                        continue
                    ota_rooms.setdefault(room, {})
                    ota_rooms[room]["floor"]   = fl
                    ota_rooms[room]["ceiling"] = ce
                    raw_price = v["current"].get().strip()
                    if raw_price:
                        ota_rooms[room]["price"] = float(raw_price)
                    saved.append(f"{room}: {int(fl)}–{int(ce)}")
                except Exception as e_room:
                    errors.append(f"{room}: {e_room}")

            # ── Trigger / time / period / enabled ─────────────────────
            if enabled_v is not None:
                ota_data["enabled"] = bool(enabled_v.get())
            if trigger_v is not None and trig_key_map is not None:
                ota_data["trigger"] = trig_key_map.get(
                    trigger_v.get(), "manual")
            if time_v is not None:
                ota_data["time"] = (time_v.get().strip() or "12:00")
            if date_v is not None:
                # Field displays d/m/y; consumers (fromisoformat, OTA URLs)
                # need ISO — normalize on save.
                ota_data["date_to"] = parse_dt_any(date_v.get().strip())
            if wknd_en_v is not None:
                ota_data["weekend_markup_enabled"] = bool(wknd_en_v.get())
            if wknd_pct_v is not None:
                try:
                    ota_data["weekend_markup_pct"] = max(0.0, float(
                        wknd_pct_v.get().replace(",", ".")))
                except Exception:
                    ota_data["weekend_markup_pct"] = 20.0
            if wknd_days_v is not None:
                ota_data["weekend_days"] = [
                    i for i, v in enumerate(wknd_days_v) if v.get()]

            cfg.save(self.app.config)

            msg_parts = []
            if saved:
                msg_parts.append("✅ Thresholds saved")
            if errors:
                msg_parts.append("⚠ " + " | ".join(errors))
            final_msg = " | ".join(msg_parts) if msg_parts else "✅ OK"

            if result_lbl:
                result_lbl.config(
                    text=final_msg,
                    fg=T.GREEN if not errors else T.ORANGE)
                if not errors:
                    self.app.root.after(4000, lambda: result_lbl.config(text=""))

        except Exception as e_save:
            from tkinter import messagebox as _mb
            _mb.showerror("Erreur sauvegarde",
                          f"OTA : {ota_name}\nErreur : {e_save}")
            if result_lbl:
                result_lbl.config(text=f"❌ {e_save}", fg=T.RED)

    def _send_cm_ota_prices(self, ota_name, ota_code, room_vars, result_lbl):
        """Sends the prices entered for one OTA to the CM (with OTACode).

        D126: goes through the transport ROUTER (extranet_bridge.push_rates).
        The previous direct CM API call came back "UnAuthorized Data"
        (13/10 20:37, Roibos) while the browser transport is the working
        one in this setup. Same fix pattern as the seasonal push (D57):
        the router follows the configured transport (API or Extranet
        Direct) and owns the D52 operation lock, the anti-parallel-push
        lock, the pause guard and the queue progress."""
        try:
            from business.app_logger import app_log as _alog
        except Exception:
            _alog = lambda *a, **k: None

        cm_cfg = self.app.config.get("channel_manager", {})
        _transport = ("extranet-direct"
                      if (cm_cfg.get("extranet_direct") or {}).get("enabled")
                      else "cm-api")
        _alog(f"[CM-OTA] Starting send OTA={ota_name} code={ota_code} "
              f"transport={_transport} "
              f"hotel={cm_cfg.get('hotel_id','?')} "
              f"test_mode={cm_cfg.get('test_mode', False)}",
              level="info", engine="CM-OTA")
        mapping = cm_cfg.get("room_mapping", {})
        pushes  = []
        skipped = []
        warnings = []

        for room, v in room_vars.items():
            raw = v["current"].get().strip()
            if not raw:
                skipped.append(room)
                continue
            try:
                price = float(raw.replace(",", ".").replace(" ", ""))
            except ValueError:
                skipped.append(room)
                continue

            # Floor / ceiling are informational bounds only in this
            # section — the user explicitly sets the price to send.
            # No clamping: send the Price column value as-is.
            try:
                floor   = float(v["floor"].get())
                ceiling = float(v["ceiling"].get())
            except (ValueError, TypeError):
                floor, ceiling = 0, 999999

            if floor and price < floor:
                warnings.append(f"{room} < {self._csym}{int(floor)} (plancher)")
            if ceiling < 999999 and price > ceiling:
                warnings.append(f"{room} > {self._csym}{int(ceiling)} (plafond)")

            rm = mapping.get(room, {})
            if not isinstance(rm, dict):
                skipped.append(room)
                continue
            rc = rm.get("room_code", "").strip()
            if not rc:
                skipped.append(room)
                continue
            # Trouver rate_plan_code pour cet OTA code
            rp = next((p.get("rate_plan_code", "")
                       for p in rm.get("rate_plans", [])
                       if str(p.get("ota_code", "")) == str(ota_code)), "")
            if not rp:
                rp = next((p.get("rate_plan_code", "")
                           for p in rm.get("rate_plans", [])), "3628")

            pushes.append({"room_code": rc, "rate_plan_code": rp,
                           "ota_code": ota_code, "price": price, "_room": room})

        if not pushes:
            result_lbl.config(text=tr_("⚠ No price entered."), fg=T.ORANGE)
            return

        result_lbl.config(text=tr_("⏳ Sending in progress…"), fg=T.YELLOW)

        # Lire majoration weekend depuis l'UI (avant le thread)
        _ota_ui   = self._cm_ota_vars.get(ota_name, {})
        _wknd_var = _ota_ui.get("wknd_en")
        _wknd_en  = bool(_wknd_var.get()) if _wknd_var is not None else False
        _wpct_var = _ota_ui.get("wknd_pct")
        try:
            _wknd_pct = float(_wpct_var.get().replace(",", ".")) if _wpct_var else 20.0
        except Exception:
            _wknd_pct = 20.0
        _wdays_list = _ota_ui.get("wknd_days") or []
        _wknd_days  = [i for i, v in enumerate(_wdays_list) if v.get()] if _wdays_list else [4, 5]

        def _task():
            clean = [{"room_code": p["room_code"],
                      "room_label": p["_room"],
                      "rate_plan_code": p["rate_plan_code"],
                      "ota_code": p["ota_code"],
                      "price":    p["price"]} for p in pushes]
            results = []
            try:
                # Compute nights from the configured end date
                _date_to_str = (self.app.config
                                .get("cm_ota_prices", {})
                                .get(ota_name, {})
                                .get("date_to", ""))
                try:
                    if _date_to_str:
                        _nights = max(1, (
                            datetime.fromisoformat(_date_to_str) - datetime.now()
                        ).days)
                    else:
                        _nights = 90
                except Exception:
                    _nights = 90
                # Apply weekend markup + skip locked dates
                _today = datetime.now().date().isoformat()
                try:
                    from business.price_calendar import get_locked_dates
                    _cal_locked = get_locked_dates(self.app.config, _today, _nights)
                except Exception:
                    _cal_locked = set()

                if _wknd_en or _cal_locked:
                    from business.channel_manager import segments_skipping_locked as _ssl
                    _wknd_cfg = {"enabled": _wknd_en, "pct": _wknd_pct,
                                 "weekend_days": _wknd_days}
                    _expanded = []
                    for _e in clean:
                        for _fd, _td, _pr in _ssl(
                                _e["price"], _today, _nights,
                                _cal_locked, _wknd_cfg):
                            _expanded.append({**_e, "price": _pr,
                                              "from_date": _fd, "to_date": _td})
                    if _expanded:
                        clean = _expanded

                # D126: transport ROUTER — API or Extranet Direct as
                # configured (same contract as the seasonal push D57).
                # Never a direct CM API call here anymore: this button
                # was dead while the CM API answers "UnAuthorized Data".
                import extranet_bridge as _xb

                def _prog(done, total, label):
                    try:
                        self.app.root.after(
                            0, lambda: self.app._push_progress(done, total, label))
                    except Exception:
                        pass

                try:
                    results = _xb.push_rates(
                        cm_cfg, clean,
                        checkin=_today, nights=_nights,
                        log_cb=self.app._log_journal, progress_cb=_prog)
                except Exception as _e:
                    _alog(f"[CM-OTA] EXCEPTION : {_e}", level="error", engine="CM-OTA")
                    results = [{"ota_code": ota_code, "ok": False,
                                "msg": str(_e), "n": len(clean), "sent": 0}]
                ok  = bool(results) and all(r.get("ok") for r in results)
                msg = " | ".join(
                    f"{r.get('ota_code') or 'all OTAs'}: {r.get('msg')}"
                    for r in results) if results else "No response"
                _alog(f"[CM-OTA] Response: ok={ok}  msg={msg[:300]}",
                      level="ok" if ok else "error", engine="CM-OTA")
            except Exception as _e:
                _alog(f"[CM-OTA] EXCEPTION : {_e}", level="error", engine="CM-OTA")
                ok, msg = False, str(_e)
                results = []

            now    = datetime.now().strftime("%d/%m %H:%M")

            # self.app.config is shared with the main thread (other
            # saves may happen in parallel) — mutating + cfg.save() here,
            # in the background thread, was exposed to a race with the
            # copy.deepcopy() interne de core/config.py::save(). On marshale
            # sur le thread principal via after(), comme _cm_record_push
            # dans app_core.py.
            def _persist():
                ota_rooms = self.app.config.setdefault(
                    "cm_ota_prices", {}).setdefault(ota_name, {}).setdefault("rooms", {})
                for p in pushes:
                    ota_rooms.setdefault(p["_room"], {})["last_sent"] = \
                        f"{self._csym}{int(p['price']):,} — {now}"
                cfg.save(self.app.config)
            self.app.root.after(0, _persist)

            def _update():
                for p in pushes:
                    room_vars[p["_room"]]["status"].config(
                        text=f"{self._csym}{int(p['price']):,} {now}",
                        fg=T.GREEN if ok else T.RED)
                parts = [f"✅ {len(pushes)} room(s)" if ok else f"❌ {msg[:80]}"]
                if warnings:
                    parts.append(f"ℹ {', '.join(warnings)}")
                result_lbl.config(text=" | ".join(parts),
                                  fg=T.GREEN if ok else T.RED)
                # D126: the shipment shows in "Latest submissions" like
                # every other send — per-OTA verdict and real sent count
                # (D42/D77), recorded on the main thread by the app.
                try:
                    _rooms_sent = {p["_room"]: p["price"] for p in pushes}
                    _per_ota = {}
                    for _r in (results or []):
                        _oc = str(_r.get("ota_code") or ota_code)
                        _per_ota[_oc] = {"name": ota_name,
                                         "rooms": _rooms_sent,
                                         "ok": bool(_r.get("ok")),
                                         "sent": int(_r.get("sent") or 0)}
                    _sent = sum(int(_r.get("sent") or 0) for _r in (results or []))
                    self.app._cm_record_push(
                        _rooms_sent, ota_name, ok, msg,
                        per_ota=_per_ota, sent_count=_sent)
                except Exception:
                    pass
                try:
                    self._cm_refresh_history()
                except Exception:
                    pass
            self.app.root.after(0, _update)

        threading.Thread(target=_task, daemon=True).start()








