"""
Entry point — OTA Guard.
"""
import sys
import logging
from pathlib import Path

BASE_DIR = Path(__file__).parent

# Diagnostic mode runs before normal logging and the activity journal.
# Signed patches still load, but the diagnostic must not deliver YAML files.
if "--diagnostic" in sys.argv:
    from diagnostic.startup import run as _run_diagnostic
    sys.exit(_run_diagnostic())

from core.paths import DATA_DIR
DATA_DIR.mkdir(parents=True, exist_ok=True)

import os as _os
_DEBUG_MODE = _os.environ.get("OTA_DEBUG", "0") == "1"
_LOG_LEVEL  = logging.DEBUG if _DEBUG_MODE else logging.INFO

LOG_PATH = DATA_DIR / "ota_guard.log"
_log_fmt = "%(asctime)s [%(levelname)-8s] %(name)s — %(message)s"

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

logging.basicConfig(
    level=_LOG_LEVEL,
    format=_log_fmt,
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8", mode="a"),
        logging.StreamHandler(sys.stdout),
    ],
    force=True,
)
if _DEBUG_MODE:
    # Separate timestamped debug file to keep the full session
    import datetime as _dt
    _dbg_path = DATA_DIR / f"debug_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    _dbg_h = logging.FileHandler(_dbg_path, encoding="utf-8", mode="w")
    _dbg_h.setLevel(logging.DEBUG)
    _dbg_h.setFormatter(logging.Formatter(_log_fmt, datefmt="%Y-%m-%d %H:%M:%S"))
    logging.getLogger().addHandler(_dbg_h)
    logging.debug("=== DEBUG MODE ACTIVE — file: %s ===", _dbg_path)
for _lib in ("matplotlib", "urllib3", "selenium", "PIL", "asyncio"):
    logging.getLogger(_lib).setLevel(logging.WARNING)

# ── Full session traceability (activity_log.txt (software root)) ──────────────────
# Captures EVERYTHING: UI interactions, internal actions, and above all hidden
# failures (DEBUG, thread exceptions, Tkinter callbacks). Must be initialized
# as early as possible.
try:
    from business.activity_log import init_activity_log
    init_activity_log()
except Exception:
    pass

# ── D91: black box — permanent flight recorder ───────────────────────────
# Captures logging + business journal app_log + unhandled crashes into
# data/blackbox/ (daily JSONL, 7-day retention). Silent failure:
# must never interfere with startup.
try:
    from diagnostic import recorder
    recorder.install()
except Exception:
    pass

logging.info("=" * 60)
logging.info("=== OTA Guard startup ===")
logging.info("=" * 60)


# ═════════════════════════════════════════════════════════════════════════
# License screen (shown when trial expired or license invalid)
# ═════════════════════════════════════════════════════════════════════════

def _show_license_screen(root, checker):
    """Blocking screen — returns True if the license was activated, False otherwise."""
    import tkinter as tk
    try:
        from core.utils import tr_
    except Exception:
        def tr_(s): return s

    BG       = "#1e1e2e"
    FG       = "#cdd6f4"
    ENTRY_BG = "#313244"
    SEL_BG   = "#45475a"
    ACCENT   = "#89b4fa"
    GREEN    = "#a6e3a1"
    RED      = "#f38ba8"
    ORANGE   = "#fab387"

    result = {"activated": False}

    root.title(tr_("🛡️ OTA Guard — License required"))
    root.configure(bg=BG)
    root.geometry("620x520")
    root.resizable(False, False)
    try:
        from pathlib import Path as _P_ico
        _ico = _P_ico(__file__).parent / "assets" / "icon.ico"
        if _ico.exists():
            root.iconbitmap(default=str(_ico))
    except Exception:
        pass

    # Center the window
    root.update_idletasks()
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    x = (sw - 620) // 2
    y = (sh - 520) // 2
    root.geometry(f"620x520+{x}+{y}")

    pad = tk.Frame(root, bg=BG, padx=40, pady=20)
    pad.pack(fill="both", expand=True)

    # Title
    tk.Label(pad, text="🛡️ OTA Guard", bg=BG, fg=ACCENT,
             font=("Segoe UI", 18, "bold")).pack(pady=(10, 4))

    # Status
    from licensing.license_checker import TRIAL_EXPIRED, LICENSE_EXPIRED, LICENSE_REVOKED
    st = checker.status
    if st == TRIAL_EXPIRED:
        msg = tr_("Your 15-day free trial period has ended.")
        col = ORANGE
    elif st == LICENSE_EXPIRED:
        exp = checker.info.get("expires", "?")
        msg = tr_("Your license expired on {date}.").format(date=exp)
        col = RED
    elif st == LICENSE_REVOKED:
        msg = tr_("This license has been reissued for another computer. Contact support.")
        col = RED
    else:
        msg = tr_("A license is required to continue.")
        col = ORANGE

    tk.Label(pad, text=msg, bg=BG, fg=col,
             font=("Segoe UI", 10, "bold"), wraplength=520).pack(pady=(8, 16))

    # Machine ID
    from licensing.hw_id import get_hw_id_display
    machine_id = get_hw_id_display()
    mid_frame = tk.Frame(pad, bg=ENTRY_BG, padx=12, pady=8)
    mid_frame.pack(fill="x", pady=(0, 12))
    tk.Label(mid_frame, text=tr_("Your machine ID:"), bg=ENTRY_BG, fg=FG,
             font=("Segoe UI", 9)).pack(anchor="w")
    mid_entry = tk.Entry(mid_frame, bg=BG, fg=ACCENT, relief="flat",
                         font=("Courier New", 12, "bold"),
                         readonlybackground=BG, state="readonly")
    mid_entry.pack(fill="x", pady=(4, 0))
    mid_entry.configure(state="normal")
    mid_entry.insert(0, machine_id)
    mid_entry.configure(state="readonly")
    tk.Label(mid_frame,
             text=tr_("Provide this ID to obtain your license key."),
             bg=ENTRY_BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", pady=(4, 0))

    # License key input field
    tk.Label(pad, text=tr_("Enter your license key:"), bg=BG, fg=FG,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(4, 4))
    key_var = tk.StringVar()
    key_entry = tk.Entry(pad, textvariable=key_var,
                         bg=ENTRY_BG, fg=FG, insertbackground=FG,
                         relief="flat", highlightthickness=1,
                         highlightbackground=SEL_BG, highlightcolor=ACCENT,
                         font=("Courier New", 11), width=50)
    key_entry.pack(fill="x", pady=(0, 6))
    key_entry.focus_set()

    status_lbl = tk.Label(pad, text="", bg=BG, fg=FG,
                          font=("Segoe UI", 9, "italic"))
    status_lbl.pack(anchor="w", pady=(0, 8))

    # Activate button
    def _activate():
        key_text = key_var.get().strip()
        if not key_text:
            status_lbl.config(text=tr_("Paste your license key."), fg=ORANGE)
            return
        ok, msg = checker.activate(key_text)
        if ok:
            status_lbl.config(text=f"✅ {tr_(msg)}", fg=GREEN)
            result["activated"] = True
            root.after(800, root.destroy)
        else:
            status_lbl.config(text=f"❌ {tr_(msg)}", fg=RED)

    tk.Button(pad, text=tr_("🔑 Activate license"), command=_activate,
              bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
              relief="flat", padx=16, pady=6, cursor="hand2").pack(fill="x", pady=(0, 12))

    # Contacts
    contact_f = tk.Frame(pad, bg=SEL_BG, padx=14, pady=10)
    contact_f.pack(fill="x")
    tk.Label(contact_f, text=tr_("Obtain a license:"), bg=SEL_BG, fg=ACCENT,
             font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 4))
    tk.Label(contact_f,
             text="📧  otaguard@proton.me",
             bg=SEL_BG, fg=FG, font=("Segoe UI", 9)).pack(anchor="w", pady=1)
    tk.Label(contact_f,
             text="💬  WhatsApp: +91 9307380525 (message only)",
             bg=SEL_BG, fg=FG, font=("Segoe UI", 9)).pack(anchor="w", pady=1)
    tk.Label(contact_f,
             text=tr_("Submit your machine ID to receive your key."),
             bg=SEL_BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", pady=(4, 0))

    # Copy machine ID button
    def _copy_mid():
        root.clipboard_clear()
        root.clipboard_append(machine_id)
        status_lbl.config(text=tr_("Machine ID copied to clipboard."), fg=GREEN)

    tk.Button(pad, text=tr_("📋 Copy machine ID"), command=_copy_mid,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 8, "bold"),
              relief="flat", padx=8, pady=3, cursor="hand2").pack(anchor="w", pady=(8, 0))

    # Bind Enter
    key_entry.bind("<Return>", lambda e: _activate())

    root.mainloop()
    return result.get("activated", False)


# ═════════════════════════════════════════════════════════════════════════
# Launch
# ═════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import tkinter as tk
    # Keep the compiled updater and build version authoritative even when an
    # older signed patch bundle still contains updater.py or version.py.
    from updater import run_update_check
    # All other patchable modules are loaded after the patch finder.
    try:
        from core.patch_loader import apply_early, check_remote
        apply_early()
        check_remote(background=True)     # newer bundle -> next start
    except Exception:
        pass
    from licensing.license_checker import (
        get_checker, TRIAL_ACTIVE, LICENSED, TRIAL_EXPIRED, LICENSE_EXPIRED,
        LICENSE_REVOKED, INVALID,
    )

    # ── Step 0: Global auto-translation ────────────────────────────────
    # Covers ALL UI text without modifying the tab files:
    #   - tk.* and ttk.* constructors (text=)
    #   - .config(text=...) / .configure(text=...) on any widget
    #   - ttk.Treeview.heading(col, text=...) — column headers
    #   - ttk.Notebook.add(tab, text=...) — notebook tabs
    #   - messagebox.showinfo/warning/error/ask* — dialog boxes
    #   - simpledialog.askstring/float/integer — inputs
    # EXCLUSIONS: ©, ®, ™, <NOTRANSLATE> (legal/trademark texts)
    try:
        import tkinter as _tk
        from tkinter import ttk as _ttk
        from tkinter import messagebox as _msgbox
        from tkinter import simpledialog as _sdlg
        from core.utils import tr_ as _tr
        import re as _re_tr

        _NO_TRANS_MARKERS = ("©", "®", "™", "<NOTRANSLATE>")
        # 2026-08-10: scan progress messages (e.g. "Agoda [3/10]
        # ⚙️ Structural analysis phase…") are formatted BEFORE being
        # displayed. bind_class intercepts them and passes them to tr_(), but
        # since every step changes the [N/M] counter, every step produces
        # a different key never present in the catalog → 1800+
        # "missing translation" warnings per scan. These ephemeral status
        # messages do not need translation (they disappear within a few
        # seconds). They are detected via the [digits/digits] pattern and
        # excluded from automatic translation.
        _PROGRESS_RE = _re_tr.compile(r'\[\d+/\d+\]')

        def _safe_tr(v):
            if not v or not isinstance(v, str):
                return v
            if any(m in v for m in _NO_TRANS_MARKERS):
                return v
            if _PROGRESS_RE.search(v):
                return v
            try:
                return _tr(v)
            except Exception:
                return v

        # ── 1. Widget constructors ────────────────────────────────────────
        def _wrap_widget(cls, kw_key="text"):
            _orig_init = cls.__init__
            def _new_init(self, *args, **kwargs):
                if kw_key in kwargs:
                    kwargs[kw_key] = _safe_tr(kwargs[kw_key])
                _orig_init(self, *args, **kwargs)
            cls.__init__ = _new_init

        # tk widgets
        _wrap_widget(_tk.Label)
        _wrap_widget(_tk.Button)
        _wrap_widget(_tk.Checkbutton)
        _wrap_widget(_tk.Radiobutton)
        _wrap_widget(_tk.Menu, kw_key="title")

        # ── 1b. Menu items: add_command/add_cascade/add_checkbutton/
        #        add_radiobutton(label=...) — the kw_key="title" above only
        #        covers the Menu's own title, never the added items
        #        (the real case of the app's context menus).
        def _wrap_menu_add(method_name):
            _orig_add = getattr(_tk.Menu, method_name)
            def _new_add(self, cnf={}, **kw):
                if cnf and isinstance(cnf, dict) and "label" in cnf:
                    cnf["label"] = _safe_tr(cnf["label"])
                elif "label" in kw:
                    kw["label"] = _safe_tr(kw["label"])
                return _orig_add(self, cnf, **kw)
            setattr(_tk.Menu, method_name, _new_add)

        for _m in ("add_command", "add_cascade", "add_checkbutton", "add_radiobutton"):
            _wrap_menu_add(_m)

        # ttk widgets (different hierarchy — NOT covered before)
        _wrap_widget(_ttk.Label)
        _wrap_widget(_ttk.Button)
        _wrap_widget(_ttk.Checkbutton)
        _wrap_widget(_ttk.Radiobutton)

        # ── 2. .config(text=...) on all widgets ───────────────────────────
        _orig_configure = _tk.Misc.configure
        def _new_configure(self, cnf=None, **kw):
            if "text" in kw:
                kw["text"] = _safe_tr(kw["text"])
            if cnf and isinstance(cnf, dict) and "text" in cnf:
                cnf["text"] = _safe_tr(cnf["text"])
            return _orig_configure(self, cnf, **kw)
        _tk.Misc.configure = _new_configure
        _tk.Misc.config    = _new_configure

        # ── 3. ttk.Treeview.heading(col, text=...) ───────────────────────
        _orig_heading = _ttk.Treeview.heading
        def _new_heading(self, column, option=None, **kw):
            if "text" in kw:
                kw["text"] = _safe_tr(kw["text"])
            return _orig_heading(self, column, option, **kw)
        _ttk.Treeview.heading = _new_heading

        # ── 4. ttk.Notebook.add(tab, text=...) ───────────────────────────
        _orig_nb_add = _ttk.Notebook.add
        def _new_nb_add(self, child, **kw):
            if "text" in kw:
                kw["text"] = _safe_tr(kw["text"])
            return _orig_nb_add(self, child, **kw)
        _ttk.Notebook.add = _new_nb_add

        # ── 5. messagebox ─────────────────────────────────────────────────
        def _wrap_msgbox_fn(fn_name):
            orig = getattr(_msgbox, fn_name, None)
            if orig is None:
                return
            def _wrapped(*args, **kwargs):
                args = list(args)
                # args[0] = title, args[1] = message
                for i in range(min(2, len(args))):
                    args[i] = _safe_tr(args[i])
                for k in ("title", "message"):
                    if k in kwargs:
                        kwargs[k] = _safe_tr(kwargs[k])
                return orig(*args, **kwargs)
            setattr(_msgbox, fn_name, _wrapped)

        for _fn in ("showinfo", "showwarning", "showerror",
                    "askyesno", "askokcancel", "askyesnocancel", "askquestion"):
            _wrap_msgbox_fn(_fn)

        # ── 6. simpledialog ───────────────────────────────────────────────
        def _wrap_sdlg_fn(fn_name):
            orig = getattr(_sdlg, fn_name, None)
            if orig is None:
                return
            def _wrapped(*args, **kwargs):
                args = list(args)
                # args[0] = title, args[1] = prompt
                for i in range(min(2, len(args))):
                    args[i] = _safe_tr(args[i])
                for k in ("title", "prompt"):
                    if k in kwargs:
                        kwargs[k] = _safe_tr(kwargs[k])
                return orig(*args, **kwargs)
            setattr(_sdlg, fn_name, _wrapped)

        for _fn in ("askstring", "askinteger", "askfloat"):
            _wrap_sdlg_fn(_fn)

    except Exception:
        pass

    # ── Step 1: Live exchange rates ──────────────────────────────────────
    # If the on-disk cache is still valid (< 24h), the refresh runs in the
    # background. If the cache is expired, we wait (rates are needed for display).
    try:
        import json as _json, time as _time
        from pathlib import Path as _PFX
        _fx_cache = DATA_DIR / "fx_cache.json"
        _fx_fresh = False
        if _fx_cache.exists():
            try:
                _d = _json.loads(_fx_cache.read_text(encoding="utf-8"))
                _fx_fresh = (_time.time() - _d.get("ts", 0)) < 86400 and bool(_d.get("rates"))
            except Exception:
                pass
        from core.utils import refresh_fx_rates
        if _fx_fresh:
            import threading as _thr_fx
            _thr_fx.Thread(target=refresh_fx_rates, daemon=True).start()
        else:
            refresh_fx_rates()
    except Exception:
        pass


    # ── VAE: passive listener startup (background, 5s after launch) ──
    # VAE listens to the user's browser (Brave/Chrome/Edge) via CDP
    # and captures the OTAs' JSON responses. 100% passive, undetectable.
    def _deferred_vae_listener():
        import time as _t_vae
        _t_vae.sleep(5)
        try:
            # Sync OTA Guard config → VAE hotel.yaml + target currency
            from core import config as _cfg_vae
            from vae_bridge import sync_config_from_otaguard, start_vae_listener
            _vae_cfg = _cfg_vae.load()
            sync_config_from_otaguard(_vae_cfg)
            start_vae_listener()
        except Exception:
            import logging as _lg_vae
            _lg_vae.getLogger(__name__).error(
                "VAE listener not started", exc_info=True)

    import threading as _threading_vae
    _threading_vae.Thread(target=_deferred_vae_listener, daemon=True,
                          name="vae-startup").start()

    # ── Step 1c: EULA acceptance (first launch) ───────────────────
    try:
        from core import config as _cfg_eula
        from legal.legal_screens import ensure_eula_accepted
        _cur_cfg = _cfg_eula.load()
        if not ensure_eula_accepted(None, _cur_cfg, _cfg_eula.save):
            import sys as _sys
            _sys.exit(0)  # Declined → close the app
    except Exception:
        pass

    # ── Step 3: Update ─────────────────────────────────────────────────────
    try:
        from core import config as _cfg
        from lang import load_language as _load_lang
        _load_lang(_cfg.load().get("language", "en"))
    except Exception:
        pass
    run_update_check()

    # ── Step 3: License ─────────────────────────────────────────────────
    # Fresh-install bug (2026-08-17): an exception here left the process
    # alive with no window and no trace — the log just stopped. Any failure
    # is now logged and falls back to the license screen instead of a
    # silent hang.
    try:
        checker = get_checker()
        status  = checker.status
    except Exception:
        logging.exception("main.py: license check failed at startup")
        status = INVALID

    if status in (TRIAL_ACTIVE, LICENSED):
        # D33: mono-instance lock BEFORE everything. Two OTA Guard on the
        # same CDP port 9222 = two executors in the same CM form
        # (incident of 27/08: conflicting queues pushed in parallel
        # 16:10→17:29). Clean refusal if an instance is already alive.
        try:
            from core.single_instance import acquire_lock
            _lock_ok, _old_pid = acquire_lock()
            if not _lock_ok:
                import tkinter.messagebox as _mb
                _lr = tk.Tk()
                _lr.withdraw()
                _mb.showwarning(
                    "OTA Guard",
                    "OTA Guard is already in progress (PID "
                    f"{_old_pid}).\n\nClose it before opening "
                    "another one: two instances could drive the same "
                    "browser at the same time.")
                _lr.destroy()
                logging.warning("main.py: instance already in progress (PID %s) "
                                "— startup refused", _old_pid)
                sys.exit(1)
        except SystemExit:
            raise
        except Exception:
            logging.exception("main.py: mono-instance lock unreadable "
                              "— startup allowed by default")

        # D79: pricing zone — if the signed license carries a zone
        # (A..F) and THIS machine does not belong to it (time zone +
        # Windows country), startup is refused. WORLD / trial / v2 licenses
        # (grandfathering) → no check.
        if status == LICENSED:
            try:
                from licensing.limits import check_zone, license_limits
                _max_r, _zone = license_limits()
                _zok, _zmsg = check_zone(_zone)
                if not _zok:
                    import tkinter.messagebox as _mb
                    _zr = tk.Tk()
                    _zr.withdraw()
                    _mb.showerror("OTA Guard — zone license", _zmsg)
                    _zr.destroy()
                    logging.warning("main.py: incompatible zone "
                                    "(license %s) — startup refused",
                                    _zone)
                    sys.exit(1)
            except SystemExit:
                raise
            except Exception:
                logging.exception("main.py: zone check unreadable "
                                  "— startup allowed by default")

        # License OK → launch the application
        root = tk.Tk()
        from app import App
        application = App(root)
        root.mainloop()

    elif status in (TRIAL_EXPIRED, LICENSE_EXPIRED, LICENSE_REVOKED):
        # Blocked → license screen
        root = tk.Tk()
        activated = _show_license_screen(root, checker)
        if activated:
            # Restart the app after activation
            root2 = tk.Tk()
            from app import App
            application = App(root2)
            root2.mainloop()

    else:
        root = tk.Tk()
        _show_license_screen(root, checker)
