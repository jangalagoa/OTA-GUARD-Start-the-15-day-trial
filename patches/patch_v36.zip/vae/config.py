"""
Central configuration for OTA Guard VAE.
Provides PROJECT_ROOT and loads settings.yaml.
All modules import paths and settings from here — no hardcoded paths elsewhere.
"""

import yaml
from pathlib import Path
from typing import Optional, Dict, Any


# Project root: this file is at the project root level
def _install_root():
    # D104: anchor on the install dir, never on __file__ —
    # a patch-served module would otherwise point into the
    # patches data folder
    try:
        from core.paths import INSTALL_DIR
        return Path(INSTALL_DIR) / "vae"
    except Exception:
        return Path(__file__).resolve().parent

PROJECT_ROOT = _install_root()

# Standard directories (all relative to PROJECT_ROOT)
DATA_DIR = PROJECT_ROOT / "data" / "api_discovery"
MAPPINGS_DIR = PROJECT_ROOT / "config" / "ota_mappings"
CONFIG_DIR = PROJECT_ROOT / "config"
SETTINGS_FILE = CONFIG_DIR / "settings.yaml"
OTA_DOMAINS_FILE = CONFIG_DIR / "ota_domains.yaml"
HOTEL_CONFIG_FILE = CONFIG_DIR / "hotel.yaml"

# Default settings (used if settings.yaml is missing or incomplete)
_DEFAULT_SETTINGS = {
    'auto_refresh': {
        'enabled': True,
        'min_interval_seconds': 1800,
        'max_interval_seconds': 3600,
    },
    'browser': {
        'debug_port': 9222,
    },
    'target_currency': 'EUR',
    'exchange_rates_api': 'https://api.frankfurter.app/latest',
    'capture': {
        'min_body_size': 10000,
    },
    'tab_monitor': {
        'check_interval_seconds': 10,
    },
}

# Cached settings
_settings: Optional[Dict[str, Any]] = None


def load_settings() -> Dict[str, Any]:
    """Load settings from settings.yaml, merged with defaults."""
    global _settings
    if _settings is not None:
        return _settings

    settings = _DEFAULT_SETTINGS.copy()

    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                loaded = yaml.safe_load(f) or {}
            # Deep merge: loaded values override defaults
            for key, value in loaded.items():
                if isinstance(value, dict) and isinstance(settings.get(key), dict):
                    settings[key] = {**settings[key], **value}
                else:
                    settings[key] = value
        except Exception as e:
            print(f"[CONFIG] Error loading settings.yaml: {e}, using defaults")

    _settings = settings
    return settings


def get_setting(key: str, default: Any = None) -> Any:
    """Get a single setting value by dot-notation key (e.g., 'auto_refresh.enabled')."""
    settings = load_settings()
    parts = key.split('.')
    current = settings
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return default
    return current


def get_target_currency() -> str:
    """Get the target currency for price normalization."""
    return str(get_setting('target_currency', 'EUR'))


def set_target_currency(currency: str) -> None:
    """
    Override the target currency at runtime.
    Called by the host software (e.g., OTA Guard sets its working currency).
    """
    global _settings
    settings = load_settings()
    settings['target_currency'] = currency


def get_data_dir() -> Path:
    """Get the data directory path."""
    return DATA_DIR


def get_mappings_dir() -> Path:
    """Get the mappings directory path."""
    return MAPPINGS_DIR
