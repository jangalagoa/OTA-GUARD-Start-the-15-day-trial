"""
DOM-based price extraction for OTAs that don't expose pricing via
capturable JSON APIs.

Some OTAs (Expedia, MakeMyTrip) render room prices client-side in the
DOM via JavaScript.  Their API responses either contain empty listing
containers or return HTML anti-bot challenges.  This module connects
to the live browser tab via CDP and reads the rendered prices directly
from the page.

Usage:
    from src.extractors.dom_extractor import DomExtractor

    extractor = DomExtractor(debug_port=9222, target_currency="INR")
    results = extractor.extract_all()  # {ota_name: {room_name: price_int}}
"""

import asyncio
import json
import logging
from diagnostic import scan_trace as _diag
from core.scan_context import url_scope, same_stay, merge_room_prices
import urllib.request
import websockets
from typing import Dict, List, Optional


# ── Per-OTA JavaScript extraction scripts ──────────────────────────────────
# Each script must:
#   1. Find the room listings section (NOT "Similar properties" or
#      "Things to do nearby")
#   2. Return JSON.stringify([{name, price, currency}, ...])
#   3. price must be a number (no currency symbol)
#   4. Scroll the page first if needed to trigger lazy loading

_EXPEDIA_JS = r"""
(function() {
    // STRICT PASSIVITY: no scroll, no mutation. Read whatever the user's
    // own scrolling has loaded — if the room cards are not rendered yet,
    // return empty and let the next scan (after the user scrolls) read it.
    // Find the "Choose your room" heading — this is the ONLY section
    // that contains room rate cards.  Everything after "Similar
    // properties" or "things to do nearby" is irrelevant.
    var headings = document.querySelectorAll('h2');
    var roomH2 = null;
    for (var i = 0; i < headings.length; i++) {
        var t = headings[i].textContent.trim();
        if (t === 'Choose your room' || t === 'Select your room'
            || t === 'Rooms') {
            roomH2 = headings[i];
            break;
        }
    }
    if (!roomH2) return JSON.stringify([]);

    // Walk up to the section container
    var section = roomH2;
    for (var i = 0; i < 5; i++) {
        if (section.parentElement) section = section.parentElement;
    }

    // Find room name headings within the section
    var rooms = [];
    var h3s = section.querySelectorAll('h3, h4');
    h3s.forEach(function(h3) {
        var name = h3.textContent.trim();
        if (/view all photos|gallery|upgrade your stay/i.test(name)) return;
        if (!/room|suite|deluxe|standard|basic|elite|studio|villa/i.test(name)) return;
        if (name.length < 5 || name.length > 80) return;

        // Walk up to the card container
        var card = h3;
        for (var depth = 0; depth < 4; depth++) {
            if (card.parentElement) card = card.parentElement;
        }

        // Extract the nightly price: "$XX nightly" or "$XX/night"
        var cardText = card.textContent;
        var nightlyMatch = cardText.match(/[\$€£₹]\s*(\d[\d,]*)\s*(?:nightly|\/night)/i)
                        || cardText.match(/[\$€£₹]\s*(\d[\d,]*)\s*\/\s*n/i);
        var price = nightlyMatch ? parseFloat(nightlyMatch[1].replace(/,/g, '')) : null;

        // Detect currency symbol
        var currency = 'USD';
        if (cardText.indexOf('₹') >= 0) currency = 'INR';
        else if (cardText.indexOf('€') >= 0) currency = 'EUR';
        else if (cardText.indexOf('£') >= 0) currency = 'GBP';

        if (price && price > 0) {
            rooms.push({name: name, price: price, currency: currency});
        }
    });

    return JSON.stringify(rooms);
})()
"""

_MAKEMYTRIP_JS = r"""
(function() {
    // MakeMyTrip is a React SPA.  Room prices are NOT rendered as text
    // in the DOM (anti-bot masking), but the full room data — including
    // the price — lives in the Redux state injected at ``__INITIAL_STATE__``.
    // We read it directly instead of scraping the rendered DOM.
    var state = window.__INITIAL_STATE__;
    if (!state || !state.hotelDetail || !state.hotelDetail.searchRooms) {
        return JSON.stringify([]);
    }
    var sr = state.hotelDetail.searchRooms;
    var rooms = sr.exactRoomsDetail || [];
    var currency = sr.searchRoomsCurrency || 'USD';

    var result = [];
    rooms.forEach(function(r) {
        var name = (r.roomName || '').trim();
        if (!name) return;

        // Primary source: roomInfoText = "Starts at $ 16 | 215 sq ft"
        var info = r.roomInfoText || '';
        var match = info.match(/[\u20ac\u00a3\u20b9\u00a5$]\s*(\d[\d,]*)/);
        var price = match ? parseFloat(match[1].replace(/,/g, '')) : null;

        // Fallback: walk ratePlans.priceDetails for a numeric price.
        if (!price && r.ratePlans) {
            for (var i = 0; i < r.ratePlans.length; i++) {
                var pd = r.ratePlans[i].priceDetails;
                if (!pd) continue;
                var s = JSON.stringify(pd);
                var pm = s.match(/"(?:price|sellingPrice|displayPrice)"\s*:\s*(\d[\d,]*)/);
                if (pm) { price = parseFloat(pm[1].replace(/,/g, '')); break; }
            }
        }

        if (price && price > 0) {
            result.push({name: name, price: price, currency: currency});
        }
    });

    return JSON.stringify(result);
})()
"""

_BOOKING_JS = r"""
(function() {
    // Room-table prices can be stay totals. Accept only an explicit one-night
    // search so the returned amount is a nightly price.
    var params = new URLSearchParams(location.search);
    var checkin = params.get('checkin');
    var checkout = params.get('checkout');
    if (!checkin || !checkout ||
        Date.parse(checkout) - Date.parse(checkin) !== 86400000) {
        return JSON.stringify([]);
    }
    var byName = {};
    document.querySelectorAll('tr.js-rt-block-row, tr.e2e-hprt-table-row')
      .forEach(function(row) {
        var room = row.querySelector('.hprt-roomtype-icon-link');
        var priceEl = row.querySelector('.bui-price-display__value, .prco-valign-middle-helper');
        if (!room || !priceEl) return;
        var name = room.textContent.trim().replace(/\s+/g, ' ');
        var raw = priceEl.textContent.trim().replace(/\s+/g, ' ');
        var match = raw.match(/\b(THB|INR|USD|EUR|GBP)\s*([\d,]+(?:\.\d{1,2})?)/i)
                 || raw.match(/([฿₹€$£])\s*([\d,]+(?:\.\d{1,2})?)/);
        if (!name || !match) return;
        var currencies = {'฿':'THB', '₹':'INR', '€':'EUR', '$':'USD', '£':'GBP'};
        var currency = currencies[match[1]] || match[1].toUpperCase();
        var price = Number(match[2].replace(/,/g, ''));
        if (!Number.isFinite(price) || price <= 0) return;
        if (!byName[name] || price < byName[name].price) {
            byName[name] = {name:name, price:price, currency:currency};
        }
      });
    return JSON.stringify(Object.values(byName));
})()
"""

# Maps domain substring → JS script
_DOMAIN_SCRIPTS = {
    "expedia": _EXPEDIA_JS,
    "makemytrip": _MAKEMYTRIP_JS,
    "booking.com/hotel/": _BOOKING_JS,
}

# Maps domain substring → display name
_DOMAIN_NAMES = {
    "expedia": "Expedia",
    "makemytrip": "MakeMyTrip",
    "booking.com/hotel/": "Booking.com",
}


class DomExtractor:
    """Extract room prices from live OTA tabs via CDP DOM evaluation."""

    def __init__(self, debug_port: int = 9222, target_currency: str = "INR"):
        self.debug_port = debug_port
        self.target_currency = target_currency
        self._converter = None

    def _get_converter(self):
        """Lazy-load the currency converter."""
        if self._converter is None:
            try:
                from vae.src.extractors.currency_converter import CurrencyConverter
                self._converter = CurrencyConverter()
            except Exception as exc:
                _diag.error("dom_currency_init", exc)
                self._converter = None
        return self._converter

    def _convert(self, amount: float, from_curr: str) -> float:
        """Convert amount from from_curr to target_currency."""
        if from_curr.upper() == self.target_currency.upper():
            return amount
        conv = self._get_converter()
        if conv is None:
            _diag.event("dom_conversion", "error", amount=amount, source_currency=from_curr,
                        target_currency=self.target_currency, reason="converter absent; price rejected")
            raise RuntimeError(f"Currency converter unavailable: {from_curr} to {self.target_currency}")
        try:
            converted = conv.convert(amount, from_curr, self.target_currency)
            _diag.event("dom_conversion", amount=amount, converted=converted,
                        source_currency=from_curr, target_currency=self.target_currency)
            return converted
        except Exception as exc:
            _diag.error("dom_conversion", exc, amount=amount, source_currency=from_curr,
                        target_currency=self.target_currency)
            raise

    def _get_tabs(self) -> List[dict]:
        """Fetch browser tabs from CDP /json/list."""
        try:
            url = f"http://127.0.0.1:{self.debug_port}/json/list"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=2) as resp:
                return json.loads(resp.read().decode())
        except Exception as exc:
            raise RuntimeError("Could not read browser tabs for DOM extraction") from exc

    async def _unthrottle_tab(self, ws_url: str):
        """D152 — lift Chromium background throttling on ONE tab (D93
        recipe, CDP only, never raises the window): focus emulation ON
        + lifecycle set to active, then let the SPA mount its room
        cards. A failing call is non-fatal (the read is attempted as-is)."""
        async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
            for cmd in (
                    {"id": 1, "method": "Emulation.setFocusEmulationEnabled",
                     "params": {"enabled": True}},
                    {"id": 2, "method": "Page.setWebLifecycleState",
                     "params": {"state": "active"}},
            ):
                await ws.send(json.dumps(cmd))
                deadline = asyncio.get_event_loop().time() + 4
                while asyncio.get_event_loop().time() < deadline:
                    data = json.loads(await asyncio.wait_for(ws.recv(), timeout=5))
                    if data.get("id") == cmd["id"]:
                        break

    def extract_all(self, skip_otas: Optional[set] = None,
                     cancel_cb=None, url_allowed=None) -> Dict[str, Dict[str, int]]:
        """Extract room prices from all supported OTA tabs.

        Args:
            skip_otas: set of OTA display names already extracted via JSON
                       (these will be skipped).
            cancel_cb: optional () -> bool — D107 (STOP = STOP) : la phase
                       DOM est la plus longue du scan (lecture des onglets
                       one by one). Checked at entry AND before
                       each tab: a ⏹ cuts at tab granularity, the
                       tabs already read are kept.

        Returns:
            {ota_display_name: {room_name: price_int_in_target_currency}}
        """
        def _stop_now() -> bool:
            if not cancel_cb:
                return False
            try:
                return bool(cancel_cb())
            except Exception:
                return False

        skip = skip_otas or set()
        self.errors = []
        self.contexts = {}
        if _stop_now():
            return {}
        tabs = self._get_tabs()
        if not tabs:
            return {}

        results = {}
        for tab in tabs:
            if _stop_now():
                break
            if tab.get("type") != "page":
                continue
            if url_allowed is not None and not url_allowed(tab.get("url", "")):
                continue
            url = tab.get("url", "").lower()
            ws_url = tab.get("webSocketDebuggerUrl", "")
            if not ws_url:
                continue

            # Match URL to a supported OTA
            ota_domain = None
            js_script = None
            display_name = None
            for domain, script in _DOMAIN_SCRIPTS.items():
                if domain in url:
                    ota_domain = domain
                    js_script = script
                    display_name = _DOMAIN_NAMES.get(domain, domain)
                    break

            if not ota_domain:
                continue
            if display_name in skip:
                continue

            # Run extraction on this tab
            try:
                # D152: background-tab throttling starves SPA room lists
                # (observed 02/11: Goibibo/Expedia/MMT pages rendered only
                # 2.8-5.7 KB of text — the room cards never mounted). The
                # D93 remedy, CDP-only, NO window raise: focus emulation
                # + active lifecycle before reading.
                try:
                    asyncio.run(self._unthrottle_tab(ws_url))
                except Exception:
                    pass
                _diag.event("dom_start", ota=display_name, url=tab.get("url"))
                rooms = asyncio.run(self._extract_tab(ws_url, js_script))
                _diag.event("dom_candidates", ota=display_name, rooms=rooms)
            except Exception as e:
                _diag.error("dom_read", e, ota=display_name)
                logging.exception("[DOM_EXTRACTOR] Failed for %s", display_name)
                self.errors.append({'ota': display_name, 'stage': 'DOM', 'error': str(e)})
                continue

            if rooms:
                # Convert prices to target currency
                room_prices = {}
                for r in rooms:
                    name = r.get("name", "")
                    price = r.get("price", 0)
                    currency = r.get("currency", "USD")
                    if price > 0 and name:
                        try:
                            converted = self._convert(price, currency)
                            room_prices[name] = int(round(converted))
                        except Exception as exc:
                            self.errors.append({'ota': display_name, 'stage': 'conversion',
                                                'room': name, 'error': str(exc)})
                            _diag.error("dom_room_conversion", exc, ota=display_name, room=name)

                if room_prices:
                    context = url_scope(tab.get("url", ""))
                    # Comparison uses the source currency, before normalization.
                    currencies = {r.get('currency', 'USD') for r in rooms if r.get('price', 0) > 0}
                    if len(currencies) == 1:
                        context['fields']['currency'] = next(iter(currencies))
                    old_contexts = self.contexts.get(display_name) or []
                    if results.get(display_name) and not all(same_stay(c, context) for c in old_contexts):
                        self.errors.append({'ota': display_name, 'stage': 'DOM',
                                            'error': 'Several live pages have different or unknown stay contexts; additional page skipped'})
                        continue
                    results[display_name] = merge_room_prices(results.get(display_name, {}), room_prices)
                    self.contexts.setdefault(display_name, []).append(context)
                    print(f"[DOM_EXTRACTOR] {display_name}: "
                          f"{len(room_prices)} rooms extracted",
                          flush=True)

        return results

    async def _extract_tab(self, ws_url: str, js_script: str) -> List[dict]:
        """Connect to a tab and run the read-only extraction JS.

        STRICT PASSIVITY RULE: never scroll, click, navigate or mutate the
        page — anti-bot watches programmatic behaviour. Lazy-loaded content
        is the user's job: when the human scrolls, the data loads, and the
        next scan reads it. Reading the DOM/state fires no event and leaves
        no trace, unlike window.scrollTo (instant 3000px jump, no pointer
        events — a clear bot signature)."""
        import websockets

        async with websockets.connect(ws_url, max_size=10 * 1024 * 1024) as ws:
            # Execute extraction script
            await ws.send(json.dumps({
                "id": 2, "method": "Runtime.evaluate",
                "params": {
                    "expression": js_script,
                    "returnByValue": True,
                }
            }))

            # Wait for the response (skip any intermediate events)
            while True:
                raw = await asyncio.wait_for(ws.recv(), timeout=15.0)
                data = json.loads(raw)
                if data.get("id") == 2:
                    result = data.get("result", {})
                    if "exceptionDetails" in result:
                        raise RuntimeError("DOM script failed: " + result['exceptionDetails'].get('text', '?'))
                    value = result.get("result", {}).get("value", "[]")
                    return json.loads(value)

        return []
