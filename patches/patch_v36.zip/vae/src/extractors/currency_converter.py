"""
Intelligent currency converter for OTA Guard VAE.
Multi-source rate fetching ensures ALL currencies can be converted,
even rare ones like LAK, IDR, KRW that major APIs sometimes omit.

Sources (tried in order):
  1. open.er-api.com  — free, ALL ISO 4217 currencies, no key needed
  2. frankfurter.app  — ECB daily rates (~31 major currencies)
  3. Static fallback   — emergency rates for common currencies

The host software can also provide custom rates via set_custom_rates().
"""

import json
import urllib.request
from typing import Optional, Dict
from datetime import datetime
from pathlib import Path

from vae.config import get_setting, PROJECT_ROOT


# Emergency fallback rates (approximate, relative to EUR).
# Used ONLY if both APIs are unreachable. Updated periodically.
_EMERGENCY_RATES = {
    'EUR': 1.0, 'USD': 1.08, 'GBP': 0.85, 'CHF': 0.95,
    'INR': 98.5, 'IDR': 17200, 'LAK': 23500, 'KRW': 1450,
    'JPY': 168, 'CNY': 7.8, 'AUD': 1.65, 'CAD': 1.47,
    'SGD': 1.45, 'THB': 39, 'MYR': 5.1, 'PHP': 62,
    'VND': 27500, 'HKD': 8.4, 'NZD': 1.82, 'SEK': 11.5,
    'NOK': 12.8, 'DKK': 7.46, 'PLN': 4.3, 'CZK': 25.4,
    'HUF': 420, 'RUB': 99, 'TRY': 35, 'BRL': 6.1,
    'MXN': 20, 'ZAR': 20, 'AED': 3.97, 'SAR': 4.05,
    'PKR': 300, 'BDT': 130, 'LKR': 350, 'NPR': 145,
    'MAD': 10.8, 'EGP': 53, 'KES': 139, 'NGN': 1700,
}

# API sources in priority order (all free, no API key)
_API_SOURCES = [
    {
        'name': 'open.er-api.com',
        'url': 'https://open.er-api.com/v6/latest/EUR',
        'parser': lambda data: (
            data.get('rates', {}),
            'EUR',
            data.get('time_last_update_utc', '').split(' ')[0] or datetime.now().strftime('%Y-%m-%d')
        ),
    },
    {
        'name': 'frankfurter.app',
        'url': 'https://api.frankfurter.app/latest',
        'parser': lambda data: (
            {**data.get('rates', {}), data.get('base', 'EUR'): 1.0},
            data.get('base', 'EUR'),
            data.get('date', datetime.now().strftime('%Y-%m-%d'))
        ),
    },
]


class CurrencyConverter:
    """
    Convert amounts between ANY two currencies using live exchange rates.
    Multi-source fetching with fallback ensures no currency is left unconverted.
    """

    CACHE_FILE = PROJECT_ROOT / "data" / "exchange_rates.json"

    def __init__(self, api_url: str = "", custom_rates: Optional[Dict[str, float]] = None):
        self._rates: Optional[Dict[str, float]] = None
        self._rates_base: str = "EUR"
        self._rates_date: str = ""
        self._custom_rates = custom_rates or {}
        self._api_url_override = api_url

    def _load_cache(self) -> bool:
        """Load cached rates from disk if fresh (< 24h old)."""
        if not self.CACHE_FILE.exists():
            return False
        try:
            with open(self.CACHE_FILE, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            cache_date = cache.get('date', '')
            today = datetime.now().strftime('%Y-%m-%d')
            if cache_date == today:
                self._rates = cache.get('rates', {})
                self._rates_base = cache.get('base', 'EUR')
                self._rates_date = cache_date
                return True
        except Exception:
            pass
        return False

    def _save_cache(self):
        """Save rates to disk."""
        try:
            self.CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(self.CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump({
                    'date': self._rates_date,
                    'base': self._rates_base,
                    'rates': self._rates,
                    'source': 'multi',
                }, f, indent=2)
        except Exception:
            pass

    def _fetch_from_source(self, source: dict) -> bool:
        """Try to fetch rates from a single API source."""
        try:
            url = source['url']
            req = urllib.request.Request(url, headers={'User-Agent': 'OTA-Guard-VAE/1.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())

            rates, base, date = source['parser'](data)
            if rates and len(rates) > 5:
                self._rates = rates
                self._rates_base = base
                self._rates_date = date
                # Ensure base currency has rate 1.0
                self._rates[self._rates_base] = 1.0
                print(f"[CURRENCY] Rates loaded from {source['name']} "
                      f"({len(rates)} currencies, {date})")
                return True
        except Exception as e:
            print(f"[CURRENCY] {source['name']} failed: {e}")
        return False

    def _fetch_rates(self):
        """Fetch rates from multiple sources until one succeeds."""
        # If a specific API URL was provided, use it
        if self._api_url_override:
            custom_source = {
                'name': 'custom',
                'url': self._api_url_override,
                'parser': _API_SOURCES[0]['parser'],
            }
            if self._fetch_from_source(custom_source):
                self._save_cache()
                return

        # Try each source in priority order
        for source in _API_SOURCES:
            if self._fetch_from_source(source):
                self._save_cache()
                return

        # All APIs failed: use emergency fallback
        print("[CURRENCY] All APIs unavailable, using emergency fallback rates")
        self._rates = _EMERGENCY_RATES.copy()
        self._rates_base = 'EUR'
        self._rates_date = datetime.now().strftime('%Y-%m-%d') + ' (fallback)'

    def _ensure_rates(self):
        """Ensure rates are loaded (cache → fetch → fallback)."""
        if self._rates is not None:
            return
        if self._load_cache():
            return
        self._fetch_rates()

    def get_rate(self, from_currency: str, to_currency: str) -> float:
        """
        Get the exchange rate from one currency to another.
        Uses cross-rate calculation: from → base → to.
        Returns 1.0 only if currencies are identical.
        Never fails — always returns a usable rate.
        """
        from_currency = from_currency.upper().strip()
        to_currency = to_currency.upper().strip()

        if from_currency == to_currency:
            return 1.0

        # Check custom rates first (host-provided)
        custom_key = f"{from_currency}_{to_currency}"
        if custom_key in self._custom_rates:
            return self._custom_rates[custom_key]

        self._ensure_rates()

        if not self._rates:
            return 1.0

        # All rates are relative to _rates_base (usually EUR).
        # Cross-rate: amount_in_target = amount_in_source * (rate[to] / rate[from])
        from_rate = self._rates.get(from_currency)
        to_rate = self._rates.get(to_currency)

        if from_rate and to_rate and from_rate > 0:
            return to_rate / from_rate

        # Currency not in rates table — try emergency fallback
        from_fb = _EMERGENCY_RATES.get(from_currency)
        to_fb = _EMERGENCY_RATES.get(to_currency)

        if from_fb and to_fb and from_fb > 0:
            print(f"[CURRENCY] '{from_currency}' not in live rates, "
                  f"using fallback for cross-rate")
            return to_fb / from_fb

        # Last resort: return 1.0 with warning
        print(f"[CURRENCY] WARNING: Cannot convert {from_currency} → {to_currency}, "
              f"returning original amount")
        return 1.0

    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        """Convert an amount from one currency to another."""
        if not from_currency or not to_currency or amount == 0:
            return amount
        rate = self.get_rate(from_currency, to_currency)
        return round(amount * rate, 2)

    def set_custom_rates(self, rates: Dict[str, float]):
        """Set custom exchange rates (e.g., from host software). Keys: 'USD_EUR'."""
        self._custom_rates.update(rates)

    def get_available_currencies(self) -> list:
        """Return list of all currencies that can be converted."""
        self._ensure_rates()
        combined = set(self._rates.keys() if self._rates else [])
        combined.update(_EMERGENCY_RATES.keys())
        return sorted(combined)
