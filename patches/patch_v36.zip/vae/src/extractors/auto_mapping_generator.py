"""
Generateur automatique de mappings YAML pour OTA Guard VAE.
Analyse les fichiers JSON captures et genere les mappings pour toutes les OTA.
"""

import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from collections import defaultdict

from vae.config import get_data_dir, get_mappings_dir


class AutoMappingGenerator:
    """
    Genere automatiquement les fichiers YAML de mapping
    en analysant la structure des fichiers JSON captures.
    """

    CANDIDATES = {
        'name': ['name', 'hotelname', 'propertyname', 'title', 'listingname', 'hotel_name'],
        'ota_id': ['giHotelId', 'hotelid', 'propertyid', 'hotel_id', 'property_id', 'listingid', 'id'],
        'address': ['address', 'fulladdress', 'hoteladdress', 'propertyaddress'],
        'description': ['description', 'longdesc', 'shortdesc', 'longdescription', 'shortdescription', 'about', 'overview'],
        'star_rating': ['starrating', 'star_rating', 'stars', 'class'],
        'property_type': ['propertytype', 'property_type', 'type', 'hoteltype', 'hotel_type', 'category'],
        'checkin_time': ['checkintime', 'check_in_time', 'checkin'],
        'checkout_time': ['checkouttime', 'check_out_time', 'checkout'],
        'cumulative_rating': ['cumulativerating', 'cumulative_rating', 'avgrating', 'avg_rating', 'overalrating'],
        'review_count': ['reviewcount', 'review_count', 'totalreviews', 'total_reviews', 'numreviews'],
        'rooms': ['roominfomap', 'rooms', 'roomlist', 'room_list', 'roomtypes', 'room_types', 'accommodations'],
        'reviews': ['reviews', 'best', 'reviewlist', 'review_list', 'guestreviews', 'guest_reviews'],
        'amenities': ['amenities', 'facilities', 'amenitiesgi', 'amenities_gi', 'hotelfacilities', 'hotel_facilities'],
    }

    ROOM_CANDIDATES = {
        'name': ['roomname', 'room_name', 'name', 'title'],
        # Machine room IDs: the only 100%-stable anchor for attribution
        # (names can repeat across listings or be translated; ids cannot).
        # Verified in real captures: Agoda 'typeId'/'roomTypeId', Expedia
        # 'roomTypeId', MakeMyTrip 'ratePlanCode', Goibibo 'roomCode',
        # Booking 'blockId'.
        'id': ['roomcode', 'room_code', 'roomid', 'room_id', 'id',
               'typeid', 'type_id', 'roomtypeid', 'roomtype_id',
               'roomTypeId', 'roomId', 'rateplancode', 'rate_plan_code',
               'ratePlanCode', 'blockid', 'block_id', 'blockId'],
        'size': ['roomsize', 'room_size', 'size', 'area'],
        'view': ['roomviewname', 'room_view_name', 'view', 'roomview'],
        'max_guests': ['maxguest', 'max_guest', 'maxguests', 'max_guests', 'capacity'],
        'max_adults': ['maxadult', 'max_adult', 'maxadults', 'max_adults'],
        'beds': ['beds', 'bedinfo', 'bed_info', 'bedtypes'],
    }

    REVIEW_CANDIDATES = {
        'author': ['travellername', 'traveller_name', 'author', 'username', 'user_name', 'guestname', 'name'],
        'rating': ['rating', 'score', 'stars', 'value'],
        'title': ['title', 'summary', 'headline'],
        'text': ['reviewtext', 'review_text', 'text', 'comment', 'body', 'content'],
        'date': ['publishdate', 'publish_date', 'date', 'createdat', 'created_at'],
        'travel_type': ['traveltype', 'travel_type', 'triptype', 'trip_type'],
    }

    # Maps known detail-array keys to Price dataclass fields.
    # Covers Goibibo, MakeMyTrip and any OTA using {key, amount} items.
    PRICE_KEY_MAP = {
        'BASE_FARE': 'base_price',
        'TOTAL_DISCOUNT': 'discount',
        'PRICE_AFTER_DISCOUNT': 'price_after_discount',
        'TAXES': 'taxes',
        'TOTAL_AMOUNT': 'total_amount',
        'TOTAL_PRICE': 'total_amount',
        'GRAND_TOTAL': 'total_amount',
    }

    # Direct price field candidates (Agoda, Expedia, etc.)
    DIRECT_PRICE_CANDIDATES = {
        'base_price': ['displayprice', 'display_price', 'baseprice', 'base_price',
                       'roompricepernightamount', 'agodaprice', 'lead', 'originalprice',
                       'price', 'basefare'],
        'total_amount': ['totalamount', 'total_amount', 'totalprice', 'total_price',
                         'finalprice', 'final_price', 'chargepriceamount',
                         'discountedpricewithtax'],
        'discount': ['discount', 'discountamount', 'couponamount', 'savings'],
        'taxes': ['taxes', 'taxamount', 'tax_amount', 'servicetaxes',
                  'taxesandfees', 'taxes_and_fees'],
        'price_after_discount': ['discountedprice', 'discounted_price',
                                  'priceafterdiscount', 'netprice', 'net_price'],
    }

    # Currency field candidates
    CURRENCY_CANDIDATES = ['currency', 'currencycode', 'currency_code',
                           'currencyinfo.code', 'currencycode']

    def __init__(self, data_dir: str = "", output_dir: str = ""):
        self.data_dir = Path(data_dir) if data_dir else get_data_dir()
        self.output_dir = Path(output_dir) if output_dir else get_mappings_dir()
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def find_json_files(self) -> Dict[str, List[Path]]:
        """Trouve tous les fichiers body.json groupes par OTA.
        Falls back to extracting inline bodies from metadata JSON files."""
        ota_files = defaultdict(list)

        # 1. Standard body files (*_body.json)
        for f in self.data_dir.glob("*_body.json"):
            name = f.stem.replace('_body', '')
            parts = name.split('_')
            if len(parts) >= 3:
                ota_name = '_'.join(parts[2:])
                ota_files[ota_name].append(f)

        # 2. Metadata JSON files with inline bodies (fallback)
        # When a response body was < threshold, it's stored inline in the
        # metadata .json as result['body']. We extract it to a temp body file.
        for f in self.data_dir.glob("*.json"):
            if f.name.endswith("_body.json"):
                continue  # Already handled above
            try:
                with open(f, 'r', encoding='utf-8') as fh:
                    meta = json.load(fh)
                body = meta.get('body')
                if not body or not isinstance(body, str) or len(body) < 100:
                    continue
                # Extract OTA name from filename
                stem = f.stem  # e.g., 20260813_162831_agoda_com
                parts = stem.split('_')
                if len(parts) >= 3:
                    ota_name = '_'.join(parts[2:])
                    # Write a temporary body file so the rest of the pipeline works
                    body_file = self.data_dir / f"{stem}_body.json"
                    if not body_file.exists():
                        with open(body_file, 'w', encoding='utf-8') as bf:
                            bf.write(body)
                    if body_file not in ota_files[ota_name]:
                        ota_files[ota_name].append(body_file)
            except Exception:
                continue

        return dict(ota_files)

    def get_json_path(self, data: Any, path: str) -> Any:
        """Navigue dans un JSON avec un chemin par points."""
        if not path or not data:
            return None

        keys = path.split('.')
        current = data

        for key in keys:
            if current is None:
                return None
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list):
                if key.isdigit():
                    idx = int(key)
                    current = current[idx] if idx < len(current) else None
                elif current and isinstance(current[0], dict):
                    current = current[0].get(key)
                else:
                    return None
            else:
                return None

        return current

    def find_best_path(self, data: Any, candidates: List[str], prefix: str = "", depth: int = 0, max_depth: int = 6) -> Optional[str]:
        """Cherche le meilleur chemin pour un champ donne."""
        if depth > max_depth:
            return None

        if isinstance(data, dict):
            for key, value in data.items():
                key_lower = key.lower()
                for candidate in candidates:
                    if candidate.lower() == key_lower:
                        full_path = f"{prefix}.{key}" if prefix else key
                        return full_path

            for key, value in data.items():
                if isinstance(value, dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_best_path(value, candidates, current_path, depth + 1, max_depth)
                    if result:
                        return result
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_best_path(value[0], candidates, current_path, depth + 1, max_depth)
                    if result:
                        return result

        return None

    def find_rooms_structure(self, data: Any, prefix: str = "", depth: int = 0, max_depth: int = 6) -> Optional[Dict]:
        """Cherche la structure des chambres."""
        if depth > max_depth:
            return None

        if isinstance(data, dict):
            for key, value in data.items():
                key_lower = key.lower()
                is_rooms_candidate = any(c.lower() in key_lower for c in self.CANDIDATES['rooms'])

                if is_rooms_candidate:
                    current_path = f"{prefix}.{key}" if prefix else key

                    if isinstance(value, dict) and value:
                        first_key = list(value.keys())[0]
                        first_value = value[first_key]

                        if isinstance(first_value, dict):
                            first_value_keys = [k.lower() for k in first_value.keys()]
                            has_room_indicators = any(
                                any(c.lower() in fk for c in ['roomname', 'room_name', 'name', 'beds', 'roomsize'])
                                for fk in first_value_keys
                            )

                            if has_room_indicators:
                                fields = self._extract_room_fields(first_value)
                                return {
                                    'path': current_path,
                                    'type': 'dict',
                                    'fields': fields
                                }

                    elif isinstance(value, list) and value and isinstance(value[0], dict):
                        first_item = value[0]
                        first_item_keys = [k.lower() for k in first_item.keys()]
                        has_room_indicators = any(
                            any(c.lower() in fk for c in ['roomname', 'room_name', 'name', 'beds', 'roomsize'])
                            for fk in first_item_keys
                        )

                        if has_room_indicators:
                            fields = self._extract_room_fields(first_item)
                            return {
                                'path': current_path,
                                'type': 'list',
                                'fields': fields
                            }

                if isinstance(value, dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_rooms_structure(value, current_path, depth + 1, max_depth)
                    if result:
                        return result
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_rooms_structure(value[0], current_path, depth + 1, max_depth)
                    if result:
                        return result

        return None

    def _extract_room_fields(self, room_data: Dict) -> Dict[str, str]:
        """Extrait les mappings de champs pour une chambre."""
        fields = {}
        room_keys = {k.lower(): k for k in room_data.keys()}

        for field_name, candidates in self.ROOM_CANDIDATES.items():
            for candidate in candidates:
                if candidate.lower() in room_keys:
                    fields[field_name] = room_keys[candidate.lower()]
                    break

        return fields

    def find_reviews_structure(self, data: Any, prefix: str = "", depth: int = 0, max_depth: int = 6) -> Optional[Dict]:
        """Cherche la structure des avis."""
        if depth > max_depth:
            return None

        if isinstance(data, dict):
            for key, value in data.items():
                key_lower = key.lower()
                is_reviews_candidate = any(c.lower() in key_lower for c in self.CANDIDATES['reviews'])

                if is_reviews_candidate and isinstance(value, list) and value:
                    if isinstance(value[0], dict):
                        first_item = value[0]
                        first_item_keys = [k.lower() for k in first_item.keys()]

                        has_review_indicators = any(
                            any(c.lower() in fk for c in ['rating', 'reviewtext', 'review_text', 'text', 'author', 'travellername'])
                            for fk in first_item_keys
                        )

                        if has_review_indicators:
                            current_path = f"{prefix}.{key}" if prefix else key
                            fields = self._extract_review_fields(first_item)
                            return {
                                'path': current_path,
                                'type': 'list',
                                'fields': fields
                            }

                if isinstance(value, dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_reviews_structure(value, current_path, depth + 1, max_depth)
                    if result:
                        return result
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_reviews_structure(value[0], current_path, depth + 1, max_depth)
                    if result:
                        return result

        return None

    def _extract_review_fields(self, review_data: Dict) -> Dict[str, str]:
        """Extrait les mappings de champs pour un avis."""
        fields = {}
        review_keys = {k.lower(): k for k in review_data.keys()}

        for field_name, candidates in self.REVIEW_CANDIDATES.items():
            for candidate in candidates:
                if candidate.lower() in review_keys:
                    fields[field_name] = review_keys[candidate.lower()]
                    break

        return fields

    def find_amenities_structure(self, data: Any, prefix: str = "", depth: int = 0, max_depth: int = 6) -> Optional[Dict]:
        """Cherche la structure des equipements."""
        if depth > max_depth:
            return None

        if isinstance(data, dict):
            for key, value in data.items():
                key_lower = key.lower()
                is_amenities_candidate = any(c.lower() in key_lower for c in self.CANDIDATES['amenities'])

                if is_amenities_candidate:
                    current_path = f"{prefix}.{key}" if prefix else key

                    if isinstance(value, dict):
                        for sub_key, sub_value in value.items():
                            if isinstance(sub_value, list) and sub_value:
                                if isinstance(sub_value[0], dict):
                                    first_item = sub_value[0]
                                    label_key = None
                                    data_key = None
                                    for k in first_item.keys():
                                        if k.lower() in ['label', 'category', 'name', 'title']:
                                            label_key = k
                                        if k.lower() in ['data', 'items', 'values', 'amenities']:
                                            data_key = k

                                    if label_key and data_key:
                                        return {
                                            'path': f"{current_path}.{sub_key}",
                                            'type': 'list_of_lists',
                                            'data_key': data_key,
                                            'label_key': label_key
                                        }

                    elif isinstance(value, list) and value:
                        if isinstance(value[0], str):
                            return {
                                'path': current_path,
                                'type': 'simple_list'
                            }

                if isinstance(value, dict):
                    current_path = f"{prefix}.{key}" if prefix else key
                    result = self.find_amenities_structure(value, current_path, depth + 1, max_depth)
                    if result:
                        return result

        return None

    # ------------------------------------------------------------------
    # Price detection (generic — works for any OTA without hardcoding)
    # ------------------------------------------------------------------

    # Fields that indicate an item is a ROOM (not a hotel listing)
    ROOM_INDICATOR_FIELDS = [
        'roomname', 'room_name', 'roomcode', 'room_code', 'roomsize',
        'room_size', 'roomviewname', 'bedcount', 'bed_count', 'maxguest',
        'max_guest', 'beds', 'bedroomcount', 'roomtypename',
    ]
    # Fields that indicate an item is a HOTEL LISTING (not a room)
    HOTEL_INDICATOR_FIELDS = [
        'starrating', 'star_rating', 'propertytype', 'property_type',
        'checkintime', 'checkouttime', 'hotelname', 'hotel_name',
    ]

    def find_price_structure(self, data: Any, prefix: str = "",
                             depth: int = 0, max_depth: int = 8) -> Optional[Dict]:
        """
        Collect ALL lists that contain pricing data, score each candidate,
        and return the one that most likely represents hotel rooms (not
        search results or hotel listings).
        """
        candidates = []
        self._collect_price_candidates(data, "", candidates, 0, max_depth)

        if not candidates:
            return None

        # Score each candidate
        best = None
        best_score = -999
        for cand in candidates:
            score = self._score_price_candidate(cand)
            if score > best_score:
                best_score = score
                best = cand

        return best

    def _collect_price_candidates(self, data: Any, prefix: str,
                                   candidates: List[Dict],
                                   depth: int, max_depth: int):
        """Recursively find all lists whose items contain pricing data."""
        if depth > max_depth:
            return

        if isinstance(data, dict):
            for key, value in data.items():
                current = f"{prefix}.{key}" if prefix else key

                if isinstance(value, list) and len(value) >= 1 and isinstance(value[0], dict):
                    price_config = self._detect_pricing_in_item(value[0])
                    if price_config:
                        room_name = self._find_room_name_key(value[0])
                        room_code = self._find_room_code_key(value[0])
                        item_keys_lower = {k.lower() for k in value[0].keys()}
                        candidate = {
                            'rooms_path': current,
                            'room_name_key': room_name,
                            'list_length': len(value),
                            'item_keys_lower': item_keys_lower,
                        }
                        if room_code:
                            candidate['room_code_key'] = room_code
                        candidate.update(price_config)
                        candidates.append(candidate)

                if isinstance(value, dict):
                    self._collect_price_candidates(value, current, candidates, depth + 1, max_depth)
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    self._collect_price_candidates(value[0], current, candidates, depth + 1, max_depth)

    def _score_price_candidate(self, cand: Dict) -> int:
        """
        Score a pricing candidate. Higher = more likely to be hotel rooms.
        - Room-like fields (roomName, bedCount): big bonus
        - Hotel-like fields (starRating, address): penalty (search results)
        - Short lists (<=12): bonus (rooms); long lists (>20): penalty (search)
        - More price fields: bonus
        """
        score = 0
        item_keys = cand.get('item_keys_lower', set())

        # Room indicators: strong positive signal
        for rif in self.ROOM_INDICATOR_FIELDS:
            if any(rif in ik for ik in item_keys):
                score += 5

        # Hotel indicators: penalty only for LONG lists (search results).
        # Short lists with hotel fields are fine (single-property room listings).
        length = cand.get('list_length', 0)
        if length > 15:
            for hif in self.HOTEL_INDICATOR_FIELDS:
                if any(hif in ik for ik in item_keys):
                    score -= 3

        # List length: rooms are typically 2-12, search results are 20+
        if length <= 12:
            score += 3
        elif length > 20:
            score -= 5

        # Price fields count
        if cand.get('mode') == 'details_array':
            score += 2 * len(cand.get('key_mapping', {}))
        elif cand.get('mode') == 'direct':
            score += 2 * len(cand.get('fields', {}))
            # Prefer candidates where price fields are directly on the item
            # (shorter paths = data is more directly accessible).
            # This breaks ties between nested vs direct candidates.
            for field_path in cand.get('fields', {}).values():
                score += max(0, 3 - field_path.count('.'))

        return score

    def _detect_pricing_in_item(self, item: Dict) -> Optional[Dict]:
        """
        Check if a room/rate item contains pricing data.
        Tries each detection strategy and returns the first match.
        """
        # Strategy 1: details_array (Goibibo, MakeMyTrip)
        result = self._find_details_array_in_item(item)
        if result:
            return result

        # Strategy 2: direct price fields (Agoda, Expedia)
        result = self._find_direct_price_in_item(item)
        if result:
            return result

        return None

    def _find_details_array_in_item(self, item: Any,
                                     prefix: str = "", depth: int = 0,
                                     max_depth: int = 8) -> Optional[Dict]:
        """
        Find a 'details' array with {key, amount} items containing
        known price keys (BASE_FARE, TOTAL_AMOUNT, etc.).
        Returns the relative path to the priceMap parent.
        Paths use dot-notation without explicit list indices;
        get_json_path auto-navigates to list[0] for non-digit keys.
        """
        if depth > max_depth:
            return None

        # Handle lists: recurse into first element
        if isinstance(item, list) and item and isinstance(item[0], dict):
            item = item[0]

        if not isinstance(item, dict):
            return None

        for key, value in item.items():
            if isinstance(value, list) and value and isinstance(value[0], dict):
                first = value[0]
                if 'key' in first and 'amount' in first:
                    found_keys = set()
                    for entry in value:
                        if isinstance(entry, dict):
                            ek = entry.get('key', '')
                            if ek in self.PRICE_KEY_MAP:
                                found_keys.add(ek)
                    if found_keys:
                        key_mapping = {k: self.PRICE_KEY_MAP[k] for k in found_keys}
                        # prefix = path to the dict containing this list (plan dict)
                        # price_plan_path = parent of plan dict = priceMap
                        price_plan_path = prefix.rsplit('.', 1)[0] if '.' in prefix else ''
                        return {
                            'mode': 'details_array',
                            'price_plan_path': price_plan_path,
                            'details_key': key,
                            'key_mapping': key_mapping,
                        }

            current = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                result = self._find_details_array_in_item(value, current, depth + 1, max_depth)
                if result:
                    return result
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                result = self._find_details_array_in_item(value[0], current, depth + 1, max_depth)
                if result:
                    return result

        return None

    def _find_direct_price_in_item(self, item: Any,
                                    prefix: str = "", depth: int = 0,
                                    max_depth: int = 8) -> Optional[Dict]:
        """
        Find direct price fields on or near the room item.
        Builds FULL paths relative to the room item at the point of discovery,
        so no post-hoc path adjustment is needed (which caused doubling).
        """
        if depth > max_depth:
            return None

        # Handle lists: recurse into first element
        if isinstance(item, list) and item and isinstance(item[0], dict):
            return self._find_direct_price_in_item(item[0], prefix, depth, max_depth)

        if not isinstance(item, dict):
            return None

        # Collect all keys at this level (case-insensitive)
        item_keys = {k.lower(): k for k in item.keys()}

        found_fields = {}
        for price_field, candidates in self.DIRECT_PRICE_CANDIDATES.items():
            for cand in candidates:
                if cand.lower() in item_keys:
                    actual_key = item_keys[cand.lower()]
                    val = item[actual_key]
                    # Build the full path from the room item root
                    full_path = f"{prefix}.{actual_key}" if prefix else actual_key

                    if isinstance(val, (int, float)) and val > 0:
                        found_fields[price_field] = full_path
                        break
                    elif isinstance(val, dict):
                        for sk, sv in val.items():
                            if isinstance(sv, (int, float)) and sv > 0:
                                found_fields[price_field] = f"{full_path}.{sk}"
                                break
                        if price_field in found_fields:
                            break
                    elif isinstance(val, str):
                        # Extract numeric value from formatted string like "27 €"
                        import re
                        num_str = re.sub(r'[^0-9.,]', '', val)
                        if num_str:
                            try:
                                # Handle European decimal format
                                if ',' in num_str and '.' in num_str:
                                    num = float(num_str.replace('.', '').replace(',', '.'))
                                elif ',' in num_str:
                                    num = float(num_str.replace(',', '.'))
                                else:
                                    num = float(num_str)
                                if num > 0:
                                    found_fields[price_field] = full_path
                                    break
                            except ValueError:
                                pass

        if len(found_fields) >= 1:
            return {
                'mode': 'direct',
                'fields': found_fields,
            }

        # Recurse into nested dicts and lists — paths are already built
        # inside the recursion via prefix, no adjustment needed here.
        for key, value in item.items():
            current = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                result = self._find_direct_price_in_item(value, current, depth + 1, max_depth)
                if result:
                    return result
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                result = self._find_direct_price_in_item(value[0], current, depth + 1, max_depth)
                if result:
                    return result

        return None

    def _find_room_name_key(self, item: Dict) -> str:
        """Find the key that holds the room name."""
        candidates = ['roomname', 'room_name', 'name', 'title', 'roomtypename',
                      'roomtype_name', 'listingname']
        item_keys = {k.lower(): k for k in item.keys()}
        for cand in candidates:
            if cand.lower() in item_keys:
                return item_keys[cand.lower()]
        return ''

    def _find_room_code_key(self, item: Dict) -> str:
        """Find the key that holds the room code/id."""
        candidates = ['roomcode', 'room_code', 'roomid', 'room_id', 'id',
                      'vendorrateplancode', 'rateplancode']
        item_keys = {k.lower(): k for k in item.keys()}
        for cand in candidates:
            if cand.lower() in item_keys:
                return item_keys[cand.lower()]
        return ''

    def find_currency(self, data: Any, prefix: str = "",
                      depth: int = 0, max_depth: int = 7) -> Optional[str]:
        """Find the currency field path in the JSON data."""
        if depth > max_depth:
            return None

        if isinstance(data, dict):
            for key, value in data.items():
                key_lower = key.lower()
                current = f"{prefix}.{key}" if prefix else key

                if key_lower in ['currency', 'currencycode', 'currency_code']:
                    if isinstance(value, str) and len(value) <= 5:
                        return current
                elif key_lower == 'currencyinfo' and isinstance(value, dict):
                    if 'code' in value:
                        return f"{current}.code"

                if isinstance(value, dict):
                    result = self.find_currency(value, current, depth + 1, max_depth)
                    if result:
                        return result
                elif isinstance(value, list) and value and isinstance(value[0], dict):
                    result = self.find_currency(value[0], current, depth + 1, max_depth)
                    if result:
                        return result

        return None

    def _parse_google_batchexecute(self, raw: str) -> dict:
        """Parse Google Hotels price offers for mapping discovery."""
        import re

        text = raw.lstrip()
        if text.startswith(")]}'"):
            text = text[4:].lstrip()

        price_pattern = re.compile(
            r'\\"([A-Z]{3})[\s\u00a0]+([0-9][0-9,.]*)\\",null,'
            r'([0-9]+(?:\.[0-9]+)?)'
        )
        name_pattern = re.compile(r'\\"/g/[^"]+\\",\\"([^"]+)\\"')

        hotels = []
        seen = set()
        for match in price_pattern.finditer(text):
            currency = match.group(1)
            raw_price = float(match.group(3))
            if raw_price <= 0 or raw_price > 50000000:
                continue

            context = text[max(0, match.start() - 5000):match.start()]
            names = name_pattern.findall(context)
            name = names[-1].strip() if names else "Google Hotels"
            key = (name.lower(), currency, round(raw_price, 2))
            if key in seen:
                continue
            seen.add(key)
            hotels.append({
                "name": name,
                "displayPrice": raw_price,
                "currency": currency,
            })

        return {"google_hotels": hotels} if hotels else {}

    def analyze_ota(self, files: List[Path]) -> Optional[Dict]:
        """
        Analyze ALL files for an OTA and build a complete mapping.
        Different data (details, prices, reviews) may live in different files
        because modern OTAs split data across multiple API endpoints.
        """
        # Load all files, sorted by size descending (biggest = most data)
        file_data = {}
        for fp in sorted(files, key=lambda p: p.stat().st_size, reverse=True):
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    raw = f.read()

                # Detect Google Travel/Hotels batchexecute format. Depending
                # on the endpoint, the body may start with )]}', or directly
                # contain the wrb.fr envelope.
                stripped = raw.lstrip()
                if stripped.startswith(")]}'") or '"wrb.fr"' in stripped[:200]:
                    data = self._parse_google_batchexecute(raw)
                else:
                    data = json.loads(raw)

                # Unwrap GraphQL responses
                if isinstance(data, list) and data and isinstance(data[0], dict):
                    data = data[0]
                if data:
                    file_data[fp] = data
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

        if not file_data:
            return None

        mapping = {}

        # --- Hotel fields: find the file with the most hotel detail fields ---
        best_hotel_file = None
        best_count = 0
        for fp, data in file_data.items():
            count = sum(1 for fn, cands in self.CANDIDATES.items()
                        if fn not in ['rooms', 'reviews', 'amenities']
                        and self.find_best_path(data, cands))
            if count > best_count:
                best_count = count
                best_hotel_file = fp

        if best_hotel_file:
            data = file_data[best_hotel_file]
            for field_name, candidates in self.CANDIDATES.items():
                if field_name in ['rooms', 'reviews', 'amenities']:
                    continue
                path = self.find_best_path(data, candidates)
                if path:
                    mapping[field_name] = path

        # --- Rooms: find the file with room structure ---
        for fp, data in file_data.items():
            rooms = self.find_rooms_structure(data)
            if rooms:
                mapping['rooms'] = rooms
                break

        # --- Reviews ---
        for fp, data in file_data.items():
            reviews = self.find_reviews_structure(data)
            if reviews:
                mapping['reviews'] = reviews
                break

        # --- Amenities ---
        for fp, data in file_data.items():
            amenities = self.find_amenities_structure(data)
            if amenities:
                mapping['amenities'] = amenities
                break

        # --- Prices: scan ALL files, collect ALL candidates, pick the best ---
        all_price_candidates = []
        for fp, data in file_data.items():
            file_candidates = []
            self._collect_price_candidates(data, "", file_candidates, 0, 8)
            for cand in file_candidates:
                cand['_source_data'] = data
                all_price_candidates.append(cand)

        if all_price_candidates:
            best = max(all_price_candidates, key=lambda c: self._score_price_candidate(c))
            source_data = best.pop('_source_data', None)

            # Clean up internal fields before storing
            best.pop('item_keys_lower', None)
            best.pop('list_length', None)
            mapping['prices'] = best

            # Find currency from the source file, then any file
            currency_path = self.find_currency(source_data) if source_data else None
            if not currency_path:
                for fp2, data2 in file_data.items():
                    cur = self.find_currency(data2)
                    if cur:
                        currency_path = cur
                        break
            if currency_path:
                mapping['prices']['currency_path'] = currency_path

        return mapping

    def generate_yaml(self, ota_name: str, mapping: Dict) -> str:
        """Genere le contenu YAML."""
        lines = []
        lines.append(f"ota_name: {ota_name}")
        lines.append(f"file_pattern: \"*{ota_name}*body.json\"")
        lines.append("")

        hotel_fields = {}
        for field in ['name', 'ota_id', 'address', 'description', 'star_rating',
                      'property_type', 'checkin_time', 'checkout_time']:
            if field in mapping:
                hotel_fields[field] = mapping[field]

        if hotel_fields:
            lines.append("hotel_fields:")
            for field, path in hotel_fields.items():
                lines.append(f"  {field}: {path}")
            lines.append("")

        rating_fields = {}
        for field in ['cumulative_rating', 'review_count']:
            if field in mapping:
                key = 'cumulative' if field == 'cumulative_rating' else 'count'
                rating_fields[key] = mapping[field]

        if rating_fields:
            lines.append("rating:")
            for field, path in rating_fields.items():
                lines.append(f"  {field}: {path}")
            lines.append("")

        if 'rooms' in mapping:
            rooms = mapping['rooms']
            lines.append("rooms:")
            lines.append(f"  path: {rooms['path']}")
            lines.append(f"  type: {rooms['type']}")
            if rooms.get('fields'):
                lines.append("  fields:")
                for field, key in rooms['fields'].items():
                    lines.append(f"    {field}: {key}")
            lines.append("")

        if 'reviews' in mapping:
            reviews = mapping['reviews']
            lines.append("reviews:")
            lines.append(f"  path: {reviews['path']}")
            lines.append(f"  type: {reviews['type']}")
            if reviews.get('fields'):
                lines.append("  fields:")
                for field, key in reviews['fields'].items():
                    lines.append(f"    {field}: {key}")
            lines.append("")

        if 'amenities' in mapping:
            amenities = mapping['amenities']
            lines.append("amenities:")
            lines.append(f"  path: {amenities['path']}")
            lines.append(f"  type: {amenities['type']}")
            if amenities.get('data_key'):
                lines.append(f"  data_key: {amenities['data_key']}")
            if amenities.get('label_key'):
                lines.append(f"  label_key: {amenities['label_key']}")
            lines.append("")

        if 'prices' in mapping:
            prices = mapping['prices']
            lines.append("prices:")
            lines.append(f"  rooms_path: {prices.get('rooms_path', '')}")
            if prices.get('room_name_key'):
                lines.append(f"  room_name_key: {prices['room_name_key']}")
            if prices.get('room_code_key'):
                lines.append(f"  room_code_key: {prices['room_code_key']}")
            if prices.get('currency_path'):
                lines.append(f"  currency_path: {prices['currency_path']}")
            lines.append(f"  mode: {prices.get('mode', 'direct')}")

            if prices.get('mode') == 'details_array':
                lines.append(f"  price_plan_path: {prices.get('price_plan_path', '')}")
                lines.append(f"  details_key: {prices.get('details_key', 'details')}")
                if prices.get('key_mapping'):
                    lines.append("  key_mapping:")
                    for k, v in prices['key_mapping'].items():
                        lines.append(f"    {k}: {v}")
            elif prices.get('mode') == 'direct':
                if prices.get('fields'):
                    lines.append("  fields:")
                    for k, v in prices['fields'].items():
                        lines.append(f"    {k}: {v}")
            lines.append("")

        return '\n'.join(lines)

    def run(self, quiet: bool = False):
        """Execute la generation automatique pour toutes les OTA.
        quiet=True suppresses banner/summary prints (used by vae_bridge)."""
        if not quiet:
            print("=" * 70)
            print("GENERATEUR AUTOMATIQUE DE MAPPINGS YAML")
            print("=" * 70)

        ota_files = self.find_json_files()

        if not ota_files:
            if not quiet:
                print("\nAucun fichier JSON trouve dans data/api_discovery/")
                print("Lancez d'abord l'api_analyzer pour capturer des donnees.")
            return

        if not quiet:
            print(f"\n{len(ota_files)} OTA(s) trouvee(s) : {', '.join(ota_files.keys())}")

        for ota_name, files in ota_files.items():
            if not quiet:
                print(f"\n{'='*60}")
                print(f"Analyse : {ota_name} ({len(files)} fichiers)")
                print(f"{'='*60}")

            mapping = self.analyze_ota(files)

            if not mapping:
                if not quiet:
                    print("  [ECHEC] Aucune donnee exploitable trouvee")
                continue

            if not quiet:
                print(f"\n  Champs trouves :")
                for field, path in mapping.items():
                    if isinstance(path, str):
                        print(f"    OK {field}: {path}")
                    elif isinstance(path, dict):
                        if field == 'prices':
                            mode = path.get('mode', '?')
                            rooms_p = path.get('rooms_path', '?')
                            print(f"    OK {field}: {rooms_p} (mode: {mode})")
                        else:
                            print(f"    OK {field}: {path.get('path', 'N/A')} (type: {path.get('type', 'N/A')})")

            yaml_content = self.generate_yaml(ota_name, mapping)

            output_file = self.output_dir / f"{ota_name}.yaml"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(yaml_content)

            if not quiet:
                print(f"\n  OK Mapping sauvegarde : {output_file}")

        if not quiet:
            print(f"\n{'='*70}")
            print("RESUME")
            print(f"{'='*70}")

            yaml_files = list(self.output_dir.glob("*.yaml"))
            print(f"\n{len(yaml_files)} fichier(s) YAML dans config/ota_mappings/ :")
            for f in sorted(yaml_files):
                print(f"  - {f.name}")

            print(f"\nPour tester l'extraction :")
            print(f'  python "C:\\Users\\Sensisky\\Downloads\\OTAGUARD QWEN V2\\src\\extractors\\generic_extractor.py"')


def main():
    generator = AutoMappingGenerator()
    generator.run()


if __name__ == "__main__":
    main()