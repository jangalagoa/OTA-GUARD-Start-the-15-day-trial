"""
Module de gestion du navigateur Brave pour OTA Guard VAE.
Detecte Brave deja lance, le ferme proprement si necessaire,
et le relance avec le flag de debug + restauration de session.
"""

import asyncio
import os
import platform
import subprocess
import time
from pathlib import Path
from typing import List, Dict, Optional, Any
import aiohttp
import yaml


class BrowserManager:
    """
    Gestionnaire du navigateur Brave.
    Gere automatiquement le lancement avec le flag de debug.
    Restaure la session precedente.
    """

    def __init__(self, debug_port: int = 9222, config_file: str = ""):
        from vae.config import OTA_DOMAINS_FILE
        self.debug_port = debug_port
        self.config_file = Path(config_file) if config_file else OTA_DOMAINS_FILE
        self.ota_domains = []
        self.detection_keywords = []
        self.browser_ws_url = None
        self.is_connected = False
        self._load_config()

    def _load_config(self):
        """Charge la configuration depuis le fichier YAML."""
        if not self.config_file.exists():
            raise FileNotFoundError(
                f"Fichier de configuration introuvable : {self.config_file}"
            )

        with open(self.config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        self.ota_domains = [d.lower() for d in config.get('ota_domains', [])]
        self.detection_keywords = [k.lower() for k in config.get('detection_keywords', [])]

        print(f"Configuration chargee : {len(self.ota_domains)} OTA, {len(self.detection_keywords)} mots-cles")

    async def _get_brave_path(self) -> Optional[str]:
        """Detect installed Brave Browser (required — no other browser supported)."""
        system = platform.system()

        if system == "Windows":
            pf64 = os.environ.get("ProgramW6432", "C:/Program Files")
            pf32 = os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")
            la = os.environ.get("LOCALAPPDATA", "")
            candidates = [
                f"{pf64}/BraveSoftware/Brave-Browser/Application/brave.exe",
                f"{pf32}/BraveSoftware/Brave-Browser/Application/brave.exe",
                f"{la}/BraveSoftware/Brave-Browser/Application/brave.exe",
            ]
            for path_str in candidates:
                if Path(path_str).exists():
                    print(f"Brave detecte: {path_str}")
                    return path_str
            return None

        elif system == "Darwin":
            brave = "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
            if Path(brave).exists():
                print(f"Brave detecte: {brave}")
                return brave
            return None

        else:
            for cmd in ["brave-browser", "brave"]:
                result = subprocess.run(["which", cmd], capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"Brave detecte: {cmd}")
                    return result.stdout.strip()
            return None

    async def _is_port_active(self) -> bool:
        """Verifie si le port de debug est actif."""
        url = f"http://127.0.0.1:{self.debug_port}/json/version"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as response:
                    return response.status == 200
        except (aiohttp.ClientError, asyncio.TimeoutError):
            return False

    # Brave process names for detection
    _BROWSER_PROCESSES = {
        "Windows": ["brave.exe"],
        "Darwin": ["Brave Browser"],
        "Linux": ["brave", "brave-browser"],
    }

    def _is_brave_running(self) -> bool:
        """Verifie si un processus navigateur (Brave/Chrome/Edge) est en cours."""
        system = platform.system()
        try:
            process_names = self._BROWSER_PROCESSES.get(system, ["brave"])
            if system == "Windows":
                for proc in process_names:
                    result = subprocess.run(
                        ["tasklist", "/FI", f"IMAGENAME eq {proc}"],
                        capture_output=True, text=True, shell=True
                    )
                    if proc in result.stdout:
                        return True
                return False
            else:
                for proc in process_names:
                    result = subprocess.run(["pgrep", "-f", proc], capture_output=True)
                    if result.returncode == 0:
                        return True
                return False
        except Exception:
            return False

    def _close_brave_gracefully(self):
        """
        Ferme le navigateur proprement (Brave/Chrome/Edge).
        Envoie un signal de fermeture puis attend que TOUS les processus
        soient termines avant de relancer avec --restore-last-session.
        """
        system = platform.system()
        try:
            if system == "Windows":
                for proc in self._BROWSER_PROCESSES.get("Windows", ["brave.exe"]):
                    subprocess.run(["taskkill", "/IM", proc],
                                   capture_output=True, shell=True)
            elif system == "Darwin":
                for proc in self._BROWSER_PROCESSES.get("Darwin", ["Brave Browser"]):
                    subprocess.run(["pkill", proc], capture_output=True)
            else:
                for proc in self._BROWSER_PROCESSES.get("Linux", ["brave"]):
                    subprocess.run(["pkill", proc], capture_output=True)

            # Poll until all Brave processes are gone (max 15 seconds)
            print("Fermeture de Brave en cours...")
            max_wait = 15
            waited = 0
            while waited < max_wait:
                time.sleep(0.5)
                waited += 0.5
                if not self._is_brave_running():
                    print(f"Brave ferme proprement ({waited:.1f}s)")
                    return

            # Fallback: processes still running after 15s
            print(f"[ATTENTION] Brave toujours en cours apres {max_wait}s, fermeture forcee...")
            if system == "Windows":
                subprocess.run(
                    ["taskkill", "/IM", proc, "/F"],
                    capture_output=True,
                    shell=True
                )
            elif system == "Darwin":
                subprocess.run(["pkill", "-9", proc], capture_output=True)
            else:
                subprocess.run(["pkill", "-9", proc], capture_output=True)
            time.sleep(2)

        except Exception as e:
            print(f"Erreur lors de la fermeture de Brave: {e}")

    def _launch_brave_with_debug(self, brave_path: str):
        """
        Lance Brave avec le flag de debug et restauration de session.
        
        Args:
            brave_path: Chemin de l'executable Brave
        """
        args = [
            brave_path,
            f"--remote-debugging-port={self.debug_port}",
            "--restore-last-session",  # Restaure les onglets de la session precedente
            # Akamai-fronted OTAs (MakeMyTrip) emit malformed HTTP/2 frames
            # that Chromium rejects with ERR_HTTP2_PROTOCOL_ERROR on some
            # machines (Firefox tolerates or falls back to HTTP/1.1).
            # Forcing HTTP/1.1 fixes those machines and changes nothing for
            # capture: CDP interception is protocol-agnostic (verified
            # 2026-08-15 — full MMT page load + VAE captures while disabled).
            "--disable-http2",
        ]
        
        print("Lancement de Brave avec le port de debug...")
        
        subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            # Explicit CWD OUTSIDE the OTA Guard install folder: a child
            # process must never inherit a working directory inside it —
            # Windows blocks renaming/deleting a folder that is a running
            # process's CWD (breaks updates and uninstalls).
            cwd=str(Path(brave_path).parent),
        )
        
        # Attendre que le port soit actif
        time.sleep(4)

    async def connect(self) -> bool:
        """
        Se connecte a Brave.
        Si Brave n'est pas lance avec le port de debug :
        1. Ferme Brave proprement s'il est lance
        2. Le relance avec le flag de debug
        3. Restaure la session precedente
        
        Returns:
            True si la connexion a reussi
        """
        brave_path = await self._get_brave_path()
        if not brave_path:
            raise RuntimeError("Brave Browser n'a pas ete trouve.")

        # Verifier si le port de debug est deja actif
        is_port_active = await self._is_port_active()

        if is_port_active:
            print("Brave deja lance avec le port de debug")
        else:
            # Le port n'est pas actif
            if self._is_brave_running():
                print("Brave lance sans le port de debug, redemarrage necessaire...")
                self._close_brave_gracefully()
            
            # Lancer Brave avec le flag de debug
            self._launch_brave_with_debug(brave_path)
            
            # Verifier que le port est maintenant actif
            for i in range(10):
                if await self._is_port_active():
                    break
                await asyncio.sleep(0.5)
            
            if not await self._is_port_active():
                raise RuntimeError("Brave n'a pas demarre avec le port de debug")

        print("Connexion a Brave via l'API CDP...")
        
        # Recuperer l'URL WebSocket du navigateur
        url = f"http://127.0.0.1:{self.debug_port}/json/version"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    response.raise_for_status()
                    version_info = await response.json()
                    self.browser_ws_url = version_info.get("webSocketDebuggerUrl")
                    
                    if self.browser_ws_url:
                        self.is_connected = True
                        print(f"Connecte a Brave avec succes !")
                        print(f"Browser: {version_info.get('Browser', 'Unknown')}")
                        return True
                    else:
                        raise RuntimeError("URL WebSocket non trouvee dans la reponse")
                        
        except Exception as e:
            raise RuntimeError(f"Erreur lors de la connexion a Brave: {e}")

    def _is_ota_url(self, url: str) -> Optional[str]:
        """Verifie si une URL correspond a un OTA."""
        url_lower = url.lower()

        # The CM can move while the listener is already running. Its learned
        # host lives in writable app data, not in the bundled YAML (which may
        # be read-only after installation). Read it at tab-discovery time so
        # an existing OTASheet tab is attached as soon as the host is known.
        try:
            from urllib.parse import urlsplit
            from business import cm_sites

            tab_host = (urlsplit(url).hostname or "").lower()
            if tab_host and tab_host in cm_sites.all_hosts():
                return tab_host
        except (ImportError, OSError, TypeError, ValueError):
            pass

        # Methode 1 : Domaine connu
        for domain in self.ota_domains:
            if domain in url_lower:
                return domain

        # Methode 2 : Mot-cle de detection
        for keyword in self.detection_keywords:
            if keyword in url_lower:
                if "://" in url_lower:
                    domain = url_lower.split("://")[1].split("/")[0]
                    return domain

        return None

    async def get_all_tabs(self) -> List[Dict[str, Any]]:
        """Recupere la liste de tous les onglets ouverts via l'API CDP."""
        if not self.is_connected:
            raise RuntimeError("Navigateur non connecte.")

        url = f"http://127.0.0.1:{self.debug_port}/json/list"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as response:
                    response.raise_for_status()
                    tabs_data = await response.json()
                    
                    tabs = []
                    for tab in tabs_data:
                        if tab.get("type") == "page":
                            tabs.append({
                                "title": tab.get("title", "Sans titre"),
                                "url": tab.get("url", ""),
                                "id": tab.get("id", ""),
                                "webSocketDebuggerUrl": tab.get("webSocketDebuggerUrl", "")
                            })
                    return tabs
                    
        except Exception as e:
            print(f"Erreur lors de la recuperation des onglets: {e}")
            return []

    async def get_ota_tabs(self) -> List[Dict[str, Any]]:
        """Recupere uniquement les onglets correspondant a des OTA."""
        all_tabs = await self.get_all_tabs()
        ota_tabs = []

        for tab in all_tabs:
            url = tab.get("url", "")
            ota_domain = self._is_ota_url(url)
            
            if ota_domain:
                tab["ota_domain"] = ota_domain
                ota_tabs.append(tab)

        return ota_tabs

    async def close(self) -> None:
        """Ferme la connexion (ne ferme pas Brave)."""
        self.is_connected = False
        self.browser_ws_url = None
        print("Connexion au navigateur fermee")


async def main():
    """Fonction de test du module BrowserManager."""
    print("=" * 60)
    print("TEST DU MODULE BROWSER MANAGER")
    print("=" * 60)

    manager = BrowserManager()

    try:
        await manager.connect()
        await asyncio.sleep(1)

        print("\nTous les onglets ouverts:")
        all_tabs = await manager.get_all_tabs()
        for i, tab in enumerate(all_tabs, 1):
            print(f"  {i}. {tab['title']}")
            print(f"     URL: {tab['url']}")

        print("\nOnglets OTA detectes:")
        ota_tabs = await manager.get_ota_tabs()
        if ota_tabs:
            for i, tab in enumerate(ota_tabs, 1):
                print(f"  {i}. {tab['title']}")
                print(f"     Domaine: {tab['ota_domain']}")
                print(f"     URL: {tab['url']}")
        else:
            print("  Aucun onglet OTA detecte")

    except Exception as e:
        print(f"Erreur: {e}")
        import traceback
        traceback.print_exc()

    finally:
        await manager.close()


if __name__ == "__main__":
    asyncio.run(main())
