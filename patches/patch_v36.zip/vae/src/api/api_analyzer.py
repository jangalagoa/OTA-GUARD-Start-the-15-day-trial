"""
Module d'analyse des APIs OTA pour OTA Guard VAE.
Mode ECOUTE TOTALE : capture toutes les requetes sans filtrage.
"""

import asyncio
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import yaml
import aiohttp

from vae.config import DATA_DIR as _VAE_DATA_DIR, HOTEL_CONFIG_FILE as _VAE_HOTEL_FILE


# Configuration du logging
_VAE_LOG_DIR = _VAE_DATA_DIR
_VAE_LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.FileHandler(str(_VAE_DATA_DIR / 'analyzer.log'), encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class HotelConfig:
    """
    Configuration de l'hotel a surveiller.
    """

    def __init__(self, config_file: str = ""):
        self.config_file = Path(config_file) if config_file else _VAE_HOTEL_FILE
        self.name = ""
        self.aliases = []
        self.ota_ids = {}
        self.unique_keywords = []
        self.location = {}
        self.settings = {}
        self._load_config()

    def _load_config(self):
        """Charge la configuration depuis le fichier YAML."""
        if not self.config_file.exists():
            raise FileNotFoundError(
                f"Fichier de configuration hotel introuvable : {self.config_file}\n"
                "Creez le fichier config/hotel.yaml avec les informations de votre hotel."
            )

        with open(self.config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        hotel = config.get('hotel', {})
        self.name = hotel.get('name', '')
        self.aliases = hotel.get('aliases', [])
        self.ota_ids = hotel.get('ota_ids', {})
        self.unique_keywords = hotel.get('unique_keywords', [])
        self.location = hotel.get('location', {})
        self.settings = hotel.get('settings', {})

        logger.info(f"Configuration hotel chargee : {self.name}")
        logger.info(f"  - Aliases : {len(self.aliases)}")
        logger.info(f"  - OTA IDs connus : {sum(1 for v in self.ota_ids.values() if v)}")
        logger.info(f"  - Mots-cles uniques : {len(self.unique_keywords)}")

    def get_all_names(self) -> List[str]:
        """Retourne tous les noms possibles de l'hotel."""
        return [self.name] + self.aliases

    def get_ota_id(self, ota_domain: str) -> Optional[str]:
        """Retourne l'ID de l'hotel pour une OTA donnee."""
        domain_map = {
            'booking.com': 'booking',
            'expedia.com': 'expedia',
            'agoda.com': 'agoda',
            'airbnb.com': 'airbnb',
            'airbnb.fr': 'airbnb',
            'makemytrip.com': 'makemytrip',
            'makemytrip.global': 'makemytrip',
            'goibibo.com': 'goibibo',
            'hotels.com': 'hotels_com',
        }

        ota_key = domain_map.get(ota_domain, ota_domain.replace('.com', '').replace('.fr', '').replace('.global', ''))
        return self.ota_ids.get(ota_key)

    def matches_hotel_name(self, text: str) -> bool:
        """Verifie si un texte correspond au nom de l'hotel."""
        text_lower = text.lower()

        for name in self.get_all_names():
            if name.lower() in text_lower:
                return True

        for keyword in self.unique_keywords:
            if keyword.lower() in text_lower:
                return True

        return False


class ApiAnalyzer:
    """
    Analyseur d'APIs OTA en mode ECOUTE TOTALE.
    Capture TOUTES les requetes JSON sans filtrage de contexte.
    """

    # Seules exclusions : ressources statiques et tracking evidents
    EXCLUDED_EXTENSIONS = [
        '.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico',
        '.woff', '.woff2', '.ttf', '.eot', '.map', '.webp', '.mp4', '.webm',
        '.mp3', '.wav', '.pdf', '.zip', '.gz'
    ]
    
    EXCLUDED_CDN_DOMAINS = [
        'muscache.com',
        'travel-assets.com',
        'adobedtm.com',
        'googleapis.com',
        'gstatic.com',
        'cloudflare.com',
        'akamaihd.net',
        'ibcdn.com',
        'mmtcdn.com',
        'hotelscdn.com',
    ]

    def __init__(self, hotel_config: HotelConfig, output_dir: str = ""):
        self.hotel = hotel_config
        self.output_dir = Path(output_dir) if output_dir else _VAE_DATA_DIR
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Cache des contextes d'onglets (pour info seulement)
        self.tab_contexts = {}
        
        # Statistiques
        self.stats = {
            'total_requests': 0,
            'filtered_out': 0,
            'kept': 0,
            'errors': 0
        }

    async def update_tab_context(self, tab_id: str, tab_url: str, ota_domain: str):
        """
        Met a jour le contexte d'un onglet (pour info seulement).
        """
        hotel_id = self.hotel.get_ota_id(ota_domain)
        is_hotel_page = False
        reason = ""
        
        if hotel_id and hotel_id in tab_url:
            is_hotel_page = True
            reason = f"ID {hotel_id} trouve dans URL"
        elif self.hotel.matches_hotel_name(tab_url):
            is_hotel_page = True
            reason = "Nom hotel trouve dans URL"
        
        self.tab_contexts[tab_id] = {
            'is_hotel_page': is_hotel_page,
            'url': tab_url,
            'reason': reason,
            'ota_domain': ota_domain,
            'hotel_id': hotel_id
        }
        
        if is_hotel_page:
            logger.info(f"Contexte onglet {tab_id[:8]} : PAGE DE L'HOTEL ({reason})")
        else:
            logger.info(f"Contexte onglet {tab_id[:8]} : Autre page ({tab_url[:60]}...)")

    def should_exclude(self, url: str, mime_type: str = '') -> bool:
        """
        Verifie si une requete doit etre exclue.
        Seules les ressources statiques sont exclues.
        """
        url_lower = url.lower()
        
        # Exclure les extensions de fichiers statiques
        for ext in self.EXCLUDED_EXTENSIONS:
            if url_lower.endswith(ext) or f'{ext}?' in url_lower:
                return True
        
        # Exclure les CDN
        for cdn in self.EXCLUDED_CDN_DOMAINS:
            if cdn in url_lower:
                return True
        
        # Exclure si MIME type indique une ressource non-JSON
        if mime_type:
            mime_lower = mime_type.lower()
            if mime_lower and 'json' not in mime_lower and 'javascript' not in mime_lower and 'text' not in mime_lower:
                return True
        
        return False

    def analyze_request(self, request_data: Dict, body: Optional[str] = None) -> Optional[Dict]:
        """
        Analyse une requete capturee.
        Mode ECOUTE TOTALE : accepte tout sauf ressources statiques.
        """
        self.stats['total_requests'] += 1
        
        url = request_data.get('url', '')
        tab_id = request_data.get('tab_id', '')
        ota_domain = request_data.get('ota_domain', '')
        mime_type = request_data.get('mimeType', '')
        
        # Seule exclusion : ressources statiques
        if self.should_exclude(url, mime_type):
            self.stats['filtered_out'] += 1
            return None
        
        # Pas de filtrage de contexte en mode ECOUTE TOTALE
        context = self.tab_contexts.get(tab_id, {})

        # Page URL at REQUEST TIME beats the tab context: the context is
        # only refreshed at startup / new-tab detection, so a tab that
        # navigated (Airbnb listing A opened in a tab showing listing B)
        # kept tagging every capture with the WRONG /rooms/<id> — the root
        # cause of Airbnb prices rotating between listings.
        tab_url = request_data.get('documentURL') or context.get('url', '')

        # Accepter TOUTES les requetes JSON
        self.stats['kept'] += 1

        result = {
            'timestamp': datetime.now().isoformat(),
            'hotel_name': self.hotel.name,
            'ota_domain': ota_domain,
            'tab_url': tab_url,
            'tab_id': request_data.get('tab_id', ''),
            'loaderId': request_data.get('loaderId', ''),
            'is_hotel_page': context.get('is_hotel_page', False),
            'confidence': 'high' if context.get('is_hotel_page') else 'medium',
            'url': url,
            'method': request_data.get('method', ''),
            # D33: the POST payload captured passively by the listener
            # (requestWillBeSent) doit survivre jusqu'au fichier final —
            # it is the proof of WHAT was sent (AddBulkUpdate).
            'post_data': request_data.get('postData', '') or '',
            'body': body
        }
        
        self._save_result(result)
        
        return result

    def _save_result(self, result: Dict):
        """Sauvegarde le resultat dans un fichier JSON."""
        # Microseconds in the stamp: reload bursts produce several captures
        # within the SAME second, and a second-resolution name made them
        # overwrite each other — the proven loss path for the big Expedia
        # price graphql (one file survived out of 8 saves, the 240 KB room
        # list included). Uniqueness is mandatory, ordering stays mtime-based.
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        ota = result['ota_domain'].replace('.', '_').replace('/', '_')
        filename = f"{timestamp}_{ota}.json"
        filepath = self.output_dir / filename

        body = result.get('body', '')
        if body and len(body) > 100:
            body_filename = f"{timestamp}_{ota}_body.json"
            body_filepath = self.output_dir / body_filename
            with open(body_filepath, 'w', encoding='utf-8') as f:
                f.write(body)
            result['body_file'] = str(body_filepath)
            result['body'] = None

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        logger.info(f"Sauvegarde : {filename} (body: {'separe' if result.get('body_file') else 'inline'})")

    def get_stats(self) -> Dict:
        """Retourne les statistiques de l'analyseur."""
        return self.stats.copy()

    def print_stats(self):
        """Affiche les statistiques."""
        print("\n" + "=" * 60)
        print("STATISTIQUES DE L'ANALYSEUR (MODE ECOUTE TOTALE)")
        print("=" * 60)
        print(f"Total requetes traitees : {self.stats['total_requests']}")
        print(f"Filtrees (statiques)    : {self.stats['filtered_out']}")
        print(f"Gardees (API)           : {self.stats['kept']}")
        print(f"Erreurs                 : {self.stats['errors']}")
        print("=" * 60)


async def main():
    """
    Fonction principale : ECOUTE TOTALE de toutes les OTA.
    """
    from vae.src.browser.browser_manager import BrowserManager
    from vae.src.browser.network_interceptor import NetworkInterceptor

    print("=" * 60)
    print("ANALYSEUR API - MODE ECOUTE TOTALE")
    print("=" * 60)

    hotel_config = HotelConfig()
    analyzer = ApiAnalyzer(hotel_config)
    manager = BrowserManager()

    try:
        await manager.connect()
        await asyncio.sleep(1)

        from vae.config import get_setting
        monitor_interval = int(get_setting('tab_monitor.check_interval_seconds', 10))

        ota_tabs = await manager.get_ota_tabs()

        if not ota_tabs:
            print("\n" + "=" * 60)
            print("AUCUN ONGLET OTA OUVERT POUR LE MOMENT")
            print("Ouvrez des onglets OTA dans le navigateur.")
            print(f"Verification automatique toutes les {monitor_interval}s...")
            print("=" * 60 + "\n")

        # Wait for OTA tabs to appear instead of exiting
        while not ota_tabs:
            await asyncio.sleep(monitor_interval)
            try:
                ota_tabs = await manager.get_ota_tabs()
            except Exception:
                pass

        print(f"\n{len(ota_tabs)} onglet(s) OTA detecte(s) :")
        for i, tab in enumerate(ota_tabs, 1):
            print(f"  {i}. {tab['ota_domain']} - {tab['title'][:50]}")
        
        print("\nInitialisation des contextes d'onglets...")
        for tab in ota_tabs:
            await analyzer.update_tab_context(
                tab['id'],
                tab['url'],
                tab['ota_domain']
            )

        interceptor = NetworkInterceptor(manager.debug_port)

        # Dynamic tab lookup: updated when new tabs are detected
        tab_ota_map = {tab['id']: tab['ota_domain'] for tab in ota_tabs}

        async def on_response(captured):
            # NetworkInterceptor already retrieves the response body after
            # loadingFinished. Fetching it a second time is unnecessary and
            # can make CDP return an empty/error response on some tabs.
            body = captured.get('body')

            captured['ota_domain'] = tab_ota_map.get(captured['tab_id'], 'unknown')
            # Offload analysis + file writes: a synchronous save (some bodies
            # are 1 MB+) blocks the whole asyncio loop, delays every tab's
            # websocket processing, and by the time the delayed body re-ask
            # fires Chrome has already evicted the big price payloads.
            try:
                await asyncio.get_event_loop().run_in_executor(
                    None, analyzer.analyze_request, captured, body)
            except Exception as e:
                print(f"[ANALYZE] analyze_request failed: {e}", flush=True)

        interceptor.on_response_received = on_response

        tasks = await interceptor.start_listening(ota_tabs)

        # ── Initial one-time refresh of every OTA tab ──────────────────
        # The listener only reaches this point once Brave is up and the
        # OTA tabs exist. Waiting >= 30 s more lets every restored tab
        # finish loading, THEN one hard reload (Ctrl+F5-like, ignoreCache)
        # refreshes them all: without this the FIRST scan reads whatever
        # captures are left from a previous session — stale or missing —
        # and silently skips OTAs (user request 2026-08-16).
        initial_refresh_delay = float(get_setting(
            'auto_refresh.initial_delay_seconds', 30))

        async def initial_refresh_all():
            await asyncio.sleep(initial_refresh_delay)
            reloaded = 0
            for tid in list(interceptor.active_connections.keys()):
                try:
                    if await interceptor.reload_tab(tid):
                        reloaded += 1
                except Exception:
                    pass
            ts = datetime.now().strftime('%H:%M:%S')
            print(f"[REFRESH INITIAL {ts}] {reloaded} onglet(s) OTA "
                  f"recharge(s) — captures fraiches pour le 1er scan",
                  flush=True)

        asyncio.create_task(initial_refresh_all())

        # Start auto-refresh (CDP Page.reload = F5, undetectable)
        # Intervals are configurable via settings.yaml
        # Auto-refresh stays ON — randomized 1-2 h per tab, visibility-gated
        # (see network_interceptor.start_auto_refresh): the reload only fires
        # while the tab is actually visible, exactly like a human pressing F5.
        ar_enabled = get_setting('auto_refresh.enabled', True)
        ar_min = float(get_setting('auto_refresh.min_interval_seconds', 3600))
        ar_max = float(get_setting('auto_refresh.max_interval_seconds', 7200))
        if ar_enabled:
            interceptor.start_auto_refresh(ota_tabs, min_delay=ar_min, max_delay=ar_max)

        # Monitor for newly opened OTA tabs (dynamic detection)
        # monitor_interval already defined above

        async def monitor_new_tabs():
            """Periodically check for new OTA tabs and connect to them.

            Also RECONNECTS known tabs whose listener socket died: Brave's
            memory saver discards background tabs, which closes their
            debugger sockets — without this, a discarded OTA tab kept a
            dead connection forever and every scan read its last old
            capture (Goibibo case, 2026-08-16)."""
            while True:
                await asyncio.sleep(monitor_interval)
                try:
                    current_tabs = await manager.get_ota_tabs()
                    for tab in current_tabs:
                        tab_id = tab.get("id", "")
                        if not tab_id:
                            continue

                        # Known AND still connected → nothing to do
                        if tab_id in tab_ota_map and \
                           tab_id in interceptor.active_connections:
                            continue

                        ws_url = tab.get("webSocketDebuggerUrl", "")
                        if not ws_url:
                            continue

                        # Connect to the new or reconnected tab
                        if await interceptor.connect_to_tab(ws_url, tab_id):
                            await interceptor.enable_network_listening(tab_id)
                            asyncio.create_task(interceptor.listen_to_tab(tab_id))

                            was_known = tab_id in tab_ota_map
                            tab_ota_map[tab_id] = tab.get("ota_domain", "unknown")
                            await analyzer.update_tab_context(
                                tab_id, tab.get("url", ""),
                                tab.get("ota_domain", "unknown")
                            )
                            ts = datetime.now().strftime('%H:%M:%S')
                            kind = "RECONNECTE" if was_known else "NOUVEL ONGLET"
                            print(f"[{kind} {ts}] {tab.get('ota_domain', '?')} "
                                  f"ecoute active", flush=True)
                except Exception:
                    pass

        monitor_task = asyncio.create_task(monitor_new_tabs())

        print("\n" + "=" * 60)
        print("ECOUTE ACTIVE + AUTO-REFRESH + DETECTION NOUVEAUX ONGLETS")
        print("Ouvrez de nouveaux onglets OTA - ils seront detectes automatiquement")
        print("Appuyez sur Ctrl+C pour arreter")
        print("=" * 60 + "\n")

        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            print("\n\nArret de l'ecoute...")

        monitor_task.cancel()
        await interceptor.stop_listening()
        analyzer.print_stats()

    except Exception as e:
        print(f"Erreur: {e}")
        import traceback
        traceback.print_exc()

    finally:
        await manager.close()


if __name__ == "__main__":
    asyncio.run(main())
