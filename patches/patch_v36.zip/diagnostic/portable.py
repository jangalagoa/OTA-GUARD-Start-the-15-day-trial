"""Launch the vendor diagnostic independently of the application entry point."""
import argparse
import ast
import sys
import types
from pathlib import Path


def configure(app_dir, data_dir, output_dir):
    """Bind read-only target paths without importing core/__init__ or main.py."""
    app_dir, data_dir, output_dir = map(lambda p: Path(p).resolve(), (app_dir, data_dir, output_dir))
    if not app_dir.is_dir() or not data_dir.is_dir():
        raise ValueError("Application and data folders must exist")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(app_dir))
    core = types.ModuleType("core")
    core.__path__ = [str(app_dir / "core")]
    paths = types.ModuleType("core.paths")
    paths.DATA_DIR, paths.INSTALL_DIR = data_dir, app_dir
    core.paths = paths
    sys.modules["core"] = core
    sys.modules["core.paths"] = paths
    version = types.ModuleType("version")
    version.VERSION, version.BUILD_DATE = "unknown target version", "unknown"
    source = app_dir / "version.py"
    try:
        nodes = ast.parse(source.read_text(encoding="utf-8-sig")).body if source.is_file() else []
    except (SyntaxError, OSError, UnicodeError) as exc:
        nodes = []
        version.VERSION = f"unreadable version file: {type(exc).__name__}"
    for node in nodes:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ("VERSION", "BUILD_DATE"):
                    setattr(version, target.id, str(node.value.value))
    sys.modules["version"] = version
    from diagnostic import report, bundle
    report.REPORTS_DIR = output_dir
    bundle.REPORTS_DIR = output_dir
    from diagnostic import collect
    collect.PORTABLE_TARGET = True
    from diagnostic import replay
    replay.TARGET_APP_DIR = app_dir


def main():
    parser = argparse.ArgumentParser(description="OTA Guard vendor diagnostic; no application startup")
    parser.add_argument("--app-dir")
    parser.add_argument("--data-dir")
    parser.add_argument("--output-dir", default=str(Path(__file__).resolve().parents[1] / "exports"))
    args = parser.parse_args()
    if not args.app_dir or not args.data_dir:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk(); root.withdraw()
        try:
            args.app_dir = args.app_dir or filedialog.askdirectory(title="OTA Guard: dossier contenant main.py ou main.exe", parent=root)
            if not args.app_dir:
                return
            args.data_dir = args.data_dir or filedialog.askdirectory(title="OTA Guard: dossier de donnees contenant config.json", parent=root)
            if not args.data_dir:
                return
        finally:
            root.destroy()
    configure(args.app_dir, args.data_dir, args.output_dir)
    from diagnostic.ui import run
    run()


if __name__ == "__main__":
    main()
