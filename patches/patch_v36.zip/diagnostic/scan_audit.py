"""Explain saved scan evidence without guessing availability or UI state."""
import datetime as dt


def _dict(value):
    return value if isinstance(value, dict) else {}


def _list(value):
    return value if isinstance(value, list) else []


def _time(value):
    try:
        return dt.datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def analyze(evidence):
    snapshots = _dict(evidence.get("snapshots"))
    cfg = _dict(snapshots.get("config.json"))
    watch = _dict(cfg.get("ota_watch"))
    detected = _dict(snapshots.get("ota_detected_rooms.json"))
    reports = _dict(detected.get("otas"))
    results = _dict(watch.get("last_results"))
    report_time, scan_time = _time(detected.get("updated")), _time(watch.get("last_scan_time"))
    same_time = False
    if report_time and scan_time:
        try:
            same_time = abs((report_time - scan_time).total_seconds()) <= 5
        except TypeError:
            pass  # Mixed timezone metadata is not comparable evidence.
    same_hotel = bool(cfg.get("hotel_name")) and detected.get("hotel_name") == cfg.get("hotel_name")
    same_rooms = detected.get("room_types") == cfg.get("room_types")
    current_selection = None
    try:
        try:
            from core.ota_selection import selected_page_keys
            current_selection = selected_page_keys(watch)
        except ModuleNotFoundError as exc:
            if exc.name != "core.ota_selection":
                raise
            from core.ota_page_identity import selected_page_keys
            current_selection = selected_page_keys(cfg)
    except (ImportError, TypeError, ValueError, AttributeError):
        pass
    saved_selection = detected.get("page_keys")
    same_selection = (set(saved_selection) == set(current_selection)
                      if isinstance(saved_selection, list) and current_selection is not None else None)
    comparable = same_time and same_hotel and same_rooms and same_selection is True
    profiles = {_dict(p).get("name"): _dict(p) for p in _list(watch.get("otas")) if _dict(p).get("name")}
    names = sorted(set(profiles) | set(reports) | set(results))
    rows = []
    for name in names:
        observed = [_dict(r) for r in _list(_dict(reports.get(name)).get("rooms")) if _dict(r)]
        priced = [r for r in observed if isinstance(r.get("price"), (float, int)) and r["price"] > 0]
        saved_results = _dict(results.get(name))
        mapped_priced = {r["our"] for r in priced if isinstance(r.get("our"), str) and r["our"]}
        rows.append({"ota": name, "profile_active_flag": profiles.get(name, {}).get("active"),
                     "detected_names": [r.get("name") for r in observed],
                     "priced_names": [r.get("name") for r in priced],
                     "without_price": [r.get("name") for r in observed if r not in priced],
                     "without_match": [r.get("name") for r in observed if not r.get("our")],
                     "saved_scan_rooms": sorted(saved_results),
                     "priced_and_matched_but_absent": sorted(mapped_priced - set(saved_results)) if comparable else [],
                     "comparison_permitted": comparable})
    history = []
    for event in _list(evidence.get("room_checkpoints")):
        event = _dict(event)
        payload = _dict(event.get("data"))
        if payload.get("stage") != "scan_finished":
            continue
        history.append({"time": event.get("ts"), "run_id": payload.get("run_id"),
                        "session": payload.get("session"), "rooms": _dict(payload.get("otas"))})
    history.sort(key=lambda r: str(r.get("time") or ""))
    changes = []
    if len(history) >= 2:
        older, newer = history[-2:]
        for name in sorted(set(older["rooms"]) | set(newer["rooms"])):
            before, after = set(_list(older["rooms"].get(name))), set(_list(newer["rooms"].get(name)))
            if before != after:
                changes.append({"ota": name, "absent_since_previous": sorted(before - after),
                                "added_since_previous": sorted(after - before)})
    return {"status": "observed" if rows else "unavailable", "scan_time": watch.get("last_scan_time"),
            "report_time": detected.get("updated"), "context": {
                "same_hotel": same_hotel, "same_room_inventory": same_rooms,
                "same_time": same_time, "same_selection": same_selection},
            "saved_page_choices": _dict(watch.get("tab_choices")),
            "rows": rows, "last_two_scans": history[-2:], "changes": changes,
            "limits": ["Saved flags do not prove the visible checkbox state.",
                       "A room without a captured price is not proven sold out.",
                       "Scan checkpoints do not record stay dates or full selection; differences alone do not prove a regression.",
                       "Rendered UI, live DOM and actual CM sends are not observed."]}
