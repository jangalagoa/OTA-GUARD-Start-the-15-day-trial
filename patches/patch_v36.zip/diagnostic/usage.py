"""Small, privacy-safe checkpoints for real user journeys.

Only counts, booleans, stable action names and short hashes are recorded.
No event names, URLs, room prices or form contents enter the usage stream.
The app never depends on a successful diagnostic write.
"""
import hashlib
import json
import os

from core.paths import DATA_DIR


def trace(action, **fields):
    """Record one observed action without letting diagnostics affect the app."""
    try:
        from diagnostic import recorder
        session = recorder.session_id()
        if not session:
            return
        allowed = {"phase", "status", "count", "room_count", "ota_count",
                   "selected_count", "operation", "tab", "run_id",
                   "disk_matches", "screen_matches", "fingerprint"}
        data = {key: value for key, value in fields.items()
                if key in allowed and isinstance(value, (str, int, bool, type(None)))}
        data["action"] = str(action)[:40]
        data["pid"] = os.getpid()
        data["session"] = session
        recorder.event("usage", "warn" if data.get("status") in
                       ("failed", "crashed") or data.get("disk_matches") is False
                       or data.get("screen_matches") is False else "info", data)
    except Exception:
        pass


def _disk_config():
    try:
        with (DATA_DIR / "config.json").open(encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return None


def _fingerprint(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False,
                     separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _calendar_visible_fields(events):
    """Only values represented by the event form; preserve other metadata."""
    fields = ("id", "name", "start_date", "end_date", "recurring",
              "locked", "enabled", "rooms", "tolerance_amount",
              "verify_every_days", "wait_minutes", "auto_correct")
    defaults = {"recurring": False, "locked": False, "enabled": True,
                "rooms": {}, "tolerance_amount": None,
                "verify_every_days": 7, "wait_minutes": 10,
                "auto_correct": False}
    return [{key: event.get(key, defaults.get(key))
             for key in fields} for event in events]


def calendar_checkpoint(phase, config, visible_events=None):
    """Compare calendar in memory, on disk and, when supplied, on screen."""
    try:
        memory = (config.get("price_calendar") or {}).get("events") or []
        disk = _disk_config()
        stored = ((disk.get("price_calendar") or {}).get("events") or []) \
            if isinstance(disk, dict) else None
        trace("calendar", phase=phase, count=len(memory),
              fingerprint=_fingerprint(memory),
              disk_matches=(memory == stored) if stored is not None else None,
              screen_matches=(_calendar_visible_fields(memory) ==
                              _calendar_visible_fields(visible_events))
              if visible_events is not None else None)
    except Exception:
        pass


def pages_checkpoint(phase, watch, visible_rows=None):
    """Check the selected OTA page identities against disk and visible cases."""
    try:
        from core.ota_selection import page_key, selected_page_keys
        memory = selected_page_keys(watch)
        disk = _disk_config()
        stored = selected_page_keys(disk.get("ota_watch") or {}) \
            if isinstance(disk, dict) else None
        shown = ({page_key(row.get("url")) for row in visible_rows
                  if row.get("url") and row.get("active")}
                 if visible_rows is not None else None)
        trace("ota_pages", phase=phase, selected_count=len(memory),
              fingerprint=_fingerprint(sorted(memory)),
              disk_matches=(memory == stored) if stored is not None else None,
              screen_matches=(memory == shown) if shown is not None else None)
    except Exception:
        pass


def summarize(events):
    """Compact, evidence-based coverage of the actions actually exercised."""
    counts = {}
    failures = []
    latest_save = {}
    verified_returns = {"calendar": 0, "ota_pages": 0}
    unfinished = {}
    stop_requests = stopped_scans = 0
    first = last = ""
    for item in events:
        if item.get("kind") != "usage":
            continue
        data = item.get("data") or {}
        action = data.get("action")
        phase = data.get("phase")
        if not action:
            continue
        first = first or item.get("ts", "")
        last = item.get("ts", "")
        key = f"{action}:{phase}" if phase else action
        counts[key] = counts.get(key, 0) + 1
        if action in ("calendar", "ota_pages"):
            if data.get("disk_matches") is False or \
                    data.get("screen_matches") is False:
                failures.append({"time": item.get("ts"), "action": key,
                                 "cause": "saved data or visible selection differs"})
            if phase in ("saved", "selected") and data.get("disk_matches"):
                latest_save[action] = (data.get("session"),
                                       data.get("fingerprint"))
            elif phase == "opened" and data.get("screen_matches") and \
                    data.get("disk_matches") and latest_save.get(action) == (
                        data.get("session"), data.get("fingerprint")):
                verified_returns[action] += 1
        if data.get("status") in ("failed", "crashed"):
            failures.append({"time": item.get("ts"), "action": key,
                             "cause": data.get("status")})
        if action == "stop_requested":
            stop_requests += 1
        elif action == "scan" and phase == "finished" and \
                data.get("status") == "stopped":
            stopped_scans += 1
        run_id = data.get("run_id")
        if run_id and action in ("scan", "push"):
            identity = (data.get("session"), action, run_id)
            if phase == "started":
                unfinished[identity] = item.get("ts")
            elif phase == "finished":
                unfinished.pop(identity, None)
    required = {"calendar save": "calendar:saved",
                "calendar return": "calendar:opened",
                "OTA selection": "ota_pages:selected",
                "OTA return": "ota_pages:opened",
                "scan": "scan:finished", "Stop": "stop_requested",
                "CM push": "push:finished"}
    return {"first": first, "last": last, "counts": counts,
            "verified_returns": verified_returns,
            "failures": failures[-20:],
            "unfinished": len(unfinished),
            "stop_requests": stop_requests,
            "stopped_scans": stopped_scans,
            "unverified_returns": [label for label, action in
                                   (("calendar save → return", "calendar"),
                                    ("OTA selection → return", "ota_pages"))
                                   if not verified_returns[action]],
            "not_exercised": [label for label, key in required.items()
                              if not counts.get(key)]}
