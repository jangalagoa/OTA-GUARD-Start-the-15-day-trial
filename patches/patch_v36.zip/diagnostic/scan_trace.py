"""Evidence from the real scan process, independent of the general log quota.

No browser calls, application imports or writes on import. Observers never
change a scan's result. Files contain bounded, sanitized structured evidence,
not browser HTML, cookies, credentials or executable objects.
"""
import contextvars
import datetime as dt
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import sys
import threading
import time
import traceback
import uuid

from diagnostic.sanitize import clean

SCHEMA = "otaguard-scan-trace/1"
MAX_EVENTS = 1500
MAX_BYTES = 4 * 1024 * 1024
KEEP_RUNS = 80
_current = contextvars.ContextVar("ota_diagnostic_scan", default=None)
_listing = contextvars.ContextVar("ota_diagnostic_listing", default="")
_lock = threading.RLock()
_fingerprints = {}
_warned = False


def _digest(path):
    path = Path(path)
    st = path.stat()
    key = (str(path), st.st_size, st.st_mtime_ns)
    if key not in _fingerprints:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        if len(_fingerprints) > 512:
            _fingerprints.clear()
        _fingerprints[key] = h.hexdigest()
    return _fingerprints[key]


def runtime_identity():
    """Observe loaded modules in THIS process; never load missing app modules."""
    paths = sys.modules.get("core.paths")
    install = str(getattr(paths, "INSTALL_DIR", ""))
    data = str(getattr(paths, "DATA_DIR", ""))
    main = sys.modules.get("__main__")
    compiled = bool(getattr(sys, "frozen", False) or hasattr(main, "__compiled__")
                    or (paths is not None and hasattr(paths, "__compiled__")))
    result = {"pid": os.getpid(), "mode": "exe" if compiled else "python",
              "python": sys.version, "executable": sys.executable,
              "install_dir": install, "data_dir": data, "modules": []}
    for name, module in sorted(list(sys.modules.items())):
        if not (name in ("vae_bridge", "version", "updater") or
                name.startswith(("core.", "vae.", "src.", "diagnostic.", "websockets"))):
            continue
        if module is None:
            continue
        p = str(getattr(module, "__file__", "") or "")
        row = {"name": name, "file": p,
               "loader": type(getattr(module, "__loader__", None)).__name__}
        try:
            if p and Path(p).is_file():
                row["file_sha256"] = _digest(p)
            else:
                row["identity_note"] = "No separate module file (may be compiled into executable)."
        except OSError as exc:
            row["hash_error"] = str(exc)
        if name == "vae.config":
            row["capture_dir"] = str(getattr(module, "DATA_DIR", ""))
            row["mapping_dir"] = str(getattr(module, "MAPPINGS_DIR", ""))
        result["modules"].append(row)
    try:
        executable = Path(install) / "main.exe" if compiled and install else Path(sys.executable)
        result["executable_sha256"] = _digest(executable)
    except OSError as exc:
        result["executable_hash_error"] = str(exc)
    version = sys.modules.get("version")
    result["version"] = str(getattr(version, "APP_VERSION", getattr(version, "VERSION", "unknown")))
    loader = sys.modules.get("core.patch_loader")
    if loader is not None:
        result["patch"] = loader.status()
        result["bundled_patch_level"] = getattr(loader, "_BUNDLED_PATCH_LEVEL", None)
    recorder = sys.modules.get("diagnostic.recorder")
    if recorder is not None and hasattr(recorder, "health"):
        result["recorder"] = recorder.health()
    result["hash_scope"] = "On-disk module files at observation time; executable hash for embedded modules."
    return clean(result)


def _bounded(value, depth=0):
    if depth > 12:
        return {"truncated": "depth limit"}
    if isinstance(value, dict):
        items = list(value.items())
        out = {str(k): _bounded(v, depth + 1) for k, v in items[:300]}
        if len(items) > 300:
            out["_omitted_fields"] = len(items) - 300
        return out
    if isinstance(value, (list, tuple, set, frozenset)):
        items = list(value)
        out = [_bounded(v, depth + 1) for v in items[:300]]
        if len(items) > 300:
            out.append({"omitted_items": len(items) - 300})
        return out
    if isinstance(value, str):
        return value if len(value) <= 4000 else value[:4000] + " [TRUNCATED]"
    if value is None or isinstance(value, (int, float, bool)):
        return value
    return {"type": type(value).__name__}  # never repr arbitrary application objects


def _failure(exc):
    global _warned
    if not _warned:
        _warned = True
        logging.getLogger(__name__).error("Diagnostic scan trace write failed: %s", exc)


class Trace:
    def __init__(self, folder, run_id):
        safe = re.sub(r"[^a-zA-Z0-9_-]", "_", str(run_id))[:80] or uuid.uuid4().hex
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / ("scan_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + safe + ".jsonl")
        self.run_id = safe
        self.started = time.monotonic()
        self.count = self.size = 0
        self.limited = False
        # Only our own trace files are retained; no application data is touched.
        old = sorted(folder.glob("scan_*.jsonl"), key=lambda p: p.name)
        for p in old[:-KEEP_RUNS + 1]:
            try:
                p.unlink()
            except OSError:
                pass

    def emit(self, stage, status="observed", **data):
        with _lock:
            if self.count >= MAX_EVENTS or self.size >= MAX_BYTES:
                if self.limited:
                    return
                self.limited = True
                stage, status, data = "trace_limit", "incomplete", {"reason": "event/byte quota reached"}
            payload = {"schema": SCHEMA, "run_id": self.run_id,
                       "time": dt.datetime.now(dt.timezone.utc).isoformat(),
                       "elapsed_ms": round((time.monotonic() - self.started) * 1000),
                       "stage": stage, "status": status,
                       "thread": threading.current_thread().name,
                       "data": data}
            line = json.dumps(clean(_bounded(payload)), ensure_ascii=False, allow_nan=False) + "\n"
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line)
            self.count += 1
            self.size += len(line.encode("utf-8"))


def begin(config, run_id="", *, folder=None):
    """Start before importing the engine, so missing imports are recorded too.

    Normal app recording requires an installed recorder session. Tests pass
    an explicit sandbox folder; standalone imports cannot touch hotel data.
    """
    token = None
    try:
        if folder is None:
            from diagnostic.recorder import session_id
            if not session_id():
                return None
            from core.paths import DATA_DIR
            folder = DATA_DIR / "diagnostic_traces"
        trace = Trace(folder, run_id)
        token = _current.set(trace)
        watch = config.get("ota_watch") or {}
        trace.emit("scan_start", hotel=config.get("hotel_name"),
                   rooms=config.get("room_types"), currency=config.get("hotel_currency"),
                   profiles=watch.get("otas"), choices=watch.get("tab_choices"))
        trace.emit("runtime_start", identity=runtime_identity())
        return token
    except Exception as exc:
        if token is not None:
            _current.reset(token)
        _failure(exc)
        return None


def event(stage, status="observed", **data):
    try:
        trace = _current.get()
        if trace:
            if _listing.get():
                data.setdefault("listing_id", _listing.get())
                data.setdefault("ota", "Airbnb")
            trace.emit(stage, status, **data)
    except Exception as exc:
        _failure(exc)


def error(stage, exc, **data):
    event(stage, "error", error_type=type(exc).__name__, error=str(exc),
          traceback="".join(traceback.format_exception(type(exc), exc, exc.__traceback__)), **data)


def finish(token, results=None, failure=None):
    if token is None:
        return
    try:
        event("runtime_end", identity=runtime_identity())
        event("scan_end", "error" if failure else "returned",
              results=results, errors=getattr(results, "errors", []), error=failure)
    except Exception as exc:
        _failure(exc)
    finally:
        _current.reset(token)


def listing_scope(listing_id):
    """Context manager for attribution of price/conversion evidence."""
    from contextlib import contextmanager
    @contextmanager
    def scope():
        token = _listing.set(str(listing_id))
        try:
            yield
        finally:
            _listing.reset(token)
    return scope()


def append_checkpoint(run_id, stage, **data):
    """UI thread hand-off, linked by explicit run id rather than latest file."""
    if not run_id:
        return
    try:
        from diagnostic.recorder import session_id
        if not session_id():
            return
        from core.paths import DATA_DIR
        safe = re.sub(r"[^a-zA-Z0-9_-]", "_", str(run_id))[:80]
        matches = sorted((DATA_DIR / "diagnostic_traces").glob("scan_*_" + safe + ".jsonl"))
        if not matches:
            return
        p = matches[-1]
        with _lock:
            if p.stat().st_size > MAX_BYTES + 65536:
                return
            payload = {"schema": SCHEMA, "run_id": safe,
                       "time": dt.datetime.now(dt.timezone.utc).isoformat(),
                       "stage": stage, "status": "observed", "data": data}
            with p.open("a", encoding="utf-8") as f:
                f.write(json.dumps(_bounded(clean(payload)), ensure_ascii=False) + "\n")
    except Exception as exc:
        _failure(exc)
