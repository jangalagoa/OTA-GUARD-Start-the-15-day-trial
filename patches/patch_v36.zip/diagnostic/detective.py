"""Detective (D91) — causal analysis of the collected facts.

Turns the raw facts (collect.py) into TRACEABLE conclusions: for every
detected problem, a proposed cause and its proof (file, log line, exact
value). This is the core of the owner's "why are the prices not
accurate" request.

Each finding:
  severity : ok | info | warn | error
  section  : grouping for the report
  title    : one line
  detail   : explanation
  evidence : list of cited proofs (paths, values, log lines)

The detective NEVER guesses without proof: anything not demonstrable is
reported as "not determinable" with the reason.
"""
from datetime import datetime

_TOL_PCT = 2.0        # default tolerance (±2%, same default as D74)


def _finding(severity, section, title, detail="", evidence=None):
    return {"severity": severity, "section": section, "title": title,
            "detail": detail, "evidence": evidence or []}


def _parse_iso(ts: str):
    try:
        return datetime.fromisoformat((ts or "").strip())
    except ValueError:
        return None


def _pct(a, b) -> float:
    """Relative deviation of a from b, in %."""
    if not a or not b:
        return 0.0
    return (a - b) * 100.0 / b


def _target_for(targets: dict, room: str, ota_name: str):
    """Target for a room×OTA pair — WITH the MakeMyTrip/Goibibo alias.

    Project rule: the two OTAs share the SAME inventory and the target
    lives under the combined config key "MakeMyTrip / Goibibo". The first
    real report said "no target defined" for the 4 Goibibo rooms while
    the targets existed — this single resolver fixes that (never
    duplicated elsewhere in the detective)."""
    per = targets.get(room) or {}
    if ota_name in per:
        return per[ota_name]
    low = (ota_name or "").lower()
    if "goibibo" in low or "makemytrip" in low:
        for k, v in per.items():
            lk = (k or "").lower()
            if "goibibo" in lk or "makemytrip" in lk:
                return v
    return None


def _rooms_with_target(targets: dict, ota_name: str) -> list:
    return [r for r, per in targets.items() if _target_for(targets, r, ota_name)]


def analyze_price_precision(facts: dict) -> list:
    """THE core: for each OTA × room of the last scan, verdict and cause."""
    out = []
    cfg = facts.get("configuration") or {}
    sends = (facts.get("shipments") or {}).get("per_ota") or {}
    last_results = cfg.get("last_results") or {}
    targets = cfg.get("target_prices") or {}
    currency = cfg.get("currency") or ""
    min_gap = cfg.get("min_gap") or 0
    clamps = (facts.get("pushes") or {}).get("clamps") or {}

    if not last_results:
        return [_finding("warn", "price",
                         "No scan result in memory",
                         "config.json has no ota_watch.last_results: "
                         "no scan has succeeded since the last "
                         "installation/reset.",
                         ["config.json → ota_watch.last_results empty"])]

    # table ota_name → ota_id of the send_history files
    try:
        from core.send_history import ota_id as _ota_id
    except Exception:
        def _ota_id(n):
            return (n or "").lower().replace(" ", "_")

    from datetime import date as _date
    today = _date.today()

    def _clamp_active(ota_name, room):
        """min/max clamp seen on this pair, recent (≤ 2 days) → dict or None.
        TEXT key "OTA / room" (D96-bis: tuples blew up the report JSON)."""
        c = clamps.get(f"{ota_name} / {room}")
        if not c:
            return None
        try:
            d = datetime.strptime(c.get("date", ""), "%d/%m/%Y").date()
            if (today - d).days > 2:
                return None
        except ValueError:
            pass
        return c

    for ota_name, rooms in sorted(last_results.items()):
        if not isinstance(rooms, dict):
            continue
        hist = sends.get(_ota_id(ota_name)) or {}
        for room, displayed in sorted(rooms.items()):
            try:
                displayed = float(displayed)
            except (TypeError, ValueError):
                out.append(_finding("info", "price",
                                    f"{ota_name} / {room} : unreadable price",
                                    f"Raw value: {displayed!r}"))
                continue
            target = _target_for(targets, room, ota_name)
            if not target:
                # Does the target exist under a DIFFERENT room name for
                # this OTA? D86 signature: the listing exposes its room
                # under a shorter name than the config.
                other = _rooms_with_target(targets, ota_name)
                hint = ""
                if other:
                    hint = (f" ⚠ this OTA does have targets under: "
                            f"{', '.join(other)} — the calibration "
                            f"files the price under a different room "
                            f"name (see the CALIBRATION section).")
                out.append(_finding(
                    "info" if not other else "warn", "price",
                    f"{ota_name} / {room} : showing {displayed:.0f}"
                    f"{currency} — no target defined",
                    "No target price for this room×OTA pair in "
                    "'Target prices per room': no gap is therefore "
                    "computed, no correction will ever be triggered."
                    + hint,
                    ["config.json → ota_watch.target_prices"]))
                continue

            gap = _pct(displayed, target)
            base = (f"{ota_name} / {room} : showing {displayed:.0f} "
                    f"vs target {target:.0f}{currency} "
                    f"(gap {gap:+.1f} %)")
            ev = [f"config.json → ota_watch.last_results[{ota_name!r}]"
                  f"[{room!r}] = {displayed:.0f}",
                  f"config.json → target_prices[{room!r}]"
                  f" = {target:.0f}"]

            if abs(gap) <= _TOL_PCT:
                out.append(_finding("ok", "price", base + " — WITHIN tolerance"))
                continue

            # ── gap below min_gap: NO shipment is expected (user setting,
            # not a bug) — the 1st report shouted "NO shipment" in error
            # for Expedia while the ₹56 gap is deliberately below the
            # ₹100 threshold.
            if min_gap and abs(displayed - target) < min_gap:
                out.append(_finding(
                    "info", "price", base + f" — below the min_gap "
                    f"threshold ({min_gap:.0f}{currency})",
                    f"The gap ({abs(displayed - target):.0f}{currency}) is "
                    f"deliberately ignored: min_gap = "
                    f"{min_gap:.0f}{currency} in the settings — no "
                    "correction will be triggered, this is the expected "
                    "behavior.",
                    ev + ["config.json → ota_watch.min_gap = "
                          f"{min_gap}"]))
                continue

            h = hist.get(room) or {}

            # ── CAUSE n°1 (seen on the 1st real report): the min/max
            # guard blocks the computed price → the target is UNREACHABLE
            # until floor/ceiling and target are reconciled.
            clamp = _clamp_active(ota_name, room)
            if clamp:
                what = ("floor (minimum)" if clamp["kind"] == "floor"
                        else "ceiling (maximum)")
                out.append(_finding(
                    "error", "price", base + " — target BLOCKED by the "
                    f"allowed {what}",
                    f"The software computed that {clamp['calc']:,} must be "
                    f"sent to reach the target, but the {what} of "
                    f"{clamp['bound']:,} prevents it — the price is "
                    "clamped back to the guard and the target will NEVER "
                    "be displayed. Decision needed: reconcile the target "
                    f"({target:.0f}) and the {what} ({clamp['bound']:,}) "
                    "for this room.",
                    ev + [f"app.log [{clamp['date']}] → computed price "
                          f"{clamp['calc']:,} "
                          f"{'below the minimum' if clamp['kind'] == 'floor' else 'above the maximum'} "
                          f"{clamp['bound']:,} — clamped to the guard"]))
                continue

            # ── significant gap: look for the CAUSE ─────────────────────
            ratio = h.get("ratio_median")
            last_sent = h.get("last_sent")
            pending_checks = h.get("pending_checks") or 0

            if h.get("pending") and pending_checks > 0:
                out.append(_finding(
                    "warn", "price", base + " — shipment pending "
                    "propagation",
                    f"A shipment left ({last_sent}) but the OTA still "
                    f"shows the old price after {pending_checks} scan(s). "
                    "The Channel Manager accepted the shipment; the OTA "
                    "has not (yet) propagated it — resending would teach "
                    "nothing (send_history: checks counter).",
                    ev + [f"send_history → checks = {pending_checks}, "
                          f"since {h.get('pending_since')}"]))
                continue

            if ratio and last_sent:
                expected = last_sent * ratio
                dev = _pct(displayed, expected)
                if abs(dev) <= 8.0:
                    # SAME formula as the app (fresh anchor D35/D38):
                    # shipment = last_sent × target ÷ displayed.
                    needed = int(round(last_sent * target / displayed))
                    out.append(_finding(
                        "warn", "price", base + " — consistent with the "
                        f"OTA's ratio (×{ratio:.2f})",
                        f"The display is EXACTLY what the OTA usually "
                        f"makes of the shipment: {last_sent} sent → "
                        f"{expected:.0f} expected, {displayed:.0f} shown. "
                        f"The reading is CORRECT — the gap comes from the "
                        f"last shipment, not from a bug. To display "
                        f"{target:.0f}, the app would compute a shipment "
                        f"≈ {needed:,}.",
                        ev + [f"send_history → median shown/sent ratio "
                              f"= {ratio}", f"last shipment = {last_sent}"]))
                    continue
                out.append(_finding(
                    "error", "price", base + " — INCONSISTENT with the "
                    f"known ratio (×{ratio:.2f})",
                    f"With {last_sent} sent, this OTA usually shows "
                    f"{expected:.0f} — yet it shows "
                    f"{displayed:.0f} ({dev:+.1f} % deviation from the "
                    "model). Suspects: unextracted active promotion, "
                    "unconverted currency, or a reading of another "
                    "room/listing (see the calibrations section).",
                    ev + [f"send_history → median ratio = {ratio}"]))
                continue

            if last_sent:
                out.append(_finding(
                    "warn", "price", base + " — last shipment never measured",
                    f"Last shipment: {last_sent}, but no confirmed "
                    "(sent→shown) measurement exists yet for this room: "
                    "impossible to tell whether the gap is the OTA's "
                    "normal ratio or a problem. The next scan that sees "
                    "the price move will create the measurement.",
                    ev + ["send_history → 0 confirmed measurement"]))
                continue

            out.append(_finding(
                "error", "price", base + " — NO shipment ever recorded",
                "send_history has no trace of any shipment for this "
                "room×OTA pair: the gap cannot fix itself and the loop "
                "has nothing to learn from. Suspects: pushes never "
                "triggered, lock refusals, or a recently added "
                "room/OTA.",
                ev + ["send_history → nothing for this room"]))
    return out


def analyze_calibrations(facts: dict) -> list:
    """Calibration ambiguities — the D43/D86 species detected in advance."""
    out = []
    cfg = facts.get("configuration") or {}
    cal = facts.get("calibrations") or {}
    inventory = cfg.get("room_inventory") or {}
    inv_names = set(inventory.keys())
    targets = cfg.get("target_prices") or {}
    last_results = cfg.get("last_results") or {}

    if cal.get("invalid_files"):
        out.append(_finding("error", "calibration",
                            f"{len(cal['invalid_files'])} unreadable "
                            "calibration file(s)",
                            "A corrupted JSON = the aliases it carried "
                            "are lost for the scans.",
                            [f"calibration_data_{f}" for f in
                             cal["invalid_files"][:5]]))

    # Nested room names ("Double Room" ⊂ "Double Room with Balcony"):
    # fuzzy matching can eclipse the target (D86).
    names = sorted(inv_names)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if a.lower() in b.lower() or b.lower() in a.lower():
                out.append(_finding(
                    "info", "calibration",
                    f"Nested room names: '{a}' / '{b}'",
                    "The perfect match of the short name can eclipse the "
                    "long name when associating the target (D86 bug of "
                    "09/23). The code works around it per-OTA target, but "
                    "any new OTA must be re-checked."))

    # Aliases pointing outside the inventory
    for p in cal.get("profiles") or []:
        for alias, room in (p.get("room_aliases") or {}).items():
            if inv_names and room not in inv_names:
                out.append(_finding(
                    "warn", "calibration",
                    f"{p.get('ota')} : the alias leads to an unknown room "
                    f"('{room}')",
                    "The calibration maps what the OTA displays to a room "
                    "that no longer exists in the inventory — prices will "
                    "be filed nowhere.",
                    [f"{p.get('file')} → room_aliases[{alias!r}] = {room!r}",
                     f"inventory = {sorted(inv_names)}"]))

    # Room reported by the scan but NOT claimed by this profile's
    # calibration, while this OTA has targets defined (under another
    # name): the exact signature of the D86 bug — the listing exposes its
    # room under a shorter name, the price is filed under "Double Room"
    # while the target lives under "Double Room with Balcony" →
    # correction never triggered.
    for ota_cfg, rooms in last_results.items():
        ota_key = (ota_cfg or "").lower().replace(" ", "_")
        has_targets = any(ota_cfg in (per or {})
                          for per in targets.values())
        if not has_targets:
            continue
        for p in cal.get("profiles") or []:
            if ota_key not in (p.get("ota") or "").lower():
                continue
            alias_rooms = set((p.get("room_aliases") or {}).values())
            if not alias_rooms:
                continue
            for room in rooms:
                if room not in alias_rooms:
                    out.append(_finding(
                        "warn", "calibration",
                        f"{ota_cfg} reports '{room}' but its calibration "
                        "expects other rooms",
                        "The scan files this listing's price under a room "
                        "that this profile's calibration does not claim "
                        "(the listing exposes its room under a shorter "
                        "name — mechanism of the D86 bug of 09/23). The "
                        "corrector works around it per-OTA target "
                        "(D86 fix: priority track = candidate carrying a "
                        "target for THIS OTA), but the display shows the "
                        "price under the other name and any new OTA will "
                        "need re-checking.",
                        [f"{p.get('file')} → aliases = "
                         f"{sorted(alias_rooms)}",
                         f"last_results[{ota_cfg!r}] contains {room!r}",
                         f"this OTA's targets = "
                         f"{[r for r, per in targets.items() if ota_cfg in (per or {})]}"]))
    return out


def analyze_operations(facts: dict) -> list:
    """Locks, shipment failures, recurring errors, scan freshness."""
    out = []
    env = facts.get("environment") or {}
    pushes = facts.get("pushes") or {}
    errors = facts.get("errors") or {}
    cfg = facts.get("configuration") or {}

    # Residual single-instance lock
    if (env.get("data_files") or {}).get("instance.lock"):
        age = env["data_files"]["instance.lock"].get("age_h")
        out.append(_finding(
            "info", "operations",
            f"Single-instance lock present ({age} h)",
            "Normal while the app runs; residual when it is closed "
            "(hard kill) — it is ignored when the PID is dead."))

    # Classified shipment failures
    causes = pushes.get("failure_causes") or {}
    if causes:
        worst = max(causes.values())
        sev = "error" if worst >= 5 else "warn"
        detail = "Causes counted in app.log (app.log.bak included):\n" + \
            "\n".join(f"  • {k} : {v}" for k, v in
                      sorted(causes.items(), key=lambda kv: -kv[1]))
        ev = [pushes.get("failure_last", {}).get(k, "")[:140]
              for k in sorted(causes, key=lambda k: -causes[k])]
        out.append(_finding(sev, "operations",
                            f"{sum(causes.values())} shipment failure "
                            "line(s) in the logs", detail,
                            [e for e in ev if e]))

    # Grouped recurring errors
    for g in (errors.get("groups") or [])[:5]:
        if g.get("count", 0) >= 3:
            out.append(_finding(
                "warn", "operations",
                f"Recurring error ×{g['count']} : {g.get('last', '')[:90]}",
                "Normalized signature: " + g.get("signature", ""),
                [g.get("sample", "")[:300]]))

    # Scan freshness
    st = _parse_iso(cfg.get("last_scan_time") or "")
    if st:
        age_h = (datetime.now() - st).total_seconds() / 3600
        if age_h > 48:
            out.append(_finding(
                "warn", "operations",
                f"Last scan {age_h:.0f} h ago",
                "The prices held in memory are more than 2 days old: "
                "every decision taken on them is stale.",
                [f"config.json → last_scan_time = {cfg.get('last_scan_time')}"]))
        else:
            out.append(_finding("ok", "operations",
                                f"Last scan {age_h:.1f} h ago"))

    # Watched OTAs
    actives = [o["name"] for o in cfg.get("otas") or [] if o.get("active")]
    if cfg and not actives:
        out.append(_finding("error", "operations",
                            "NO OTA watched (all inactive)",
                            "No scan will report any price.",
                            ["config.json → ota_watch.otas"]))
    elif cfg:
        out.append(_finding("ok", "operations",
                            f"{len(actives)} OTA(s) watched: "
                            + ", ".join(actives)))

    # Blocked measurements (OTA not propagating)
    for ota_id, rooms in ((facts.get("shipments") or {}).get("per_ota")
                          or {}).items():
        for room, h in rooms.items():
            if isinstance(h, dict) and (h.get("pending_checks") or 0) >= 5:
                out.append(_finding(
                    "warn", "operations",
                    f"{ota_id} / {room} : {h['pending_checks']} scans "
                    "without propagation",
                    "The CM accepted the shipment but the OTA still shows "
                    "the old price — shipments are suspended for this "
                    "room (send_history guard).",
                    [f"send_history_{ota_id}.json → checks = "
                     f"{h['pending_checks']}"]))

    # Environment
    if env and env.get("cdp_9222") is False:
        out.append(_finding(
            "warn", "operations",
            "CDP port 9222 closed — browser not detected",
            "Brave is not running with remote debugging (or is closed): "
            "scans and Extranet Direct cannot work.",
            ["local connection test 127.0.0.1:9222"]))
    if env and env.get("captures", {}).get("age_h") is not None and \
            env["captures"]["age_h"] > 48:
        out.append(_finding(
            "warn", "operations",
            f"VAE captures {env['captures']['age_h']:.0f} h old",
            "The listener has captured nothing for more than 2 days.",
            [f"captures → {env['captures'].get('count')} files, "
             f"newest {env['captures'].get('newest')}"]))
    return out


def analyze_integrity(facts: dict) -> list:
    """Self-tests: valid JSONs, healthy databases, proofs, license."""
    out = []
    cfg = facts.get("configuration") or {}
    env = facts.get("environment") or {}
    lic = facts.get("license") or {}
    dbs = facts.get("databases") or {}
    ev = facts.get("proofs") or {}

    if cfg.get("invalid_json"):
        out.append(_finding("error", "integrity",
                            "config.json UNREADABLE",
                            "The app restarted on the .bak backup or an "
                            "empty config — every setting may be gone.",
                            [cfg.get("invalid_json", "")]))
    elif cfg.get("valid_json"):
        out.append(_finding("ok", "integrity", "config.json : valid JSON"))
        if not (env.get("data_files") or {}).get("config.json.bak"):
            out.append(_finding("info", "integrity",
                                "No config.json.bak",
                                "The backup does not exist yet (created "
                                "on the first save after this file)."))

    for name, entry in dbs.items():
        if not isinstance(entry, dict):
            continue
        if entry.get("missing"):
            out.append(_finding("info", "integrity", f"{name} absent"))
        elif entry.get("integrity") == "ok":
            out.append(_finding("ok", "integrity",
                                f"{name} : SQLite integrity OK "
                                f"({entry.get('size_kb', '?')} KB)"))
        else:
            out.append(_finding("error", "integrity",
                                f"{name} : integrity FAILING",
                                str(entry.get("integrity") or
                                    entry.get("error"))))

    if ev.get("sessions"):
        bad = [s for s in ev["sessions"] if not s.get("index_monotonic")]
        if bad:
            out.append(_finding(
                "warn", "integrity",
                f"{len(bad)} session(s) of the ⚖ ledger with a non-"
                "monotonic index",
                "Records are missing or duplicated in these sessions — "
                "evidentiary value to be verified.",
                [s["session"] for s in bad[:3]]))
        else:
            out.append(_finding("ok", "integrity",
                                f"⚖ ledger : {ev.get('total_sessions')} "
                                "session(s), monotonic indexes"))

    status = lic.get("status") or "?"
    if "expir" in status or "invalid" in status or "revoked" in status:
        out.append(_finding("warn", "integrity",
                            f"License : {status}",
                            "The diagnostic tool still works "
                            "(vendor tool).",
                            [f"zone={lic.get('zone')} "
                             f"max_rooms={lic.get('max_rooms')}"]))
    else:
        out.append(_finding("ok", "integrity", f"License : {status}",
                            "", [f"zone={lic.get('zone')} "
                                 f"max_rooms={lic.get('max_rooms')}"]))

    bb = facts.get("blackbox") or {}
    if bb.get("recent_crashes"):
        out.append(_finding(
            "warn", "integrity",
            f"{len(bb['recent_crashes'])} recent crash(es) in the "
            "black box",
            "Unhandled exceptions caught by the flight recorder.",
            [(c.get("data") or {}).get("exc", "")[:200]
             for c in bb["recent_crashes"][:3]]))
    return out


def analyze(facts: dict) -> list:
    """All findings, in report order."""
    out = []
    out.extend(analyze_price_precision(facts))
    out.extend(analyze_calibrations(facts))
    out.extend(analyze_operations(facts))
    out.extend(analyze_integrity(facts))
    evidence = facts.get("evidence") or {}
    traces = evidence.get("scan_traces") or {}
    runs = traces.get("runs") or []
    if not runs:
        out.append(_finding("warn", "collection", "No per-scan execution trace recorded",
                            "Saved room names do not explain a missing price. This installation needs a scan with the trace-enabled reader."))
    for run in runs[-1:]:
        if not run.get("complete"):
            out.append(_finding("warn", "collection", "Latest scan trace is incomplete",
                                "The scan may be running, interrupted, truncated or unable to write its trace.",
                                [str(run.get("run_id")), str(run.get("file"))]))
        for row in run.get("rows", []):
            if row.get("verdict") == "no_price_returned":
                out.append(_finding("warn", "price", f"No price returned for {row['ota']}",
                                    "Recorded stages below describe this scan; they are not inferred from the saved catalogue.",
                                    [f"{e.get('stage')}: {e.get('data')}" for e in row.get("observed_problems", [])[-10:]]))
        if run.get("scan_error"):
            out.append(_finding("error", "price", "Scan exception recorded", str(run["scan_error"])))
    for issue in evidence.get("issues", []):
        out.append(_finding(issue.get("severity", "warn"), "collection",
                            f"Evidence: {issue.get('area')}", issue.get("message", "")))
    chain = evidence.get("rooms") or {}
    for row in (evidence.get("scan_audit") or {}).get("rows", []):
        if row.get("priced_and_matched_but_absent"):
            out.append(_finding("warn", "rooms", f"{row['ota']}: priced mapped rooms absent from saved results",
                                "The report and saved scan have matching time, hotel, inventory and selected pages. Inspect the JSON/DOM merge and result persistence; this does not prove visible UI state.",
                                row["priced_and_matched_but_absent"]))
    offline = evidence.get("extraction_replay") or {}
    for item in offline.get("results", []):
        if item.get("status") in ("error", "not_checked"):
            out.append(_finding("warn", "collection", f"Offline extraction incomplete: {item.get('ota', item.get('mapping'))}",
                                item.get("error") or item.get("reason", "")))
    replay = (evidence.get("extraction_replay") or {}).get("results") or []
    for row in chain.get("otas", []):
        candidates = [r for r in replay if row.get("source_id") and r.get("status") == "replayed"
                      and str(row.get("source_id", "")).lower() in str(r.get("ota", "")).lower()]
        if candidates and max(len(r.get("rooms", [])) for r in candidates) > len(row["detected"]):
            out.append(_finding("warn", "rooms", f"{row['ota']}: extraction and room report differ",
                                "Offline extraction has more priced rooms than the saved report. Compare timestamps, selection and mappings before attributing a cause.",
                                [f"report: {chain.get('report_time')}, {len(row['detected'])} rooms",
                                 f"offline: {max(len(r.get('rooms', [])) for r in candidates)} rooms",
                                 *[r.get("mapping", "") for r in candidates]]))
        if row.get("unmatched"):
            out.append(_finding("warn", "rooms", f"{row['ota']}: detected rooms without correspondence",
                                "These names reached the detected report but have no saved match in that report.", row["unmatched"]))
    if evidence and not evidence.get("room_checkpoints"):
        out.append(_finding("info", "rooms", "No runtime room checkpoint available",
                            "The UI room lists have not been observed by this diagnostic version."))
    usage = facts.get("usage") or {}
    if usage.get("counts"):
        out.append(_finding("info", "usage",
                            "Real-use checkpoints recorded",
                            "Only actions actually performed can be assessed; "
                            "unexercised paths remain untested.",
                            [f"{sum(usage['counts'].values())} checkpoints, "
                             f"calendar returns verified: "
                             f"{usage.get('verified_returns', {}).get('calendar', 0)}, "
                             f"OTA returns verified: "
                             f"{usage.get('verified_returns', {}).get('ota_pages', 0)}"]))
    for failure in (usage.get("failures") or [])[-10:]:
        out.append(_finding("error", "usage",
                            f"Real-use check failed: {failure.get('action')}",
                            failure.get("cause", ""),
                            [failure.get("time", "")]))
    for key, sec in facts.items():
        if key.startswith("_"):
            continue
        if isinstance(sec, dict) and sec.get("collect_error"):
            out.append(_finding("error", "collection",
                                f"Section '{key}' not collected",
                                sec.get("collect_error")))
    return out


def health_score(findings: list):
    """Overall score 0-100 + per section. Each error -15, warn -5."""
    score = 100
    sections = {}
    for f in findings:
        sev = f.get("severity")
        penalty = {"error": 15, "warn": 5}.get(sev, 0)
        score -= penalty
        s = f.get("section", "?")
        sections.setdefault(s, 100)
        sections[s] -= penalty
    score = max(0, min(100, score))
    sections = {k: max(0, min(100, v)) for k, v in sections.items()}
    return score, sections
