"""Vendor deliverable (D91) — cleaned zip + comparison of two reports.

make_bundle(): packs report.txt/.json + masked config + masked logs
and black box data. Recognized credentials are masked automatically;
review the export before sharing it.

compare_reports(): diagnostic-oriented diff between the JSON report of
the python PC and the one of the installed PC (the owner's original
request).
"""
import datetime
import hashlib
import json
import zipfile
from pathlib import Path

from core.paths import DATA_DIR

from diagnostic import masker
from diagnostic.report import REPORTS_DIR

_BUNDLE_MAX_LINES = 400


def _tail_file(fp, n=_BUNDLE_MAX_LINES):
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception:
        return ""
    return "".join(masker.mask_text(l) for l in lines[-n:])


def _full_file_masked(fp) -> str:
    """D99: the ENTIRE log, masked line by line — the zip leaves the
    machine, so every line goes through the mask (same patterns as the
    black box and the tails). A 15 MB log takes a few seconds: this is
    an explicit manual action (📦 button)."""
    out = []
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            for line in f:
                out.append(masker.mask_text(line.rstrip("\n")))
    except Exception:
        return ""
    return "\n".join(out) + ("\n" if out else "")


def make_bundle(txt_path, json_path, facts: dict, progress_cb=None):
    """One verified, masked export. Missing evidence is part of the deliverable."""
    from diagnostic import comprehensive as full, sanitize
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    zip_path = REPORTS_DIR / f"otaguard_bundle_{ts}.zip"
    temporary = zip_path.with_suffix(".zip.part")
    evidence = facts.get("evidence") or {}
    manifest = {"schema": full.SCHEMA, "created": ts, "files": [],
                "collection_issues": evidence.get("issues", []),
                "coverage": full.coverage(facts), "limits": evidence.get("limits", {}),
                "note": "Coverage is not proof that every application behavior works."}
    entries, used, failures = [], 0, 0
    roots = [Path(evidence.get("data_dir", DATA_DIR)).resolve()]
    if evidence.get("install_dir"):
        roots.append(Path(evidence["install_dir"]).resolve())
    roots += [Path(r["path"]).resolve() for r in evidence.get("capture_roots", [])]
    for f in evidence.get("files", []):
        entries.append(dict(f))
    # Existing callers still receive useful logs when their collector is old.
    if not entries:
        manifest["collection_issues"].append({"area": "inventory", "message": "No evidence inventory; export incomplete"})
        for name in ("config.json", "room_names.json", "ota_detected_rooms.json", "app.log", "ota_guard.log"):
            p = DATA_DIR / name
            if p.is_file():
                st = p.stat()
                entries.append({"path": str(p), "archive": "state/" + name, "export": True,
                                "size": st.st_size, "mtime_ns": st.st_mtime_ns})
    written = {}
    def put(z, name, raw):
        if name in written:
            raise ValueError("duplicate export path: " + name)
        z.writestr(name, raw)
        written[name] = hashlib.sha256(raw).hexdigest()
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as z:
            for index, entry in enumerate(entries):
                if progress_cb and index % 25 == 0:
                    progress_cb(f"Export {index + 1}/{len(entries)}")
                row = dict(entry)
                manifest["files"].append(row)
                path, arc = Path(row["path"]), row["archive"]
                if not row.get("export") or full.SECRET_FILE.search(path.name):
                    row["status"] = "excluded"
                    continue
                try:
                    if Path(arc).is_absolute() or ".." in Path(arc).parts:
                        raise ValueError("invalid archive path")
                    resolved = path.resolve()
                    if not any(resolved.is_relative_to(root) for root in roots):
                        raise ValueError("source moved outside inspected directories")
                    before = path.stat()
                    if before.st_size > full.MAX_FILE or used + before.st_size > full.MAX_EXPORT:
                        row.update(status="omitted", reason="export size limit")
                        failures += 1
                        continue
                    raw = path.read_bytes()
                    after = path.stat()
                    row["source_sha256"] = hashlib.sha256(raw).hexdigest()
                    row["changed_since_analysis"] = before.st_mtime_ns != row.get("mtime_ns")
                    row["changed_during_read"] = (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size)
                    suffix = path.suffix.lower()
                    if path.name.endswith(".json.bak"):
                        suffix = ".json"
                    encoded, warning = sanitize.encode(raw, suffix)
                    if warning:
                        row["warning"] = warning
                        failures += 1
                    if not encoded and raw:
                        row["status"] = "omitted"
                        continue
                    put(z, arc, encoded)
                    used += len(raw)
                    row.update(status="exported", exported_bytes=len(encoded), exported_sha256=written[arc])
                    if row["changed_since_analysis"] or row["changed_during_read"]:
                        failures += 1
                except Exception as exc:
                    row.update(status="error", reason=sanitize.clean_text(str(exc)))
                    failures += 1
            for p in (txt_path, json_path):
                if p and Path(p).is_file():
                    raw, warning = sanitize.encode(Path(p).read_bytes(), Path(p).suffix)
                    if warning:
                        failures += 1
                    put(z, "reports/" + Path(p).name, raw)
            put(z, "analysis_snapshots.json", json.dumps(sanitize.clean(evidence.get("snapshots", {})), ensure_ascii=False, indent=1).encode("utf-8"))
            put(z, "evidence.json", json.dumps(sanitize.clean(evidence), ensure_ascii=False, indent=1).encode("utf-8"))
            manifest["export_complete"] = failures == 0 and bool(entries)
            manifest["inventory_complete"] = not bool(manifest["collection_issues"])
            manifest["all_files_included"] = all(r["status"] == "exported" for r in manifest["files"])
            manifest["omitted_count"] = sum(r["status"] != "exported" for r in manifest["files"])
            put(z, "manifest.json", json.dumps(sanitize.clean(manifest), ensure_ascii=False, indent=1).encode("utf-8"))
            put(z, "READ_ME.txt", ("OTA Guard diagnostic evidence\n"
                "Start with reports/ and manifest.json. Every missing, excluded or changing file is listed.\n"
                "analysis_snapshots.json describes analysis time; state/ describes export time.\n"
                "Capture metadata and bodies keep their paired filenames. Paths in metadata refer to the original PC.\n"
                "Prices in offline replay are in their original currency. DOM/UI/real sends are not exercised.\n"
                "Source secrets and licenses are not exported. Known credential patterns are masked.\n"
                "A complete export is not a guarantee of complete behavioral testing.\n").encode("utf-8"))
        # Verify actual bytes in the archive before declaring the artifact ready.
        with zipfile.ZipFile(temporary) as z:
            for name, expected in written.items():
                if hashlib.sha256(z.read(name)).hexdigest() != expected:
                    raise ValueError("archive verification failed: " + name)
        temporary.replace(zip_path)
        return zip_path
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def compare_reports(path_a, path_b) -> list:
    """Readable diff between two .json reports. Returns lines."""
    def load(p):
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d

    try:
        A, B = load(path_a), load(path_b)
    except Exception as e:
        return [f"❌ Unreadable: {e}"]

    L = ["⚖ COMPARISON OF TWO REPORTS",
         f"  A : {path_a.name}",
         f"  B : {path_b.name}", ""]

    def fa(d):  # facts_lite
        return d.get("facts_lite") or {}

    a, b = fa(A), fa(B)

    def row(label, va, vb):
        if va != vb:
            L.append(f"  • {label} :")
            L.append(f"      A = {_short(va)}")
            L.append(f"      B = {_short(vb)}")

    ia, ib = a.get("identity") or {}, b.get("identity") or {}
    row("version", ia.get("app_version"), ib.get("app_version"))
    row("mode (python/exe)", ia.get("mode"), ib.get("mode"))
    row("health score", A.get("score"), B.get("score"))
    from diagnostic.trace_analysis import compare as compare_traces
    ra = ((a.get("evidence") or {}).get("scan_traces") or {}).get("runs") or []
    rb = ((b.get("evidence") or {}).get("scan_traces") or {}).get("runs") or []
    if ra and rb:
        for change in compare_traces(ra[-1], rb[-1]):
            row("actual scan / " + change["field"], change["a"], change["b"])
    else:
        L.append("  Actual scan comparison incomplete: one or both reports lack per-scan traces.")

    ca, cb = a.get("configuration") or {}, b.get("configuration") or {}
    row("last scan", ca.get("last_scan_time"),
        cb.get("last_scan_time"))
    row("CM transport", ca.get("transport"), cb.get("transport"))
    row("CM map", ca.get("cm_map"), cb.get("cm_map"))
    row("active OTAs",
        [o["name"] for o in ca.get("otas") or [] if o.get("active")],
        [o["name"] for o in cb.get("otas") or [] if o.get("active")])
    row("targets", ca.get("target_prices"), cb.get("target_prices"))
    row("room inventory", sorted((ca.get("room_inventory") or {}).keys()),
        sorted((cb.get("room_inventory") or {}).keys()))

    la, lb = ca.get("last_results") or {}, cb.get("last_results") or {}
    if la != lb:
        L.append("  • last displayed prices:")
        for ota in sorted(set(la) | set(lb)):
            if la.get(ota) != lb.get(ota):
                L.append(f"      {ota} : A = {la.get(ota)}  |  "
                         f"B = {lb.get(ota)}")

    ka, kb = a.get("calibrations") or {}, b.get("calibrations") or {}
    row("calibrations (aliases)",
        [(p.get("ota"), p.get("room_aliases"))
         for p in ka.get("profiles") or []],
        [(p.get("ota"), p.get("room_aliases"))
         for p in kb.get("profiles") or []])

    sa, sb = a.get("shipments") or {}, b.get("shipments") or {}
    row("shipments (summary)",
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sa.get("per_ota") or {}).items()},
        {o: {r: (h.get("last_sent"), h.get("ratio_median"))
             for r, h in rooms.items() if isinstance(h, dict)}
         for o, rooms in (sb.get("per_ota") or {}).items()})

    # Diverging findings
    def titles(d):
        return sorted(f"{f.get('severity', '?')}|{f.get('title', '')}"
                      for f in d.get("findings") or [])
    ta, tb = titles(A), titles(B)
    only_a = [t for t in ta if t not in tb]
    only_b = [t for t in tb if t not in ta]
    if only_a:
        L.append("  • findings present ONLY in A:")
        L.extend(f"      {t}" for t in only_a[:12])
    if only_b:
        L.append("  • findings present ONLY in B:")
        L.extend(f"      {t}" for t in only_b[:12])

    if len(L) == 4:
        L.append("  ✅ No difference found on the tracked points.")
    return L


def _short(v):
    s = json.dumps(v, ensure_ascii=False, default=str) \
        if not isinstance(v, str) else v
    return s if len(s) <= 220 else s[:217] + "…"
