"""Observe actual room lists at the scan/UI boundary; never alter application data."""
def rooms(stage, otas, run_id=""):
    try:
        from diagnostic import recorder, sanitize
        if not recorder.session_id():
            return
        data = {str(ota): [str(name) for name in names][:500]
                for ota, names in otas.items()}
        recorder.event("room_checkpoint", data=sanitize.clean({
            "stage": stage, "run_id": run_id, "otas": data,
            "session": recorder.session_id()}))
    except Exception:
        # This observer is non-critical; the collector reports missing traces.
        return
