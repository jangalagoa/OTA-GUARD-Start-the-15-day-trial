"""Explain real scan events; never confuse configured rooms with read prices."""
import json
from pathlib import Path

MAX_READ = 5 * 1024 * 1024


def analyze_run(events):
    valid = [e for e in events if isinstance(e, dict) and isinstance(e.get("data"), dict)]
    starts = [e for e in valid if e.get("stage") == "scan_start"]
    ends = [e for e in valid if e.get("stage") == "scan_end"]
    expected_id = starts[0].get("run_id") if starts else (valid[0].get("run_id") if valid else None)
    mixed = any(e.get("run_id") != expected_id for e in valid)
    problems = [e for e in valid if e.get("status") in ("error", "rejected", "skipped", "incomplete")]
    end = ends[-1]["data"] if ends else {}
    outcome = end.get("results") or {}
    if not isinstance(outcome, dict):
        outcome = {}
    identities = [e["data"].get("identity") for e in valid
                  if e.get("stage") in ("runtime_start", "runtime_end")]
    ota_names = set(outcome)
    ota_names.update(str(e["data"]["ota"]) for e in valid if e["data"].get("ota"))
    rows = []
    for ota in sorted(ota_names):
        steps = [e for e in valid if e["data"].get("ota") == ota]
        prices = outcome.get(ota) or {}
        rows.append({"ota": ota, "returned_prices": prices,
                     "reader_called": any(e.get("stage") in ("reader_start", "airbnb_live_start", "dom_start", "json_start") for e in steps),
                     "observed_problems": [e for e in problems if e["data"].get("ota") == ota],
                     "last_stage": steps[-1]["stage"] if steps else None,
                     "verdict": "prices_returned" if prices else "no_price_returned" if ends else "unfinished"})
    handoffs = [e for e in valid if e.get("stage") == "ui_outcome"]
    render = [e for e in valid if e.get("stage") == "ui_render"]
    limit = any(e.get("stage") == "trace_limit" for e in valid)
    return {"run_id": expected_id, "started": starts[0].get("time") if starts else None,
            "ended": ends[-1].get("time") if ends else None,
            "complete": bool(starts and ends and not mixed and not limit),
            "mixed_run_ids": mixed, "quota_reached": limit,
            "runtime": identities[-1] if identities else {},
            "scan_error": end.get("error"), "rows": rows,
            "problems": problems, "events": valid,
            "ui_outcome": handoffs[-1]["data"] if handoffs else None,
            "ui_render": render[-1]["data"] if render else None}


def collect(data_dir, limit=20):
    folder = Path(data_dir) / "diagnostic_traces"
    paths = sorted(folder.glob("scan_*.jsonl"))
    result = {"status": "observed" if paths else "unavailable", "runs": [], "issues": [],
              "available_files": len(paths), "omitted_older_files": max(0, len(paths) - limit),
              "scope": "Events recorded by the actual application process; collection does not launch a scan."}
    for path in paths[-limit:]:
        try:
            before = path.stat()
            with path.open("rb") as f:
                raw = f.read(MAX_READ + 1)
            if len(raw) > MAX_READ:
                result["issues"].append(f"{path.name}: exceeds trace read limit")
                continue
            events, invalid = [], 0
            for line in raw.decode("utf-8-sig", "replace").splitlines():
                try:
                    events.append(json.loads(line))
                except ValueError:
                    invalid += 1
            run = analyze_run(events)
            run["file"] = path.name
            run["invalid_lines"] = invalid
            after = path.stat()
            run["changed_during_read"] = (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns)
            if invalid or run["changed_during_read"]:
                run["complete"] = False
            result["runs"].append(run)
        except OSError as exc:
            result["issues"].append(f"{path.name}: {exc}")
    if paths and (result["issues"] or any(not r["complete"] for r in result["runs"])):
        result["status"] = "partial"
    return result


def compare(a, b):
    """Structured differences, including module identities and rejection steps."""
    changes = []
    def check(field, left, right):
        if left != right:
            changes.append({"field": field, "a": left, "b": right})
    for field in ("mode", "version", "patch", "executable_sha256"):
        check(field, (a.get("runtime") or {}).get(field), (b.get("runtime") or {}).get(field))
    def modules(run):
        return {m["name"]: {k: m.get(k) for k in ("file_sha256", "loader", "capture_dir", "mapping_dir")}
                for m in (run.get("runtime") or {}).get("modules", [])}
    am, bm = modules(a), modules(b)
    for name in sorted(set(am) | set(bm)):
        check("module:" + name, am.get(name), bm.get(name))
    def stages(run):
        return [(e.get("stage"), e.get("status"), e.get("data")) for e in run.get("events", [])
                if e.get("stage") not in ("runtime_start", "runtime_end")]
    check("scan_path", stages(a), stages(b))
    check("ui_outcome", a.get("ui_outcome"), b.get("ui_outcome"))
    check("ui_render", a.get("ui_render"), b.get("ui_render"))
    return changes
