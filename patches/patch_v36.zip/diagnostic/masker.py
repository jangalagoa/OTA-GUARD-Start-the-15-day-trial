"""Secret masking — used by the black box, the report and the zip.

Rule: reduce the risk of exposing credentials in diagnostic output.
Pattern-based masking cannot recognize every possible secret format, so
exported bundles still need review. Three mechanisms:
1. mask_dict()   : recursive — every key with a suspicious name
                   (password, token, api_key, secret, auth…) gets its
                   value replaced;
2. mask_text()   : regex patterns in free text (AIza… keys, Bearer…,
                   ?token=…, "password": "…") — same patterns as
                   business/app_logger._sanitize, re-imported to stay
                   in sync;
3. the secret files (secrets.json) are NEVER opened.
"""
import re
from urllib.parse import urlsplit, urlunsplit

# Key names whose value is ALWAYS masked (case-insensitive).
_KEY_HINTS = ("password", "passwd", "pass", "secret", "token", "api_key",
              "apikey", "auth", "credential", "private_key", "cm_pass",
              "cm_user")

# Values that look like a key even under an innocent name.
_VALUE_PATTERNS = [
    re.compile(r"AIza[A-Za-z0-9_\-]{20,}"),
    re.compile(r"sk-(?:ant|proj)-[A-Za-z0-9_\-]{10,}"),
    re.compile(r"gsk_[A-Za-z0-9_\-]{10,}"),
]

_MASK = "***"
_URL_PATTERN = re.compile(r"\b(?:https?|wss?)://[^\s\"'<>]+", re.I)


def _key_is_sensitive(key: str) -> bool:
    k = (key or "").lower()
    return any(h in k for h in _KEY_HINTS)


def mask_value(v):
    """Masks a value if it looks like a key, otherwise returns it."""
    if isinstance(v, str):
        v = _mask_urls(v)
        for pat in _VALUE_PATTERNS:
            if pat.search(v):
                return _MASK
        if len(v) > 80 and re.search(r"[A-Za-z0-9_\-]{30,}", v):
            # Long opaque string resembling an encoded secret.
            return _MASK
    return v


def mask_dict(obj, _depth: int = 0):
    """Masked deep copy of a dict/list (the original is untouched)."""
    if _depth > 12:
        return _MASK
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _key_is_sensitive(str(k)):
                out[k] = _MASK if v not in ("", None, False, 0) else v
            else:
                out[k] = mask_dict(v, _depth + 1)
        return out
    if isinstance(obj, (list, tuple)):
        return [mask_dict(v, _depth + 1) for v in obj]
    return mask_value(obj)


def mask_text(text: str) -> str:
    """Masks secrets in free text (log lines, etc.)."""
    if not text:
        return text
    # Same patterns as business/app_logger (single source of truth).
    try:
        from business.app_logger import _sanitize
        text = _sanitize(text)
    except Exception:
        pass
    text = _mask_urls(text)
    for pat in (re.compile(r'([?&](?:key|token|auth|api_key|secret)=)[^&\s"\']+',
                           re.I),
                re.compile(r'((?:password|secret|token|api_key|auth)\s*[=:]\s*)\S+',
                           re.I)):
        text = pat.sub(r"\1" + _MASK, text)
    return text


def mask_url(url: str) -> str:
    """Keeps the host + path; removes user-info and masks query/fragment."""
    if not isinstance(url, str) or not re.match(
            r"^(?:https?|wss?)://", url, re.I):
        return url
    try:
        parts = urlsplit(url)
        host = parts.hostname
        if not host:
            return "[masked URL]"
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        if parts.port is not None:
            host = f"{host}:{parts.port}"
        return urlunsplit((parts.scheme, host, parts.path,
                           "…" if parts.query else "",
                           "…" if parts.fragment else ""))
    except ValueError:
        return "[masked URL]"


def _mask_urls(text: str) -> str:
    """Sanitizes URLs embedded in arbitrary config values or log text."""
    def replace(match):
        raw = match.group(0)
        trimmed = raw.rstrip(".,;:!?)]}")
        suffix = raw[len(trimmed):]
        return mask_url(trimmed) + suffix
    return _URL_PATTERN.sub(replace, text)
