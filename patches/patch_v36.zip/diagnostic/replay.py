"""Offline extraction only. No live page, mapping regeneration, currency HTTP or push."""
import fnmatch
import json
import time
from pathlib import Path


def replay(evidence, config, budget_seconds=20):
    try:
        import yaml
        from vae.src.extractors.generic_extractor import GenericExtractor
        if globals().get("TARGET_APP_DIR"):
            import inspect
            engine_file = Path(inspect.getfile(GenericExtractor)).resolve()
            if not engine_file.is_relative_to(Path(TARGET_APP_DIR).resolve()):
                return {"status": "unavailable", "reason": "Target extractor unavailable; refusing to replay with another installation's engine."}
        try:
            from core.ota_selection import selected_page_keys
            allowed = selected_page_keys(config.get("ota_watch") or {})
        except ModuleNotFoundError as exc:
            if exc.name != "core.ota_selection":
                raise
            from core.ota_page_identity import selected_page_keys
            allowed = selected_page_keys(config)
    except ImportError as exc:
        return {"status": "unavailable", "reason": str(exc)}
    deadline = time.monotonic() + budget_seconds
    files = [Path(f["path"]) for f in evidence.get("files", [])
             if f["category"] == "capture" and f["export"] and f["size"] <= 32 * 1024 * 1024]
    class SnapshotFolder:
        def glob(self, pattern):
            if time.monotonic() > deadline:
                raise TimeoutError("offline extraction budget exceeded")
            return [p for p in files if fnmatch.fnmatch(p.name, pattern)]
    results, mappings = [], []
    for f in evidence.get("files", []):
        if f["category"] != "mapping" or "ota_mappings" not in f["archive"]:
            continue
        try:
            mapping = yaml.safe_load(Path(f["path"]).read_text(encoding="utf-8-sig"))
            if isinstance(mapping, dict) and mapping.get("ota_name"):
                mappings.append((f["archive"], mapping))
        except Exception as exc:
            results.append({"mapping": f["archive"], "status": "error", "error": str(exc)})
    for label, mapping in mappings:
        if time.monotonic() > deadline:
            results.append({"mapping": label, "status": "not_checked", "reason": "time limit"})
            continue
        try:
            engine = GenericExtractor.__new__(GenericExtractor)
            engine.data_dir = SnapshotFolder()
            engine.mappings = {mapping["ota_name"]: mapping}
            engine.allowed_page_keys = allowed
            engine.allowed_pages = allowed  # V2 names this field differently.
            engine._page_cache = {}
            engine.hotel_name = str(config.get("hotel_name") or "")
            engine.target_currency = ""  # raw source currency: no HTTP converter
            engine._currency_converter = None
            used = []
            original = engine._load_cached
            def read(path, cache):
                if time.monotonic() > deadline:
                    raise TimeoutError("offline extraction budget exceeded")
                value = original(path, cache)
                if value is not None and str(path) not in used:
                    used.append(str(path))
                return value
            engine._load_cached = read
            hotel = engine.extract_ota(mapping["ota_name"])
            rooms = [{"name": r.name, "id": r.id,
                      "price": (r.price.price_after_discount or r.price.total_amount or r.price.base_price),
                      "currency": r.price.currency}
                     for r in (hotel.rooms if hotel else []) if r.price and r.price.has_data]
            catalogue = [{"name": r.name, "id": r.id,
                          "has_price": bool(r.price and r.price.has_data)}
                         for r in (hotel.rooms if hotel else [])]
            results.append({"mapping": label, "ota": mapping["ota_name"], "status": "replayed",
                            "rooms": rooms, "catalogue": catalogue, "files_read": used,
                            "files_read_scope": "Examined files; not per-price provenance."})
        except Exception as exc:
            results.append({"mapping": label, "ota": mapping["ota_name"], "status": "error", "error": str(exc)})
    successes = sum(r.get("status") == "replayed" for r in results)
    status = "observed" if successes and successes == len(results) else "partial" if successes else "unavailable"
    return {"status": status, "results": results, "selected_pages": sorted(allowed),
            "scope": "Selected captured pages, installed JSON mappings, raw currency. Live DOM, UI and sends are not executed."}
