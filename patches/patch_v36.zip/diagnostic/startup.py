"""Independent diagnostic entry point; never start the normal application."""
import datetime
import os
from pathlib import Path
import sys
import tempfile
import traceback


def record_failure(text):
    """Keep startup/UI errors even with Nuitka's disabled console."""
    try:
        from diagnostic.sanitize import clean_text
        text = clean_text(text)
    except Exception:
        text = "Diagnostic failed; error details unavailable because masking failed."
    roots = []
    try:
        from core.paths import DATA_DIR
        roots.append(Path(DATA_DIR) / "diagnostics")
    except Exception:
        pass
    roots.append(Path(tempfile.gettempdir()) / "OTA_Guard_Diagnostic")
    for folder in roots:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            path = folder / f"diagnostic_error_{stamp}.log"
            path.write_text(text, encoding="utf-8")
            return path
        except OSError:
            continue
    return None


def run():
    sys.dont_write_bytecode = True
    try:
        from core.patch_loader import apply_early
        apply_early(read_only=True)
        from diagnostic.ui import run as open_diagnostic
        open_diagnostic()
        return 0
    except Exception:
        path = record_failure(traceback.format_exc())
        message = "Diagnostic startup failed.\n" + (
            f"Error log: {path}" if path else "The error log could not be written.")
        if sys.stderr is not None:
            print(message, file=sys.stderr)
        if os.name == "nt":
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(None, message, "OTA Guard diagnostic", 0x10)
            except Exception:
                pass
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
