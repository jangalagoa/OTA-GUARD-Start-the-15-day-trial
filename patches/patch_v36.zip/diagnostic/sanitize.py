"""Evidence redaction that retains property identity and room/price structure."""
import json
import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

MASK = "[REDACTED]"
SENSITIVE = re.compile(r"password|passwd|secret|token|authorization|cookie|credential|private.?key|api.?key|session.?id|^sid$|^ds$|^cm_user$|email|phone|credit.?card", re.I)
SAFE_QUERY = {"propertyid", "hotelid", "listingid", "roomid", "roomtypeid", "gihotelid", "mmtid",
              "checkin", "checkout", "check_in", "check_out", "chkin", "chkout", "date",
              "currency", "currencycode", "adults", "children", "rooms", "nights"}
URL = re.compile(r"(?:https?|wss?)://[^\s\"'<>]+", re.I)


def clean_url(value):
    try:
        p = urlsplit(value)
        host = p.hostname or ""
        if ":" in host:
            host = "[" + host + "]"
        if p.port:
            host += ":" + str(p.port)
        query = urlencode([(k, v if k.lower() in SAFE_QUERY else MASK)
                           for k, v in parse_qsl(p.query, keep_blank_values=True)])
        fragment = p.fragment
        if "?" in fragment or "=" in fragment:
            fragment = MASK
        return urlunsplit((p.scheme, host, p.path, query, fragment))
    except ValueError:
        return MASK


def clean_text(value):
    value = URL.sub(lambda m: clean_url(m.group()), value)
    value = re.sub(r"(?i)\bBearer\s+[^\s\"']+", "Bearer " + MASK, value)
    value = re.sub(r"(?i)([\"']?(?:password|passwd|secret|[\w-]*token|authorization|cookie|api[_-]?key|session[_-]?id)[\"']?\s*[:=]\s*)(\"(?:\\.|[^\"\\])*\"|'[^']*'|[^\s&,;]+)",
                   lambda m: m[1] + '"' + MASK + '"', value)
    value = re.sub(r"\b(?:AIza[\w-]{20,}|sk-(?:proj-|ant-)?[\w-]{20,}|eyJ[\w-]+\.[\w-]+\.[\w-]+)\b", MASK, value)
    value = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", MASK, value, flags=re.S)
    return value


def clean(value, depth=0):
    if depth > 80:
        return "[DEPTH LIMIT]"
    if isinstance(value, dict):
        # Some HTTP libraries store headers as {name: Authorization, value: ...}.
        header = str(value.get("name", ""))
        return {clean_text(str(k)): (MASK if SENSITIVE.search(str(k)) or
                        (str(k).lower() == "value" and SENSITIVE.search(header))
                        else clean(v, depth + 1)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v, depth + 1) for v in value]
    if isinstance(value, str):
        stripped = value.lstrip()
        if stripped.startswith(("{", "[")):
            try:
                return json.dumps(clean(json.loads(value), depth + 1), ensure_ascii=False)
            except (ValueError, RecursionError):
                pass
        return clean_text(value)
    return value


def encode(raw, suffix):
    """Return sanitized UTF-8 bytes and a parse warning, never an original fallback."""
    text = raw.decode("utf-8-sig", errors="replace")
    try:
        if suffix == ".json":
            # Some captured *_body.json files are actually hotel HTML.
            # Export only the structured state; never execute JS or release
            # raw HTML with unparsed credentials. Mark the transformation.
            if text.lstrip().startswith("<"):
                match = re.search(r'(?:window\.)?__INITIAL_STATE__\s*=\s*', text)
                if not match:
                    return b"", "HTML capture omitted: no supported JSON state"
                value, _ = json.JSONDecoder().raw_decode(text[match.end():])
                if not isinstance(value, dict):
                    return b"", "HTML capture omitted: invalid JSON state"
                return (json.dumps(clean(value), ensure_ascii=False, indent=1).encode("utf-8"),
                        "HTML capture transformed: sanitized JSON state only; HTML omitted")
            return json.dumps(clean(json.loads(text)), ensure_ascii=False, indent=1).encode("utf-8"), ""
        if suffix in (".yaml", ".yml"):
            import yaml
            return yaml.safe_dump(clean(yaml.safe_load(text)), allow_unicode=True).encode("utf-8"), ""
        if suffix == ".jsonl":
            lines, invalid = [], 0
            for line in text.splitlines():
                try:
                    lines.append(json.dumps(clean(json.loads(line)), ensure_ascii=False))
                except ValueError:
                    invalid += 1
                    lines.append(json.dumps({"invalid_jsonl": "unparsed line omitted"}))
            return ("\n".join(lines) + "\n").encode("utf-8"), (f"{invalid} invalid JSONL lines" if invalid else "")
    except (ValueError, ImportError, RecursionError) as exc:
        # Malformed documents can hide secrets in escaped strings. Preserve
        # the failure in the manifest, without releasing an unparsed payload.
        return b"", f"cannot sanitize structured document: {type(exc).__name__}"
    except Exception as exc:
        return b"", f"cannot sanitize document: {type(exc).__name__}"
    return clean_text(text).encode("utf-8"), ""
