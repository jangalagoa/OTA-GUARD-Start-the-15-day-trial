"""Read-only patch inventory and dependency evidence, without activating code."""
import ast
import hashlib
import json
from pathlib import Path
import time


def inspect(install_dir, data_dir, budget_seconds=5):
    root, patch = Path(install_dir), Path(data_dir) / "patches"
    out = {"status": "observed", "files": [], "issues": [], "dependencies": []}
    manifest_path = patch / "manifest.json"
    if not manifest_path.is_file():
        return {**out, "manifest": "absent"}
    deadline = time.monotonic() + budget_seconds
    try:
        if manifest_path.stat().st_size > 2 * 1024 * 1024:
            raise ValueError("oversized manifest")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        files = manifest["files"]
        if not isinstance(files, dict) or len(files) > 2000:
            raise ValueError("invalid patch file inventory")
        out["version"] = manifest.get("version")
        # Verification is local cryptography only; no activation or download.
        try:
            from core.patch_loader import verify_manifest
            out["signature_valid"] = verify_manifest(manifest)
            if not out["signature_valid"]:
                out["issues"].append("Patch signature rejected by this diagnostic runtime's public key")
        except Exception as exc:
            out["signature_error"] = str(exc)
        for name, expected in files.items():
            if time.monotonic() > deadline:
                out["issues"].append("Patch inspection time limit reached")
                break
            rel = Path(name)
            p = patch / rel
            if rel.is_absolute() or ".." in rel.parts or ":" in name or not p.resolve().is_relative_to(patch.resolve()):
                out["issues"].append("Unsafe patch path: " + name)
                continue
            row = {"name": name}
            out["files"].append(row)
            try:
                if p.stat().st_size > 8 * 1024 * 1024:
                    raise ValueError("module size limit")
                raw = p.read_bytes()
                row["hash_matches"] = hashlib.sha256(raw).hexdigest() == expected
                if not row["hash_matches"]:
                    out["issues"].append("Patch file hash mismatch: " + name)
                if p.suffix != ".py":
                    continue
                tree = ast.parse(raw)
                dependencies = set()
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom) and node.module:
                        dependencies.add(node.module)
                        dependencies.update(node.module + "." + alias.name for alias in node.names)
                    elif isinstance(node, ast.Import):
                        dependencies.update(alias.name for alias in node.names)
                for module in sorted(dependencies):
                    if not module.startswith(("core.", "vae.", "diagnostic.")):
                        continue
                    dep = module.replace(".", "/") + ".py"
                    if dep in files:
                        continue
                    if (root / dep).is_file():
                        out["dependencies"].append({"importer": name, "module": module,
                                                     "status": "source_file_present"})
                    elif module in ("core.scan_context", "diagnostic.scan_trace", "diagnostic.trace_analysis",
                                    "diagnostic.startup", "diagnostic.sanitize"):
                        out["dependencies"].append({"importer": name, "module": module,
                                                     "status": "not_in_patch_or_loose_source",
                                                     "note": "May be compiled into EXE; compare actual scan runtime/import errors."})
            except Exception as exc:
                row["error"] = str(exc)
                out["issues"].append(f"{name}: {exc}")
    except Exception as exc:
        out["issues"].append(str(exc))
    if out["issues"]:
        out["status"] = "partial"
    return out
