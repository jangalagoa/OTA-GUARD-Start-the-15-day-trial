"""Internal diagnostic window (D91) — hidden vendor tool.

Launch: main.py --diagnostic (bat in the diag/ folder on the source
side, next to main.exe on the installed side). Protected by the vendor
password (only its SHA-256 lives in the code — never the password in
clear text).

Standalone window (fixed dark theme, independent from the app and its
license): collection progress, colorized report, buttons
📁 open the folder / 📦 cleaned zip / ⚖ compare two reports.
"""
import hashlib
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

# SHA-256 of the vendor password (the password itself is NEVER stored
# in the code or in the compiled exe).
_PASS_HASH = "74cf5ae15956c96fa52e9a1c985786a276cccb1cf85cf514c0c473806ebf87ce"

BG, FG = "#1e1e2e", "#cdd6f4"
ENTRY_BG, SEL_BG, ACCENT = "#313244", "#45475a", "#89b4fa"
GREEN, RED, ORANGE, YELLOW = "#a6e3a1", "#f38ba8", "#fab387", "#f9e2af"

_MAX_TRIES = 3


def _check_password(candidate: str) -> bool:
    return hashlib.sha256((candidate or "").strip().encode("utf-8")) \
        .hexdigest() == _PASS_HASH


class DiagnosticWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self._txt_path = None
        self._json_path = None
        self._facts = None
        self._findings = None
        self._report_text = ""
        self._busy = False
        self._queue = queue.Queue()
        root.title("🔎 OTA Guard — Internal diagnostic (vendor tool)")
        root.configure(bg=BG)
        root.geometry("980x720")
        self._center(980, 720)
        try:
            from pathlib import Path
            ico = Path(__file__).resolve().parent.parent / "assets" \
                / "icon.ico"
            if ico.exists():
                root.iconbitmap(default=str(ico))
        except Exception:
            pass
        self._build_password_gate()

    def _center(self, w, h):
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")

    # ── Step 1: password gate ──────────────────────────────────────────

    def _build_password_gate(self):
        self.gate = tk.Frame(self.root, bg=BG)
        self.gate.pack(fill="both", expand=True)
        tk.Label(self.gate, text="🔒", bg=BG, fg=ACCENT,
                 font=("Segoe UI", 34)).pack(pady=(60, 6))
        tk.Label(self.gate, text="Internal diagnostic tool",
                 bg=BG, fg=FG, font=("Segoe UI", 13, "bold")).pack()
        tk.Label(self.gate,
                 text="Vendor only — password required.",
                 bg=BG, fg="#888888", font=("Segoe UI", 9)).pack(pady=(2, 24))

        self.pw_var = tk.StringVar()
        ent = tk.Entry(self.gate, textvariable=self.pw_var, show="•",
                       bg=ENTRY_BG, fg=FG, insertbackground=FG,
                       relief="flat", justify="center",
                       font=("Segoe UI", 12), width=28,
                       highlightthickness=1,
                       highlightbackground=SEL_BG,
                       highlightcolor=ACCENT)
        ent.pack(ipady=6)
        ent.focus_set()
        ent.bind("<Return>", lambda e: self._try_password())

        self.gate_status = tk.Label(self.gate, text="", bg=BG, fg=FG,
                                    font=("Segoe UI", 9, "italic"))
        self.gate_status.pack(pady=10)
        tk.Button(self.gate, text="Unlock", command=self._try_password,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=18, pady=6,
                  cursor="hand2").pack()
        self._tries = 0

    def _try_password(self):
        if _check_password(self.pw_var.get()):
            self.gate.destroy()
            self._build_main()
            self._start_analysis()
        else:
            self._tries += 1
            left = _MAX_TRIES - self._tries
            self.pw_var.set("")
            if left <= 0:
                self.root.destroy()
                return
            self.gate_status.config(
                text=f"❌ Wrong password — {left} attempt(s) left",
                fg=RED)

    # ── Step 2: main screen ────────────────────────────────────────────

    def _build_main(self):
        top = tk.Frame(self.root, bg=SEL_BG, pady=8, padx=12)
        top.pack(fill="x", side="top")
        tk.Label(top, text="🔎 OTA Guard internal diagnostic",
                 bg=SEL_BG, fg=ACCENT,
                 font=("Segoe UI", 12, "bold")).pack(side="left")
        self.score_lbl = tk.Label(top, text="", bg=SEL_BG, fg=FG,
                                  font=("Segoe UI", 11, "bold"))
        self.score_lbl.pack(side="right")

        self.status_lbl = tk.Label(self.root, text="…", bg=BG, fg="#888888",
                                   font=("Segoe UI", 9))
        self.status_lbl.pack(fill="x", padx=12, pady=(8, 0))
        # Determinate bar: the analysis is fast (~2 s) — an indeterminate
        # animation looked frozen as soon as it ended. Here every
        # collected section advances the percentage, 0 → 100.
        self.progress = ttk.Progressbar(self.root, mode="determinate",
                                        maximum=100, length=940)
        self.progress.pack(fill="x", padx=12, pady=(2, 8))
        self.progress.configure(value=0)

        # Root uses pack. Reserve the bottom controls before the expanding
        # report takes the remaining space (also on small Windows screens).
        bar = tk.Frame(self.root, bg=BG, pady=8)
        bar.pack(fill="x", side="bottom")
        for label, cmd in (
                ("🔄 Analyze again", self._start_analysis),
                ("📦 Analyze + export ZIP", self._make_bundle),
                ("📁 Folder", self._open_folder),
                ("⚖ Compare", self._compare),
                ("✖ Close", self.root.destroy)):
            tk.Button(bar, text=label, command=cmd, bg=SEL_BG, fg=FG,
                      relief="flat", font=("Segoe UI", 9, "bold"),
                      padx=10, pady=5, cursor="hand2").pack(side="left", padx=4)

        self.text = scrolledtext.ScrolledText(
            self.root, bg=ENTRY_BG, fg=FG, relief="flat",
            font=("Consolas", 9), wrap="word", state="disabled")
        self.text.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        for tag, color in (("ok", GREEN), ("warn", ORANGE), ("err", RED),
                           ("info", ACCENT), ("head", YELLOW),
                           ("dim", "#888888")):
            self.text.tag_configure(tag, foreground=color)
        self.text.tag_configure("head", font=("Consolas", 9, "bold"))

        self._set_text("Analysis in progress…", [("info", )])

    # ── Collection thread ──────────────────────────────────────────────

    def _start_analysis(self, export=False):
        if self._busy:
            return
        self._busy = True
        self._stage = "starting"
        self._display_error = False
        # 14 collection sections + analysis + writing. Export has its own
        # file counters and does not pretend that the bar is an ETA.
        self._steps_done = 0
        self._steps_total = 16
        self._t0 = time.time()
        self.progress.configure(value=0)

        def work():
            # D95: an unexpected error here killed the thread silently —
            # the window stayed "Analyzing..." forever (owner's finding:
            # "a report spent 2 h scanning"). Every exception is now
            # DISPLAYED, never swallowed.
            try:
                from diagnostic import collect, detective, report
                facts = collect.collect_facts(
                    progress_cb=lambda s: self._queue.put(("status", s)))
                self._queue.put(("status", "causal analysis"))
                findings = detective.analyze(facts)
                self._queue.put(("status", "writing the report"))
                txt, jsn = report.save_report(facts, findings)
                self._queue.put(("done", (facts, findings, txt, jsn)))
                if export:
                    from diagnostic.bundle import make_bundle
                    self._queue.put(("exporting", "Building and verifying the ZIP…"))
                    zp = make_bundle(txt, jsn, facts,
                                     progress_cb=lambda s: self._queue.put(("exporting", s)))
                    self._queue.put(("exported", str(zp)))
                else:
                    self._queue.put(("idle", None))
            except Exception as e:
                import traceback
                from diagnostic.startup import record_failure
                error_log = record_failure(traceback.format_exc())
                self._queue.put(("error",
                                 f"{type(e).__name__}: {e}\n"
                                 + f"Error log: {error_log or 'unavailable'}"))

        threading.Thread(target=work, daemon=True,
                         name="diagnostic").start()
        self.root.after(150, self._poll)

    def _poll(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "status":
                    self._stage = str(payload)
                    self._steps_done += 1
                    pct = min(99, self._steps_done * 100 // self._steps_total)
                    self.progress.configure(value=pct)
                    elapsed = int(time.time() - self._t0)
                    self.status_lbl.config(
                        text=f"Analysis ({pct} %, {elapsed} s): "
                        f"{payload}…", fg="#888888")
                elif kind == "error":
                    self._busy = False
                    self.progress.configure(value=100)
                    self.status_lbl.config(
                        text="❌ Error during the analysis — the report "
                             "is incomplete", fg=RED)
                    self._set_text("❌ ERROR DURING THE ANALYSIS:\n\n"
                                   + str(payload))
                    return
                elif kind == "done":
                    # Rendering is a main-thread operation. A missing report or
                    # Tk callback error must not stop polling the export worker.
                    try:
                        self._on_done(*payload)
                    except Exception:
                        import traceback
                        from diagnostic.startup import record_failure
                        error_log = record_failure(traceback.format_exc())
                        self._display_error = True
                        self.status_lbl.config(text=f"Report display failed. Error log: {error_log}", fg=RED)
                elif kind == "exporting":
                    self._stage = str(payload)
                    self.status_lbl.config(text=payload, fg=ORANGE)
                elif kind == "exported":
                    self._busy = False
                    self.status_lbl.config(text="Verified ZIP: " + payload, fg=ACCENT)
                    messagebox.showinfo("Diagnostic export", "ZIP verified:\n" + payload +
                                        "\n\nRead manifest.json for exclusions and incomplete checks.", parent=self.root)
                    return
                elif kind == "idle":
                    self._busy = False
                    return
        except queue.Empty:
            pass
        if self._busy and not self._display_error:
            elapsed = int(time.time() - self._t0)
            self.status_lbl.config(text=f"{self._stage} ({elapsed} s)", fg=ORANGE)
        self.root.after(150, self._poll)

    def _on_done(self, facts, findings, txt_path, jsn_path):
        self.progress.configure(value=100)
        from diagnostic.detective import health_score
        score, _ = health_score(findings)
        color = GREEN if score >= 85 else (ORANGE if score >= 60 else RED)
        from diagnostic.comprehensive import coverage
        checks = coverage(facts)
        incomplete = sum(c["status"] != "collected" for c in checks)
        self.score_lbl.config(text=f"{incomplete}/{len(checks)} areas partly or not checked",
                              fg=ORANGE if incomplete else color)
        self.status_lbl.config(
            text=f"Evidence report: {txt_path.name}", fg=ACCENT)
        self._facts, self._findings = facts, findings
        self._txt_path, self._json_path = txt_path, jsn_path
        with open(txt_path, encoding="utf-8") as f:
            self._report_text = f.read()
        self._render(self._report_text)

    # ── Colorized rendering ────────────────────────────────────────────

    def _render(self, text: str):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        for line in text.splitlines():
            tag = "dim"
            if line.startswith(("✅",)):
                tag = "ok"
            elif line.startswith(("⚠️",)):
                tag = "warn"
            elif line.startswith(("❌",)):
                tag = "err"
            elif line.startswith(("ℹ️",)):
                tag = "info"
            elif line.startswith(("=", "─")) or line.isupper() or \
                    ("FINDINGS" in line or "RAW FACTS" in line):
                tag = "head"
            self.text.insert("end", line + "\n", tag)
        self.text.configure(state="disabled")

    def _set_text(self, msg, tags=()):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("end", msg + "\n", *[t[0] for t in tags])
        self.text.configure(state="disabled")

    # ── Boutons ────────────────────────────────────────────────────────

    def _open_folder(self):
        try:
            from diagnostic.report import REPORTS_DIR
            REPORTS_DIR.mkdir(parents=True, exist_ok=True)
            import os
            os.startfile(str(REPORTS_DIR))
        except Exception as e:
            messagebox.showerror("Diagnostic", str(e), parent=self.root)

    def _make_bundle(self):
        self._start_analysis(export=True)

    def _compare(self):
        try:
            a = filedialog.askopenfilename(
                title="Rapport A (ex. : PC python)",
                filetypes=[("JSON reports", "*.json")],
                parent=self.root)
            if not a:
                return
            b = filedialog.askopenfilename(
                title="Report B (e.g. installed PC)",
                filetypes=[("JSON reports", "*.json")],
                parent=self.root)
            if not b:
                return
            from pathlib import Path
            from diagnostic.bundle import compare_reports
            lines = compare_reports(Path(a), Path(b))
            self._render("\n".join(lines) +
                         "\n\n(The full report is displayed again at the next "
                         "analysis run)")
        except Exception as e:
            messagebox.showerror("Diagnostic", str(e), parent=self.root)


def run():
    """Entry point: blocking window (main.py --diagnostic)."""
    root = tk.Tk()
    def callback_error(kind, value, tb):
        import traceback
        from diagnostic.startup import record_failure
        path = record_failure("".join(traceback.format_exception(kind, value, tb)))
        messagebox.showerror("Diagnostic error", f"Action failed. Error log: {path}", parent=root)
    root.report_callback_exception = callback_error
    DiagnosticWindow(root)
    root.mainloop()


if __name__ == "__main__":  # permet aussi : python -m diagnostic.ui
    run()
