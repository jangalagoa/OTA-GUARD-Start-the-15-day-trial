"""Fact collection — full read-only sweep (D91).

Reads EVERYTHING OTA Guard knows about itself: identity, environment,
license, configuration (masked), calibrations, last scan, send history,
push failures, log errors, seasonal verifications, legal ledger, SQLite
databases, black box.

RULES:
- config.json read DIRECTLY (never core.config.load(), which injects the
  secrets and may rewrite the file);
- secrets.json: presence/size only, NEVER opened; license checks are local
  and read-only (no trial initialization or online revocation request);
- any failing section is marked "collect_error" — never a crash;
- progress_cb(section_label) for the window.
"""
import datetime
import json
import os
import re
import socket
import threading
import time
from pathlib import Path

from core.paths import DATA_DIR, INSTALL_DIR

from diagnostic import masker
from diagnostic import recorder

# D95: time guards — on the client PC (~120,000 captures, 15 MB
# ota_guard.log), a section could drag on for minutes and the window
# stayed "Analyzing..." forever. Every section now runs under a
# watchdog: past SECTION_TIMEOUT s it is abandoned (reported as "too
# slow" in the report) and collection CONTINUES. Logs are read through
# their TAIL only (last _TAIL_BYTES bytes): the diagnostic is about the
# recent past, not history.
SECTION_TIMEOUT = 30.0
_TAIL_BYTES = 2 * 1024 * 1024


def _tail_lines(fp: Path, max_bytes: int = _TAIL_BYTES) -> list:
    """Last lines of a file (tail of the last max_bytes bytes).
    A diagnostic is about the RECENT: reading a whole 15 MB log changes
    nothing in the verdict and costs minutes on a slow disk."""
    try:
        size = fp.stat().st_size
        with open(fp, "rb") as f:
            if size > max_bytes:
                f.seek(-max_bytes, os.SEEK_END)
            raw = f.read()
        text = raw.decode("utf-8", "replace")
        if size > max_bytes and "\n" in text:
            text = text.split("\n", 1)[1]   # partial line at the start
        return [l for l in text.splitlines() if l.strip()]
    except Exception:
        return []


def _read_json(fp: Path):
    with open(fp, encoding="utf-8") as f:
        return json.load(f)


def _file_info(fp: Path) -> dict:
    st = fp.stat()
    return {
        "size": st.st_size,
        "mtime": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(
            timespec="seconds"),
        "age_h": round((time.time() - st.st_mtime) / 3600, 1),
    }


def _collect_identity(out: dict):
    import platform
    import sys
    try:
        from version import VERSION, BUILD_DATE
        out["app_version"] = f"{VERSION} (build {BUILD_DATE})"
    except Exception:
        out["app_version"] = "unknown"
    out["generated_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    # Nuitka standalone does NOT define sys.frozen: every compiled module
    # gets the __compiled__ attribute — that is the exe marker (first real
    # report: the exe wrongly introduced itself as "python source").
    out["mode"] = ("compiled exe" if (getattr(sys, "frozen", False)
                                      or "__compiled__" in globals())
                   else "python source")
    if globals().get("PORTABLE_TARGET"):
        out["mode"] = "standalone diagnostic; target execution mode not observed"
    out["python"] = sys.version.split()[0]
    out["os"] = f"{platform.system()} {platform.release()}"
    out["machine"] = platform.node()
    out["user"] = os.environ.get("USERNAME", "?")
    out["tz"] = time.tzname[0]
    out["install_dir"] = str(INSTALL_DIR)
    out["data_dir"] = str(DATA_DIR)


def _collect_environment(out: dict):
    # Key files of the data folder
    watched = ["config.json", "config.json.bak", "secrets.json", "scraper.db",
               "otaguard.db", "license.dat", ".tdata", "app.log", "app.log.bak",
               "ota_guard.log", "activity_log.txt", "fx_cache.json",
               "instance.lock"]
    files = {}
    for name in watched:
        fp = DATA_DIR / name
        if fp.exists():
            fi = _file_info(fp)
            fi["size_kb"] = round(fi.pop("size") / 1024, 1)
            files[name] = fi
    out["data_files"] = files
    out["secrets_present"] = (DATA_DIR / "secrets.json").exists()

    # VAE captures: the REAL folder is the one the app uses
    # (extranet_bridge.captures_dir — freshest between the embedded vae
    # and the standalone). data/captures is only a candidate: the first
    # real report counted 0 captures while the journal kept saving them
    # continuously. Silent fallback when the import is impossible.
    caps_path = None
    try:
        from diagnostic.comprehensive import capture_roots
        cfg = _read_json(DATA_DIR / "config.json")
        candidates = [p for p in capture_roots(DATA_DIR, INSTALL_DIR, cfg) if p.is_dir()]
        caps_path = next(iter(candidates), None)
        out["capture_candidates"] = [str(p) for p in candidates]
    except Exception as exc:
        out["capture_path_error"] = str(exc)
    if caps_path is None or not Path(caps_path).exists():
        caps_path = DATA_DIR / "captures"
    out["captures_dir"] = str(caps_path)
    caps = Path(caps_path)
    if caps.exists():
        try:
            # D95: ONE pass (scandir) for count + freshness — the old code
            # did glob + max(stat) then re-globbed, 3 full sweeps (minutes
            # over 120,000 files).
            count, newest = 0, 0.0
            for entry in os.scandir(caps):
                if not entry.name.lower().endswith(".json"):
                    continue
                count += 1
                try:
                    m = entry.stat(follow_symlinks=False).st_mtime
                    if m > newest:
                        newest = m
                except OSError:
                    pass
            out["captures"] = {
                "count": count,
                "newest": datetime.datetime.fromtimestamp(newest).isoformat(
                    timespec="seconds") if newest else "",
                "age_h": round((time.time() - newest) / 3600, 1) if newest
                else None,
            }
        except Exception:
            out["captures"] = {"error": "unreadable"}
    else:
        out["captures"] = {"count": 0}

    # Browser CDP port 9222 (LOCAL connection to the user's own browser —
    # same as the VAE listen, no OTA request, R1).
    try:
        s = socket.create_connection(("127.0.0.1", 9222), timeout=1.0)
        s.close()
        out["cdp_9222"] = True
    except Exception:
        out["cdp_9222"] = False

    # Free disk space of the data folder
    try:
        import shutil as _sh
        usage = _sh.disk_usage(str(DATA_DIR))
        out["disk_free_gb"] = round(usage.free / 1024 ** 3, 1)
    except Exception:
        pass

    # Black box: volume
    try:
        bb = DATA_DIR / "blackbox"
        days = sorted(bb.glob("blackbox_*.jsonl")) if bb.exists() else []
        out["blackbox_days"] = [f.name for f in days[-3:]]
    except Exception:
        pass


def _collect_license(out: dict):
    # A diagnostic must not call LicenseChecker.check(): implementations can
    # update trial/registry state or contact a revocation service. Presence is
    # evidence, not a successful license validation.
    out["license_file_present"] = (DATA_DIR / "license.dat").is_file()
    out["trial_file_present"] = (DATA_DIR / ".tdata").is_file()
    out["status"] = "not checked: local evidence only"
    out["revocation_checked"] = False
    out["limitations"] = "Signature, expiry, machine binding and online revocation are not executed by diagnostics."
    return



def _collect_config(out: dict):
    """config.json read DIRECTLY — never core.config.load() (secret
    injection + save side effect). Result masked."""
    fp = DATA_DIR / "config.json"
    if not fp.exists():
        out["missing"] = True
        return
    try:
        cfg = _read_json(fp)
    except Exception as e:
        out["invalid_json"] = str(e)[:200]
        return
    out["valid_json"] = True

    ow = cfg.get("ota_watch") or {}
    otas = []
    for o in ow.get("otas") or []:
        if isinstance(o, dict) and o.get("name"):
            otas.append({"name": o.get("name"),
                         "active": bool(o.get("active")),
                         "domain": masker.mask_url(o.get("url") or "")})
    out["otas"] = otas
    out["target_prices"] = ow.get("target_prices") or {}
    out["last_results"] = ow.get("last_results") or {}
    out["last_scan_time"] = ow.get("last_scan_time") or ""
    out["auto_correct"] = cfg.get("ota_watch", {}).get("auto_correct")
    out["scan_interval_h"] = ow.get("interval_h")
    out["min_gap"] = ow.get("min_gap")
    out["room_inventory"] = cfg.get("room_inventory") or {}
    out["room_types"] = cfg.get("room_types") or []
    strat = cfg.get("strategy") or {}
    out["floors"] = strat.get("floors") or {}
    out["ceilings"] = strat.get("ceilings") or {}
    out["currency"] = cfg.get("currency_code") or cfg.get("hotel_currency")
    out["hotel"] = {"name": cfg.get("hotel_name"), "city": cfg.get("hotel_city"),
                    "country": cfg.get("hotel_country")}

    # Extranet direct: transport + active CM (no secret)
    ed = cfg.get("extranet_direct") or {}
    out["transport"] = ed.get("transport") or (
        cfg.get("channel_manager", {}) or {}).get("transport", "api")
    out["cm_map"] = ed.get("cm_map") or ""
    out["extranet_browser_execution"] = ed.get("browser_execution")
    out["cm_domain"] = masker.mask_url(
        ((cfg.get("channel_manager") or {}).get("base_url")) or "")

    # Full masked config (for the JSON report / the comparison)
    out["_sanitized_full"] = masker.mask_dict(cfg)


def _collect_calibrations(out: dict):
    profs = []
    # D108: room mappings live in THE single file room_names.json — the
    # report shows THE truth the scan reads (the room_aliases of the
    # calibration files no longer decide anything).
    try:
        _rn = _read_json(DATA_DIR / "room_names.json").get("otas") or {}
    except Exception as exc:
        _rn = {}
        out["room_names_error"] = str(exc)
    for fp in sorted(DATA_DIR.glob("calibration_data_*.json")):
        if fp.name.endswith("_shared.json") or ".bak" in fp.name:
            continue
        try:
            data = _read_json(fp)
        except Exception:
            out.setdefault("invalid_files", []).append(fp.name)
            continue
        for key, p in (data.get("profiles") or {}).items():
            if not isinstance(p, dict):
                continue
            _sid = str(key).split("||")[-1]
            profs.append({
                "file": fp.name,
                "ota": p.get("ota") or _sid,
                "room_aliases": ((_rn.get(_sid) or {}).get("names")) or {},
                "calibrated_at": p.get("calibrated_at") or "",
                "last_scan": p.get("last_scan") or "",
                "prices_learned": len(p.get("prices_learned") or {}),
                "source_currency": p.get("source_currency") or "",
            })
    out["profiles"] = profs
    sh = DATA_DIR / "calibration_data_shared.json"
    if sh.exists():
        try:
            out["shared_keys"] = sorted((_read_json(sh) or {}).keys())
        except Exception:
            out["shared_error"] = "unreadable"


def _collect_sends(out: dict):
    """Send history: per file/OTA, per room."""
    per_ota = {}
    for fp in sorted(DATA_DIR.glob("send_history_*.json")):
        ota = fp.stem.replace("send_history_", "")
        try:
            data = _read_json(fp)
        except Exception:
            per_ota[ota] = {"error": "unreadable"}
            continue
        rooms = {}
        for room, lst in (data.get("measures") or {}).items():
            if not isinstance(lst, list):
                continue
            confirmed = [e for e in lst
                         if e.get("status") == "confirmed" and e.get("sent")
                         and e.get("observed")]
            pend = next((e for e in reversed(lst)
                         if e.get("status") == "pending"), None)
            ratios = [e["observed"] / e["sent"] for e in confirmed
                      if e.get("sent")]
            rooms[room] = {
                "total": len(lst),
                "confirmed": len(confirmed),
                "pending": bool(pend),
                "pending_checks": (pend or {}).get("checks", 0),
                "pending_since": (pend or {}).get("sent_at", ""),
                "last_sent": next((e.get("sent") for e in reversed(lst)
                                   if not e.get("simulated") and e.get("sent")),
                                  None),
                "last_observed": (confirmed[-1].get("observed")
                                  if confirmed else None),
                "last_target": next((e.get("target") for e in reversed(lst)
                                     if e.get("target")), None),
                "ratio_median": round(sorted(ratios)[len(ratios) // 2], 3)
                if ratios else None,
            }
        per_ota[ota] = rooms
    out["per_ota"] = per_ota


_PUSH_CAUSES = [
    # NOTE: the regexes intentionally match BOTH the English and the
    # French wording historically written by the app into app.log.
    ("preflight_failed", re.compile(r"preflight", re.I)),
    ("post_missing", re.compile(r"post_missing|aucun POST", re.I)),
    ("session expired", re.compile(r"session.*expir|login", re.I)),
    ("lock refused", re.compile(r"déjà en cours|already in progress|refus", re.I)),
    ("not_seen", re.compile(r"not_seen|change not seen", re.I)),
    ("network/CDP failure", re.compile(r"websocket|timeout|cdp|reconnect", re.I)),
]

# D92: min/max clamps seen by the app — the #1 cause of "imprecise
# prices" (the computation wants to send X but the floor/ceiling clamps
# it back to Y → the target is never reached). Extracted from app.log,
# the dated source of truth.
_CLAMP_FR = re.compile(
    r"\[(\d{2}/\d{2}/\d{4})[^\]]*\] \[OTA_WATCH\] ⚠ (?:Calibration )?"
    r"([^:/]+?) / ([^:]+?) : prix calculé ([\d\s,]+?) "
    r"(sous le minimum|au-dessus du maximum) autorisé ([\d\s,]+)")
_CLAMP_EN = re.compile(
    r"\[(\d{2}/\d{2}/\d{4})[^\]]*\] \[OTA_WATCH\] ⚠ Calibration "
    r"([^:/]+?) / ([^:]+?): calculated price ₹?([\d,]+) "
    r"(below the minimum|above the maximum) ([\d,]+)")


def _collect_clamps(out: dict):
    """Last min/max clamp per room×OTA (tail of app.log + .bak).

    TEXT key "OTA / room" — never a tuple: the first real key set
    (7 pairs on the client PC, 05/10 evening) blew up the report's
    json.dumps (TypeError: keys must be str…) — on the dev PC the dict
    was empty, hence no crash in the tests."""
    clamps = {}
    for name in ("app.log", "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        for line in _tail_lines(fp):
            m = _CLAMP_FR.search(line) or _CLAMP_EN.search(line)
            if not m:
                continue
            day, ota, room, calc, kind, bound = m.groups()
            fr = kind.startswith(("sous", "au-dessus"))
            clamps[f"{ota.strip()} / {room.strip()}"] = {
                "date": day,
                "ota": ota.strip(),
                "room": room.strip(),
                "calc": int(calc.replace(",", "").replace(" ", "")),
                "kind": "floor" if (kind.startswith("sous")
                                    or kind.startswith("below"))
                else "ceiling",
                "bound": int(bound.replace(",", "").replace(" ", "")),
                "fr": fr,
            }
    out["clamps"] = clamps
    out["clamp_count"] = len(clamps)


def _classify_push_line(line: str):
    for name, pat in _PUSH_CAUSES:
        if pat.search(line):
            return name
    return None


def _collect_pushes(out: dict, max_lines: int = 400):
    """Shipment lines ([EXTRANET], push, correction) in app.log — the
    source of truth of the real failures (D81: dated lines).
    D95: TAIL reading (last 2 MB) — not the whole file."""
    lines_out, causes, last_by_cause = [], {}, {}
    for name in ("app.log", "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        all_lines = _tail_lines(fp)
        push_lines = [l.rstrip() for l in all_lines
                      if re.search(r"\[EXTRANET\]|push|AddBulkUpdate|"
                                   r"correction|BulkUpdate", l, re.I)]
        for l in push_lines:
            cause = _classify_push_line(l)
            if re.search(r"échec|failed|erreur|error|refus|expir", l, re.I):
                if cause:
                    causes[cause] = causes.get(cause, 0) + 1
                    last_by_cause[cause] = l[:160]
        lines_out.extend(push_lines[-max_lines:])
    out["recent_count"] = len(lines_out)
    out["recent_tail"] = lines_out[-40:]
    out["failure_causes"] = causes
    out["failure_last"] = last_by_cause
    _collect_clamps(out)


_ERR_SIG = re.compile(r"[0-9]+|\"[^\"]*\"|'[^']*'")


def _signature(line: str) -> str:
    """Normalize an error line to group recurrences."""
    return _ERR_SIG.sub("#", line)[:150]


def _collect_errors(out: dict, days: int = 7):
    """Exceptions/errors from the logs, grouped by signature.
    D95: TAIL reading (last 2 MB per file)."""
    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)
    groups = {}
    for name in ("ota_guard.log", "ota_guard.log.bak", "app.log",
                 "app.log.bak"):
        fp = DATA_DIR / name
        if not fp.exists():
            continue
        content = _tail_lines(fp)
        for i, l in enumerate(content):
            if not re.search(r"\b(ERROR|CRITICAL|Traceback|Exception)\b",
                             l, re.I):
                continue
            # Line date (DD/MM/YYYY D81 or ISO logging)
            m = re.search(r"(\d{2}/\d{2}/\d{4})|(\d{4}-\d{2}-\d{2})", l)
            if m:
                try:
                    raw = m.group(0)
                    dt = (datetime.datetime.strptime(raw, "%d/%m/%Y")
                          if "/" in raw else
                          datetime.datetime.fromisoformat(raw))
                    if dt < cutoff:
                        continue
                except ValueError:
                    pass
            sig = _signature(l)
            g = groups.setdefault(sig, {"count": 0, "last": "", "sample": ""})
            g["count"] += 1
            g["last"] = l.strip()[:160]
            if not g["sample"]:
                ctx = "".join(content[i:i + 4])[:400]
                g["sample"] = masker.mask_text(ctx)
    top = sorted(groups.items(), key=lambda kv: -kv[1]["count"])[:15]
    out["groups"] = [{"signature": k, **v} for k, v in top]
    out["total_grouped"] = len(groups)


def _collect_seasonal(out: dict):
    d = DATA_DIR / "seasonal_reports"
    if not d.exists():
        out["missing"] = True
        return
    reports = sorted(d.glob("verification_*.json"))
    out["count"] = len(reports)
    last = None
    if reports:
        try:
            env = _read_json(reports[-1])
            report = env.get("report") or ""
            last = {
                "file": reports[-1].name,
                "generated": env.get("generated", ""),
                "ok_count": report.count("✅"),
                "warn_count": report.count("⚠️"),
                "not_read": report.lower().count("non lue"),
            }
        except Exception as e:
            # D92: cite the cause and try the same-named .txt (the first
            # real report just said "unreadable" with no explanation).
            last = {"file": reports[-1].name,
                    "error": str(e)[:160]}
            txt_twin = reports[-1].with_suffix(".txt")
            try:
                if txt_twin.exists():
                    raw = txt_twin.read_text(encoding="utf-8",
                                             errors="replace")
                    last["ok_count"] = raw.count("✅")
                    last["warn_count"] = raw.count("⚠️")
                    last["not_read"] = raw.lower().count("non lue")
                    last["from_txt"] = True
            except Exception:
                pass
    out["last"] = last


def _collect_evidence(out: dict):
    # Do not call legal_ledger.evidence_dir(): it creates the directory.
    # The collector only inspects an existing evidence folder.
    root = DATA_DIR / "evidence"
    if not root.exists():
        out["missing"] = True
        return
    sessions = []
    for sd in sorted(root.glob("session-*")):
        counts, mono_ok, expected = {}, True, 0
        for fp in sorted(sd.glob("evidence-*.jsonl")):
            try:
                with open(fp, encoding="utf-8", errors="replace") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except ValueError:
                            mono_ok = False
                            continue
                        counts[rec.get("record_type", "?")] = \
                            counts.get(rec.get("record_type", "?"), 0) + 1
                        idx = rec.get("record_index")
                        if idx is not None and idx != expected:
                            mono_ok = False
                        expected = (idx if idx is not None else expected) + 1
            except Exception:
                pass
        sessions.append({"session": sd.name, "records": counts,
                         "index_monotonic": mono_ok})
    out["sessions"] = sessions[-10:]
    out["total_sessions"] = len(sessions)


def _collect_dbs(out: dict):
    import sqlite3
    for name in ("scraper.db", "otaguard.db"):
        fp = DATA_DIR / name
        entry = {}
        if not fp.exists():
            entry["missing"] = True
            out[name] = entry
            continue
        try:
            entry.update(_file_info(fp))
            entry["size_kb"] = round(entry.pop("size") / 1024, 1)
            con = sqlite3.connect(fp.resolve().as_uri() + "?mode=ro", uri=True, timeout=2)
            try:
                deadline = time.monotonic() + 5
                con.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
                entry["integrity"] = (con.execute(
                    "PRAGMA integrity_check").fetchone() or ["?"])[0]
                tables = [r[0] for r in con.execute(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
                entry["tables"] = {t: con.execute(
                    'SELECT COUNT(*) FROM "' + t.replace('"', '""') + '"').fetchone()[0]
                    for t in tables}
            finally:
                con.close()
        except Exception as e:
            entry["error"] = str(e)[:120]
        out[name] = entry


def _collect_blackbox(out: dict):
    evts = recorder.recent_events(200)
    out["count"] = len(evts)
    out["tail"] = evts[-60:]
    crashes = [e for e in evts if e.get("kind") == "crash"]
    out["recent_crashes"] = crashes[-10:]


def _collect_usage(out: dict):
    from diagnostic.usage import summarize
    out.update(summarize(recorder.recent_usage_events()))


def _collect_catalog(out: dict):
    from diagnostic.comprehensive import collect
    out.update(collect(DATA_DIR, INSTALL_DIR))


def _run_with_watchdog(fn, sec: dict, timeout: float = None):
    """Run one section in a watched thread. Past SECTION_TIMEOUT seconds
    the section is ABANDONED (reported as "too slow") and collection
    continues — the report must never stay stuck on "Analyzing..." for
    hours (owner's finding 05/10: a report "spent 2 h scanning"). The
    abandoned thread dies as a daemon, it only reads. NB: the limit is
    read at EXECUTION time (not a default frozen at definition — the
    trap that made the timeout unconfigurable)."""
    if timeout is None:
        timeout = SECTION_TIMEOUT
    box = {"done": False, "error": None}
    private = {}

    def _work():
        try:
            fn(private)
        except Exception as exc:
            box["error"] = exc
        finally:
            box["done"] = True

    t = threading.Thread(target=_work, daemon=True,
                         name=f"diag-{fn.__name__}")
    t.start()
    t.join(timeout)
    if box["done"]:
        if box["error"] is not None:
            raise box["error"]
        sec.update(private)
    return box["done"]


def collect_facts(progress_cb=None) -> dict:
    """Entry point: gathers ALL the facts. Never raises.

    D95: every section is capped at SECTION_TIMEOUT seconds — a section
    that drags (slow disk, 120,000 captures, any lock) is abandoned and
    REPORTED instead of freezing the report.
    """
    facts = {"_meta": {"started": datetime.datetime.now().isoformat(
        timespec="seconds")}}
    steps = [
        ("identity", _collect_identity),
        ("environment", _collect_environment),
        ("license", _collect_license),
        ("configuration", _collect_config),
        ("calibrations", _collect_calibrations),
        ("shipments", _collect_sends),
        ("pushes", _collect_pushes),
        ("errors", _collect_errors),
        ("seasonal", _collect_seasonal),
        ("proofs", _collect_evidence),
        ("databases", _collect_dbs),
        ("blackbox", _collect_blackbox),
        ("usage", _collect_usage),
        ("evidence", _collect_catalog),
    ]
    for label, fn in steps:
        key = label.replace(" ", "_")
        if progress_cb:
            try:
                progress_cb(label)
            except Exception:
                pass
        sec = facts.setdefault(key, {})
        finished = None
        try:
            section_timeout = 100 if key == "evidence" else SECTION_TIMEOUT
            finished = _run_with_watchdog(fn, sec, timeout=section_timeout)
        except Exception as e:
            facts[key] = {"collect_error": f"{type(e).__name__}: {e}"}
            continue
        if finished is False:
            facts[key] = {
                "collect_error": f"section abandoned: too slow "
                f"(> {section_timeout:.0f} s) — busy disk or very large "
                "captures folder",
            }
    facts["_meta"]["ended"] = datetime.datetime.now().isoformat(
        timespec="seconds")
    from diagnostic.comprehensive import coverage
    facts["coverage"] = coverage(facts)
    return facts
