"""Read-only evidence catalog and offline extraction. No app startup or price sends.

Every omission, bounded inspection and changing file is recorded. A successful
collection is not a certificate that all application behavior is correct.
"""
import ast
import datetime as dt
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

from diagnostic import sanitize

SCHEMA = "otaguard-evidence/3"
MAX_FILE = 32 * 1024 * 1024
MAX_EXPORT = 512 * 1024 * 1024
MAX_CAPTURE_FILES = 6000
MAX_WALK = 200000
SECRET_FILE = re.compile(r"secrets\.json|license\.dat|\.tdata|private|master\.key|keygen|firebase.*(?:key|account)|service.?account|credentials|\.pem$|\.pfx$|\.env", re.I)
STATE_FILES = ("config.json", "room_names.json", "ota_detected_rooms.json", "scan_debug.json",
               "cm_sites.json", "extranet_pending.json", "instance.lock")
DOMAINS = ("configuration", "rooms", "captures", "extraction", "channel_manager", "seasonal",
           "operations", "updates", "installation", "databases", "license", "browser", "mobile", "ui")


def load_json(path):
    if path.stat().st_size > MAX_FILE:
        raise ValueError("file exceeds inspection limit")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def file_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def capture_roots(data_dir, install_dir, config):
    candidates = [install_dir / "vae/data/api_discovery", data_dir / "api_discovery", data_dir / "captures"]
    for tree in (config, config.get("channel_manager") or {}):
        if not isinstance(tree, dict):
            continue
        settings = tree.get("extranet_direct") or {}
        explicit = settings.get("captures_dir") if isinstance(settings, dict) else None
        if isinstance(explicit, str) and explicit:
            candidates.append(Path(explicit))
    # Source installations historically used a standalone passive listener.
    candidates.append(Path.home() / "Downloads/vae_standalone/vae/data/api_discovery")
    for name in ("vae.config", "config"):
        mod = sys.modules.get(name)
        if mod and "vae" in str(getattr(mod, "__file__", "")).lower():
            value = getattr(mod, "DATA_DIR", None)
            if value:
                candidates.append(Path(value))
    unique = {}
    for p in candidates:
        unique.setdefault(os.path.normcase(str(p.resolve())), p)
    return list(unique.values())


def _scan_files(root, deadline, recursive=True, excluded=()):
    """Yield regular files only; never follow directory junctions or symlinks."""
    todo, count = [root], 0
    while todo:
        folder = todo.pop()
        with os.scandir(folder) as entries:
            for entry in entries:
                count += 1
                if count > MAX_WALK or time.monotonic() > deadline:
                    raise TimeoutError("inventory limit reached; remaining files not examined")
                if entry.is_symlink() or (hasattr(os.path, "isjunction") and os.path.isjunction(entry.path)):
                    continue
                if entry.is_dir(follow_symlinks=False):
                    if recursive and entry.name not in {"__pycache__", ".git", "diagnostics", "node_modules", ".venv", "venv", *excluded} and not entry.name.startswith("tmp"):
                        todo.append(Path(entry.path))
                elif entry.is_file(follow_symlinks=False):
                    yield Path(entry.path)


def collect(data_dir, install_dir, *, budget_seconds=20, browser_probe=True):
    data_dir, install_dir = Path(data_dir), Path(install_dir)
    deadline = time.monotonic() + budget_seconds
    result = {"schema": SCHEMA, "started": dt.datetime.now().isoformat(timespec="seconds"),
              "data_dir": str(data_dir), "install_dir": str(install_dir), "files": [],
              "issues": [], "capture_roots": [], "snapshots": {}, "code": [],
              "limits": {"file_bytes": MAX_FILE, "export_bytes": MAX_EXPORT,
                         "capture_files": MAX_CAPTURE_FILES, "capture_days": 3,
                         "inspection_seconds": budget_seconds}}
    # Capture causal traces FIRST, so a large capture directory cannot starve
    # the evidence needed for the actual failed scan.
    from diagnostic.trace_analysis import collect as collect_traces
    from diagnostic.installation_audit import inspect as inspect_installation
    for key, fn, args in (("scan_traces", collect_traces, (data_dir,)),
                          ("patch_audit", inspect_installation, (install_dir, data_dir))):
        try:
            result[key] = fn(*args)
        except Exception as exc:
            result[key] = {"status": "unavailable", "issues": [str(exc)]}
            result["issues"].append({"area": "collection", "message": f"{key}: {exc}", "severity": "error"})
    seen = set()
    def issue(area, message, severity="warn"):
        result["issues"].append({"area": area, "message": str(message), "severity": severity})
    def add(path, archive, category, eligible=True, reason=""):
        try:
            real = str(path.resolve())
            if real in seen:
                return
            seen.add(real)
            st = path.stat()
            sensitive = bool(SECRET_FILE.search(path.name))
            result["files"].append({"path": str(path), "archive": archive, "category": category,
                                    "size": st.st_size, "mtime_ns": st.st_mtime_ns,
                                    "export": eligible and not sensitive,
                                    "reason": "sensitive file; metadata only" if sensitive else reason})
        except OSError as exc:
            issue(category, f"{archive}: {exc}")
    config = {}
    for name in STATE_FILES:
        p = data_dir / name
        if not p.is_file():
            issue("rooms" if name in ("room_names.json", "ota_detected_rooms.json") else "configuration",
                  f"{name}: absent", "info")
            continue
        add(p, "state/" + name, "state")
        if name.endswith(".json"):
            try:
                value = load_json(p)
                result["snapshots"][name] = sanitize.clean(value)
                if name == "config.json" and isinstance(value, dict):
                    config = value
            except Exception as exc:
                issue("configuration", f"{name}: {exc}", "error")
    # Current state, schedules, queues, calibration, legal evidence, blackbox
    # and logs: inventory every file, export supported text only.
    try:
        if data_dir.exists():
            for p in _scan_files(data_dir, deadline, excluded=("patches", "api_discovery", "captures")):
                rel = p.relative_to(data_dir).as_posix()
                if rel.startswith(("patches/", "api_discovery/", "captures/")):
                    continue
                text = p.suffix.lower() in (".json", ".jsonl", ".yaml", ".yml", ".log", ".txt") or p.name.endswith((".log.bak", ".json.bak"))
                add(p, "state/" + rel, "state", text, "binary/unknown format; metadata only" if not text else "")
    except (OSError, TimeoutError) as exc:
        issue("inventory", exc)
    # Both bundled and patched extraction maps / CM maps / runtime manifests.
    for base, prefix in ((install_dir, "installed"), (data_dir / "patches", "patches")):
        for rel in ("vae/config", "vae2/maps", "config", "manifests"):
            root = base / rel
            if not root.exists():
                continue
            try:
                for p in _scan_files(root, deadline):
                    if p.suffix.lower() in (".yaml", ".yml", ".json"):
                        add(p, f"{prefix}/{p.relative_to(base).as_posix()}", "mapping")
            except (OSError, TimeoutError) as exc:
                issue("extraction", f"{root}: {exc}")
        for name in ("version.py", "patch_level.json", "manifest.json", "release_build_manifest.json", "release_installer_manifest.json"):
            p = base / name
            if p.is_file():
                add(p, f"{prefix}/{name}", "installation")
    # Give captures their own budget: a large state tree must not hide them.
    capture_deadline = time.monotonic() + budget_seconds
    cutoff = time.time() - 3 * 86400
    for idx, root in enumerate(capture_roots(data_dir, install_dir, config)):
        rec = {"path": str(root), "exists": root.is_dir(), "files": 0, "newest": None}
        result["capture_roots"].append(rec)
        if not rec["exists"]:
            continue
        try:
            paths = list(_scan_files(root, capture_deadline, recursive=False))
            paths.sort(key=lambda p: p.name, reverse=True)
            rec["files"] = len(paths)
            exported = 0
            for p in paths:
                if time.monotonic() > capture_deadline:
                    raise TimeoutError("capture inspection time limit; inventory incomplete")
                if p.suffix != ".json" or p.name.endswith("_body.json"):
                    continue
                pair = [p]
                body = p.with_name(p.stem + "_body.json")
                if body.is_file():
                    pair.append(body)
                st = p.stat()
                rec["newest"] = max(rec["newest"] or 0, st.st_mtime)
                allowed = st.st_mtime >= cutoff and exported + len(pair) <= MAX_CAPTURE_FILES
                why = "" if allowed else "outside capture time/file limit"
                for member in pair:
                    add(member, f"captures/{idx}/{member.name}", "capture", allowed, why)
                if allowed:
                    exported += len(pair)
            # Orphan bodies matter: they cannot pass page-selection validation.
            for p in paths:
                if p.name.endswith("_body.json") and str(p.resolve()) not in seen:
                    add(p, f"captures/{idx}/{p.name}", "capture", False, "orphan body or inspection limit; metadata unavailable")
            rec["selected_files"] = exported
        except (OSError, TimeoutError) as exc:
            rec["error"] = str(exc)
            issue("captures", exc)
    # Code identity and syntax: do not import application modules or execute them.
    deadline = time.monotonic() + budget_seconds
    for base, label in ((install_dir, "installed"), (data_dir / "patches", "patches")):
        if not base.exists():
            continue
        try:
            for p in _scan_files(base, deadline, excluded=("data", "sandbox", "tests", "docs", "build", "patches_backup")):
                rel = p.relative_to(base).as_posix()
                if rel.startswith(("data/", "sandbox/", "tests/", "docs/", "vae/data/")) or SECRET_FILE.search(p.name):
                    continue
                if p.suffix.lower() not in (".py", ".pyd", ".exe", ".dll"):
                    continue
                row = {"path": label + "/" + rel, "size": p.stat().st_size}
                if row["size"] <= MAX_FILE:
                    row["sha256"] = file_digest(p)
                    if p.suffix == ".py":
                        try:
                            ast.parse(p.read_text(encoding="utf-8-sig"))
                            row["syntax"] = "valid"
                        except Exception as exc:
                            row["syntax"] = str(exc)
                            issue("installation", f"{row['path']}: {exc}", "error")
                else:
                    row["hash_skipped"] = "file size limit"
                result["code"].append(row)
        except (OSError, TimeoutError) as exc:
            issue("installation", exc)
    # Read-only CDP inventory: no Page.reload, Runtime.evaluate or navigation.
    result["browser"] = {"status": "not_checked", "tabs": []}
    if browser_probe:
        try:
            import urllib.request
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open("http://127.0.0.1:9222/json/list", timeout=2) as response:
                tabs = json.loads(response.read(2 * 1024 * 1024))
            result["browser"] = {"status": "observed", "tabs": [
                {"type": t.get("type"), "url": sanitize.clean_url(t.get("url", "")),
                 "title": sanitize.clean_text(t.get("title", ""))} for t in tabs if t.get("type") == "page"]}
        except Exception as exc:
            result["browser"] = {"status": "unavailable", "error": str(exc), "tabs": []}
    try:
        result["rooms"] = room_chain(result["snapshots"])
    except (TypeError, AttributeError, ValueError) as exc:
        result["rooms"] = {"error": f"Invalid nested room/configuration structure: {exc}"}
    if result["rooms"].get("error"):
        issue("rooms", result["rooms"]["error"], "error")
    result["room_checkpoints"] = []
    for p in sorted((data_dir / "blackbox").glob("blackbox_*.jsonl"))[-3:]:
        try:
            with p.open("rb") as f:
                size = p.stat().st_size
                f.seek(max(0, size - 2 * 1024 * 1024))
                if size > 2 * 1024 * 1024:
                    f.readline()
                for line in f:
                    try:
                        item = json.loads(line)
                        if item.get("kind") == "room_checkpoint":
                            result["room_checkpoints"].append(sanitize.clean(item))
                    except (ValueError, UnicodeError):
                        continue
        except OSError as exc:
            issue("operations", f"{p.name}: {exc}")
    result["room_checkpoints"] = result["room_checkpoints"][-100:]
    try:
        from diagnostic.replay import replay
        result["extraction_replay"] = replay(result, config, budget_seconds=budget_seconds)
    except Exception as exc:
        result["extraction_replay"] = {"status": "unavailable", "error": str(exc)}
    from diagnostic.scan_audit import analyze as scan_audit
    result["scan_audit"] = scan_audit(result)
    result["loaded_modules_scope"] = "Diagnostic process only; not a snapshot of the running application's modules."
    result["loaded_modules"] = [{"name": name, "file": str(getattr(mod, "__file__", ""))}
                                for name, mod in list(sys.modules.items())
                                if name.startswith(("core.", "vae", "diagnostic.", "tabs.", "licensing.", "updater"))]
    result["ended"] = dt.datetime.now().isoformat(timespec="seconds")
    return result


def room_chain(snapshots):
    cfg = snapshots.get("config.json") or {}
    detected = snapshots.get("ota_detected_rooms.json") or {}
    mapping = snapshots.get("room_names.json") or {}
    if not all(isinstance(x, dict) for x in (cfg, detected, mapping)):
        return {"error": "invalid configuration/report/mapping structure"}
    names = mapping.get("otas") or {}
    watch = cfg.get("ota_watch") or {}
    expected = [r if isinstance(r, str) else r.get("type", "") for r in cfg.get("room_types") or []]
    rows = []
    for profile in watch.get("otas") or []:
        name = profile.get("name") or ""
        if not name or not profile.get("active", True):
            continue
        src = next((s for s in names if s.casefold() == name.casefold()), name.lower())
        report = next((v for k, v in (detected.get("otas") or {}).items() if k.casefold() == name.casefold()), {})
        observed = report.get("rooms") or []
        mapped = {r.get("our") for r in observed if isinstance(r, dict) and r.get("our")}
        rows.append({"ota": name, "source_id": report.get("source_id", src),
                     "detected": [r.get("name") for r in observed if isinstance(r, dict)],
                     "unmatched": [r.get("name") for r in observed if isinstance(r, dict) and not r.get("our")],
                     "missing_configured": [r for r in expected if r not in mapped],
                     "scan_rooms": list((watch.get("last_results") or {}).get(name, {})),
                     "names": (names.get(src) or {}).get("names", {}),
                     "ids": (names.get(src) or {}).get("ids", {})})
    return {"report_time": detected.get("updated"), "scan_time": watch.get("last_scan_time"),
            "context_matches": detected.get("hotel_name") == cfg.get("hotel_name") and detected.get("room_types") == cfg.get("room_types"),
            "otas": rows,
            "interpretation": "Absent from a snapshot is not proof of a bug or of room availability. UI visibility is not observed."}


def coverage(facts):
    checks = []
    evidence = facts.get("evidence") or {}
    mapping = {"configuration": "configuration", "rooms": "evidence", "captures": "evidence", "extraction": "evidence",
               "channel_manager": "pushes", "seasonal": "seasonal", "operations": "usage", "updates": "evidence",
               "installation": "identity", "databases": "databases", "license": "license", "browser": "evidence",
               "mobile": "usage", "ui": "usage"}
    for area in DOMAINS:
        section = facts.get(mapping[area])
        status = "collected" if section else "unavailable"
        detail = "Read-only evidence; behavior not automatically exercised."
        if isinstance(section, dict) and (section.get("collect_error") or section.get("checker_error")):
            status, detail = "unavailable", section.get("collect_error") or section.get("checker_error")
        if isinstance(section, dict) and (section.get("missing") or section.get("invalid_json")):
            status, detail = "unavailable", "Required data is missing or invalid."
        if area in ("ui", "mobile", "updates", "license", "channel_manager", "extraction") and status == "collected":
            status = "partial"
        if area == "captures" and not any(r.get("files") for r in evidence.get("capture_roots", [])):
            status, detail = "unavailable", "No capture indexed; check paths and inventory errors."
        if area == "browser" and evidence.get("browser", {}).get("status") != "observed":
            status, detail = "unavailable", "Browser tabs were not observed."
        if area == "rooms" and "ota_detected_rooms.json" not in evidence.get("snapshots", {}):
            status, detail = "unavailable", "Detected-room snapshot missing."
        if area == "rooms" and status == "collected" and not (evidence.get("rooms") or {}).get("context_matches"):
            status, detail = "partial", "Report context differs from the current configuration."
        if area == "rooms" and (evidence.get("rooms") or {}).get("error"):
            status, detail = "unavailable", evidence["rooms"]["error"]
        if area == "extraction":
            replay = evidence.get("extraction_replay") or {}
            state = replay.get("status")
            status = "partial" if state in ("observed", "partial") else "unavailable"
            detail = "Offline replay only; live DOM and displayed UI not verified."
            if status == "unavailable":
                detail = replay.get("reason") or replay.get("error") or "Offline extraction unavailable."
            if (evidence.get("scan_traces") or {}).get("runs"):
                status = "partial"
                detail = "Actual scan stages recorded; see scan_traces for prices, rejections, errors and trace completeness."
        if area == "databases" and isinstance(section, dict) and section:
            good = [v for v in section.values() if isinstance(v, dict) and v.get("integrity") == "ok"]
            if len(good) != len(section):
                status = "partial" if good else "unavailable"
                detail = "See per-database missing files, integrity and read errors."
        if status == "collected" and any(i["area"] in (area, "inventory") for i in evidence.get("issues", [])):
            status, detail = "partial", "See collection issues; evidence is incomplete."
        checks.append({"area": area, "status": status, "detail": detail})
    return checks
