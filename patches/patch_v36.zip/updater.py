"""
Auto-updater — OTA Guard.

Silently checks whether a new version is available at launch.
If yes → optional or forced notification depending on the server.
Downloads and replaces the .exe automatically.
"""

import json
import logging
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path

from version import VERSION

log = logging.getLogger(__name__)

# ── GitHub releases (public repo) ───────────────────────────────────────────
_GITHUB_REPO  = "jangalagoa/OTA-GUARD-Start-the-15-day-trial"
_GITHUB_API   = f"https://api.github.com/repos/{_GITHUB_REPO}/releases"
_RELEASE_TAG  = re.compile(r"^v3\.0\.[0-9]+$")
_INSTALLER_PREFIX = "OTAGuardV3_Setup_v"

# Network timeout in seconds
_TIMEOUT = 8


def _is_compiled_app() -> bool:
    """Recognize Nuitka builds even when its runtime marker is absent.

    Nuitka standalone builds this application as ``main.exe``. Some startup
    contexts (notably the early updater import) do not expose ``sys.frozen``
    or ``__compiled__`` consistently, so use the executable name as a final,
    product-specific fallback. A normal source launch uses python.exe/pythonw.exe.
    """
    entry_point = sys.modules.get("__main__")
    return (bool(getattr(sys, "frozen", False))
            or "__compiled__" in globals()
            or (entry_point is not None and hasattr(entry_point, "__compiled__"))
            or Path(sys.executable).name.casefold() == "main.exe")


# ═════════════════════════════════════════════════════════════════════════
# Version comparison (e.g. "1.2.0" > "1.1.3")
# ═════════════════════════════════════════════════════════════════════════

def _parse_version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.strip().lstrip("v").split("."))
    except Exception:
        return (0,)


def _extract_version_str(*sources: str) -> str:
    """Search for the most precise version number among several sources
    (e.g. tag_name="OTA-Guard-v1", name="OTA Guard v1.0.1"): some GitHub
    tags do not carry the full number, unlike the release name. The match
    with the most components is kept (x.y.z > x)."""
    best, best_parts = "", 0
    for s in sources:
        if not s:
            continue
        m = re.search(r'\d+(?:\.\d+)*', s)
        if m:
            parts = m.group(0).count(".") + 1
            if parts > best_parts:
                best, best_parts = m.group(0), parts
    return best or "0"


def is_newer(remote: str, current: str = VERSION) -> bool:
    return _parse_version(remote) > _parse_version(current)


def _select_release(releases: list) -> dict | None:
    """Choose the newest complete, public V3 release only."""
    matches = []
    for release in releases:
        if not isinstance(release, dict) or release.get("draft") or release.get("prerelease"):
            continue
        tag = str(release.get("tag_name") or "")
        if not _RELEASE_TAG.fullmatch(tag):
            continue
        version = tag[1:]
        asset_name = f"{_INSTALLER_PREFIX}{version}.exe"
        assets = [asset for asset in (release.get("assets") or [])
                  if isinstance(asset, dict) and asset.get("name") == asset_name]
        if len(assets) != 1:
            continue
        url = str(assets[0].get("browser_download_url") or "")
        if not url.startswith("https://"):
            continue
        lines = str(release.get("body") or "").splitlines()
        try:
            metadata = json.loads(lines[0]) if lines else {}
        except (ValueError, TypeError):
            continue
        if not isinstance(metadata, dict):
            continue
        sha256 = str(metadata.get("sha256") or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", sha256):
            continue
        digest = str(assets[0].get("digest") or "")
        if digest and digest.lower() != f"sha256:{sha256}":
            continue
        matches.append((version, {
            "version": version,
            "forced": bool(metadata.get("forced", False)),
            "notes": "\n".join(lines[1:]).strip(),
            "download_url": url,
            "sha256": sha256,
        }))
    return max(matches, key=lambda item: _parse_version(item[0]))[1] if matches else None


# ═════════════════════════════════════════════════════════════════════════
# Remote check
# ═════════════════════════════════════════════════════════════════════════

def check_for_update() -> dict | None:
    """
    Contact the server and return the update info.

    Returns None if:
      - No internet connection
      - URL not configured (placeholder)
      - Same version or network error

    Returns a dict when a new version is available:
      {
        "version":      "1.1.0",
        "forced":       False,
        "notes":        "Agoda scan fix",
        "download_url": "https://github.com/.../OTAGuard.exe",
        "sha256":       "abc123..."   ← optional but recommended
      }
    """
    try:
        for page in range(1, 6):
            req = urllib.request.Request(
                f"{_GITHUB_API}?per_page=100&page={page}",
                headers={
                    "User-Agent": f"OTAGuard/{VERSION}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
            )
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                releases = json.loads(resp.read().decode("utf-8"))
            if not isinstance(releases, list):
                raise ValueError("GitHub release catalog is not a list")
            update = _select_release(releases)
            if update:
                if is_newer(update["version"]):
                    log.info("[Updater] New V3 version available: %s → %s",
                             VERSION, update["version"])
                    return update
                log.info("[Updater] V3 version up to date (%s)", VERSION)
                return None
            if len(releases) < 100:
                break
        log.info("[Updater] No complete V3 release in the public catalog")
        return None

    except urllib.error.URLError as e:
        log.info("[Updater] Update check unavailable: %s", e)
        return None
    except Exception as e:
        log.warning("[Updater] Check error: %s", e)
        return None


# ═════════════════════════════════════════════════════════════════════════
# Download with progress
# ═════════════════════════════════════════════════════════════════════════

def _updates_dir() -> Path:
    """Persistent folder for downloaded installers.

    NEVER %TEMP%: a temp file vanishes on cleanup/reboot, and an install
    that failed after the old version was removed would force the user to
    download the whole setup again. Here the installer stays on disk until
    the next successful update replaces it."""
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    d = Path(base) / "OTA Guard" / "updates"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


def download_update(url: str, on_progress=None, on_done=None):
    """
    Download the new .exe into a temporary file.

    on_progress : callable(percent: int, downloaded_mb: float, total_mb: float)
    on_done     : callable(ok: bool, path_or_error: str)
    """
    def _run():
        tmp_path = None
        if not url.lower().startswith("https://"):
            if on_done:
                on_done(False, "Insecure download URL (HTTPS required).")
            return
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": f"OTAGuard/{VERSION}",
                    "Accept":     "application/octet-stream",
                },
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                total_mb = total / 1_048_576 if total else 0

                name = Path(url).name
                if not name.lower().endswith(".exe"):
                    name = f"otaguard_setup_{int(time.time())}.exe"
                dest = _updates_dir() / name
                tmp_path = str(dest)
                downloaded = 0
                chunk = 65_536   # 64 KB

                with open(dest, "wb") as f:
                    while True:
                        buf = resp.read(chunk)
                        if not buf:
                            break
                        f.write(buf)
                        downloaded += len(buf)
                        if on_progress and total:
                            pct = int(downloaded * 100 / total)
                            on_progress(pct, downloaded / 1_048_576, total_mb)

            # Keep only the latest installer in the updates folder
            try:
                for old in _updates_dir().glob("*.exe"):
                    if old != dest:
                        old.unlink(missing_ok=True)
            except Exception:
                pass

            if on_done:
                on_done(True, tmp_path)

        except Exception as e:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            if on_done:
                on_done(False, str(e))

    threading.Thread(target=_run, daemon=True).start()


# ═════════════════════════════════════════════════════════════════════════
# .exe replacement and restart
# ═════════════════════════════════════════════════════════════════════════

def verify_sha256(file_path: str, expected_hash: str) -> bool:
    """Verify the integrity of the downloaded file via SHA-256."""
    import hashlib
    h = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest().lower() == expected_hash.lower()
    except Exception:
        return False


def apply_update(new_exe_path: str, on_error=None):
    """
    Launch the downloaded installer via a relay script, then exit the app.

    The relay waits for this process to die, then runs the installer SILENTLY
    with its working directory
    OUTSIDE the install folder, and restarts the app on success.

    Why a relay: launching the installer directly from the app passes it the
    app's own working directory (= the install folder). Windows then refuses
    to rename/delete that folder during the update ("reboot required") —
    the historical cause of updates destroying the installation. The relay
    also guarantees the app is fully stopped before the installer starts.
    on_error: callable(str) called if the relay cannot be launched.
    """
    exe_path = new_exe_path
    if not new_exe_path.lower().endswith(".exe"):
        exe_path = new_exe_path + ".exe"
        try:
            os.rename(new_exe_path, exe_path)
        except Exception:
            exe_path = new_exe_path

    try:
        from core.paths import INSTALL_DIR
        updates_dir = _updates_dir()
        relay = updates_dir / "apply_update.cmd"
        relay.write_text(
            "@echo off\r\n"
            "chcp 65001 >nul\r\n"
            f'cd /d "{updates_dir}"\r\n'
            "ping -n 4 127.0.0.1 >nul\r\n"
            ":wait\r\n"
            f'tasklist /FI "PID eq {os.getpid()}" /NH 2>nul | find "{os.getpid()}" >nul\r\n'
            "if not errorlevel 1 (\r\n"
            "    ping -n 2 127.0.0.1 >nul\r\n"
            "    goto wait\r\n"
            ")\r\n"
            f'"{exe_path}" /SILENT /NORESTART /SUPPRESSMSGBOXES\r\n'
            "if errorlevel 1 exit /b %errorlevel%\r\n"
            f'if exist "{INSTALL_DIR}\\main.exe" start "" "{INSTALL_DIR}\\main.exe"\r\n',
            encoding="utf-8",
        )
        subprocess.Popen(
            ["cmd", "/c", str(relay)],
            cwd=str(updates_dir),
            close_fds=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        os._exit(0)
    except Exception as e:
        log.error("[Updater] Unable to launch the installer: %s", e)
        if on_error:
            on_error(str(e))


# ═════════════════════════════════════════════════════════════════════════
# Tkinter UI — Notification + Download
# ═════════════════════════════════════════════════════════════════════════

def show_update_dialog(root_tk, update_info: dict) -> bool:
    """
    Show the update notification.
    Returns True if the user chose to update.
    """
    import tkinter as tk
    from tkinter import ttk
    from core.utils import tr_

    BG       = "#1e1e2e"
    FG       = "#cdd6f4"
    ENTRY_BG = "#313244"
    SEL_BG   = "#45475a"
    ACCENT   = "#89b4fa"
    GREEN    = "#a6e3a1"
    RED      = "#f38ba8"
    ORANGE   = "#fab387"
    YELLOW   = "#f9e2af"

    remote_version = update_info.get("version", "?")
    notes          = update_info.get("notes", "")
    forced         = update_info.get("forced", False)
    download_url   = update_info.get("download_url", "")

    result = {"action": None}   # "update" or "skip"

    dlg = tk.Toplevel(root_tk)
    dlg.title(tr_("🔄 OTA Guard Update"))
    dlg.configure(bg=BG)
    dlg.geometry("520x380")
    dlg.resizable(False, False)
    dlg.grab_set()

    # Center
    dlg.update_idletasks()
    sw = dlg.winfo_screenwidth()
    sh = dlg.winfo_screenheight()
    dlg.geometry(f"520x380+{(sw-520)//2}+{(sh-380)//2}")

    if forced:
        dlg.protocol("WM_DELETE_WINDOW", lambda: None)  # prevents closing

    pad = tk.Frame(dlg, bg=BG, padx=32, pady=20)
    pad.pack(fill="both", expand=True)

    # Title
    tk.Label(pad, text=tr_("🔄 Update available"),
             bg=BG, fg=ACCENT, font=("Segoe UI", 14, "bold")).pack(pady=(0, 4))

    # Versions
    v_frame = tk.Frame(pad, bg=ENTRY_BG, padx=14, pady=8)
    v_frame.pack(fill="x", pady=(0, 12))
    tk.Label(v_frame,
             text=tr_("Current version: {v}").format(v=VERSION),
             bg=ENTRY_BG, fg="#888888", font=("Segoe UI", 9)).pack(anchor="w")
    tk.Label(v_frame,
             text=tr_("New version: {v}").format(v=remote_version),
             bg=ENTRY_BG, fg=GREEN, font=("Segoe UI", 10, "bold")).pack(anchor="w")

    # Notes
    if notes:
        tk.Label(pad, text=tr_("What's new:"), bg=BG, fg=FG,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 4))
        notes_box = tk.Text(pad, bg=ENTRY_BG, fg=FG,
                            font=("Segoe UI", 9), height=4,
                            relief="flat", wrap="word", state="normal",
                            padx=8, pady=6)
        notes_box.insert("1.0", notes)
        notes_box.configure(state="disabled")
        notes_box.pack(fill="x", pady=(0, 10))

    if forced:
        tk.Label(pad,
                 text=tr_("⚠️ This update is mandatory."),
                 bg=BG, fg=ORANGE,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 8))

    # Progress area (hidden initially)
    prog_frame = tk.Frame(pad, bg=BG)
    prog_var   = tk.StringVar(value="")
    prog_lbl   = tk.Label(prog_frame, textvariable=prog_var,
                          bg=BG, fg="#888888", font=("Segoe UI", 8))
    prog_lbl.pack(anchor="w")
    prog_bar = ttk.Progressbar(prog_frame, length=450, maximum=100)
    prog_bar.pack(fill="x", pady=(4, 0))

    # Manual actions frame (invisible until the download succeeds)
    manual_frame = tk.Frame(pad, bg=BG)
    manual_state = {"path": None}

    # Buttons
    btn_frame = tk.Frame(pad, bg=BG)
    btn_frame.pack(fill="x", pady=(8, 0))

    def _do_update():
        if not download_url:
            return
        update_btn.configure(state="disabled")
        if not forced:
            skip_btn.configure(state="disabled")
        prog_frame.pack(fill="x", pady=(8, 0))

        # The background download thread must NEVER call Tkinter methods
        # directly (dlg.after, .configure, ...): at that point, no Tk
        # interpreter of the program has run mainloop() yet
        # (run_update_check() is called from main.py before any mainloop()),
        # so Tkinter rejects those cross-thread calls with
        # "RuntimeError: main thread is not in main loop". The thread only
        # drops events into a queue; the main thread (via the self-scheduled
        # dlg.after) consumes them and is the only one touching widgets.
        ui_queue = queue.Queue()

        def _progress(pct, dl_mb, total_mb):
            ui_queue.put(("progress", pct, dl_mb, total_mb))

        def _done(ok, path_or_err):
            if ok:
                expected = update_info.get("sha256", "")
                if not expected:
                    # D26: SHA-256 missing from the manifest → REFUSAL. Without
                    # a fingerprint, the installer's integrity cannot be
                    # guaranteed — every GitHub release MUST include
                    # {"sha256": "..."} on the first line of the body.
                    try:
                        os.remove(path_or_err)
                    except Exception:
                        pass
                    ui_queue.put(("error", "❌ Unsigned update (SHA-256 missing from the release) — installation refused."))  # noqa: E501
                    return
                # SHA-256 present → mandatory verification
                if not verify_sha256(path_or_err, expected):
                    try:
                        os.remove(path_or_err)
                    except Exception:
                        pass
                    ui_queue.put(("error", "❌ Invalid signature — download cancelled."))
                    return
                ui_queue.put(("success", path_or_err))
            else:
                ui_queue.put(("error", f"❌ Error: {path_or_err[:60]}"))

        def _poll_queue():
            try:
                while True:
                    item = ui_queue.get_nowait()
                    kind = item[0]
                    if kind == "progress":
                        _, pct, dl_mb, total_mb = item
                        prog_bar.configure(value=pct)
                        prog_var.set(f"Downloading… {dl_mb:.1f} MB / {total_mb:.1f} MB  ({pct}%)")
                    elif kind == "success":
                        path_or_err = item[1]
                        prog_var.set("✅ Download verified — launching the installer…")
                        prog_bar.configure(value=100)
                        manual_state["path"] = path_or_err
                        manual_frame.pack(fill="x", pady=(8, 0))
                        def _launch(p=path_or_err):
                            def _on_err(msg):
                                prog_var.set(f"❌ Launch failed: {msg[:80]}")
                                prog_lbl.configure(fg=RED)
                                update_btn.configure(state="normal")
                            apply_update(p, on_error=_on_err)
                        dlg.after(800, _launch)
                        return  # done — no need to reschedule the polling
                    elif kind == "error":
                        msg = item[1]
                        prog_var.set(msg)
                        prog_lbl.configure(fg=RED)
                        update_btn.configure(state="normal")
                        return  # done — no need to reschedule the polling
            except queue.Empty:
                pass
            dlg.after(100, _poll_queue)

        dlg.after(100, _poll_queue)
        download_update(download_url, on_progress=_progress, on_done=_done)

    def _skip():
        result["action"] = "skip"
        dlg.destroy()

    update_btn = tk.Button(
        btn_frame, text=tr_("⬇️ Update now"),
        command=_do_update,
        bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
        relief="flat", padx=14, pady=6, cursor="hand2")
    update_btn.pack(side="left")

    if not forced:
        skip_btn = tk.Button(
            btn_frame, text=tr_("Later"),
            command=_skip,
            bg=SEL_BG, fg=FG, font=("Segoe UI", 9),
            relief="flat", padx=12, pady=6, cursor="hand2")
        skip_btn.pack(side="right")

    # Manual buttons — visible after a successful download
    def _manual_install():
        p = manual_state.get("path")
        if p:
            def _on_err(msg):
                prog_var.set(f"❌ Launch failed: {msg[:80]}")
                prog_lbl.configure(fg=RED)
            apply_update(p, on_error=_on_err)

    def _manual_restart():
        try:
            subprocess.Popen([sys.executable] + sys.argv[1:], close_fds=True)
        except Exception:
            pass
        os._exit(0)

    tk.Label(manual_frame,
             text=tr_("If the installer does not start automatically:"),
             bg=BG, fg="#888888", font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 4))
    manual_btn_row = tk.Frame(manual_frame, bg=BG)
    manual_btn_row.pack(fill="x")
    tk.Button(manual_btn_row, text=tr_("⬇️ Install now"),
              command=_manual_install,
              bg="#059669", fg="#fff", font=("Segoe UI", 9, "bold"),
              relief="flat", padx=12, pady=5, cursor="hand2").pack(side="left", padx=(0, 8))
    tk.Button(manual_btn_row, text=tr_("🔄 Restart OTA Guard"),
              command=_manual_restart,
              bg=SEL_BG, fg=FG, font=("Segoe UI", 9),
              relief="flat", padx=12, pady=5, cursor="hand2").pack(side="left")

    dlg.wait_window()
    return result.get("action") == "update" or False


# ═════════════════════════════════════════════════════════════════════════
# Main entry point — called from main.py
# ═════════════════════════════════════════════════════════════════════════

def run_update_check(root_tk=None):
    """
    Check for updates and show the dialog if necessary.
    Silent when there is no update or no connection.

    Args:
        root_tk: parent Tk window (may be None if called before the main window)
    """
    # Guard D12/D26: never download/launch an installer in source mode —
    # auto-update only applies to the compiled build. Same detection as
    # licensing/keys.py::_embedded_public_pem (D24).
    if not _is_compiled_app():
        entry_point = sys.modules.get("__main__")
        log.info(
            "[Updater] Source mode — update check disabled "
            "(executable=%r, frozen=%r, module_compiled=%r, main_compiled=%r).",
            sys.executable,
            bool(getattr(sys, "frozen", False)),
            "__compiled__" in globals(),
            entry_point is not None and hasattr(entry_point, "__compiled__"),
        )
        return

    log.info("[Updater] Checking GitHub for updates (current version %s).", VERSION)
    update_info = check_for_update()
    if update_info is None:
        return   # Nothing to do

    # A Tk window is needed to show the dialog
    import tkinter as tk
    owner = root_tk

    if owner is None:
        owner = tk.Tk()
        owner.withdraw()   # invisible window just for the dialog
        show_update_dialog(owner, update_info)
        owner.destroy()
    else:
        show_update_dialog(owner, update_info)
