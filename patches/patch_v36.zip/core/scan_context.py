"""Pure capture context comparison; page identity is separate from stay context."""
import datetime as dt
import hashlib
import json
import re
from urllib.parse import parse_qsl, urlsplit
from core.ota_selection import page_key

_FIELDS = {
    'checkin': 'checkin', 'checkindate': 'checkin', 'chkin': 'checkin',
    'checkout': 'checkout', 'checkoutdate': 'checkout', 'chkout': 'checkout',
    'arrivaldate': 'checkin', 'departuredate': 'checkout',
    'adults': 'adults', 'numadults': 'adults', 'numberofadults': 'adults',
    'children': 'children', 'numchildren': 'children', 'childages': 'childages',
    'rooms': 'rooms', 'roomstring': 'occupancy', 'roomstayqualifier': 'occupancy',
    'rm1': 'occupancy', 'guests': 'guests', 'nights': 'nights', 'los': 'nights',
    'currency': 'currency', 'currencycode': 'currency', 'ucurrency': 'currency',
    'hotelid': 'property', 'propertyid': 'property', 'listingid': 'property',
}


def _normal(key):
    return re.sub('[^a-z0-9]', '', str(key).lower())


def _date(value):
    value = str(value)
    for fmt in ('%Y-%m-%d', '%Y%m%d', '%m%d%Y'):
        try:
            return dt.datetime.strptime(value[:10] if '-' in value else value, fmt).date().isoformat()
        except ValueError:
            pass
    return value


def _fields(value, depth=0):
    out = {}
    if depth > 6 or not isinstance(value, dict):
        return out
    for key, item in value.items():
        target = _FIELDS.get(_normal(key))
        if target and isinstance(item, (str, int, float)) and str(item):
            out[target] = _date(item) if target in ('checkin', 'checkout') else str(item)
        elif isinstance(item, dict):
            # Conflicting contexts in one request are not safe to merge.
            for field, val in _fields(item, depth + 1).items():
                out[field] = val if field not in out or out[field] == val else '[ambiguous]'
    return out


def url_scope(url):
    try:
        fields = _fields(dict(parse_qsl(urlsplit(url).query)))
        return {'page': page_key(url), 'fields': fields}
    except (TypeError, ValueError):
        return {'page': '', 'fields': {}}


def capture_scope(meta):
    scope = url_scope(meta.get('documentURL') or meta.get('tab_url') or '')
    # Request parameters describe the actual stay, even when the tab URL is stale.
    scope['fields'].update(url_scope(meta.get('url') or '')['fields'])
    body = meta.get('post_data') or meta.get('postData') or {}
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except ValueError:
            body = dict(parse_qsl(body))
    scope['fields'].update(_fields(body))
    scope['tab'] = str(meta.get('tab_id') or '')
    scope['loader'] = str(meta.get('loaderId') or '')
    return scope


def same_stay(a, b):
    """Require property and stay evidence; unknown is not a compatible context."""
    if not a or not b or not a.get('page') or a['page'] != b.get('page'):
        return False
    af, bf = a.get('fields', {}), b.get('fields', {})
    if not af.get('checkin') or not bf.get('checkin'):
        return False
    if not (af.get('checkout') or af.get('nights')) or not (bf.get('checkout') or bf.get('nights')):
        return False
    if '[ambiguous]' in af.values() or '[ambiguous]' in bf.values():
        return False
    return af == bf


def request_family(meta):
    """Repeated responses to one request replace each other, not union inventory."""
    ignored = {'requestid', 'correlationid', 'timestamp', 'token', 'sessionid', 'ck'}
    def stable(value):
        if isinstance(value, dict):
            return {k: stable(v) for k, v in value.items() if _normal(k) not in ignored}
        if isinstance(value, list):
            return [stable(v) for v in value]
        return value
    url = urlsplit(meta.get('url') or '')
    if not url.hostname:
        return ''
    body = meta.get('post_data') or meta.get('postData') or ''
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except ValueError:
            pass
    value = [meta.get('method', 'GET'), url.hostname, url.path,
             sorted((k.lower(), v) for k, v in parse_qsl(url.query) if _normal(k) not in ignored), stable(body)]
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


class ScanResults(dict):
    """Legacy dictionary interface plus per-OTA failure evidence."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.errors = []

    def failure(self, ota, stage, error):
        self.errors.append({'ota': str(ota), 'stage': stage, 'error': str(error)})


def merge_room_prices(captured, observed):
    """Use live values for overlapping identities, retain distinct captured rooms."""
    return {**captured, **observed}
