"""Pure page selection shared by the Brave list and price readers.

No disk access, browser access or migration on import. A brand is a price
column; a page is the independently selected monitoring identity.
"""
from copy import deepcopy
import re
from urllib.parse import parse_qsl, urlencode, urlsplit


_VOLATILE = {
    "checkin", "checkout", "check_in", "check_out", "checkindate",
    "checkoutdate", "check_in_date", "check_out_date", "checkin_date",
    "checkout_date", "chkin", "chkout", "date1", "date2", "startdate", "enddate", "dates",
    "adults", "children", "childrenages", "childages", "rooms", "guests",
    "currency", "selectedcurrency", "curr", "lang", "language", "locale",
    "sid", "sessionid", "session_id", "unique_share_id", "source_impression_id",
    "source", "ref", "referrer", "gclid", "fbclid", "aid", "label",
    "search_id", "searchid", "federated_search_id",
}


def page_key(url):
    """Ignore stay/tracking changes, retain property identifiers in queries."""
    try:
        p = urlsplit((url or "").strip())
        if p.scheme not in ("http", "https") or not p.hostname:
            return ""
        host = p.hostname.lower().removeprefix("www.")
        path = p.path.rstrip("/") or "/"
        # Public property pages keep one identity when dates, tracking and
        # locale change. Never collapse extranet or search pages this way.
        # The whole Airbnb FAMILY is one identity (D122 brand rule): .fr,
        # .co.in, .com and share links ("?s=67") are the SAME listing —
        # the number is the identity (D110). Before this, only airbnb.com
        # collapsed, so a tab left on "airbnb.fr/rooms/910?s=67" no longer
        # matched the saved key "airbnb.fr/rooms/910" and the D120 open-tab
        # filter silently dropped the listing from every scan (client
        # 2026-10-26: three listings rejected "outside retained selection").
        if path.startswith("/rooms/") and re.match(r"(^|\.)airbnb\.[a-z.]+$", host):
            listing_id = re.match(r"/rooms/(\d+)", path)
            if listing_id:
                return "airbnb.com/rooms/" + listing_id.group(1)
        if (host == "booking.com" or host.endswith(".booking.com")) and path.startswith("/hotel/") and not host.startswith("admin."):
            stable_path = re.sub(r"\.[a-z]{2}(?:-[a-z]{2})?\.html$", ".html", path, flags=re.I)
            return "booking.com" + stable_path.lower()
        if host == "agoda.com" or host.endswith(".agoda.com"):
            if not host.startswith("portal."):
                property_id = next((v for k, v in parse_qsl(p.query)
                                    if k.lower() == "propertyid" and v.isdigit()), "")
                if property_id:
                    return "agoda.com/property/" + property_id
                if path != "/" and not path.endswith("/accom/property"):
                    return "agoda.com" + path.lower()
        query = sorted(
            (k.lower(), v) for k, v in parse_qsl(p.query, keep_blank_values=True)
            if k.lower() not in _VOLATILE and not k.lower().startswith("utm_"))
        suffix = ("?" + urlencode(query)) if query else ""
        # SPA routes can identify different properties; ordinary anchors cannot.
        fragment = "#" + p.fragment if p.fragment.startswith(("/", "!/")) else ""
        return host + path + suffix + fragment
    except (ValueError, TypeError):
        return ""


def profile_urls(profile):
    urls = [profile.get("url") or ""]
    urls += list(profile.get("watch_urls") or [])
    urls += list(profile.get("listings") or [])
    return list({page_key(u): u for u in urls if page_key(u)}.values())


def _canonical_choice_key(stored_key):
    value = str(stored_key or "")
    return page_key(value if "://" in value else "https://" + value)


def _stored_choice(choices, key):
    if key in choices:
        return bool(choices[key])
    # Pre-upgrade choices used full tracking queries. The newest choice for
    # this property wins until the next save migrates them to one stable key.
    for old_key in reversed(list(choices)):
        if _canonical_choice_key(old_key) == key:
            return bool(choices[old_key])
    return None


def page_active(watch, url):
    key = page_key(url)
    if not key:
        return False
    choices = watch.get("tab_choices") or {}
    saved = _stored_choice(choices, key)
    if saved is not None:
        return saved
    return any(o.get("active", True) and
               key in {page_key(u) for u in profile_urls(o)}
               for o in watch.get("otas") or [])


def merge_pages(detected, watch):
    """Exact page association only; never consume a profile by browser order."""
    by_page = {}
    for profile in watch.get("otas") or []:
        for url in profile_urls(profile):
            by_page.setdefault(page_key(url), profile)
    result = []
    for row in detected:
        d = dict(row)
        profile = by_page.get(page_key(d.get("url")))
        d["brand_name"] = d.get("brand_name") or d.get("name", "")
        if profile:
            d["name"] = profile.get("name") or d["name"]
        d["profile_name"] = profile.get("name", "") if profile else ""
        d["auto_name"] = profile is None
        d["active"] = page_active(watch, d.get("url"))
        result.append(d)
    return result


def save_page_choices(watch, rows):
    """Return a copy; preserve closed pages and metadata, including listings.

    Selecting a new page deliberately registers it. Pages of one OTA share
    a price column, but their choices are never collapsed by display name.
    """
    out = deepcopy(watch)
    profiles = out.setdefault("otas", [])
    choices = out.setdefault("tab_choices", {})
    for old_key, value in list(choices.items()):
        stable = _canonical_choice_key(old_key)
        if stable and stable != old_key:
            choices[stable] = bool(value)
            del choices[old_key]
    # Freeze legacy per-profile defaults before updating the aggregate flag.
    for profile in profiles:
        for url in profile_urls(profile):
            choices.setdefault(page_key(url), bool(profile.get("active", True)))
    for row in rows:
        url = row.get("url") or ""
        key = page_key(url)
        name = (row.get("profile_name") or row.get("brand_name") or
                row.get("name") or "").strip()
        if not key or not name:
            continue
        active = bool(row.get("active"))
        choices[key] = active
        if not active:
            continue
        profile = next((o for o in profiles
                        if key in {page_key(u) for u in profile_urls(o)}), None)
        if profile is None:
            profile = next((o for o in profiles if o.get("name") == name), None)
        if profile is None:
            profile = {"name": name, "url": url, "active": True}
            profiles.append(profile)
        # I138: an INCOMPLETE profile (name/url wiped, e.g. by the old
        # name-only dedupe) is REPAIRED from the very page the user just
        # re-selected — the checkbox must fix the zombie, not preserve it.
        # Other settings (targets, watch_urls) are preserved; the profile
        # is never re-activated implicitly (only `active` above, driven by
        # the explicit row state, decides that).
        if not (profile.get("name") or "").strip():
            profile["name"] = name
        if not (profile.get("url") or "").strip():
            profile["url"] = url
        urls = profile_urls(profile)
        if key not in {page_key(u) for u in urls}:
            urls.append(url)
        profile["watch_urls"] = urls
        if "airbnb" in (urlsplit(url).hostname or "").split("."):
            profile["listings"] = urls
    for profile in profiles:
        profile["active"] = any(choices.get(page_key(u), False)
                                for u in profile_urls(profile))
    return out


def selected_profiles(watch):
    """Scan-only copies. Never prune the persistent configuration."""
    selected = []
    for profile in watch.get("otas") or []:
        urls = [u for u in profile_urls(profile) if page_active(watch, u)]
        if not urls:
            continue
        item = dict(profile, active=True, url=urls[0], watch_urls=urls)
        if "listings" in profile:
            item["listings"] = urls
        selected.append(item)
    return selected


def selected_page_keys(watch):
    return {page_key(u) for p in selected_profiles(watch)
            for u in profile_urls(p)}
