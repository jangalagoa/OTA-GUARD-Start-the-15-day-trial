"""Persist scan outcome separately from the last successful observation."""
from copy import deepcopy


def record_outcome(watch, results, status, timestamp, errors=(), pages=()):
    previous = watch.get('last_results') or {}
    if previous and watch.get('last_scan_status', 'completed') == 'completed':
        watch['last_successful_scan'] = {'time': watch.get('last_scan_time'),
                                         'results': deepcopy(previous)}
    current = dict(results) if status != 'selection_changed' else {}
    watch['last_results'] = current
    watch['last_scan_time'] = timestamp
    watch['last_scan_status'] = status
    watch['last_scan_attempt'] = {'time': timestamp, 'status': status,
                                  'errors': list(errors), 'page_keys': sorted(pages or [])}
    if status == 'completed' and current:
        watch['last_successful_scan'] = {'time': timestamp, 'results': deepcopy(current)}
