"""
lang.py — Static translation, pre-generated catalogs.

The software is written in French. Translations into the other languages
are generated offline, before delivery (see tools/i18n_batch_translate.py),
and shipped with the software in locales/{lang}.json. At runtime, t() only
does an in-memory read — no network call, no disk write.

Usage: tr_("Hotel name") → "Hotel name" (if language = en)
"""
import json
import logging
import sys
from pathlib import Path

log = logging.getLogger(__name__)

from core.paths import INSTALL_DIR
from core.i18n_overrides import get_overrides

LOCALES_INSTALL_DIR = INSTALL_DIR / "locales"    # bundled catalogs (read-only)

_lang_code: str  = "fr"         # French = source language of the code
_cache: dict     = {}           # {french_text: translation}
_cache_values: set = set()      # already-translated values (detects double pass)
_overrides: dict = {}           # manual corrections for the active language
_DEV_MODE = not (getattr(sys, "frozen", False) or "__compiled__" in globals())
_warned_missing: set = set()    # avoids logging the same missing key 100 times


def load_language(lang_code: str = "en") -> None:
    """Load the bundled static catalog for the requested language."""
    global _lang_code, _cache, _cache_values, _overrides
    _lang_code = (lang_code or "fr").strip().lower()
    _overrides = get_overrides(_lang_code)

    if _lang_code == "fr":
        _cache = {}
        _cache_values = set()
        return

    catalog_file = LOCALES_INSTALL_DIR / f"{_lang_code}.json"
    try:
        _cache = json.loads(catalog_file.read_text(encoding="utf-8"))
        _cache_values = set(_cache.values())
        log.info("[Lang] Catalog %s loaded: %d entries", _lang_code, len(_cache))
    except Exception as e:
        _cache = {}
        _cache_values = set()
        log.warning("[Lang] Catalog %s missing or invalid: %s", _lang_code, e)


def t(text: str) -> str:
    """Translate a UI text — pure read, no network.

    - If language = fr → returned as-is
    - Otherwise → manual override > static catalog > original text (safety net)
    """
    if _lang_code == "fr" or not text or not text.strip():
        return text

    override = _overrides.get(text)
    if override:
        return override

    cached = _cache.get(text)
    if cached:
        return cached

    # Text already translated (present among the catalog values): this is the
    # universal patch (main.py::_safe_tr) re-processing a text already
    # translated by a first explicit tr_() call. Nothing to report, this
    # is not a missing translation.
    if text in _cache_values:
        return text

    if _DEV_MODE and text not in _warned_missing:
        _warned_missing.add(text)
        # Dynamic UI values (URLs, prices, names) are not catalog failures.
        # Keep the fallback diagnostic available without flooding client logs.
        log.debug("[Lang] Missing translation (%s): %r", _lang_code, text)

    return text


# ⚠ UNUSED as of 2026-07-22 — function with no call anywhere in the project (audit G3).
#   Kept voluntarily; do not rely on it without rewiring and testing it first.
def get_lang() -> str:
    """Return the active language code."""
    return _lang_code
