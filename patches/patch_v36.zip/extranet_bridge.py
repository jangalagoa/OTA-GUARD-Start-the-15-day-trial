"""
"Extranet Direct" (VAE 2) ↔ application seam — mirror of vae_bridge.py.

Role (strictly limited, D1/D14: no deep modification of V2):
  1. read the CM state from the passive captures of the VAE listener
     (same files as the vae2 scanner — no request emitted, R1/R3);
  2. run ONE correction through the vae2 coordinator (brick 3) in a
     separate thread — the Tkinter UI is never blocked;
  3. after a verified REAL shipment, record the measurement into
     core.send_history so the V2 loop (sent → displayed) keeps working
     exactly as with the CM API.

Every real action stays behind the owner's manual validation
("Apply" in the tab) — plan E4: manual validation first.
"""
import json
import threading
from dataclasses import asdict
from pathlib import Path

from core.utils import tr_  # D60: engine messages translated

# D104 — path anchor: NEVER the __file__ of THIS module. When this file
# is served by the patch loader, __file__ points into
# %APPDATA%\...\data\patches\ — the "PROJECT_ROOT" derived from there made
# captures_dir and the CM map unfindable on EVERY patched exe
# ("Channel Manager status: 0 rooms" since patch v2, 10/06).
# core.paths.INSTALL_DIR is the startup bootstrap (never patched) and
# always knows the real folder of the software, exe OR source.
try:
    from core.paths import INSTALL_DIR as _INSTALL_DIR
    PROJECT_ROOT = Path(_INSTALL_DIR)
except Exception:
    PROJECT_ROOT = Path(__file__).resolve().parent
V3_SANDBOX = PROJECT_ROOT / "sandbox" / "e4"
DEFAULT_CM_MAP = "channelmanager_com_au.yaml"

# D55: product limit of the Extranet Direct channel (annex A to the terms
# of sale, §4-c): a single property, up to TWENTY rooms. The correction
# time grows linearly with the number of rooms
# (≈1 h queue for 4 rooms x 60 days; 4-5 h at 20; 12 h+ at 50 —
# beyond that the channel is not designed for it). The CM API remains
# the channel for large properties. Checked against the REAL size of the
# property (rooms of the CM grid), not the current shipment.
EXTRANET_MAX_ROOMS = 20


def active_cm_map(app_config=None):
    """D49 — map of the ACTIVE CM (a single one at a time, product
    constraint: VAE2 never works with several CMs simultaneously). Read in
    channel_manager.extranet_direct.cm_map (file name in
    vae2/maps/), default = channelmanager_com_au.yaml. Missing or
    invalid file → silent fallback to the default, never an exception in
    the middle of a push."""
    name = ""
    try:
        if app_config is None:
            from core import config as _cfg
            app_config = _cfg.load()
        name = str((((app_config or {}).get("channel_manager") or {})
                    .get("extranet_direct") or {}).get("cm_map") or "").strip()
    except Exception:
        name = ""
    if not name or "/" in name or "\\" in name or ".." in name \
            or not name.lower().endswith(".yaml"):
        name = DEFAULT_CM_MAP
    cand = PROJECT_ROOT / "vae2" / "maps" / name
    if not cand.exists():
        cand = PROJECT_ROOT / "vae2" / "maps" / DEFAULT_CM_MAP
    return cand

# D56: USER stop of the running queue (⏹ Stop button) — distinct from
# SHUTDOWN (app closing). Set = the queue stops BEFORE the next
# task (never in the middle of a typing: D12). Cleared at the
# start of each queue.
QUEUE_STOP = threading.Event()


def request_stop():
    """D107: STOP = STOP — sets ALL the user stop flags:
    the queue (remaining segments) AND the executor (the current step:
    typing stops at the action boundary, the page is left as-is)."""
    QUEUE_STOP.set()
    try:
        from vae2.executor import STOP_REQUESTED
        STOP_REQUESTED.set()
    except Exception:
        pass


def clear_stop():
    """D107: every queue starts cleanly — no residual ⏹ flag
    left (otherwise a queue started right after a stop would refuse
    every task without explanation)."""
    QUEUE_STOP.clear()
    try:
        from vae2.executor import STOP_REQUESTED
        STOP_REQUESTED.clear()
    except Exception:
        pass

# D33: clean stop of the shipment queues at app closing. On 08/27,
# a closed-window process (Exit 16:04) kept pushing prices
# until 17:29 in parallel with the restarted instance — two executors in
# the same form. Exit raises this flag; the loops back off
# BEFORE the next task (never in the middle of a typing: D12 stays
# in charge until the end of the current task).
SHUTDOWN = threading.Event()


# ── D98: GLOBAL PAUSE (⏸ button next to ⏹) ──────────────────────────────
# The tool prevents NOTHING from starting while paused is not set: the
# owner works on his PC, Brave jumps to the foreground (OS raises
# D31/D93, bringToFront, keepalive reloads, scans navigating the
# tabs) and he must re-minimize the window every few minutes.
# PAUSE = total peace of mind:
#   - NO new operation (scan / push / correction / verification):
#     operation_begin refuses;
#   - NO keepalive reload (the loop skips, 60 s deferrals);
#   - NO OS raise nor bringToFront nor unthrottle (the exe no longer
#     wakes the Brave window);
#   - the RUNNING task finishes cleanly (D12: never in the middle
#     of a typing) — pause ≠ stop.
# Session-only, default OFF: a forgotten pause would stop the protection
# silently. The ⏸/▶ button (tab_blocage_ota) sets/clears the flag.
PAUSED = threading.Event()


def pause_set() -> None:
    """Sets the global pause — no more activity, no more stolen window."""
    PAUSED.set()
    try:
        from diagnostic.recorder import event as _bb
        _bb("pause_on", "info", {})
    except Exception:
        pass


def pause_clear() -> None:
    """Clears the global pause — the tool resumes its normal pace."""
    PAUSED.clear()
    try:
        from diagnostic.recorder import event as _bb
        _bb("pause_off", "info", {})
    except Exception:
        pass


def is_paused() -> bool:
    return PAUSED.is_set()


def request_shutdown():
    """Signaled by the app Exit (app.py::_on_close) — the extranet
    shipment queues stop before the next task."""
    SHUTDOWN.set()
    # D107: Exit ALSO cuts the current step (no more typing that
    # keeps going after the window closes — lesson from the 08/27 zombie).
    try:
        from vae2.executor import STOP_REQUESTED
        STOP_REQUESTED.set()
    except Exception:
        pass


# ── E5: session keep-alive (D9) — singleton started a single time ──────

_KEEPALIVE = None
_KEEPALIVE_LOCK = threading.Lock()

# D37-2: anti-parallel-push lock — a SINGLE extranet executor at a
# time in the whole process (queue OR manual task). On 08/28
# 13:16-13:25, two simultaneous queues drove the same CDP form
# (checkboxes unchecked by the other, calendar closed, fields emptied
# during typing). D33 covered clean Exit + 2nd instance, not two
# concurrent push flows WITHIN the same app.
_PUSH_LOCK = threading.Lock()

# D52: ONE SINGLE operation at a time in the whole process (scan OR
# extranet correction). On 08/29, scan cycles arrived DURING
# the marathon queues -> refusals in series ("already running"). From
# now on the running operation cleanly blocks the launch of a second one.
_OPERATION = {"kind": None, "since": ""}
_OP_STATE_LOCK = threading.Lock()


def operation_begin(kind: str) -> bool:
    """Reserves the operation slot. False = another operation is running
    OR the global pause is set (D98 — traced refusal, dedicated message)."""
    from datetime import datetime as _dt
    with _OP_STATE_LOCK:
        if _OPERATION["kind"] is not None:
            try:  # D91: black box — traced refusal, never fatal
                from diagnostic.recorder import event as _bb
                _bb("operation_refused", "warn",
                    {"kind": kind, "busy_with": _OPERATION["kind"]})
            except Exception:
                pass
            return False
        if PAUSED.is_set():
            try:  # D98: pause refusal — traced too
                from diagnostic.recorder import event as _bb
                _bb("operation_refused", "info",
                    {"kind": kind, "reason": "paused"})
            except Exception:
                pass
            return False
        _OPERATION["kind"] = kind
        _OPERATION["since"] = _dt.now().strftime("%H:%M:%S")
    try:  # D91: black box — outside the lock, never fatal
        from diagnostic.recorder import event as _bb
        _bb("operation_begin", "info", {"kind": kind})
    except Exception:
        pass
    return True


def operation_end(kind: str) -> None:
    """Releases the slot (idempotent, tolerant to different orders)."""
    with _OP_STATE_LOCK:
        if _OPERATION["kind"] == kind:
            _OPERATION["kind"] = None
            _OPERATION["since"] = ""
    try:  # D91: black box — never fatal
        from diagnostic.recorder import event as _bb
        _bb("operation_end", "info", {"kind": kind})
    except Exception:
        pass


def operation_current() -> str:
    """Name of the running operation ('' if none)."""
    with _OP_STATE_LOCK:
        return _OPERATION["kind"] or ""


def operation_since() -> str:
    with _OP_STATE_LOCK:
        return _OPERATION["since"] or ""


def ensure_keepalive(say=print):
    """Starts (a single time) the E5 session keep-alive: hard reload
    (ignoreCache) of the CM tabs at a RANDOM 10-20 min interval,
    NEVER during an edition (EDITION flag), never any tab opened
    or closed (D24). Settings read in the map (session.keepalive)."""
    global _KEEPALIVE
    with _KEEPALIVE_LOCK:
        if _KEEPALIVE is not None:
            return _KEEPALIVE
        try:
            from vae2.keepalive import ExtranetKeepalive
            _ka = ExtranetKeepalive.from_map(
                active_cm_map(), log_sink=lambda m: say(f"[keepalive] {m}"))
            _ka.start()
            _KEEPALIVE = _ka
        except Exception as e:
            say(f"[keepalive] cannot start: {e}")
    return _KEEPALIVE


class _Edition:
    """Context manager: raises the keepalive.EDITION flag while the
    executor drives a tab — the keep-alive NEVER reloads during
    that time (plan §4.5)."""

    def __enter__(self):
        try:
            from vae2.keepalive import EDITION
            EDITION.set()
        except Exception:
            pass
        return self

    def __exit__(self, *exc):
        try:
            from vae2.keepalive import EDITION
            EDITION.clear()
        except Exception:
            pass
        return False


# ── Passive captures folder ──────────────────────────────────────────

def _newest_capture_mtime(d: Path) -> float:
    """mtime of the newest capture file in a folder (0 if none).

    D102: the capture folder is written and purged WHILE we walk it — a
    file can vanish between glob() and stat(). Each stat is guarded so a
    vanished file costs its own skip, never the whole scan (client
    2026-10-07: the CM passive read crashed on this exact race and the
    anchor grid went silent for every room)."""
    newest = 0.0
    try:
        for f in d.glob("*.json"):
            try:
                m = f.stat().st_mtime
            except OSError:
                continue
            if m > newest:
                newest = m
        return newest
    except OSError:
        return 0


def captures_dir(app_config=None) -> Path:
    """Where the VAE listener writes its captures:
    1. explicit setting (config "extranet_direct.captures_dir", read at
       root level OR under channel_manager);
    2. the FRESHEST folder between vae_standalone (old dev console
       listener) and the embedded vae/ (integrated listener of the app).
    Bug 08/23-26 (root cause of the repeated "submitted_but_change_not_seen",
    found on 08/26): the fixed preference for vae_standalone made it read
    STALE captures (last one from 08/23 17:09) while the integrated
    listener wrote fresh captures — the shipment worked but the
    verification compared with a 3-day delay. We now choose
    the candidate whose newest capture is the freshest.
    None of these folders is EVER written by this module."""
    for tree in (app_config or {},
                 (app_config or {}).get("channel_manager") or {}):
        try:
            d = (tree.get("extranet_direct") or {}).get("captures_dir")
            if d:
                return Path(d)
        except Exception:
            pass
    cands = [Path.home() / "Downloads" / "vae_standalone" / "vae" / "data"
             / "api_discovery",
             PROJECT_ROOT / "vae" / "data" / "api_discovery"]
    cands = [c for c in cands if c.exists()]
    if not cands:
        return cands[-1] if cands else PROJECT_ROOT / "vae" / "data" / "api_discovery"
    return max(cands, key=_newest_capture_mtime)


# ── Reading the CM state ────────────────────────────────────────────────

def capture_folders_report(app_config=None):
    """D103 — candidate capture folders, FOR DISPLAY in
    the Extranet Direct tab. "0 rooms" must never be silent:
    the section shows each folder (path, capture count, freshness)
    and the one actually read carries chosen=True. Read-only,
    never an exception."""
    out = []
    seen = {}

    def _add(label, p):
        try:
            p = Path(p)
            key = str(p)
            if key in seen:
                return
            seen[key] = len(out)
            n, newest = 0, 0.0
            exists = p.is_dir()
            if exists:
                for f in p.glob("*.json"):
                    n += 1
                    try:
                        m = f.stat().st_mtime
                    except OSError:
                        continue
                    if m > newest:
                        newest = m
            out.append({"label": label, "path": key, "count": n,
                        "newest": newest, "exists": exists,
                        "chosen": False})
        except Exception:
            pass

    try:
        for tree, lab in ((app_config or {}, "config"),
                          ((app_config or {}).get("channel_manager") or {},
                           "config(cm)")):
            d = (tree.get("extranet_direct") or {}).get("captures_dir")
            if d:
                _add(lab, d)
    except Exception:
        pass
    _add("vae_standalone",
         Path.home() / "Downloads" / "vae_standalone" / "vae" / "data"
         / "api_discovery")
    _add("app (embedded vae)", PROJECT_ROOT / "vae" / "data"
         / "api_discovery")
    try:
        chosen = captures_dir(app_config)
        if str(chosen) in seen:
            out[seen[str(chosen)]]["chosen"] = True
        else:
            n, newest, exists = 0, 0.0, False
            try:
                exists = chosen.is_dir()
                if exists:
                    for f in chosen.glob("*.json"):
                        n += 1
                        try:
                            m = f.stat().st_mtime
                        except OSError:
                            continue
                        if m > newest:
                            newest = m
            except Exception:
                pass
            out.append({"label": "read folder", "path": str(chosen),
                        "count": n, "newest": newest, "exists": exists,
                        "chosen": True})
    except Exception:
        pass
    return out


# ── Pending-shipment safeguard (D136 rule, D138 repairs) ────────────────────
# A shipment whose proof has not been seen on the grid yet must not be
# blindly resent on the same room/OTA/dates. The client incident of
# 10-26..27 (180 waits frozen for days, Goibibo/Expedia pushed nothing)
# came from waits that could NEVER resolve:
#   - stays already in the past (nobody will ever display them again),
#   - a grid never re-read after the POST.
# D138 repairs, WITHOUT weakening the control:
#   1. past stays expire on their own;
#   2. no wait may outlive PENDING_MAX_AGE_DAYS;
#   3. a conflicting segment is SKIPPED — the queue keeps flowing with
#      the other segments (the 10-27 halt froze 40 segments because ONE
#      pending wait stopped the whole batch);
#   4. every successful grid scan clears the waits it confirms
#      (_resolve_pending_from_report) and the post-submit verification
#      re-reloads the OTASheet tab once more if no fresh capture shows
#      up (vae2.coordinator) — the proof is PROVOKED, not hoped for.

PENDING_MAX_AGE_DAYS = 3.0
_PENDING_LOCK = threading.RLock()


def _pending_file():
    from core.paths import DATA_DIR
    return Path(DATA_DIR) / "cm_pending_verification.json"


def _pending_key(task):
    return json.dumps([
        str(task.room_label).strip().casefold(),
        str(task.ota_label).strip().casefold(),
        str(task.rate).strip(), task.date_from, task.date_to,
    ], ensure_ascii=False, separators=(",", ":"))


def _read_pending():
    p = _pending_file()
    if not p.exists():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    if (not isinstance(data, dict) or
            any(not isinstance(item, dict) or
                not isinstance(item.get("task"), dict)
                for item in data.values())):
        raise ValueError(f"Invalid CM pending-verification file: {p}")
    return data


def _write_pending(data):
    import os
    p = _pending_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        os.replace(tmp, p)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _expire_pending():
    """D138-1/2: drop the waits that can never resolve.

    A wait whose stay lies entirely in the past, or older than
    PENDING_MAX_AGE_DAYS, frees the shipment. The control itself is
    untouched: the send history keeps its pending measure and a later
    observation can still confirm it."""
    import time as _time
    from datetime import date as _date
    today = _date.today().isoformat()
    now = _time.time()
    with _PENDING_LOCK:
        data = _read_pending()
        expired = []
        for key, item in list(data.items()):
            task = item.get("task") or {}
            stay_past = str(task.get("date_to") or "") < today
            too_old = (now - float(item.get("created_at") or 0)
                       > PENDING_MAX_AGE_DAYS * 86400.0)
            if stay_past or too_old:
                expired.append((key, stay_past, too_old))
                del data[key]
        if expired:
            _write_pending(data)
            try:
                import logging
                logging.info(
                    "[EXTRANET] %d pending shipment wait(s) expired "
                    "(%d past stay(s), %d older than %.1f day(s))",
                    len(expired),
                    sum(1 for _k, past, _old in expired if past),
                    sum(1 for _k, _past, old in expired if old),
                    PENDING_MAX_AGE_DAYS)
            except Exception:
                pass
        return len(expired)


def _pending_conflict(task):
    """Any unresolved shipment for overlapping room/OTA dates blocks a POST
    (D136). Expiry runs first so a dead wait can never block anything."""
    _expire_pending()
    with _PENDING_LOCK:
        for item in _read_pending().values():
            old = item.get("task") or {}
            if (str(old.get("room_label") or "").strip().casefold()
                    != str(task.room_label).strip().casefold() or
                    str(old.get("ota_label") or "").strip().casefold()
                    != str(task.ota_label).strip().casefold()):
                continue
            if (str(old.get("date_from") or "") <= task.date_to and
                    task.date_from <= str(old.get("date_to") or "")):
                return old
    return None


def _reserve_pending(task):
    """Persist intent before touching the browser; a crash cannot resend it."""
    import time as _time
    with _PENDING_LOCK:
        data = _read_pending()
        data[_pending_key(task)] = {"task": asdict(task),
                                    "created_at": _time.time()}
        _write_pending(data)


def _forget_pending(task):
    with _PENDING_LOCK:
        data = _read_pending()
        if data.pop(_pending_key(task), None) is not None:
            _write_pending(data)


def _resolve_pending_from_report(report):
    """A later, complete fresh grid clears a pending POST automatically
    (D136) — the proof comes from OUR reloads, never from luck."""
    import logging
    from datetime import datetime
    from vae2.scanner import grid_shows_rate

    source = report.sources_status.get("otasheet_grid") or {}
    if not source.get("found"):
        return
    try:
        stamp = datetime.fromisoformat(
            str(source.get("captured_at") or "").replace("Z", "+00:00")
        ).timestamp()
        state = asdict(report)
        with _PENDING_LOCK:
            data = _read_pending()
            resolved = []
            for key, item in data.items():
                task = item.get("task") or {}
                if stamp < float(item.get("created_at") or 0):
                    continue
                if grid_shows_rate(state, task.get("room_label", ""),
                                   task.get("ota_label", ""),
                                   task.get("rate"),
                                   task.get("date_from", ""),
                                   task.get("date_to", "")):
                    resolved.append(key)
            if resolved:
                for key in resolved:
                    del data[key]
                _write_pending(data)
                logging.info("[EXTRANET] %d pending shipment(s) confirmed "
                             "by a later fresh OTASheet capture", len(resolved))
    except (OSError, ValueError, TypeError, KeyError):
        logging.exception("[EXTRANET] pending-verification check failed")


_last_scan = None   # in-memory cache: data of the last successful scan


def scan_cm(app_config=None, save_before=True, say=print):
    """Scans the captures and returns the normalized state (vae2.scanner).
    Also saves the "before" report (reference of the future diff).

    D34 (08/27, "before it opened the tab" behavior restored):
    if the reading does NOT find a usable grid (status != ok or
    zero rooms), we RELOAD the OTASheet tab — opened if missing,
    only with a live CM session (guard included in
    vae2.coordinator.reload_otasheet, recipe 22/23) — then we read again.
    Fast path unchanged when a fresh grid already exists: no
    browser action. A wake-up failure never prevents the
    reading: the captures are returned as-is."""
    global _last_scan
    import time as _time
    from vae2.scanner import run_scan

    def _run():
        return run_scan(captures_dir(app_config), active_cm_map(app_config))

    rep = _run()
    if rep.status != "ok" or not rep.rooms:
        say("[EXTRANET] no usable grid in the captures — "
            "waking the OTASheet tab (reloaded/opened if needed)")
        try:
            from vae2.coordinator import reload_otasheet
            import asyncio as _aio
            # Up to 2 wake-ups: if the tab was just OPENED, its
            # grid loads BEFORE the listener attaches to it (detection
            # cycle 10 s — the trap of 08/27 evening); the 1st attempt
            # lets the monitor find it, the 2nd RELOADS the now-listened
            # tab → the grid captures are emitted for sure.
            for _attempt in range(2):
                _aio.run(reload_otasheet(map_path=active_cm_map(app_config)))
                _time.sleep(12.0 if _attempt == 0 else 4.0)
                rep = _run()
                say(f"[EXTRANET] wake-up { _attempt + 1}/2: status={rep.status}, "
                    f"rooms={len(rep.rooms)}")
                if rep.status == "ok" and rep.rooms:
                    break
        except Exception as e:
            say(f"[EXTRANET] OTASheet wake-up impossible ({e}) — reading "
                "the existing captures only")
    if rep.status == "ok":
        _last_scan = asdict(rep)
        # D138: this fresh grid is exactly the proof the pending waits
        # need — free every shipment it confirms, on the spot.
        try:
            _resolve_pending_from_report(rep)
        except Exception:
            pass
        if save_before:
            V3_SANDBOX.mkdir(parents=True, exist_ok=True)
            (V3_SANDBOX / "before_app.json").write_text(
                json.dumps(_last_scan, indent=2, ensure_ascii=False),
                encoding="utf-8")
    return rep


def cm_state(app_config=None):
    """State of the last scan (scan beforehand if necessary).
    Returns a dict: captured_at, currency, rooms [{code,label}],
    otas [{code,label}], daily {(room,ota,date): price}."""
    global _last_scan
    if _last_scan is None:
        rep = scan_cm(app_config, save_before=False)
        if rep.status != "ok":
            return None
    d = _last_scan
    daily = {}
    for cell in d.get("daily_prices") or []:
        if cell.get("kind") == "availability" or cell.get("price") is None:
            continue
        daily[(str(cell.get("room_id")), str(cell.get("ota_id")),
               str(cell.get("date")))] = cell.get("price")
    return {
        "captured_at": d.get("captured_at"),
        "currency": d.get("currency"),
        "rooms": [{"code": str(r["room_id"]), "label": r["label"]}
                  for r in d.get("rooms") or []],
        "otas": [{"code": str(o["ota_id"]), "label": o["label"]}
                 for o in d.get("otas") or []],
        "daily": daily,
    }


def daily_price(room_code, ota_code, date_iso, app_config=None):
    """Current daily price (OTASheet grid) for room×OTA×date."""
    st = cm_state(app_config)
    if not st:
        return None
    return st["daily"].get((str(room_code), str(ota_code), str(date_iso)))


# ── Running a correction (separate thread) ─────────────────────────────

def run_correction(task_dict, confirmed=False, say=print, done=None,
                   app_config=None):
    """Starts the coordinator in the background.
    `task_dict`: {room_label, ota_label, rate, date_from, date_to, days?}
    `say(line)`: each journal line (called from the thread).
    `done(result_dict)`: called at the end (thread)."""
    from vae2.coordinator import run_task, Task

    def _worker():
        result = None
        try:
            # D98: global pause — the task is ignored (dedicated message).
            if is_paused():
                say("[EXTRANET] ⏸ " + tr_("global pause — task ignored "
                                          "(resume with ▶ Resume)"))
                result = {"outcome": "paused",
                          "error": "global pause active"}
            # D37-2: same lock as the queue — a single executor at a time
            # in the whole process, manual path included.
            elif not _PUSH_LOCK.acquire(blocking=False):
                say("[EXTRANET] 🛑 an extranet shipment is ALREADY running — "
                    "task ignored (D37 lock)")
                result = {"outcome": "push_locked",
                          "error": "an extranet shipment is already running"}
            elif not operation_begin("push"):
                _PUSH_LOCK.release()
                say(f"[EXTRANET] 🛑 operation \"{operation_current()}\" "
                    f"running — task ignored (D52: one single operation)")
                result = {"outcome": "push_locked",
                          "error": "a scan/a correction is already running"}
            else:
                try:
                    ensure_keepalive(say)
                    task = Task(**task_dict)
                    with _Edition():
                        result = run_task(
                            task, map_path=active_cm_map(app_config),
                            captures_dir=captures_dir(app_config),
                            confirmed=confirmed,
                            before_report=V3_SANDBOX / "before_app.json",
                            after_out=V3_SANDBOX / "after_app.json",
                            journal_path=V3_SANDBOX / "journal_app.json",
                            log_sink=say)
                    # real shipment WITH POST proof → the measurement enters
                    # the V2 loop (D38: submitted_but_change_not_seen
                    # counts too — the POST is proven sent, only the
                    # diff did not see the change; without this a manual
                    # shipment left NO trace in the history
                    # and the anchor restarted from a stale figure).
                    if result.get("outcome") in (
                            "verified", "submitted_but_change_not_seen"):
                        try:
                            _record_send_history(task_dict)
                            say("[send_history] measurement recorded (pending)")
                        except Exception as e:
                            say(f"[send_history] recording failed: {e}")
                finally:
                    operation_end("push")
                    _PUSH_LOCK.release()
        except Exception as e:
            say(f"[error] {e}")
            result = {"outcome": "exception", "error": str(e)}
        if done:
            try:
                done(result)
            except Exception:
                pass

    t = threading.Thread(target=_worker, daemon=True,
                         name="vae2-extranet-correction")
    t.start()
    return t


def _record_send_history(task_dict):
    """"Sent" measurement in the same format as the CM API pushes
    (core/send_history.py) — the OTA observation will come from the normal scan."""
    from core import send_history as _sh
    _sh.record_send(
        ota_name=task_dict.get("ota_label", ""),
        room=task_dict.get("room_label", ""),
        sent=int(float(task_dict.get("rate", 0))),
        target=None,
        observed_before=None,
        stay_date=task_dict.get("date_from", ""),
        simulated=False,
        device="extranet_direct",
    )


def record_queue_sent_items(sent_items, app_config=None):
    """D105-2 — records the segments that REALLY went out of a batch that
    ended in group failure (1-2 failed segments out of 95 must not
    deprive the learning loop of the 93 that succeeded).

    Each item {room, ota, rate, from} is recorded under the MONITORED NAME
    of the OTA (the learning files are named by monitored OTA —
    "airbnb_double_room", not the CM label "AirBnB"): matching by
    case-insensitive substring CM → monitored. Without a certain
    match, the item is skipped (never a parasite file). Fail-safe:
    a recording failure is logged, never propagated."""
    import logging as _logging
    try:
        from core import send_history as _sh
        _monitored = []
        for o in ((app_config or {}).get("ota_watch") or {}).get(
                "otas") or []:
            _n = (o.get("name") or "").strip()
            if _n:
                _monitored.append(_n)
        n_ok = 0
        for it in sent_items or []:
            try:
                _cm = str(it.get("ota") or "").strip().lower()
                _room = str(it.get("room") or "").strip()
                if not _cm or not _room:
                    continue
                _matches = [m for m in _monitored if _cm in m.lower()]
                if len(_matches) != 1:
                    continue        # ambiguous or unknown: we do not guess
                _sh.record_send(
                    ota_name=_matches[0],
                    room=_room,
                    sent=int(float(it.get("rate") or 0)),
                    target=None,
                    observed_before=None,
                    stay_date=str(it.get("from") or ""),
                    simulated=False,
                    device="extranet_direct",
                )
                n_ok += 1
            except Exception:
                _logging.exception("[send_history] batch item not "
                                   "recorded: %s", it)
        return n_ok
    except Exception:
        _logging.exception("[send_history] cannot record the batch "
                           "items")
        return 0


# ── Transport dispatcher (E4 seam) ───────────────────────────────────────

def push_rates(cm_cfg, room_pushes, checkin=None, nights=1,
               delay_seconds=5, log_cb=None, progress_cb=None,
               stop_event=None, allow_locked=False):
    """Transport router: Extranet Direct if enabled in the config
    (channel_manager.extranet_direct.enabled), otherwise the classic CM API.
    Contract IDENTICAL to business.channel_manager.push_rates_to_cm_by_ota —
    the callers (app_core._do_push, floor/ceiling corrections) only
    change their import.

    D148 — allow_locked=False (default): any segment overlapping a
    locked AND enabled calendar event is DROPPED here, at the router,
    whatever the caller — the OTA price block can NEVER touch a locked
    price. Only the seasonal drift-restoration writers pass
    allow_locked=True (seasonal_loop, « Push locked prices »)."""
    # D98: global pause — NO transport sends (guard at the router
    # level: API and Extranet Direct are covered in one piece).
    if is_paused():
        _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))
        _say("[EXTRANET] ⏸ " + tr_("global pause — shipment refused "
                                    "(resume with ▶ Resume)"))
        _groups_p = {}
        for rp in room_pushes:
            _oc = str(rp.get("ota_code", "") or "").strip()
            _groups_p.setdefault(_oc, []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("the tool is ON PAUSE — no activity "
                            "until ▶ Resume"),
                 "body": "", "n": len(v), "sent": 0}
                for k, v in _groups_p.items()]
    # D79: rate grid — shipments refused above the signed room
    # limit (CM grid count > declaration).
    try:
        from licensing.limits import operation_allowed
        import core.config as _cfg_mod
        _ok, _why = operation_allowed(_cfg_mod.load())
        if not _ok:
            _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))
            _say("[EXTRANET] 🛑 " + _why)
            _groups_d79 = {}
            for rp in room_pushes:
                _oc = str(rp.get("ota_code", "") or "").strip()
                _groups_d79.setdefault(_oc, []).append(rp)
            return [{"ota_code": k, "ok": False, "msg": _why,
                     "body": "", "n": len(v), "sent": 0}
                    for k, v in _groups_d79.items()]
    except Exception:
        pass
    # D148 — LOCKED = UNTOUCHABLE (owner order 02/11): a locked AND
    # enabled calendar event protects its dates from EVERY price-block
    # shipment, on BOTH transports, at the router level. A segment
    # containing a locked night is dropped with an explicit message.
    # Escape hatch: allow_locked=True (seasonal restoration only).
    if not allow_locked and room_pushes:
        try:
            from business.price_calendar import get_locked_dates
            _cfg_src = cm_cfg if isinstance(cm_cfg, dict) and \
                (cm_cfg.get("price_calendar") or {}) else None
            if _cfg_src is None:
                try:
                    import core.config as _cc
                    _cfg_src = _cc.load()
                except Exception:
                    _cfg_src = {}
            _dropped = []
            _kept = []
            for rp in room_pushes:
                fd = str(rp.get("from_date") or "").strip()
                td = str(rp.get("to_date") or "").strip()
                if not fd or not td:
                    _kept.append(rp)          # flat push: stay window below
                    continue
                try:
                    from datetime import date as _d8
                    _span = max(1, (_d8.fromisoformat(td) -
                                    _d8.fromisoformat(fd)).days + 1)
                except Exception:
                    _span = 1
                _lk = get_locked_dates(_cfg_src, fd, _span)
                if _lk:
                    _dropped.append(rp)
                else:
                    _kept.append(rp)
            _final = []
            for rp in _kept:
                if not str(rp.get("from_date") or "").strip() and checkin:
                    try:
                        _nn = max(1, int(nights or 1))
                    except Exception:
                        _nn = 1
                    _lk = get_locked_dates(_cfg_src, checkin, _nn)
                    if len(_lk) >= _nn:       # the WHOLE stay is locked
                        _dropped.append(rp)
                        continue
                _final.append(rp)
            if _dropped:
                _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))
                _say("[EXTRANET] 🔒 " + tr_(
                    "{n} segment(s) skipped — locked calendar dates are "
                    "untouchable (D148)").format(n=len(_dropped)))
                try:
                    import logging as _lg8
                    _lg8.info("[EXTRANET] 🔒 D148: %d segment(s) dropped "
                              "overlapping locked calendar dates",
                              len(_dropped))
                except Exception:
                    pass
            room_pushes = _final
            if not room_pushes:
                _groups = {}
                for rp in _dropped:
                    _oc = str(rp.get("ota_code", "") or "").strip()
                    _groups.setdefault(_oc, []).append(rp)
                return [{"ota_code": k, "ok": False,
                         "msg": tr_("every segment is locked — nothing "
                                    "sent (D148)"),
                         "body": "", "n": len(v), "sent": 0}
                        for k, v in _groups.items()]
        except Exception as _e148:
            try:
                import logging as _lg8
                _lg8.warning("[EXTRANET] D148 lock check skipped: %s", _e148)
            except Exception:
                pass
    try:
        xd = ((cm_cfg or {}).get("extranet_direct") or {})
        enabled = bool(xd.get("enabled"))
    except Exception:
        enabled = False
    # D80: legal ledger — instructions entrusted to the transport (verbatim)
    # then verdict per group. Write failure non-blocking.
    try:
        from business import legal_ledger as _ll
        _ll.journal_push_order(room_pushes, transport=(
            "extranet-direct" if enabled else "api-cm"))
    except Exception:
        pass
    if enabled:
        results = push_rates_via_extranet(cm_cfg, room_pushes,
                                          checkin=checkin, nights=nights,
                                          log_cb=log_cb,
                                          progress_cb=progress_cb,
                                          stop_event=stop_event)
    else:
        from business.channel_manager import push_rates_to_cm_by_ota
        results = push_rates_to_cm_by_ota(cm_cfg, room_pushes,
                                          checkin=checkin, nights=nights,
                                          delay_seconds=delay_seconds,
                                          log_cb=log_cb)
    # D80: verdict of each group into the evidence ledger
    try:
        from business import legal_ledger as _ll
        for _r in results or []:
            _ll.journal_push_result(_r.get("ota_code"), _r.get("ok"),
                                    _r.get("sent", _r.get("n")),
                                    _r.get("msg"))
    except Exception:
        pass
    return results


def revive_cm_tabs(cm_cfg, say=print, wait_s=8.0):
    """D87: wake-up of the CM tabs when the form is dead at
    preflight — Page.reload ignoreCache on the EXISTING tabs (the
    exact keepalive mechanics; the browser reloads by itself,
    R4, never any tab opened/closed). The half-dead form is
    ALREADY unusable: the reload cannot break anything and the
    retry restarts on a live page. Number of reloads returned."""
    try:
        import asyncio
        from vae2.keepalive import ExtranetKeepalive
        ka = ExtranetKeepalive.from_map(
            active_cm_map(cm_cfg),
            log_sink=lambda m: say(f"[keepalive] {m}"))
        tabs = ka._tabs()
        n = 0

        async def _go():
            nonlocal n
            for _t in tabs:
                if await ka._reload(_t):
                    n += 1
        asyncio.run(_go())
        if n:
            say("[EXTRANET] " + tr_("🔄 CM wake-up: {n} tab(s) "
                                    "reloaded — waiting {s} s then "
                                    "segment retry").format(
                n=n, s=int(wait_s)))
            import time as _t
            _t.sleep(wait_s)
        return n
    except Exception as e:
        say(f"[EXTRANET] CM wake-up impossible: {e}")
        return 0


def push_rates_via_extranet(cm_cfg, room_pushes, checkin=None, nights=1,
                            log_cb=None, progress_cb=None,
                            stop_event=None):
    """Pushes the rates via extranet execution (real browser,
    trusted events — zero API request). Return contract identical
    to push_rates_to_cm_by_ota. Called from a background thread
    (the UI is never blocked). One category at a time (D8), verification
    on the grid after each shipment.

    D37-2: anti-parallel-push lock — a second push arriving while
    another is running is REFUSED cleanly (ok=False result with
    explicit message), never run in parallel.
    D52: one single operation in the whole process — a push started
    during a SCAN is refused, and progress_cb(done, total, label) follows
    the queue progress."""
    _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))

    # Parity with the OTA Guard test mode (C16): nothing goes out, everything is OK.
    try:
        from business.channel_manager import _is_test_mode
        if _is_test_mode(cm_cfg):
            _say("[EXTRANET] " + tr_("OTA Guard test mode — no price sent (API parity)"))
            _groups = {}
            for rp in room_pushes:
                _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                                   []).append(rp)
            return [{"ota_code": k, "ok": True,
                     "msg": tr_("Test mode — no real shipment"),
                     "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    except Exception:
        pass

    if is_paused():   # D98: global pause — no shipment starts
        _say("[EXTRANET] ⏸ " + tr_("global pause — shipment refused "
                                    "(resume with ▶ Resume)"))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("the tool is ON PAUSE — no activity "
                            "until ▶ Resume"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    if not _PUSH_LOCK.acquire(blocking=False):
        _say("[EXTRANET] " + tr_("🛑 an extranet push is ALREADY running — "
                                "request refused (anti-parallel-push lock)"))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("an extranet shipment is already running — wait "
                           "for it to finish then restart (anti-parallel-push lock)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    if not operation_begin("push"):
        _PUSH_LOCK.release()
        _say("[EXTRANET] " + tr_("🛑 operation \"{k}\" running since "
                                "{s} — shipment refused (D52: one single "
                                "operation at a time)").format(
            k=operation_current(), s=operation_since()))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("a scan/a correction is already running — "
                           "one single operation at a time (D52)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]
    try:
        return _push_rates_via_extranet_locked(cm_cfg, room_pushes,
                                               checkin=checkin,
                                               nights=nights,
                                               log_cb=log_cb,
                                               progress_cb=progress_cb,
                                               stop_event=stop_event)
    finally:
        operation_end("push")
        _PUSH_LOCK.release()


def _push_rates_via_extranet_locked(cm_cfg, room_pushes, checkin=None,
                                    nights=1, log_cb=None, progress_cb=None,
                                    stop_event=None):
    """Execution body of the extranet push — ALWAYS called under _PUSH_LOCK."""
    from datetime import date, timedelta
    from vae2.coordinator import run_task, Task

    _say = log_cb or (lambda m: print(f"[EXTRANET] {m}"))

    # code → label resolution via the passively read grid
    st = cm_state(cm_cfg)
    if not st:
        try:
            scan_cm(cm_cfg, save_before=True, say=_say)
            st = cm_state(cm_cfg)
        except Exception:
            st = None
    if not st:
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("CM state unavailable (capture scan)"),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]

    rooms_by_code = {r["code"]: r["label"] for r in st["rooms"]}
    otas_by_code = {o["code"]: o["label"] for o in st["otas"]}

    # D55: size limit — the property managed by the CM must not
    # exceed EXTRANET_MAX_ROOMS rooms. Refusal BEFORE any shipment.
    _n_rooms = len(st.get("rooms") or [])
    if _n_rooms > EXTRANET_MAX_ROOMS:
        _say("[EXTRANET] " + tr_("🛑 refused: the property has {n} "
                                "rooms (Extranet Direct limit: {m}) — "
                                "properties of this size "
                                "require the CM API").format(
            n=_n_rooms, m=EXTRANET_MAX_ROOMS))
        _groups = {}
        for rp in room_pushes:
            _groups.setdefault(str(rp.get("ota_code", "") or "").strip(),
                               []).append(rp)
        return [{"ota_code": k, "ok": False,
                 "msg": tr_("configuration not supported by the "
                            "Extranet Direct channel: the property has {n} "
                            "rooms (maximum {m}). Properties of "
                            "this size require the CM API channel.").format(
                    n=_n_rooms, m=EXTRANET_MAX_ROOMS),
                 "body": "", "n": len(v), "sent": 0} for k, v in _groups.items()]

    stay_from = checkin or date.today().isoformat()
    try:
        nd = max(1, int(nights or 1))
    except (ValueError, TypeError):
        nd = 1
    stay_to = (date.fromisoformat(stay_from) +
               timedelta(days=nd - 1)).isoformat()

    # Fresh "before" scan for the diff verification
    scan_cm(cm_cfg, save_before=True, say=_say)

    groups, order = {}, []
    for rp in room_pushes:
        key = str(rp.get("ota_code", "")).strip()
        groups.setdefault(key, []).append(rp)
        if key not in order:
            order.append(key)

    def _month_ranges(d_from: date, d_to: date):
        """Multi-month splitting: the datepicker CANNOT navigate between
        months (arrows inoperative in that state — observed live
        21/37). Each sub-range stays within ONE single month → zero
        navigation needed."""
        out = []
        _d, _end = d_from, d_to
        while _d <= _end:
            _eom = (date(_d.year + 1, 1, 1) if _d.month == 12
                    else date(_d.year, _d.month + 1, 1)) - timedelta(days=1)
            _r_end = min(_end, _eom)
            out.append((_d.isoformat(), _r_end.isoformat()))
            _d = _r_end + timedelta(days=1)
        return out

    def _ranges_for(rp: dict):
        """Ranges to send for THIS entry (D33). The V2 generator
        (weekend / locked dates) already cuts dated segments carried by
        from_date/to_date — we RESPECT them: each price
        only reaches ITS dates. Without segment dates (flat push,
        backward compatible), the full requested range. Before D33, each
        segment was applied to the WHOLE period: they overwrote
        each other and the last one won — weekend markup erased
        (08/27: 2591 flat instead of 2591/2850 weekday/weekend)."""
        _sf = str(rp.get("from_date") or "").strip()
        _st = str(rp.get("to_date") or "").strip()
        try:
            if _sf and _st and _sf <= _st:
                return _month_ranges(date.fromisoformat(_sf),
                                     date.fromisoformat(_st))
        except ValueError:
            _say("[EXTRANET] " + tr_("invalid segment dates "
                                    "({a}..{b}) → full range "
                                    "used").format(a=_sf, b=_st))
        return _month_ranges(date.fromisoformat(stay_from),
                             date.fromisoformat(stay_to))

    results = []
    _consec_failures = 0   # circuit breaker: stop hammering a broken target
    ensure_keepalive(_say)
    # D52: total number of segments known in advance -> X/Y progress
    _total_tasks = 0
    for _key in order:
        for _rp in groups[_key]:
            try:
                _total_tasks += len(_ranges_for(_rp))
            except Exception:
                _total_tasks += 1
    _done_tasks = 0

    def _tick(label: str):
        nonlocal _done_tasks
        _done_tasks += 1
        if progress_cb:
            try:
                progress_cb(_done_tasks, _total_tasks, label)
            except Exception:
                pass

    if progress_cb:
        try:
            progress_cb(0, _total_tasks, "queue preparation")
        except Exception:
            pass
    # D56: every queue starts cleanly. D107: BOTH ⏹ flags
    # (queue + executor) are cleared together — a residual one would kill the queue.
    clear_stop()
    _revives_left = 4     # D87: max 4 CM wake-ups per queue
    with _Edition():       # E5: no keep-alive reload during the batch
      for key in order:
        group = groups[key]
        ota_label = otas_by_code.get(key)
        ok_all, msgs, sent_ok = True, [], []
        # D105-2: STRUCTURED list of the segments that really went out — when a
        # batch ends ok=False because of 1-2 failed segments, the caller could
        # lose the memory of the 93 that succeeded (client PC 10/08-09: zero
        # Expedia measurement despite massive POST proofs). The caller
        # records these measurements even on group failure.
        sent_items = []
        for rp in group:
            # D78: the ⏹ must be able to cut BETWEEN the segments — otherwise
            # the stop is ignored during the whole shipping phase (lesson
            # from 09/21: clicks ignored for 30 min, nothing displayed).
            if stop_event is not None and stop_event.is_set():
                _say("[EXTRANET] " + tr_("🛑 stop requested — remaining "
                                        "segments cancelled ({r}/{n} "
                                        "sent for this OTA)").format(
                    r=len(sent_ok), n=len(group)))
                ok_all = False
                msgs.append(tr_("INTERRUPTED: stop requested (⏹) — "
                                "remaining segments not sent"))
                break
            if _consec_failures >= 3:
                ok_all = False
                msgs.append(tr_("INTERRUPTED: 3 consecutive failures — "
                                "batch stopped to avoid hammering "
                                "(go back to the CM tab in Brave then "
                                "restart)"))
                _say("[EXTRANET] " + tr_("🛑 Circuit breaker: 3 consecutive "
                                        "failures — batch interrupted"))
                break
            room_label = rooms_by_code.get(str(rp.get("room_code", "")).strip())
            if not room_label:
                ok_all = False
                msgs.append(tr_("room code {c} not found on the "
                                "grid").format(c=rp.get('room_code')))
                continue
            if not ota_label:
                ok_all = False
                msgs.append(tr_("OTA code {c} not found on the "
                                "grid").format(c=key))
                continue
            try:
                rate = str(int(round(float(rp["price"]))))
            except (KeyError, TypeError, ValueError) as e:
                ok_all = False
                msgs.append(tr_("invalid price ({e})").format(e=e))
                continue
            _rp_ranges = _ranges_for(rp)
            if len(_rp_ranges) > 1:
                _say("[EXTRANET] " + tr_("multi-month range → {n} "
                                        "sub-ranges (datepicker navigation "
                                        "unreliable)").format(
                    n=len(_rp_ranges)))
            for _from, _to in _rp_ranges:
                if QUEUE_STOP.is_set():
                    ok_all = False
                    msgs.append(tr_("⏹ stopped by the user — queue "
                                    "stopped before the next task"))
                    _say("[EXTRANET] " + tr_("⏹ Stop requested by the "
                                            "user — queue stopped "
                                            "cleanly before the next "
                                            "task"))
                    break
                if SHUTDOWN.is_set():
                    ok_all = False
                    msgs.append(tr_("INTERRUPTED: application "
                                    "closing — shipment queue stopped "
                                    "before the next task"))
                    _say("[EXTRANET] " + tr_("🛑 App closing — "
                                            "queue stopped cleanly before "
                                            "the next task"))
                    break
                task = Task(room_label=room_label, ota_label=ota_label,
                            rate=rate, date_from=_from, date_to=_to)
                # D138: never resend an unproven shipment on the same
                # room/OTA/dates — but a conflict now SKIPS this segment
                # only; the queue keeps flowing (the 10-27 client halt
                # froze 40 segments because ONE pending wait stopped the
                # whole batch). A dead wait cannot even conflict: expiry
                # runs first (past stays, PENDING_MAX_AGE_DAYS).
                _skip_pending = False
                try:
                    previous = _pending_conflict(task)
                    if previous:
                        _skip_pending = True
                        _skip_msg = tr_(
                            "shipment skipped: another shipment {r}/{o} "
                            "({a}..{b}) is still awaiting grid proof"
                        ).format(r=room_label, o=ota_label,
                                 a=previous.get('date_from'),
                                 b=previous.get('date_to'))
                        msgs.append(_skip_msg)
                        _say("[EXTRANET] 🛑 " + _skip_msg)
                        _tick(f"{room_label} / {ota_label} → {rate} "
                              f"({_from}..{_to})")
                        ok_all = False
                    else:
                        _reserve_pending(task)
                except (OSError, ValueError, TypeError) as e:
                    # The safeguard itself is unreadable — nothing leaves
                    # (same rule as D136), but the queue still says why.
                    ok_all = False
                    msgs.append(tr_("CM pending-verification safeguard "
                                    "unavailable ({e})").format(e=e))
                    _say("[EXTRANET] 🛑 " + tr_(
                        "CM pending-verification safeguard unavailable — "
                        "no new POST sent"))
                    break
                if _skip_pending:
                    continue
                _say(f"[EXTRANET] {room_label} / {ota_label} → {rate} "
                     f"({_from}..{_to})")
                _outcome = None
                for _retry in range(2):  # 1 attempt + 1 retry if transient
                    try:
                        res = run_task(task, map_path=active_cm_map(cm_cfg),
                                       captures_dir=captures_dir(cm_cfg),
                                       confirmed=True,
                                       before_report=V3_SANDBOX / "before_app.json",
                                       after_out=V3_SANDBOX / "after_app.json",
                                       journal_path=V3_SANDBOX / "journal_app.json",
                                       log_sink=_say)
                        _outcome = res.get("outcome")
                        # D117: "already in place" = success just like
                        # "verified" — no retry.
                        if _outcome in ("verified", "already_in_place"):
                            break
                        # D107: a ⏹ is NOT a failure — never retried,
                        # never counted in the circuit breaker. The segment
                        # is cancelled, the queue stops (flags set).
                        if _outcome == "stopped_by_user":
                            _say("[EXTRANET] " + tr_(
                                "⏹ Segment cancelled by the user — "
                                "current step interrupted, page left "
                                "as-is"))
                            break
                        # retry only on transient errors
                        if _outcome in ("executor_failed", "preflight_failed") \
                                and _retry == 0:
                            _say("[EXTRANET] " + tr_("⏳ retry {r} "
                                                    "({o})…").format(
                                r=room_label, o=_outcome))
                            # D87: form dead at preflight = RELOAD the
                            # CM tabs before replaying (a simple sleep
                            # replayed on the still-dead page — the 3 failures
                            # in a row of 09/26).
                            if _outcome == "preflight_failed" and _revives_left > 0:
                                _revives_left -= 1
                                revive_cm_tabs(cm_cfg, say=_say)
                            else:
                                import time as _t; _t.sleep(5)
                            continue
                        break
                    except Exception as e:
                        _outcome = f"exception {e}"
                        if _retry == 0:
                            _say("[EXTRANET] " + tr_("⏳ retry after "
                                                    "exception…"))
                            import time as _t; _t.sleep(5)
                            continue
                        break
                _tick(f"{room_label} / {ota_label} → {rate} "
                      f"({_from}..{_to})")
                # D138: the wait has served its purpose — settled outcomes
                # free the segment (a refusal never left the browser, a
                # verified/in-place shipment has its grid proof).
                if _outcome in ("verified", "already_in_place",
                                "preflight_failed", "cm_login_required",
                                "refused_window"):
                    try:
                        _forget_pending(task)
                    except (OSError, ValueError, TypeError) as e:
                        _say(f"[EXTRANET] pending record not cleared: {e}")
                if _outcome in ("verified", "already_in_place"):
                    # D117: "already in place" = success — the POST went out
                    # (proof) and the grid already displays the sent price;
                    # restoring the same value is invisible to the diff
                    # (D33-a). Message "✓ already in place", not a failure.
                    _consec_failures = 0
                    sent_ok.append(tr_("{r} → {p} ({a}..{b}) {v}").format(
                        r=room_label, p=rate, a=_from, b=_to,
                        v=("✓ grid-verified" if _outcome == "verified"
                           else "✓ already in place (grid-confirmed)")))
                    sent_items.append({"room": room_label, "ota": ota_label,
                                       "rate": rate, "from": _from, "to": _to})
                    _say("[EXTRANET] " + tr_(
                        "✅ {r} / {o}: {v} ({a}..{b})").format(
                        r=room_label, o=ota_label, a=_from, b=_to,
                        v=("verified on the grid" if _outcome == "verified"
                           else "already in place — confirmed on the grid")))
                elif _outcome == "submitted_but_change_not_seen":
                    # D37-1: the POST is PROVEN sent (post-proof D32) —
                    # only the strict diff did not see the change. Known
                    # cause: an instruction that RESTORES the queue-start
                    # value is invisible in the diff (documented false
                    # negative D33-a). Failing the whole group — hence the
                    # whole push → ok=False → NO measurement recorded — for
                    # a verification false negative broke the whole
                    # learning loop (08/28: ~75 verified shipments,
                    # zero measurement recorded, everything shown as failed).
                    # The group stays OK; the note stays visible in the msg.
                    _consec_failures = 0
                    sent_ok.append(tr_("{r} → {p} ({a}..{b}) ✓ sent "
                                       "(POST proof)").format(
                        r=room_label, p=rate, a=_from, b=_to))
                    sent_items.append({"room": room_label, "ota": ota_label,
                                       "rate": rate, "from": _from, "to": _to})
                    _say(f"[EXTRANET] ✅ {room_label} / {ota_label}: "
                         f"sent — POST proof ok, change not seen on "
                         f"the grid ({_from}..{_to}) — probable "
                         f"restoration (known false negative)")
                    msgs.append(tr_("{r} ({a}..{b}): sent (POST proof) "
                                    "— change not detected on the grid "
                                    "(probable restoration)").format(
                        r=room_label, a=_from, b=_to))
                elif _outcome == "cm_login_required":
                    # not a "failure" to count: the 2-click auto-login
                    # (D26, Brave autofill) was already attempted and
                    # failed — human action required, clean stop
                    ok_all = False
                    msgs.append(tr_("CM session expired — the automatic "
                                    "re-login (2 clicks, Brave autofill) "
                                    "did not succeed: log in once in the "
                                    "BulkUpdate tab of "
                                    "Brave then restart the shipment"))
                    _say("[EXTRANET] " + tr_("🔑 CM session expired — "
                                            "auto-login failed, manual "
                                            "login required in "
                                            "the BulkUpdate tab of Brave "
                                            "(no tab opened or "
                                            "closed)"))
                    break
                else:
                    _consec_failures += 1
                    ok_all = False
                    msgs.append(tr_("{r} ({a}..{b}): {o}").format(
                        r=room_label, a=_from, b=_to, o=_outcome))
                if _consec_failures >= 3:
                    _say(f"[EXTRANET] 🛑 3 consecutive failures — "
                         f"batch stopped")
                    break
        # D40: the SUCCESSFUL shipments ALSO show up in the group message —
        # the "Latest submissions" panel must show room/price/dates
        # of what went out, not only the errors. Failures
        # stay at the top (read first), successes behind.
        # D42: "sent" = number of shipments that REALLY went out (verified +
        # POST proof) — the panel shows green if everything is ok, ORANGE if
        # at least one shipment went out despite failures, red otherwise.
        _parts = msgs + (["✓ " + " ; ".join(sent_ok)] if sent_ok else [])
        results.append({"ota_code": key, "ok": ok_all,
                        "msg": " | ".join(_parts) or tr_("sent and "
                                                        "verified (grid)"),
                        "body": "", "n": len(group),
                        "sent": len(sent_ok),
                        "sent_items": sent_items})
    return results
