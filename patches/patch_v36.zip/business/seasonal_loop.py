"""business/seasonal_loop.py — D76: the seasonal correction loop.

OWNER GO-AHEAD (09/20): assemble verify → compute → push →
wait → re-verify until the OTA DISPLAYS the target (within the
event tolerance), with a max number of iterations.

The building blocks (all already proven in real use):
  - displayed read: dated room-grid reader (D72) via
    seasonal_nav.verify_future_event — unread nights = never guessed;
  - in-place price read: passive CM grid (cm_state/OTASheet,
    D34/D38) — the grid is the truth;
  - THE computation law (owner's loop/compute.py, D35):
        send = in_place_price × target ÷ displayed
    zero hidden guard — every step is logged read/computed/sent;
  - push: the existing ROUTER (extranet_bridge.push_rates, D57) —
    the same path as "📤 Push the locked prices"; it manages
    its own locks (_PUSH_LOCK + D52 slot "push");
  - the loop's D52 lock: taken for verify+compute, RELEASED
    before the push (D75: always with the exact name), taken again after;
  - wait: STOP.wait(minutes) — interruptible by ⏹.

Safety (owner protocol): nothing is sent without a listing;
dry_run=True = computes everything and sends NOTHING (blank test); an
unread night or a silent grid cell is SKIPPED and logged —
no invented value (spirit of D12).
"""
import threading
import time
from datetime import date, timedelta

from core.utils import tr_

MAX_ITERS_DEFAULT = 3
WAIT_MINUTES_DEFAULT = 10

# ⏹ Cooperative stop (D53/D56): set by the button, read between the
# loop phases (verification, computation, wait).
STOP = threading.Event()


def reset_stop():
    STOP.clear()


def compute_send(price_in_place, displayed, target):
    """THE single law (owner's loop/compute.py). Raises ValueError
    on a zero input — never an invented division."""
    if not price_in_place or not displayed or not target:
        raise ValueError(
            f"compute_send needs three non-zero values, got "
            f"in_place={price_in_place}, displayed={displayed}, "
            f"target={target}")
    return int(round(price_in_place * target / displayed))


def _norm_date(s):
    s = str(s or "")
    return s.replace(".", "-")[:10]


# ── D82: cover nights beyond the CM grid window ────────────────────────────
# The passively read OTASheet grid is anchored on today's date
# (#/D=today) and its window stops ~100 days later — a
# Dec→January event leaves January "silent" (finding 09/21: the
# loop skipped 2027-01-01..03). Solution: navigate the EXISTING
# OTASheet tab to the missing window (same mechanism as D34,
# never a closed tab), re-read, MERGE the two grids, then
# bring the tab back to its page.

def _set_anchor(url, night_iso):
    """OTASheet URL with the #/D= fragment rewritten towards night_iso.
    None if the URL is empty. The fragment drives the date window."""
    import re as _re
    u = str(url or "")
    if not u:
        return None
    if _re.search(r"#/D=\d{4}-\d{2}-\d{2}", u):
        return _re.sub(r"#/D=\d{4}-\d{2}-\d{2}", f"#/D={night_iso}", u)
    return u.split("#")[0] + f"#/D={night_iso}"


def _uncovered_dates(entries, st):
    """Dates of the nights to correct that the CM grid does not cover."""
    covered = {d for (_r, _o, d) in ((st or {}).get("daily") or {})}
    return sorted({e.get("date") for e in entries
                   if not e.get("ok") and e.get("date")
                   and e.get("date") not in covered})


def _merge_cm_states(old, new):
    """Merges two grid states (different date windows):
    daily/rooms/otas deduplicated — BOTH windows stay readable."""
    if not old:
        return new
    if not new:
        return old
    rooms = {str(r.get("code")): r
             for r in (old.get("rooms") or []) + (new.get("rooms") or [])}
    otas = {str(o.get("code")): o
            for o in (old.get("otas") or []) + (new.get("otas") or [])}
    daily = dict(old.get("daily") or {})
    daily.update(new.get("daily") or {})
    return {"captured_at": (new or old).get("captured_at"),
            "currency": (new or old).get("currency"),
            "rooms": list(rooms.values()), "otas": list(otas.values()),
            "daily": daily}


def ensure_cm_window(app_config, night_iso, log=print, ui=None):
    """cm_state covering night_iso — navigates the OTASheet tab if the
    current window ignores it, then brings the tab back. Returns the
    MERGED state (old + new dates) or the state as-is if impossible
    (never an exception towards the caller)."""

    def _ui(m, tag="mut"):
        if ui:
            try:
                ui(m, tag)
            except Exception:
                pass

    import extranet_bridge as xb
    import business.seasonal_nav as snav

    def _covered(st):
        return any(d == night_iso
                   for (_r, _o, d) in ((st or {}).get("daily") or {}))

    try:
        st = xb.cm_state(app_config)
        if _covered(st):
            return st
        from vae2.adapters import ExtranetAdapter
        from business import cm_sites
        from urllib.parse import urlsplit
        adapter = ExtranetAdapter.from_map(xb.active_cm_map(app_config))
        card_url = adapter.page_url("read") or adapter.page_url("otasheet")
        tabs = snav._tabs()
        cm_sites.learn_from_tab_paths(tabs, {"read": card_url})
        hosts = set(cm_sites.all_hosts(adapter.domain))
        read_path = urlsplit(card_url or "").path.rstrip("/").casefold()
        tab = next((t for t in tabs
                    if cm_sites.host_of(t.get("url", "")) in hosts
                    and read_path
                    and urlsplit(t.get("url", "")).path.rstrip("/").casefold()
                    == read_path), None)
        if tab is None:
            log("      ⚠️ OTASheet tab not open — CM window not "
                f"extended (nights beyond {night_iso} without in-place price)")
            return st
        original = tab.get("url")
        new_url = _set_anchor(original, night_iso)
        if not new_url or new_url == original:
            return st
        _ui(tr_("   🧭 CM grid window too short — OTASheet tab navigated to {d}…").format(d=night_iso))
        if not snav._navigate(tab, new_url, wait_s=12, log=log):
            return st
        try:
            xb._last_scan = None          # force the capture re-read
            rep = xb.scan_cm(app_config, save_before=False, say=log)
            st2 = xb.cm_state(app_config)
            merged = _merge_cm_states(st, st2)
            if _covered(merged):
                _ui(tr_("   ✅ CM window extended — {d} covered").format(
                    d=night_iso), "ok")
            else:
                _ui(tr_("   ⚠️ CM window not extended after navigation — nights of {d} still without in-place price")
                    .format(d=night_iso), "warn")
            return merged
        finally:
            if original:
                snav._navigate(tab, original, wait_s=snav._RESTORE_WAIT_S,
                               log=lambda m: None)
                _ui(tr_("   ↩️ OTASheet tab restored to its page"))
    except Exception as e:
        log(f"      ⚠️ CM window extension impossible ({e})")
        try:
            return xb.cm_state(app_config)
        except Exception:
            return None


def cm_price_of(st, room_label, ota_name, night_iso):
    """In-place price on the CM grid (cm_state) for room×OTA×date.
    None if the grid is silent for this cell. Goibibo↔MMT alias
    (same inventory — house convention)."""
    if not st:
        return None
    ol = (ota_name or "").strip().lower()
    ol = "goibibo" if ol == "makemytrip" else ol
    ota_code = None
    for o in st.get("otas") or []:
        if str(o.get("label", "")).strip().lower() == ol:
            ota_code = str(o.get("code"))
            break
    if ota_code is None:
        return None
    rl = (room_label or "").strip().lower()
    for r in st.get("rooms") or []:
        if str(r.get("label", "")).strip().lower() == rl:
            daily = st.get("daily") or {}
            p = daily.get((str(r.get("code")), ota_code, night_iso))
            if p is None:                      # defensive: dotted dates
                for (rc, oc, d), v in daily.items():
                    if rc == str(r.get("code")) and oc == ota_code \
                            and _norm_date(d) == night_iso:
                        p = v
                        break
            if p is None:
                return None
            try:
                return int(round(float(p)))
            except (TypeError, ValueError):
                return None
    return None


def build_push_entry(cm_cfg, room, ota_name, night_iso, price):
    """Push entry (same shape as "Push the locked prices")
    for ONE night: from=the night, to=the next day (exclusive end).
    None if the mapping does not know this room/OTA pair — no
    invented codes."""
    mapping = ((cm_cfg or {}).get("room_mapping") or {})
    m = mapping.get(room)
    if not isinstance(m, dict):
        return None
    rc = (m.get("room_code") or "").strip()
    if not rc:
        return None
    for plan in m.get("rate_plans") or []:
        if (plan.get("ota_name") or "").strip().lower() \
                != (ota_name or "").strip().lower():
            continue
        entry = {
            "room_code": rc, "room_label": room,
            "ota_label": (ota_name or None),
            "rate_plan_code": (plan.get("rate_plan_code") or "1").strip(),
            "price": int(price),
            "from_date": night_iso,
            "to_date": (date.fromisoformat(night_iso)
                        + timedelta(days=1)).isoformat(),
        }
        oc = str(plan.get("ota_code") or "").strip()
        if oc:
            entry["ota_code"] = oc
        return entry
    return None


def collect_corrections(app_config, event, entries, st, log=print, ui=None,
                        only_room=None, only_ota=None):
    """For each verification entry OUTSIDE tolerance: read the in-place
    price, compute the send by THE law. Returns (corrections, skipped)
    — corrections = dicts {entry, in_place, send}."""
    from business.seasonal_verify import event_tolerance

    def _ui(m, tag=None):
        if ui:
            try:
                ui(m, tag)
            except Exception:
                pass

    corrections, skipped = [], []
    for e in entries:
        if e.get("ok"):
            continue
        room, ota = e.get("room"), e.get("ota")
        if only_room and only_room.lower() not in (room or "").lower():
            continue
        if only_ota and only_ota.lower() not in (ota or "").lower():
            continue
        expected = float(e.get("expected") or 0)
        displayed = float(e.get("displayed") or 0)
        tol, _desc = event_tolerance(event, expected)
        if abs(e.get("drift") or 0) <= tol:
            continue                        # already within tolerance
        in_place = cm_price_of(st, room, ota, e.get("date"))
        if not in_place:
            skipped.append((e, tr_("CM grid silent for this cell")))
            _ui(tr_("   ⚠️ {d} · {room}/{ota}: CM grid silent — night skipped (no value invented)").format(
                d=e.get("date"), room=room, ota=ota), "warn")
            log(f"      CM grid silent {e.get('date')} {room}/{ota} — "
                "skipped")
            continue
        try:
            send = compute_send(in_place, displayed, expected)
        except ValueError as ex:
            skipped.append((e, str(ex)))
            continue
        corrections.append({"entry": e, "in_place": in_place, "send": send})
        # D80: the observed in-place price goes to the evidence journal —
        # it grounds the correction decision (fact, not conclusion).
        try:
            from business import legal_ledger as _ll
            _ll.journal_cm_price(room, ota, e.get("date"), in_place)
        except Exception:
            pass
        _ui(tr_("   🧮 {d} · {room}/{ota}: read {ip} in place, displayed {dp} → SEND COMPUTED {s}").format(
            d=e.get("date"), room=room, ota=ota, ip=f"{in_place:,.0f}",
            dp=f"{displayed:,.0f}", s=f"{send:,.0f}"), "tit")
        log(f"      computation {e.get('date')} {room}/{ota}: in_place="
            f"{in_place} displayed={displayed:,.0f} target={expected:,.0f} "
            f"→ send={send}")
    return corrections, skipped


def push_corrections(app_config, corrections, log=print, ui=None,
                     progress_cb=None):
    """Pushes the corrections through the ROUTER (configured transport).
    One push entry per (room, OTA, night). Returns (results,
    n_entries)."""
    import extranet_bridge as xb
    cm_cfg = app_config.get("channel_manager", {})
    pushes, missing = [], []
    for c in corrections:
        e = c["entry"]
        entry = build_push_entry(cm_cfg, e.get("room"), e.get("ota"),
                                 e.get("date"), c["send"])
        if entry is None:
            missing.append(e)
            log(f"      ⚠️ CM mapping missing for {e.get('room')}/"
                f"{e.get('ota')} — no send for this cell")
            continue
        pushes.append(entry)
    if not pushes:
        return [], 0
    checkin = pushes[0]["from_date"]
    results = xb.push_rates(cm_cfg, pushes, checkin=checkin, nights=1,
                            log_cb=log, progress_cb=progress_cb,
                            stop_event=STOP, allow_locked=True)
    return results, len(pushes)


def run_correction_loop(app_config, event, log=print, ui=None,
                        max_iters=MAX_ITERS_DEFAULT,
                        wait_minutes=None, dry_run=False,
                        only_room=None, only_ota=None,
                        progress_cb=None) -> dict:
    """The complete loop. Returns a summary dict:
    {converged, reason, iterations, dry_run, corrections, pushed,
     not_read_nights, drifts_before, drifts_after}."""
    import extranet_bridge as xb
    import business.seasonal_nav as snav
    from business.seasonal_verify import event_tolerance

    reset_stop()          # an earlier ⏹ (scan/push) must not kill
    #                       this loop — STOP restarts from zero here.

    def _ui(m, tag=None):
        if ui:
            try:
                ui(m, tag)
            except Exception:
                pass

    today = date.today()
    from business.price_calendar import resolve_event_dates
    start, end = resolve_event_dates(event, today)
    if start is None:
        return {"converged": False, "reason": "invalid dates",
                "iterations": 0, "dry_run": dry_run, "corrections": 0,
                "pushed": 0, "not_read_nights": 0, "drifts_before": 0,
                "drifts_after": 0}
    try:
        raw_wm = wait_minutes if wait_minutes is not None \
            else event.get("wait_minutes")
        # explicit 0 = no wait (do not confuse with absent)
        wm = int(raw_wm) if raw_wm not in (None, "") \
            else WAIT_MINUTES_DEFAULT
    except (TypeError, ValueError):
        wm = WAIT_MINUTES_DEFAULT
    wm = max(0, wm)
    tol, tol_desc = event_tolerance(event, 0)   # descriptive if fixed amount
    scope = (f"room≈{only_room} " if only_room else "") + \
            (f"ota≈{only_ota}" if only_ota else "")
    _ui(tr_("🛠 Correction loop — max {i} round(s), {w} min wait between rounds, event tolerance{s}").format(
        i=max_iters, w=wm, s=f" ({scope.strip()})" if scope else ""),
        "tit")
    if dry_run:
        _ui(tr_("   DRY RUN: everything is computed, NOTHING is sent to the CM."), "warn")

    summary = {"converged": False, "reason": "", "iterations": 0,
               "dry_run": dry_run, "corrections": 0, "pushed": 0,
               "not_read_nights": 0, "drifts_before": 0, "drifts_after": 0}
    drifts_before = None

    for it in range(1, max_iters + 1):
        if STOP.is_set():
            summary["reason"] = tr_("stop requested (⏹)")
            return summary
        # D98: global pause — the loop interrupts itself cleanly.
        if xb.is_paused():
            summary["reason"] = tr_("global pause (⏸) — loop interrupted")
            log("⏸ " + tr_("global pause — correction loop pauses (resume with ▶ Resume)"))
            return summary
        _ui(tr_("◀ Round {i}/{n} — checking displayed prices…")
            .format(i=it, n=max_iters), "mut")
        # Verify under the "seasonal correction" slot (the push
        # manages its own: released here, otherwise D52 would refuse it).
        if not xb.operation_begin("seasonal correction"):
            _ui(tr_("⚠️ another operation is running — loop aborted"), "err")
            summary["reason"] = tr_("D52 slot busy")
            return summary
        try:
            rep = snav.verify_future_event(app_config, event, log=log,
                                           ui=ui)
        finally:
            try:
                xb.operation_end("seasonal correction")
            except Exception as e:
                log(f"⚠️ D52 release impossible: {e}")
        if STOP.is_set():
            summary["reason"] = tr_("stop requested (⏹)")
            return summary
        if rep is None:
            summary["reason"] = tr_("verification impossible")
            return summary
        entries = rep["events"][0]["entries"] if rep.get("events") else []
        n_off = sum(1 for e in entries if not e.get("ok"))
        n_nr = int(rep.get("not_read_nights") or 0)
        summary["not_read_nights"] = n_nr
        if drifts_before is None:
            drifts_before = n_off
            summary["drifts_before"] = n_off
        if not entries:
            summary["reason"] = tr_("no price read from the OTAs")
            return summary
        if n_off == 0 and n_nr == 0:
            summary.update(converged=True,
                           reason=tr_("all displayed prices are within tolerance"),
                           iterations=it, drifts_after=0)
            _ui(tr_("✅ CONVERGENCE at round {i}: all displayed prices are within tolerance.").format(i=it), "ok")
            return summary
        if n_off == 0 and n_nr:
            summary.update(iterations=it, drifts_after=0,
                           reason=tr_("{n} night(s) could not be read — no conclusion").format(n=n_nr))
            _ui(tr_("⚠️ {n} night(s) NOT READ — convergence unproven, no value invented.").format(n=n_nr),
                "warn")
            return summary

        # ── computation ───────────────────────────────────────────
        _ui(tr_("🧮 Reading the CM grid (prices in place) + computing compensated sends…"), "mut")
        st = xb.cm_state(app_config)
        # D82: nights to correct outside the grid window (Dec→January
        # event: window anchored today stops ~end of Dec) →
        # navigate OTASheet to the missing window then MERGE.
        _missing = _uncovered_dates(entries, st)
        if _missing:
            st = ensure_cm_window(app_config, _missing[0],
                                  log=log, ui=ui)
        corrections, skipped = collect_corrections(
            app_config, event, entries, st, log=log, ui=ui,
            only_room=only_room, only_ota=only_ota)
        summary["corrections"] += len(corrections)
        if not corrections:
            summary.update(iterations=it,
                           reason=tr_("no correction computable (CM grid silent or mapping missing)"),
                           drifts_after=n_off)
            _ui(tr_("⚠️ no correction computable — see the skipped lines above."), "warn")
            return summary
        if dry_run:
            summary.update(iterations=it, drifts_after=n_off,
                           reason=tr_("dry run finished — nothing was sent"))
            _ui(tr_("✅ DRY RUN finished: {n} send(s) computed, 0 sent. Check the 🧮 values above then run for real.").format(n=len(corrections)), "ok")
            return summary

        # ── push (the push takes its own D52 slot) ────────────────
        _ui(tr_("📤 Sending {n} correction(s) to the CM via the router…")
            .format(n=len(corrections)), "tit")
        results, n_entries = push_corrections(
            app_config, corrections, log=log, ui=ui,
            progress_cb=progress_cb)
        ok_push = all(r.get("ok") for r in results) if results else False
        summary["pushed"] += sum(
            int(r.get("sent") or 0) if "sent" in r
            else (int(r.get("n") or 0) if r.get("ok") else 0)
            for r in results)
        if not ok_push:
            if any(r.get("unverified") for r in results):
                summary.update(iterations=it, drifts_after=n_off,
                               reason=tr_("CM submission detected, price not verified"))
                _ui(tr_("⚠ CM submission detected, but prices remain unverified "
                        "— loop stopped without resending."), "warn")
                return summary
            summary.update(iterations=it, drifts_after=n_off,
                           reason=tr_("CM send failed — retry at the next manual round"))
            _ui(tr_("✗ the CM send failed — loop aborted (details in the journal)"), "err")
            return summary
        if it == max_iters:
            break
        if wm and not STOP.is_set():
            _ui(tr_("⏳ waiting {w} min (event setting) — the CM propagates to the OTA…").format(w=wm), "mut")
            if STOP.wait(wm * 60):
                summary["reason"] = tr_("stop requested (⏹)")
                return summary

    summary.update(reason=tr_("{n} round(s) exhausted without full convergence — run again if needed")
                   .format(n=max_iters),
                   iterations=max_iters)
    return summary
