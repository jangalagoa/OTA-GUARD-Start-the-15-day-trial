"""core/patch_loader.py — Hot-patch channel (D39).

Vendors publish SIGNED patch bundles (Ed25519, same key as licensing).
At startup this module loads the local patch set and registers a
sys.meta_path finder so patched modules take priority over the ones
compiled into the Nuitka build. Result: a bug fix = sign & upload a few
.py files — no recompile, no installer; clients pick it up at next start.

Manifest (patches/manifest.json):
    {"version": 3,
     "files":   {"tabs/tab_hotel.py": "<sha256>", ...},
     "sig":     "<base64 Ed25519 of canonical JSON {version, files}>"}

Bootstrap exception: core.paths and core.config CANNOT be patched (they
are imported before this loader can run). Everything else (app, tabs/,
business/, vae_bridge, extranet_bridge, updater, vae2/, ...) is patchable.

Fail-safe: any verification/loading error disables patching for this run
(the compiled app keeps working). Never crashes the app.
"""

import base64
import hashlib
import json
import logging
import re
import sys
import threading
import zipfile
from pathlib import Path

# Remote default: same repo as the updater (override via
# config["vendor"]["patch_manifest_url"]).
DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/jangalagoa/"
    "OTA-GUARD-Start-the-15-day-trial/main/patches/manifest.json"
)

_PATCH_DIR_NAME = "patches"
# The next compiled release contains the diagnostic/scan repairs newer than v30.
# An older user-data patch must never shadow those bundled modules.
_BUNDLED_PATCH_LEVEL = 30
_MODULE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")

_lock = threading.Lock()
_version = 0
_patched_files: dict = {}       # relpath -> absolute Path
_patched_modules: dict = {}     # module name -> absolute Path
_last_error = ""


# ── Signature (same Ed25519 key as licensing) ────────────────────────────────

def _public_pem() -> bytes:
    from licensing.keys import _embedded_public_pem
    return _embedded_public_pem()


def canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def verify_manifest(manifest: dict) -> bool:
    """True when the manifest signature is valid for its content."""
    body = {"version": manifest.get("version"),
            "files": manifest.get("files") or {}}
    sig = str(manifest.get("sig") or "")
    try:
        from licensing.keys import verify_key
        return verify_key(_public_pem(), canonical(body),
                          base64.b64decode(sig))
    except Exception:
        return False


# ── Path / module mapping (security-checked) ─────────────────────────────────

def _safe_relpath(rel: str) -> bool:
    """Reject absolute paths, drive letters, .. traversal, non-.py files.
    D128 : exception — les mappings OTA (vae/config/ota_mappings/*.yaml)
    sont livrables par patch : ce sont des données de lecture du scan,
    copiées dans le dossier mappings réel au démarrage (voir _deliver_yamls)."""
    p = str(rel or "").replace("\\", "/")
    if p.startswith("/") or ":" in p:
        return False
    parts = p.split("/")
    if any(part in ("", ".", "..") for part in parts):
        return False
    if p.endswith(".yaml"):
        return (len(parts) == 4 and parts[:3] == ["vae", "config",
                "ota_mappings"])
    return p.endswith(".py")


def _module_name(rel: str) -> str:
    return rel.replace("\\", "/")[:-3].replace("/", ".")


def validate_scan_contract(files: dict) -> None:
    """Reject the v29 bridge/extractor mismatch before activating any patch."""
    import ast
    bridge_name = "vae_bridge.py"
    extractor_name = "vae/src/extractors/generic_extractor.py"
    if bridge_name not in files or extractor_name not in files:
        return
    bridge = ast.parse(files[bridge_name].decode("utf-8-sig"))
    extractor = ast.parse(files[extractor_name].decode("utf-8-sig"))
    cls = next(n for n in extractor.body
               if isinstance(n, ast.ClassDef) and n.name == "GenericExtractor")
    init = next(n for n in cls.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__")
    accepted = {a.arg for a in init.args.args + init.args.kwonlyargs}
    for call in ast.walk(bridge):
        if (isinstance(call, ast.Call) and isinstance(call.func, ast.Name)
                and call.func.id == "GenericExtractor"):
            unsupported = {k.arg for k in call.keywords
                           if k.arg and k.arg not in accepted}
            if unsupported and init.args.kwarg is None:
                raise ValueError("Incompatible GenericExtractor: "
                                 + ", ".join(sorted(unsupported)))


# ── Import hook ──────────────────────────────────────────────────────────────

class _PatchFinder:
    """sys.meta_path finder: resolves patched module names from the patch
    directory BEFORE any other importer (compiled modules included)."""

    def __init__(self):
        self._announced = set()

    def find_spec(self, fullname, path=None, target=None):
        with _lock:
            file = _patched_modules.get(fullname)
        if file is None or not _MODULE_RE.match(fullname):
            return None
        import importlib.util
        try:
            spec = importlib.util.spec_from_file_location(fullname, file)
        except Exception:
            return None
        if spec is not None and fullname not in self._announced:
            # Logging can import diagnostic.masker through the black box.
            # Mark BEFORE logging so that the nested import cannot recurse.
            self._announced.add(fullname)
            logging.info("[PATCH] %s <- %s", fullname, file)
        return spec


def _install_finder() -> None:
    if not any(isinstance(f, _PatchFinder) for f in sys.meta_path):
        sys.meta_path.insert(0, _PatchFinder())


# ── Load the local patch set ─────────────────────────────────────────────────

def _patch_dir() -> Path:
    from core.paths import DATA_DIR
    return DATA_DIR / _PATCH_DIR_NAME


def _deliver_yamls(files: dict, patch_dir: Path) -> None:
    """D128 : copie les mappings OTA livrés par le patch vers le dossier
    réel vae/config/ota_mappings/ (le scan les lit du disque). Échec
    silencieux — jamais bloquant."""
    import shutil
    try:
        from core.paths import INSTALL_DIR
        target_dir = Path(INSTALL_DIR) / "vae" / "config" / "ota_mappings"
        for rel in files:
            p = str(rel).replace("\\", "/")
            if not p.endswith(".yaml"):
                continue
            src = patch_dir / rel
            if not src.exists():
                continue
            target_dir.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, target_dir / Path(p).name)
            logging.info("[PATCH] mapping livré : %s", Path(p).name)
    except Exception:
        logging.exception("[PATCH] livraison mappings impossible")


def apply_early(read_only: bool = False) -> int:
    """Load patches/manifest.json, verify it, register the import hook.
    Returns the patch level applied (0 = none). Never raises.
    read_only skips delivery of YAML mappings for the diagnostic tool."""
    global _version, _patched_files, _patched_modules, _last_error
    try:
        mfile = _patch_dir() / "manifest.json"
        if not mfile.exists():
            return 0
        manifest = json.loads(mfile.read_text(encoding="utf-8"))
        if int(manifest.get("version") or 0) <= _BUNDLED_PATCH_LEVEL:
            logging.info("[PATCH] local level %s superseded by bundled sources "
                         "(baseline %s)", manifest.get("version"),
                         _BUNDLED_PATCH_LEVEL)
            return 0
        files = manifest.get("files") or {}
        if not isinstance(files, dict) or not files:
            return 0
        # D97 hard rule (incident 03/11): the patch channel must NEVER
        # serve version.py — a stale copy shadows the exe's embedded
        # version and makes the updater propose updates forever (a
        # 3.0.39 constant served over a 3.0.40 install). version.py is
        # banned from every manifest, old or new.
        if "version.py" in files:
            files = dict(files)
            files.pop("version.py")
            logging.warning("[PATCH] version.py refused (never served "
                            "by the patch channel - D97)")
        if not verify_manifest(manifest):
            _last_error = "invalid signature — patches ignored"
            logging.warning("[PATCH] %s", _last_error)
            return 0
        mapping_files, mapping_mods = {}, {}
        for rel, sha in files.items():
            if not _safe_relpath(rel):
                _last_error = f"forbidden path in the manifest: {rel}"
                logging.warning("[PATCH] %s", _last_error)
                return 0
            f = _patch_dir() / rel
            if not f.exists():
                _last_error = f"missing file: {rel}"
                logging.warning("[PATCH] %s", _last_error)
                return 0
            digest = hashlib.sha256(f.read_bytes()).hexdigest()
            if digest != str(sha).lower():
                _last_error = f"invalid hash: {rel}"
                logging.warning("[PATCH] %s", _last_error)
                return 0
            mapping_files[rel] = f
            mapping_mods[_module_name(rel)] = f
        validate_scan_contract({
            rel: mapping_files[rel].read_bytes()
            for rel in ("vae_bridge.py",
                        "vae/src/extractors/generic_extractor.py")
            if rel in mapping_files})
        if not read_only:
            _deliver_yamls(files, _patch_dir())
        with _lock:
            _version = int(manifest.get("version") or 0)
            _patched_files = mapping_files
            _patched_modules = mapping_mods
        _install_finder()
        logging.info("[PATCH] level %s active — %d file(s): %s",
                     _version, len(mapping_files),
                     ", ".join(sorted(mapping_files)))
        return _version
    except Exception as e:
        _last_error = str(e)
        logging.exception("[PATCH] load impossible — patches ignored")
        return 0


def current_version() -> int:
    return _version


def status() -> dict:
    return {"patch_level": _version, "files": sorted(_patched_files),
            "error": _last_error}


# ── Remote check (background, effect at NEXT start) ─────────────────────────

def _remote_manifest_url() -> str:
    try:
        from core import config as _cfg
        url = ((_cfg.load() or {}).get("vendor") or {}).get(
            "patch_manifest_url")
        if url:
            return str(url).strip()
    except Exception:
        pass
    return DEFAULT_MANIFEST_URL


def check_remote(background: bool = True) -> None:
    """Download a newer signed bundle if available. Extracted into
    patches/ ; takes effect at next app start. Never blocks, never raises."""
    def _work():
        try:
            import urllib.request
            import urllib.error
            base = _remote_manifest_url()
            req = urllib.request.Request(base, headers={"Accept": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=15) as r:
                    manifest = json.loads(r.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    logging.info("[PATCH] no patch published (404) — "
                                 "channel still pristine")
                    return
                raise
            rver = int(manifest.get("version") or 0)
            if rver <= max(_version, _BUNDLED_PATCH_LEVEL) or not verify_manifest(manifest):
                return
            # Remember a signed bundle rejected for an internal API mismatch.
            # Otherwise a client with that remote v29 would download the same
            # unusable archive on every startup. A corrected manifest has a
            # different digest and is tried normally, even at the same level.
            manifest_digest = hashlib.sha256(canonical({
                "version": manifest.get("version"),
                "files": manifest.get("files") or {}})).hexdigest()
            rejected = _patch_dir().with_name("patch_rejected.json")
            try:
                if json.loads(rejected.read_text(encoding="utf-8")).get(
                        "manifest_digest") == manifest_digest:
                    logging.info("[PATCH] bundle %s previously rejected; "
                                 "waiting for a corrected manifest", rver)
                    return
            except (OSError, ValueError, TypeError):
                pass
            zip_url = str(manifest.get("bundle") or "").strip()
            if not zip_url:
                return
            if not (zip_url.startswith("http://")
                    or zip_url.startswith("https://")):
                # relative to the manifest location
                root = base.rsplit("/", 1)[0]
                zip_url = f"{root}/{zip_url}"
            with urllib.request.urlopen(
                    urllib.request.Request(zip_url), timeout=60) as r:
                blob = r.read()
            pdir = _patch_dir()
            staging = pdir.with_name(pdir.name + "_staging")
            if staging.exists():
                import shutil
                shutil.rmtree(staging)
            staging.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(io_bytes(blob)) as zf:
                for member in zf.namelist():
                    if member.endswith("/") or not _safe_relpath(member):
                        continue
                    if str(member) not in (manifest.get("files") or {}):
                        continue
                    target = staging / member
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(zf.read(member))
            # verify EVERY file hash before promoting
            for rel, sha in (manifest.get("files") or {}).items():
                f = staging / rel
                if not f.exists() or hashlib.sha256(
                        f.read_bytes()).hexdigest() != str(sha).lower():
                    logging.warning("[PATCH] bundle %s rejected (%s)",
                                    rver, rel)
                    return
            # A signed archive can still be internally incompatible. Check
            # the bridge/extractor API before replacing the currently usable
            # patch directory, so v29-style bundles cannot be installed again.
            try:
                validate_scan_contract({
                    rel: (staging / rel).read_bytes()
                    for rel in ("vae_bridge.py",
                                "vae/src/extractors/generic_extractor.py")
                    if rel in (manifest.get("files") or {})})
            except (ValueError, SyntaxError, StopIteration) as e:
                logging.error("[PATCH] bundle %s rejected before install: %s",
                              rver, e)
                try:
                    rejected.write_text(json.dumps({
                        "manifest_digest": manifest_digest,
                        "version": rver, "reason": str(e)},
                        ensure_ascii=False), encoding="utf-8")
                except OSError:
                    logging.exception("[PATCH] rejected-bundle marker failed")
                return
            if pdir.exists():
                import shutil
                shutil.rmtree(pdir)
            staging.rename(pdir)
            # write the manifest INSIDE the patch folder: apply_early
            # activates nothing without it (bug of 18/09: the bundle arrived
            # without a manifest -> patch never active)
            (pdir / "manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False),
                encoding="utf-8", newline="\n")
            logging.info("[PATCH] bundle %s downloaded — active at "
                         "next startup", rver)
        except Exception:
            logging.exception("[PATCH] remote check failed")

    import io
    io_bytes = io.BytesIO
    if background:
        threading.Thread(target=_work, name="patch-check",
                         daemon=True).start()
    else:
        _work()
