"""
VAE Bridge — connects VAE passive interception to OTA Guard's UI.

Converts VAE's HotelData/Room/Price objects into OTA Guard's expected format:
    {ota_name: {room_type: price_int}}

This is the ONLY integration point between VAE and OTA Guard.
The UI, parity detection, CM push, and notifications all consume this dict.
"""

import sys
import difflib
import json
import logging
import time
import re as _re
from pathlib import Path
from core.ota_selection import page_key, selected_profiles, selected_page_keys
from core.scan_context import ScanResults, merge_room_prices, same_stay
from diagnostic import scan_trace as _diag

# Add VAE module to Python path
# D104 — same rule as extranet_bridge: INSTALL_DIR anchor (never
# patched) and not the __file__ of THIS module, wrong when served from patches/.
try:
    from core.paths import INSTALL_DIR as _INSTALL_DIR
    _VAE_ROOT = Path(_INSTALL_DIR) / "vae"
except Exception:
    _VAE_ROOT = Path(__file__).resolve().parent / "vae"
if str(_VAE_ROOT) not in sys.path:
    sys.path.insert(0, str(_VAE_ROOT))


class ScanCancelled(Exception):
    """D53: raised by the progress callback when the user
    requests a stop — swallowed at the 2 call sites so the loop
    skips the current OTA and returns the PARTIAL results."""
    pass


def learn_cm_sites_from_captures(max_files: int = 600) -> list:
    """D128 — passive learning of the CM's current address.

    Walks the listener's capture metas NEWER than the last check
    (checkpoint stored in cm_sites.json) and learns every host seen
    serving a known CM page path (BulkUpdate / OTASheet). The owner
    just USES his CM in Brave; the next scan (or startup) picks the new
    address up. Learned hosts are also appended to the listener's
    ota_domains.yaml so its tabs stay attributed to the CM (capture
    naming) and to the purge protection. Fail-safe: never raises."""
    try:
        from business import cm_sites as _cms
        from vae import config as _vcfg
        import json as _json
        d = _cms._load()
        checkpoint = str(d.get("captures_checked") or "")
        metas, names = [], []
        files = sorted(_vcfg.DATA_DIR.glob("*.json"),
                       key=lambda p: p.name)
        for f in files:
            if f.name.endswith("_body.json"):
                continue
            if checkpoint and f.name <= checkpoint:
                continue
            names.append(f.name)
            if len(metas) < max_files:
                try:
                    metas.append(_json.loads(
                        f.read_text(encoding="utf-8",
                                    errors="replace")))
                except Exception:
                    pass
        if not names:
            return []
        learned = _cms.learn_from_capture_metas(metas)
        d = _cms._load()
        d["captures_checked"] = names[-1]
        _cms._save(d)
        if learned:
            _sync_learned_hosts_to_listener(learned)
        return learned
    except Exception:
        return []


def _sync_learned_hosts_to_listener(hosts) -> None:
    """Appends the learned CM hosts to vae/config/ota_domains.yaml so
    the listener attributes the CM's tabs on the new address (capture
    naming + hotel context). Never raises."""
    try:
        import yaml as _yaml
        p = _VAE_ROOT / "config" / "ota_domains.yaml"
        data = _yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        domains = list(data.get("ota_domains") or [])
        changed = False
        for h in hosts:
            if h and h not in domains:
                domains.append(h)
                changed = True
        if changed:
            data["ota_domains"] = domains
            p.write_text(_yaml.dump(data, allow_unicode=True,
                                    default_flow_style=False),
                         encoding="utf-8")
    except Exception:
        pass


def vae_scan(config: dict, progress_cb=None, cancel_cb=None,
             require_open_tab: bool = True) -> dict:
    """
    Extract prices from VAE's captured data and return in OTA Guard format.

    Args:
        config: OTA Guard's config dict (contains hotel_currency, room_types,
                ota_watch.otas with OTA names/URLs)
        progress_cb: optional callback(progress_percent: int, message: str)
        cancel_cb: optional callback() -> bool — D107: STOP = STOP. Queried
                between EVERY phase and EVERY unit of work (capture
                purge, Airbnb listing, OTA, DOM tab). A requested stop
                KEEPS the results already read — never thrown away, never invented.

    Returns:
        {ota_name(str): {room_type(str): price_int}} — same format as old engines.
        Prices are in the target currency (config['hotel_currency']),
        rounded to integers.
    """
    target_currency = config.get("hotel_currency", "INR")
    room_types = config.get("room_types", [])
    otas = config.get("ota_watch", {}).get("otas", [])

    # D128: pick up a CM address change straight from the owner's own
    # browsing (passive) BEFORE anything reads or writes the CM.
    try:
        _learned = learn_cm_sites_from_captures()
        if _learned:
            print(f"[VAE_BRIDGE] CM address learned from captures: "
                  f"{', '.join(_learned)}")
    except Exception:
        pass

    # D108: THE single mapping file exists from the first
    # scan (one-shot migration from the old calibration files).
    # D110: ONE SINGLE "Airbnb" OTA (Expedia model) — migration of the
    # in-memory config; the tab persists it at build time.
    try:
        from core.airbnb_unify import unify_airbnb
        unify_airbnb(config)
    except Exception:
        pass
    # Page choices, including newly selected pages, drive every reader.
    # Keep the full config for lifecycle maintenance; filter scan-only copies.
    otas = selected_profiles(config.get("ota_watch", {}))
    _selected_pages = selected_page_keys(config.get("ota_watch", {}))
    _configured_pages = frozenset(_selected_pages)
    _diag.event("selection", selected_pages=sorted(_selected_pages),
                profiles=[{"name": o.get("name"), "url": o.get("url"),
                           "listings": o.get("listings")} for o in otas])
    if not _selected_pages:
        if progress_cb:
            progress_cb(100, "No OTA pages selected")
        _save_detected_report({}, config, open_pages=[], selected_pages=_configured_pages)
        return ScanResults()
    try:
        from core import room_names as _rn
        _rn.ensure_ready(config)
    except Exception:
        pass

    def _raise_if_stopped() -> None:
        # D107: the ⏹ must cut ANY phase of the scan, not
        # only the extraction loop. ScanCancelled is ALWAYS
        # caught in vae_scan: the partial results survive.
        try:
            if cancel_cb and cancel_cb():
                raise ScanCancelled()
        except ScanCancelled:
            raise
        except Exception:
            pass  # a failing cancel_cb must never break a scan

    # D79: rate grid — above the signed room limit,
    # the price scan is refused (count: CM grid > declaration).
    try:
        from licensing.limits import operation_allowed
        _ok, _why = operation_allowed(config)
        if not _ok:
            print(f"[VAE_BRIDGE] {_why}")
            if progress_cb:
                progress_cb(100, _why)
            return {}
    except Exception:
        pass

    # Configure VAE target currency
    try:
        from vae.config import set_target_currency
        set_target_currency(target_currency)
    except Exception:
        pass

    # IMPORTANT: a scan must be READ-ONLY with respect to the mappings.
    # Do not regenerate YAML mappings here. Auto-regeneration on every scan
    # can replace a known-good mapping with a path found in an unrelated
    # response (tracking, search, teaser, etc.) and make a working OTA
    # suddenly return no prices. Mapping generation is an explicit maintenance
    # operation, not part of the passive price scan.
    if progress_cb:
        progress_cb(5, "Reading captured data...")

    # Create VAE extractor
    try:
        from vae.src.extractors.generic_extractor import GenericExtractor
        extractor = GenericExtractor(target_currency=target_currency,
                                     allowed_pages=_selected_pages)
        _diag.event("extractor_ready", mappings=list(extractor.mappings),
                    mappings_dir=str(extractor.mappings_dir))
    except Exception as e:
        _diag.error("extractor_init", e)
        logging.exception("[VAE_BRIDGE] Cannot initialize VAE extractor")
        raise RuntimeError(f"Cannot initialize VAE extractor: {e}") from e

    if not extractor.mappings:
        raise RuntimeError(f"No OTA mappings loaded from {extractor.mappings_dir}")

    # Map OTA Guard OTA names to VAE mapping keys for quick lookup
    ota_name_map = _build_ota_name_map(otas, extractor.mappings)

    # Generalist / metasearch sites are not real OTAs — skip them entirely
    # so they never appear in scan results.
    _GENERALIST_DOMAINS = {"google", "trivago", "kayak", "tripadvisor"}

    results = ScanResults()
    total = len(extractor.mappings)
    done = 0
    detected_report = {}   # display_name -> {source_id, rooms:[{name,price,our,rid}]}
    _json_rids = {}        # display_name -> {detected_name: ota machine room id}
    _json_contexts = {}

    # D120: "closed tab = OTA absent from the scan" (owner's finding
    # 10/13: Agoda closed in Brave kept appearing with prices
    # read from OLD captures). A single list of open tabs
    # via CDP; if Brave is unreachable, the historical
    # behavior (reading the captures) is kept so nothing breaks offline.
    _open_hosts = None
    _open_pages = None
    try:
        import urllib.request as _ureq
        _tabs_json = json.loads(_ureq.urlopen(
            "http://localhost:9222/json", timeout=3).read().decode())
        _open_hosts = set()
        _open_pages = set()
        for _t in _tabs_json:
            if _t.get("type") != "page":
                continue
            _h = ((_t.get("url") or "").split("//", 1)[-1]
                  .split("/", 1)[0].lower())
            if _h:
                _open_hosts.add(_h)
            _open_pages.add(page_key(_t.get("url", "")))
    except Exception as exc:
        _open_hosts = None
        _open_pages = None
        _diag.error("browser_inventory", exc)

    if _open_hosts is not None and require_open_tab:
        _selected_pages = _selected_pages & _open_pages
    extractor.allowed_page_keys = _selected_pages
    _diag.event("browser_selection", open_pages=sorted(_open_pages or []),
                browser_observed=_open_hosts is not None,
                selected_before=sorted(_configured_pages), retained=sorted(_selected_pages),
                require_open_tab=require_open_tab)
    if not _selected_pages:
        _diag.event("selection_gate", "rejected", reason="no selected page retained")
        _save_detected_report({}, config, open_pages=[], selected_pages=_configured_pages)
        return results

    # One pass over capture filenames: which domains actually have data?
    # Leftover auto-generated mappings (trip_com, booking_com, kayak,
    # trivago… — produced whenever those sites were browsed once) used to
    # make the scan bar flash "Extraction : Trip.com…" for sites with NO
    # capture at all. Mappings without captures are now skipped BEFORE any
    # progress message.
    _cap_domains = set()
    try:
        from vae import config as _vcfg_dirs
        _dom_re = _re.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        for _f in _vcfg_dirs.DATA_DIR.glob("*.json"):
            _m = _dom_re.match(_f.name)
            if _m:
                _cap_domains.add(_m.group(1))
    except Exception:
        _cap_domains = None   # check disabled — behave like before

    # ── THE decisive filter: only the OTA profiles the hotelier MONITORS ──
    # Having captures is NOT being watched: trip.com browsed once (2026-08-14)
    # left 29 capture files on disk and kept appearing in the scan bar even
    # with no tab open and no config entry. The active config profiles are
    # the single source of truth. The token is the URL hostname
    # ('www.expedia.co.in' → 'expedia_co_in') matched inside the VAE mapping
    # key ('www_expedia_co_in' ✓, old 'expedia_com' ✗ — stale duplicate
    # excluded at the same time).
    _active_tokens = set()
    try:
        for _o in (otas or []):
            _url = ((_o.get("url") or "").lower() or "").strip()
            if not _o.get("active", True) or not _url.startswith("http"):
                continue
            _host = _url.split("//", 1)[-1].split("/")[0]
            _host = _host.replace(".", "_")
            if _host.startswith("www_"):
                _host = _host[4:]
            if _host:
                _active_tokens.add(_host)
        # D121 : la famille MakeMyTrip (.com/.global) = un seul token de
        # marque — un onglet .com satisfait une OTA configurée .global.
        for _t in list(_active_tokens):
            _b = _brand_of(_t)
            if _b:
                _active_tokens.add(_b)
        # Reference OTA (price benchmark), if one is configured: it is
        # deliberately watched, captures or not.
        _ref = (config.get("ota_watch", {}).get("reference") or {})
        _ref_url = ((_ref.get("url") or "").lower() or "").strip()
        if _ref.get("active") and _ref_url.startswith("http"):
            _ref_host = _ref_url.split("//", 1)[-1].split("/")[0]
            _ref_host = _ref_host.replace(".", "_")
            if _ref_host.startswith("www_"):
                _ref_host = _ref_host[4:]
            if _ref_host:
                _active_tokens.add(_ref_host)
    except Exception:
        _active_tokens = set()

    # ── OTA lifecycle, on EVERY scan ───────────────────────────────────
    # Removed OTA → everything of it is purged (captures, mappings,
    # calibration, history): a commercial product leaves zero trace.
    # Newly added OTA with captures but no mapping → wired automatically.
    # Fail-safe: lifecycle issues never block the scan itself.
    try:
        _purged = ota_lifecycle_cleanup(config, cancel_cb=cancel_cb)
        if any(_purged.values()):
            print(f"[VAE_BRIDGE] OTA cleanup removed: {_purged}",
                  flush=True)
    except ScanCancelled:
        return results   # D107: stopped during the cleanup — nothing read yet
    except Exception:
        pass
    # D105-3: age-based retention — the captures folder must never
    # grow unbounded (client: x2 in 2 days, 231k files on 10/09).
    try:
        _ret = capture_retention_cleanup(config, cancel_cb=cancel_cb)
        if _ret:
            print(f"[VAE_BRIDGE] Capture retention: {_ret} file(s) "
                  f"expired deleted (>{_capture_retention_days(config)} d)",
                  flush=True)
    except ScanCancelled:
        return results   # D107: stopped during the retention purge
    except Exception:
        pass
    try:
        ota_lifecycle_wire_new(config)
    except Exception:
        pass

    for vae_ota_name in sorted(extractor.mappings.keys()):
        done += 1

        # D107: STOP = STOP — tested at EVERY OTA, BEFORE any work
        # (including before the Airbnb read, once started without
        # any control). Results already read: kept.
        try:
            _raise_if_stopped()
        except ScanCancelled:
            print("[VAE_BRIDGE] ⏹ scan stopped by the user — "
                  "partial results kept", flush=True)
            break

        # Skip mappings with zero captures, silently: nothing to extract,
        # nothing to show.
        # Airbnb can read its own live booking card without an API capture.
        if (_cap_domains is not None and "airbnb" not in vae_ota_name.lower()
                and not _cap_domain_matches(vae_ota_name, _cap_domains)):
            _diag.event("capture_gate", "skipped", ota=ota_name_map.get(vae_ota_name, vae_ota_name),
                        reason="no capture domain", mapping=vae_ota_name)
            continue
        # Skip anything the hotelier does not monitor, no matter how many
        # captures sit on disk (trip.com case, 2026-08-16).
        if not any(_t in vae_ota_name
                                      for _t in _active_tokens):
            continue

        # D120: NO open tab for this OTA → no read. Old
        # captures (retention window) must never
        # resurface as current prices: a displayed price comes from a
        # LIVE page, not from a memory.
        if _open_hosts is not None and require_open_tab:
            _dom = vae_ota_name.lower().replace("www_", "").replace("_", ".")
            _bare = vae_ota_name.lower().replace("www_", "").replace("_", "")
            # D121 : famille MakeMyTrip (.com/.global) — un onglet de
            # l'un ou l'autre domaine compte comme ouvert.
            _brand = _brand_of(vae_ota_name)
            _tab_open = (
                any(_brand_of(h) == _brand for h in _open_hosts)
                if _brand
                else not any(_dom in h or _bare in h.replace(".", "")
                             for h in _open_hosts))
            if not _tab_open:
                display_name = ota_name_map.get(vae_ota_name, vae_ota_name)
                print(f"[VAE_BRIDGE] {display_name}: tab not open in "
                      f"Brave — no read (old captures are "
                      f"not displayed)", flush=True)
                continue

        display_name = ota_name_map.get(vae_ota_name, vae_ota_name)

        # ── Airbnb: per-listing attribution ─────────────────────────────
        # Each Airbnb config entry IS one listing (URL /rooms/<id>) and one
        # room type. The generic mapping path reads similarListings — the
        # NEIGHBOUR listings' prices — so it must not be used when config
        # entries carry listing URLs. Attribute each capture to its own
        # listing via the metadata tab_url and read the page's OWN
        # displayed price (structuredDisplayPrice).
        if "airbnb" in vae_ota_name.lower():
            _diag.event("reader_start", ota="Airbnb", reader="per_listing")
            # D107: the Airbnb read (live page per listing) cuts
            # BETWEEN the listings — never again "the 4 listings keep going".
            try:
                _listing_rooms, _listing_rows = _airbnb_listing_data(
                    otas, target_currency, cancel_cb=cancel_cb,
                    room_types=room_types, config=config,
                    allowed_pages=_selected_pages)
            except ScanCancelled:
                print("[VAE_BRIDGE] ⏹ stop during the Airbnb read — "
                      "partial results kept", flush=True)
                break
            for issue in getattr(_listing_rooms, 'errors', []):
                results.failure(issue['ota'], issue['stage'], issue['error'])
            if _listing_rows:
                detected_report['Airbnb'] = {'source_id': 'airbnb', 'rooms': _listing_rows}
            if _listing_rooms:
                # One key per listing profile — they match the monitored OTA
                # names, so the results survive the tab-bar purge that deleted
                # the old generic "Airbnb" key right after each scan.
                results.update(_listing_rooms)
                detected_report["Airbnb"] = {
                    "source_id": "airbnb",
                    "rooms": _listing_rows,
                }
                if progress_cb:
                    try:
                        progress_cb(int(done * 90 / max(total, 1)),
                                    f"Airbnb: {len(_listing_rooms)} listings")
                    except ScanCancelled:
                        continue
                continue
            # Config HAS per-listing Airbnb entries but no usable capture
            # was found. The generic mapping path reads similarListings —
            # the NEIGHBOUR listings' prices — and must NEVER be used to
            # price this hotel's rooms: it is exactly how a rescan shuffled
            # room categories with foreign prices. Skip Airbnb for this
            # scan instead of inventing data.
            _has_listing_cfg = any(
                "airbnb" in ((o.get("url") or "").lower())
                and _re.search(r"/rooms/\d+", o.get("url") or "")
                for o in otas or [])
            if _has_listing_cfg:
                print("[VAE_BRIDGE] Airbnb: per-listing captures "
                      "unfound — listing ignored for this scan "
                      "(never the neighbouring listings' prices)", flush=True)
                continue

        # Skip generalist / metasearch sites
        if any(g in vae_ota_name.lower() or g in display_name.lower()
               for g in _GENERALIST_DOMAINS):
            continue

        if progress_cb:
            try:
                pct = int(done / total * 100) if total > 0 else 100
                progress_cb(pct, f"Extraction: {display_name}...")
            except ScanCancelled:
                # stop requested: current OTA skipped, the next ones too
                # (the callback raises the exception at every call) —
                # partial results kept
                continue

        try:
            _diag.event("json_start", ota=display_name, mapping=vae_ota_name)
            hotel = extractor.extract_ota(vae_ota_name)
            _json_contexts[display_name] = getattr(extractor, "price_contexts", {}).get(vae_ota_name, [])
            _diag.event("json_result", ota=display_name,
                        rooms=[{"name": r.name, "id": r.id, "price": vars(r.price) if r.price else None}
                               for r in hotel.rooms] if hotel else [])
        except Exception as e:
            _diag.error("json_extract", e, ota=display_name)
            logging.exception("[VAE_BRIDGE] JSON extraction failed for %s", display_name)
            results.failure(display_name, "JSON", e)
            continue

        if not hotel or not hotel.rooms:
            continue

        # Build {detected_room_name: price} from VAE data
        detected_prices = {}
        detected_names = []
        rid_by_name = {}     # OTA machine room id per detected name (100% anchor)
        _unnamed_idx = 0
        for room in hotel.rooms:
            if room.name and room.name not in detected_names:
                detected_names.append(room.name)
                if getattr(room, "id", ""):
                    rid_by_name[room.name] = str(room.id)
            if room.price and room.price.has_data:
                # Use the DISCOUNTED price (what the guest actually sees on
                # the OTA) first, then total with taxes, then base as last
                # resort.
                price = (room.price.price_after_discount_normalized
                         or room.price.total_amount_normalized
                         or room.price.base_price_normalized
                         or room.price.price_after_discount
                         or room.price.total_amount
                         or room.price.base_price)
                if price and price > 0:
                    price_int = int(round(price))
                    # Rooms with no name still carry a real price — give them
                    # a synthetic key so they reach the matching step instead
                    # of being silently dropped (Airbnb listings, etc.).
                    room_name = room.name or f"__unnamed_{_unnamed_idx}"
                    if not room.name:
                        _unnamed_idx += 1

                    # If this exact name was already seen at the SAME price,
                    # skip (true duplicate rate plan). But if the same name
                    # appears at a DIFFERENT price, keep both — Google Hotels
                    # and metasearch often label every room with the hotel
                    # name while showing different room-type prices.
                    previous = detected_prices.get(room_name)
                    if previous is None:
                        detected_prices[room_name] = price_int
                        if getattr(room, "id", ""):
                            rid_by_name[room_name] = str(room.id)
                    elif previous != price_int:
                        # Disambiguate: append an index
                        _idx = 2
                        while f"{room_name} ({_idx})" in detected_prices:
                            _idx += 1
                        detected_prices[f"{room_name} ({_idx})"] = price_int
                        if getattr(room, "id", ""):
                            rid_by_name[f"{room_name} ({_idx})"] = str(room.id)
                    # else: same name, same price → skip (duplicate)

        if not detected_prices and not detected_names:
            continue

        # Match detected room names to configured room types
        _src_id = _source_id_from_vae_name(vae_ota_name)
        if room_types:
            _aliases = _calib_room_aliases(_src_id)
            matched = _match_rooms(list(dict.fromkeys(detected_names + list(detected_prices))), room_types,
                                   aliases=_aliases)
            # Machine-ID attribution overrides names: ids never repeat,
            # never get translated, never change on an OTA rename.
            matched = _apply_id_aliases(matched, rid_by_name, _src_id, _aliases)
        else:
            # No config room types: use detected names as-is
            matched = {name: name for name in dict.fromkeys(detected_names + list(detected_prices))}

        # Build {config_room_type: price}
        # Deterministic on purpose: when one OTA name appears at several
        # prices (rate plans → disambiguated as "name" and "name (2)"),
        # several detected names map to the SAME config room. Taking the
        # last one written made the price depend on capture order, which
        # flips between scans. The LOWEST price is kept — the rate a guest
        # can actually book, stable across scans.
        room_results = {}
        for detected_name, config_room in matched.items():
            price = detected_prices.get(detected_name)
            if not price or price <= 0:
                continue
            prev = room_results.get(config_room)
            if prev is None or price < prev:
                room_results[config_room] = price

        # ── Fallback: hotel-level prices → room types ──────────────────
        # ONLY for hotel-level payloads: listings with no room name of
        # their own (metasearch cards, hotel-named listings). A NAMED room
        # that room_match refused must NEVER be force-assigned by price
        # order — that is exactly how a promotion puts the wrong price on
        # the wrong room (Expedia case, 2026-08-15). Named rooms without a
        # safe match (or a memorized alias) are logged and left aside.
        # When the user has defined room mappings ("Room names on OTAs"),
        # price-order guessing is disabled entirely for that OTA: their
        # mapping is the only authority (user report 2026-08-16: rescans
        # were reshuffling room categories by price on every OTA).
        if room_types and not _aliases:
            _assigned = set(room_results.keys())
            _unnamed_prices = sorted(
                set(p for n, p in detected_prices.items()
                    if n.startswith("__unnamed_") and p > 0))
            _free_rooms = [rt for rt in room_types if rt not in _assigned]
            for _price_val, _room in zip(_unnamed_prices, _free_rooms):
                room_results[_room] = _price_val

            _dropped = [n for n in detected_prices
                        if not n.startswith("__unnamed_") and n not in matched]
            for _n in _dropped[:6]:
                print(f"[VAE_BRIDGE] {vae_ota_name}: unmatched room "
                      f"(left aside): {_n[:44]} = "
                      f"{detected_prices[_n]}", flush=True)

            # Remove non-config keys that were orphaned
            _to_del = [rt for rt in list(room_results.keys()) if rt not in room_types]
            for _rt in _to_del:
                del room_results[_rt]

        if room_results:
            display_name = ota_name_map.get(vae_ota_name, vae_ota_name)
            results[display_name] = room_results
        detected_report[display_name] = {
            "source_id": _src_id,
            "rooms": [{"name": n, "price": detected_prices.get(n),
                       "our": matched.get(n) or "", "rid": rid_by_name.get(n, "")}
                      for n in dict.fromkeys(detected_names + list(detected_prices))
                      if not n.startswith("__unnamed_")],
        }
        _diag.event("room_match", ota=display_name, detected=detected_prices,
                    correspondence=matched, retained=room_results)
        # Machine ids gathered by the JSON pass, for the DOM merge below:
        # DOM-extracted OTAs (Expedia, MakeMyTrip) replace the JSON results,
        # but the ids their JSON payloads carried survive via name
        # correlation — the dialog can then anchor on ids there too.
        _json_rids[display_name] = dict(rid_by_name)

    # D107: this progress_cb was the only UNPROTECTED one of the scan — a ⏹
    # landing here crashed the scan AND threw away all the results already read.
    # Now: clean stop, results kept, DOM phase skipped
    # (extract_all checks the flag at its entry like per tab).
    _stopped_after_loop = False
    try:
        if progress_cb:
            progress_cb(100, "Extraction finished")
    except ScanCancelled:
        _stopped_after_loop = True
        print("[VAE_BRIDGE] ⏹ stop requested after the extraction — partial "
              "results kept, DOM phase cancelled", flush=True)

    # ── DOM extraction fallback ───────────────────────────────────────
    # Some OTAs (Expedia, MakeMyTrip) render prices client-side in the DOM
    # instead of returning them via capturable JSON APIs.  For any OTA that
    # the JSON extraction missed, try reading prices directly from the live
    # browser tab via CDP.
    try:
        try:
            from src.extractors.dom_extractor import DomExtractor
            from src.extractors.dom_extractor import _DOMAIN_NAMES as _DOM_OTAS
        except ModuleNotFoundError:
            from vae.src.extractors.dom_extractor import DomExtractor
            from vae.src.extractors.dom_extractor import _DOMAIN_NAMES as _DOM_OTAS
        dom = DomExtractor(
            debug_port=9222,
            target_currency=target_currency,
        )
        # OTAs supported by DOM extraction must NEVER be skipped — the DOM
        # (or the SPA state) is the authoritative source for them.  Their
        # JSON APIs are anti-bot blocked or return empty pricing, so a
        # partial JSON capture (e.g. MakeMyTrip with 1 room from the
        # search page) must be replaced by the complete DOM extraction.
        _dom_supported = set(_DOM_OTAS.values())
        _skip = set(results.keys()) - _dom_supported
        # D107: STOP = STOP — the DOM phase (the longest of the scan:
        # reading the live tabs one by one) NEVER starts after
        # a ⏹, and cuts between each tab if the stop lands during it.
        _dom_cancel = (lambda: True) if _stopped_after_loop else cancel_cb
        dom_results = dom.extract_all(
            skip_otas=_skip, cancel_cb=_dom_cancel,
            url_allowed=lambda url: page_key(url) in _selected_pages)
        results.errors.extend(getattr(dom, "errors", []))
        _diag.event("dom_result", results=dom_results, errors=getattr(dom, "errors", []))
        # Merge DOM results — apply the same room-matching logic
        for ota_name, room_prices in dom_results.items():
            if not room_prices:
                continue
            if progress_cb:
                # D107: protected like everywhere — a ⏹ here no longer
                # throws away the already-merged results.
                try:
                    progress_cb(100, f"DOM: {ota_name} ({len(room_prices)} rooms)")
                except ScanCancelled:
                    break

            # Match detected room names to configured room types.
            # SAME alias loading as the JSON path: the mapping the user
            # saved in "Room names on OTAs" is authoritative everywhere.
            # Without this, the DOM path re-derived attribution by name
            # similarity alone and could shuffle rooms between scans.
            _dom_src = _source_id_from_vae_name(str(ota_name).lower())
            _dom_rids = dict(_json_rids.get(ota_name) or {})
            if room_types:
                _dom_aliases = _calib_room_aliases(_dom_src)
                matched = _match_rooms(list(room_prices.keys()), room_types,
                                       aliases=_dom_aliases)
                # Machine-ID attribution (ids inherited from the JSON pass
                # by name correlation) overrides names here too.
                matched = _apply_id_aliases(matched, _dom_rids, _dom_src,
                                            _dom_aliases)
            else:
                matched = {n: n for n in room_prices}

            room_results = {}
            for detected_name, config_room in matched.items():
                price = room_prices.get(detected_name)
                if price and price > 0:
                    room_results[config_room] = price

            # Same rule as the JSON path: a NAMED room without a safe match
            # is left aside — never redistributed by price order.
            if room_types:
                _to_del = [rt for rt in list(room_results.keys())
                           if rt not in room_types]
                for _rt in _to_del:
                    del room_results[_rt]
                for n in (n for n in room_prices if n not in matched):
                    print(f"[VAE_BRIDGE] {ota_name}: unmatched room "
                          f"(left aside): {n[:44]} = {room_prices[n]}",
                          flush=True)

            if room_results:
                _existing = results.get(ota_name, {})
                captured_contexts = _json_contexts.get(ota_name) or []
                live_contexts = getattr(dom, "contexts", {}).get(ota_name) or []
                compatible = bool(captured_contexts and live_contexts and all(
                    any(same_stay(c, live) for c in captured_contexts) for live in live_contexts))
                if compatible:
                    results[ota_name] = merge_room_prices(_existing, room_results)
                else:
                    results[ota_name] = room_results
                _diag.event("context_merge", ota=ota_name, contexts_compatible=compatible,
                            decision="merge" if compatible else "live observation replaces unverified captured context",
                            captured=_existing, observed=room_results, retained=results[ota_name])
            else:
                compatible = False
            # The matching menu needs observed names even without a saved match.
            rows = {r["name"]: r for r in detected_report.get(ota_name, {}).get("rooms", [])} if compatible else {}
            rows.update({n: {"name": n, "price": p, "our": matched.get(n) or "", "rid": _dom_rids.get(n, "")}
                         for n, p in room_prices.items()})
            detected_report[ota_name] = {"source_id": _dom_src, "rooms": list(rows.values())}
    except Exception as e:
        _diag.error("dom_extract", e)
        logging.exception("[VAE_BRIDGE] DOM extraction failed")
        results.failure("DOM", "DOM", e)

    _save_detected_report(detected_report, config,
                          open_pages=_selected_pages if _open_hosts is not None and require_open_tab else None,
                          selected_pages=_configured_pages)

    # D80: legal ledger — every displayed price read goes to the evidence
    # registry (append-only, never purged). Failure non-blocking.
    try:
        from business import legal_ledger as _ll
        for _ota, _rooms in (results or {}).items():
            for _room, _price in (_rooms or {}).items():
                _ll.journal_price_read(_ota, _room, _price,
                                       currency=target_currency,
                                       source="OTA scan")
    except Exception:
        pass

    return results


def _save_detected_report(report: dict, config=None, open_pages=None, selected_pages=None) -> None:
    """Best-effort persistence of the room names each OTA displayed during
    this scan — feeds the 'Room names on OTA' dialog so the
    hotelier maps names picked from real data, never typed blind."""
    try:
        import datetime
        from core.paths import DATA_DIR
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        path = DATA_DIR / "ota_detected_rooms.json"
        path.write_text(
            json.dumps({"updated": datetime.datetime.now().isoformat(timespec="seconds"),
                        "page_keys": sorted(selected_pages or []),
                        "open_page_keys": sorted(open_pages) if open_pages is not None else None,
                        "hotel_name": (config or {}).get("hotel_name", ""),
                        "room_types": (config or {}).get("room_types", []),
                        "otas": report}, ensure_ascii=False, indent=1),
            encoding="utf-8")
    except Exception as exc:
        _diag.error("report_save", exc)
        logging.exception("Could not save detected room report")


def _airbnb_stay_key(url):
    """Only an explicit listing, stay and occupancy identify a comparable price."""
    from urllib.parse import urlsplit, parse_qs
    from datetime import date
    try:
        u = urlsplit(url)
        if not _re.search(r'(^|\.)airbnb\.[a-z.]+$', (u.hostname or '').lower()):
            return None
        match = _re.fullmatch(r'/rooms/(\d+)/?', u.path)
        q = parse_qs(u.query)
        if not match or any(len(q.get(k, [])) != 1 for k in ('check_in', 'check_out', 'adults')):
            return None
        start, end = (date.fromisoformat(q[k][0]) for k in ('check_in', 'check_out'))
        occupancy = tuple(int(q.get(k, ['0'])[0]) for k in ('adults', 'children', 'infants', 'pets'))
        if end <= start or occupancy[0] < 1 or any(n < 0 for n in occupancy):
            return None
        return (match.group(1), start.isoformat(), end.isoformat(), *occupancy)
    except (ValueError, TypeError):
        return None


def _airbnb_parse_price(s: str):
    """Parse an Airbnb display price in any locale layout.

    Handles symbol-after ("24 €", FR) and symbol-before ("$2,431", EN),
    with FR decimal commas ("24,5 €") vs EN thousands commas ("2,431").
    Returns (float, symbol) or (None, None).
    """
    s = s.replace("\u00a0", " ").replace("\u202f", " ").strip()
    m = (_re.search(r"([\d][\d\s.,]*)\s*(€|₹|\$|£)", s)
         or _re.search(r"(€|₹|\$|£)\s*([\d][\d\s.,]*)", s))
    if not m:
        return None, None
    g = m.groups()
    num_s, sym = (g[0], g[1]) if g[1] in "€₹$£" else (g[1], g[0])
    num_s = num_s.strip()
    if "," in num_s and "." in num_s:
        if num_s.rfind(',') > num_s.rfind('.'):
            num_s = num_s.replace('.', '').replace(',', '.')
        else:
            num_s = num_s.replace(",", "")
    elif "," in num_s:
        parts = num_s.split(",")
        if len(parts[-1]) == 3 and all(len(p) == 3 for p in parts[1:]):
            num_s = num_s.replace(",", "")        # thousands: 2,431
        else:
            num_s = num_s.replace(",", ".")       # FR decimal: 24,5
    elif "." in num_s and len(num_s.rsplit('.', 1)[-1]) == 3:
        num_s = num_s.replace('.', '')
    num_s = num_s.replace(" ", "")
    try:
        return float(num_s), sym
    except ValueError:
        return None, None


def _airbnb_state_price(prices, target_currency: str):
    """Best integer price (target currency) from raw display strings found
    on ONE listing's page (D100).

    A listing page repeats its OWN price across its sections; when several
    distinct values still appear, the most common wins so a stray promo
    badge cannot outweigh the book module."""
    _sym_map = {"€": "EUR", "₹": "INR", "$": "USD", "£": "GBP"}
    conv = None
    try:
        from vae.src.extractors.currency_converter import CurrencyConverter
        conv = CurrencyConverter()
    except Exception as exc:
        _diag.error("currency_init", exc, ota="Airbnb")
        conv = None
    votes = {}
    for cand in prices or []:
        p = _airbnb_parse_price(str(cand))
        if p is None or p[0] is None:
            _diag.event("price_parse", "rejected", ota="Airbnb", candidate=str(cand), reason="unrecognized amount")
            continue
        num, sym = p
        cur = _sym_map.get(sym, "EUR")
        _diag.event("price_parse", ota="Airbnb", candidate=str(cand), amount=num,
                    source_currency=cur, target_currency=target_currency)
        if conv is not None and cur != target_currency:
            try:
                num = conv.convert(num, cur, target_currency)
                _diag.event("conversion", ota="Airbnb", amount=num, target_currency=target_currency)
            except Exception as exc:
                _diag.error("conversion", exc, ota="Airbnb", source_currency=cur, target_currency=target_currency)
                continue
        elif conv is None and cur != target_currency:
            _diag.event("conversion", "rejected", ota="Airbnb", reason="converter unavailable",
                        amount=num, source_currency=cur, target_currency=target_currency)
            continue
        if not num or num <= 0:
            continue
        val = int(round(num))
        votes[val] = votes.get(val, 0) + 1
    if not votes:
        return None
    return max(votes.items(), key=lambda kv: (kv[1], kv[0]))[0]


def _airbnb_live_price(listing_id: str, target_currency: str):
    """Displayed price of an OPEN Airbnb listing tab, via CDP.

    Finds the browser tab whose URL contains /rooms/<listing_id> and reads
    the page's own price — first from its embedded structured state
    (per-listing truth, same shape as the captured API bodies), then from
    the visible text as a last resort. Returns (price_in_target_currency,
    source) with source 'page-state' (embedded JSON) or 'page-card'
    (booking card, D106), or (None, None) when
    the tab is closed, the page has no price yet, or anything fails.
    Pure read — no navigation, no click."""
    import asyncio
    import urllib.request
    import websockets
    _diag.event("airbnb_live_start", ota="Airbnb", listing_id=listing_id,
                target_currency=target_currency)

    def _read_tab():
        try:
            tabs = json.load(urllib.request.urlopen(
                "http://localhost:9222/json", timeout=5))
        except Exception as exc:
            _diag.error("airbnb_tabs", exc, listing_id=listing_id, ota="Airbnb")
            return None
        candidates = [t for t in tabs if t.get('type') == 'page'
                      and (_airbnb_stay_key(t.get('url', '')) or (None,))[0] == listing_id]
        if len({_airbnb_stay_key(t['url']) for t in candidates}) == 1:
            return candidates[0]
        if candidates:
            _diag.event('airbnb_tab', 'rejected', ota='Airbnb', listing_id=listing_id,
                        reason='multiple open stays for this listing')
        return None

    def _tab_still_on_listing(ws_url: str) -> bool:
        """Anti-crossing re-check AFTER the read.

        The auto-refresh navigates Airbnb tabs between listings. A read that
        started on listing X's tab can land after the tab moved to listing Y
        — the price returned would be Y's, attributed to X (measured
        2026-08-16: scan readings crossed exactly this way). Re-listing the
        tabs and confirming the SAME socket still shows /rooms/<listing_id>
        kills the race: when in doubt, no price at all."""
        try:
            tabs = json.load(urllib.request.urlopen(
                "http://localhost:9222/json", timeout=5))
        except Exception:
            return False
        for t in tabs:
            if t.get("webSocketDebuggerUrl") == ws_url:
                return _airbnb_stay_key(t.get('url', '')) == _airbnb_stay_key(tab.get('url', ''))
        return False

    async def _evaluate(ws_url: str):
        # D100/D105 — trusted sources ONLY, both per-listing by construction:
        #   1. 'state' : the page's embedded <script type="application/json">
        #      blobs (same stayProductDetailPrice sections as captured API
        #      bodies — belongs to THIS listing);
        #   2. 'card'  : the booking card (D106). One booking card exists per
        #      PDP and it prices THIS listing's stay — reading inside it
        #      cannot catch the property-level "from" price or another
        #      room's card, which is exactly how the WHOLE-DOM text scan
        #      produced 1734/1734 on two different listings (client PC).
        #   NO unscoped DOM text, ever.
        js = r'''
        (() => {
          const found = [];
          const diagnostic = {ready_state: document.readyState, json_blocks: 0,
                              json_parse_errors: 0, card_found: false};
          const finish = (src, prices, reason) => JSON.stringify({src, prices, diagnostic: {...diagnostic, reason}});
          const walk = (n, d) => {
            if (!n || typeof n !== 'object' || d > 16 || found.length >= 8) return;
            for (const k of Object.keys(n)) {
              const v = n[k];
              if (k === 'structuredDisplayPrice' && v && typeof v === 'object') {
                const line = v.primaryLine || {};
                const s = line.discountedPrice || line.price || '';
                if (s) found.push(String(s));
              } else if (v && typeof v === 'object') {
                walk(v, d + 1);
              }
            }
          };
          for (const sc of document.querySelectorAll('script[type="application/json"]')) {
            diagnostic.json_blocks++;
            try { walk(JSON.parse(sc.textContent), 0); } catch (e) { diagnostic.json_parse_errors++; }
            if (found.length) break;
          }
          if (found.length) return finish('state', found, 'structured_price_found');
          let card = document.querySelector(
            '[data-testid="bookit-sidebar"], [data-testid="book-it"]');
          if (!card) {
            const btn = [...document.querySelectorAll('button, a[role="button"]')]
              .find(b => /^(r[ée]server|reserve|book)$/i.test(
                  (b.textContent || '').trim()));
            if (btn) {
              let el = btn;
              for (let i = 0; i < 14 && el.parentElement; i++) {
                el = el.parentElement;
                const t = (el.textContent || '');
                if (/au total|total/i.test(t) && t.length < 3000) {
                  card = el;
                  break;
                }
              }
            }
          }
          if (!card) return finish('none', [], 'booking_card_not_found');
          diagnostic.card_found = true;
          const txt = (card.textContent || '').replace(/\s+/g, ' ');
          diagnostic.card_text_length = txt.length;
          diagnostic.visible_amounts = (txt.match(/[€$₹£]\s*\d[\d., ]{0,14}|\d[\d., ]{0,14}\s*[€$₹£]/g) || []).slice(0, 20);
          const amount = '(?:[€$₹£]\\s*\\d[\\d.,\\s]*|\\d[\\d.,\\s]*[€$₹£])';
          let m = txt.match(new RegExp('(' + amount + ')\\s*(?:/|par|per|a)\\s*(?:nuit|night)', 'i'));
          if (m) return finish('card', [m[1].trim()], 'nightly_card_price_found');
          m = txt.match(new RegExp('(' + amount + ')\\s*(?:au total|total)', 'i'));
          if (m) return finish('card', [m[1].trim()], 'total_card_price_found');
          return finish('none', [], 'card_price_pattern_not_matched');
        })()
        '''
        async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
            await ws.send(json.dumps({
                "id": 1, "method": "Runtime.evaluate",
                "params": {"expression": js, "returnByValue": True}}))
            while True:
                data = json.loads(await asyncio.wait_for(ws.recv(), timeout=6))
                if data.get("id") == 1:
                    if data.get("error") or data.get("result", {}).get("exceptionDetails"):
                        _diag.event("airbnb_evaluate", "error", ota="Airbnb", listing_id=listing_id,
                                    protocol_error=data.get("error"),
                                    javascript_error=data.get("result", {}).get("exceptionDetails"))
                    return (data.get("result", {}).get("result", {})
                            .get("value"))

    async def _evaluate_ready_js(ws_url: str, js: str):
        """Run one JS snippet via CDP (fire-and-forget read)."""
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                await ws.send(json.dumps({
                    "id": 1, "method": "Runtime.evaluate",
                    "params": {"expression": js, "returnByValue": True}}))
                while True:
                    data = json.loads(await asyncio.wait_for(
                        ws.recv(), timeout=6))
                    if data.get("id") == 1:
                        return (data.get("result", {})
                                .get("result", {}).get("value"))
        except Exception:
            return None

    async def _evaluate_ready(ws_url: str):
        """document.readyState via CDP — the walk's render wait."""
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                await ws.send(json.dumps({
                    "id": 1, "method": "Runtime.evaluate",
                    "params": {"expression": "document.readyState",
                               "returnByValue": True}}))
                while True:
                    data = json.loads(await asyncio.wait_for(
                        ws.recv(), timeout=6))
                    if data.get("id") == 1:
                        return (data.get("result", {})
                                .get("result", {}).get("value"))
        except Exception:
            return None

    def _find_plain_tab():
        """Tabs on /rooms/<listing_id> WITHOUT a complete stay (share links
        '?s=67', bare links): Airbnb prices nothing without dates, so these
        are navigation candidates only — never read as-is, and their
        original URL is always restored afterwards (D34)."""
        from urllib.parse import urlsplit as _usplit
        out = []
        try:
            tabs = json.load(urllib.request.urlopen(
                "http://localhost:9222/json", timeout=5))
        except Exception:
            return out
        for t in tabs:
            if t.get('type') != 'page':
                continue
            u = _usplit(t.get('url', '') or '')
            if not _re.search(r'(^|\.)airbnb\.[a-z.]+$', (u.hostname or '').lower()):
                continue
            m = _re.fullmatch(r'/rooms/(\d+)/?', u.path or '')
            if m and m.group(1) == listing_id and not _airbnb_stay_key(t.get('url', '')):
                out.append(t)
        return out

    async def _navigate(ws_url: str, url: str) -> bool:
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                await ws.send(json.dumps({
                    "id": 1, "method": "Page.navigate",
                    "params": {"url": url}}))
                while True:
                    data = json.loads(await asyncio.wait_for(ws.recv(), timeout=6))
                    if data.get("id") == 1:
                        return not data.get("error")
        except Exception:
            return False

    def _default_stay_url():
        """Tonight's stay — the reference night. Airbnb renders no booking
        card without dates and none for a PAST night (client tab left on
        check_in=2026-10-27 read nothing for a whole day)."""
        from datetime import date, timedelta
        ci = date.today()
        co = ci + timedelta(days=1)
        return (f"https://www.airbnb.fr/rooms/{listing_id}"
                f"?check_in={ci.isoformat()}"
                f"&check_out={co.isoformat()}&adults=1")

    def _nav_to_tonight(candidate):
        """Navigate a tab to tonight's stay; returns the tab to read (with
        its url updated so the anti-crossing re-check stays coherent) or
        None, plus the URL to restore."""
        restore = candidate.get("url") or ""
        nav_url = _default_stay_url()
        if not asyncio.run(_navigate(candidate.get("webSocketDebuggerUrl", ""), nav_url)):
            _diag.event("airbnb_nav", "error", ota="Airbnb", listing_id=listing_id,
                        reason="navigation failed", from_url=restore, to_url=nav_url)
            return None, ""
        _diag.event("airbnb_nav", ota="Airbnb", listing_id=listing_id,
                    reason="no usable stay on the tab — navigated to tonight",
                    from_url=restore, to_url=nav_url)
        time.sleep(3)
        return dict(candidate, url=nav_url), restore


    _ACTIVATE_JS = r"""
    (() => {
      const btn = [...document.querySelectorAll('button, a[role="button"]')]
        .find(b => /^(réserver|reserve|book)$/i.test(
            (b.textContent || '').trim()));
      if (!btn) return null;
      try { btn.scrollIntoView({block: 'center'}); } catch (e) {}
      const r = btn.getBoundingClientRect();
      if (!r || r.width <= 0 || r.height <= 0) return null;
      return JSON.stringify([r.x + r.width / 2, r.y + r.height / 2]);
    })()
    """

    async def _activate_tab(ws_url: str) -> bool:
        """Active fallback (proven on the date-walk engine): on some
        pages the embedded state carries structuredDisplayPrice=null and
        the booking card NEVER renders without interaction — the passive
        pure-read waits forever. D93 anti-throttle, scroll to the
        booking section, ONE native trusted Réserver click (real
        input event, not .click()), wait for the render. No navigation:
        the owner's URL stays untouched (D34)."""
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                state = {"mid": 0}

                async def _cmd(method, params=None):
                    state["mid"] += 1
                    await ws.send(json.dumps({
                        "id": state["mid"], "method": method,
                        "params": params or {}}))

                async def _wait():
                    while True:
                        data = json.loads(await asyncio.wait_for(
                            ws.recv(), timeout=8))
                        if data.get("id") == state["mid"]:
                            return data

                await _cmd("Emulation.setFocusEmulationEnabled",
                           {"enabled": True})
                await _wait()
                await _cmd("Page.setWebLifecycleState",
                           {"state": "active"})
                await _wait()
                await _cmd("Runtime.evaluate",
                           {"expression": _ACTIVATE_JS,
                            "returnByValue": True})
                data = await _wait()
                raw = (data.get("result", {}).get("result", {})
                       .get("value"))
                center = json.loads(raw) if isinstance(raw, str) else None
                if not center:
                    _diag.event("airbnb_activate", "rejected",
                                ota="Airbnb", listing_id=listing_id,
                                reason="Réserver button not clickable")
                    return False
                for typ in ("mousePressed", "mouseReleased"):
                    await _cmd("Input.dispatchMouseEvent", {
                        "type": typ, "x": int(center[0]),
                        "y": int(center[1]), "button": "left",
                        "buttons": 1, "clickCount": 1})
                    await _wait()
                _diag.event("airbnb_activate", ota="Airbnb",
                            listing_id=listing_id,
                            reason="Réserver clicked — card render wait")
                return True
        except Exception as exc:
            _diag.error("airbnb_activate", exc, ota="Airbnb",
                        listing_id=listing_id)
            return False

    async def _reload_tab(ws_url: str) -> bool:
        """Second fallback (proven live: a tab open for hours keeps the
        booking widget UNMOUNTED — no Réserver button at all). Reload the
        SAME URL (D34: never close, never move the owner's tab), wait
        for the document to complete, then the activation click runs on
        the fresh render."""
        try:
            async with websockets.connect(ws_url, max_size=2 ** 22) as ws:
                state = {"mid": 0}

                async def _cmd(method, params=None):
                    state["mid"] += 1
                    await ws.send(json.dumps({
                        "id": state["mid"], "method": method,
                        "params": params or {}}))

                async def _wait():
                    while True:
                        data = json.loads(await asyncio.wait_for(
                            ws.recv(), timeout=8))
                        if data.get("id") == state["mid"]:
                            return data

                await _cmd("Page.enable")
                await _wait()
                await _cmd("Page.reload", {"ignoreCache": True})
                await _wait()
                deadline = asyncio.get_event_loop().time() + 25
                while asyncio.get_event_loop().time() < deadline:
                    await _cmd("Runtime.evaluate",
                               {"expression": "document.readyState",
                                "returnByValue": True})
                    data = await _wait()
                    v = (data.get("result", {}).get("result", {})
                         .get("value"))
                    if v == "complete":
                        # widget mounts with scrolling (measured live)
                        for _sc in range(6):
                            await _cmd("Runtime.evaluate", {
                                "expression": "window.scrollTo(0,"
                                              " document.body.scrollHeight)",
                                "returnByValue": True})
                            await _wait()
                            await asyncio.sleep(2)
                        return True
                    await asyncio.sleep(1)
                return False
        except Exception as exc:
            _diag.error("airbnb_reload", exc, ota="Airbnb",
                        listing_id=listing_id)
            return False

    def _shifted_stay_url(url: str, offset_days: int) -> str:
        """The tab's own URL with the stay moved forward by N days
        (owner rule: no price at this stay -> the next day)."""
        from datetime import date as _d, timedelta as _td
        m = _re.search(r'check_in=(\d{4}-\d{2}-\d{2})', url)
        if not m:
            return ""
        ci = _d.fromisoformat(m.group(1)) + _td(days=offset_days)
        out = url[:m.start(1)] + ci.isoformat() + url[m.end(1):]
        m2 = _re.search(r'check_out=(\d{4}-\d{2}-\d{2})', url)
        if m2:
            co = _d.fromisoformat(m2.group(1)) + _td(days=offset_days)
            out = out[:m2.start(1)] + co.isoformat() + out[m2.end(1):]
        return out

    tab = None
    restore_url = ""
    try:
        tab = _read_tab()
        if tab is not None:
            stay = _airbnb_stay_key(tab.get("url", "")) or None
            from datetime import date as _date
            if stay is not None and stay[1] < _date.today().isoformat():
                # Past stay: no booking card will EVER render — move to
                # tonight for the read, then give the owner's URL back.
                _navigated, restore_url = _nav_to_tonight(tab)
                if _navigated is not None:
                    tab = _navigated
                else:
                    restore_url = ""
        if tab is None:
            # No complete stay on any tab of this listing (e.g. '?s=67'
            # share links): pick its plain tab and navigate to tonight.
            plain = _find_plain_tab()
            if plain:
                tab, restore_url = _nav_to_tonight(plain[0])
        if not tab:
            _diag.event("airbnb_tab", "rejected", ota="Airbnb", listing_id=listing_id, reason="listing tab not returned by CDP")
            return None, None
        _diag.event("airbnb_tab", ota="Airbnb", listing_id=listing_id, url=tab.get("url"),
                    websocket_present=bool(tab.get("webSocketDebuggerUrl")))
        val = None
        activated = False
        for attempt in range(3):
            val = asyncio.run(_evaluate(tab["webSocketDebuggerUrl"]))
            try:
                evidence = json.loads(val or '{}')
            except (TypeError, ValueError):
                break
            if evidence.get('prices') or evidence.get('diagnostic', {}).get('card_found'):
                break
            _diag.event('airbnb_waiting_for_price', ota='Airbnb', listing_id=listing_id,
                        attempt=attempt + 1, reason='reservation card not rendered',
                        ready_state=evidence.get('diagnostic', {}).get('ready_state'))
            if attempt == 0 and not activated:
                # first miss: make the page ACTIVE (D93 + native click)
                # and re-read immediately
                activated = True
                try:
                    asyncio.run(_activate_tab(tab["webSocketDebuggerUrl"]))
                except Exception as exc:
                    _diag.error("airbnb_activate_call", exc, ota="Airbnb",
                                listing_id=listing_id)
                time.sleep(4)
                continue
            if attempt == 1:
                # second miss: the widget may never have mounted (tab
                # open for hours) — reload the SAME URL and reactivate
                try:
                    if asyncio.run(_reload_tab(tab["webSocketDebuggerUrl"])):
                        asyncio.run(
                            _activate_tab(tab["webSocketDebuggerUrl"]))
                except Exception as exc:
                    _diag.error("airbnb_reload_call", exc, ota="Airbnb",
                                listing_id=listing_id)
                time.sleep(4)
                continue
            if attempt < 2:
                time.sleep(1)
        # Stay date-walk (owner's scan rule, proven on the date-walk
        # engine): a listing's CURRENT tab stay can simply have NO price
        # (unavailable stay — measured live: full page rendered, booking
        # widget in "modify dates" state, zero amounts). Walk the stay
        # forward day by day (max +7) until a price shows; the owner's
        # original URL is restored at the end (D34).
        try:
            _ev_last = json.loads(val or '{}')
        except (TypeError, ValueError):
            _ev_last = {}
        if not (_ev_last.get('prices')
                or _ev_last.get('diagnostic', {}).get('card_found')):
            _base_url = tab.get("url", "")
            if _re.search(r'check_in=\d{4}-\d{2}-\d{2}', _base_url):
                restore_url = restore_url or _base_url
                _diag.event("airbnb_stay_walk", ota="Airbnb",
                            listing_id=listing_id,
                            reason="no price at the current stay — walking",
                            from_stay=_base_url[:90])
                for _off in range(1, 8):
                    _wu = _shifted_stay_url(_base_url, _off)
                    if not _wu:
                        break
                    if not asyncio.run(_navigate(
                            tab["webSocketDebuggerUrl"], _wu)):
                        break
                    time.sleep(2)
                    for _ in range(15):
                        try:
                            _rs = asyncio.run(_evaluate_ready(
                                tab["webSocketDebuggerUrl"]))
                        except Exception:
                            _rs = None
                        if _rs == "complete":
                            break
                        time.sleep(1)
                    # the booking widget mounts progressively WITH
                    # scrolling (measured live: 582 -> 10 951 chars over
                    # 8 scrolls) — scroll while waiting, never blind
                    for _sc in range(6):
                        try:
                            asyncio.run(_evaluate_ready_js(
                                tab["webSocketDebuggerUrl"],
                                "window.scrollTo(0,"
                                " document.body.scrollHeight)"))
                        except Exception:
                            pass
                        time.sleep(2)
                    try:
                        asyncio.run(_activate_tab(
                            tab["webSocketDebuggerUrl"]))
                    except Exception:
                        pass
                    time.sleep(3)
                    val = asyncio.run(_evaluate(
                        tab["webSocketDebuggerUrl"]))
                    try:
                        _ev_last = json.loads(val or '{}')
                    except (TypeError, ValueError):
                        _ev_last = {}
                    if (_ev_last.get('prices')
                            or _ev_last.get('diagnostic', {})
                            .get('card_found')):
                        tab = dict(tab, url=_wu)
                        _diag.event("airbnb_stay_walk", ota="Airbnb",
                                    listing_id=listing_id,
                                    reason="price found at a later stay",
                                    to_stay=_wu[:90])
                        break
        # LAST fallback — the PROVEN card machine of the date-walk
        # engine (scan_dates, 4/4 listings measured live): it navigates
        # this tab to the listing's dated stay, scroll-loops until the
        # widget mounts (measured 582 -> 11k chars), clicks Réserver
        # natively and reads the card. The owner's original URL is
        # restored in the finally below (D34).
        try:
            import scan_dates as _sd
            from datetime import date as _d2, timedelta as _td2
            _stay = _airbnb_stay_key(tab.get('url', ''))
            _ci = (_d2.fromisoformat(_stay[1])
                   if _stay and len(_stay) > 1 and _stay[1] else _d2.today())
            _raw = None
            for _off in range(14):
                # owner's scan rule: no price at this stay -> next day
                _raw = _sd._airbnb_card_price(
                    listing_id, _ci + _td2(days=_off), log=lambda m: None)
                if _raw:
                    break
            if _raw:
                _out = _airbnb_state_price([f'{_raw} €'],
                                           target_currency)
                if _out:
                    restore_url = restore_url or (tab.get('url') or '')
                    _diag.event("airbnb_walk_card", ota="Airbnb",
                                listing_id=listing_id, price=_out,
                                reason="date-walk card machine read")
                    return _out, "page-card"
        except Exception as exc:
            _diag.error("airbnb_walk_card", exc, ota="Airbnb",
                        listing_id=listing_id)
        if not val:
            _diag.event("airbnb_payload", "rejected", ota="Airbnb", listing_id=listing_id,
                        reason="evaluation returned no price payload")
            return None, None
        # Navigation race: the tab may have been navigated to another
        # listing between the URL match and the read (auto-refresh). The
        # price read would belong to the WRONG listing — discard it.
        if not _tab_still_on_listing(tab["webSocketDebuggerUrl"]):
            _diag.event("airbnb_navigation", "rejected", ota="Airbnb", listing_id=listing_id,
                        reason="listing identity not confirmed after read")
            return None, None
        src, prices = "text", []
        try:
            payload = json.loads(val)
            src = payload.get("src") or "text"
            prices = payload.get("prices") or []
            if payload.get('diagnostic', {}).get('reason') == 'total_card_price_found':
                from datetime import date
                stay = _airbnb_stay_key(tab['url'])
                nights = (date.fromisoformat(stay[2]) - date.fromisoformat(stay[1])).days
                prices = [f'{amount / nights:.8f}{symbol}' for amount, symbol in
                          (_airbnb_parse_price(str(p)) for p in prices) if amount is not None]
            _diag.event("airbnb_page_evidence", ota="Airbnb", listing_id=listing_id,
                        evidence=payload.get("diagnostic", {}))
        except (TypeError, ValueError):
            prices = [str(val)]
        _diag.event("airbnb_candidates", ota="Airbnb", listing_id=listing_id, source=src, prices=prices)
        out = _airbnb_state_price(prices, target_currency)
        _diag.event("airbnb_live_result", "observed" if out else "rejected", ota="Airbnb",
                    listing_id=listing_id, price=out, source=src)
        if not out:
            return None, None
        return out, ("page-state" if src == "state" else
                     "page-card" if src == "card" else None)
    except Exception as exc:
        _diag.error("airbnb_live", exc, ota="Airbnb", listing_id=listing_id)
        return None, None
    finally:
        # D34: a tab we navigated is ALWAYS given its original URL back.
        if restore_url and tab is not None and tab.get("webSocketDebuggerUrl"):
            try:
                asyncio.run(_navigate(tab["webSocketDebuggerUrl"], restore_url))
                _diag.event("airbnb_restore", ota="Airbnb", listing_id=listing_id,
                            url=restore_url)
            except Exception:
                pass


# How many newest Airbnb capture metas the scan reads when the live read
# misses (D101, widened D105-1): on the client PC the newest 400 metas held
# NO PDP body (231k captures churning — keepalive floods drown the listing
# pages), so the read fell through to a text guess. 2500 metas costs only
# meta-JSON parsing (bodies are read on match only).
_AIRBNB_META_WINDOW = 2500


def _airbnb_listing_data(otas: list, target_currency: str, cancel_cb=None,
                         room_types=None, config=None, allowed_pages=None):
    """Per-listing Airbnb extraction — D110: the Expedia model.

    ONE SINGLE "Airbnb" OTA (single result key), one room per
    listing, a listing's identity = ITS NUMBER (/rooms/<id>, displayed
    "Listing …XXXX") — the Airbnb listings all share the same title,
    a name cannot distinguish anything (historical cause of the mixing).
    D107: cancel_cb (⏹ Stop) — queried BEFORE EVERY listing.
    D108: attribution by the room_names sheet — D110: single
    "airbnb" sheet: ids = {listing number: room} (the menu writes it), then
    listing label; a listing with no match is IGNORED with a
    message, never filed at random.

    Returns ({"Airbnb": {room_type: price_int}}, [{name, price, our, lid,
    url}]) — the results live under the "Airbnb" key like Expedia
    under "Expedia": one column, one price per room."""
    from vae import config as _vcfg
    try:
        from core.airbnb_unify import listing_ids_of, listing_display
    except Exception:
        return {}, []

    entries = []
    for lid, url in listing_ids_of({"ota_watch": {"otas": otas or []}}):
        if allowed_pages is not None and page_key(url) not in allowed_pages:
            _diag.event("airbnb_listing_gate", "skipped", ota="Airbnb", listing_id=lid,
                        url=url, reason="listing outside retained selection")
            continue
        ci = _re.search(r"check_in=(\d{4}-\d{2}-\d{2})", url)
        entries.append((lid, listing_display(lid), url,
                        ci.group(1) if ci else ""))
    if not entries:
        return {}, []

    _SYM = {"€": "EUR", "₹": "INR", "$": "USD", "£": "GBP"}
    _lid_set = {lid for lid, _, _, _ in entries}
    # Compare captures to the stay actually open, never to the old saved URL.
    import urllib.request
    live_stays = {lid: set() for lid in _lid_set}
    try:
        tabs = json.load(urllib.request.urlopen('http://localhost:9222/json', timeout=5))
        for tab in tabs:
            key = _airbnb_stay_key(tab.get('url', ''))
            if tab.get('type') == 'page' and key and key[0] in live_stays:
                live_stays[key[0]].add(key)
    except Exception as exc:
        _diag.error('airbnb_capture_context', exc, ota='Airbnb')

    # Index capture bodies by listing id from the PAGE URL (tab
    # attribution), newest first. Content-based re-keying was tried and
    # REJECTED (2026-08-16): Airbnb payloads reference NEIGHBOUR listings
    # and a neighbour's id can be the ONLY config id inside a page's
    # payload — re-keying on it rotates prices between listings. The tab
    # attribution is kept correct by the monitor's reconnect+context
    # refresh; the page URL (documentURL when present, tab_url otherwise)
    # is the page that actually produced the response.
    by_listing = {lid: [] for lid in _lid_set}
    try:
        metas = [p for p in _vcfg.DATA_DIR.glob("*airbnb*.json")
                 if not p.name.endswith('_body.json')]
    except Exception:
        metas = []
    # Only the recent captures matter for a live price: scanning the whole
    # history (2 300+ files after a day of reloads) would parse megabytes
    # per scan for nothing.
    metas.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    for meta_path in metas[:_AIRBNB_META_WINDOW]:
        if meta_path.name.endswith("_body.json"):
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        body_path = meta_path.with_name(meta_path.name[:-5] + "_body.json")
        if not (body_path.exists() and body_path.stat().st_size > 500):
            continue
        page_url = meta.get("documentURL") or meta.get("tab_url") or ""
        m = _re.search(r"/rooms/(\d+)", page_url)
        if not m or m.group(1) not in by_listing:
            continue
        key = _airbnb_stay_key(page_url)
        expected = live_stays[m.group(1)]
        if not key or len(expected) != 1 or key not in expected:
            _diag.event('airbnb_capture_context', 'rejected', ota='Airbnb',
                        listing_id=m.group(1), file=str(meta_path),
                        reason='capture stay/occupancy does not match one unambiguous open stay')
            continue
        from core.scan_context import capture_scope
        fields = capture_scope(meta).get('fields', {})
        if any(str(fields.get(field, value)) != str(value) for field, value in
               zip(('checkin', 'checkout', 'adults', 'children', 'infants', 'pets'), key[1:])):
            _diag.event('airbnb_capture_context', 'rejected', ota='Airbnb',
                        listing_id=m.group(1), file=str(meta_path), reason='request context differs from open stay')
            continue
        if not 0 <= time.time() - meta_path.stat().st_mtime <= 1800:
            _diag.event('airbnb_capture_context', 'rejected', ota='Airbnb',
                        listing_id=m.group(1), file=str(meta_path), reason='capture older than 30 minutes or future-dated')
            continue
        by_listing[m.group(1)].append((body_path, page_url,
                                       body_path.stat().st_mtime))
    for lid in by_listing:
        by_listing[lid].sort(key=lambda t: t[2], reverse=True)
    _diag.event("airbnb_capture_index", ota="Airbnb", directory=str(_vcfg.DATA_DIR),
                examined_limit=_AIRBNB_META_WINDOW, metadata_candidates=len(metas),
                per_listing={lid: len(caps) for lid, caps in by_listing.items()})

    conv = None
    try:
        from vae.src.extractors.currency_converter import CurrencyConverter
        conv = CurrencyConverter()
    except Exception:
        conv = None

    def _price_of(body_path):
        """Displayed price (target currency int) inside one capture, or None."""
        try:
            data = json.loads(body_path.read_text(encoding="utf-8",
                                                  errors="replace"))
        except Exception as exc:
            _diag.error("airbnb_capture_parse", exc, ota="Airbnb", file=str(body_path))
            return None
        sections = (data.get("data", {}).get("presentation", {})
                       .get("stayProductDetailPage", {})
                       .get("sections", {}).get("sections", []))
        for sec in sections:
            if not isinstance(sec, dict):
                continue
            line = ((sec.get("section", {})
                      .get("structuredDisplayPrice") or {})
                    .get("primaryLine") or {})
            # DiscountedDisplayPriceLine carries discountedPrice +
            # originalPrice (struck-through); QualifiedDisplayPriceLine
            # carries price. The CURRENT displayed selling price is
            # discountedPrice when present.
            cand = line.get("discountedPrice") or line.get("price")
            if not cand:
                continue
            p = _airbnb_parse_price(str(cand))
            if p is None or p[0] is None:
                _diag.event("airbnb_capture_price", "rejected", ota="Airbnb", file=str(body_path),
                            candidate=str(cand), reason="unrecognized amount")
                continue
            num, sym = p
            cur = _SYM.get(sym, "EUR")
            if conv is not None and cur != target_currency:
                try:
                    num = conv.convert(num, cur, target_currency)
                except Exception as exc:
                    _diag.error("airbnb_capture_conversion", exc, ota="Airbnb", file=str(body_path),
                                source_currency=cur, target_currency=target_currency)
                    continue
            elif conv is None and cur != target_currency:
                _diag.event("airbnb_capture_conversion", "rejected", ota="Airbnb", file=str(body_path), reason="converter absent")
                continue
            if num and num > 0:
                return int(round(num))
        return None

    rooms, rows = ScanResults(), []
    # D108: a listing's attribution lives in ITS sheet of the single
    # file (room_names.json, ota_id of the "Airbnb <room>" config entry).
    # The old generic "airbnb" file (crossed since August, never
    # fixed — the cause of the permanent mixing) is NO LONGER consulted.
    try:
        from core import room_names as _rn
        # config absent (tests/stubs): completion WITHOUT seeding —
        # sheets are never seeded from a trial list.
        _rn.ensure_ready(config or {"room_types": room_types or [],
                                     "ota_watch": {"otas": []}})
    except Exception:
        _rn = None

    def _fiche():
        """(names, ids) of THE "airbnb" sheet of the single file (D110:
        a single sheet, like a single OTA). The sheet alone rules (D108
        menu authority); if an install ever wipes it back to a poisoned
        stub, repair_fiche() heals it ONCE from the owner's per-listing
        declarations (2026-10-26 incident) — no per-scan fallback here,
        the menu's edits and deletions must always win."""
        return _calib_room_aliases("airbnb"), _calib_id_aliases("airbnb")

    for lid, _display, _url, check_in in entries:
        # D107: STOP = STOP — before each listing, not after the four.
        if cancel_cb:
            try:
                if cancel_cb():
                    raise ScanCancelled()
            except ScanCancelled:
                raise
            except Exception:
                pass
        # D105-1 — LIVE STRUCTURED STATE first; the DOM-TEXT guess is BANNED.
        # Client PC 08-09/10 (patch v7 active): the structured state was not
        # found on the real pages and the capture window held no PDP body,
        # so the TEXT path ran and read the property-level "from" price —
        # the SAME figure for two different listings (1734/1734), which is
        # exactly the cross-reading this function exists to kill. Rule now:
        # state → captures → NOTHING (a listing with no trustworthy price is
        # skipped with a log; inventing a price is forbidden).
        with _diag.listing_scope(lid):
            found, _lsrc = _airbnb_live_price(lid, target_currency)
        if _lsrc in ("page-state", "page-card"):
            _src = ("live page (page state)" if _lsrc == "page-state"
                    else "live page (booking card)")
        else:
            found = None
            _src = None
        if not found:
            caps = by_listing.get(lid) or []
            # Only fresh captures of the exact open stay can rescue a page
            # whose reservation card has not rendered yet.
            passes = [caps]  # Already checked against the exact open stay and age.
            for pool in passes:
                for body_path, _page_url, _mt in pool:
                    _cap = _price_of(body_path)
                    if _cap:
                        found = _cap
                        _diag.event("airbnb_capture_result", ota="Airbnb", listing_id=lid,
                                    file=str(body_path), page_url=_page_url, price=_cap)
                        _src = 'capture matching open stay'
                        break
                if found:
                    break
        if found and _src == 'capture matching open stay':
            try:
                current_tabs = json.load(urllib.request.urlopen('http://localhost:9222/json', timeout=5))
                current_keys = {_airbnb_stay_key(t.get('url', '')) for t in current_tabs
                                if t.get('type') == 'page' and
                                (_airbnb_stay_key(t.get('url', '')) or (None,))[0] == lid}
                if current_keys != live_stays[lid] or len(current_keys) != 1:
                    found = None
            except Exception as exc:
                _diag.error('airbnb_capture_recheck', exc, ota='Airbnb', listing_id=lid)
                found = None
        if found:
            if not _src.startswith("capture"):
                print(f"[AIRBNB] {_display}: {found} {target_currency} "
                      f"[{_src}]", flush=True)
            # D110 — attribution by the single "airbnb" sheet:
            #   1. the anchor by LISTING NUMBER (what the menu records,
            #      immutable — survives any renaming);
            #   2. the listing label ("Listing …XXXX");
            #   3. otherwise: listing IGNORED with a message — never filed
            #      at random.
            _names, _ids = _fiche()
            final_room = (_ids.get(lid)
                          or _names.get(listing_display(lid)))
            if not final_room:
                _diag.event("room_match", "rejected", ota="Airbnb", listing_id=lid,
                            price=found, reason="no configured room correspondence")
                print(f"[AIRBNB] {_display}: NO room "
                      f"match — open \"Room names on OTA\" "
                      f"to file it (ignored price: {found})", flush=True)
                rows.append({'name': _display, 'price': found, 'our': None, 'lid': lid, 'url': _url})
                rooms.failure('Airbnb', 'room_match', f'Listing {lid}: no room correspondence. Open Room names on OTAs.')
                continue
            rooms.setdefault("Airbnb", {})[final_room] = found
            _diag.event("room_match", ota="Airbnb", listing_id=lid, room=final_room, price=found, source=_src)
            rows.append({"name": _display, "price": found, "our": final_room,
                         "lid": lid, "url": _url})
        else:
            rows.append({'name': _display, 'price': None, 'our': _fiche()[1].get(lid), 'lid': lid, 'url': _url})
            rooms.failure('Airbnb', 'price_unavailable', f'Listing {lid}: no readable current price; page may still be loading. No older or different-stay price substituted.')
            if not _fiche()[1].get(lid) and not _fiche()[0].get(listing_display(lid)):
                rooms.failure('Airbnb', 'room_match', f'Listing {lid}: no room correspondence. Open Room names on OTAs.')
            # D106: EXPLICIT purge of the old value — without this, the
            _diag.event("airbnb_price", "rejected", ota="Airbnb", listing_id=lid,
                        reason="live reader and captured data returned no reliable price")
            # last wrong figure stayed in last_results, was displayed
            # and fed the corrections forever ("the problem
            # comes back"). A listing with no reliable price = no value
            # at all, not an old value.
            print(f"[AIRBNB] {_display}: no readable live price or fresh capture "
                  f"matching the open stay — listing ignored for "
                  f"this scan", flush=True)
    return rooms, rows




# D121 : la famille MakeMyTrip (.com ET .global) est UNE SEULE OTA —
# l'hôtelier peut naviguer l'un ou l'autre site : les captures des deux
# domaines appartiennent au même profil (constat 13/10 : captures .com
# ignorées → prix figé sur les vieilles captures .global).
def _brand_of(name: str) -> str:
    """D121-generalized: the OTA brand contained in a domain / a mapping
    key ('' if none). An OTA's identity is its BRAND, not its exact
    domain: the hotelier may browse any URL variant (expedia.com /
    expedia.co.in, makemytrip.com / .global...)."""
    n = str(name or "").lower()
    for d in ("makemytrip", "goibibo", "airbnb", "expedia", "agoda",
              "booking", "google", "trivago", "kayak", "tripadvisor",
              "traveloka", "hotels", "channelmanager", "trip"):
        if d in n:
            return d
    return ""


def _cap_domain_matches(name: str, cap_domains: set) -> bool:
    """True if `name` (mapping key) has captures — same brand = same
    captures, whatever the domain variant."""
    if name in cap_domains:
        return True
    b = _brand_of(name)
    return bool(b) and any(_brand_of(d) == b for d in cap_domains)


def refresh_ota_tabs(brands: set) -> int:
    """D123 — recharge les onglets OTA ouverts dont la MARQUE est dans
    `brands` (via CDP Page.reload — l'onglet reste ouvert, même URL).

    Pourquoi : le scan lit le prix AFFICHÉ dans l'onglet — une page ouverte
    depuis une heure montre le prix tel qu'au chargement, même si l'OTA a
    mis à jour son serveur entre-temps (mise à jour côté OTA : minutes).
    Le garde-fou « scans sans répercution » doit donc rafraîchir la page
    AVANT de compter un strike, sinon il compte du bruit sur une page
    figée (constat propriétaire 13/10 : « le garde-fou doit se rafraîchir
    à chaque nouveau scan »).

    Retourne le nombre d'onglets rechargés. Jamais d'exception.
    """
    import asyncio
    import urllib.request

    wanted = {_brand_of(b) for b in (brands or set()) if _brand_of(b)}
    if not wanted:
        return 0
    try:
        tabs = json.load(urllib.request.urlopen(
            "http://localhost:9222/json", timeout=5))
    except Exception:
        return 0

    targets = []
    for t in tabs:
        if t.get("type") != "page":
            continue
        if _brand_of(t.get("url") or "") in wanted:
            ws = t.get("webSocketDebuggerUrl")
            if ws:
                targets.append(ws)
    if not targets:
        return 0

    async def _reload_all():
        import websockets
        ok = 0
        for ws_url in targets:
            try:
                async with websockets.connect(ws_url, max_size=None) as ws:
                    await ws.send(json.dumps({
                        "id": 1, "method": "Page.reload",
                        "params": {"ignoreCache": True}}))
                    # courte lecture d'accusé (la page recharge ensuite)
                    try:
                        await asyncio.wait_for(ws.recv(), timeout=3)
                    except Exception:
                        pass
                    ok += 1
            except Exception:
                continue
        return ok

    try:
        return asyncio.run(_reload_all())
    except Exception:
        return 0


def _source_id_from_vae_name(vae_ota_name: str) -> str:
    """Config-style OTA id from a VAE domain-based name.
    'www_expedia_co_in' → 'expedia' (calibration profile key)."""
    n = str(vae_ota_name or "").lower()
    # longest first: 'makemytrip' must win over 'trip'
    for domain in ("makemytrip", "goibibo", "airbnb", "expedia", "agoda",
                   "booking", "google", "hotels", "trivago", "kayak",
                   "tripadvisor", "traveloka", "trip"):
        if domain in n:
            return domain
    return ""


def _calib_room_aliases(source_id: str) -> dict:
    """Room-name mappings memorized for this OTA — D108: THE single file.

    ``data/room_names.json`` is the single source of truth of the
    mappings (the "Room names on OTA" menu writes it).
    The calibration files no longer decide the names — the old
    generic airbnb file (crossed since August) is never read again."""
    if not source_id:
        return {}
    try:
        from core import room_names
        return room_names.aliases(source_id)
    except Exception:
        return {}


def _calib_profile_key(source_id: str):
    """Calibration profile key holding this OTA's memorized prices.

    D108: it is no longer THE source of the room names (room_names.json
    is) — the calibration profiles keep the learned prices and sessions."""
    try:
        from core.calib_store import load_calib_data
        data = load_calib_data() or {}
        for key in (data.get("profiles") or {}):
            if str(key).split("||")[-1] == source_id:
                return key
    except Exception:
        pass
    return None


def _calib_id_aliases(source_id: str) -> dict:
    """Machine-ID mappings memorized for this OTA: {ota_room_id: our_room}.

    D108: read from THE single file (room_names.json). IDs (Agoda typeId,
    Goibibo roomCode, MakeMyTrip ratePlan/id, Airbnb listing id…) are the
    only 100%-stable anchor: unlike names they never repeat across rooms,
    never get translated, never change when the OTA renames a category.
    When an id alias exists it OVERRIDES every name-based decision."""
    if not source_id:
        return {}
    try:
        from core import room_names
        return room_names.id_aliases(source_id)
    except Exception:
        return {}


def _learn_id_alias(source_id: str, ota_room_id: str, our_room: str) -> None:
    """Memorize {ota_room_id: our_room} for this OTA — D108: single file.

    Called ONLY when the attribution already succeeded through a source we
    trust (a user-confirmed name alias, or an explicit id alias): the id
    then becomes the durable anchor surviving any future rename of the
    room on the OTA. Fire-and-forget, load-modify-save (collision-safe
    with a running app)."""
    if not (source_id and ota_room_id and our_room):
        return
    try:
        from core import room_names
        room_names.learn_id_alias(source_id, ota_room_id, our_room)
    except Exception:
        pass


def _apply_id_aliases(matched: dict, rids: dict, source_id: str,
                      name_aliases: dict) -> dict:
    """Enforce machine-ID attribution over any name-based decision.

    `matched` : {detected_name: our_room} from the name engine (may miss
    refused/ambiguous entries). `rids` : {detected_name: ota_room_id}.
    An id alias wins everywhere — including rescuing rooms the name
    engine refused. When a name alias (user-confirmed truth) attributed a
    room and the id is not yet memorized, learn it: next time the OTA
    renames the category, the id still matches."""
    id_al = _calib_id_aliases(source_id)
    for det, rid in (rids or {}).items():
        if not rid:
            continue
        if rid in id_al:
            matched[det] = id_al[rid]
        if det in (name_aliases or {}):
            # The name mapping is the user-managed truth: re-sync the id
            # table from it every scan so a poisoned id entry (learned
            # during a past mis-configuration) heals itself.
            _learn_id_alias(source_id, rid, name_aliases[det])
            matched[det] = name_aliases[det]
    return matched


def _match_rooms(detected_names: list, config_room_types: list,
                 aliases: dict = None) -> dict:
    """
    Match detected room names to configured room types.
    Tries exact match first, then fuzzy matching with difflib.
    Falls back to core.room_match if available.

    Returns: {detected_name: config_room_type}
    """
    # Try OTA Guard's room_match module first.
    # match_rooms() returns (mapping, refus) where mapping uses INTEGER indices
    # into detected_names — we must unpack the tuple and convert indices to names.
    try:
        from core.room_match import match_rooms
        mapping, _refus = match_rooms(detected_names, config_room_types,
                                      aliases=aliases)
        # core.room_match is the AUTHORITY: an empty mapping means deliberate
        # refusals (ambiguity / too-dissimilar). Never fall through to the
        # difflib fallback below — raw sequence-ratio happily pairs
        # "Elite Double Room, Garden View" with the wrong room and puts
        # the price on the wrong card (seen on Expedia, 2026-08-15).
        return {detected_names[i]: room
                for i, room in mapping.items()
                if i < len(detected_names)}
    except Exception:
        pass

    # Fallback: simple fuzzy matching
    matched = {}
    used_config = set()

    # Exact matches first (case-insensitive)
    for det in detected_names:
        det_lower = det.lower().strip()
        for cfg in config_room_types:
            if cfg.lower().strip() == det_lower and cfg not in used_config:
                matched[det] = cfg
                used_config.add(cfg)
                break

    # Fuzzy match for remaining
    remaining_detected = [d for d in detected_names if d not in matched]
    remaining_config = [c for c in config_room_types if c not in used_config]

    for det in remaining_detected:
        best_match = None
        best_score = 0.0
        for cfg in remaining_config:
            score = difflib.SequenceMatcher(None, det.lower(), cfg.lower()).ratio()
            if score > best_score and score >= 0.55:
                best_score = score
                best_match = cfg
        if best_match:
            matched[det] = best_match
            remaining_config.remove(best_match)

    # Unmatched detected rooms keep their original name
    for det in detected_names:
        if det not in matched:
            matched[det] = det

    return matched


def _build_ota_name_map(otas: list, vae_mappings: dict) -> dict:
    """
    Build a mapping from VAE domain-based names to OTA Guard display names.
    e.g., 'goibibo_com' → 'Goibibo', 'www_airbnb_fr' → 'Airbnb'

    Priority: domain_display (generic names) first, then config-based
    matching for domains not in the generic list.  This prevents a VAE
    key like ``www_airbnb_fr`` from being mapped to a room-specific
    config entry such as "Airbnb Deluxe Double Room with Balcony" when
    multiple Airbnb config entries exist.
    """
    result = {}

    # 1) Generic domain → display name (takes priority)
    domain_display = {
        "goibibo": "Goibibo",
        "makemytrip": "MakeMyTrip",
        "agoda": "Agoda",
        "expedia": "Expedia",
        "airbnb": "Airbnb",
        "booking": "Booking.com",
        "google": "Google Hotels",
        "hotels": "Hotels.com",
        "trivago": "Trivago",
        "kayak": "Kayak",
        "tripadvisor": "TripAdvisor",
        "traveloka": "Traveloka",
        "trip": "Trip.com",
    }

    for vae_key in vae_mappings:
        for domain, display in domain_display.items():
            if domain in vae_key.lower():
                result[vae_key] = display
                break

    # 2) Config-based matching for VAE keys not yet mapped
    for ota in otas:
        name = ota.get("name", "")
        source_id = ota.get("source_id", "")
        url = ota.get("url", ota.get("full_url", "")).lower()

        for vae_key in vae_mappings:
            if vae_key in result:
                continue  # already mapped by domain_display
            vae_key_lower = vae_key.replace("_", ".").lower()
            domain_parts = source_id.lower().split(".")
            if any(part in vae_key_lower for part in domain_parts if len(part) > 3):
                result[vae_key] = name
                break
            if url and any(part in vae_key_lower for part in url.split(".") if len(part) > 3):
                result[vae_key] = name
                break

    # 3) Last resort: clean up the key
    for vae_key in vae_mappings:
        if vae_key not in result:
            clean = vae_key.replace("www_", "").replace("_com", "").replace("_fr", "")
            result[vae_key] = clean.replace("_", " ").title()

    return result


def start_vae_listener():
    """
    Start the VAE passive listener in a background thread.
    This connects to Brave/Chrome via CDP and captures API responses.
    Should be called once at application startup.
    """
    import asyncio
    import threading
    import logging

    _log = logging.getLogger("vae_bridge")

    def _run_listener():
        try:
            from vae.src.api.api_analyzer import main as analyzer_main
            asyncio.run(analyzer_main())
        except Exception as e:
            # Log it — a silent death here means Brave is never launched
            # and the whole listening mode is dead without any trace.
            _log.exception("VAE listener crashed: %s", e)

    thread = threading.Thread(target=_run_listener, daemon=True, name="vae-listener")
    thread.start()
    return thread


def generate_mappings():
    """
    Run the auto-mapping generator to create/update YAML mappings
    from captured data. Should be called when new OTA data is captured.
    """
    try:
        from vae.src.extractors.auto_mapping_generator import AutoMappingGenerator
        generator = AutoMappingGenerator()
        generator.run()
    except Exception as e:
        print(f"[VAE_BRIDGE] Auto-mapping error: {e}")


# ── OTA lifecycle: adding wires everything, removing cleans everything ──────

def _lifecycle_profile_ids(config: dict) -> set:
    """OTA ids that must SURVIVE a cleanup: one per configured profile
    (active or not — a deactivated OTA keeps its data), plus the shared
    stores and the generic 'airbnb' profile used by per-listing setups."""
    from core.calib_store import _normalize_ota_id, _safe_ota_id
    keep = set()
    ow = config.get("ota_watch", {}) or {}
    for o in (ow.get("otas") or []):
        name = (o.get("name") or "").strip()
        if name:
            keep.add(_safe_ota_id(_normalize_ota_id(name)))
    ref = (ow.get("reference") or {})
    if (ref.get("name") or "").strip():
        keep.add(_safe_ota_id(_normalize_ota_id(ref.get("name"))))
    keep.add("shared")
    if any(k.startswith("airbnb") for k in keep):
        keep.add("airbnb")       # generic profile: home of the listing mapping
    return keep


def _lifecycle_domain_tokens(config: dict) -> set:
    """URL domain tokens of every configured OTA (active or not)."""
    tokens = set()
    ow = config.get("ota_watch", {}) or {}
    entries = list(ow.get("otas") or [])
    if (ow.get("reference") or {}).get("url"):
        entries.append(ow["reference"])
    for o in entries:
        url = ((o.get("url") or "").lower() or "").strip()
        if not url.startswith("http"):
            continue
        host = url.split("//", 1)[-1].split("/")[0].replace(".", "_")
        if host.startswith("www_"):
            host = host[4:]
        if host:
            tokens.add(host)

    # D121-generalized: each configured OTA's brand protects the captures
    # of ALL its domain variants (.com/.fr/.co.in...).
    for _t in list(tokens):
        _b = _brand_of(_t)
        if _b:
            tokens.add(_b)
    # D33: the Channel Manager EXTRANET is not a monitored OTA,
    # but its captures (OTASheet grid, AddBulkUpdate POST proofs)
    # must survive the purge. On 08/27, every scan wiped the WHOLE
    # CM history (the 12 real POSTs of 3 pm destroyed at the 16:12
    # restart): the channelmanager_com_au domain matched no token.
    def _add_host(url_or_host):
        u = ((url_or_host or "").lower() or "").strip()
        if not u:
            return
        if "://" in u:
            u = u.split("://", 1)[-1].split("/")[0]
        host = u.split("/")[0].replace(".", "_")
        if host.startswith("www_"):
            host = host[4:]
        if not host:
            return
        tokens.add(host)
        # app.channelmanager.com.au → ALSO protect the form without the
        # subdomain (the captures are labeled without it). A single
        # level, and only if ≥4 labels, so we never fall back on
        # a generic token like com_au.
        parts = host.split("_")
        if len(parts) >= 4:
            tokens.add("_".join(parts[1:]))

    cm_cfg = config.get("channel_manager", {}) or {}
    for _k in ("endpoint", "api_url"):
        _add_host(cm_cfg.get(_k))
    try:
        from extranet_bridge import active_cm_map   # lazy import: no
        import yaml as _yaml                        # import cycle for the
        from pathlib import Path as _P              # module (bridge → vae2)
        _map = _yaml.safe_load(_P(active_cm_map(config)).read_text(
            encoding="utf-8")) or {}
        _add_host("https://" + str(_map.get("extranet") or ""))
    except Exception:
        pass
    # D128 — the CM's LEARNED addresses are protected exactly like the
    # card's: after a provider move (14/10: update247.cloud), the grid
    # captures and POST proofs land under the NEW domain and must
    # survive this very purge or the proof history is wiped on the
    # first scan (same trap as D33-b).
    try:
        from business import cm_sites as _cms
        for _h in _cms.all_hosts():
            _add_host("https://" + str(_h))
    except Exception:
        pass
    return tokens


def _capture_retention_days(config: dict) -> int:
    """Capture retention duration (D105-3). Configurable via config
    ("capture_retention_days", root); default 14 d: beyond that, a
    capture no longer serves the CM scan (grid = hours) nor the Airbnb
    reads (recent pages); the learning history lives in
    send_history, the legal ledger in evidence/ — never in the
    captures."""
    try:
        v = int(float((config or {}).get("capture_retention_days") or 14))
        return max(1, min(365, v))
    except (TypeError, ValueError):
        return 14


def capture_retention_cleanup(config: dict, cancel_cb=None) -> int:
    """D105-3 — purges the captures OLDER than the retention.

    The api_discovery folder doubled every 2 days on the client side (231k
    files on 10/09): unbounded, it ends up choking the disk AND
    slowing every scan. The capture date is IN the file name
    (YYYYMMDD_HHMMSS…): decision by name = ZERO stat() call = no
    race with the scan (lesson D102). The meta + _body pairs go
    together. Fail-safe: an error on one file is ignored, never
    propagated. D107: cancel_cb → ScanCancelled to cut the purge
    (large client folder). Returns the number of deleted files."""
    import re as _re3
    import time as _time
    removed = 0
    try:
        from vae import config as _vcfg
        _cutoff = time.strftime(
            "%Y%m%d%H%M%S", time.localtime(
                _time.time() - _capture_retention_days(config) * 86400.0))
        _pat = _re3.compile(r"^(\d{8}_\d{6})")
        for f in list(_vcfg.DATA_DIR.glob("*.json")):
            # D107: STOP = STOP — even in the middle of a purge of thousands
            # of files, the ⏹ cuts at the next file.
            if cancel_cb:
                try:
                    if cancel_cb():
                        raise ScanCancelled()
                except ScanCancelled:
                    raise
                except Exception:
                    pass
            m = _pat.match(f.name)
            if not m or m.group(1) >= _cutoff:
                continue
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
    except ScanCancelled:
        raise                     # D107: the stop goes through, it is not an error
    except Exception:
        pass
    return removed


def ota_lifecycle_cleanup(config: dict, cancel_cb=None) -> dict:
    """Purge EVERYTHING belonging to OTAs that are no longer configured.

    Commercial-product requirement (user report 2026-08-16): removing an
    OTA must leave zero trace — no ghost in the scan bar, no orphan file.
    Deleted for domains/ids matching no configured profile (deactivated
    profiles KEEP their data — only removed ones are cleaned):
      - network captures (meta + body) in vae/data/api_discovery/
      - auto-generated YAML mappings in vae/config/ota_mappings/
      - calibration_data_<id>.json / send_history_<id>.json
    Backups (.bak, *_bak) are never touched. Returns a {kind: count}
    summary for logging. Fail-safe: any error aborts the cleanup, never
    the scan."""
    summary = {"captures": 0, "mappings": 0, "calibration": 0, "history": 0}
    # D107 (incident 10/11): a config with NO declared OTA must
    # NEVER trigger a purge — the CM tokens (D33 protection) made
    # the old "empty tokens" guard dead, and a scan started with an empty
    # trial config actually deleted the calibrations/histories of the
    # data folder. Zero configured OTA = nothing to clean, period.
    _ow_cfg = (config or {}).get("ota_watch", {}) or {}
    if not (_ow_cfg.get("otas") or _ow_cfg.get("reference")):
        return summary
    # D107: STOP = STOP — tested in EVERY file loop.
    def _stop_now() -> bool:
        if not cancel_cb:
            return False
        try:
            return bool(cancel_cb())
        except Exception:
            return False
    try:
        import re as _re2
        from vae import config as _vcfg
        tokens = _lifecycle_domain_tokens(config)
        if not tokens:
            return summary          # no configured OTA: clean nothing (safety)

        # 1) Captures: <timestamp>_<domain>.json (+ _body.json)
        _dom_re = _re2.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+?)_body\.json$|"
                               r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        for f in list(_vcfg.DATA_DIR.glob("*.json")):
            if _stop_now():
                raise ScanCancelled()
            m = _dom_re.match(f.name)
            if not m:
                continue
            domain = m.group(1) or m.group(2)
            if domain and not any(t in domain for t in tokens):
                try:
                    f.unlink()
                    summary["captures"] += 1
                except OSError:
                    pass

        # 2) Auto-generated mappings
        for f in list(_vcfg.get_mappings_dir().glob("*.yaml")):
            if _stop_now():
                raise ScanCancelled()
            stem = f.stem
            if not any(t in stem for t in tokens):
                try:
                    f.unlink()
                    summary["mappings"] += 1
                except OSError:
                    pass

        # 3) Per-OTA stores in the app data dir
        from core.paths import DATA_DIR as _APP_DATA
        keep = _lifecycle_profile_ids(config)
        import re as _re3
        for f in list(_APP_DATA.glob("calibration_data_*.json")):
            m = _re3.match(r"^calibration_data_(.+)\.json$", f.name)
            if m and m.group(1) not in keep:
                try:
                    f.unlink()
                    summary["calibration"] += 1
                except OSError:
                    pass
        for f in list(_APP_DATA.glob("send_history_*.json")):
            m = _re3.match(r"^send_history_(.+)\.json$", f.name)
            if m and m.group(1) not in keep:
                try:
                    f.unlink()
                    summary["history"] += 1
                except OSError:
                    pass
    except ScanCancelled:
        raise                 # D107: the stop goes through (caught in vae_scan)
    except Exception as e:
        print(f"[VAE_BRIDGE] cleanup OTA: {e}", flush=True)
    return summary


def ota_lifecycle_wire_new(config: dict) -> list:
    """Auto-wire newly added OTAs: for every CONFIGURED domain that has
    captures but no YAML mapping yet, generate the missing mapping — and
    only the missing ones. Known-good mappings of existing OTAs are never
    rewritten (auto-regeneration over a working mapping is how a healthy
    OTA suddenly returns no prices). Returns the wired domain list."""
    wired = []
    try:
        import re as _re2
        from vae import config as _vcfg
        from vae.src.extractors.auto_mapping_generator import AutoMappingGenerator
        tokens = _lifecycle_domain_tokens(config)
        if not tokens:
            return wired
        gen = AutoMappingGenerator()
        _dom_re = _re2.compile(r"^\d{8}_\d{6}(?:_\d{6})?_(.+)\.json$")
        # Actual capture domains (e.g. 'www_airbnb_fr') for each configured
        # token — mapping files are named after THEM, not the URL token.
        domains = {}
        for f in _vcfg.DATA_DIR.glob("*.json"):
            if f.name.endswith("_body.json"):
                continue
            m = _dom_re.match(f.name)
            if not m:
                continue
            dom = m.group(1)
            if any(t in dom for t in tokens):
                domains.setdefault(dom, []).append(f)
        _mapping_brands = {_brand_of(f.name)
                           for f in _vcfg.get_mappings_dir().glob("*.yaml")}
        for dom, files in sorted(domains.items()):
            if (_vcfg.get_mappings_dir() / f"{dom}.yaml").exists():
                continue
            # D121-generalized: one single mapping per BRAND — never
            # generate a duplicate of another domain variant.
            _db = _brand_of(dom)
            if _db and _db in _mapping_brands:
                continue
            files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            mapping = gen.analyze_ota(files)
            if not mapping:
                continue
            out = _vcfg.get_mappings_dir() / f"{dom}.yaml"
            with open(out, "w", encoding="utf-8") as fh:
                fh.write(gen.generate_yaml(dom, mapping))
            wired.append(dom)
            print(f"[VAE_BRIDGE] OTA auto-wired: {dom}", flush=True)
    except Exception as e:
        print(f"[VAE_BRIDGE] wire OTA: {e}", flush=True)
    return wired


def sync_config_from_otaguard(config: dict):
    """
    Synchronize OTA Guard's config.json → VAE's hotel.yaml and settings.
    Called at startup to keep VAE's hotel identity and target currency
    in sync with OTA Guard's configuration.

    Args:
        config: OTA Guard's config dict (from core.config.load())
    """
    import yaml as _yaml

    # D128: startup pass — learn a CM address change straight from the
    # owner's own browsing since the last run (passive, bounded).
    try:
        _learned = learn_cm_sites_from_captures()
        if _learned:
            print(f"[VAE_BRIDGE] CM address learned from captures: "
                  f"{', '.join(_learned)}")
    except Exception:
        pass

    _VAE_CONFIG_DIR = _VAE_ROOT / "config"
    _VAE_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # --- Sync hotel.yaml ---
    hotel_data = {
        "hotel": {
            "name": config.get("hotel_name", ""),
            "aliases": [],
            "ota_ids": {},
            "unique_keywords": [],
            "location": {
                "city": config.get("hotel_city", ""),
                "country": config.get("hotel_country", ""),
            },
            "settings": {
                "default_nights": config.get("hotel_nights", 1),
                "default_adults": config.get("hotel_adults", 2),
                "default_currency": config.get("hotel_currency", "INR"),
            },
        }
    }

    # Extract OTA IDs from ota_watch config
    for ota in config.get("ota_watch", {}).get("otas", []):
        source_id = ota.get("source_id", "")
        # Map OTA Guard source_ids to VAE OTA keys
        ota_key_map = {
            "booking": "booking", "expedia": "expedia", "agoda": "agoda",
            "airbnb": "airbnb", "makemytrip": "makemytrip",
            "goibibo": "goibibo", "google_hotels": "google",
            "hotels_com": "hotels_com", "trivago": "trivago",
        }
        key = ota_key_map.get(source_id, source_id)
        # Try to extract ID from URL
        url = ota.get("url", "")
        if key and url:
            hotel_data["hotel"]["ota_ids"][key] = None  # Will be auto-detected

    # Write hotel.yaml
    hotel_file = _VAE_CONFIG_DIR / "hotel.yaml"
    with open(hotel_file, "w", encoding="utf-8") as f:
        _yaml.dump(hotel_data, f, allow_unicode=True, default_flow_style=False)

    # --- Sync target currency ---
    target_currency = config.get("hotel_currency", "INR")
    try:
        from vae.config import set_target_currency
        set_target_currency(target_currency)
    except Exception:
        pass

    # Also update settings.yaml
    settings_file = _VAE_CONFIG_DIR / "settings.yaml"
    if settings_file.exists():
        try:
            with open(settings_file, "r", encoding="utf-8") as f:
                settings = _yaml.safe_load(f) or {}
            settings["target_currency"] = target_currency
            with open(settings_file, "w", encoding="utf-8") as f:
                _yaml.dump(settings, f, allow_unicode=True, default_flow_style=False)
        except Exception:
            pass

    print(f"[VAE_BRIDGE] Config synced: hotel='{hotel_data['hotel']['name']}', "
          f"currency={target_currency}")
