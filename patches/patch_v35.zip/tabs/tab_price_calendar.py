"""
Tab: 📅 Seasonal rates — annual price agenda.

The user defines prices per room and per OTA for specific
periods (Christmas, events…).  Events can be recurring
(repeat every year) or one-off.  Locked events are protected:
the "Push & Correct" button (D+N days) skips them entirely.
"""
import calendar as _cal
from copy import deepcopy
import logging
import threading
import tkinter as tk
from datetime import date, datetime, timedelta
from tkinter import ttk, messagebox, simpledialog

from core.theme import T
from core.widgets import lbl, btn, entry, section, scrolled_frame, tooltip
from core.utils import tr_
from core import config as cfg
from core.base_tab import BaseTab
from diagnostic import usage as _usage

from business.price_calendar import (
    resolve_event_dates,
    get_locked_dates,
)

_log = logging.getLogger(__name__)

_EVENT_COLORS = [
    "#f38ba8", "#fab387", "#a6e3a1", "#89b4fa",
    "#cba6f7", "#f9e2af", "#94e2d5", "#eba0ac",
]

_MONTHS_FR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _currency_symbol(config):
    """Return the currency symbol from config (same logic as other tabs)."""
    try:
        from core.utils import get_currency_symbol
        return get_currency_symbol(config)
    except Exception:
        return config.get("hotel_currency", "INR") + " "


def _room_types(config):
    """Canonical room-type list (handles str and dict entries)."""
    return [r if isinstance(r, str) else r.get("type", "")
            for r in config.get("room_types", [])
            if (r if isinstance(r, str) else r.get("type", ""))
            and (r if isinstance(r, str) else r.get("type", "")).lower() != "move room"]


def _ota_identity(name):
    """One seasonal price column per OTA, including unified Airbnb listings."""
    normalized = (name or "").strip().casefold()
    if normalized == "airbnb" or normalized.startswith(("airbnb ", "airbnb #")):
        return "airbnb"
    return normalized


def _seen_otas(config):
    """Build {ota_name: ota_code} from room_mapping + OTA Watch active OTAs."""
    mapping = config.get("channel_manager", {}).get("room_mapping", {})
    seen = {}
    identities = set()
    for rm_data in mapping.values():
        if isinstance(rm_data, dict):
            for rp in rm_data.get("rate_plans", []):
                name = (rp.get("ota_name") or "").strip()
                code = str(rp.get("ota_code") or "").strip()
                identity = _ota_identity(name)
                if identity and identity not in identities:
                    seen[name] = code
                    identities.add(identity)
    # Merge OTA Watch active OTAs
    for o in config.get("ota_watch", {}).get("otas", []):
        if not o.get("active", True):
            continue
        name = (o.get("name") or "").strip()
        identity = _ota_identity(name)
        if not identity or identity in identities:
            continue
        seen[name] = ""
        identities.add(identity)
    return seen


class Tab(BaseTab):

    def build(self, app, frame):
        self.app = app
        self._csym = _currency_symbol(app.config)
        self._event_vars = []   # list of dicts with tk vars for each event card
        self._timeline_frame = None
        self._verify_running = False   # D67: anticipated verification running?

        # ── Top bar ──────────────────────────────────────────────────
        topbar = tk.Frame(frame, bg=T.SEL_BG, pady=6, padx=10)
        topbar.pack(fill="x", side="top")

        lbl(topbar, "📅 " + tr_("Seasonal rates"),
            bold=True, size=11, color=T.ACCENT).pack(side="left")
        btn(topbar, tr_("📖 Wiki"),
            lambda: self._show_wiki('📅 Tarifs saisonniers'), color="#89b4fa", width=10).pack(side="right")

        # D83-bis: FLASH green (pulsing) — the button used to be a discrete
        # blue and went unnoticed (owner report 21/09).
        _save_btn = btn(topbar, tr_("💾 Save"), self._save,
                        color="#22c55e", width=16)
        tooltip(
            _save_btn,
            tr_("SAVE all events (names, dates, prices, options ⚙️). Click BEFORE changing menu.")
        ).pack(side="right", padx=(4, 0))

        def _pulse(_step=[0]):
            try:
                if not _save_btn.winfo_exists():
                    return
                _step[0] += 1
                _save_btn.configure(
                    bg="#a6e3a1" if _step[0] % 2 else "#22c55e")
                topbar.after(900, _pulse)
            except Exception:
                pass
        _pulse()

        tooltip(
            btn(topbar, tr_("📤 Push locked prices"),
                self._push_locked_prices, color=T.GREEN, width=26),
            tr_("Sends the prices of all active locked events to the Channel Manager.")
        ).pack(side="right", padx=(4, 0))

        tooltip(
            btn(topbar, tr_("➕ Add an event"),
                self._add_event, color="#cba6f7", width=22),
            tr_("Creates a new seasonal event.")
        ).pack(side="right", padx=(4, 0))

        # ── Scrollable body ──────────────────────────────────────────
        outer, inner = scrolled_frame(frame)
        outer.pack(fill="both", expand=True)
        self._inner = inner

        # Timeline section
        self._timeline_section = tk.Frame(inner, bg=T.BG)
        self._timeline_section.pack(fill="x", padx=10, pady=(8, 4))

        # Events section
        self._events_section = tk.Frame(inner, bg=T.BG)
        self._events_section.pack(fill="x", padx=10, pady=(4, 8))

        # Verification section (D67)
        self._verify_section = tk.Frame(inner, bg=T.BG)
        self._verify_section.pack(fill="x", padx=10, pady=(4, 8))

        self._build_all()

    # ── refresh on tab show ─────────────────────────────────────────

    def refresh_on_show(self):
        """Rebuild timeline (dates advance) + sync room/OTA lists."""
        try:
            self._csym = _currency_symbol(self.app.config)
            for w in self._timeline_section.winfo_children():
                w.destroy()
            for w in self._events_section.winfo_children():
                w.destroy()
            self._build_all()
        except Exception:
            _log.exception("refresh_on_show (tab_price_calendar)")

    # ── build everything ────────────────────────────────────────────

    def _build_all(self):
        self._build_timeline()
        self._build_events()
        self._build_verify()

    # ── Displayed-price verification (D67) ───────────────────────────

    def _build_verify(self):
        try:
            import business.seasonal_verify as sv
        except Exception:
            _log.exception("import seasonal_verify")
            return
        for w in self._verify_section.winfo_children():
            w.destroy()
        s = section(self._verify_section,
                    tr_("🔍 Displayed-price verification"))
        s.pack(fill="x")

        cfg = self.app.config
        actifs = sv.active_locked_events(cfg)
        # ALL future locked events: the owner must be able to test the
        # anticipated verification whenever he wants, not only 30 days
        # before the event (19/09).
        futurs = sv.upcoming_locked_events(cfg, horizon_days=3650)
        head = tk.Frame(s, bg=T.BG)
        head.pack(fill="x")
        # IMMEDIATE visual feedback (the owner must see the click did
        # something): timestamp of the last report
        self._verify_status = tk.Label(head, text="", bg=T.BG,
                                       fg=T.GREEN, font=("Segoe UI", 8))
        self._verify_status.pack(side="right", padx=(0, 8))
        tooltip(
            btn(head, tr_("🔄 Recompile report"), self._verify_now,
                color="#cba6f7", width=22),
            tr_("Does NOT re-read anything on the OTAs: recompiles the report from data ALREADY read (hence “nothing changes” if no new read). To RE-READ prices at an event's dates: the event's 🔍 button below.")
        ).pack(side="right")

        def _open_reports():
            try:
                import os
                import business.seasonal_verify as _sv
                os.startfile(str(_sv.report_dir()))
            except Exception:
                _log.exception("open seasonal reports folder")

        def _open_evidence():
            try:
                import os
                from business import legal_ledger as _ll
                os.startfile(str(_ll.evidence_dir()))
            except Exception:
                _log.exception("open evidence dir")

        tooltip(
            btn(head, tr_("⚖ Evidence"), _open_evidence,
                color="#a6e3a1", width=10),
            tr_("Legal evidence journal: every price read and every push (with POST proof), append-only register never erased — evidence folder.")
        ).pack(side="right", padx=(0, 6))

        tooltip(
            btn(head, tr_("📁 Reports"), _open_reports,
                color="#89b4fa", width=12),
            tr_("Opens the verification reports folder (readable .txt files: room × OTA × date, displayed vs locked price).")
        ).pack(side="right", padx=(0, 6))
        lbl(head, tr_("Read-only — nothing is sent."),
            color="#888888", size=8).pack(side="right", padx=(0, 10))

        # auto: refresh if the report is older than 7 days
        try:
            if sv.is_stale(cfg):
                self._verify_now(silent=True)
        except Exception:
            _log.exception("auto-verify seasonal")

        box = tk.Frame(s, bg=T.BG)
        box.pack(fill="x", pady=(4, 0))
        self._verify_txt = tk.Text(box, height=min(12, 3 + len(actifs) * 3),
                                   bg=T.ENTRY_BG, fg=T.FG, relief="flat",
                                   font=("Consolas", 9), state="disabled",
                                   wrap="word")
        self._verify_txt.pack(fill="x")
        for tag, coul in (("ok", T.GREEN), ("warn", T.ORANGE),
                          ("err", T.RED), ("mut", "#888888"),
                          ("tit", T.ACCENT)):
            self._verify_txt.tag_config(tag, foreground=coul)
        # PERSISTANT container of the future-event buttons: _render_verify
        # populates it, but it has no access to the local `s` frame
        # (NameError bug of 20/09 — the whole tab crashed).
        self._verify_future_box = tk.Frame(s, bg=T.BG)
        self._verify_future_box.pack(fill="x", pady=(6, 0))
        self._render_verify()

    def _verify_now(self, silent=False):
        """Compare (read-only) displayed prices to locked prices.
        Immediate visible feedback: timestamp + event count."""
        try:
            import business.seasonal_verify as sv
        except Exception:
            _log.exception("import seasonal_verify")
            return
        rep = sv.build_report(self.app.config)
        path = None
        try:
            path = sv.write_report_file(
                self.app.config, rep,
                source=tr_("current scan (stay shown today)"))
        except Exception:
            _log.exception("write seasonal report file")
        sv.save_report(self.app.config, rep, report_file=path)
        try:
            from datetime import datetime as _dt
            if hasattr(self, "_verify_status"):
                n_act = len(rep.get("events", []))
                self._verify_status.configure(
                    text=tr_("✔ recompiled at {h} — reuses the LATEST data already read ({n} active event). To RE-READ prices on the OTAs: the event's 🔍 button.")
                    .format(
                        h=_dt.now().strftime("%H:%M:%S"), n=n_act))
        except Exception:
            pass
        if not silent:
            self._render_verify()

    def _render_verify(self):
        try:
            import business.seasonal_verify as sv
            from datetime import date as _date
        except Exception:
            return
        txt = getattr(self, "_verify_txt", None)
        if txt is None:
            return
        cfg = self.app.config
        rep = sv.build_report(cfg)
        actifs = sv.active_locked_events(cfg)
        # same wide horizon as _build_verify (ALL future locked events —
        # 19/09: the owner tests whenever he wants)
        futurs = sv.upcoming_locked_events(cfg, horizon_days=3650)
        txt.configure(state="normal")
        txt.delete("1.0", "end")

        n_lines = [0]

        def w(t, tag=None):
            n_lines[0] += 1
            txt.insert("end", t + "\n", (tag,) if tag else ())

        if not actifs and not futurs:
            w(tr_("No locked event running or upcoming."),
              "mut")
            w(tr_("Create a locked event above: its verification will start automatically at its dates."), "mut")
        for ev_out in rep.get("events", []):
            w(f"📌 {ev_out['name']}  ({ev_out['dates']})", "tit")
            if not ev_out["entries"]:
                w(tr_("   No displayed price available — run an OTA scan first."), "mut")
            for e in ev_out["entries"]:
                if e["ok"]:
                    w(tr_("   ✅ {ota} · {room}: displayed {d:,.0f} ≈ locked {p:,.0f}").format(
                        ota=e["ota"], room=e["room"],
                        d=e["displayed"], p=e["expected"]), "ok")
                else:
                    w(tr_("   ⚠️ {ota} · {room}: displayed {d:,.0f} ≠ locked {p:,.0f} (gap {drift:+,.0f})")
                      .format(ota=e["ota"], room=e["room"],
                              d=e["displayed"], p=e["expected"],
                              drift=e["drift"]), "err")
        if rep.get("drifts"):
            w(tr_("→ Drifts detected: fix with « 📤 Push locked prices » then re-scan to re-verify."), "warn")
        for ev, start, end in futurs:
            w(tr_("⏳ Upcoming: {name} ({d}) — verification activates at its dates.").format(
                name=ev.get("name") or "Event",
                d=start.isoformat()), "mut")
        if actifs:
            w(tr_("Last verification: {d}").format(
                d=sv.last_verify(cfg) or "—"), "mut")

        # ── full report VISIBLE IN THE APP (20/09, owner order): the last
        #    persisted detailed report (🔍 or 🔄 button) is re-rendered
        #    here, night by night, with the same lines as the .txt file ──
        try:
            env = sv.load_last_report(cfg)
        except Exception:
            _log.exception("load last seasonal report")
            env = None
        if env:
            gen = str(env.get("generated") or "")[:16].replace("T", " ")
            w("")
            w(tr_("📋 Last full report{g}:").format(
                g=tr_(" (generated {d})").format(d=gen) if gen else ""),
              "tit")
            src = str(env.get("source") or "").strip()
            if src:
                w(tr_("   source: {s}").format(s=src), "mut")
            for line, tag in sv.report_tagged_lines(env.get("report")
                                                    or {}):
                w(line, tag)
            lastf = str(((cfg.get("price_calendar", {}) or {})
                         .get("verify") or {}).get("last_file") or "")
            if lastf:
                w(tr_("📁 Report file: {p}").format(p=lastf),
                  "mut")
        txt.configure(state="disabled")
        try:
            txt.configure(height=min(30, max(8, n_lines[0])))
        except Exception:
            pass

        # anticipated verification of future events (phase 2, D67):
        # brings each OTA tab to the event dates, reads, brings back.
        # Always in the persistent container (never `s` which does not
        # exist here) and protected: a rendering error must NEVER kill
        # the whole tab (lesson of 20/09).
        try:
            import business.seasonal_nav as _snav
        except Exception:
            _snav = None
        box_fut = getattr(self, "_verify_future_box", None)
        if box_fut is not None:
            for wid in box_fut.winfo_children():
                wid.destroy()
        if _snav and futurs and box_fut is not None:
            lbl(box_fut, tr_("Anticipated verification (moves the OTA tabs to the event dates, read-only):"),
                color="#888888", size=8).pack(side="left")
            for ev, start, end in futurs:
                nm = (ev.get("name") or tr_("Event"))[:14]
                if self._verify_running:
                    # NEVER hidden (20/09: "the button disappeared"):
                    # during a test it stays visible, disabled.
                    b = btn(box_fut, tr_("⏳ {name}…").format(name=nm),
                            lambda: None, color="#f9e2af", width=18)
                    try:
                        b.configure(state="disabled")
                    except Exception:
                        pass
                    tooltip(b, tr_("Verification running — follow the live readings in the report above."))
                    b.pack(side="left", padx=4)
                    continue
                btn(box_fut, tr_("🔍 {name}").format(name=nm),
                    lambda e=ev: self._verify_future(e),
                    color="#cba6f7", width=18).pack(side="left", padx=4)
                tooltip(
                    btn(box_fut, tr_("🛠 Correct"),
                        lambda e=ev: self._correct_future(e),
                        color=T.ORANGE, width=10),
                    tr_("Full loop: reads prices, computes the compensated send (CM price × target ÷ displayed), pushes to the CM, waits, re-checks. Dry run offered BEFORE any send.")).pack(
                    side="left", padx=(0, 8))

    def _verify_future(self, event):
        import business.seasonal_nav as snav
        from datetime import date as _date
        from business.price_calendar import resolve_event_dates
        start, end = resolve_event_dates(event, _date.today())
        if start is None:
            return
        if end < start:
            end = start
        if self._verify_running:
            return
        # Real parameters announced BEFORE any action (owner rule)
        n_nuits = (end - start).days + 1
        otas_ok = 0
        for prof in ((self.app.config.get("ota_watch", {}) or {})
                     .get("otas") or []):
            nm = (prof.get("name") or "").strip()
            if (nm and not nm.lower().startswith("airbnb")
                    and snav.dated_url(prof.get("url") or "", start)):
                otas_ok += 1
        est_min = max(1, round(n_nuits * max(1, otas_ok) * 0.8))
        if not messagebox.askyesno(
                tr_("Anticipated verification"),
                tr_("Take the OTA tabs to the dates of “{name}” ({d} → {e}) to read the displayed prices?\n\n• The WHOLE period will be checked: {n} night(s), one by one.\n• {o} OTA(s) controllable by URL (open tab required, Airbnb excluded).\n• Each tab will be navigated night after night THEN returned to its page.\n• Read-only: NO price is sent.\n• Estimated duration: ~{m} min.\n• A full report will be written (seasonal_reports folder).\n\nStart the verification?").format(
                    name=event.get("name") or "Event",
                    d=start.isoformat(), e=end.isoformat(),
                    n=n_nuits, o=otas_ok, m=est_min),
                parent=self.app.root):
            return
        self._verify_running = True
        # DIRECT mode: the report area becomes the live screen of the
        # test — the owner SEES every night read and every price during
        # the ~12 min (before: everything went to the journal only).
        self._verify_txt.configure(state="normal")
        self._verify_txt.delete("1.0", "end")
        self._verify_txt.insert(
            "end", tr_("⏳ Verification running — what the software reads is shown here live:\n"), ("tit",))
        self._verify_txt.configure(state="disabled")
        self._verify_txt.see("end")

        def _log(m):
            try:
                self.app._log_journal(f"📅 [Seasons] {m}",
                                      engine="SEASONAL")
            except Exception:
                pass

        def _ui_line(msg, tag=None):
            """Live line in the report area (thread-safe)."""
            def _ins():
                try:
                    t = self._verify_txt
                    t.configure(state="normal")
                    t.insert("end", msg + "\n", (tag,) if tag else ())
                    t.see("end")
                    t.configure(state="disabled")
                except Exception:
                    pass
            try:
                self.app.root.after(0, _ins)
            except RuntimeError:
                pass

        def _done(rep):
            def _ui():
                self._verify_running = False
                if rep is None:
                    _log("verification cancelled or impossible")
                else:
                    path = None
                    try:
                        import business.seasonal_verify as sv
                        path = sv.write_report_file(
                            self.app.config, rep,
                            source=tr_("advance verification — OTA tabs taken to the event dates"))
                        sv.save_report(self.app.config, rep,
                                       report_file=path)
                    except Exception:
                        _log("⚠️ could not write the report file")
                    # the full detail is rendered by _render_verify
                    # (reloaded from the persisted report) — we no longer
                    # insert here, the re-render's clear would immediately
                    # destroy it.
                    # D76: "🔁 Auto-correction" checked + drifts detected →
                    # offer THE loop (confirmation always: the auto
                    # chains, the human keeps the last word before any
                    # real send).
                    if rep.get("drifts") and event.get("auto_correct"):
                        try:
                            go = messagebox.askyesno(
                                tr_("Automatic correction"),
                                tr_("{d} drift(s) detected for “{name}”.\nStart the correction loop now?\n\n(uncheck “🔁 Auto-correction” in the card to stop being asked)").format(
                                    d=rep.get("drifts"),
                                    name=event.get("name")
                                    or tr_("Event")),
                                parent=self.app.root)
                            if go:
                                self._start_loop(event, dry=False)
                                return
                        except Exception:
                            pass
                    try:
                        from datetime import datetime as _dt
                        if hasattr(self, "_verify_status"):
                            self._verify_status.configure(
                                text=tr_("✔ verification done at {h} — {c} prices, {d} drift(s)")
                                .format(
                                    h=_dt.now().strftime("%H:%M:%S"),
                                    c=rep.get("checked", 0),
                                    d=rep.get("drifts", 0)))
                    except Exception:
                        pass
                    if path:
                        _log(f"📁 report: {path}")
                self._render_verify()
            try:
                self.app.root.after(0, _ui)
            except RuntimeError:
                self._verify_running = False

        snav.run_in_thread(self.app.config, event, on_done=_done,
                           log=_log, ui=_ui_line)

    # ── Correction loop (D76, owner GO) ─────────────────────────────

    def _start_loop(self, event, dry, only_room=None):
        """Runs business/seasonal_loop.run_correction_loop in a thread,
        live screen like for 🔍. dry=True = dry run (nothing is sent).
        only_room = limits the trial to ONE room (first real trial,
        owner protocol)."""
        import business.seasonal_loop as sloop
        if self._verify_running:
            return
        self._verify_running = True
        self._verify_txt.configure(state="normal")
        self._verify_txt.delete("1.0", "end")
        self._verify_txt.insert(
            "end", tr_("🛠 CORRECTION LOOP — {mode}\n").format(
                mode=tr_("DRY RUN (nothing is sent)") if dry
                else tr_("REAL SEND to the Channel Manager")),
            ("tit" if dry else "err",))
        self._verify_txt.configure(state="disabled")
        self._verify_txt.see("end")

        def _log(m):
            try:
                self.app._log_journal(f"📅 [Seasons] {m}",
                                      engine="SEASONAL")
            except Exception:
                pass

        def _ui_line(msg, tag=None):
            def _ins():
                try:
                    t = self._verify_txt
                    t.configure(state="normal")
                    t.insert("end", msg + "\n", (tag,) if tag else ())
                    t.see("end")
                    t.configure(state="disabled")
                except Exception:
                    pass
            try:
                self.app.root.after(0, _ins)
            except RuntimeError:
                pass

        def _done(summary):
            def _ui():
                self._verify_running = False
                if not summary:
                    _log("loop impossible")
                else:
                    try:
                        from datetime import datetime as _dt
                        icon = "✅" if summary.get("converged") else "⚠️"
                        if hasattr(self, "_verify_status"):
                            self._verify_status.configure(
                                text=tr_("{icon} loop finished at {h} — {i} round(s), {c} correction(s) computed, {p} sent")
                                .format(
                                    icon=icon,
                                    h=_dt.now().strftime("%H:%M:%S"),
                                    i=summary.get("iterations", 0),
                                    c=summary.get("corrections", 0),
                                    p=summary.get("pushed", 0)))
                    except Exception:
                        pass
                    _log(f"loop: {summary}")
                self._render_verify()
            try:
                self.app.root.after(0, _ui)
            except RuntimeError:
                self._verify_running = False

        def _work():
            summary = sloop.run_correction_loop(
                self.app.config, event, log=_log, ui=_ui_line,
                dry_run=dry, only_room=only_room)
            try:
                self.app.root.after(0, lambda: _done(summary))
            except RuntimeError:
                self._verify_running = False

        threading.Thread(target=_work, daemon=True).start()

    def _correct_future(self, event):
        import business.seasonal_loop as sloop
        from datetime import date as _date
        from business.price_calendar import resolve_event_dates
        start, end = resolve_event_dates(event, _date.today())
        if start is None or end is None:
            return
        if self._verify_running:
            return
        self._save()          # sync the tolerance/wait settings
        try:
            wm = int(event.get("wait_minutes") or 10)
        except (TypeError, ValueError):
            wm = 10
        # Owner protocol: announce the parameters + choose the mode
        # BEFORE any action. Yes = dry run, No = real.
        choice = messagebox.askyesnocancel(
            tr_("Event correction"),
            tr_("Correction loop for “{name}” ({d} → {e}):\n\n• reads the prices displayed by the OTAs night by night\n• reads the current price on the CM grid\n• computes the compensated send: CM price × target ÷ displayed\n• pushes to the CM (router), waits {w} min, re-checks\n• max 3 rounds, tolerance set in the card\n\nYES  = DRY RUN — computes everything, SENDS NOTHING\nNO   = REAL SEND to the Channel Manager\nCancel = do nothing").format(
                name=event.get("name") or tr_("Event"),
                d=start.isoformat(), e=end.isoformat(), w=wm),
            parent=self.app.root)
        if choice is None:
            return
        _log = lambda m: self.app._log_journal(
            f"📅 [Seasons] {m}", engine="SEASONAL")
        _log(f"loop started (mode {'dry run' if choice else 'REAL'}) "
             f"by the 🛠 button")
        only_room = None
        if not choice:
            # Owner protocol: the FIRST real trial is limited to one
            # room (empty field = all).
            only_room = simpledialog.askstring(
                tr_("Real test"),
                tr_("Limit this REAL test to one room?\nType the name of the room (e.g.: Double Room)\nor leave empty to correct ALL rooms:"),
                parent=self.app.root)
            if only_room is None:          # Cancel
                return
            only_room = only_room.strip() or None
        self._start_loop(event, dry=bool(choice), only_room=only_room)

    # ── Timeline ────────────────────────────────────────────────────

    def _build_timeline(self):
        events = self.app.config.get("price_calendar", {}).get("events", [])
        today = date.today()
        year = today.year

        s = section(self._timeline_section, tr_("🗓️ Annual frieze {year}").format(year=year))
        s.pack(fill="x")

        if not events:
            lbl(s, tr_("No events defined. Click “Add Event” to get started."),
                color="#888888", size=9).pack(anchor="w", pady=(4, 8))
            return

        # Canvas-based timeline: 12 months, ~30 px each = 360 px wide
        _MONTH_W = 34
        _ROW_H = 22
        _PAD = 28
        canvas_w = 12 * _MONTH_W + _PAD * 2
        canvas_h = max(60, _ROW_H * min(len(events), 6) + _ROW_H + 10)

        canvas = tk.Canvas(s, bg=T.BG, height=canvas_h,
                           scrollregion=(0, 0, canvas_w, canvas_h),
                           highlightthickness=0)
        canvas.pack(fill="x", padx=2, pady=(4, 6))

        # Month headers
        for m in range(12):
            x = _PAD + m * _MONTH_W
            canvas.create_text(x + _MONTH_W / 2, 8, text=_MONTHS_FR[m],
                               fill=T.ACCENT, font=("Segoe UI", 7, "bold"))
            # Month separator
            canvas.create_line(x, 14, x, canvas_h - 4, fill=T.SEL_BG, dash=(1, 2))

        # "Today" vertical line
        day_of_year = today.timetuple().tm_yday
        today_x = _PAD + (day_of_year / 365.0) * (12 * _MONTH_W)
        canvas.create_line(today_x, 14, today_x, canvas_h - 4,
                           fill=T.YELLOW, width=2)
        canvas.create_text(today_x, canvas_h - 2, text="▼",
                           fill=T.YELLOW, font=("Segoe UI", 6))

        # Event bars
        for i, evt in enumerate(events):
            if not evt.get("enabled", True):
                continue
            ev_start, ev_end = resolve_event_dates(evt, today)
            if ev_start is None or ev_end is None:
                continue
            # Only draw if event overlaps current year
            year_start = date(year, 1, 1)
            year_end = date(year, 12, 31)
            if ev_end < year_start or ev_start > year_end:
                continue

            # Clamp to current year
            s_clamped = max(ev_start, year_start)
            e_clamped = min(ev_end, year_end)

            s_doy = (s_clamped - year_start).days
            e_doy = (e_clamped - year_start).days + 1  # inclusive
            x1 = _PAD + (s_doy / 365.0) * (12 * _MONTH_W)
            x2 = _PAD + (e_doy / 365.0) * (12 * _MONTH_W)

            row_y = 18 + (i % 6) * _ROW_H
            color = _EVENT_COLORS[i % len(_EVENT_COLORS)]
            is_past = e_clamped < today
            bar_fill = "#555555" if is_past else color
            canvas.create_rectangle(x1, row_y, x2, row_y + _ROW_H - 4,
                                    fill=bar_fill, outline="", stipple="" if not is_past else "gray50")
            # Lock icon
            prefix = "🔒 " if evt.get("locked") else ""
            # Recurring icon
            rec = "↻ " if evt.get("recurring") else ""
            label_text = f"{rec}{prefix}{evt.get('name', '?')}"
            canvas.create_text((x1 + x2) / 2, row_y + (_ROW_H - 4) / 2,
                               text=label_text, fill="white",
                               font=("Segoe UI", 7, "bold"))

    # ── Events list ─────────────────────────────────────────────────

    def _build_events(self):
        events = self.app.config.get("price_calendar", {}).get("events", [])
        self._event_vars = []

        if not events:
            s = section(self._events_section, tr_("Events"))
            s.pack(fill="x")
            lbl(s, tr_("No events. Click “➕ Add event” at the top."),
                color="#888888", size=9).pack(anchor="w", pady=8)
            return

        room_types = _room_types(self.app.config)
        otas = _seen_otas(self.app.config)

        for i, evt in enumerate(events):
            color = _EVENT_COLORS[i % len(_EVENT_COLORS)]
            card_vars = self._build_event_card(self._events_section, evt, i, color,
                                               room_types, otas)
            self._event_vars.append(card_vars)

    def _build_event_card(self, parent, evt, idx, color, room_types, otas):
        """Build a single event card. Returns a dict of tk variables."""
        evt_id = evt.get("id", f"evt_{idx}")
        card = tk.Frame(parent, bg=T.SEL_BG, padx=10, pady=8,
                        highlightthickness=2, highlightbackground=color)
        card.pack(fill="x", pady=3)

        # ── Header row: name + delete ────────────────────────────
        hdr = tk.Frame(card, bg=T.SEL_BG); hdr.pack(fill="x", pady=(0, 4))

        tk.Label(hdr, text="●", bg=T.SEL_BG, fg=color,
                 font=("Segoe UI", 14)).pack(side="left", padx=(0, 4))

        name_v = tk.StringVar(value=evt.get("name", ""))
        tk.Entry(hdr, textvariable=name_v, bg=T.ENTRY_BG, fg=T.FG,
                 relief="flat", font=("Segoe UI", 10, "bold"), width=22
                 ).pack(side="left", padx=(0, 8))

        btn(hdr, "🗑", lambda _id=evt_id: self._delete_event(_id),
            color=T.RED, width=4).pack(side="right")

        # ── Dates row ────────────────────────────────────────────
        dr = tk.Frame(card, bg=T.SEL_BG); dr.pack(fill="x", pady=2)
        lbl(dr, tr_("Of"), bold=True, size=9).pack(side="left", padx=(0, 4))
        start_v = tk.StringVar(value=evt.get("start_date", ""))
        tk.Entry(dr, textvariable=start_v, bg=T.ENTRY_BG, fg=T.FG,
                 relief="flat", font=("Segoe UI", 9), width=12
                 ).pack(side="left", padx=(0, 8))
        lbl(dr, tr_("At"), bold=True, size=9).pack(side="left", padx=(0, 4))
        end_v = tk.StringVar(value=evt.get("end_date", ""))
        tk.Entry(dr, textvariable=end_v, bg=T.ENTRY_BG, fg=T.FG,
                 relief="flat", font=("Segoe UI", 9), width=12
                 ).pack(side="left", padx=(0, 12))

        # ── Checkboxes row ───────────────────────────────────────
        cr = tk.Frame(card, bg=T.SEL_BG); cr.pack(fill="x", pady=2)
        recurring_v = tk.BooleanVar(value=evt.get("recurring", False))
        tk.Checkbutton(cr, text=tr_("↻ Repeat every year"),
                       variable=recurring_v, bg=T.SEL_BG, fg=T.ACCENT,
                       selectcolor=T.ENTRY_BG, activebackground=T.SEL_BG,
                       activeforeground=T.ACCENT,
                       font=("Segoe UI", 9)).pack(side="left", padx=(0, 12))

        locked_v = tk.BooleanVar(value=evt.get("locked", False))
        tk.Checkbutton(cr, text=tr_("🔒 Lock (protect from D+)"),
                       variable=locked_v, bg=T.SEL_BG, fg=T.RED,
                       selectcolor=T.ENTRY_BG, activebackground=T.SEL_BG,
                       activeforeground=T.RED,
                       font=("Segoe UI", 9)).pack(side="left", padx=(0, 12))

        enabled_v = tk.BooleanVar(value=evt.get("enabled", True))
        tk.Checkbutton(cr, text=tr_("Active"),
                       variable=enabled_v, bg=T.SEL_BG, fg=T.GREEN,
                       selectcolor=T.ENTRY_BG, activebackground=T.SEL_BG,
                       activeforeground=T.GREEN,
                       font=("Segoe UI", 9)).pack(side="left")

        # ── Verification / loop options (20/09: the owner wants to SET
        #    tolerance, frequency, etc. per event) ──
        orow = tk.Frame(card, bg=T.SEL_BG); orow.pack(fill="x", pady=2)
        lbl(orow, tr_("⚙️ Tolerance ({sym})").format(sym=self._csym),
            color="#888888", size=8).pack(side="left", padx=(0, 3))
        tol_v = tk.StringVar(
            value=(str(int(evt["tolerance_amount"]))
                   if evt.get("tolerance_amount") else ""))
        tol_entry = tk.Entry(orow, textvariable=tol_v, bg=T.ENTRY_BG,
                             fg=T.ACCENT, relief="flat",
                             font=("Segoe UI", 8), width=6)
        tooltip(tol_entry,
                tr_("Maximum accepted gap between displayed and locked price, IN THE software's currency. Empty = default ±2%."))
        tol_entry.pack(side="left", padx=(0, 8))
        lbl(orow, tr_("(empty = ±2%)"), color="#888888", size=8
            ).pack(side="left", padx=(0, 12))

        lbl(orow, tr_("Re-check every (days)"), color="#888888", size=8
            ).pack(side="left", padx=(0, 3))
        freq_v = tk.StringVar(
            value=str(evt.get("verify_every_days")
                      if evt.get("verify_every_days") else 7))
        freq_entry = tk.Entry(orow, textvariable=freq_v, bg=T.ENTRY_BG,
                              fg=T.ACCENT, relief="flat",
                              font=("Segoe UI", 8), width=4)
        tooltip(freq_entry,
                tr_("Auto-refresh cadence of THIS event's verification report, in days (default 7)."))
        freq_entry.pack(side="left", padx=(0, 12))

        lbl(orow, tr_("Wait after fix (min)"), color="#888888", size=8
            ).pack(side="left", padx=(0, 3))
        wait_v = tk.StringVar(value=str(evt.get("wait_minutes", 10)))
        wait_entry = tk.Entry(orow, textvariable=wait_v, bg=T.ENTRY_BG,
                              fg=T.ACCENT, relief="flat",
                              font=("Segoe UI", 8), width=4)
        tooltip(wait_entry,
                tr_("Used by the VAE3 correction loop: wait between sending the price to the CM and re-checking on the OTA (default 10 min)."))
        wait_entry.pack(side="left", padx=(0, 12))

        autoc_v = tk.BooleanVar(value=bool(evt.get("auto_correct")))
        tk.Checkbutton(orow, text=tr_("🔁 Auto-correction (VAE3 loop)"),
                       variable=autoc_v, bg=T.SEL_BG, fg=T.ORANGE,
                       selectcolor=T.ENTRY_BG, activebackground=T.SEL_BG,
                       activeforeground=T.ORANGE,
                       font=("Segoe UI", 8)
                       ).pack(side="left")
        tooltip(orow.winfo_children()[-1],
                tr_("After a 🔍 check with drifts: the correction loop is AUTOMATICALLY offered (a confirmation is still required before any send)."))

        # ── Price table ──────────────────────────────────────────
        tk.Label(card, text=tr_("Price per room {sym}:").format(sym=self._csym),
                 bg=T.SEL_BG, fg=T.FG, font=("Segoe UI", 9, "bold")
                 ).pack(anchor="w", pady=(6, 2))

        table_f = tk.Frame(card, bg=T.SEL_BG)
        table_f.pack(fill="x")

        ota_names = sorted(otas.keys()) if otas else []
        col_names = ["Room", "_default"] + ota_names
        col_widths = [4, 2] + [2] * len(ota_names)
        for c, (cn, cw) in enumerate(zip(col_names, col_widths)):
            table_f.columnconfigure(c, weight=cw)

        # Header
        display_names = ["Room", tr_("Default")] + ota_names
        for c, dn in enumerate(display_names):
            tk.Label(table_f, text=dn, bg=T.BG, fg=T.ACCENT,
                     font=("Segoe UI", 8, "bold"), anchor="center"
                     ).grid(row=0, column=c, sticky="ew", padx=2, pady=(0, 3))

        # Room price rows
        evt_rooms = evt.get("rooms", {})
        price_vars = {}  # {room: {"_default": StringVar, ota_name: StringVar}}

        for ridx, room in enumerate(room_types, start=1):
            tk.Label(table_f, text=room, bg=T.SEL_BG, fg=T.FG,
                     font=("Segoe UI", 8), anchor="w"
                     ).grid(row=ridx, column=0, sticky="ew", padx=2, pady=1)

            room_cfg = evt_rooms.get(room, {})
            price_vars[room] = {}

            # _default column
            dv = tk.StringVar(value=str(int(room_cfg.get("_default", 0)))
                              if room_cfg.get("_default") else "")
            tk.Entry(table_f, textvariable=dv, bg=T.ENTRY_BG, fg=T.ACCENT,
                     relief="flat", font=("Segoe UI", 8, "bold"), width=8
                     ).grid(row=ridx, column=1, sticky="ew", padx=2, pady=1)
            price_vars[room]["_default"] = dv

            # Per-OTA columns
            for oc, ota_name in enumerate(ota_names, start=2):
                # Prefer the displayed CM name, then a saved OTA Watch alias.
                rv = room_cfg.get(ota_name)
                if not rv:
                    rv = next((val for k, val in room_cfg.items()
                               if _ota_identity(k) == _ota_identity(ota_name)
                               and val), None)
                ov = tk.StringVar(value=str(int(rv)) if rv else "")
                tk.Entry(table_f, textvariable=ov, bg=T.ENTRY_BG, fg=T.FG,
                         relief="flat", font=("Segoe UI", 8), width=8
                         ).grid(row=ridx, column=oc, sticky="ew", padx=2, pady=1)
                price_vars[room][ota_name] = ov

        return {
            "id":         evt_id,
            "name":       name_v,
            "start":      start_v,
            "end":        end_v,
            "recurring":  recurring_v,
            "locked":     locked_v,
            "enabled":    enabled_v,
            "prices":     price_vars,
            "tol":        tol_v,
            "freq":       freq_v,
            "wait":       wait_v,
            "autoc":      autoc_v,
        }

    # ── Add / Delete ────────────────────────────────────────────────

    def _add_event(self):
        import uuid as _uuid
        today = date.today()
        new_evt = {
            "id":         "evt_" + _uuid.uuid4().hex[:6],
            "name":       tr_("New event"),
            "start_date": today.isoformat(),
            "end_date":   (today + timedelta(days=7)).isoformat(),
            "recurring":  False,
            "locked":     False,
            "enabled":    True,
            "rooms":      {},
            # verification / loop options (D74)
            "tolerance_amount": None,
            "verify_every_days": 7,
            "wait_minutes": 10,
            "auto_correct": False,
        }
        events = self._events_from_form()
        events.append(new_evt)
        if self._persist_events(events):
            self.refresh_on_show()

    def _delete_event(self, evt_id):
        events = [e for e in self._events_from_form() if e.get("id") != evt_id]
        if self._persist_events(events):
            self.refresh_on_show()

    # ── Save ────────────────────────────────────────────────────────

    def _events_from_form(self):
        """Read EVERY card, retaining order and fields not represented in the UI.

        Only the delete button removes an event. Rebuilding a partial view
        must not erase another card, an OTA price or an event's metadata.
        """
        events = deepcopy(self.app.config.get("price_calendar", {}).get("events", []))
        existing = {}
        for idx, event in enumerate(events):
            event.setdefault("id", f"evt_{idx}")
            existing[event["id"]] = event

        def _num(var, default=None, kind=float):
            raw = (var.get() or "").strip().replace(",", ".")
            if not raw:
                return default
            try:
                return kind(float(raw))
            except (ValueError, OverflowError):
                return default

        for ev in self._event_vars:
            saved = existing.get(ev["id"])
            if saved is None:
                saved = {"id": ev["id"]}
                events.append(saved)
                existing[ev["id"]] = saved
            rooms_out = deepcopy(saved.get("rooms") or {})
            for room, prices in ev["prices"].items():
                room_prices = dict(rooms_out.get(room) or {})
                for ota_name, var in prices.items():
                    # An explicitly emptied cell clears its value; fields that
                    # are absent from the current UI keep their stored values.
                    value = _num(var)
                    # An old "Airbnb"/"AirBnB" pair represents the same
                    # CM OTA. Remove the hidden alias so it cannot override
                    # the price the owner just saved in the visible column.
                    for old_name in list(room_prices):
                        if old_name != ota_name and \
                                _ota_identity(old_name) == _ota_identity(ota_name):
                            room_prices.pop(old_name)
                    if value is None:
                        room_prices.pop(ota_name, None)
                    else:
                        room_prices[ota_name] = value
                if room_prices:
                    rooms_out[room] = room_prices
                else:
                    rooms_out.pop(room, None)
            saved.update({
                "name": ev["name"].get().strip(),
                "start_date": ev["start"].get().strip(),
                "end_date": ev["end"].get().strip(),
                "recurring": bool(ev["recurring"].get()),
                "locked": bool(ev["locked"].get()),
                "enabled": bool(ev["enabled"].get()),
                "rooms": rooms_out,
                "tolerance_amount": _num(ev["tol"]),
                "verify_every_days": _num(ev["freq"], default=7, kind=int),
                "wait_minutes": _num(ev["wait"], default=10, kind=int),
                "auto_correct": bool(ev["autoc"].get()),
            })
        return events

    def _persist_events(self, events):
        """Publish the new calendar in memory only after a successful write."""
        candidate = deepcopy(self.app.config)
        candidate.setdefault("price_calendar", {})["events"] = events
        try:
            if not cfg.save(candidate):
                raise OSError(tr_("The calendar could not be saved. Your edits remain on screen."))
        except Exception as exc:
            _log.exception("Saving seasonal events failed")
            _usage.trace("calendar", phase="saved", status="failed")
            messagebox.showerror(tr_("Seasonal rates"), str(exc), parent=self.app.root)
            return False
        self.app.config["price_calendar"] = candidate["price_calendar"]
        _usage.calendar_checkpoint("saved", candidate, events)
        return True

    def _save(self):
        events = self._events_from_form()
        if not self._persist_events(events):
            return False
        messagebox.showinfo(
            tr_("Seasonal rates"),
            tr_("✅ {n} saved event(s).").format(n=len(events)),
            parent=self.app.root)
        return True

    # ── Push locked prices ─────────────────────────────────────────

    def _push_locked_prices(self):
        """Push all locked+enabled event prices to the CM."""
        # Never send prices if the preceding calendar save failed.
        if not self._save():
            return

        events = self.app.config.get("price_calendar", {}).get("events", [])
        cm_cfg = self.app.config.get("channel_manager", {})
        mapping = cm_cfg.get("room_mapping", {})
        today = date.today()

        pushes = []
        pushed_events = []

        for evt in events:
            if not evt.get("locked") or not evt.get("enabled", True):
                continue
            ev_start, ev_end = resolve_event_dates(evt, today)
            if ev_start is None or ev_end is None:
                continue
            # Only push future or current events
            if ev_end < today:
                continue

            evt_pushes = 0
            for room, ota_prices in evt.get("rooms", {}).items():
                m = mapping.get(room, {})
                if not isinstance(m, dict):
                    continue
                rc = (m.get("room_code") or "").strip()
                if not rc:
                    continue
                rate_plans = m.get("rate_plans", [])
                if not rate_plans:
                    rp_code = (m.get("rate_plan_code") or "1").strip()
                    try:
                        disc = float(m.get("ota_discount_pct", 0) or 0)
                    except (ValueError, TypeError):
                        disc = 0.0
                    _price_raw = ota_prices.get("_default")
                    if not _price_raw:
                        continue
                    _push = round(_price_raw / (1 - disc / 100.0)) if 0 < disc < 100 else round(_price_raw)
                    pushes.append({
                        "room_code": rc, "room_label": room,
                        "rate_plan_code": rp_code,
                        "price": _push,
                        "from_date": ev_start.isoformat(),
                        "to_date": (ev_end + timedelta(days=1)).isoformat(),
                    })
                    evt_pushes += 1
                    continue

                for plan in rate_plans:
                    ota_name = (plan.get("ota_name") or "").strip()
                    ota_code = str(plan.get("ota_code") or "").strip()
                    rp_code = (plan.get("rate_plan_code") or "1").strip()
                    try:
                        disc = float(plan.get("ota_discount_pct", 0) or 0)
                    except (ValueError, TypeError):
                        disc = 0.0

                    # OTA-specific price or _default
                    price_raw = None
                    for k, v in ota_prices.items():
                        if k.lower() == ota_name.lower():
                            price_raw = v
                            break
                    if price_raw is None:
                        price_raw = ota_prices.get("_default")
                    if not price_raw:
                        continue

                    if 0 < disc < 100:
                        push_price = round(float(price_raw) / (1.0 - disc / 100.0))
                    else:
                        push_price = round(float(price_raw))

                    entry = {
                        "room_code": rc, "room_label": room,
                        "ota_label": (ota_name or None),
                        "rate_plan_code": rp_code,
                        "price": push_price,
                        "from_date": ev_start.isoformat(),
                        "to_date": (ev_end + timedelta(days=1)).isoformat(),
                    }
                    if ota_code:
                        entry["ota_code"] = ota_code
                    pushes.append(entry)
                    evt_pushes += 1

            if evt_pushes:
                pushed_events.append(f"{evt.get('name', '?')} ({evt_pushes} rate(s))")

        if not pushes:
            messagebox.showinfo(
                tr_("Seasonal rates"),
                tr_("No locked events with push prices."),
                parent=self.app.root)
            return

        # Confirm
        if not messagebox.askyesno(
                tr_("Push locked prices"),
                tr_("Send {n} rate(s) to Channel Manager?\n\n{events}").format(
                    n=len(pushes),
                    events="\n".join(pushed_events)),
                parent=self.app.root):
            return

        # Push in background thread
        def _task():
            try:
                # D57: go through the transport ROUTER (API or Extranet
                # Direct depending on the CM tab configuration) — before,
                # the direct API call made this button unusable in
                # keyless mode. The entries already carry from_date/to_date
                # (honored by both transports).
                import extranet_bridge as _xb

                def _prog(done, total, label):
                    try:
                        self.app.root.after(
                            0, lambda: self.app._push_progress(done, total,
                                                               label))
                    except Exception:
                        pass

                results = _xb.push_rates(
                    cm_cfg, pushes, checkin=date.today().isoformat(),
                    nights=1, log_cb=self.app._log_journal,
                    progress_cb=_prog)
                _ok = all(r["ok"] for r in results) if results else False
                _unverified = sum(int(r.get("unverified") or 0) for r in results)
                _msg = " | ".join(
                    f"{'✅' if r['ok'] else '✗'} {r['ota_code'] or 'all OTAs'}: {r['msg']}"
                    for r in results) if results else "No response"

                def _ui():
                    # D58: the seasonal push appears in "Latest
                    # submissions" like the other shipments.
                    try:
                        # labels carried by the shipments themselves
                        # (D58 v2: the resolution via cm_state re-read the
                        # 120k captures = minutes of blocking)
                        per_ota = {}
                        for r in (results or []):
                            oc = str(r.get("ota_code") or "").strip()
                            if not oc:
                                continue
                            rooms = {}
                            label = r.get("ota_label")
                            for p in pushes:
                                if str(p.get("ota_code") or "").strip() == oc:
                                    rooms[p.get("room_label")
                                          or p.get("room_code")
                                          or "?"] = p.get("price", 0)
                                    label = (p.get("ota_label") or label)
                            per_ota[oc] = {"name": label or oc,
                                           "rooms": rooms,
                                           # D77: verdict SPECIFIC to each
                                           # OTA (one failing OTA must not
                                           # paint the others ❌)
                                           "ok": bool(r.get("ok")),
                                           "sent": int(r.get("sent") or 0)}
                        _sent = 0
                        for r in (results or []):
                            if "sent" in r:
                                _sent += int(r.get("sent") or 0)
                            elif r.get("ok"):
                                _sent += int(r.get("n") or 0)
                        self.app._cm_record_push(
                            {p.get("room_label") or p.get("room_code"):
                             p.get("price", 0) for p in pushes},
                            "Seasonal rates", _ok, _msg,
                            per_ota=per_ota, sent_count=_sent)
                    except Exception:
                        pass
                    if _unverified:
                        messagebox.showwarning(
                            tr_("Seasonal rates"),
                            tr_("⚠ {n} shipment(s) detected, but their prices "
                                "are not confirmed on the CM grid.\n{msg}").format(
                                    n=_unverified, msg=_msg[:600]),
                            parent=self.app.root)
                    elif _ok:
                        messagebox.showinfo(
                            tr_("Seasonal rates"),
                            tr_("✅ {n} rate(s) sent successfully.").format(n=len(pushes)),
                            parent=self.app.root)
                    else:
                        messagebox.showwarning(
                            tr_("Seasonal rates"),
                            tr_("⚠ Partial shipment:\n{msg}").format(msg=_msg[:300]),
                            parent=self.app.root)
                self.app.root.after(0, _ui)
            except Exception as e:
                def _err(e=str(e)):
                    messagebox.showerror(
                        tr_("Error"), str(e), parent=self.app.root)
                self.app.root.after(0, _err)

        threading.Thread(target=_task, daemon=True, name="cal-push").start()
