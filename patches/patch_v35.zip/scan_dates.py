"""Scan par dates — normal et profond (Agoda modèle, ordre porteur).

Scan normal : pour chaque catégorie de chambre, si aucun prix à la date
D, avancer jour par jour jusqu'à trouver un prix (cap +14 jours).
Scan profond : même principe mais CUMULE ~1 mois : chaque date de la
période est lue et les prix horodatés par catégorie — filet de sécurité
contre les modifications de prix futures invisibles au scan normal.

Utilise le VAE1 copié (intercepteur réseau) et le lecteur vae4.agoda
(format français Agoda, refus des séjours non concordants) TELS QUELS.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
import re
import time
import urllib.request
from urllib.parse import urlsplit
from datetime import date, timedelta
from types import SimpleNamespace

from vae.src.browser.network_interceptor import NetworkInterceptor
from vae4.agoda import is_room_grid, normalize


def _new_tab(url: str = "about:blank") -> dict:
    req = urllib.request.Request("http://127.0.0.1:9222/json/new?" + url,
                                 method='PUT', data=b'')
    return json.loads(urllib.request.urlopen(req, timeout=15).read())


def _close_tab(tab_id: str) -> None:
    try:
        urllib.request.urlopen(
            f"http://127.0.0.1:9222/json/close/{tab_id}", timeout=5)
    except Exception:
        pass


def _agoda_dated(base_url: str, d: date) -> str:
    u = re.sub(r'checkin=\d{4}-\d{2}-\d{2}', f'checkin={d.isoformat()}', base_url)
    u = re.sub(r'checkout=\d{4}-\d{2}-\d{2}', f'checkout={(d + timedelta(days=1)).isoformat()}', u)
    if 'checkin=' not in u:
        u += ('&' if '?' in u else '?') + \
             f'checkin={d.isoformat()}&checkout={(d + timedelta(days=1)).isoformat()}'
    return u


async def _collect_grid(base_url: str, d: date, timeout_s: float = 40.0):
    """One date = one temp tab: VAE1 captures, waits for the room-grid
    body, closes the tab. Returns the parsed grid (or None)."""
    tab = _new_tab("about:blank")
    interceptor = NetworkInterceptor(9222)
    grid_raw = {"body": None}
    got = asyncio.Event()

    async def on_response(capture):
        if is_room_grid(capture.get("url", "")) and capture.get("status") == 200:
            body = capture.get("body") or ""
            try:
                grid_raw["body"] = json.loads(body)
                grid_raw["text"] = body
                got.set()
            except Exception:
                pass

    interceptor.on_response_received = on_response
    if not await interceptor.connect_to_tab(tab["webSocketDebuggerUrl"],
                                            tab["id"]):
        _close_tab(tab["id"])
        return None
    await interceptor.enable_network_listening(tab["id"])
    listener = asyncio.create_task(interceptor.listen_to_tab(tab["id"]))
    ws = interceptor.active_connections[tab["id"]]
    interceptor._message_id_counter += 1
    await ws.send(json.dumps({"id": interceptor._message_id_counter,
                              "method": "Page.navigate",
                              "params": {"url": _agoda_dated(base_url, d)}}))
    try:
        await asyncio.wait_for(got.wait(), timeout=timeout_s)
    except asyncio.TimeoutError:
        pass
    listener.cancel()
    try:
        await listener
    except asyncio.CancelledError:
        pass
    _close_tab(tab["id"])
    body = grid_raw.get("body")
    return body if isinstance(body, dict) else None


def _search_of(grid: dict, d: date):
    """Builds the expected-search from the grid's own analyticsContext
    (observe-then-verify: the dates we navigated + the currency the page
    itself charges in)."""
    ctx = grid.get("analyticsContext") or {}
    return SimpleNamespace(
        property_id=str(grid.get("propertyId")),
        check_in=str(ctx.get("checkin_date") or d.isoformat()),
        check_out=str(ctx.get("checkout_date")
                      or (d + timedelta(days=1)).isoformat()),
        adults=ctx.get("search_occ_no_of_adults") or 2,
        rooms=ctx.get("search_occ_no_of_rooms") or 1,
        currency=str(ctx.get("charge_currency") or ctx.get("currency")
                     or "INR"),
    )


def _canonical(name: str) -> str:
    """Agoda FR: 'Chambre Double (Double Room)' -> 'Double Room' —
    the English name in parentheses is the canonical room name."""
    m = re.search(r'\(([^)]+)\)\s*$', str(name) or '')
    return (m.group(1).strip() if m else str(name)).strip()


def _grid_prices(grid: dict, d: date):
    """{(canonical room name): price|None} for this date."""
    search = _search_of(grid, d)
    norm = normalize(grid, search)
    rows = []
    for room in norm.get("rooms") or []:
        price = None
        for of in room.get("offers") or []:
            if of.get("final") is not None:
                price = int(of["final"])
                break
        rows.append((_canonical(room.get("name") or "?"), price,
                     room.get("sold_out")))
    return rows, norm.get("currency")


def scan_normal(base_url: str, room_types: list, max_walk: int = 14,
                log=print) -> dict:
    """Per room category: advance day by day until a price is found."""
    out = {r: None for r in room_types}
    dates = {r: None for r in room_types}
    missing = list(room_types)
    d0 = date.today() + timedelta(days=7)
    for offset in range(max_walk + 1):
        d = d0 + timedelta(days=offset)
        grid = asyncio.run(_collect_grid(base_url, d))
        if not grid:
            log(f"[normal] {d}: grille non capturée")
            continue
        rows, cur = _grid_prices(grid, d)
        for name, price, sold in rows:
            if name in out and out[name] is None and price:
                out[name] = price
                dates[name] = d.isoformat()
        missing = [r for r in room_types if out[r] is None]
        log(f"[normal] {d}: {len(room_types) - len(missing)}/{len(room_types)} "
            f"catégories prixées (devise {cur})")
        if not missing:
            break
    return {"prices": out, "dates": dates, "missing": missing,
            "currency": cur if not missing else (cur or "?")}


def scan_deep(base_url: str, room_types: list, days: int = 30,
              log=print) -> dict:
    """Walks `days` stay dates; accumulates every price per category
    per date — the future price-change safety net."""
    history = {r: {} for r in room_types}
    d0 = date.today() + timedelta(days=7)
    for offset in range(days):
        d = d0 + timedelta(days=offset)
        grid = asyncio.run(_collect_grid(base_url, d))
        if not grid:
            log(f"[profond] {d}: grille non capturée")
            continue
        rows, cur = _grid_prices(grid, d)
        priced = sum(1 for _, p, _ in rows if p)
        log(f"[profond] {d}: {priced}/{len(rows)} chambres prixées")
        for name, price, sold in rows:
            if name in history and price:
                history[name][d.isoformat()] = price
    changes = {}
    for room, series in history.items():
        seen = []
        for d in sorted(series):
            if not seen or series[d] != seen[-1][1]:
                seen.append((d, series[d]))
        if len(seen) > 1:
            changes[room] = seen
    return {"history": history, "changes": changes,
            "currency": cur if 'cur' in dir() else None}


# ══ UNIVERSAL — any OTA, any date format ═══════════════════════════════

OTA_LABELS = {"AGODA": "Agoda", "GOIBIBO": "Goibibo", "EXPEDIA": "Expedia", "MAKEMYTRIP": "MakeMyTrip", "AIRBNB": "Airbnb"}
from websockets.sync.client import connect as _ws_connect


class _SyncTab:
    """Minimal sync CDP tab client (self-contained)."""

    def __init__(self, info: dict):
        self.info = info
        self.url = info.get("url") or ""
        self._ws = _ws_connect(info["webSocketDebuggerUrl"], max_size=2 ** 25)
        self._id = 0

    def cmd(self, method, params=None):
        self._id += 1
        self._ws.send(json.dumps({"id": self._id, "method": method,
                                  "params": params or {}}))

    def eval(self, js, timeout=20.0):
        self._id += 1
        mid = self._id
        self._ws.send(json.dumps({"id": mid, "method": "Runtime.evaluate",
                                  "params": {"expression": js,
                                             "returnByValue": True,
                                             "awaitPromise": True,
                                             "userGesture": True}}))
        deadline = time.time() + timeout
        while time.time() < deadline:
            frame = json.loads(self._ws.recv(timeout=max(0.2,
                                                         deadline - time.time())))
            if frame.get("id") == mid:
                r = frame.get("result", {})
                if r.get("exceptionDetails"):
                    return None
                return r.get("result", {}).get("value")
        raise TimeoutError("eval")

    def click_finder(self, finder_js):
        center = self.eval(f"""
        (() => {{
          const el = ({finder_js});
          if (!el) return null;
          const r = el.getBoundingClientRect();
          if (!r || r.width <= 0 || r.height <= 0) return null;
          return [r.x + r.width / 2, r.y + r.height / 2];
        }})()
        """)
        if isinstance(center, list) and len(center) == 2:
            for type_ in ("mousePressed", "mouseReleased"):
                self.cmd("Input.dispatchMouseEvent", {
                    "type": type_, "x": int(float(center[0])),
                    "y": int(float(center[1])),
                    "button": "left", "buttons": 1, "clickCount": 1})
                time.sleep(0.07)
            return True
        return False

    def navigate(self, url, wait_ready=25.0):
        self.cmd("Page.navigate", {"url": url})
        deadline = time.time() + wait_ready
        while time.time() < deadline:
            try:
                if (self.eval("document.readyState", timeout=5)
                        or "") == "complete":
                    return
            except Exception:
                pass
            time.sleep(0.5)


_MONEY_JS = r"""
(namesJson) => {
  const names = JSON.parse(namesJson);
  const MONEY = new RegExp('\\d[\\d ,.\\u00a0\\u202f]{0,10}\\s?(?:\\u20b9|\\u20ac|\\$|\\u0e3f)|(?:\\u20b9|\\u20ac|\\$|\\u0e3f)\\s?\\d[\\d ,.\\u00a0\\u202f]{0,10}', 'g');
  const all = [...document.querySelectorAll('body *')];
  const result = {};
  const cards = {};
  const used = new Set();
  for (const name of names) {
    if (!name) { continue; }
    // substring pollution: 'Double Room' lives inside 'Deluxe Double
    // Room' — a shorter name must not match an element that carries a
    // LONGER expected name
    const holders = all.filter(e => (e.textContent || '').includes(name)
      && !names.some(o => o && o.length > name.length
                          && (e.textContent || '').includes(o)));
    if (!holders.length) { result[name] = []; continue; }
    const smallest = holders.reduce((a, b) =>
      (a.textContent.length <= b.textContent.length ? a : b));
    let el = smallest;
    let amounts = [];
    for (let up = 0; up < 8 && el; up++) {
      const t = (el.textContent || '').replace(/[  ]/g, ' ');
      const found = (t.match(MONEY) || [])
        .map(a => a.replace(/[  ]/g, ' ').trim())
        .filter(a => !used.has(a));
      if (found.length) { amounts = found; break; }
      el = el.parentElement;
    }
    amounts.forEach(a => used.add(a));
    result[name] = amounts;
    cards[name] = el ? (el.textContent || '').slice(0, 700) : '';
  }
  return JSON.stringify({prices: result, cards: cards});
}
"""



def select_price(amounts: list, card_text: str = ""):
    """The DISPLAYED booking price among the amounts found in a room
    card — proven on Goibibo cards: 'INR 1,696/Night' is authoritative;
    '+ 210 taxes & fees' must never win; absent a /night anchor the
    largest remaining amount is the booking price (a tax line is always
    smaller than the room price)."""
    import re as _re
    vals = []
    for a in amounts or []:
        d = _re.sub(r'[^\d]', '', str(a) or '')
        # bounds cover every display currency: rupees (500-20000) as
        # well as dollars (10-200) — proven on makemytrip.global '$ 22'
        if d and 10 <= int(d) <= 50000:
            vals.append(int(d))
    if not vals:
        return None
    # 1) amount anchored to '/night' or 'Per Night: X' in the card text
    if card_text:
        m = _re.search(r'([\d][\d ,.  ]{0,9})\s*/\s*night',
                       card_text, _re.I)
        if not m:
            m = _re.search(r'per\s*night\s*[:\-]?\s*(?:[^\d]{0,6})'
                           r'([\d][\d ,.  ]{0,9})',
                           card_text, _re.I)
        if m:
            d = _re.sub(r'[^\d]', '', m.group(1))
            if d and 10 <= int(d) <= 50000:
                return int(d)
    # 2) drop the amount that immediately precedes 'taxes' (the tax line)
    cleaned = list(vals)
    if card_text:
        m = _re.search(r'([\d][\d ,.  ]{0,9})\s*(?:&?\s*taxes|\s*tax)',
                       card_text, _re.I)
        if m:
            d = _re.sub(r'[^\d]', '', m.group(1))
            if d and int(d) in cleaned and len(cleaned) > 1:
                cleaned.remove(int(d))
    if not cleaned:
        cleaned = list(vals)
    return max(cleaned)


def _apply_selection(dom: dict, cards: dict, jsub: dict,
                     room_types: list) -> dict:
    # DOM card read first (the precise source, proven on Goibibo);
    # JSON pairing as fallback.
    out = {}
    sym_map = {'₹': 'INR', '$': 'USD', '€': 'EUR',
               '฿': 'THB', 'Rs': 'INR', 'INR': 'INR'}
    for room in room_types:
        dom_vals = dom.get(room) or []
        if dom_vals:
            sel = select_price(dom_vals, cards.get(room, ' '))
        else:
            sel = select_price(jsub.get(room) or [], ' ')
        vals = sorted(set(
            [int(re.sub(r'[^\d]', '', r)) for r in dom_vals
             if re.sub(r'[^\d]', '', r).isdigit()
             and 10 <= int(re.sub(r'[^\d]', '', r)) <= 50000]
        ) | set(jsub.get(room) or []))
        cur = None
        for raw in dom_vals:
            for sym, code in sym_map.items():
                if sym in str(raw):
                    cur = code
                    break
            if cur:
                break
        out[room] = {'displayed': vals, 'selected': sel, 'currency': cur}
    return out

def _json_room_prices(items: list, room_types: list) -> dict:
    """UNIVERSAL JSON pairing (post-order subtree)."""
    result = {r: set() for r in room_types}

    def walk(o):
        names, nums = set(), set()
        if isinstance(o, dict):
            for k, v in o.items():
                if isinstance(v, str):
                    # attribute to the LONGEST matching name only —
                    # 'Double Room' must not steal a 'Deluxe Double
                    # Room' value through substring matching
                    for r in room_types:
                        if r in v and not any(
                                o2 in room_types and len(o2) > len(r)
                                and o2 in v for o2 in room_types):
                            names.add(r)
                elif isinstance(v, (int, float)) and not isinstance(v, bool)                         and re.search(r'(price|total|amount|gross|inclusive)',
                                      k, re.I) and 10 <= v <= 50000:
                    nums.add(int(v))
                elif isinstance(v, str) and re.match(r'^[\d.,]{3,9}$', v)                         and re.search(r'(price|total|amount)', k, re.I):
                    d = int(re.sub(r'[^\d]', '', v) or 0)
                    if 10 <= d <= 50000:
                        nums.add(d)
                cn, cnm = walk(v)
                names |= cn
                nums |= cnm
        elif isinstance(o, list):
            for v in o[:150]:
                cn, cnm = walk(v)
                names |= cn
                nums |= cnm
        return names, nums

    for url, text in items:
        try:
            payload = json.loads(text)
        except Exception:
            continue
        names, nums = walk(payload)
        for r in names:
            result[r].update(n for n in nums if 10 <= n <= 50000)
    return {r: sorted(v) for r, v in result.items()}

SCROLL_BOTTOM_JS = "window.scrollTo(0, document.body.scrollHeight)"

ROOMS_RENDERED_JS = """
(namesJson) => {
  const names = JSON.parse(namesJson);
  const body = document.body.innerText || '';
  return JSON.stringify({found: names.filter(n => body.includes(n)).length,
                         of: names.length});
}
"""


def shift_dates(url: str, target: date) -> tuple[str, bool]:
    """Rewrites EVERY date-looking param so the CHECK-IN becomes
    `target`, preserving each param's own format. Returns (url, ok)."""
    params = list(DATE_PARAM.finditer(url))
    if not params:
        return url, False
    checkin = next((p for p in params
                    if re.search(r'checkin|check_in|chkin|arrival',
                                 p.group(1), re.I)), params[0])
    raw = checkin.group(2)
    val, fmt = None, None
    for f in ('%Y-%m-%d', '%Y%m%d', '%m%d%Y'):
        try:
            val = datetime.datetime.strptime(raw, f)
            fmt = f
            break
        except ValueError:
            continue
    if val is None:
        return url, False
    base = val
    delta = target - base.date()
    out, last = [], 0
    for p in params:
        out.append(url[last:p.start()])
        try:
            pv = datetime.datetime.strptime(p.group(2), fmt)
        except ValueError:
            out.append(url[p.start():p.end()])
            continue
        shifted = pv.date() + delta
        out.append(f"{p.group(1)}={shifted.strftime(fmt)}")
        last = p.end()
    out.append(url[last:])
    return ''.join(out), True


import datetime
DATE_PARAM = re.compile(
    r'(checkin|check_in|chkin|checkout|check_out|chkout|arrival|departure)'
    r'=(\d{4}-?\d{2}-?\d{2})', re.I)


def _universal_collect(url: str, room_types: list, dwell: float = 25.0):
    """Temp tab: VAE1 network capture + scroll-to-render + name-first
    DOM read + JSON-subtree pairing. Returns (dom, items, rendered)."""
    tab = _new_tab("about:blank")
    st = _SyncTab(tab)
    items: list = []

    async def _run():
        interceptor = NetworkInterceptor(9222)
        await interceptor.connect_to_tab(tab["webSocketDebuggerUrl"],
                                         tab["id"])
        await interceptor.enable_network_listening(tab["id"])

        def on_response(capture):
            body = capture.get("body") or ""
            if body[:1] in ('{', '['):
                items.append((capture.get("url", ""), body))

        interceptor.on_response_received = on_response
        listener = asyncio.create_task(interceptor.listen_to_tab(tab["id"]))
        st.navigate(url, wait_ready=25)
        names_json = json.dumps(json.dumps(
            sorted(room_types, key=len, reverse=True),
            ensure_ascii=False))
        deadline = time.time() + dwell
        rendered = False
        while time.time() < deadline:
            st.eval(SCROLL_BOTTOM_JS)
            time.sleep(2)
            try:
                r = json.loads(st.eval(
                    f"({ROOMS_RENDERED_JS})({names_json})",
                    timeout=10) or '{}')
                if r.get('of') and r.get('found', 0) >= r.get('of'):
                    rendered = True
                    break
            except Exception:
                pass
        dom_raw = st.eval(f"({_MONEY_JS})({names_json})", timeout=30)
        dom = {}
        if isinstance(dom_raw, str):
            try:
                dom = (json.loads(dom_raw) or {}).get('prices') or {}
            except Exception:
                pass
        listener.cancel()
        try:
            await listener
        except asyncio.CancelledError:
            pass

    dom, rendered = {}, False
    try:
        asyncio.run(_run())
    except Exception:
        pass
    finally:
        _close_tab(tab["id"])
    return dom, items, rendered


def universal_read(url: str, room_types: list) -> dict:
    """{room: {'displayed': [...], 'selected': int|None}} for ANY OTA."""
    dom, items, _ = _universal_collect(url, room_types)
    pairs = _json_room_prices(items, room_types)
    return _apply_selection(dom, {}, pairs, room_types)




def _find_user_tab(host_frag: str) -> dict | None:
    """The USER'S already-open, already-rendered tab for this OTA."""
    import urllib.request as _ur
    tabs = json.loads(_ur.urlopen("http://127.0.0.1:9222/json",
                                  timeout=5).read())
    return next((t for t in tabs if t.get('type') == 'page'
                 and host_frag in (t.get('url') or '')), None)


_PAGE_HOOK = r"""(function(){if(window.__orionLive)return;window.__orionLive=1;const NOISE=/jitney|google-analytics|doubleclick|googletagmanager|sentry|beacon|metrics\.|pdt\.|\/ee\/|interact/i;const send=(u,t)=>{try{if(!t||t.length>24e6)return;const c=t.trim()[0];if(c!=='{'&&c!=='[')return;if(NOISE.test(u))return;window.__orionReport(JSON.stringify({u:String(u),b:t}))}catch(e){}};const of=window.fetch;window.fetch=function(){const p=of.apply(this,arguments);p.then(r=>{try{const ct=r.headers.get('content-type')||'';if(ct.indexOf('json')>-1)r.clone().text().then(t=>send(r.url,t))}catch(e){}}).catch(()=>{});return p};const oo=XMLHttpRequest.prototype.open,os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__u=u;return oo.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){this.addEventListener('load',function(){try{const ct=this.getResponseHeader('content-type')||'';if(ct.indexOf('json')>-1)send(this.__u,this.responseText)}catch(e){}});return os.apply(this,arguments)}})()"""

def universal_read_user_tab(host_frag: str, url: str,
                            room_types: list) -> dict:
    """Date-walk read on the USER'S OWN TAB (already rendered, session
    warm) — the mode that proved Goibibo 3-4/4. The tab is navigated to
    the dated URL, scrolled until the room names render, then read.
    The page-side hook captures ALL network JSON for the JSON pass."""
    tab_info = _find_user_tab(host_frag)
    if not tab_info:
        return {r: {'displayed': [], 'selected': None} for r in room_types}
    st = _SyncTab(tab_info)
    # arm the page-side hook BEFORE navigation
    st.cmd("Page.enable")
    st.cmd("Runtime.enable")
    st.cmd("Runtime.addBinding", {"name": "__orionReport"})
    st.cmd("Page.addScriptToEvaluateOnNewDocument", {"source": _PAGE_HOOK})
    items: list = []

    def _drain_ws(seconds):
        deadline = time.time() + seconds
        while time.time() < deadline:
            try:
                f = json.loads(st._ws.recv(timeout=max(0.2,
                    deadline - time.time())))
            except Exception:
                continue
            p2 = f.get("params") or {}
            if f.get("method") == "Runtime.bindingCalled" \
                    and p2.get("name") == "__orionReport":
                try:
                    payload = json.loads(p2["payload"])
                    items.append((payload.get("u", ""), payload.get("b", "")))
                except Exception:
                    pass

    st.navigate(url, wait_ready=25)
    names_json = json.dumps(json.dumps(
        sorted(room_types, key=len, reverse=True), ensure_ascii=False))
    rendered = False
    deadline = time.time() + 45
    while time.time() < deadline:
        st.eval(SCROLL_BOTTOM_JS)
        _drain_ws(2.5)
        try:
            r = json.loads(st.eval(
                f"({ROOMS_RENDERED_JS})({names_json})",
                timeout=10) or '{}')
            if r.get('of') and r.get('found', 0) >= r.get('of'):
                rendered = True
                break
        except Exception:
            pass
    # prices often render AFTER the room names (proven on MakeMyTrip:
    # names first, '$ 22' seconds later) — settle before the read
    st.eval(SCROLL_BOTTOM_JS)
    time.sleep(4)
    _drain_ws(3.0)
    dom_raw = st.eval(f"({_MONEY_JS})({names_json})", timeout=30)
    dom, cards = {}, {}
    if isinstance(dom_raw, str):
        try:
            _d = json.loads(dom_raw) or {}
            dom = _d.get('prices') or {}
            cards = _d.get('cards') or {}
        except Exception:
            pass
    # JSON-subtree pairing on the hook-captured bodies - FALLBACK only
    jsub = _json_room_prices(items, room_types)
    return _apply_selection(dom, cards, jsub, room_types)


def _launch_brave(port: int = 9222):
    """Launches Brave with the debug port when nothing listens."""
    import subprocess
    brave = next((p for p in (
        "C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe",
        "C:/Program Files (x86)/BraveSoftware/Brave-Browser/Application/brave.exe")
        if os.path.exists(p)), None)
    if not brave:
        return False
    subprocess.Popen([brave, f"--remote-debugging-port={port}",
                      "--restore-last-session"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     cwd=os.path.dirname(brave))
    import time as _t
    deadline = _t.time() + 20
    while _t.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2)
            return True
        except Exception:
            _t.sleep(1)
    return False


def scan_normal_user_tabs(config_urls: dict, room_types: list,
                          max_walk: int = 14, log=print) -> dict:
    # auto-launch Brave if the debug port is unreachable
    try:
        urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=3)
    except Exception:
        log("[scan] Brave fermé — lancement automatique…")
        _launch_brave()
    table = {}
    d0 = date.today() + timedelta(days=7)
    # charger les alias OTA → chambres depuis room_names.json (D108)
    display_names = {}  # ota_name -> [noms affichés par l'OTA]
    try:
        import os as _os
        _rn_path = _os.path.join(_os.environ['APPDATA'], 'OTA Guard V3', 'data', 'room_names.json')
        rn = json.loads(Path(_rn_path).read_text(encoding='utf-8'))
        for sheet_key, sheet in (rn.get('otas') or {}).items():
            for displayed, our_room in (sheet.get('names') or {}).items():
                ota_label = next((OTA_LABELS.get(k, k) for k in OTA_LABELS
                                  if sheet_key.startswith(k.lower())), None)
                if ota_label:
                    display_names.setdefault(ota_label, []).append(displayed)
    except Exception as e:
        print(f"[DEBUG] display_names loading error: {e}")
    # FALLBACK: hard-code the known aliases so the scan ALWAYS works
    if not display_names:
        display_names = {
            'Agoda': ['Chambre Double (Double Room)', 'Chambre Double Deluxe (Deluxe Double Room)', 'Chambre Double avec Balcon (Double Room with Balcony)', 'Chambre Double Deluxe avec Balcon (Deluxe Double Room with Balcony)'],
            'Expedia': ['Basic Double Room, Garden View', 'Standard Single Room, Garden View', 'Elite Double Room, 1 King Bed, Garden View', 'Deluxe Double Room, Garden View'],
            'Goibibo': ['Deluxe Double Room with Balcony', 'Double Room with Balcony', 'Double Room', 'Deluxe Double Room'],
            'MakeMyTrip': ['Double Room', 'Deluxe Double Room', 'Double Room with Balcony', 'Deluxe Double Room with Balcony'],
            'Airbnb': ['Airbnb Double Room', 'Airbnb Deluxe Double Room', 'Airbnb Double Room with Balcony', 'Airbnb Deluxe Double Room with Balcony'],
        }
    log(f"[DEBUG] display_names: { {k: len(v) for k, v in display_names.items()} }")

    for ota_name, base_url in config_urls.items():
        host_frag = next((h for h in ('agoda', 'expedia', 'goibibo',
                                      'makemytrip', 'airbnb')
                          if h in (urlsplit(base_url).hostname or '')), None)
        if not host_frag:
            continue
        # ── AIRBNB: the card machine (calendar clicks + card read) ──────
        if host_frag == 'airbnb':
            m = re.search(r'/rooms/(\d+)', urlsplit(base_url).path or '')
            if not m:
                continue
            lid = m.group(1)
            ci = d0
            co = d0 + timedelta(days=1)
            aurl = (f"https://www.airbnb.fr/rooms/{lid}"
                    f"?check_in={ci.isoformat()}&check_out={co.isoformat()}"
                    f"&adults=1&locale=fr")
            tab_info = _find_user_tab(host_frag)
            if not tab_info:
                continue
            st = _SyncTab(tab_info)
            st.navigate(aurl, wait_ready=25)
            # wait for the booking card or click to open it
            CARD_READ = r"""
(() => {
  const card = document.querySelector('[data-testid="bookit-sidebar"], [data-testid="book-it"]');
  if (!card) {
    const btn = [...document.querySelectorAll('button, a[role="button"]')]
      .find(b => /^(r[ée]server|reserve|book)$/i.test((b.textContent || '').trim()));
    if (btn) {
      let el = btn;
      for (let i = 0; i < 14 && el; i++) {
        el = el.parentElement;
        const tx = (el && el.textContent || '');
        if (/au total|Total/i.test(tx) && tx.length < 3000) {
          const clean = tx.replace(/\s+/g, ' ');
          const amounts = (clean.match(/\d[\d .,]{0,10}\s?[€$₹]|[€$₹]\s?\d[\d .,]{0,12}/g) || []).slice(0, 6);
          return JSON.stringify({card: true, where: 'footer',
              amounts, dates: ((clean.match(/Arrivée\s?(\d{2}\/\d{2}\/\d{4})/) || [])[1] || '') + '→' + ((clean.match(/Départ\s?(\d{2}\/\d{2}\/\d{4})/) || [])[1] || '')});
        }
      }
    }
  }
  const t2 = card ? (card.textContent || '').replace(/\s+/g, ' ') : '';
  const amounts = card ? (t2.match(/\d[\d .,]{0,10}\s?[€$₹]|[€$₹]\s?\d[\d .,]{0,12}/g) || []).slice(0, 6) : [];
  return JSON.stringify({card: !!card, where: card ? 'sidebar' : null, amounts});
})()
"""
            result = None
            for _ in range(6):
                raw = st.eval(CARD_READ)
                if isinstance(raw, str):
                    try:
                        result = json.loads(raw)
                    except Exception:
                        result = None
                if result and result.get('card'):
                    break
                # click Réserver to open the card
                st.click_finder("""(() => [...document.querySelectorAll(
                    'button, a[role="button"]')].find(b =>
                    /^(r[ée]server|reserve|book)$/i.test(
                    (b.textContent || '').trim())))()""")
                time.sleep(3)
            if result and result.get('card') and result.get('amounts'):
                amount_str = result['amounts'][0]
                digits = re.sub(r'[^\d]', '', amount_str)
                price = int(digits) if digits else None
                if price:
                    table.setdefault('AIRBNB', []).append(
                        (f"annonce …{lid[-4:]}", price, 'EUR'))
            continue

        # ── les noms à chercher dans la page = les noms que CETTE OTA affiche
        # (alias room_names) + les room_types bruts (au cas où)
        search_names = list(dict.fromkeys(
            display_names.get(ota_name, []) + room_types))
        log(f"[normal/{ota_name}] recherche par noms: {search_names}")
        out = {r: None for r in room_types}
        dates = {r: None for r in room_types}
        # mapping display_name -> room_type pour convertir le résultat
        name_to_room = {}
        try:
            from core.paths import DATA_DIR as _dd
            rn = json.loads((Path(_dd) / 'room_names.json').read_text(
                encoding='utf-8'))
            for sheet_key, sheet in (rn.get('otas') or {}).items():
                for displayed, our_room in (sheet.get('names') or {}).items():
                    name_to_room[displayed] = our_room
        except Exception:
            pass
        for offset in range(max_walk + 1):
            d = d0 + timedelta(days=offset)
            url, ok = shift_dates(base_url, d)
            res = universal_read_user_tab(host_frag, url, search_names)
            for display_name, info in res.items():
                room = name_to_room.get(display_name, display_name)
                if room in out and out[room] is None and info['selected']:
                    out[room] = info['selected']
                    dates[room] = d.isoformat()
            missing = [r for r in room_types if out[r] is None]
            log(f"[normal/{ota_name}] {d}: "
                f"{len(room_types) - len(missing)}/{len(room_types)} prixées")
            if not missing:
                break
        table[ota_name] = {'prices': out, 'dates': dates,
                           'missing': missing}
    return table

def scan_normal_generic(base_url: str, room_types: list,
                        max_walk: int = 14, log=print) -> dict:
    out = {r: None for r in room_types}
    dates = {r: None for r in room_types}
    d0 = date.today() + timedelta(days=7)
    for offset in range(max_walk + 1):
        d = d0 + timedelta(days=offset)
        url, ok = shift_dates(base_url, d)
        res = universal_read(url, room_types)
        for room in room_types:
            if out[room] is None and res[room]['selected']:
                out[room] = res[room]['selected']
                dates[room] = d.isoformat()
        missing = [r for r in room_types if out[r] is None]
        log(f"[normal] {d}: {len(room_types) - len(missing)}/{len(room_types)} "
            f"catégories prixées" + ("" if ok else " | format de dates inconnu"))
        if not missing:
            break
    return {"prices": out, "dates": dates, "missing": missing}


# ══ ORCHESTRATION — the entry point used by OTA Guard ═══════════════════

STOP_FLAG = {"stop": False}


def request_stop():
    """⏹ cooperative stop — checked between every date step."""
    STOP_FLAG["stop"] = True


def _stopped() -> bool:
    return bool(STOP_FLAG["stop"])


_CARD_READ_JS = r"""
(() => {
  const card = document.querySelector('[data-testid="bookit-sidebar"], [data-testid="book-it"]');
  if (!card) {
    const btn = [...document.querySelectorAll('button, a[role="button"]')]
      .find(b => /^(r[ée]server|reserve|book)$/i.test((b.textContent || '').trim()));
    if (btn) {
      let el = btn;
      for (let i = 0; i < 14 && el; i++) {
        el = el.parentElement;
        const tx = (el && el.textContent || '');
        if (/au total|Total/i.test(tx) && tx.length < 3000) {
          const clean = tx.replace(/\s+/g, ' ');
          const amounts = (clean.match(/\d[\d .,]{0,10}\s?[€$₹]|[€$₹]\s?\d[\d .,]{0,12}/g) || []).slice(0, 6);
          return JSON.stringify({card: true, where: 'footer',
              amounts, dates: ((clean.match(/Arrivée\s?(\d{2}\/\d{2}\/\d{4})/) || [])[1] || '') + '→' + ((clean.match(/Départ\s?(\d{2}\/\d{2}\/\d{4})/) || [])[1] || '')});
        }
      }
    }
  }
  const t2 = card ? (card.textContent || '').replace(/\s+/g, ' ') : '';
  const amounts = card ? (t2.match(/\d[\d .,]{0,10}\s?[€$₹]|[€$₹]\s?\d[\d .,]{0,12}/g) || []).slice(0, 6) : [];
  return JSON.stringify({card: !!card, where: card ? 'sidebar' : null, amounts});
})()
"""


def _airbnb_card_price(lid: str, d: date, log=print):
    """Navigates the listing's OWN Airbnb tab to its dated URL, opens
    the booking card (click Réserver if needed), returns the total."""
    # the listing's OWN tab first — never steal another listing's tab
    # (measured live: stealing merged two listings onto one tab)
    tab_info = _find_user_tab(f'/rooms/{lid}')
    stolen = False
    temp = None
    if not tab_info:
        tab_info = _find_user_tab('airbnb')
        stolen = tab_info is not None
    if not tab_info:
        # no Airbnb tab open — a temporary tab does the same job and is
        # closed afterwards (the user's tabs are never touched)
        temp = _new_tab("about:blank")
        tab_info = temp
        log("[airbnb] pas d'onglet ouvert — onglet temporaire")
    restore_url = (tab_info.get('url') or '') if stolen else ''
    st = _SyncTab(tab_info)
    ci, co = d, d + timedelta(days=1)
    aurl = (f"https://www.airbnb.fr/rooms/{lid}"
            f"?check_in={ci.isoformat()}&check_out={co.isoformat()}"
            f"&adults=1&locale=fr")
    st.navigate(aurl, wait_ready=25)
    for _ in range(8):
        raw = st.eval(_CARD_READ_JS, timeout=20)
        result = None
        if isinstance(raw, str):
            try:
                result = json.loads(raw)
            except Exception:
                result = None
        if result and result.get('card') and result.get('amounts'):
            digits = re.sub(r'[^\d]', '', result['amounts'][0])
            return int(digits) if digits else None
        # the booking widget mounts progressively WITH scrolling
        # (measured live: 582 -> 11k chars) — scroll every attempt
        st.eval(SCROLL_BOTTOM_JS)
        st.click_finder("""(() => [...document.querySelectorAll(
            'button, a[role="button"]')].find(b =>
            /^(r[ée]server|reserve|book)$/i.test(
            (b.textContent || '').trim())))()""")
        time.sleep(3)
    if temp:
        try:
            _close_tab(temp["id"])
        except Exception:
            pass
    elif restore_url:
        # a stolen tab gets its own URL back (D34 spirit)
        try:
            st.navigate(restore_url, wait_ready=15)
        except Exception:
            pass
    return None


def _airbnb_listings(profile: dict) -> list:
    """The listing URLs of an Airbnb config entry (url + watch_urls)."""
    urls = []
    if profile.get('url'):
        urls.append(profile['url'])
    urls += [u for u in (profile.get('watch_urls') or []) if u]
    return list(dict.fromkeys(urls))


def _ota_display_maps() -> tuple:
    """(display_names per OTA label, display→our-room) from the D108
    file room_names.json — with the known-alias fallback so the scan
    ALWAYS has the names the OTAs actually display."""
    display_names = {}
    try:
        import os as _os
        _rn_path = _os.path.join(_os.environ['APPDATA'], 'OTA Guard V3',
                                 'data', 'room_names.json')
        rn = json.loads(Path(_rn_path).read_text(encoding='utf-8'))
        for sheet_key, sheet in (rn.get('otas') or {}).items():
            for displayed in (sheet.get('names') or {}):
                ota_label = next((OTA_LABELS.get(k, k) for k in OTA_LABELS
                                  if sheet_key.startswith(k.lower())), None)
                if ota_label:
                    display_names.setdefault(ota_label, []).append(displayed)
    except Exception:
        pass
    if not display_names:
        display_names = {
            'Agoda': ['Chambre Double (Double Room)',
                      'Chambre Double Deluxe (Deluxe Double Room)',
                      'Chambre Double avec Balcon (Double Room with Balcony)',
                      'Chambre Double Deluxe avec Balcon (Deluxe Double Room with Balcony)'],
            'Expedia': ['Basic Double Room, Garden View',
                        'Standard Single Room, Garden View',
                        'Elite Double Room, 1 King Bed, Garden View',
                        'Deluxe Double Room, Garden View'],
            'Goibibo': ['Deluxe Double Room with Balcony',
                        'Double Room with Balcony', 'Double Room',
                        'Deluxe Double Room'],
            'MakeMyTrip': ['Double Room', 'Deluxe Double Room',
                           'Double Room with Balcony',
                           'Deluxe Double Room with Balcony'],
            'Airbnb': ['Airbnb Double Room', 'Airbnb Deluxe Double Room',
                       'Airbnb Double Room with Balcony',
                       'Airbnb Deluxe Double Room with Balcony'],
        }
    name_to_room = {}
    try:
        from core.paths import DATA_DIR as _dd
        rn = json.loads((Path(_dd) / 'room_names.json').read_text(
            encoding='utf-8'))
        for sheet in (rn.get('otas') or {}).values():
            name_to_room.update(sheet.get('names') or {})
    except Exception:
        pass
    return display_names, name_to_room


def _segments(history: dict) -> dict:
    """Collapses a {date: price} series into [(date, price)] change
    segments — consecutive identical prices merge."""
    changes = {}
    for room, series in history.items():
        seen = []
        for d in sorted(series):
            if not seen or series[d] != seen[-1][1]:
                seen.append((d, series[d]))
        if len(seen) > 1:
            changes[room] = seen
    return changes


def scan_ota_user_tab(ota_name: str, urls: list, room_types: list,
                      mode: str = 'normal', days: int = 30,
                      max_walk: int = 14, maps: tuple = None,
                      log=print) -> dict:
    """ONE non-Agoda OTA on the user's own tab. normal = walk dates
    until every category is priced (cap max_walk); deep = walk ALL
    days dates and accumulate the per-date price history."""
    display_names, name_to_room = maps if maps else _ota_display_maps()
    base_url = urls[0]
    host_frag = next((h for h in ('expedia', 'goibibo', 'makemytrip',
                                  'airbnb')
                      if h in (urlsplit(base_url).hostname or '')), None)
    empty = ({} if mode == 'deep'
             else {'prices': {}, 'dates': {}, 'missing': list(room_types)})
    if not host_frag or not urls:
        return empty
    search_names = list(dict.fromkeys(
        display_names.get(ota_name, []) + list(room_types)))
    span = days if mode == 'deep' else max_walk
    d0 = date.today() + timedelta(days=7)
    history = {}
    prices = {r: None for r in room_types}
    dates = {r: None for r in room_types}
    for offset in range(span + (0 if mode == 'deep' else 1)):
        if _stopped():
            break
        d = d0 + timedelta(days=offset)
        if host_frag == 'airbnb':
            n_lu = 0
            for lu in urls:
                if _stopped():
                    break
                m = re.search(r'/rooms/(\d+)', urlsplit(lu).path or '')
                if not m:
                    continue
                lid = m.group(1)
                key = f'annonce …{lid[-4:]}'
                price = _airbnb_card_price(lid, d, log=log)
                if price:
                    n_lu += 1
                    history.setdefault(key, {})[d.isoformat()] = price
                    if mode == 'normal' and prices.get(key) is None:
                        prices[key] = price
                        dates[key] = d.isoformat()
            log(f"[{mode}/{ota_name}] {d}: {n_lu}/{len(urls)} annonces lues")
        else:
            url, ok = shift_dates(base_url, d)
            if _find_user_tab(host_frag):
                res = universal_read_user_tab(host_frag, url, search_names)
            else:
                # no tab open for this OTA — temporary tab (VAE1 + DOM
                # + JSON), the owner's "unknown OTA not open in Brave"
                # case
                log(f"[{mode}/{ota_name}] {d}: onglet {host_frag} "
                    f"absent — onglet temporaire")
                res = universal_read(url, search_names)
            n_found = 0
            for display_name, info in res.items():
                room = name_to_room.get(display_name, display_name)
                if not info['selected']:
                    continue
                n_found += 1
                if mode == 'deep':
                    if room in room_types:
                        history.setdefault(
                            room, {})[d.isoformat()] = info['selected']
                elif room in prices and prices[room] is None:
                    prices[room] = info['selected']
                    dates[room] = d.isoformat()
            if mode == 'normal':
                missing = [r for r in room_types if prices[r] is None]
                log(f"[normal/{ota_name}] {d}: "
                    f"{len(room_types) - len(missing)}/{len(room_types)} "
                    f"catégories prixées"
                    + ("" if ok else " | format de dates inconnu"))
                if not missing:
                    break
            else:
                log(f"[profond/{ota_name}] {d}: {n_found} noms trouvés, "
                    f"{len(history)} chambres cumulées")
    if mode == 'deep':
        return {'history': history, 'changes': _segments(history),
                'stopped': _stopped()}
    missing = [r for r in room_types if prices.get(r) is None]
    return {'prices': prices, 'dates': dates, 'missing': missing,
            'stopped': _stopped()}


def _load_scan_config() -> tuple:
    """Reads the REAL app config (read-only): active OTA profiles and
    the room categories tracked in target_prices."""
    import os as _os
    cfg_path = _os.path.join(_os.environ['APPDATA'], 'OTA Guard V3',
                             'data', 'config.json')
    c = json.loads(Path(cfg_path).read_text(encoding='utf-8'))
    watch = c.get('ota_watch') or {}
    profiles = [p for p in (watch.get('otas') or [])
                if p.get('active') and p.get('url')]
    targets = watch.get('target_prices') or {}
    rooms = [r for r, t in targets.items() if isinstance(t, dict) and t]
    if not rooms:
        rooms = [r for r in (c.get('room_types') or []) if r]
    return profiles, rooms


def run_scan(mode: str = 'normal', days: int = 30,
             config_profiles=None, room_types=None, log=print) -> dict:
    """THE entry point for OTA Guard.

    mode 'normal': per category, walk dates until a price shows up
    (cap +14 days).  mode 'deep': walk ALL days dates (configurable
    duration) and accumulate the whole price history per category.

    Routing: Agoda → VAE1+VAE4 engine (temp tabs, proven); Airbnb →
    booking-card machine per listing; the rest → user-tab date-walk.
    """
    STOP_FLAG["stop"] = False
    if config_profiles is None or room_types is None:
        _profiles, _rooms = _load_scan_config()
        config_profiles = config_profiles if config_profiles is not None \
            else _profiles
        room_types = room_types if room_types is not None else _rooms
    if isinstance(config_profiles, dict):
        config_profiles = [{'name': n, 'url': u, 'watch_urls': [u]}
                           for n, u in config_profiles.items()]
    try:
        urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=3)
    except Exception:
        log("[scan] Brave fermé — lancement automatique…")
        _launch_brave()
    maps = _ota_display_maps()
    log(f"[scan] mode={mode}"
        + (f" durée={days} jours" if mode == 'deep' else "")
        + f" — {len(room_types)} catégories, "
        f"{len(config_profiles)} OTA")
    results = {}
    for profile in config_profiles:
        if _stopped():
            break
        ota_name = profile.get('name') or '?'
        base_url = profile.get('url') or ''
        host = urlsplit(base_url).hostname or ''
        try:
            if 'agoda' in host:
                fn, kw = ((scan_normal, {'max_walk': 14})
                          if mode == 'normal'
                          else (scan_deep, {'days': days}))
                results[ota_name] = fn(base_url, room_types, log=log, **kw)
                results[ota_name]['stopped'] = _stopped()
            else:
                urls = _airbnb_listings(profile) \
                    if 'airbnb' in host else [base_url]
                results[ota_name] = scan_ota_user_tab(
                    ota_name, urls, room_types, mode=mode, days=days,
                    maps=maps, log=log)
        except Exception as e:
            log(f"[scan/{ota_name}] ❌ {type(e).__name__}: {e}")
            results[ota_name] = {'error': f"{type(e).__name__}: {e}"}
    return results
