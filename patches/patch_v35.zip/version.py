# Current version of OTA Guard
# Update on every release before compiling
# 3.0.0 (2026-08-24): Extranet Direct CM — full verified cycle
# (E4 §15-17), 2-click auto-login (D26), session keep-alive (E5/D9).
VERSION    = "3.0.36"
BUILD_DATE = "2026-10-28"

# Product identity (used by the "About" screen and .exe metadata)
PRODUCT_NAME = "OTA Guard"
COMPANY      = "LISBOA PVT"
COPYRIGHT    = "© 2026 LISBOA PVT — All rights reserved."

# Legal mentions — registered Indian company
COMPANY_ADDRESS = "1/22 Second floor, Asaf Ali Road, New Delhi 110002, India"
COMPANY_CIN     = "U55101DL2022PTC394676"
COMPANY_GST     = "07AAECL9436G1ZB"
